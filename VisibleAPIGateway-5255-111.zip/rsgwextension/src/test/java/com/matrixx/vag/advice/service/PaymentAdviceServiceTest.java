package com.matrixx.vag.advice.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.ArgumentMatchers.contains;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doReturn;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.aggregator.ArgumentsAccessor;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.matrixx.datacontainer.MtxDate;
import com.matrixx.datacontainer.MtxObjectId;
import com.matrixx.datacontainer.MtxTimestamp;
import com.matrixx.datacontainer.SubscriberManagementApi;
import com.matrixx.datacontainer.mdc.BalanceInfo;
import com.matrixx.datacontainer.mdc.MtxBalanceInfo;
import com.matrixx.datacontainer.mdc.MtxPricingMetadataInfo;
import com.matrixx.datacontainer.mdc.MtxPurchasedOfferInfo;
import com.matrixx.datacontainer.mdc.MtxResponseDevice;
import com.matrixx.datacontainer.mdc.MtxResponseGroup;
import com.matrixx.datacontainer.mdc.MtxResponseMulti;
import com.matrixx.datacontainer.mdc.MtxResponsePricingBalance;
import com.matrixx.datacontainer.mdc.MtxResponsePricingCatalogItem;
import com.matrixx.datacontainer.mdc.MtxResponsePurchase;
import com.matrixx.datacontainer.mdc.MtxResponseRecurringChargeInfo;
import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import com.matrixx.datacontainer.mdc.MtxSubscriberSearchData;
import com.matrixx.datacontainer.mdc.PurchasedOfferInfo;
import com.matrixx.datacontainer.mdc.SubscriptionResponse;
import com.matrixx.datacontainer.mdc.VisibleCredits;
import com.matrixx.datacontainer.mdc.VisibleDeviceExtension;
import com.matrixx.datacontainer.mdc.VisibleOfferDetails;
import com.matrixx.datacontainer.mdc.VisiblePurchasedOfferExtension;
import com.matrixx.datacontainer.mdc.VisibleRequestPaymentAdviceService;
import com.matrixx.datacontainer.mdc.VisibleResponsePaymentAdviceService;
import com.matrixx.datacontainer.mdc.VisibleSubscriberExtension;
import com.matrixx.datacontainer.mdc.VisibleTemplate;
import com.matrixx.vag.CommonTestHelper;
import com.matrixx.vag.TestDescription;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.Constants.CI_METADATA;
import com.matrixx.vag.common.Constants.CREDIT_CONSTANTS;
import com.matrixx.vag.common.Constants.DEVICE_CONSTANTS;
import com.matrixx.vag.common.Constants.MATRIXX_CONSTANTS;
import com.matrixx.vag.common.Constants.OFFER_CONSTANTS;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.common.Constants.TAX_CONSTANTS;
import com.matrixx.vag.common.OneParameterTest;
import com.matrixx.vag.common.TestConstants.BALANCE_NAMES;
import com.matrixx.vag.common.TestConstants.CI_EXTERNAL_IDS;
import com.matrixx.vag.common.TestConstants.DATA_DIR;
import com.matrixx.vag.common.TestConstants.OFFER_PRICES;
import com.matrixx.vag.common.TestConstants.PURCHASE_SERVICE_TYPES;
import com.matrixx.vag.common.TestConstants.TAX_CLASS_CODES;
import com.matrixx.vag.common.TestUtils;
import com.matrixx.vag.common.TwoParameterTest;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.exception.PaymentAdviceException;
import com.matrixx.vag.exception.TaxApiException;
import com.matrixx.vag.tax.client.TaxApiClient;
import com.matrixx.vag.tax.model.DpcGroup;
import com.matrixx.vag.tax.model.DpcGroupTax;
import com.matrixx.vag.tax.model.DpcItem;
import com.matrixx.vag.tax.model.DpcItemTax;
import com.matrixx.vag.tax.model.ServiceTaxRequest;
import com.matrixx.vag.tax.model.ServiceTaxResponse;
import com.matrixx.vag.tax.model.TaxItem;
import com.matrixx.vag.tax.model.TransactionElement;
import com.matrixx.vag.util.MDCTest;

public class PaymentAdviceServiceTest extends MDCTest {

    /**
     * Some test cases will fail. These are cases where we want template attributes modified. We
     * should explore using @TestInstance annotation for such test cases.
     */

    @Spy
    @InjectMocks
    private PaymentAdviceService instance;

    @Mock
    private SubscriberManagementApi api;

    private TestInfo testInfo;

    @BeforeEach
    public void setUp(TestInfo testInfo) throws Exception {
        instance = new PaymentAdviceService();
        MockitoAnnotations.openMocks(this);
        this.testInfo = testInfo;
    }

    @Test
    public void test_getAOP_When_NoError_Then_CorrectCycleTimes() throws Exception {
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(
                        CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.GRANT_GOODWILL,
                        CI_EXTERNAL_IDS.GOODWILL_REDEEM, CI_EXTERNAL_IDS.PARTY_PAY_GRANT));

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                "1234", ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                "1234", ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        subscriptionResponse.getBillingCycle().setDateOffset(1L);
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(BigDecimal.ZERO).when(instance).getChargeableAmountForPurchaseOffer(
                any(), eq(CI_EXTERNAL_IDS.PARTY_PAY_REDEEM), any(),
                any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        // Assertions here.
        assertEquals(
                subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime().getTime(),
                output.getCycleStartTime());
        assertEquals(
                TestUtils.addOneMonth(
                        subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime(),
                        subscriptionResponse.getTimeZone()).toString(),
                output.getCycleEndTime());
    }

    @Test
    @Tag("Tax")
    public void test_getAOP_When_TaxCallFail_Then_IntegrationServiceException() throws Exception {
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(
                        CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.GRANT_GOODWILL,
                        CI_EXTERNAL_IDS.PARTY_PAY_GRANT));

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(BigDecimal.ZERO).when(instance).getChargeableAmountForPurchaseOffer(
                any(), eq(CI_EXTERNAL_IDS.PARTY_PAY_REDEEM), any(),
                any(MtxSubscriberSearchData.class));
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), any(String.class))).thenThrow(
                            new TaxApiException((long) -100, "TestInternalError"));
            // method to test
            instance.getAOP(input, output);
        }

        System.out.println(output.toJson());

        assertTrue(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS == output.getResult());
        assertTrue(!MATRIXX_CONSTANTS.RESULT_TEXT_MTX_SUCCESS.equals(output.getResultText()));
        assertTrue(output.getResultText().contains("TestInternalError"));
    }

    @Test
    @Tag("Tax")
    public void test_getAOP_When_TaxCallFail_Then_ResultTextHasTaxError() throws Exception {
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(
                        CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.GRANT_GOODWILL,
                        CI_EXTERNAL_IDS.PARTY_PAY_GRANT));
        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        doReturn(BigDecimal.ZERO).when(instance).getChargeableAmountForPurchaseOffer(
                any(), eq(CI_EXTERNAL_IDS.PARTY_PAY_REDEEM), any(),
                any(MtxSubscriberSearchData.class));
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), any(String.class))).thenThrow(
                            new TaxApiException((long) -100, "TestInternalError"));
            // method to test
            instance.getAOP(input, output);
        }
        System.out.println(output.toJson());

        assertTrue(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS == output.getResult());
        assertTrue(!MATRIXX_CONSTANTS.RESULT_TEXT_MTX_SUCCESS.equals(output.getResultText()));
        assertTrue(output.getResultText().contains("TestInternalError"));
    }

    // MethodName_StateUnderTest_ExpectedBehavior
    @SuppressWarnings("unchecked")
    @Test
    @Tag("Tax")
    public void test_getAOP_When_TaxError_For_Promos() throws Exception {
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(
                        CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.GRANT_GOODWILL,
                        CI_EXTERNAL_IDS.PARTY_PAY_GRANT));

        subscription.getBalanceArrayAppender().clear();
        MtxBalanceInfo mbiGoodGrant = CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                CI_EXTERNAL_IDS.GRANT_GOODWILL, BigDecimal.ZERO);
        subscription.getBalanceArrayAppender().add(mbiGoodGrant);
        MtxBalanceInfo mbiGoodConsump = CommonTestHelper.getMtxBalanceInfoForPromoConsumable(
                CI_EXTERNAL_IDS.GRANT_GOODWILL, BigDecimal.valueOf(0.0001));
        subscription.getBalanceArrayAppender().add(mbiGoodConsump);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        doReturn(BigDecimal.ZERO).when(instance).getChargeableAmountForPurchaseOffer(
                any(), eq(CI_EXTERNAL_IDS.PARTY_PAY_REDEEM), any(),
                any(MtxSubscriberSearchData.class));
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), any(String.class))).thenThrow(
                            new TaxApiException((long) -100, "TestInternalError"));
            // method to test
            instance.getAOP(input, output);
        }
        System.out.println(output.toJson());
        assertTrue(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS == output.getResult());
        assertTrue(output.getResultText().contains("Error"));
    }

    @Test
    @Tag("Tax")
    public void test_getAOP_When_TaxError_For_Service(TestInfo testInfo) throws Exception {
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(
                        CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.GRANT_GOODWILL,
                        CI_EXTERNAL_IDS.PARTY_PAY_GRANT));

        System.out.println(testInfo.getDisplayName() + ":" + subscription.toJson());

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        emulateMtxResponseSubscription(instance, subscription);
        doReturn(BigDecimal.ZERO).when(instance).getChargeableAmountForPurchaseOffer(
                any(), eq(CI_EXTERNAL_IDS.PARTY_PAY_REDEEM), any(),
                any(MtxSubscriberSearchData.class));
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), contains("CA"))).thenThrow(
                    new TaxApiException((long) -100, "TestInternalError"));
        }
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        assertTrue(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS == output.getResult());
        assertTrue(output.getResultText().contains("Error"));
    }

    @SuppressWarnings("unchecked")
    @Test
    @Tag("Tax")
    public void test_getAOP_When_CreditsPresent_Then_CreditTaxAreCorrect(TestInfo testInfo)
            throws Exception {
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.PLUS2VIS22);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(CI_EXTERNAL_IDS.PLUS2VIS22, CI_EXTERNAL_IDS.GRANT_GOODWILL));

        subscription.getBalanceArrayAppender().clear();
        MtxBalanceInfo mbiGoodGrant = CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                CI_EXTERNAL_IDS.GRANT_GOODWILL, BigDecimal.valueOf(20));
        subscription.getBalanceArrayAppender().add(mbiGoodGrant);
        MtxBalanceInfo mbiGoodConsump = CommonTestHelper.getMtxBalanceInfoForPromoConsumable(
                CI_EXTERNAL_IDS.GRANT_GOODWILL, BigDecimal.ZERO);
        subscription.getBalanceArrayAppender().add(mbiGoodConsump);

        System.out.println(subscription.toJson());
        MtxResponsePricingCatalogItem pciGoodwill = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.GRANT_GOODWILL);
        VisibleTemplate vtGoodwill = (VisibleTemplate) pciGoodwill.getCatalogItemInfo().getTemplateAttr();
        vtGoodwill.setTaxResponseUnchanged("N");

        String taxRespServiceAsPromo = CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.PLUS2VIS22);

        String taxRespSansRefCredit = CommonTestHelper.getTaxApiResp(
                CI_EXTERNAL_IDS.PLUS2VIS22, 20, TAX_CLASS_CODES.GOODWILL);
        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            // This emulation should be split into two. One for regular tax other for servicetax as
            // promotion
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(
                            any(), contains(TAX_CLASS_CODES.SERVICE))).thenReturn(
                                    taxRespServiceAsPromo);
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(
                            any(), contains(TAX_CLASS_CODES.GOODWILL))).thenReturn(
                                    taxRespSansRefCredit);
            // method to test
            instance.getAOP(input, output);
        }

        System.out.println(testInfo.getDisplayName() + " : " + output.toJson());
        ServiceTaxResponse promoTaxResp = CommonTestHelper.getJsonFromString(
                ServiceTaxResponse.class,
                output.getCredits().stream().filter(
                        vc -> vc.getCreditRedeemableOfferCI().equals(
                                CI_EXTERNAL_IDS.GOODWILL_REDEEM)).findAny().get().getTaxDetails());

        System.out.println(testInfo.getDisplayName() + " : " + promoTaxResp.toJson());

        ServiceTaxResponse taxRespServiceAsPromoJson = CommonTestHelper.getJsonFromString(
                ServiceTaxResponse.class, taxRespServiceAsPromo);
        ServiceTaxResponse taxRespSansRefCreditJson = CommonTestHelper.getJsonFromString(
                ServiceTaxResponse.class, taxRespSansRefCredit);

        assertEquals(
                taxRespServiceAsPromoJson.getDiscountPrice().subtract(
                        taxRespSansRefCreditJson.getDiscountPrice()).doubleValue(),
                promoTaxResp.getDiscountPrice().doubleValue(), 0.001);

        assertEquals(TAX_CLASS_CODES.GOODWILL, promoTaxResp.getClassCode());

        promoTaxResp.getTransactionElement().forEach(te -> {
            TransactionElement servicete = taxRespServiceAsPromoJson.getTransactionElement().stream().filter(
                    te1 -> te1.getBtcTransactionCode().equals(
                            te.getBtcTransactionCode())).findFirst().get();
            TransactionElement negatete = taxRespSansRefCreditJson.getTransactionElement().stream().filter(
                    te1 -> te1.getBtcTransactionCode().equals(
                            te.getBtcTransactionCode())).findFirst().get();
            System.out.println(
                    testInfo.getDisplayName() + ": " + "validating BtcTransactionCode: "
                            + servicete.getBtcTransactionCode() + "-"
                            + negatete.getBtcTransactionCode());
            assertEquals(
                    servicete.getTotalTaxAmount().subtract(
                            negatete.getTotalTaxAmount()).doubleValue(),
                    te.getTotalTaxAmount().doubleValue(), 0.001);

            assertEquals(
                    servicete.getTotalNetRevenue().subtract(
                            negatete.getTotalNetRevenue()).doubleValue(),
                    te.getTotalNetRevenue().doubleValue(), 0.001);

            assertEquals(
                    servicete.getModifiedDisplayNetRevenue().subtract(
                            negatete.getModifiedDisplayNetRevenue()).doubleValue(),
                    te.getModifiedDisplayNetRevenue().doubleValue(), 0.001);

            te.getDpcGroupList().forEach(dg -> {
                DpcGroupTax servicedg = servicete.getDpcGroupList().stream().filter(
                        dg1 -> dg1.getDpcGroup().equals(dg.getDpcGroup())).findAny().get();
                DpcGroupTax negatedg = negatete.getDpcGroupList().stream().filter(
                        dg1 -> dg1.getDpcGroup().equals(dg.getDpcGroup())).findAny().get();

                System.out.println(
                        testInfo.getDisplayName() + ": " + "validating DpcGroup: "
                                + servicedg.getDpcGroup() + "-" + negatedg.getDpcGroup());
                dg.getDpcItemList().forEach(dit -> {

                    DpcItemTax servicedit = servicedg.getDpcItemList().stream().filter(
                            dit1 -> dit1.getDpcItem().equals(dit.getDpcItem())).findFirst().get();
                    DpcItemTax negatedit = negatedg.getDpcItemList().stream().filter(
                            dit1 -> dit1.getDpcItem().equals(dit.getDpcItem())).findFirst().get();

                    System.out.println(
                            testInfo.getDisplayName() + ": " + "validating GlReference: "
                                    + servicedit.getGlReference() + "-"
                                    + negatedit.getGlReference());
                    assertEquals(
                            servicedit.getDpcItemTaxAmount().subtract(
                                    negatedit.getDpcItemTaxAmount()).doubleValue(),
                            dit.getDpcItemTaxAmount().doubleValue(), 0.001);
                    assertEquals(
                            servicedit.getDpcItemNetRevenue().subtract(
                                    negatedit.getDpcItemNetRevenue()).doubleValue(),
                            dit.getDpcItemNetRevenue().doubleValue(), 0.001);

                    // Below assertion should be validated better. We should make sure that tax by
                    // subtraction works.
                    dit.getTaxItemList().forEach(ti -> {
                        if (servicedit.getTaxItemList() != null
                                && servicedit.getTaxItemList().size() > 0
                                && negatedit.getTaxItemList() != null
                                && negatedit.getTaxItemList().size() > 0) {

                            TaxItem serviceit = servicedit.getTaxItemList().stream().filter(
                                    ti1 -> ti1.getTaxCategory().equals(ti.getTaxCategory())
                                            && ti1.getTaxType().equals(
                                                    ti.getTaxType())).findFirst().get();
                            TaxItem negateit = negatedit.getTaxItemList().stream().filter(
                                    ti1 -> ti1.getTaxCategory().equals(ti.getTaxCategory())
                                            && ti1.getTaxType().equals(
                                                    ti.getTaxType())).findFirst().get();
                            System.out.println(
                                    testInfo.getDisplayName() + ": "
                                            + "validating TaxItemDescription"
                                            + serviceit.getDescription() + "-"
                                            + negateit.getDescription());
                            assertEquals(
                                    serviceit.getTaxAmount().subtract(
                                            negateit.getTaxAmount()).doubleValue(),
                                    ti.getTaxAmount().doubleValue(), 0.001,
                                    serviceit.getTaxAmount() + "-" + negateit.getTaxAmount() + "!="
                                            + ti.getTaxAmount());
                        }
                    });
                });
            });
        });
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getAOP_When_NoRedeemable_PrevTaxStringNotPresent_Then_CreditNodeNotCreated()
            throws Exception {
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");
        input.setSubscriberExternalId("123");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(
                        CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.GRANT_GOODWILL,
                        CI_EXTERNAL_IDS.PARTY_PAY_GRANT));

        subscription.getPurchasedOfferArray().forEach(poi -> {
            if (poi.getCatalogItemExternalId() != null
                    && poi.getCatalogItemExternalId().equals(CI_EXTERNAL_IDS.UNLIMITED)) {
                VisiblePurchasedOfferExtension attr = (VisiblePurchasedOfferExtension) poi.getAttr();
                while (attr.getCreditTaxDetailsArrayAppender().size() > 0) {
                    attr.getCreditTaxDetailsArrayAppender().removeAt(0);
                }
                attr.getCreditTaxDetailsArrayAppender().add(
                        "{\"msgID\":\"ABCD-CR\",\"customerType\":\"99\",\"planID\":\"BASE001A\",\"grossPrice\":\"0\",\"discountPrice\":\"0\",\"promotionCredit\":\"true\",\"offer606RevAdjDailyRecog\":\"0\",\"promotionReason\":\"Goodwill_Credits\",\"geocode\":\"US0100108296\",\"taxTreatment\":\"inclusive\",\"classCode\":\"GOOD-CR\",\"glDate\":\"2019-03-07\",\"transactionElement\":[{\"btcTransactionCode\":\"01\",\"totalTaxAmount\":\"0.00000000\",\"totalFeeAmount\":\"0.00000000\",\"totalNetRevenue\":\"0.00000000\",\"modifiedDisplayNetRevenue\":\"0.00\",\"dpcGroupList\":[{\"dpcGroup\":\"5018\",\"dpcItemList\":[{\"dpcItem\":\"618\",\"cP\":\"0.75\",\"glReference\":\"Visible_Unlimited_Data\",\"dpcItemTaxAmount\":\"0.00000000\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.00000000\",\"taxItemList\":[]},{\"dpcItem\":\"601\",\"cP\":\"0.12\",\"glReference\":\"Visible_Unlimited_Voice\",\"dpcItemTaxAmount\":\"0.00000000\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.00000000\",\"taxItemList\":[]},{\"dpcItem\":\"662\",\"cP\":\"0.04\",\"glReference\":\"Visible_Unlimited_Text\",\"dpcItemTaxAmount\":\"0.00000000\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.00000000\",\"taxItemList\":[]},{\"dpcItem\":\"629\",\"cP\":\"0.09\",\"glReference\":\"Visible_Unlimited_MMS\",\"dpcItemTaxAmount\":\"0.00000000\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.00000000\",\"taxItemList\":[]}]}]}]}");
                attr.getCreditTaxDetailsArrayAppender().add(
                        "{\"msgID\":\"EFGH-CR\",\"customerType\":\"99\",\"planID\":\"BASE001A\",\"grossPrice\":\"5.00\",\"discountPrice\":\"5.00\",\"promotionCredit\":\"true\",\"offer606RevAdjDailyRecog\":\"0\",\"promotionReason\":\"Referee_Credits\",\"geocode\":\"US0100108296\",\"taxTreatment\":\"inclusive\",\"classCode\":\"REF-CR\",\"glDate\":\"2019-03-07\",\"transactionElement\":[{\"btcTransactionCode\":\"01\",\"totalTaxAmount\":\"0.07389163\",\"totalFeeAmount\":\"0.00000000\",\"totalNetRevenue\":\"4.92610836\",\"modifiedDisplayNetRevenue\":\"4.93\",\"dpcGroupList\":[{\"dpcGroup\":\"5018\",\"dpcItemList\":[{\"dpcItem\":\"618\",\"cP\":\"0.75\",\"glReference\":\"Visible_Unlimited_Data\",\"dpcItemTaxAmount\":\"0.00000000\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"3.69458128\",\"taxItemList\":[]},{\"dpcItem\":\"601\",\"cP\":\"0.12\",\"glReference\":\"Visible_Unlimited_Voice\",\"dpcItemTaxAmount\":\"0.03546798\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.59113300\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012000\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"01\",\"description\":\"AL State Sales Tax\",\"rate\":\"0.040000000000\",\"taxAmount\":\"0.02364532\"},{\"taxItemType\":\"tax\",\"tai\":\"000001274\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"02\",\"description\":\"Autauga Cnty Sales Tax\",\"rate\":\"0.020000000000\",\"taxAmount\":\"0.01182266\"}]},{\"dpcItem\":\"662\",\"cP\":\"0.04\",\"glReference\":\"Visible_Unlimited_Text\",\"dpcItemTaxAmount\":\"0.01182266\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.19704433\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012000\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"01\",\"description\":\"AL State Sales Tax\",\"rate\":\"0.040000000000\",\"taxAmount\":\"0.00788177\"},{\"taxItemType\":\"tax\",\"tai\":\"000001274\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"02\",\"description\":\"Autauga Cnty Sales Tax\",\"rate\":\"0.020000000000\",\"taxAmount\":\"0.00394089\"}]},{\"dpcItem\":\"629\",\"cP\":\"0.09\",\"glReference\":\"Visible_Unlimited_MMS\",\"dpcItemTaxAmount\":\"0.02660099\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.44334975\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012000\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"01\",\"description\":\"AL State Sales Tax\",\"rate\":\"0.040000000000\",\"taxAmount\":\"0.01773399\"},{\"taxItemType\":\"tax\",\"tai\":\"000001274\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"02\",\"description\":\"Autauga Cnty Sales Tax\",\"rate\":\"0.020000000000\",\"taxAmount\":\"0.00886700\"}]}]}]},{\"btcTransactionCode\":\"93\",\"totalTaxAmount\":\"0.03002956\",\"totalFeeAmount\":\"0.00000000\",\"totalNetRevenue\":\"4.92610836\",\"modifiedDisplayNetRevenue\":\"4.93\",\"dpcGroupList\":[{\"dpcGroup\":\"5018\",\"dpcItemList\":[{\"dpcItem\":\"601\",\"cP\":\"0.12\",\"glReference\":\"Visible_Unlimited_Voice\",\"dpcItemTaxAmount\":\"0.03002956\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.59113300\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000000016\",\"tat\":\"0\",\"taxCategory\":\"00\",\"taxType\":\"35\",\"description\":\"Fed Universal Service Charge\",\"rate\":\"0.050800000000\",\"taxAmount\":\"0.03002956\"}]}]}]}]}");
                attr.getCreditTaxDetailsArrayAppender().add(
                        "{\"msgID\":\"IJKL-CR\",\"customerType\":\"99\",\"planID\":\"BASE001A\",\"grossPrice\":\"5.00\",\"discountPrice\":\"5.00\",\"promotionCredit\":\"true\",\"offer606RevAdjDailyRecog\":\"0\",\"promotionReason\":\"Group_Discounts\",\"geocode\":\"US0100108296\",\"taxTreatment\":\"inclusive\",\"classCode\":\"GD-CR\",\"glDate\":\"2019-03-07\",\"transactionElement\":[{\"btcTransactionCode\":\"01\",\"totalTaxAmount\":\"0.07389163\",\"totalFeeAmount\":\"0.00000000\",\"totalNetRevenue\":\"4.92610836\",\"modifiedDisplayNetRevenue\":\"4.93\",\"dpcGroupList\":[{\"dpcGroup\":\"5018\",\"dpcItemList\":[{\"dpcItem\":\"618\",\"cP\":\"0.75\",\"glReference\":\"Visible_Unlimited_Data\",\"dpcItemTaxAmount\":\"0.00000000\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"3.69458128\",\"taxItemList\":[]},{\"dpcItem\":\"601\",\"cP\":\"0.12\",\"glReference\":\"Visible_Unlimited_Voice\",\"dpcItemTaxAmount\":\"0.03546798\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.59113300\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012000\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"01\",\"description\":\"AL State Sales Tax\",\"rate\":\"0.040000000000\",\"taxAmount\":\"0.02364532\"},{\"taxItemType\":\"tax\",\"tai\":\"000001274\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"02\",\"description\":\"Autauga Cnty Sales Tax\",\"rate\":\"0.020000000000\",\"taxAmount\":\"0.01182266\"}]},{\"dpcItem\":\"662\",\"cP\":\"0.04\",\"glReference\":\"Visible_Unlimited_Text\",\"dpcItemTaxAmount\":\"0.01182266\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.19704433\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012000\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"01\",\"description\":\"AL State Sales Tax\",\"rate\":\"0.040000000000\",\"taxAmount\":\"0.00788177\"},{\"taxItemType\":\"tax\",\"tai\":\"000001274\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"02\",\"description\":\"Autauga Cnty Sales Tax\",\"rate\":\"0.020000000000\",\"taxAmount\":\"0.00394089\"}]},{\"dpcItem\":\"629\",\"cP\":\"0.09\",\"glReference\":\"Visible_Unlimited_MMS\",\"dpcItemTaxAmount\":\"0.02660099\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.44334975\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000012000\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"01\",\"description\":\"AL State Sales Tax\",\"rate\":\"0.040000000000\",\"taxAmount\":\"0.01773399\"},{\"taxItemType\":\"tax\",\"tai\":\"000001274\",\"tat\":\"3\",\"taxCategory\":\"01\",\"taxType\":\"02\",\"description\":\"Autauga Cnty Sales Tax\",\"rate\":\"0.020000000000\",\"taxAmount\":\"0.00886700\"}]}]}]},{\"btcTransactionCode\":\"93\",\"totalTaxAmount\":\"0.03002956\",\"totalFeeAmount\":\"0.00000000\",\"totalNetRevenue\":\"4.92610836\",\"modifiedDisplayNetRevenue\":\"4.93\",\"dpcGroupList\":[{\"dpcGroup\":\"5018\",\"dpcItemList\":[{\"dpcItem\":\"601\",\"cP\":\"0.12\",\"glReference\":\"Visible_Unlimited_Voice\",\"dpcItemTaxAmount\":\"0.03002956\",\"dpcItemFeeAmount\":\"0.00000000\",\"dpcItemNetRevenue\":\"0.59113300\",\"taxItemList\":[{\"taxItemType\":\"tax\",\"tai\":\"000000016\",\"tat\":\"0\",\"taxCategory\":\"00\",\"taxType\":\"35\",\"description\":\"Fed Universal Service Charge\",\"rate\":\"0.050800000000\",\"taxAmount\":\"0.03002956\"}]}]}]}]}");
            }
        });

        String taxApiResp = CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.UNLIMITED);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        doReturn(BigDecimal.ZERO).when(instance).getChargeableAmountForPurchaseOffer(
                any(), eq(CI_EXTERNAL_IDS.PARTY_PAY_REDEEM), any(),
                any(MtxSubscriberSearchData.class));
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxApiResp);
            // method to test
            instance.getAOP(input, output);
        }
        System.out.println(output.toJson());
        assertNull(output.getCredits());
    }

    @Test
    public void test_getAOP_When_TaxDetailsRequested_Then_PayNowPlusConsumableMainbalanceEqTaxDiscPrice()
            throws Exception {
        mockSubscriberGroup(instance, null);
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        List<String> ciExternalIds = Arrays.asList(
                CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.INSURANCE);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(
                        CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.GRANT_GOODWILL,
                        CI_EXTERNAL_IDS.INSURANCE));
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        MtxResponsePurchase aocRespGroupVBPP = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.PAYMENT_ADVICE + "MtxResponsePurchase.json");
        aocRespGroupVBPP.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                0).getBalanceImpactList().forEach(bi -> {
                    // Set all amounts to zero
                    bi.setImpactAmount(BigDecimal.ZERO);
                    bi.getBalanceImpactOfferList().forEach(bioiVbpp -> {
                        bioiVbpp.getBalanceImpactUpdateList().forEach(biui -> {
                            biui.setAmount(BigDecimal.ZERO);
                        });
                    });
                });

        doReturn(aocRespGroupVBPP).when(instance).doSubscriberPurchaseOfferAOC(
                any(), eq(CI_EXTERNAL_IDS.VBPP25_AOC_REDEEM), any(), any());

        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
        String taxApiResp = CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.UNLIMITED);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxApiResp);
            // method to test
            instance.getAOP(input, output);
        }
        System.out.println(output.toJson());
        argumentCaptor.getAllValues().forEach(req -> {
            System.out.println(req);
        });

        BigDecimal serviceTaxDiscountPrice = argumentCaptor.getAllValues().stream().map(
                taxString -> {
                    try {
                        return CommonTestHelper.getJsonFromString(
                                ServiceTaxRequest.class, taxString);
                    } catch (IOException e) {
                        e.printStackTrace();
                        return null;
                    }
                }).filter(taxReq -> taxReq.getClassCode().equals(TAX_CLASS_CODES.SERVICE)).map(
                        taxReq -> taxReq.getDiscountPrice()).findFirst().get();

        BigDecimal insuranceTaxDiscountPrice = argumentCaptor.getAllValues().stream().map(
                taxString -> {
                    try {
                        return CommonTestHelper.getJsonFromString(
                                ServiceTaxRequest.class, taxString);
                    } catch (IOException e) {
                        e.printStackTrace();
                        return null;
                    }
                }).filter(taxReq -> taxReq.getClassCode().equals(TAX_CLASS_CODES.INSURANCE)).map(
                        taxReq -> taxReq.getDiscountPrice()).findFirst().get();

        argumentCaptor.getAllValues().forEach(arg -> {
            System.out.println(arg);
        });

        assertEquals(
                output.getEstimatedPayableAmount().add(
                        output.getConsumableMainBalanceAmount()).doubleValue(),
                serviceTaxDiscountPrice.add(insuranceTaxDiscountPrice).doubleValue(), 0.01);
    }

    @Test
    public void test_getAOP_When_GeoCodeInRequest_Then_CorrectGeoCodeInServiceTaxRequest()
            throws Exception {
        String testGeoCode = "ELBISIVNOZIREV";

        mockSubscriberGroup(instance, null);
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");
        input.setTaxGeoCode(testGeoCode);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        List<String> ciExternalIds = Arrays.asList(
                CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.INSURANCE);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItems(
                instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.INSURANCE));
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());

        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
        String taxApiResp = CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.UNLIMITED);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxApiResp);
            // method to test
            instance.getAOP(input, output);
        }
        System.out.println(output.toJson());
        argumentCaptor.getAllValues().forEach(taxReq -> {
            System.out.println(taxReq);
        });

        String serviceTaxGeoCode = argumentCaptor.getAllValues().stream().map(taxString -> {
            try {
                return CommonTestHelper.getJsonFromString(ServiceTaxRequest.class, taxString);
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }).filter(taxReq -> taxReq.getClassCode().equals(TAX_CLASS_CODES.SERVICE)).map(
                taxReq -> taxReq.getGeocode()).findFirst().get();

        String insuranceTaxGeoCode = argumentCaptor.getAllValues().stream().map(taxString -> {
            try {
                return CommonTestHelper.getJsonFromString(ServiceTaxRequest.class, taxString);
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }).filter(taxReq -> taxReq.getClassCode().equals(TAX_CLASS_CODES.INSURANCE)).map(
                taxReq -> taxReq.getGeocode()).findFirst().get();

        assertEquals(testGeoCode, serviceTaxGeoCode);
        assertEquals(testGeoCode, insuranceTaxGeoCode);
    }

    @Test
    public void test_getAOP_When_GeoCodeInRequest_Then_CorrectGeoCodeInCreditTaxRequest()
            throws Exception {
        String testGeoCode = "ELBISIVNOZIREV";
        mockSubscriberGroup(instance, null);
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");
        input.setTaxGeoCode(testGeoCode);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
        String taxApiResp = CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.UNLIMITED);

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED));

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxApiResp);

            // method to test
            instance.getAOP(input, output);
            System.out.println(output.toJson());
            argumentCaptor.getAllValues().forEach(taxReq -> {
                System.out.println(taxReq);
            });

            argumentCaptor.getAllValues().stream().map(taxString -> {
                try {
                    return CommonTestHelper.getJsonFromString(ServiceTaxRequest.class, taxString);
                } catch (IOException e) {
                    e.printStackTrace();
                    return null;
                }
            }).map(taxReq -> taxReq.getGeocode()).forEach(creditTaxGeoCode -> {
                assertEquals(testGeoCode, creditTaxGeoCode);
            });

            assertTrue(argumentCaptor.getAllValues().size() > 0);
        }
    }

    @SuppressWarnings({
        "unchecked", "serial"
    })
    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_getAOP_When_NoError_Then_CorrectGroupCount() throws Exception {
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");
        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        emulateMtxResponsePricingCatalogItems(
                instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.GRANT_GOODWILL));

        mockSubscriberGroup(instance, new HashMap<String, String>() {

            {
                put("SubscriberMemberCount", "99");
            }
        });
        subscriptionResponse.setParentGroupCount(1L);
        subscriptionResponse.getParentGroupIdArrayAppender().clear();
        subscriptionResponse.getParentGroupIdArrayAppender().add(new MtxObjectId("1-2-3-4"));

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        assertEquals(
                99,
                output.getSubscriberGroups().stream().findFirst().get().getSubscriberMemberCount().longValue());
    }

    @SuppressWarnings({
        "unchecked", "serial"
    })
    @Test
    // MethodName_StateUnderTest_ExpectedBehavior
    public void test_getAOP_When_NoError_Then_CorrectGroupName() throws Exception {
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");
        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        emulateMtxResponsePricingCatalogItems(
                instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.GRANT_GOODWILL));

        mockSubscriberGroup(instance, new HashMap<String, String>() {

            {
                put("GroupName", "GN99");
            }
        });
        subscriptionResponse.setParentGroupCount(1L);
        subscriptionResponse.getParentGroupIdArrayAppender().clear();
        subscriptionResponse.getParentGroupIdArrayAppender().add(new MtxObjectId("1-2-3-4"));

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        assertEquals(
                "GN99", output.getSubscriberGroups().stream().findFirst().get().getGroupName());
    }

    @SuppressWarnings({
        "unchecked", "serial"
    })
    @Test
    public void test_getAOP_When_NoError_Then_CorrectGroupTier() throws Exception {
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");
        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED));

        mockSubscriberGroup(instance, new HashMap<String, String>() {

            {
                put("GroupTier", "GT99");
            }
        });
        subscriptionResponse.setParentGroupCount(1L);
        subscriptionResponse.getParentGroupIdArrayAppender().clear();
        subscriptionResponse.getParentGroupIdArrayAppender().add(new MtxObjectId("1-2-3-4"));

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        assertEquals(
                "GT99", output.getSubscriberGroups().stream().findFirst().get().getGroupTier());
    }

    @Test
    public void test_getAOP_WhenServiceTax_Then_IsPromotion_Is_False() throws Exception {
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.PARTY_PAY_GRANT));

        emulateMtxResponseRecurringChargeInfo(
                api, DATA_DIR.PAYMENT_ADVICE + "MtxResponseRecurringChargeInfo_Tax.json");

        String taxRespService = CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.UNLIMITED);
        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxRespService);
            instance.getAOP(input, output);
        }
        System.out.println("AOP Response\n" + output.toJson());
        ServiceTaxRequest serviceTaxReq = CommonTestHelper.getJsonFromString(
                ServiceTaxRequest.class, argumentCaptor.getAllValues().get(0));
        assertTrue(!serviceTaxReq.isPromotionCredit());
    }

    @Test
    public void test_getAOP_When_BaseOfferIsPresent_And_PaidCycleStartDate_Is_In_Future_Then_StandAloneTaxInput_Is_Used()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in Visible_Unlimited and Wearable",
            "Paid cycle start date is in future."
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "Standalone tax template should be used."
        };

        td.printDescription();
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");

        String taxRespService = CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.UNLIMITED);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        List<String> ciExternalIds = Arrays.asList(
                CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.WEARABLE);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        Map<String, MtxResponsePricingCatalogItem> pciMap = emulateMtxResponsePricingCatalogItems(
                instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.WEARABLE));
        MtxResponsePricingCatalogItem pciWearable = pciMap.get(CI_EXTERNAL_IDS.WEARABLE);
        (new PurchasedOfferInfo(
                subscriptionResponse.getAtPurchasedOfferArray(1))).setCatalogItemDetails(
                        pciWearable.getCatalogItemInfo());

        String randomFutureDate = "4712-12-31";
        CommonTestHelper.updatePaidCycleStartDateInMtxResponseSubscription(
                subscription, new MtxDate(randomFutureDate));
        subscriptionResponse.getPurchasedOfferArray().forEach(mpoi -> {
            ((VisiblePurchasedOfferExtension) mpoi.getAttr()).setPaidCycleStartDate(
                    new MtxDate(randomFutureDate));
        });

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxRespService);
            instance.getAOP(input, output);
        }
        System.out.println("AopResponse:" + output.toJson());

        argumentCaptor.getAllValues().forEach(req -> {
            System.out.println(req);
        });
        ServiceTaxRequest taxReq = null;
        ServiceTaxRequest taxReq1 = CommonTestHelper.getJsonFromString(
                ServiceTaxRequest.class, argumentCaptor.getAllValues().get(0));
        if (taxReq1.getMsgID().contains("Wearable")) {
            taxReq = taxReq1;
        }
        ServiceTaxRequest taxReq2 = CommonTestHelper.getJsonFromString(
                ServiceTaxRequest.class, argumentCaptor.getAllValues().get(1));
        if (taxReq2.getMsgID().contains("Wearable")) {
            taxReq = taxReq2;
        }

        assertEquals("STIWearable", taxReq.getMsgID());
    }

    @Test
    public void test_getAOP_When_OfferType_Is_VisibleWearable_Only_Then_StandaloneTaxInput_Is_Used()
            throws Exception {

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");

        String taxRespService = CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.WEARABLE);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.WEARABLE);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        MtxResponsePricingCatalogItem pciWearable = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.WEARABLE);
        (new PurchasedOfferInfo(
                subscriptionResponse.getAtPurchasedOfferArray(0))).setCatalogItemDetails(
                        pciWearable.getCatalogItemInfo());

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {

            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxRespService);
            instance.getAOP(input, output);
        }

        System.out.println("TaxRequest\n" + argumentCaptor.getAllValues().get(0));
        ServiceTaxRequest serviceTaxReq = CommonTestHelper.getJsonFromString(
                ServiceTaxRequest.class, argumentCaptor.getAllValues().get(0));
        assertTrue(!serviceTaxReq.isPromotionCredit());
        assertTrue(serviceTaxReq.getMsgID().equals("STIWearable"));
    }

    @Test
    public void test_getAOP_When_OfferType_Is_AddonPlusBase_And_PaidCycleDate_IsNull_Then_Default_TaxTemplate_Is_Used()
            throws Exception {
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        String taxRespService = CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.UNLIMITED);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        List<String> ciExternalIds = Arrays.asList(
                CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.WEARABLE);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        Map<String, MtxResponsePricingCatalogItem> pciMap = emulateMtxResponsePricingCatalogItems(
                instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.WEARABLE));
        MtxResponsePricingCatalogItem pciWearable = pciMap.get(CI_EXTERNAL_IDS.WEARABLE);
        (new PurchasedOfferInfo(
                subscriptionResponse.getAtPurchasedOfferArray(1))).setCatalogItemDetails(
                        pciWearable.getCatalogItemInfo());

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {

            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxRespService);
            instance.getAOP(input, output);

        }
        System.out.println("AOP Response\n" + output.toJson());

        argumentCaptor.getAllValues().forEach(req -> {
            System.out.println(req);
        });
        ServiceTaxRequest taxReq = null;
        ServiceTaxRequest taxReq1 = CommonTestHelper.getJsonFromString(
                ServiceTaxRequest.class, argumentCaptor.getAllValues().get(0));
        if (taxReq1.getMsgID().contains("Wearable")) {
            taxReq = taxReq1;
        }
        ServiceTaxRequest taxReq2 = CommonTestHelper.getJsonFromString(
                ServiceTaxRequest.class, argumentCaptor.getAllValues().get(1));
        if (taxReq2.getMsgID().contains("Wearable")) {
            taxReq = taxReq2;
        }

        assertEquals("TIWearable", taxReq.getMsgID());
    }

    @Test
    public void test_getAOP_TaxResponse_when_OfferType_Is_Null() throws Exception {
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        String taxRespService = CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.UNLIMITED);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.WEARABLE);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                "1234", ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                "1234", ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        MtxResponsePricingCatalogItem pciWearable = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.WEARABLE);
        ((VisibleTemplate) pciWearable.getCatalogItemInfo().getTemplateAttr()).setOfferType("");
        (new PurchasedOfferInfo(
                subscriptionResponse.getAtPurchasedOfferArray(0))).setCatalogItemDetails(
                        pciWearable.getCatalogItemInfo());

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxRespService);
            instance.getAOP(input, output);
        }
        System.out.println("Tax Request: " + argumentCaptor.getAllValues().get(0));
        ServiceTaxRequest serviceTaxReq = CommonTestHelper.getJsonFromString(
                ServiceTaxRequest.class, argumentCaptor.getAllValues().get(0));
        assertTrue(!serviceTaxReq.isPromotionCredit());
        assertTrue(serviceTaxReq.getMsgID().equals("TIWearable"));

    }

    @Test
    public void test_getAOP_TaxResponse_when_AddonPlusBase_And_PaidCycleStartDate_In_Past_Then_DefaultTaxTemplate_Is_Used()
            throws Exception {
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        String taxRespService = CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.UNLIMITED);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        List<String> ciExternalIds = Arrays.asList(
                CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.WEARABLE);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        Map<String, MtxResponsePricingCatalogItem> pciMap = emulateMtxResponsePricingCatalogItems(
                instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.WEARABLE));
        MtxResponsePricingCatalogItem pciWearable = pciMap.get(CI_EXTERNAL_IDS.WEARABLE);
        (new PurchasedOfferInfo(
                subscriptionResponse.getAtPurchasedOfferArray(1))).setCatalogItemDetails(
                        pciWearable.getCatalogItemInfo());

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
        System.out.println("subscriptionResponse\n" + subscriptionResponse.toJson());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {

            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxRespService);
            instance.getAOP(input, output);
        }

        System.out.println("AOP Response\n" + output.toJson());
        argumentCaptor.getAllValues().forEach(req -> {
            System.out.println(req);
        });
        ServiceTaxRequest taxReq = null;
        ServiceTaxRequest taxReq1 = CommonTestHelper.getJsonFromString(
                ServiceTaxRequest.class, argumentCaptor.getAllValues().get(0));
        if (taxReq1.getMsgID().contains("Wearable")) {
            taxReq = taxReq1;
        }
        ServiceTaxRequest taxReq2 = CommonTestHelper.getJsonFromString(
                ServiceTaxRequest.class, argumentCaptor.getAllValues().get(1));
        if (taxReq2.getMsgID().contains("Wearable")) {
            taxReq = taxReq2;
        }
        assertEquals("TIWearable", taxReq.getMsgID());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getAOP_When_GrantBalanceAttribute_ClassCodeIncompatibilityPresent_Then_IncompatibilityParsed(TestInfo testInfo)
            throws Exception {
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");
        AppPropertyProvider.getInstance().setProperty(
                CREDIT_CONSTANTS.AOC_GRANT_OFFERS, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED));

        MtxResponsePricingCatalogItem ciRef35Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.REF35_GRANT);
        VisibleTemplate vtRef35 = ((VisibleTemplate) ciRef35Grant.getCatalogItemInfo().getTemplateAttr());
        vtRef35.setIncompatiblePromotions(null);

        MtxResponsePricingCatalogItem ciGroupGrant = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingCatalogItem.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingCatalogItem_Visible_Group_Grant.json");
        MtxResponseMulti responseMulti = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class, DATA_DIR.PAYMENT_ADVICE
                        + "MtxResponseMulti_ForSubscriberGroupPartPay_Visible_Group_Grant.json");
        VisibleTemplate vtGroup = ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr());

        vtGroup.setIncompatiblePromotions("{\"IncompatibleList\": [{ \"ClassCode\":\"REF-35\"}]}");

        doReturn(ciGroupGrant).when(instance).queryPricingCatalogItem(
                any(), any(), eq("Visible_Group_Grant"));
        doReturn(responseMulti).when(instance).querySubscriptionGroups(any(), any(), any());

        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscription.getBalanceArrayAppender().clear();

        MtxBalanceInfo mbiRef35 = CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                CI_EXTERNAL_IDS.REF35_GRANT, BigDecimal.valueOf(20));
        subscription.getBalanceArrayAppender().add(mbiRef35);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        doReturn(new BigDecimal("-15")).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        System.out.println(
                testInfo.getDisplayName() + ":" + StringUtils.SPACE + subscription.toJson());
        // method to test
        instance.getAOP(input, output);
        System.out.println(testInfo.getDisplayName() + ":" + StringUtils.SPACE + output.toJson());
        System.out.println("VT GRoup " + vtGroup.toJson());
        // Assertions If group credit is 15 and referral is zero then incompatibility was parsed
        // correctly

        assertEquals(
                15,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGroup.getPromotionName())).findAny().get().getRedeemableCredits().intValue());
        assertEquals(
                0,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtRef35.getPromotionName())).findAny().get().getRedeemableCredits().intValue());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getAOP_When_GrantBalanceAttribute_IncompatibilityWithConditionPresent_Then_IncompatibilityParsed()
            throws Exception {
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");
        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED));

        AppPropertyProvider.getInstance().setProperty(
                CREDIT_CONSTANTS.AOC_GRANT_OFFERS, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);

        MtxResponsePricingCatalogItem ciReferralGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.REF35_GRANT);
        MtxResponseMulti responseMulti = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class, DATA_DIR.PAYMENT_ADVICE
                        + "MtxResponseMulti_ForSubscriberGroupPartPay_Visible_Group_Grant.json");
        VisibleTemplate vtReferral = (VisibleTemplate) ciReferralGrant.getCatalogItemInfo().getTemplateAttr();
        vtReferral.setIncompatiblePromotions("");

        MtxResponsePricingCatalogItem ciGroupGrant = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingCatalogItem.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingCatalogItem_Visible_Group_Grant.json");
        VisibleTemplate vtGroup = ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr());
        vtGroup.setIncompatiblePromotions(
                "{\"IncompatibleList\": [{\"ClassCode\":\"REF-35\", \"Condition\": {\"On\":\"CurrentPromoAmount\", \"Operator\":\"GE\", \"Amount\":\"15\" }}]}");
        doReturn(ciGroupGrant).when(instance).queryPricingCatalogItem(
                any(), any(), eq(CI_EXTERNAL_IDS.PARTY_PAY_GRANT));

        subscription.getBalanceArrayAppender().clear();
        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        MtxBalanceInfo mbiRef35 = CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                CI_EXTERNAL_IDS.REF35_GRANT, BigDecimal.valueOf(20));
        subscription.getBalanceArrayAppender().add(mbiRef35);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn(responseMulti).when(instance).querySubscriptionGroups(any(), any(), any());
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(new BigDecimal("-15")).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        // Assertions If group credit is 15 and referral is zero then incompatibility was parsed
        // correctly
        assertEquals(
                15,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGroup.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
        assertEquals(
                0,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtReferral.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getAOP_When_GrantBalanceAttribute_MultipleIncompatibilitiesPresent_Then_IncompatibilitiesParsed()
            throws Exception {
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");
        AppPropertyProvider.getInstance().setProperty(
                CREDIT_CONSTANTS.AOC_GRANT_OFFERS, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);
        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.GOODWILL_REDEEM));

        MtxResponsePricingCatalogItem ciGoodwillGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.GRANT_GOODWILL);
        MtxResponsePricingCatalogItem ciReferralGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.REF35_GRANT);
        VisibleTemplate vtReferral = (VisibleTemplate) ciReferralGrant.getCatalogItemInfo().getTemplateAttr();
        vtReferral.setIncompatiblePromotions("");

        MtxResponsePricingCatalogItem ciGroupGrant = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingCatalogItem.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingCatalogItem_Visible_Group_Grant.json");
        MtxResponseMulti responseMulti = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class, DATA_DIR.PAYMENT_ADVICE
                        + "MtxResponseMulti_ForSubscriberGroupPartPay_Visible_Group_Grant.json");
        VisibleTemplate vt = ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr());
        vt.setIncompatiblePromotions(
                "{\"IncompatibleList\": [{ \"ClassCode\":\"REF-35\"}, { \"ClassCode\":\"GOOD-CR\"}]}");
        doReturn(ciGroupGrant).when(instance).queryPricingCatalogItem(
                any(), any(), eq("Visible_Group_Grant"));
        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscription.getBalanceArrayAppender().clear();
        MtxBalanceInfo mbiRef35 = CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                CI_EXTERNAL_IDS.REF35_GRANT, BigDecimal.valueOf(20));
        subscription.getBalanceArrayAppender().add(mbiRef35);
        MtxBalanceInfo mbiGoodwill = CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                CI_EXTERNAL_IDS.GRANT_GOODWILL, BigDecimal.valueOf(20));
        subscription.getBalanceArrayAppender().add(mbiGoodwill);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn(responseMulti).when(instance).querySubscriptionGroups(any(), any(), any());
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(new BigDecimal("-15")).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        VisibleTemplate vtGoodwill = (VisibleTemplate) ciGoodwillGrant.getCatalogItemInfo().getTemplateAttr();
        VisibleTemplate vtGroup = (VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr();
        // Assertions If group credit is 15 and referral is zero then incompatibility was parsed
        // correctly
        assertEquals(
                15,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGroup.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
        assertEquals(
                0,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGoodwill.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
        assertEquals(
                0,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtReferral.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_getAOP_PurchasedGrantOffer_When_Incompatibility_GE_On_CurrPromoAmount_Then_GrantIgnored")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber is enrolled in Visible_Unlimited. Has First25 grant that is based of purchased grant offer. Has no consumables.|"
                +"|      |Subscriber has another credit that has incompatibility with First25 credit."
                +"|      |Incompatiblity condition is on current promo amount GreaterThan or Equal To|"
                +"|When  |Api is called.|"
                +"|Then  |First25 is not redeemables but it will be reported.|"})
    // @formatter:on
    public void test_getAOP_PurchasedGrantOffer_When_Incompatibility_GE_On_CurrPromoAmount_Then_GrantIgnored(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        AppPropertyProvider.getInstance().setProperty(
                CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "Visible_Group_Grant");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED));

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        MtxResponseMulti responseMulti = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class, DATA_DIR.PAYMENT_ADVICE
                        + "MtxResponseMulti_ForSubscriberGroupPartPay_Visible_Group_Grant.json");
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());

        BigDecimal f25Grant = BigDecimal.TEN;

        MtxPurchasedOfferInfo poF25 = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, f25Grant, null);
        poF25.setEndTime(TestUtils.getLastDateTimeOfNextMonth());
        subscription.getPurchasedOfferArrayAppender().add(poF25);

        MtxResponsePricingCatalogItem ciGroupGrant = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingCatalogItem.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingCatalogItem_Visible_Group_Grant.json");
        VisibleTemplate vt = ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr());
        vt.setIncompatiblePromotions(
                "{\"IncompatibleList\": [{\"ClassCode\":\"FIRST25\", \"Condition\": {\"On\":\"CurrentPromoAmount\", \"Operator\":\"GE\", \"Amount\":\"15\" }}]}");
        doReturn(ciGroupGrant).when(instance).queryPricingCatalogItem(
                any(), any(), eq("Visible_Group_Grant"));
        doReturn(responseMulti).when(instance).querySubscriptionGroups(any(), any(), any());

        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        BigDecimal groupGrant = new BigDecimal("-15");
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(groupGrant).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        // Assertions If group credit is 15 and referral is zero then incompatibility was parsed
        // correctly
        assertEquals(
                0,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
        assertEquals(
                10,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getAvailableCreditsGrant().intValue());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_getAOP_PurchasedGrantOffer_When_Incompatibility_GT_On_CurrPromoAmount_Then_GrantIgnored")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber is enrolled in Visible_Unlimited. Has First25 grant that is based of purchased grant offer. Has no consumables.|"
                +"|      |Subscriber has another credit that has incompatibility with First25 credit."
                +"|      |Incompatiblity condition is on current promo amount GreaterThan|"
                +"|When  |Api is called.|"
                +"|Then  |First25 is not redeemables but it will be reported.|"})
    // @formatter:on
    public void test_getAOP_PurchasedGrantOffer_When_Incompatibility_GT_On_CurrPromoAmount_Then_GrantIgnored(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        AppPropertyProvider.getInstance().setProperty(
                CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "Visible_Group_Grant");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED));

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        MtxResponseMulti responseMulti = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class, DATA_DIR.PAYMENT_ADVICE
                        + "MtxResponseMulti_ForSubscriberGroupPartPay_Visible_Group_Grant.json");
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());

        BigDecimal f25Grant = BigDecimal.TEN;

        MtxPurchasedOfferInfo poF25 = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, f25Grant, null);
        poF25.setEndTime(TestUtils.getLastDateTimeOfNextMonth());
        subscription.getPurchasedOfferArrayAppender().add(poF25);

        MtxResponsePricingCatalogItem ciGroupGrant = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingCatalogItem.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingCatalogItem_Visible_Group_Grant.json");
        VisibleTemplate vt = ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr());
        vt.setIncompatiblePromotions(
                "{\"IncompatibleList\": [{\"ClassCode\":\"FIRST25\", \"Condition\": {\"On\":\"CurrentPromoAmount\", \"Operator\":\"GT\", \"Amount\":\"15\" }}]}");
        doReturn(ciGroupGrant).when(instance).queryPricingCatalogItem(
                any(), any(), eq("Visible_Group_Grant"));
        doReturn(responseMulti).when(instance).querySubscriptionGroups(any(), any(), any());

        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        BigDecimal groupGrant = new BigDecimal("-16");
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(groupGrant).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        // Assertions If group credit is 15 and referral is zero then incompatibility was parsed
        // correctly
        assertEquals(
                0,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
        assertEquals(
                10,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getAvailableCreditsGrant().intValue());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_getAOP_PurchasedGrantOffer_When_Incompatibility_LT_On_CurrPromoAmount_Then_GrantIgnored")

    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber is enrolled in Visible_Unlimited. Has First25 grant that is based of purchased grant offer. Has no consumables.|"
                +"|      |Subscriber has another credit that has incompatibility with First25 credit."
                +"|      |Incompatiblity condition is on current promo amount Less Than|"
                +"|When  |Api is called.|"
                +"|Then  |First25 is not redeemables but it will be reported.|"})
    // @formatter:on
    public void test_getAOP_PurchasedGrantOffer_When_Incompatibility_LT_On_CurrPromoAmount_Then_GrantIgnored(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        AppPropertyProvider.getInstance().setProperty(
                CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "Visible_Group_Grant");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED));

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        MtxResponseMulti responseMulti = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class, DATA_DIR.PAYMENT_ADVICE
                        + "MtxResponseMulti_ForSubscriberGroupPartPay_Visible_Group_Grant.json");
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());

        BigDecimal f25Grant = BigDecimal.TEN;

        MtxPurchasedOfferInfo poF25 = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, f25Grant, null);
        poF25.setEndTime(TestUtils.getLastDateTimeOfNextMonth());
        subscription.getPurchasedOfferArrayAppender().add(poF25);

        MtxResponsePricingCatalogItem ciGroupGrant = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingCatalogItem.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingCatalogItem_Visible_Group_Grant.json");
        VisibleTemplate vt = ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr());
        vt.setIncompatiblePromotions(
                "{\"IncompatibleList\": [{\"ClassCode\":\"FIRST25\", \"Condition\": {\"On\":\"CurrentPromoAmount\", \"Operator\":\"LT\", \"Amount\":\"15\" }}]}");
        doReturn(ciGroupGrant).when(instance).queryPricingCatalogItem(
                any(), any(), eq("Visible_Group_Grant"));
        doReturn(responseMulti).when(instance).querySubscriptionGroups(any(), any(), any());

        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        BigDecimal groupGrant = new BigDecimal("-14");
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(groupGrant).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        // Assertions If group credit is 15 and referral is zero then incompatibility was parsed
        // correctly
        assertEquals(
                0,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
        assertEquals(
                10,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getAvailableCreditsGrant().intValue());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_getAOP_PurchasedGrantOffer_When_Incompatibility_LE_On_CurrPromoAmount_Then_GrantIgnored")

    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber is enrolled in Visible_Unlimited. Has First25 grant that is based of purchased grant offer. Has no consumables.|"
                +"|      |Subscriber has another credit that has incompatibility with First25 credit."
                +"|      |Incompatiblity condition is on current promo amount Less Than or Equal To|"
                +"|When  |Api is called.|"
                +"|Then  |First25 is not redeemables but it will be reported.|"})
    // @formatter:on
    public void test_getAOP_PurchasedGrantOffer_When_Incompatibility_LE_On_CurrPromoAmount_Then_GrantIgnored(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        AppPropertyProvider.getInstance().setProperty(
                CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "Visible_Group_Grant");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED));

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        MtxResponseMulti responseMulti = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class, DATA_DIR.PAYMENT_ADVICE
                        + "MtxResponseMulti_ForSubscriberGroupPartPay_Visible_Group_Grant.json");
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());

        BigDecimal f25Grant = BigDecimal.TEN;

        MtxPurchasedOfferInfo poF25 = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, f25Grant, null);
        poF25.setEndTime(TestUtils.getLastDateTimeOfNextMonth());
        subscription.getPurchasedOfferArrayAppender().add(poF25);

        MtxResponsePricingCatalogItem ciGroupGrant = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingCatalogItem.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingCatalogItem_Visible_Group_Grant.json");
        VisibleTemplate vt = ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr());
        vt.setIncompatiblePromotions(
                "{\"IncompatibleList\": [{\"ClassCode\":\"FIRST25\", \"Condition\": {\"On\":\"CurrentPromoAmount\", \"Operator\":\"LE\", \"Amount\":\"15\" }}]}");
        doReturn(ciGroupGrant).when(instance).queryPricingCatalogItem(
                any(), any(), eq("Visible_Group_Grant"));
        doReturn(responseMulti).when(instance).querySubscriptionGroups(any(), any(), any());

        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        BigDecimal groupGrant = new BigDecimal("-14");
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(groupGrant).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        // Assertions If group credit is 15 and referral is zero then incompatibility was parsed
        // correctly
        assertEquals(
                0,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
        assertEquals(
                10,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getAvailableCreditsGrant().intValue());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_getAOP_PurchasedGrantOffer_When_Incompatibility_EQ_On_CurrPromoAmount_Then_GrantIgnored")

    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber is enrolled in Visible_Unlimited. Has First25 grant that is based of purchased grant offer. Has no consumables.|"
                +"|      |Subscriber has another credit that has incompatibility with First25 credit."
                +"|      |Incompatiblity condition is on current promo amount Equal To|"
                +"|When  |Api is called.|"
                +"|Then  |First25 is not redeemables but it will be reported.|"})
    // @formatter:on
    public void test_getAOP_PurchasedGrantOffer_When_Incompatibility_EQ_On_CurrPromoAmount_Then_GrantIgnored(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        AppPropertyProvider.getInstance().setProperty(
                CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "Visible_Group_Grant");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED));

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        MtxResponseMulti responseMulti = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class, DATA_DIR.PAYMENT_ADVICE
                        + "MtxResponseMulti_ForSubscriberGroupPartPay_Visible_Group_Grant.json");
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());

        BigDecimal f25Grant = BigDecimal.valueOf(15);

        MtxPurchasedOfferInfo poF25 = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, f25Grant, null);
        poF25.setEndTime(TestUtils.getLastDateTimeOfNextMonth());
        subscription.getPurchasedOfferArrayAppender().add(poF25);

        MtxResponsePricingCatalogItem ciGroupGrant = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingCatalogItem.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingCatalogItem_Visible_Group_Grant.json");
        VisibleTemplate vt = ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr());
        vt.setIncompatiblePromotions(
                "{\"IncompatibleList\": [{\"ClassCode\":\"FIRST25\", \"Condition\": {\"On\":\"CurrentPromoAmount\", \"Operator\":\"EQ\", \"Amount\":\"15\" }}]}");
        doReturn(ciGroupGrant).when(instance).queryPricingCatalogItem(
                any(), any(), eq("Visible_Group_Grant"));
        doReturn(responseMulti).when(instance).querySubscriptionGroups(any(), any(), any());

        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        BigDecimal groupGrant = new BigDecimal("-15");
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(groupGrant).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        // Assertions If group credit is 15 and referral is zero then incompatibility was parsed
        // correctly
        assertEquals(
                0,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
        assertEquals(
                f25Grant.intValue(),
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getAvailableCreditsGrant().intValue());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_getAOP_PurchasedGrantOffer_When_Incompatibility_EQ_On_IncPromoAmount_Then_GrantIgnored")

    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber is enrolled in Visible_Unlimited. Has First25 grant that is based of purchased grant offer. Has no consumables.|"
                +"|      |Subscriber has another credit that has incompatibility with First25 credit."
                +"|      |Incompatiblity condition is on incomatible promo amount Equal To|"
                +"|When  |Api is called.|"
                +"|Then  |First25 is not redeemables but it will be reported.|"})
    // @formatter:on
    public void test_getAOP_PurchasedGrantOffer_When_Incompatibility_EQ_On_IncPromoAmount_Then_GrantIgnored(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        AppPropertyProvider.getInstance().setProperty(
                CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "Visible_Group_Grant");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED));

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        MtxResponseMulti responseMulti = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class, DATA_DIR.PAYMENT_ADVICE
                        + "MtxResponseMulti_ForSubscriberGroupPartPay_Visible_Group_Grant.json");
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());

        BigDecimal f25Grant = BigDecimal.valueOf(15);

        MtxPurchasedOfferInfo poF25 = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, f25Grant, null);
        poF25.setEndTime(TestUtils.getLastDateTimeOfNextMonth());
        subscription.getPurchasedOfferArrayAppender().add(poF25);

        MtxResponsePricingCatalogItem ciGroupGrant = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingCatalogItem.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingCatalogItem_Visible_Group_Grant.json");
        VisibleTemplate vt = ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr());
        vt.setIncompatiblePromotions(
                "{\"IncompatibleList\": [{\"ClassCode\":\"FIRST25\", \"Condition\": {\"On\":\"IncompatiblePromoAmount\", \"Operator\":\"EQ\", \"Amount\":\"15\" }}]}");
        doReturn(ciGroupGrant).when(instance).queryPricingCatalogItem(
                any(), any(), eq("Visible_Group_Grant"));
        doReturn(responseMulti).when(instance).querySubscriptionGroups(any(), any(), any());

        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        BigDecimal groupGrant = new BigDecimal("-15");
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(groupGrant).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        // Assertions If group credit is 15 and referral is zero then incompatibility was parsed
        // correctly
        assertEquals(
                0,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
        assertEquals(
                f25Grant.intValue(),
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getAvailableCreditsGrant().intValue());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_getAOP_PurchasedGrantOffer_When_Incompatibility_LE_On_IncPromoAmount_Then_GrantIgnored")

    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber is enrolled in Visible_Unlimited. Has First25 grant that is based of purchased grant offer. Has no consumables.|"
                +"|      |Subscriber has another credit that has incompatibility with First25 credit."
                +"|      |Incompatiblity condition is on incomatible promo amount Less Than Or Equal To|"
                +"|When  |Api is called.|"
                +"|Then  |First25 is not redeemables but it will be reported.|"})
    // @formatter:on
    public void test_getAOP_PurchasedGrantOffer_When_Incompatibility_LE_On_IncPromoAmount_Then_GrantIgnored(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        AppPropertyProvider.getInstance().setProperty(
                CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "Visible_Group_Grant");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED));

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        MtxResponseMulti responseMulti = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class, DATA_DIR.PAYMENT_ADVICE
                        + "MtxResponseMulti_ForSubscriberGroupPartPay_Visible_Group_Grant.json");
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());

        BigDecimal f25Grant = BigDecimal.valueOf(15);

        MtxPurchasedOfferInfo poF25 = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, f25Grant, null);
        poF25.setEndTime(TestUtils.getLastDateTimeOfNextMonth());
        subscription.getPurchasedOfferArrayAppender().add(poF25);

        MtxResponsePricingCatalogItem ciGroupGrant = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingCatalogItem.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingCatalogItem_Visible_Group_Grant.json");
        VisibleTemplate vt = ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr());
        vt.setIncompatiblePromotions(
                "{\"IncompatibleList\": [{\"ClassCode\":\"FIRST25\", \"Condition\": {\"On\":\"IncompatiblePromoAmount\", \"Operator\":\"LE\", \"Amount\":\"15\" }}]}");
        doReturn(ciGroupGrant).when(instance).queryPricingCatalogItem(
                any(), any(), eq("Visible_Group_Grant"));
        doReturn(responseMulti).when(instance).querySubscriptionGroups(any(), any(), any());

        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        BigDecimal groupGrant = new BigDecimal("-15");
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(groupGrant).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        // Assertions If group credit is 15 and referral is zero then incompatibility was parsed
        // correctly
        assertEquals(
                0,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
        assertEquals(
                f25Grant.intValue(),
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getAvailableCreditsGrant().intValue());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_getAOP_PurchasedGrantOffer_When_Incompatibility_GE_On_IncPromoAmount_Then_GrantIgnored")

    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber is enrolled in Visible_Unlimited. Has First25 grant that is based of purchased grant offer. Has no consumables.|"
                +"|      |Subscriber has another credit that has incompatibility with First25 credit."
                +"|      |Incompatiblity condition is on incomatible promo amount Greater Than Or Equal To|"
                +"|When  |Api is called.|"
                +"|Then  |First25 is not redeemables but it will be reported.|"})
    // @formatter:on
    public void test_getAOP_PurchasedGrantOffer_When_Incompatibility_GE_On_IncPromoAmount_Then_GrantIgnored(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        AppPropertyProvider.getInstance().setProperty(
                CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "Visible_Group_Grant");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED));

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        MtxResponseMulti responseMulti = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class, DATA_DIR.PAYMENT_ADVICE
                        + "MtxResponseMulti_ForSubscriberGroupPartPay_Visible_Group_Grant.json");
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());

        BigDecimal f25Grant = BigDecimal.valueOf(15);

        MtxPurchasedOfferInfo poF25 = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, f25Grant, null);
        poF25.setEndTime(TestUtils.getLastDateTimeOfNextMonth());
        subscription.getPurchasedOfferArrayAppender().add(poF25);

        MtxResponsePricingCatalogItem ciGroupGrant = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingCatalogItem.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingCatalogItem_Visible_Group_Grant.json");
        VisibleTemplate vt = ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr());
        vt.setIncompatiblePromotions(
                "{\"IncompatibleList\": [{\"ClassCode\":\"FIRST25\", \"Condition\": {\"On\":\"IncompatiblePromoAmount\", \"Operator\":\"GE\", \"Amount\":\"15\" }}]}");
        doReturn(ciGroupGrant).when(instance).queryPricingCatalogItem(
                any(), any(), eq("Visible_Group_Grant"));
        doReturn(responseMulti).when(instance).querySubscriptionGroups(any(), any(), any());

        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        BigDecimal groupGrant = new BigDecimal("-15");
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());

        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(groupGrant).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        // Assertions If group credit is 15 and referral is zero then incompatibility was parsed
        // correctly
        assertEquals(
                0,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
        assertEquals(
                f25Grant.intValue(),
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getAvailableCreditsGrant().intValue());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_getAOP_PurchasedGrantOffer_When_Incompatibility_GT_On_IncPromoAmount_Then_GrantIgnored")

    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber is enrolled in Visible_Unlimited. Has First25 grant that is based of purchased grant offer. Has no consumables.|"
                +"|      |Subscriber has another credit that has incompatibility with First25 credit."
                +"|      |Incompatiblity condition is on incomatible promo amount Greater Than|"
                +"|When  |Api is called.|"
                +"|Then  |First25 is not redeemables but it will be reported.|"})
    // @formatter:on
    public void test_getAOP_PurchasedGrantOffer_When_Incompatibility_GT_On_IncPromoAmount_Then_GrantIgnored(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        AppPropertyProvider.getInstance().setProperty(
                CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "Visible_Group_Grant");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED));

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        MtxResponseMulti responseMulti = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class, DATA_DIR.PAYMENT_ADVICE
                        + "MtxResponseMulti_ForSubscriberGroupPartPay_Visible_Group_Grant.json");
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());

        BigDecimal f25Grant = BigDecimal.valueOf(16);

        MtxPurchasedOfferInfo poF25 = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, f25Grant, null);
        poF25.setEndTime(TestUtils.getLastDateTimeOfNextMonth());
        subscription.getPurchasedOfferArrayAppender().add(poF25);

        MtxResponsePricingCatalogItem ciGroupGrant = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingCatalogItem.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingCatalogItem_Visible_Group_Grant.json");
        VisibleTemplate vt = ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr());
        vt.setIncompatiblePromotions(
                "{\"IncompatibleList\": [{\"ClassCode\":\"FIRST25\", \"Condition\": {\"On\":\"IncompatiblePromoAmount\", \"Operator\":\"GT\", \"Amount\":\"10\" }}]}");
        doReturn(ciGroupGrant).when(instance).queryPricingCatalogItem(
                any(), any(), eq("Visible_Group_Grant"));
        doReturn(responseMulti).when(instance).querySubscriptionGroups(any(), any(), any());

        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        BigDecimal groupGrant = new BigDecimal("-15");
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(groupGrant).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        // Assertions If group credit is 15 and referral is zero then incompatibility was parsed
        // correctly
        assertEquals(
                0,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
        assertEquals(
                f25Grant.intValue(),
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getAvailableCreditsGrant().intValue());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "test_getAOP_PurchasedGrantOffer_When_Incompatibility_LT_On_IncPromoAmount_Then_GrantIgnored")

    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber is enrolled in Visible_Unlimited. Has First25 grant that is based of purchased grant offer. Has no consumables.|"
                +"|      |Subscriber has another credit that has incompatibility with First25 credit."
                +"|      |Incompatiblity condition is on incomatible promo amount Less Than|"
                +"|When  |Api is called.|"
                +"|Then  |First25 is not redeemables but it will be reported.|"})
    // @formatter:on
    public void test_getAOP_PurchasedGrantOffer_When_Incompatibility_LT_On_IncPromoAmount_Then_GrantIgnored(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        AppPropertyProvider.getInstance().setProperty(
                CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "Visible_Group_Grant");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED));

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        MtxResponseMulti responseMulti = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class, DATA_DIR.PAYMENT_ADVICE
                        + "MtxResponseMulti_ForSubscriberGroupPartPay_Visible_Group_Grant.json");
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());

        BigDecimal f25Grant = BigDecimal.valueOf(14);

        MtxPurchasedOfferInfo poF25 = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, f25Grant, null);
        poF25.setEndTime(TestUtils.getLastDateTimeOfNextMonth());
        subscription.getPurchasedOfferArrayAppender().add(poF25);

        MtxResponsePricingCatalogItem ciGroupGrant = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingCatalogItem.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingCatalogItem_Visible_Group_Grant.json");
        VisibleTemplate vt = ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr());
        vt.setIncompatiblePromotions(
                "{\"IncompatibleList\": [{\"ClassCode\":\"FIRST25\", \"Condition\": {\"On\":\"IncompatiblePromoAmount\", \"Operator\":\"LT\", \"Amount\":\"15\" }}]}");
        doReturn(ciGroupGrant).when(instance).queryPricingCatalogItem(
                any(), any(), eq("Visible_Group_Grant"));
        doReturn(responseMulti).when(instance).querySubscriptionGroups(any(), any(), any());

        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        BigDecimal groupGrant = new BigDecimal("-15");
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(groupGrant).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        // Assertions If group credit is 15 and referral is zero then incompatibility was parsed
        // correctly
        assertEquals(
                0,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
        assertEquals(
                f25Grant.intValue(),
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getAvailableCreditsGrant().intValue());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getAOP_PurchasedGrantOffer_When_ClassCodeIncompatibilityPresent_Then_GrantIgnored()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in Visible_Unlimited. Has First25 grant that is based of purchased grant offer. Has no consumables.",
            "Subscriber has another credit that has incompatibility with First25 credit."
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "First25 is not redeemables but it will be reported."
        };
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        AppPropertyProvider.getInstance().setProperty(
                CREDIT_CONSTANTS.AOC_GRANT_OFFERS, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(
                        CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.GRANT_GOODWILL,
                        CI_EXTERNAL_IDS.GOODWILL_REDEEM));

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());

        BigDecimal f25Grant = BigDecimal.TEN;
        MtxPurchasedOfferInfo poF25 = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, f25Grant, null);
        poF25.setEndTime(TestUtils.getLastDateTimeOfNextMonth());
        subscription.getPurchasedOfferArrayAppender().add(poF25);
        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        MtxResponsePricingCatalogItem ciGroupGrant = CommonTestHelper.loadJsonMessage(
                MtxResponsePricingCatalogItem.class,
                DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingCatalogItem_Visible_Group_Grant.json");
        MtxResponseMulti responseMulti = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class, DATA_DIR.PAYMENT_ADVICE
                        + "MtxResponseMulti_ForSubscriberGroupPartPay_Visible_Group_Grant.json");
        VisibleTemplate vt = ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr());
        vt.setIncompatiblePromotions("{\"IncompatibleList\": [{ \"ClassCode\":\"FIRST25\"}]}");
        doReturn(ciGroupGrant).when(instance).queryPricingCatalogItem(
                any(), any(), eq("Visible_Group_Grant"));

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        BigDecimal groupGrant = new BigDecimal("-15");
        // mocks
        doReturn(responseMulti).when(instance).querySubscriptionGroups(any(), any(), any());
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        doReturn(groupGrant).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        // Assertions If group credit is 15 and referral is zero then incompatibility was parsed
        // correctly
        assertEquals(
                0,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
        assertEquals(
                10,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getAvailableCreditsGrant().intValue());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "When_IncompatibilityWithConditionPresent_ConsumablesPresent_Then_RedeemConsumables")
    @Tag("VER-633")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber is enrolled in Visible_Unlimited. Has group credit grant. Has some consumables.|"
                +"|      |Subscriber has another credit that has incompatibility with group credit.|"
                +"|When  |AOP is called.|"
                +"|Then  |Redeemables equals to consumables if not more than Discount Proce.|"
                +"|      |No Transferables.|"})
    // @formatter:on
    public void test_getAOP_AOC_When_IncompatibilityWithConditionPresent_ConsumablesPresent_Then_RedeemConsumables(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        AppPropertyProvider.getInstance().setProperty(
                CREDIT_CONSTANTS.AOC_GRANT_OFFERS, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.GOODWILL_REDEEM));

        MtxResponsePricingCatalogItem ciGroupGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);
        VisibleTemplate vtGroup = ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr());
        MtxResponseMulti responseMulti = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class, DATA_DIR.PAYMENT_ADVICE
                        + "MtxResponseMulti_ForSubscriberGroupPartPay_Visible_Group_Grant.json");

        MtxResponsePricingCatalogItem ciGoodwillGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.GRANT_GOODWILL);
        VisibleTemplate vtGoodwill = ((VisibleTemplate) ciGoodwillGrant.getCatalogItemInfo().getTemplateAttr());
        vtGoodwill.setIncompatiblePromotions(
                "{\"IncompatibleList\": [{ \"ClassCode\":\"GRPD-CR\"}]}");
        doReturn(responseMulti).when(instance).querySubscriptionGroups(any(), any(), any());

        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscription.getBalanceArrayAppender().clear();
        MtxBalanceInfo mbiPartyPay = CommonTestHelper.getMtxBalanceInfoForPromoConsumable(
                CI_EXTERNAL_IDS.PARTY_PAY_GRANT, BigDecimal.TEN);
        subscription.getBalanceArrayAppender().add(mbiPartyPay);
        MtxBalanceInfo mbiGoodGrant = CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                CI_EXTERNAL_IDS.GRANT_GOODWILL, BigDecimal.TEN);
        subscription.getBalanceArrayAppender().add(mbiGoodGrant);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(BigDecimal.TEN.negate()).when(instance).getChargeableAmountForPurchaseOffer(
                any(), eq(vtGroup.getRedeemOffer()), any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        // Assertions If group credit is 15 and referral is zero then incompatibility was parsed
        // correctly
        assertEquals(
                10,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGroup.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
        assertEquals(
                0,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGroup.getPromotionName())).findFirst().get().getEstimatedTransferableCredits().intValue());
        assertEquals(
                10,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGroup.getPromotionName())).findFirst().get().getAvailableCreditsGrant().intValue());
        assertEquals(
                10,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGroup.getPromotionName())).findFirst().get().getAvailableCreditsConsumable().intValue());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getAOP_AOC_When_IncompatibilityWithIncompatiblePromoAmount_ConsumablesPresent_Then_RedeemConsumables()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in Visible_Unlimited. Has group credit grant. Has some consumables.",
            "Subscriber has another credit that has incompatibility with group credit based on amount.",
            "Incompatibility is based on amount of incompatible promo. In this case group credit."
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "Redeemables equals to consumables if not more than Discount Price.",
            "No Transferables."
        };
        td.printDescription();
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        AppPropertyProvider.getInstance().setProperty(
                CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "Visible_Group_Grant");
        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED));

        MtxResponsePricingCatalogItem ciGroupGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);
        MtxResponseMulti responseMulti = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class, DATA_DIR.PAYMENT_ADVICE
                        + "MtxResponseMulti_ForSubscriberGroupPartPay_Visible_Group_Grant.json");
        VisibleTemplate vtGroup = ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr());

        String incompatibleAmount = "14";
        MtxResponsePricingCatalogItem ciGoodwillGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.GRANT_GOODWILL);
        VisibleTemplate vtGoodwill = ((VisibleTemplate) ciGoodwillGrant.getCatalogItemInfo().getTemplateAttr());
        vtGoodwill.setIncompatiblePromotions(
                "{\"IncompatibleList\": [{\"ClassCode\":\"GRPD-CR\", \"Condition\": {\"On\":\"IncompatiblePromoAmount\", \"Operator\":\"GE\", \"Amount\":"
                        + incompatibleAmount + " } }]}");

        MtxBalanceInfo mbiGoodGrant = CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                CI_EXTERNAL_IDS.GRANT_GOODWILL, BigDecimal.TEN);
        subscription.getBalanceArrayAppender().add(mbiGoodGrant);
        MtxBalanceInfo mbiPartyConsump = CommonTestHelper.getMtxBalanceInfoForPromoConsumable(
                CI_EXTERNAL_IDS.PARTY_PAY_GRANT, BigDecimal.TEN);
        subscription.getBalanceArrayAppender().add(mbiPartyConsump);
        doReturn(responseMulti).when(instance).querySubscriptionGroups(any(), any(), any());

        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        BigDecimal groupGrantBalance = new BigDecimal(incompatibleAmount).negate();

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(groupGrantBalance).when(instance).getChargeableAmountForPurchaseOffer(
                any(), eq(vtGroup.getRedeemOffer()), any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        // Assertions If group credit is 15 and referral is zero then incompatibility was parsed
        // correctly
        assertEquals(
                10,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGroup.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
        assertEquals(
                0,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGroup.getPromotionName())).findFirst().get().getEstimatedTransferableCredits().intValue());
        assertEquals(
                14,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGroup.getPromotionName())).findFirst().get().getAvailableCreditsGrant().intValue());
        assertEquals(
                10,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGroup.getPromotionName())).findFirst().get().getAvailableCreditsConsumable().intValue());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getAOP_AOC_When_ClassCodeIncompatibilityPresent_ConsumablesPresent_Then_RedeemConsumables()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in Visible_Unlimited. Has group credit grant. Has some consumables.",
            "Subscriber has another credit that has incompatibility with group credit."
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "Redeemables equals to consumables if not more than Discount Price.",
            "No Transferables."
        };
        td.printDescription();
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        AppPropertyProvider.getInstance().setProperty(
                CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "Visible_Group_Grant");
        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED));

        MtxResponsePricingCatalogItem ciGroupGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);
        MtxResponseMulti responseMulti = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class, DATA_DIR.PAYMENT_ADVICE
                        + "MtxResponseMulti_ForSubscriberGroupPartPay_Visible_Group_Grant.json");
        VisibleTemplate vtGroup = ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr());

        doReturn(responseMulti).when(instance).querySubscriptionGroups(any(), any(), any());

        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        MtxResponsePricingCatalogItem ciGoodwillGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.GRANT_GOODWILL);
        VisibleTemplate vtGoodwill = ((VisibleTemplate) ciGoodwillGrant.getCatalogItemInfo().getTemplateAttr());
        vtGoodwill.setIncompatiblePromotions(
                "{\"IncompatibleList\": [{ \"ClassCode\":\"GRPD-CR\"}]}");

        MtxBalanceInfo mbiPartyPay = CommonTestHelper.getMtxBalanceInfoForPromoConsumable(
                CI_EXTERNAL_IDS.PARTY_PAY_GRANT, BigDecimal.TEN);
        subscription.getBalanceArrayAppender().add(mbiPartyPay);

        MtxBalanceInfo mbiGoodGrant = CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                CI_EXTERNAL_IDS.GRANT_GOODWILL, BigDecimal.TEN);
        subscription.getBalanceArrayAppender().add(mbiGoodGrant);

        BigDecimal groupGrantBalance = new BigDecimal("14").negate();

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(groupGrantBalance).when(instance).getChargeableAmountForPurchaseOffer(
                any(), eq(vtGroup.getRedeemOffer()), any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        // Assertions If group credit is 15 and referral is zero then incompatibility was parsed
        // correctly
        assertEquals(
                10,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGroup.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
        assertEquals(
                0,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGroup.getPromotionName())).findFirst().get().getEstimatedTransferableCredits().intValue());
        assertEquals(
                14,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGroup.getPromotionName())).findFirst().get().getAvailableCreditsGrant().intValue());
        assertEquals(
                10,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGroup.getPromotionName())).findFirst().get().getAvailableCreditsConsumable().intValue());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getAOP_When_PromoNotUsableDueToIncompatibility_PromoHasGrantOnly_Then_PromoReportedWithNoRedeemables()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in Visible_Unlimited. Has some group grants. Has no group consumables.",
            "Subscriber has second grant that is incompatible with group credits"
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "Group credit is reported in payment advice output. But with ZERO redeemables and transferables."
        };
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        AppPropertyProvider.getInstance().setProperty(
                CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "Visible_Group_Grant");
        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED));

        MtxResponsePricingCatalogItem ciGroupGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);
        MtxResponseMulti responseMulti = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class, DATA_DIR.PAYMENT_ADVICE
                        + "MtxResponseMulti_ForSubscriberGroupPartPay_Visible_Group_Grant.json");
        VisibleTemplate vtGroup = ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr());

        MtxResponsePricingCatalogItem ciGoodwillGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.GRANT_GOODWILL);
        VisibleTemplate vtGoodwill = ((VisibleTemplate) ciGoodwillGrant.getCatalogItemInfo().getTemplateAttr());
        vtGoodwill.setIncompatiblePromotions(
                "{\"IncompatibleList\": [{ \"ClassCode\":\"GRPD-CR\"}]}");

        MtxBalanceInfo mbiGoodGrant = CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                CI_EXTERNAL_IDS.GRANT_GOODWILL, BigDecimal.TEN);
        subscription.getBalanceArrayAppender().add(mbiGoodGrant);
        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        BigDecimal groupGrantBalance = new BigDecimal("14").negate();

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn(responseMulti).when(instance).querySubscriptionGroups(any(), any(), any());
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(groupGrantBalance).when(instance).getChargeableAmountForPurchaseOffer(
                any(), eq(vtGroup.getRedeemOffer()), any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());

        assertEquals(
                0,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGroup.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
        assertEquals(
                0,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGroup.getPromotionName())).findFirst().get().getEstimatedTransferableCredits().intValue());
        assertEquals(
                14,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGroup.getPromotionName())).findFirst().get().getAvailableCreditsGrant().intValue());
    }

    @Test
    public void test_getAOP_AOC_When_IncludeCriteriaMet_Then_GrantIsRedeemable() throws Exception {
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        AppPropertyProvider.getInstance().setProperty(
                CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "Visible_Group_Grant");
        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(
                        CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.GOODWILL_REDEEM,
                        CI_EXTERNAL_IDS.GRANT_GOODWILL));

        MtxResponsePricingCatalogItem ciGroupGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);
        MtxResponseMulti responseMulti = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class, DATA_DIR.PAYMENT_ADVICE
                        + "MtxResponseMulti_ForSubscriberGroupPartPay_Visible_Group_Grant.json");
        VisibleTemplate vtGroup = ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr());
        // Clear so that this incompatibility is not applied. We need to test flag balance
        vtGroup.setIncompatiblePromotions("");
        vtGroup.setCreditIncludeFlagName(BALANCE_NAMES.LONGEVITY_COUNTER);
        vtGroup.setCreditIncludeFlagValues("1");
        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        BigDecimal grantBalance = new BigDecimal("-15");
        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn(responseMulti).when(instance).querySubscriptionGroups(any(), any(), any());
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(grantBalance).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        // Assertions If group credit is 15 and referral is zero then incompatibility was parsed
        // correctly
        assertEquals(
                15,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGroup.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getAOP_When_AOC_IncludeCriteriaNotMet_Then_GrantIsNotRedeemable()
            throws Exception {
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        AppPropertyProvider.getInstance().setProperty(
                CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "Visible_Group_Grant");
        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(
                        CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.GOODWILL_REDEEM,
                        CI_EXTERNAL_IDS.GRANT_GOODWILL));

        MtxResponsePricingCatalogItem ciGroupGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);
        MtxResponseMulti responseMulti = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class, DATA_DIR.PAYMENT_ADVICE
                        + "MtxResponseMulti_ForSubscriberGroupPartPay_Visible_Group_Grant.json");
        VisibleTemplate vtGroup = ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr());
        // Clear so that this incompatibility is not applied. We need to test flag balance
        vtGroup.setIncompatiblePromotions("");
        vtGroup.setCreditIncludeFlagName(BALANCE_NAMES.LONGEVITY_COUNTER);
        vtGroup.setCreditIncludeFlagValues("1");

        MtxBalanceInfo mbiLongevity = CommonTestHelper.getMtxBalanceInfo(
                DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Longevity_Counter.json");
        mbiLongevity.setAvailableAmount(BigDecimal.TEN);
        mbiLongevity.setAmount(BigDecimal.TEN.negate());
        subscription.getBalanceArrayAppender().add(mbiLongevity);
        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        BigDecimal grantBalance = new BigDecimal("-15");

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn(responseMulti).when(instance).querySubscriptionGroups(any(), any(), any());
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        doReturn(grantBalance).when(instance).getChargeableAmountForPurchaseOffer(
                any(), eq(vtGroup.getRedeemOffer()), any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        // Assertions If group credit is 15 and referral is zero then incompatibility was parsed
        // correctly
        assertEquals(
                0,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGroup.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
        assertEquals(
                15,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGroup.getPromotionName())).findFirst().get().getAvailableCreditsGrant().intValue());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getAOP_When_PromoNotUsableDueToFlagBalance_PromoHasConsumables_Then_PromoReportedWithNoTransferables()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in Visible_Unlimited. Has some group grants. Has some group consumables.",
            "Subscriber has flag balance that is incompatible with group credits",
            "This test works standalone. But fails if run with all other tests."
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "Group credit is reported in payment advice output. But with ZERO transferables."
        };
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        AppPropertyProvider.getInstance().setProperty(
                CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "Visible_Group_Grant");
        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED));

        MtxResponsePricingCatalogItem ciGroupGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);
        MtxResponseMulti responseMulti = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class, DATA_DIR.PAYMENT_ADVICE
                        + "MtxResponseMulti_ForSubscriberGroupPartPay_Visible_Group_Grant.json");
        VisibleTemplate vtGroup = ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr());
        // Clear so that this incompatibility is not applied. We need to test flag balance
        vtGroup.setIncompatiblePromotions("");
        vtGroup.setCreditIncludeFlagName(BALANCE_NAMES.LONGEVITY_COUNTER);
        vtGroup.setCreditIncludeFlagValues("1");

        MtxBalanceInfo mbiPartyPay = CommonTestHelper.getMtxBalanceInfoForPromoConsumable(
                CI_EXTERNAL_IDS.PARTY_PAY_GRANT, BigDecimal.TEN);
        subscription.getBalanceArrayAppender().add(mbiPartyPay);
        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        MtxBalanceInfo mbiLongevity = CommonTestHelper.getMtxBalanceInfo(
                DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Longevity_Counter.json");
        mbiLongevity.setAvailableAmount(BigDecimal.TEN);
        mbiLongevity.setAmount(BigDecimal.TEN.negate());
        subscription.getBalanceArrayAppender().add(mbiLongevity);

        BigDecimal grantBalance = new BigDecimal("-15");

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn(responseMulti).when(instance).querySubscriptionGroups(any(), any(), any());
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(grantBalance).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        // Assertions If group credit is 15 and referral is zero then incompatibility was parsed
        // correctly
        assertEquals(
                10,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGroup.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
        assertEquals(
                0,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGroup.getPromotionName())).findFirst().get().getEstimatedTransferableCredits().intValue());
        assertEquals(
                15,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGroup.getPromotionName())).findFirst().get().getAvailableCreditsGrant().intValue());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getAOP_When_GrantBalanceAttribute_IncludeCriteriaMet_Then_GrantIsRedeemable()
            throws Exception {
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.GOODWILL_REDEEM));

        MtxResponsePricingCatalogItem ciGroupGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);

        MtxResponsePricingCatalogItem ciGoodwillGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.GRANT_GOODWILL);

        MtxBalanceInfo mbiLongevity = CommonTestHelper.getMtxBalanceInfo(
                DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Longevity_Counter.json");
        mbiLongevity.setAvailableAmount(BigDecimal.ONE);
        mbiLongevity.setAmount(BigDecimal.ONE.negate());
        subscription.getBalanceArrayAppender().add(mbiLongevity);

        MtxBalanceInfo mbiGoodGrant = CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                CI_EXTERNAL_IDS.GRANT_GOODWILL, BigDecimal.valueOf(20));
        subscription.getBalanceArrayAppender().add(mbiGoodGrant);

        BigDecimal grantBalance = BigDecimal.ZERO;

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(grantBalance).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        // Assertions If group credit is 15 and referral is zero then incompatibility was parsed
        // correctly
        VisibleTemplate vtGoodwill = (VisibleTemplate) ciGoodwillGrant.getCatalogItemInfo().getTemplateAttr();
        assertEquals(
                20,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGoodwill.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getAOP_When_GrantBalanceAttribute_IncludeCriteriaNotMet_Then_GrantIsNotRedeemable()
            throws Exception {
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED));

        MtxResponsePricingCatalogItem ciGroupGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);

        MtxResponsePricingCatalogItem ciGoodwilGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.GRANT_GOODWILL);
        VisibleTemplate vtGoodwill = ((VisibleTemplate) ciGoodwilGrant.getCatalogItemInfo().getTemplateAttr());
        // Clear so that this incompatibility is not applied. We need to test flag balance
        vtGoodwill.setIncompatiblePromotions("");
        vtGoodwill.setCreditIncludeFlagName(BALANCE_NAMES.LONGEVITY_COUNTER);
        vtGoodwill.setCreditIncludeFlagValues("1");

        MtxBalanceInfo mbiLongevity = CommonTestHelper.getMtxBalanceInfo(
                DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Longevity_Counter.json");
        mbiLongevity.setAvailableAmount(BigDecimal.TEN);
        mbiLongevity.setAmount(BigDecimal.TEN.negate());
        subscription.getBalanceArrayAppender().add(mbiLongevity);

        MtxBalanceInfo mbiGoodGrant = CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                CI_EXTERNAL_IDS.GRANT_GOODWILL, BigDecimal.valueOf(20));
        subscription.getBalanceArrayAppender().add(mbiGoodGrant);

        BigDecimal grantBalance = BigDecimal.ZERO;

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(grantBalance).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());

        // Assertions If group credit is 15 and referral is zero then incompatibility was parsed
        // correctly
        assertEquals(
                0,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGoodwill.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
        assertEquals(
                20,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGoodwill.getPromotionName())).findFirst().get().getAvailableCreditsGrant().intValue());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getAOP_When_PurchasedGrantOffer_IncludeCriteriaMet_Then_GrantIsRedeemable()
            throws Exception {
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED));

        MtxResponsePricingCatalogItem ciGroupGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);

        MtxResponsePricingCatalogItem ciFirst25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        VisibleTemplate vtF25 = ((VisibleTemplate) ciFirst25Grant.getCatalogItemInfo().getTemplateAttr());
        // Clear so that this incompatibility is not applied. We need to test flag balance
        vtF25.setIncompatiblePromotions("");
        vtF25.setCreditIncludeFlagName(BALANCE_NAMES.LONGEVITY_COUNTER);
        vtF25.setCreditIncludeFlagValues("1");

        MtxBalanceInfo mbiLongevity = CommonTestHelper.getMtxBalanceInfo(
                DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Longevity_Counter.json");
        mbiLongevity.setAvailableAmount(BigDecimal.ONE);
        mbiLongevity.setAmount(BigDecimal.ONE.negate());
        subscription.getBalanceArrayAppender().add(mbiLongevity);

        BigDecimal f25Grant = BigDecimal.valueOf(15);
        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, f25Grant, null);

        BigDecimal groupGrantBalance = BigDecimal.ZERO;

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(groupGrantBalance).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        // Assertions If group credit is 15 and referral is zero then incompatibility was parsed
        // correctly
        assertEquals(
                15,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getAOP_When_PurchasedGrantOffer_IncludeCriteriaNotMet_Then_GrantIsNotRedeemable()
            throws Exception {
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED));

        MtxResponsePricingCatalogItem ciGroupGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);

        MtxResponsePricingCatalogItem ciFirst25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        VisibleTemplate vtF25 = ((VisibleTemplate) ciFirst25Grant.getCatalogItemInfo().getTemplateAttr());
        // Clear so that this incompatibility is not applied. We need to test flag balance
        vtF25.setIncompatiblePromotions("");
        vtF25.setCreditIncludeFlagName(BALANCE_NAMES.LONGEVITY_COUNTER);
        vtF25.setCreditIncludeFlagValues("1");

        BigDecimal f25Grant = BigDecimal.valueOf(15);
        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, f25Grant, null);

        MtxBalanceInfo mbiLongevity = CommonTestHelper.getMtxBalanceInfo(
                DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Longevity_Counter.json");
        mbiLongevity.setAvailableAmount(BigDecimal.TEN);
        mbiLongevity.setAmount(BigDecimal.TEN.negate());
        subscription.getBalanceArrayAppender().add(mbiLongevity);

        BigDecimal groupGrantBalance = BigDecimal.ZERO;

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(groupGrantBalance).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        // Assertions If group credit is 15 and referral is zero then incompatibility was parsed
        // correctly
        assertEquals(
                0,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
        assertEquals(
                15,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getAvailableCreditsGrant().intValue());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getAOP_When_AOC_IncludeCriteriaMet_But_IncompatibilityAlsoMet_Then_GrantIsNotRedeemable()
            throws Exception {
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        AppPropertyProvider.getInstance().setProperty(
                CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "Visible_Group_Grant");
        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.GOODWILL_REDEEM));

        MtxResponsePricingCatalogItem ciGroupGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);
        VisibleTemplate vtGroup = ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr());
        vtGroup.setCreditIncludeFlagName(BALANCE_NAMES.LONGEVITY_COUNTER);
        vtGroup.setCreditIncludeFlagValues("1");

        MtxResponsePricingCatalogItem ciGoodwillGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.GRANT_GOODWILL);
        MtxResponseMulti responseMulti = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class, DATA_DIR.PAYMENT_ADVICE
                        + "MtxResponseMulti_ForSubscriberGroupPartPay_Visible_Group_Grant.json");
        VisibleTemplate vtGoodwill = ((VisibleTemplate) ciGoodwillGrant.getCatalogItemInfo().getTemplateAttr());
        vtGoodwill.setIncompatiblePromotions(
                "{\"IncompatibleList\": [{ \"ClassCode\":\"GRPD-CR\"}]}");

        MtxBalanceInfo mbiLongevity = CommonTestHelper.getMtxBalanceInfo(
                DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Longevity_Counter.json");
        mbiLongevity.setAvailableAmount(BigDecimal.ONE);
        mbiLongevity.setAmount(BigDecimal.ONE.negate());
        subscription.getBalanceArrayAppender().add(mbiLongevity);
        doReturn(responseMulti).when(instance).querySubscriptionGroups(any(), any(), any());

        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        MtxBalanceInfo mbiGoodGrant = CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                CI_EXTERNAL_IDS.GRANT_GOODWILL, BigDecimal.TEN);
        subscription.getBalanceArrayAppender().add(mbiGoodGrant);

        BigDecimal grantBalance = new BigDecimal("-15");

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(grantBalance).when(instance).getChargeableAmountForPurchaseOffer(
                any(), eq(vtGroup.getRedeemOffer()), any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        // Assertions If group credit is 15 and referral is zero then incompatibility was parsed
        // correctly
        // assertEquals(0, output.getCredits().stream().filter(vc ->
        // vc.getPromotionName().equalsIgnoreCase(vtGroup.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
        assertEquals(
                15,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGroup.getPromotionName())).findFirst().get().getAvailableCreditsGrant().intValue());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getAOP_When_GrantBalanceAttribute_IncludeCriteriaMet_But_IncompatibilityAlsoMet_Then_GrantIsNotRedeemable()
            throws Exception {
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        AppPropertyProvider.getInstance().setProperty(
                CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "Visible_Group_Grant");
        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED));

        MtxResponsePricingCatalogItem ciGoodwilGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.GRANT_GOODWILL);
        VisibleTemplate vtGoodwill = ((VisibleTemplate) ciGoodwilGrant.getCatalogItemInfo().getTemplateAttr());
        // Clear so that this incompatibility is not applied. We need to test flag balance
        vtGoodwill.setCreditIncludeFlagName(BALANCE_NAMES.LONGEVITY_COUNTER);
        vtGoodwill.setCreditIncludeFlagValues("1");

        MtxResponsePricingCatalogItem ciGroupGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);
        MtxResponseMulti responseMulti = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class, DATA_DIR.PAYMENT_ADVICE
                        + "MtxResponseMulti_ForSubscriberGroupPartPay_Visible_Group_Grant.json");
        VisibleTemplate vtGroup = ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr());
        vtGroup.setIncompatiblePromotions("{\"IncompatibleList\": [{ \"ClassCode\":\"GOOD-CR\"}]}");

        MtxBalanceInfo mbiLongevity = CommonTestHelper.getMtxBalanceInfo(
                DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Longevity_Counter.json");
        mbiLongevity.setAvailableAmount(BigDecimal.ONE);
        mbiLongevity.setAmount(BigDecimal.ONE.negate());
        subscription.getBalanceArrayAppender().add(mbiLongevity);
        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        MtxBalanceInfo mbiGoodGrant = CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                CI_EXTERNAL_IDS.GRANT_GOODWILL, BigDecimal.valueOf(20));
        subscription.getBalanceArrayAppender().add(mbiGoodGrant);

        BigDecimal grantBalance = BigDecimal.TEN.negate();

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn(responseMulti).when(instance).querySubscriptionGroups(any(), any(), any());
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(grantBalance).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        // Assertions If group credit is 15 and referral is zero then incompatibility was parsed
        // correctly
        assertEquals(
                0,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGoodwill.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
        assertEquals(
                20,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGoodwill.getPromotionName())).findFirst().get().getAvailableCreditsGrant().intValue());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getAOP_When_PurchasedGrantOffer_IncludeCriteriaMet_But_IncompatibilityAlsoMet_Then_GrantIsNotRedeemable()
            throws Exception {
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        AppPropertyProvider.getInstance().setProperty(
                CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "Visible_Group_Grant");
        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(
                        CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.GRANT_GOODWILL,
                        CI_EXTERNAL_IDS.GOODWILL_REDEEM));

        MtxResponsePricingCatalogItem ciFirst25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        MtxResponseMulti responseMulti = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class, DATA_DIR.PAYMENT_ADVICE
                        + "MtxResponseMulti_ForSubscriberGroupPartPay_Visible_Group_Grant.json");
        VisibleTemplate vtRef25 = ((VisibleTemplate) ciFirst25Grant.getCatalogItemInfo().getTemplateAttr());
        // Clear so that this incompatibility is not applied. We need to test flag balance
        vtRef25.setIncompatiblePromotions("");
        vtRef25.setCreditIncludeFlagName(BALANCE_NAMES.LONGEVITY_COUNTER);
        vtRef25.setCreditIncludeFlagValues("1");

        MtxResponsePricingCatalogItem ciGroupGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);
        VisibleTemplate vtGroup = ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr());
        vtGroup.setIncompatiblePromotions("{\"IncompatibleList\": [{ \"ClassCode\":\"FIRST25\"}]}");

        MtxBalanceInfo mbiLongevity = CommonTestHelper.getMtxBalanceInfo(
                DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Longevity_Counter.json");
        mbiLongevity.setAvailableAmount(BigDecimal.ONE);
        mbiLongevity.setAmount(BigDecimal.ONE.negate());
        subscription.getBalanceArrayAppender().add(mbiLongevity);
        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        BigDecimal f25Grant = BigDecimal.TEN;

        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, f25Grant, null);

        BigDecimal groupGrantBalance = BigDecimal.TEN.negate();

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn(responseMulti).when(instance).querySubscriptionGroups(any(), any(), any());
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(groupGrantBalance).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        // Assertions If group credit is 15 and referral is zero then incompatibility was parsed
        // correctly
        assertEquals(
                0,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtRef25.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
        assertEquals(
                f25Grant.intValue(),
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtRef25.getPromotionName())).findFirst().get().getAvailableCreditsGrant().intValue());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getAOP_When_AocOfferInProperty_AocGrantPresent_Then_AocCreditReported()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in Visible_Unlimited. Has group credit grant. Has no consumables.",
            "CI Visible_Group_Grant is listed in rsgateway property credit.grant.calculation.method.aoc.catalog.items"
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "Group credit is reported in payment advice output."
        };
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED));

        MtxResponsePricingCatalogItem ciGroupGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);
        MtxResponseMulti responseMulti = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class, DATA_DIR.PAYMENT_ADVICE
                        + "MtxResponseMulti_ForSubscriberGroupPartPay_Visible_Group_Grant.json");
        VisibleTemplate vtGroup = ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr());
        // Clear so that this incompatibility is not applied. We need to test flag balance
        vtGroup.setIncompatiblePromotions("");
        vtGroup.setCreditIncludeFlagName(BALANCE_NAMES.LONGEVITY_COUNTER);
        vtGroup.setCreditIncludeFlagValues("1");

        MtxBalanceInfo mbiLongevity = CommonTestHelper.getMtxBalanceInfo(
                DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Longevity_Counter.json");
        mbiLongevity.setAvailableAmount(BigDecimal.TEN);
        mbiLongevity.setAmount(BigDecimal.TEN.negate());
        subscription.getBalanceArrayAppender().add(mbiLongevity);
        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        BigDecimal grantBalance = new BigDecimal("-15");

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn(responseMulti).when(instance).querySubscriptionGroups(any(), any(), any());
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        doReturn(grantBalance).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        PropertiesConfiguration mockConfig = AppPropertyProvider.getInstance();
        mockConfig.setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "Visible_Group_Grant");

        try (MockedStatic<AppPropertyProvider> mockedStatic = Mockito.mockStatic(
                AppPropertyProvider.class)) {
            mockedStatic.when(() -> AppPropertyProvider.getInstance()).thenReturn(mockConfig);
            instance.getAOP(input, output);
            System.out.println(output.toJson());
        }

        assertEquals(
                0,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGroup.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
        assertEquals(
                15,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGroup.getPromotionName())).findFirst().get().getAvailableCreditsGrant().intValue());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getAOP_When_AocOfferInProperty_AocConsumablesPresent_Then_AocCreditReported()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in Visible_Unlimited. Has some group consumables. Has no group grants.",
            "CI Visible_Group_Grant is listed in rsgateway property credit.grant.calculation.method.aoc.catalog.items"
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "Group credit is reported in payment advice output."
        };
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED));

        MtxResponsePricingCatalogItem ciGroupGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);
        MtxResponseMulti responseMulti = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class, DATA_DIR.PAYMENT_ADVICE
                        + "MtxResponseMulti_ForSubscriberGroupPartPay_Visible_Group_Grant.json");
        VisibleTemplate vtGroup = ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr());
        // Clear so that this incompatibility is not applied. We need to test flag balance
        vtGroup.setIncompatiblePromotions("");
        vtGroup.setCreditIncludeFlagName(BALANCE_NAMES.LONGEVITY_COUNTER);
        vtGroup.setCreditIncludeFlagValues("1");
        doReturn(responseMulti).when(instance).querySubscriptionGroups(any(), any(), any());

        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        MtxBalanceInfo mbiLongevity = CommonTestHelper.getMtxBalanceInfo(
                DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Longevity_Counter.json");
        mbiLongevity.setAvailableAmount(BigDecimal.TEN);
        mbiLongevity.setAmount(BigDecimal.TEN.negate());
        subscription.getBalanceArrayAppender().add(mbiLongevity);

        MtxBalanceInfo mbiGoodConsump = CommonTestHelper.getMtxBalanceInfoForPromoConsumable(
                CI_EXTERNAL_IDS.PARTY_PAY_GRANT, BigDecimal.TEN);
        subscription.getBalanceArrayAppender().add(mbiGoodConsump);
        doReturn(responseMulti).when(instance).querySubscriptionGroups(any(), any(), any());

        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));

        BigDecimal grantBalance = BigDecimal.ZERO;

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(grantBalance).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        PropertiesConfiguration mockConfig = AppPropertyProvider.getInstance();
        mockConfig.setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "Visible_Group_Grant");

        try (MockedStatic<AppPropertyProvider> mockedStatic = Mockito.mockStatic(
                AppPropertyProvider.class)) {
            mockedStatic.when(() -> AppPropertyProvider.getInstance()).thenReturn(mockConfig);
            instance.getAOP(input, output);
            System.out.println(output.toJson());
        }

        assertEquals(
                10,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGroup.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
        assertEquals(
                0,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGroup.getPromotionName())).findFirst().get().getAvailableCreditsGrant().intValue());
        assertEquals(
                10,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGroup.getPromotionName())).findFirst().get().getAvailableCreditsConsumable().intValue());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getAOP_When_BalanceAttributePresent_GrantPresent_Then_BalanceFirstCreditReported()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in Visible_Unlimited. Has some goodwill grants. Has no goodwill consumables.",
            "Goodwill grant balance has balance attribute providing grant ci name",
            "Goodwill grant balance has no purchased offer"
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "Goodwill credit is reported in payment advice output."
        };
        td.printDescription();
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.GOODWILL_REDEEM));

        MtxResponsePricingCatalogItem ciGoodwillGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.GRANT_GOODWILL);

        MtxResponsePricingCatalogItem ciGroupGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);

        MtxBalanceInfo mbiGoodGrant = CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                CI_EXTERNAL_IDS.GRANT_GOODWILL, BigDecimal.TEN);
        subscription.getBalanceArrayAppender().add(mbiGoodGrant);

        BigDecimal grantBalance = BigDecimal.ZERO;

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(grantBalance).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // Act
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        VisibleTemplate vtGoodwill = (VisibleTemplate) ciGoodwillGrant.getCatalogItemInfo().getTemplateAttr();
        assertEquals(
                10,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGoodwill.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
        assertEquals(
                10,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGoodwill.getPromotionName())).findFirst().get().getAvailableCreditsGrant().intValue());
        assertEquals(
                0,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGoodwill.getPromotionName())).findFirst().get().getAvailableCreditsConsumable().intValue());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getAOP_When_BalanceAttributePresent_ConsumablesPresent_Then_BalanceFirstCreditReported()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in Visible_Unlimited. Has some goodwill consumables. Has no goodwill grants.",
            "Goodwill grant balance has balance attribute providing grant ci name",
            "Goodwill grant balance has no purchased offer"
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "Goodwill credit is reported in payment advice output."
        };
        td.printDescription();
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED));

        MtxResponsePricingCatalogItem ciGoodwillGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.GRANT_GOODWILL);
        MtxResponsePricingCatalogItem ciGroupGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);
        MtxBalanceInfo mbiGoodGrant = CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                CI_EXTERNAL_IDS.GRANT_GOODWILL, BigDecimal.ZERO);
        subscription.getBalanceArrayAppender().add(mbiGoodGrant);
        MtxBalanceInfo mbiGoodConsump = CommonTestHelper.getMtxBalanceInfoForPromoConsumable(
                CI_EXTERNAL_IDS.GRANT_GOODWILL, BigDecimal.TEN);
        subscription.getBalanceArrayAppender().add(mbiGoodConsump);
        BigDecimal grantBalance = BigDecimal.ZERO;

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(grantBalance).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // Act
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        VisibleTemplate vtGoodwill = (VisibleTemplate) ciGoodwillGrant.getCatalogItemInfo().getTemplateAttr();
        assertEquals(
                10,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGoodwill.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
        assertEquals(
                0,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGoodwill.getPromotionName())).findFirst().get().getAvailableCreditsGrant().intValue());
        assertEquals(
                10,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtGoodwill.getPromotionName())).findFirst().get().getAvailableCreditsConsumable().intValue());
    }

    @Test
    public void test_getAOP_When_CreditOfferInstancePresent_GrantPresent_Then_OfferFirstCreditReported()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in Visible_Unlimited. Has some First25 grants. Has no First25 consumables.",
            "Purchased grant offer for First25 is present in subscriber object.",
            "First25 grant balance is present in subscriber object"
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "First25 credit is reported in payment advice output."
        };
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED));

        MtxResponsePricingCatalogItem ciGroupGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());

        BigDecimal f25Grant = BigDecimal.TEN;
        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, f25Grant, null);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        BigDecimal groupGrant = BigDecimal.ZERO;
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(groupGrant).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        // Assertions If group credit is 15 and referral is zero then incompatibility was parsed
        // correctly
        assertEquals(
                10,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
        assertEquals(
                10,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getAvailableCreditsGrant().intValue());
        assertEquals(
                0,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getAvailableCreditsConsumable().intValue());
    }

    @Test
    public void test_getAOP_When_CreditOfferInstancePresent_ConsumablesPresent_Then_OfferFirstCreditReported()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in Visible_Unlimited. Has some First25 consumables. Has no First25 grants.",
            "Purchased grant offer for First25 is present in subscriber object.",
            "First25 grant balance is present in subscriber object"
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "First25 credit is reported in payment advice output."
        };
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED));

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());

        MtxResponsePricingCatalogItem ciGroupGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);

        BigDecimal f25Grant = BigDecimal.ZERO;
        BigDecimal f25Consumable = BigDecimal.TEN;
        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, f25Grant, f25Consumable);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        BigDecimal groupGrant = BigDecimal.ZERO;
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(groupGrant).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        // Assertions If group credit is 15 and referral is zero then incompatibility was parsed
        // correctly
        assertEquals(
                10,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
        assertEquals(
                0,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getAvailableCreditsGrant().intValue());
        assertEquals(
                10,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getAvailableCreditsConsumable().intValue());
    }

    @Test
    public void test_getAOP_When_AttributesInOfferInstance_Then_OfferInstanceAttributes_Override_GrantCiAttributes()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in Visible_Unlimited. Has some First25 consumables or First25 grants.",
            "Purchased grant offer for First25 is present in subscriber object.",
            "First25 grant balance is present in subscriber object"
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "First25 credit is reported in payment advice output.",
            "Metadata passed in purchased grant offer's PurchasedOfferExtension will",
            "override metadata configured in grant offer's template attributes"
        };
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.PARTY_PAY_GRANT));

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());

        BigDecimal f25Grant = BigDecimal.TEN;
        MtxPurchasedOfferInfo poF25 = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, f25Grant, null);
        ((VisiblePurchasedOfferExtension) poF25.getAttr()).setRedeemOffer("XXX_YYY_ZZZ");
        ((VisiblePurchasedOfferExtension) poF25.getAttr()).setDiscountCalculationMethod(
                CREDIT_CONSTANTS.CALCULATION_METHOD_READ_OFFER_INSTANCE);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        BigDecimal groupGrant = BigDecimal.ZERO;
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(groupGrant).when(instance).getChargeableAmountForPurchaseOffer(
                any(), eq(CI_EXTERNAL_IDS.PARTY_PAY_REDEEM), any(),
                any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        // Assertions If group credit is 15 and referral is zero then incompatibility was parsed
        // correctly
        assertEquals(
                "XXX_YYY_ZZZ",
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getCreditRedeemableOfferCI());
    }

    @Test
    public void test_getAOP_When_AttributesNotInOfferInstance_Then_Default_To_GrantCiAttributes()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in Visible_Unlimited. Has some First25 consumables or First25 grants.",
            "Purchased grant offer for First25 is present in subscriber object.",
            "First25 grant balance is present in subscriber object"
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "First25 credit is reported in payment advice output.",
            "If metadata is not passed in purchased grant offer's PurchasedOfferExtension,",
            " metadata configured in grant offer's template attributes will be used by default."
        };
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(
                        CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.GRANT_GOODWILL,
                        CI_EXTERNAL_IDS.GOODWILL_REDEEM));

        MtxResponsePricingCatalogItem f25GrntCI = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        MtxResponsePricingCatalogItem ciGroupGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);

        BigDecimal f25Grant = BigDecimal.TEN;
        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, f25Grant, null);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        BigDecimal groupGrant = BigDecimal.ZERO;
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(groupGrant).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());

        VisibleTemplate vtF25 = ((VisibleTemplate) f25GrntCI.getCatalogItemInfo().getTemplateAttr());

        String actualVal = output.getCredits().stream().filter(
                vc -> vc.getPromotionName().equalsIgnoreCase(
                        vtF25.getPromotionName())).findFirst().get().getApplicableCI();
        assertEquals(vtF25.getApplicableOfferName(), actualVal);
    }

    @Test
    public void test_getAOP_When_CreditOfferInstancePresent_EndTimeBeforeNextBillCycleStart_Then_IgnoreCredit()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in Visible_Unlimited. Has some First25 consumables or First25 grants.",
            "Purchased grant offer for First25 is present in subscriber object.",
            "First25 grant balance is present in subscriber object",
            "First25 grant offer has end time before start of next billing cycle"
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "First25 credit is NOT reported in payment advice output."
        };

        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(
                        CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.GRANT_GOODWILL,
                        CI_EXTERNAL_IDS.GOODWILL_REDEEM));

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());

        MtxResponsePricingCatalogItem ciGroupGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);

        BigDecimal f25Grant = BigDecimal.TEN;
        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, f25Grant, null);
        MtxBalanceInfo mbiF25 = CommonTestHelper.getMtxBalanceInfoFromSubscriber(
                subscription, BALANCE_NAMES.FIRST25_GRANT);
        mbiF25.setEndTime(TestUtils.getFirstDateTimeOfCurrentMonth());

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        BigDecimal groupGrant = BigDecimal.ZERO;
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(groupGrant).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());

        long fist25Objects = 0;
        if (output.getCredits() == null || output.getCredits().size() == 0) {
            fist25Objects = 0;
        } else {
            fist25Objects = output.getCredits().stream().filter(
                    vc -> vc.getPromotionName().equalsIgnoreCase(vtF25.getPromotionName())).count();
        }
        assertEquals(0, fist25Objects);
    }

    @Test
    public void test_getAOP_When_PromoOfferNotActive_Then_IgnorePromo() throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in Visible_Unlimited. Has some First25 consumables or First25 grants.",
            "Purchased grant offer for First25 is present in subscriber object.",
            "First25 grant balance is present in subscriber object",
            "First25 grant offer is NOT active"
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "First25 credit is NOT reported in payment advice output."
        };

        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(
                        CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.GRANT_GOODWILL,
                        CI_EXTERNAL_IDS.GOODWILL_REDEEM));

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());

        MtxResponsePricingCatalogItem ciGroupGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);

        BigDecimal f25Grant = BigDecimal.TEN;
        MtxPurchasedOfferInfo poF25 = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, f25Grant, null);
        poF25.setOfferStatusDescription("suspended");
        poF25.setOfferStatusClass(4);
        poF25.setOfferStatusValue(4);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        BigDecimal groupGrant = BigDecimal.ZERO;
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(groupGrant).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());

        long fist25Objects = 0;
        if (output.getCredits() == null || output.getCredits().size() == 0) {
            fist25Objects = 0;
        } else {
            fist25Objects = output.getCredits().stream().filter(
                    vc -> vc.getPromotionName().equalsIgnoreCase(vtF25.getPromotionName())).count();
        }
        assertEquals(0, fist25Objects);
    }

    @SuppressWarnings("unchecked")
    @Test
    @Disabled("Main code Bug: For AOP we should check balances on start of next bill cycle. But code checks on start of current bill cycle.")
    public void test_getAOP_When_PromoConsumableBalanceEndBeforeNextBillCycle_Then_IgnoreConsumable(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in Visible_Unlimited. Has some First25 consumables or First25 grants.",
            "Purchased grant offer for First25 is present in subscriber object.",
            "First25 grant balance is present in subscriber object",
            "First25 consumable balance has end time before start of next billing cycle"
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "First25 credit is reported in payment advice output. But consumable balance is reported as ZERO."
        };

        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(
                        CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.GRANT_GOODWILL,
                        CI_EXTERNAL_IDS.GOODWILL_REDEEM));

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        MtxResponseMulti responseMulti = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class, DATA_DIR.PAYMENT_ADVICE
                        + "MtxResponseMulti_ForSubscriberGroupPartPay_Visible_Group_Grant.json");
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());

        MtxResponsePricingCatalogItem ciGroupGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);

        BigDecimal f25Grant = BigDecimal.TEN;
        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, f25Grant, null);

        BigDecimal f25Consumable = BigDecimal.ZERO;
        MtxBalanceInfo mbiF25Consump = CommonTestHelper.getMtxBalanceInfoForPromoConsumable(
                CI_EXTERNAL_IDS.FIRST25_GRANT, f25Consumable);
        subscription.getBalanceArrayAppender().add(mbiF25Consump);
        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        BigDecimal groupGrant = BigDecimal.ZERO;
        // mocks
        doReturn(responseMulti).when(instance).querySubscriptionGroups(any(), any(), any());
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(groupGrant).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // method to test
        System.out.println(testInfo.getDisplayName() + ": " + subscription.toJson());

        instance.getAOP(input, output);
        System.out.println(output.toJson());

        assertEquals(
                10,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
        assertEquals(
                10,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getAvailableCreditsGrant().intValue());
        assertEquals(
                0,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getAvailableCreditsConsumable().intValue());
    }

    @Test
    public void test_getAOP_When_SubscriberHasPreActiveOffer_Then_AdivceHasPractiveOffer()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in Plus22 that end dates this cycle.",
            "Has downgraded to Base22 that starts next cycle.", "Base22 grants offer is pre active"
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "AOP provides preactive offer in response."
        };

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        List<String> preActiveList = Arrays.asList(CI_EXTERNAL_IDS.BASE3VIS23);
        List<String> enddatedList = Arrays.asList(CI_EXTERNAL_IDS.PLUS3VIS23);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                "1234", null, preActiveList, null, enddatedList);
        subscription.getPurchasedOfferArray().forEach(mpoi -> {
            if (CI_EXTERNAL_IDS.PLUS3VIS23.equals(mpoi.getCatalogItemExternalId())) {
                mpoi.setEndTime(TestUtils.getFirstDateTimeOfNextMonth());
            }
        });

        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                "1234", null, preActiveList, null, enddatedList);
        ;
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        for (MtxPurchasedOfferInfo poi : subscriptionResponse.getPurchasedOfferArray()) {
            if (CI_EXTERNAL_IDS.PLUS3VIS23.equals(poi.getCatalogItemExternalId())) {
                poi.setEndTime(TestUtils.getFirstDateTimeOfNextMonth());
            }
        }
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(
                instance, Arrays.asList(CI_EXTERNAL_IDS.PLUS3VIS23, CI_EXTERNAL_IDS.BASE3VIS23));

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        assertEquals(
                CI_EXTERNAL_IDS.BASE3VIS23,
                output.getVisibleOfferDetailsList().stream().filter(
                        vc -> vc.getCatalogItemExternalId().equalsIgnoreCase(
                                CI_EXTERNAL_IDS.BASE3VIS23)).findFirst().get().getCatalogItemExternalId());
    }

    @Test
    public void test_getAOP_When_PromoGrantBalanceEndBeforeNextBillCycle_Then_IgnoreGrant()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in Visible_Unlimited. Has some First25 consumables or First25 grants.",
            "Purchased grant offer for First25 is present in subscriber object.",
            "First25 grant balance is present in subscriber object",
            "First25 grant balance has end time before start of next billing cycle"
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "First25 credit is reported in payment advice output. But grant balance is reported as ZERO."
        };
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED));

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());

        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, BigDecimal.TEN, BigDecimal.TEN);
        MtxBalanceInfo grantbal = CommonTestHelper.getMtxBalanceInfoFromSubscriber(
                subscription, BALANCE_NAMES.FIRST25_GRANT);
        grantbal.setEndTime(TestUtils.getFirstDateTimeOfCurrentMonth());

        MtxResponsePricingCatalogItem ciGroupGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        BigDecimal groupGrant = BigDecimal.ZERO;
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(groupGrant).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());

        assertEquals(
                10,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getRedeemableCredits().intValue());
        assertEquals(
                0,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getAvailableCreditsGrant().intValue());
        assertEquals(
                10,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getAvailableCreditsConsumable().intValue());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getAOP_When_NoMinimumChargeInPromo_MinimumChargeInService_Then_UseMinimumChargeInService()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in Visible_Unlimited. ", "Has some First25 grants.",
            "Has some group grants.", "Has some goodwill grants.",
            "Purchased grant offer for First25 is present in subscriber object.",
            "First25 grant balance is present in subscriber object",
            "Visible_Unlimited has minimum charge",
            "First25, Group or Goodwill do not have minimum charge."
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "Minimum charge from Visible_Unlimted will be used in payment advice"
        };
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        AppPropertyProvider.getInstance().setProperty(
                CREDIT_CONSTANTS.AOC_GRANT_OFFERS, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);
        BigDecimal minCharge = new BigDecimal("11");

        MtxResponsePricingCatalogItem svc = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.UNLIMITED);
        ((VisibleTemplate) svc.getCatalogItemInfo().getTemplateAttr()).setMinimumCharge(minCharge);

        MtxResponsePricingCatalogItem goodwill = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.GRANT_GOODWILL);
        ((VisibleTemplate) goodwill.getCatalogItemInfo().getTemplateAttr()).setMinimumCharge(null);

        MtxResponsePricingCatalogItem ciGroupGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);
        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).setMinimumCharge(
                null);

        MtxResponsePricingCatalogItem f25GrntCI = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        ((VisibleTemplate) f25GrntCI.getCatalogItemInfo().getTemplateAttr()).setMinimumCharge(null);

        MtxResponseMulti responseMulti = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class, DATA_DIR.PAYMENT_ADVICE
                        + "MtxResponseMulti_ForSubscriberGroupPartPay_Visible_Group_Grant.json");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                "1234", ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                "1234", ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        (new PurchasedOfferInfo(
                subscriptionResponse.getAtPurchasedOfferArray(0))).setCatalogItemDetails(
                        svc.getCatalogItemInfo());

        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscription.getBalanceArrayAppender().clear();
        BigDecimal f25Grant = BigDecimal.TEN;
        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, f25Grant, null);

        MtxBalanceInfo mbiGoodGrant = CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                CI_EXTERNAL_IDS.GRANT_GOODWILL, BigDecimal.TEN);
        subscription.getBalanceArrayAppender().add(mbiGoodGrant);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        BigDecimal groupGrant = BigDecimal.TEN.negate();
        // mocks
        doReturn(responseMulti).when(instance).querySubscriptionGroups(any(), any(), any());
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(groupGrant).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());

        assertEquals(minCharge.intValue(), output.getEstimatedPayableAmount().intValue());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getAOP_When_MinimumChargeInPromo_MinimumChargeInService_Then_UseMinimumChargeInPromo()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in Visible_Unlimited. ", "Has some First25 First25 grants.",
            "Has some group grants.", "Has some goodwill grants.",
            "Purchased grant offer for First25 is present in subscriber object.",
            "First25 grant balance is present in subscriber object",
            "Visible_Unlimited has minimum charge", "First25 has minimum charge."
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "Minimum charge from First25 will be used in payment advice"
        };
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        BigDecimal minChargeF25 = new BigDecimal("11");
        BigDecimal minChargeSvc = new BigDecimal("21");
        MtxResponsePricingCatalogItem svc = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.UNLIMITED);
        ((VisibleTemplate) svc.getCatalogItemInfo().getTemplateAttr()).setMinimumCharge(
                minChargeSvc);

        MtxResponseMulti responseMulti = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class, DATA_DIR.PAYMENT_ADVICE
                        + "MtxResponseMulti_ForSubscriberGroupPartPay_Visible_Group_Grant.json");

        MtxResponsePricingCatalogItem goodwill = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.GRANT_GOODWILL);
        ((VisibleTemplate) goodwill.getCatalogItemInfo().getTemplateAttr()).setMinimumCharge(null);

        MtxResponsePricingCatalogItem ciGroupGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);
        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).setMinimumCharge(
                null);

        MtxResponsePricingCatalogItem f25GrntCI = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        ((VisibleTemplate) f25GrntCI.getCatalogItemInfo().getTemplateAttr()).setMinimumCharge(
                minChargeF25);

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscription.getBalanceArrayAppender().clear();

        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, BigDecimal.TEN, null);

        MtxBalanceInfo mbiGoodGrant = CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                CI_EXTERNAL_IDS.GRANT_GOODWILL, BigDecimal.TEN);
        subscription.getBalanceArrayAppender().add(mbiGoodGrant);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        BigDecimal groupGrant = BigDecimal.TEN.negate();
        // mocks
        doReturn(responseMulti).when(instance).querySubscriptionGroups(any(), any(), any());
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(groupGrant).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());

        assertEquals(minChargeF25.intValue(), output.getEstimatedPayableAmount().intValue());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getAOP_When_MinimumChargeInMultiplePromo_Then_UseHighestMinimumChargeOfPromo()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in Visible_Unlimited. ", "Has some First25 First25 grants.",
            "Has some group grants.", "Has some goodwill grants.",
            "Purchased grant offer for First25 is present in subscriber object.",
            "First25 grant balance is present in subscriber object",
            "Visible_Unlimited has minimum charge",
            "First25, goodwill & group each has minimum charge."
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "Highest minimum charge from promos will be used in payment advice"
        };
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");
        AppPropertyProvider.getInstance().setProperty(
                CREDIT_CONSTANTS.AOC_GRANT_OFFERS, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);
        BigDecimal minChargeF25 = new BigDecimal("11");
        BigDecimal minChargeGoodwill = new BigDecimal("12");
        BigDecimal minChargeGroup = new BigDecimal("13");
        BigDecimal minChargeSvc = new BigDecimal("21");
        MtxResponsePricingCatalogItem svc = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.UNLIMITED);
        ((VisibleTemplate) svc.getCatalogItemInfo().getTemplateAttr()).setMinimumCharge(
                minChargeSvc);

        MtxResponsePricingCatalogItem goodwill = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.GRANT_GOODWILL);
        ((VisibleTemplate) goodwill.getCatalogItemInfo().getTemplateAttr()).setMinimumCharge(
                minChargeGoodwill);

        MtxResponseMulti responseMulti = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class, DATA_DIR.PAYMENT_ADVICE
                        + "MtxResponseMulti_ForSubscriberGroupPartPay_Visible_Group_Grant.json");

        MtxResponsePricingCatalogItem ciGroupGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);
        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).setMinimumCharge(
                minChargeGroup);

        MtxResponsePricingCatalogItem f25GrntCI = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        ((VisibleTemplate) f25GrntCI.getCatalogItemInfo().getTemplateAttr()).setMinimumCharge(
                minChargeF25);

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                "1234", ciExternalIds);
        subscription.getBalanceArrayAppender().clear();
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                "1234", ciExternalIds);
        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        BigDecimal f25Grant = BigDecimal.TEN;
        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, f25Grant, null);

        MtxBalanceInfo mbiGoodGrant = CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                CI_EXTERNAL_IDS.GRANT_GOODWILL, BigDecimal.TEN);
        subscription.getBalanceArrayAppender().add(mbiGoodGrant);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        BigDecimal groupGrant = BigDecimal.TEN.negate();
        // mocks
        doReturn(responseMulti).when(instance).querySubscriptionGroups(any(), any(), any());
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        doReturn(groupGrant).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());

        assertEquals(
                NumberUtils.max(
                        minChargeF25.intValue(), minChargeGoodwill.intValue(),
                        minChargeGroup.intValue()),
                output.getEstimatedPayableAmount().intValue());
    }

    @Test
    public void test_getAOP_When_PercentageOffer_LE_PriceMinusMinCharge_Then_ApplyPercentageOffer(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in Visible_Unlimited. Has no consumables but has grants.",
            "Grant type of offer is Percentage and passed to grant offer purchase.",
            "Percentage number is passed as charge amount to grant offer.",
            "Purchased percentage promo offer is present in subscriber object.",
            "Promo grant balance is present in subscriber object",
            "Total Available Credits is less than Discount Price Minus Minimum Charge."
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "Percentage promo is reported in payment advice output.",
            "Grant is equal to percentage of discount price "
        };
        td.testInfo = testInfo;
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                "1234", ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                "1234", ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED));

        BigDecimal percentageGrant = new BigDecimal("20");
        BigDecimal minCharge = new BigDecimal("5");
        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);

        MtxPurchasedOfferInfo poF25 = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, null, null);
        ((VisiblePurchasedOfferExtension) poF25.getAttr()).setCreditGrantType(
                CREDIT_CONSTANTS.GRANT_TYPE_PERCENTAGE);
        ((VisiblePurchasedOfferExtension) poF25.getAttr()).setChargeAmount(percentageGrant);
        ((VisiblePurchasedOfferExtension) poF25.getAttr()).setMinimumCharge(minCharge);
        ((VisiblePurchasedOfferExtension) poF25.getAttr()).setDiscountCalculationMethod(
                CREDIT_CONSTANTS.CALCULATION_METHOD_READ_OFFER_INSTANCE);

        MtxResponsePricingCatalogItem ciGroupGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);

        BigDecimal discountPrice = new BigDecimal("50");
        CommonTestHelper.resetImpactAmountInMtxResponseRecurringChargeInfo(
                discountPrice, chargeInfo);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        BigDecimal groupGrant = BigDecimal.ZERO;
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(groupGrant).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        VisibleTemplate vtF25 = (VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr();
        VisibleCredits promoResp = output.getCredits().stream().filter(
                vc -> vc.getPromotionName().equalsIgnoreCase(
                        vtF25.getPromotionName())).findFirst().get();
        assertEquals(
                percentageGrant.floatValue(),
                promoResp.getApplicableCreditsPercentage().floatValue(), 0.01);
        assertEquals(
                percentageGrant.multiply(discountPrice).divide(new BigDecimal(100)).floatValue(),
                promoResp.getAvailableCreditsGrant().floatValue(), 0.01);
        assertEquals(
                promoResp.getAvailableCreditsGrant().floatValue(),
                promoResp.getRedeemableCredits().floatValue(), 0.01);
        assertEquals(
                promoResp.getAvailableCreditsGrant().floatValue(),
                promoResp.getEstimatedTransferableCredits().floatValue(), 0.01);
        assertEquals(
                promoResp.getAvailableCredits().compareTo(discountPrice.subtract(minCharge)), -1);
    }

    @Test
    public void test_getAOP_When_PercentageOffer_GT_PriceMinusMinCharge_Then_IgnorePercentageOffer()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in Visible_Unlimited. Has no consumables but has grants.",
            "Grant type of offer is Percentage and passed to grant offer purchase.",
            "Percentage number is passed as charge amount to grant offer.",
            "Purchased percentage promo offer is present in subscriber object.",
            "Promo grant balance is present in subscriber object",
            "Total Available Credits is greater than Discount Price Minus Minimum Charge."
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "Percentage promo is ignored."
        };
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                "1234", ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                "1234", ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(
                        CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.GRANT_GOODWILL,
                        CI_EXTERNAL_IDS.GOODWILL_REDEEM));

        BigDecimal percentageGrant = new BigDecimal("90");
        BigDecimal minCharge = new BigDecimal("40");
        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);

        MtxPurchasedOfferInfo poF25 = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, null, null);
        ((VisiblePurchasedOfferExtension) poF25.getAttr()).setCreditGrantType(
                CREDIT_CONSTANTS.GRANT_TYPE_PERCENTAGE);
        ((VisiblePurchasedOfferExtension) poF25.getAttr()).setChargeAmount(percentageGrant);
        ((VisiblePurchasedOfferExtension) poF25.getAttr()).setMinimumCharge(minCharge);
        ((VisiblePurchasedOfferExtension) poF25.getAttr()).setDiscountCalculationMethod(
                CREDIT_CONSTANTS.CALCULATION_METHOD_READ_OFFER_INSTANCE);

        MtxResponsePricingCatalogItem ciGroupGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);

        BigDecimal discountPrice = new BigDecimal("50");
        CommonTestHelper.resetImpactAmountInMtxResponseRecurringChargeInfo(
                discountPrice, chargeInfo);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        BigDecimal groupGrant = BigDecimal.ZERO;
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(groupGrant).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        VisibleTemplate vtF25 = (VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr();
        VisibleCredits promoResp = output.getCredits().stream().filter(
                vc -> vc.getPromotionName().equalsIgnoreCase(
                        vtF25.getPromotionName())).findFirst().get();
        assertEquals(
                percentageGrant.floatValue(),
                promoResp.getApplicableCreditsPercentage().floatValue(), 0.01);
        assertEquals(
                percentageGrant.multiply(discountPrice).divide(new BigDecimal(100)).floatValue(),
                promoResp.getAvailableCreditsGrant().floatValue(), 0.01);
        assertEquals(0, promoResp.getRedeemableCredits().floatValue(), 0.01);
        assertEquals(0, promoResp.getEstimatedTransferableCredits().floatValue(), 0.01);
        assertEquals(
                promoResp.getAvailableCredits().compareTo(discountPrice.subtract(minCharge)), 1);
    }

    @Test
    public void test_getAOP_When_PercentagePromoHasNoLinkedPaynow_Then_IgnorePromo(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in Visible_Unlimited. Has no consumables but has grants.",
            "Grant type of offer is Percentage and passed to grant offer purchase.",
            "Percentage number is passed as charge amount to grant offer.",
            "Purchased percentage promo offer is present in subscriber object.",
            "Promo grant balance is present in subscriber object", "ApplicableCI is not purchased."
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "Percentage promo is ignored."
        };
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.INSURANCE);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(
                instance, Arrays.asList(CI_EXTERNAL_IDS.INSURANCE, CI_EXTERNAL_IDS.FIRST25_GRANT));

        BigDecimal percentageGrant = new BigDecimal("40");
        BigDecimal minCharge = new BigDecimal("5");

        MtxPurchasedOfferInfo poF25 = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, null, null);
        ((VisiblePurchasedOfferExtension) poF25.getAttr()).setCreditGrantType(
                CREDIT_CONSTANTS.GRANT_TYPE_PERCENTAGE);
        ((VisiblePurchasedOfferExtension) poF25.getAttr()).setChargeAmount(percentageGrant);
        ((VisiblePurchasedOfferExtension) poF25.getAttr()).setMinimumCharge(minCharge);
        ((VisiblePurchasedOfferExtension) poF25.getAttr()).setDiscountCalculationMethod(
                CREDIT_CONSTANTS.CALCULATION_METHOD_READ_OFFER_INSTANCE);

        MtxResponsePricingCatalogItem ciGroupGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        BigDecimal groupGrant = BigDecimal.ZERO;
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        doReturn(groupGrant).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        System.out.println(testInfo.getDisplayName() + ": " + subscriptionResponse.toJson());
        // method to test
        instance.getAOP(input, output);
        System.out.println(testInfo.getDisplayName() + ": " + output.toJson());
        assertEquals(output.getCredits(), null);
    }

    @Test
    public void test_getAOP_When_PercentagePromoHasConsumables_Then_PromoReportedWithNoTransferables()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in Visible_Unlimited. Has Percentage Promo consumables. Has Percentage Promo grants.",
            "Grant type of offer is Percentage and passed to grant offer purchase.",
            "Percentage number is passed as charge amount to grant offer.",
            "Purchased percentage promo offer is present in subscriber object.",
            "Promo grant balance is present in subscriber object"
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "Percentage promo is reported with no transferables."
        };
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED));

        BigDecimal percentageGrant = new BigDecimal("20");
        BigDecimal minCharge = new BigDecimal("5");
        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());

        BigDecimal f25Grant = BigDecimal.ZERO;
        BigDecimal f25Consumable = BigDecimal.TEN;
        MtxPurchasedOfferInfo poF25 = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, f25Grant, f25Consumable);
        ((VisiblePurchasedOfferExtension) poF25.getAttr()).setCreditGrantType(
                CREDIT_CONSTANTS.GRANT_TYPE_PERCENTAGE);
        ((VisiblePurchasedOfferExtension) poF25.getAttr()).setChargeAmount(percentageGrant);
        ((VisiblePurchasedOfferExtension) poF25.getAttr()).setMinimumCharge(minCharge);
        ((VisiblePurchasedOfferExtension) poF25.getAttr()).setDiscountCalculationMethod(
                CREDIT_CONSTANTS.CALCULATION_METHOD_READ_OFFER_INSTANCE);

        System.out.println(subscription.toJson());
        MtxResponsePricingCatalogItem ciGroupGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        BigDecimal groupGrant = BigDecimal.ZERO;
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(groupGrant).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        VisibleCredits promoResp = output.getCredits().stream().filter(
                vc -> vc.getPromotionName().equalsIgnoreCase(
                        vtF25.getPromotionName())).findFirst().get();
        assertEquals(
                percentageGrant.floatValue(),
                promoResp.getApplicableCreditsPercentage().floatValue(), 0.01);
        assertEquals(
                percentageGrant.multiply(OFFER_PRICES.UNLIMITED).divide(
                        new BigDecimal(100)).floatValue(),
                promoResp.getAvailableCreditsGrant().floatValue(), 0.01);
        assertEquals(10, promoResp.getRedeemableCredits().floatValue(), 0.01);
        assertEquals(0, promoResp.getEstimatedTransferableCredits().floatValue(), 0.01);
    }

    @Test
    public void test_getAOP_When_PercentagePromoGrantIsMoreThanCreditCap_Then_IgnorePromo()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in Visible_Unlimited. Has no consumables but has grants.",
            "Grant type of offer is Percentage and passed to grant offer purchase.",
            "Percentage number is passed as charge amount to grant offer.",
            "Purchased percentage promo offer is present in subscriber object.",
            "Promo grant balance is present in subscriber object",
            "Total Available Credits is greater than Credit Cap."
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "Percentage promo is ignored."
        };
        td.printDescription();
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                "1234", ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                "1234", ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED));

        BigDecimal percentageGrant = new BigDecimal("50");
        BigDecimal minCharge = new BigDecimal("5");
        BigDecimal promoLimit = new BigDecimal("10");
        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);

        MtxPurchasedOfferInfo poF25 = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT);
        ((VisiblePurchasedOfferExtension) poF25.getAttr()).setCreditGrantType(
                CREDIT_CONSTANTS.GRANT_TYPE_PERCENTAGE);
        ((VisiblePurchasedOfferExtension) poF25.getAttr()).setChargeAmount(percentageGrant);
        ((VisiblePurchasedOfferExtension) poF25.getAttr()).setMinimumCharge(minCharge);
        ((VisiblePurchasedOfferExtension) poF25.getAttr()).setPromotionLimit(promoLimit);
        ((VisiblePurchasedOfferExtension) poF25.getAttr()).setDiscountCalculationMethod(
                CREDIT_CONSTANTS.CALCULATION_METHOD_READ_OFFER_INSTANCE);

        // MtxBalanceInfo mbiGoodGrant = CommonTestHelper.getMtxBalanceInfoForPromoGrant(
        // CI_EXTERNAL_IDS.GRANT_GOODWILL, BigDecimal.ZERO);
        // subscription.getBalanceArrayAppender().add(mbiGoodGrant);

        MtxResponsePricingCatalogItem ciGroupGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);

        BigDecimal discountPrice = new BigDecimal("50");
        CommonTestHelper.resetImpactAmountInMtxResponseRecurringChargeInfo(
                discountPrice, chargeInfo);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        BigDecimal groupGrant = BigDecimal.ZERO;
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(groupGrant).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        VisibleTemplate vtF25 = (VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr();
        VisibleCredits promoResp = output.getCredits().stream().filter(
                vc -> vc.getPromotionName().equalsIgnoreCase(
                        vtF25.getPromotionName())).findFirst().get();
        assertEquals(
                percentageGrant.floatValue(),
                promoResp.getApplicableCreditsPercentage().floatValue(), 0.01);
        assertEquals(
                percentageGrant.multiply(discountPrice).divide(new BigDecimal(100)).floatValue(),
                promoResp.getAvailableCreditsGrant().floatValue(), 0.01);
        assertEquals(0, promoResp.getRedeemableCredits().floatValue(), 0.01);
        assertEquals(0, promoResp.getEstimatedTransferableCredits().floatValue(), 0.01);
        assertEquals(-1, promoLimit.compareTo(promoResp.getAvailableCredits()));
    }

    @Test
    public void test_getAOP_When_PromoTypePercentage_PercentageNumberInvalid_Then_IgnorePromo()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in Visible_Unlimited. Has no consumables but has grants.",
            "Grant type of offer is Percentage and passed to grant offer purchase.",
            "Percentage number is passed as charge amount to grant offer. But it more than 100",
            "Purchased percentage promo offer is present in subscriber object.",
            "Promo grant balance is present in subscriber object"
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "Percentage promo is ignored."
        };
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                "1234", ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                "1234", ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED));

        BigDecimal percentageGrant = new BigDecimal("150");
        BigDecimal minCharge = new BigDecimal("5");
        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.FIRST25_GRANT);

        MtxPurchasedOfferInfo poF25 = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT);
        ((VisiblePurchasedOfferExtension) poF25.getAttr()).setCreditGrantType(
                CREDIT_CONSTANTS.GRANT_TYPE_PERCENTAGE);
        ((VisiblePurchasedOfferExtension) poF25.getAttr()).setChargeAmount(percentageGrant);
        ((VisiblePurchasedOfferExtension) poF25.getAttr()).setMinimumCharge(minCharge);
        ((VisiblePurchasedOfferExtension) poF25.getAttr()).setDiscountCalculationMethod(
                CREDIT_CONSTANTS.CALCULATION_METHOD_READ_OFFER_INSTANCE);

        MtxResponsePricingCatalogItem ciGroupGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);

        BigDecimal discountPrice = new BigDecimal("50");
        CommonTestHelper.resetImpactAmountInMtxResponseRecurringChargeInfo(
                discountPrice, chargeInfo);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        BigDecimal groupGrant = BigDecimal.ZERO;
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(groupGrant).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        assertEquals(output.getCredits(), null);
    }

    @Test
    public void test_getAOP_When_PromoTypePercentage_GrantOfferInTemplateAttributes_Then_PercentagePromoProcessed()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in Visible_Unlimited. Has no consumables but has grants.",
            "Grant type of offer is Percentage and is set in template attributes.",
            "Percentage number is passed as charge amount to grant offer.",
            "Purchased percentage promo offer is present in subscriber object.",
            "Promo grant balance is present in subscriber object"
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "Percentage promo is processed."
        };
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                "1234", ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                "1234", ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED));

        BigDecimal percentageGrant = new BigDecimal("20");
        MtxResponsePricingCatalogItem first25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        VisibleTemplate vt = (VisibleTemplate) first25Grant.getCatalogItemInfo().getTemplateAttr();
        vt.setCreditGrantType(CREDIT_CONSTANTS.GRANT_TYPE_PERCENTAGE);
        vt.setDiscountCalculationMethod(CREDIT_CONSTANTS.CALCULATION_METHOD_READ_OFFER_INSTANCE);

        MtxPurchasedOfferInfo poF25 = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT);
        ((VisiblePurchasedOfferExtension) poF25.getAttr()).setChargeAmount(percentageGrant);

        MtxResponsePricingCatalogItem ciGroupGrant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);

        BigDecimal discountPrice = new BigDecimal("50");
        CommonTestHelper.resetImpactAmountInMtxResponseRecurringChargeInfo(
                discountPrice, chargeInfo);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        BigDecimal groupGrant = BigDecimal.ZERO;
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(groupGrant).when(instance).getChargeableAmountForPurchaseOffer(
                any(),
                eq(
                        ((VisibleTemplate) ciGroupGrant.getCatalogItemInfo().getTemplateAttr()).getRedeemOffer()),
                any(), any(MtxSubscriberSearchData.class));

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        VisibleTemplate vtF25 = (VisibleTemplate) first25Grant.getCatalogItemInfo().getTemplateAttr();
        VisibleCredits promoResp = output.getCredits().stream().filter(
                vc -> vc.getPromotionName().equalsIgnoreCase(
                        vtF25.getPromotionName())).findFirst().get();
        assertEquals(
                percentageGrant.floatValue(),
                promoResp.getApplicableCreditsPercentage().floatValue(), 0.01);
        assertEquals(
                percentageGrant.multiply(discountPrice).divide(new BigDecimal(100)).floatValue(),
                promoResp.getAvailableCreditsGrant().floatValue(), 0.01);
        assertEquals(10, promoResp.getRedeemableCredits().floatValue(), 0.01);
        assertEquals(10, promoResp.getEstimatedTransferableCredits().floatValue(), 0.01);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getAOP_When_CreditsPresent_Using_BaseOfferTaxInput_Then_CreditTaxAreCorrect(TestInfo testInfo)
            throws Exception {
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");

        System.out.println(
                testInfo.getDisplayName()
                        + "Purpose of this test case is not clear. We need revisit this and rewrite.");

        emulateAocServicePurchase(instance);

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                "1234", ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                "1234", ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.PARTY_PAY_GRANT));
        emulateMtxResponseSubscription(api, subscription);

        String taxApiResp = CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.UNLIMITED);
        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo poUnlimited = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.UNLIMITED);
        VisiblePurchasedOfferExtension attrUnlimited = (VisiblePurchasedOfferExtension) poUnlimited.getAttr();
        attrUnlimited.appendCreditTaxDetailsArray(taxApiResp);

        emulateSubscriptionResponse(instance, subscriptionResponse);
        subscriptionResponse.getPurchasedOfferArrayAppender().clear();
        PurchasedOfferInfo poiUnlimited = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, CI_EXTERNAL_IDS.UNLIMITED);
        VisiblePurchasedOfferExtension poiAttrUnlimited = (VisiblePurchasedOfferExtension) poiUnlimited.getAttr();
        poiAttrUnlimited.appendCreditTaxDetailsArray(taxApiResp);
        subscriptionResponse.getPurchasedOfferArrayAppender().add(poiUnlimited);

        subscription.getBalanceArrayAppender().add(
                CommonTestHelper.getMtxBalanceInfo(
                        DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_AmazonPrepayGrant.json"));

        MtxResponsePricingCatalogItem pciAmazon = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.AMAZON_REDEEM);
        VisibleTemplate vtAmazon = (VisibleTemplate) pciAmazon.getCatalogItemInfo().getTemplateAttr();

        String taxRespServiceAsPromo = CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.UNLIMITED);
        String taxRespSansRefCredit = new String(
                Files.readAllBytes(
                        Paths.get(
                                DATA_DIR.PAYMENT_ADVICE + "TaxResponseServiceMinusReferral.json")));

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn(new BigDecimal(-10)).when(instance).getChargeableAmountForPurchaseOffer(
                any(), eq(CI_EXTERNAL_IDS.PARTY_PAY_REDEEM), any(),
                any(MtxSubscriberSearchData.class));

        Map<String, String> amazonAttr = new HashMap<String, String>();
        amazonAttr.put("good_type", "purchase_service");
        doReturn(amazonAttr).when(instance).getOfferAttributes(
                any(), any(), eq("Visible_Redeem_Amazon_PrePay_Discount"));

        Map<String, String> groupattr = new HashMap<String, String>();
        groupattr.put("good_type", "purchase_service");
        doReturn(groupattr).when(instance).getOfferAttributes(
                any(), any(), eq(CI_EXTERNAL_IDS.PARTY_PAY_REDEEM));

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {

            // This emulation should be split into two. One for regular tax other for servicetax as
            // promotion
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), contains("CA"))).thenReturn(
                    taxRespServiceAsPromo);
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), contains("AMZN"))).thenReturn(
                            taxRespSansRefCredit);
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), contains("GRPD-CR"))).thenReturn(
                            taxRespSansRefCredit);
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), contains("CA Service"))).thenReturn(
                            taxRespSansRefCredit);
            // method to test
            instance.getAOP(input, output);
        }
        System.out.println(output.toJson());
        ServiceTaxResponse refCreditTaxResp = CommonTestHelper.getJsonFromString(
                ServiceTaxResponse.class,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equals(
                                vtAmazon.getPromotionName())).findAny().get().getTaxDetails());

        assertEquals("REF-35", refCreditTaxResp.getPlanID());
        assertEquals("REF-35", refCreditTaxResp.getMsgID());

    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getAOP_When_PurchaseServiceType_In_Offer_Then_ResponseHasIt()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in offers that have PurchaseServiceType."
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "AOP response should have PurchaseServiceType in offer details"
        };
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        TwoParameterTest pTests = (ciExternalId, purchaseServiceType) -> {
            td.printDescription();

            VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
            input.setIncludeTaxDetails("N");

            MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription();
            SubscriptionResponse subscriptionResponse = CommonTestHelper.getEmptySubscriptionResponse();
            input.setSubscriberExternalId(subscriptionResponse.getExternalId());

            emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(ciExternalId.toString()));

            subscription.getPurchasedOfferArrayAppender().clear();
            MtxPurchasedOfferInfo po = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, ciExternalId.toString());
            po.setCatalogItemExternalId(ciExternalId.toString());
            VisiblePurchasedOfferExtension attr = (VisiblePurchasedOfferExtension) po.getAttr();
            attr.setPurchaseServiceType(purchaseServiceType.toString());
            po.setAttr(attr);

            subscriptionResponse.getPurchasedOfferArrayAppender().clear();
            PurchasedOfferInfo poiUnlimited = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, ciExternalId.toString());
            po.setCatalogItemExternalId(ciExternalId.toString());
            VisiblePurchasedOfferExtension poiattr = (VisiblePurchasedOfferExtension) po.getAttr();
            poiattr.setPurchaseServiceType(purchaseServiceType.toString());
            poiUnlimited.setAttr(poiattr);
            subscriptionResponse.getPurchasedOfferArrayAppender().add(poiUnlimited);

            subscription.getBalanceArrayAppender().clear();
            MtxBalanceInfo biMainBalance = CommonTestHelper.getMtxBalanceInfo(
                    BALANCE_NAMES.MAIN_BALANCE, null, null, null);
            subscription.getBalanceArrayAppender().add(biMainBalance);

            MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                    subscriptionResponse);
            VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

            // mocks
            doReturn("").when(instance).getRoute(any());
            doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
            doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
            emulateMtxResponseSubscription(instance, subscription);
            emulateSubscriptionResponse(instance, subscriptionResponse);
            emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
            emulateMtxResponseMulti_CreditBalances(instance, subscription);
            emulateAocServicePurchase(instance);

            System.out.println(subscription.toJson());
            // method to test
            instance.getAOP(input, output);
            System.out.println(output.toJson());
            // Assertions here.
            assertEquals(
                    purchaseServiceType.toString(),
                    output.getAtVisibleOfferDetailsList(0).getPurchaseServiceType());
        };

        pTests.test(CI_EXTERNAL_IDS.UNLIMITED, PURCHASE_SERVICE_TYPES.NIB_TO_CORE_MIGRATION);
        pTests.test(CI_EXTERNAL_IDS.INSURANCE, PURCHASE_SERVICE_TYPES.NIB_TO_CORE_MIGRATION);
        pTests.test(CI_EXTERNAL_IDS.WEARABLE, PURCHASE_SERVICE_TYPES.NIB_TO_CORE_MIGRATION);
        pTests.test(CI_EXTERNAL_IDS.PLUS_CURRENT, PURCHASE_SERVICE_TYPES.NIB_TO_CORE_MIGRATION);
        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, PURCHASE_SERVICE_TYPES.NIB_TO_CORE_MIGRATION);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getAOP_When_PaidCycleStartDate_In_Offer_Then_ResponseHasIt() throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in offers that have PaidCycleStartDate."
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "AOP response should have PaidCycleStartDate in offer details"
        };
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription();
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getEmptySubscriptionResponse();
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        String baseOffer = CI_EXTERNAL_IDS.PLUS_CURRENT;
        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(
                        CI_EXTERNAL_IDS.INSURANCE, CI_EXTERNAL_IDS.WEARABLE,
                        baseOffer));

        MtxPurchasedOfferInfo poBase = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, baseOffer);
        VisiblePurchasedOfferExtension attrBase = (VisiblePurchasedOfferExtension) poBase.getAttr();
        MtxDate baseDate = new MtxDate("4000-01-01");
        attrBase.setPaidCycleStartDate(baseDate);
        poBase.setAttr(attrBase);

        PurchasedOfferInfo poiBaseEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, baseOffer);
        System.out.println("Before: " + poiBaseEnrolled.toJson());
        VisiblePurchasedOfferExtension attrBase1 = (VisiblePurchasedOfferExtension) poiBaseEnrolled.getAttr();
        attrBase1.setPaidCycleStartDate(baseDate);
        poiBaseEnrolled.setAttr(attrBase1);
        System.out.println("After: " + poiBaseEnrolled.toJson());

        MtxPurchasedOfferInfo poInsurance = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.INSURANCE);
        poInsurance.setCatalogItemExternalId(CI_EXTERNAL_IDS.INSURANCE);
        VisiblePurchasedOfferExtension attrInsurance = (VisiblePurchasedOfferExtension) poInsurance.getAttr();
        MtxDate insuranceDate = new MtxDate("4000-01-02");
        attrInsurance.setPaidCycleStartDate(insuranceDate);
        poInsurance.setAttr(attrInsurance);

        PurchasedOfferInfo poiInsuranceEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, CI_EXTERNAL_IDS.INSURANCE);
        VisiblePurchasedOfferExtension attrInsurance1 = (VisiblePurchasedOfferExtension) poiInsuranceEnrolled.getAttr();
        attrInsurance1.setPaidCycleStartDate(insuranceDate);
        poiInsuranceEnrolled.setAttr(attrInsurance1);

        MtxPurchasedOfferInfo poWearable = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.WEARABLE);
        poWearable.setCatalogItemExternalId(CI_EXTERNAL_IDS.WEARABLE);
        VisiblePurchasedOfferExtension attrWearable = (VisiblePurchasedOfferExtension) poWearable.getAttr();
        MtxDate wearableDate = new MtxDate("4000-01-03");
        attrWearable.setPaidCycleStartDate(wearableDate);
        poWearable.setAttr(attrWearable);

        PurchasedOfferInfo poiWearableEnrolled = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, CI_EXTERNAL_IDS.WEARABLE);
        VisiblePurchasedOfferExtension attrWearable1 = (VisiblePurchasedOfferExtension) poiWearableEnrolled.getAttr();
        attrWearable1.setPaidCycleStartDate(wearableDate);
        poiWearableEnrolled.setAttr(attrWearable1);

        subscription.getBalanceArrayAppender().clear();
        MtxBalanceInfo biMainBalance = CommonTestHelper.getMtxBalanceInfo(
                BALANCE_NAMES.MAIN_BALANCE, null, null, null);
        subscription.getBalanceArrayAppender().add(biMainBalance);

        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        System.out.println(subscriptionResponse.toJson());
        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());

        // Assertions here.
        MtxDate baseDateActual = output.getVisibleOfferDetailsList().stream().filter(
                vod -> vod.getCatalogItemExternalId().equals(baseOffer)).map(
                        vod -> vod.getPaidCycleStartDate()).findFirst().get();
        MtxDate insuranceDateActual = output.getVisibleOfferDetailsList().stream().filter(
                vod -> vod.getCatalogItemExternalId().equals(CI_EXTERNAL_IDS.INSURANCE)).map(
                        vod -> vod.getPaidCycleStartDate()).findFirst().get();
        MtxDate wearableDateActual = output.getVisibleOfferDetailsList().stream().filter(
                vod -> vod.getCatalogItemExternalId().equals(CI_EXTERNAL_IDS.WEARABLE)).map(
                        vod -> vod.getPaidCycleStartDate()).findFirst().get();

        assertEquals(baseDate.getTimestamp().getTime(), baseDateActual.getTimestamp().getTime());
        assertEquals(
                insuranceDate.getTimestamp().getTime(),
                insuranceDateActual.getTimestamp().getTime());
        assertEquals(
                wearableDate.getTimestamp().getTime(), wearableDateActual.getTimestamp().getTime());
    }

    @Test
    public void test_getAOP_When_Always_Then_ResponseHasOfferStatus() throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in active or preactive offers."
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "AOP response should have Offer Status in offer details"
        };
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        @SuppressWarnings("unchecked")
        TwoParameterTest pTests = (ciExternalId, status) -> {
            td.printDescription();

            VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
            input.setIncludeTaxDetails("N");

            MtxResponseSubscription subscription;
            SubscriptionResponse subscriptionResponse;
            MtxResponseRecurringChargeInfo chargeInfo;
            if (OFFER_CONSTANTS.OFFER_STATUS_PRE_ACTIVE.equalsIgnoreCase(status.toString())) {
                subscription = CommonTestHelper.getMtxResponseSubscription(
                        "1234", null, Arrays.asList(ciExternalId.toString()));
                subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                        "1234", null, Arrays.asList(ciExternalId.toString()));
                chargeInfo = CommonTestHelper.getEmptyMtxResponseRecurringChargeInfo(
                        subscriptionResponse);
            } else {
                subscription = CommonTestHelper.getMtxResponseSubscription(
                        "1234", Arrays.asList(ciExternalId.toString()));
                subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                        "1234", Arrays.asList(ciExternalId.toString()));
                chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                        subscriptionResponse);
            }
            input.setSubscriberExternalId(subscriptionResponse.getExternalId());
            emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(ciExternalId.toString()));

            subscription.getBalanceArrayAppender().clear();
            MtxBalanceInfo biMainBalance = CommonTestHelper.getMtxBalanceInfo(
                    BALANCE_NAMES.MAIN_BALANCE, null, null, null);
            subscription.getBalanceArrayAppender().add(biMainBalance);

            VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

            // mocks
            doReturn("").when(instance).getRoute(any());
            doReturn(null).when(instance).queryDeviceData(any(), any(), any());
            doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
            doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
            doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(
                    instance).queryDeviceData(any(), any(), any());
            emulateMtxResponseSubscription(instance, subscription);
            emulateSubscriptionResponse(instance, subscriptionResponse);
            emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
            emulateMtxResponseMulti_CreditBalances(instance, subscription);
            emulateAocServicePurchase(instance);

            System.out.println(subscription.toJson());
            // method to test
            instance.getAOP(input, output);
            System.out.println(output.toJson());
            // Assertions here.
            assertEquals(status, output.getAtVisibleOfferDetailsList(0).getStatus());
        };

        pTests.test(CI_EXTERNAL_IDS.UNLIMITED, OFFER_CONSTANTS.OFFER_STATUS_ACTIVE);
        pTests.test(CI_EXTERNAL_IDS.INSURANCE, OFFER_CONSTANTS.OFFER_STATUS_ACTIVE);
        pTests.test(CI_EXTERNAL_IDS.WEARABLE, OFFER_CONSTANTS.OFFER_STATUS_ACTIVE);
        pTests.test(CI_EXTERNAL_IDS.PLUS_CURRENT, OFFER_CONSTANTS.OFFER_STATUS_ACTIVE);
        pTests.test(CI_EXTERNAL_IDS.BASE_CURRENT, OFFER_CONSTANTS.OFFER_STATUS_PRE_ACTIVE);
    }

    @Test
    public void test_getAOP_When_PromoHasNoAttributeFilters_Then_ProcessNormally(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "VisibleTemplate.CreditIncludeAttributeValues is empty for promotion."
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "Promotion eligibility is decided by ignoring CreditIncludeAttributeValues.",
            "When promo is eligible to be used grant will be transferable into consumable."
        };
        td.comments = new String[] {
            "MTXVER2-169", "VER-142"
        };
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        String baseOffer = CI_EXTERNAL_IDS.PLUS_CURRENT;
        List<String> ciExternalIds = Arrays.asList(baseOffer);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription();
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(baseOffer));

        BigDecimal f25Grant = BigDecimal.TEN;
        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, f25Grant, null);

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());
        vtF25.setApplicableOfferName(baseOffer);
        vtF25.getCreditIncludeAttributeValuesAppender().clear();

        System.out.println(testInfo.getDisplayName() + "subscription: " + subscription.toJson());
        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        // method to test
        instance.getAOP(input, output);
        System.out.println(testInfo.getDisplayName() + "Output: " + output.toJson());
        assertEquals(
                f25Grant.intValue(),
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getEstimatedTransferableCredits().intValue());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getAOP_When_OnlyAttributeFilter_is_Empty_Then_ProcessNormally()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "VisibleTemplate.CreditIncludeAttributeValues has only one entry, and the entry is EMPTY."
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "Promotion eligibility is decided by ignoring CreditIncludeAttributeValues.",
            "When promo is eligible to be used grant will be transferable into consumable."
        };
        td.comments = new String[] {
            "MTXVER2-169", "VER-142"
        };
        td.printDescription();
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, ""); // Assume
                                                                                              // there
                                                                                              // are
                                                                                              // no
                                                                                              // AOC
                                                                                              // Promos

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.PLUS2VIS22);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription();
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.PLUS2VIS22));

        BigDecimal f25Grant = BigDecimal.TEN;
        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, f25Grant, null);

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());
        vtF25.setApplicableOfferName(CI_EXTERNAL_IDS.PLUS2VIS22);
        vtF25.getCreditIncludeAttributeValuesAppender().clear();
        vtF25.getCreditIncludeAttributeValuesAppender().add("  ");

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        assertEquals(
                f25Grant.intValue(),
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getEstimatedTransferableCredits().intValue());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getAOP_When_OnlyAttributeFilter_is_Invalid_Then_IgnoreFilter()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "VisibleTemplate.CreditIncludeAttributeValues has only one entry, and the entry is invalid."
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "Promotion eligibility is decided by ignoring CreditIncludeAttributeValues.",
            "When promo is eligible to be used grant will be transferable into consumable."
        };
        td.comments = new String[] {
            "MTXVER2-169", "VER-142"
        };
        td.printDescription();
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, ""); // Assume
                                                                                              // there
                                                                                              // are
                                                                                              // no
                                                                                              // AOC
                                                                                              // Promos

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.PLUS2VIS22);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.PLUS2VIS22));

        BigDecimal f25Grant = BigDecimal.TEN;
        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, f25Grant, null);

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());
        vtF25.setApplicableOfferName(CI_EXTERNAL_IDS.PLUS2VIS22);
        vtF25.getCreditIncludeAttributeValuesAppender().clear();
        vtF25.getCreditIncludeAttributeValuesAppender().add("bla bli blu ");

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        assertEquals(
                f25Grant.intValue(),
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getEstimatedTransferableCredits().intValue());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getAOP_When_AnyAttributeFilter_is_Invalid_Then_IgnoreFilter()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "VisibleTemplate.CreditIncludeAttributeValues has multiple entries, and at least one entry is invalid."
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "Promotion eligibility is decided by ignoring bad CreditIncludeAttributeValues",
            "When promo is eligible to be used grant will be transferable into consumable."
        };
        td.comments = new String[] {
            "MTXVER2-169", "VER-142"
        };
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, ""); 
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription();
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getEmptySubscriptionResponse();
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        String baseOffer = CI_EXTERNAL_IDS.PLUS_CURRENT;
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList());

        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo poPlus22 = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, baseOffer);
        VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poPlus22.getAttr();
        String offerChangetype = "XYZ123";
        poExtn.setOfferChangeType(offerChangetype);

        subscriptionResponse.getPurchasedOfferArrayAppender().clear();
        PurchasedOfferInfo poiPlus22 = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, baseOffer);
        VisiblePurchasedOfferExtension poiExtn = (VisiblePurchasedOfferExtension) poiPlus22.getAttr();
        poiExtn.setOfferChangeType(offerChangetype);
        subscriptionResponse.getPurchasedOfferArrayAppender().add(poiPlus22);

        BigDecimal f25Grant = BigDecimal.TEN;
        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT, null, f25Grant, null);

        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT);
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());
        vtF25.setApplicableOfferName(poPlus22.getCatalogItemExternalId());
        vtF25.getCreditIncludeAttributeValuesAppender().clear();
        vtF25.getCreditIncludeAttributeValuesAppender().add("bla bli blu ");
        vtF25.getCreditIncludeAttributeValuesAppender().add(
                VisiblePurchasedOfferExtension.class.getSimpleName() + ".OfferChangeType="
                        + offerChangetype);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        assertEquals(
                f25Grant.intValue(),
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getEstimatedTransferableCredits().intValue());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getAOP_When_OnlyAttributeFilterBlocks_Then_Promo_Not_In_Response()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "VisibleTemplate.CreditIncludeAttributeValues has only one entry, and the entry is valid.\r\n"
                    + "Promotion has zero consumables."
        };
        td.when = new String[] {
            "Payment Advice is called.\r\n"
                    + "CreditIncludeAttributeValues does not match with any VisiblePurchasedOfferExtension.OfferChangeType"
        };
        td.then = new String[] {
            "Promotion is present in PaymentAdvice Response with zero transferables."
        };
        td.comments = new String[] {
            "MTXVER2-169", "VER-142"
        };
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, ""); // Assume
                                                                                              // there
                                                                                              // are
                                                                                              // no
                                                                                              // AOC
                                                                                              // Promos
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription();
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getEmptySubscriptionResponse();
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.PLUS2VIS22));

        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo poPlus22 = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.PLUS2VIS22);
        VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poPlus22.getAttr();
        String offerChangetypeActual = "XYZ123";
        String offerChangetypeExpected = "ABC123";
        poExtn.setOfferChangeType(offerChangetypeActual);

        subscriptionResponse.getPurchasedOfferArrayAppender().clear();
        PurchasedOfferInfo poiPlus22 = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, CI_EXTERNAL_IDS.PLUS2VIS22);
        VisiblePurchasedOfferExtension poiExtn = (VisiblePurchasedOfferExtension) poiPlus22.getAttr();
        poiExtn.setOfferChangeType(offerChangetypeActual);
        subscriptionResponse.getPurchasedOfferArrayAppender().add(poiPlus22);

        BigDecimal f25Grant = BigDecimal.TEN;
        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, f25Grant, null);

        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());
        vtF25.setApplicableOfferName(poPlus22.getCatalogItemExternalId());
        vtF25.getCreditIncludeAttributeValuesAppender().clear();
        vtF25.getCreditIncludeAttributeValuesAppender().add(
                VisiblePurchasedOfferExtension.class.getSimpleName() + ".OfferChangeType="
                        + offerChangetypeExpected);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        assertEquals(
                0,
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getEstimatedTransferableCredits().intValue());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getAOP_When_OnlyAttributeFilterMatches_Then_Promo_In_Response()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "VisibleTemplate.CreditIncludeAttributeValues has only one entry, and the entry is valid."
        };
        td.when = new String[] {
            "Payment Advice is called.",
            "CreditIncludeAttributeValues matches with at least one of VisiblePurchasedOfferExtension.OfferChangeType.",
            "Promotion is not blocked by any other rule."
        };
        td.then = new String[] {
            "Promotion is present in PaymentAdvice Response."
        };
        td.comments = new String[] {
            "MTXVER2-169", "VER-142"
        };
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, ""); // Assume
                                                                                              // there
                                                                                              // are
                                                                                              // no
                                                                                              // AOC
                                                                                              // Promos
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription();
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getEmptySubscriptionResponse();
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());

        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.PLUS2VIS22));

        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo poPlus22 = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.PLUS2VIS22);
        VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poPlus22.getAttr();
        String offerChangetype = "XYZ123";
        poExtn.setOfferChangeType(offerChangetype);

        subscriptionResponse.getBillingCycle().setCurrentPeriodStartTime(
                TestUtils.getLastDateTimeOfLastMonth(subscriptionResponse.getTimeZone()));
        subscriptionResponse.getBillingCycle().setCurrentPeriodEndTime(
                TestUtils.getLastDateTimeOfCurrentMonth(subscriptionResponse.getTimeZone()));
        subscriptionResponse.getPurchasedOfferArrayAppender().clear();

        CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, CI_EXTERNAL_IDS.PLUS2VIS22);
        VisiblePurchasedOfferExtension poiExtn = (VisiblePurchasedOfferExtension) poPlus22.getAttr();
        poiExtn.setOfferChangeType(offerChangetype);

        BigDecimal f25Grant = BigDecimal.TEN;
        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, f25Grant, null);

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());
        vtF25.setApplicableOfferName(poPlus22.getCatalogItemExternalId());
        vtF25.getCreditIncludeAttributeValuesAppender().clear();
        vtF25.getCreditIncludeAttributeValuesAppender().add(
                VisiblePurchasedOfferExtension.class.getSimpleName() + ".OfferChangeType="
                        + offerChangetype);

        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        assertEquals(
                f25Grant.intValue(),
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getEstimatedTransferableCredits().intValue());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getAOP_When_AnyAttributeFilterMatches_Then_Promo_In_Response(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "VisibleTemplate.CreditIncludeAttributeValues has multiple entries."
        };
        td.when = new String[] {
            "Payment Advice is called."
                    + "At least one of the CreditIncludeAttributeValues matches with at least one of VisiblePurchasedOfferExtension.OfferChangeType.\r\n"
                    + "Promotion is not blocked by any other rule."
        };
        td.then = new String[] {
            "Promotion is present in PaymentAdvice Response. Has transferables as applicable."
        };
        td.comments = new String[] {
            "MTXVER2-169", "VER-142"
        };
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription();
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getEmptySubscriptionResponse();
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.PLUS2VIS22));

        subscription.getPurchasedOfferArrayAppender().clear();
        MtxPurchasedOfferInfo poPlus22 = CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.PLUS2VIS22);
        VisiblePurchasedOfferExtension poExtn = (VisiblePurchasedOfferExtension) poPlus22.getAttr();
        String offerChangetype = "XYZ123";
        poExtn.setOfferChangeType(offerChangetype);

        BigDecimal f25Grant = BigDecimal.TEN;
        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIRST25_GRANT, null, f25Grant, null);

        subscriptionResponse.getPurchasedOfferArrayAppender().clear();
        CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, CI_EXTERNAL_IDS.PLUS2VIS22);
        CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, CI_EXTERNAL_IDS.FIRST25_GRANT);

        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        MtxResponsePricingCatalogItem ciF25Grant = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.FIRST25_GRANT);
        VisibleTemplate vtF25 = ((VisibleTemplate) ciF25Grant.getCatalogItemInfo().getTemplateAttr());
        vtF25.setApplicableOfferName(poPlus22.getCatalogItemExternalId());
        vtF25.getCreditIncludeAttributeValuesAppender().clear();
        vtF25.getCreditIncludeAttributeValuesAppender().add(
                VisibleSubscriberExtension.class.getSimpleName() + ".Brand=" + "ABC123");
        vtF25.getCreditIncludeAttributeValuesAppender().add(
                VisiblePurchasedOfferExtension.class.getSimpleName() + ".OfferChangeType="
                        + offerChangetype);

        System.out.println(
                testInfo.getDisplayName() + " Subscription: " + subscriptionResponse.toJson());
        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        // method to test
        instance.getAOP(input, output);
        System.out.println(testInfo.getDisplayName() + " output: " + output.toJson());
        assertEquals(
                f25Grant.intValue(),
                output.getCredits().stream().filter(
                        vc -> vc.getPromotionName().equalsIgnoreCase(
                                vtF25.getPromotionName())).findFirst().get().getEstimatedTransferableCredits().intValue());
    }

    /******************************************************
     * Tax Related Tests Begin
     *************************************/
    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "Given_ServiceTemplateNo_DefaultTemplateExist_Then_Use_DefaultTemplate")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber is eligible for a promotion. Promotion has does not have ServicePromoTaxTemplate. Promotion has default tax temlate.|"             
                +"|When  |AOP is called.|"
                +"|Then  |Default PromoTaxTemplate will be used call taxapi for promotion.|"})
    // @formatter:on
    public void test_getAOP_Given_ServiceTemplateNo_DefaultTemplateExist_Then_Use_DefaultTemplate(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");

        AppPropertyProvider.getInstance().setProperty(
                CREDIT_CONSTANTS.AOC_GRANT_OFFERS, CI_EXTERNAL_IDS.VBPP5_AOC_GRANT);
        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.PLUS2VIS22);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.PLUS2VIS22));

        subscription.getBalanceArrayAppender().clear();
        MtxBalanceInfo biMainbalance = CommonTestHelper.getMtxBalanceInfo(
                BALANCE_NAMES.MAIN_BALANCE, null, null, null);
        subscription.getBalanceArrayAppender().add(biMainbalance);
        subscription.setParentGroupCount(1L);
        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscriptionResponse.setParentGroupCount(1L);
        subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));

        doReturn(BigDecimal.valueOf(5).negate()).when(instance).getChargeableAmountForPurchaseOffer(
                any(), eq(CI_EXTERNAL_IDS.VBPP_CORE_REDEEM), any(),
                any(MtxSubscriberSearchData.class));

        MtxResponsePricingCatalogItem pciVbpp5 = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.VBPP5_AOC_GRANT);
        pciVbpp5.getCatalogItemInfo().getMetadataList().forEach(pmi -> {
            if (pmi.getName().startsWith(CI_EXTERNAL_IDS.PLUS2VIS22)) {
                pmi.setName("Garbage");
            }
            if (pmi.getName().endsWith(CI_METADATA.TAX_INPUT)) {
                pmi.setValue(
                        pmi.getValue().replace(
                                pmi.getValue().split(",")[0],
                                "{\"msgID\": \"" + pmi.getName() + "\""));
            }
        });

        MtxResponseMulti responseGroupMulti = new MtxResponseMulti();
        responseGroupMulti.setResult(RESULT_CODES.MTX_SUCCESS);
        responseGroupMulti.setResultText("OK");
        MtxResponseGroup respGrp = new MtxResponseGroup();
        respGrp.setTier("VBPP");
        responseGroupMulti.appendResponseList(respGrp);

        System.out.println(responseGroupMulti.toJson());
        doReturn(responseGroupMulti).when(instance).querySubscriptionGroups(any(), any(), any());
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        String taxRespServiceAsPromo = CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.PLUS2VIS22);
        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxRespServiceAsPromo);

            // method to test
            instance.getAOP(input, output);
        }
        System.out.println(output.toJson());

        VisibleTemplate vtVbpp5 = (VisibleTemplate) pciVbpp5.getCatalogItemInfo().getTemplateAttr();
        String templateName = "";
        for (String taxReqString : argumentCaptor.getAllValues()) {
            System.out.println(taxReqString);
            ServiceTaxRequest taxReq = CommonTestHelper.getJsonFromString(
                    ServiceTaxRequest.class, taxReqString);
            if (taxReq.getClassCode().equalsIgnoreCase(vtVbpp5.getClassCode())) {
                templateName = taxReq.getMsgID();
            }
        }

        System.out.println(
                "If Service Specific Tax Template is not present but Default Template exists. Use default template.");
        assertThat(templateName).startsWith(CI_METADATA.TAX_INPUT);
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name = "Given_ServiceTemplateNo_DefaultTemplateNo_Then_Use_NoPromoTax")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber is eligible for a promotion. Promotion has neither ServicePromoTaxTemplate nor defaultTaxTemlate.|"             
                +"|When  |AOP is called.|"
                +"|Then  |taxapi will not be called for promotion.|"})
    // @formatter:on
    public void test_getAOP_Given_ServiceTemplateNo_DefaultTemplateNo_Then_Use_NoPromoTax(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");

        AppPropertyProvider.getInstance().setProperty(
                CREDIT_CONSTANTS.AOC_GRANT_OFFERS, CI_EXTERNAL_IDS.VBPP5_AOC_GRANT);
        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.PLUS2VIS22);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.PLUS2VIS22));

        subscription.getBalanceArrayAppender().clear();
        MtxBalanceInfo biMainbalance = CommonTestHelper.getMtxBalanceInfo(
                BALANCE_NAMES.MAIN_BALANCE, null, null, null);
        subscription.getBalanceArrayAppender().add(biMainbalance);
        subscription.setParentGroupCount(1L);
        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscriptionResponse.setParentGroupCount(1L);
        subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));

        doReturn(BigDecimal.valueOf(5).negate()).when(instance).getChargeableAmountForPurchaseOffer(
                any(), eq(CI_EXTERNAL_IDS.VBPP_CORE_REDEEM), any(),
                any(MtxSubscriberSearchData.class));

        MtxResponsePricingCatalogItem pciVbpp5 = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.VBPP5_AOC_GRANT);
        pciVbpp5.getCatalogItemInfo().getMetadataList().forEach(pmi -> {
            if (pmi.getName().equalsIgnoreCase(CI_METADATA.TAX_INPUT)) {
                pmi.setName("Garbage1");
            }
            if (pmi.getName().startsWith(CI_EXTERNAL_IDS.PLUS2VIS22)) {
                pmi.setName("Garbage2");
            }
            if (pmi.getName().endsWith(CI_METADATA.TAX_INPUT)) {
                pmi.setValue(
                        pmi.getValue().replace(
                                pmi.getValue().split(",")[0],
                                "{\"msgID\": \"" + pmi.getName() + "\""));
            }
        });

        MtxResponseMulti responseGroupMulti = new MtxResponseMulti();
        responseGroupMulti.setResult(RESULT_CODES.MTX_SUCCESS);
        responseGroupMulti.setResultText("OK");
        MtxResponseGroup respGrp = new MtxResponseGroup();
        respGrp.setTier("VBPP");
        responseGroupMulti.appendResponseList(respGrp);

        System.out.println(responseGroupMulti.toJson());
        doReturn(responseGroupMulti).when(instance).querySubscriptionGroups(any(), any(), any());
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        String taxRespServiceAsPromo = CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.PLUS2VIS22);
        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxRespServiceAsPromo);

            // method to test
            instance.getAOP(input, output);
        }
        System.out.println(output.toJson());

        VisibleTemplate vtVbpp5 = (VisibleTemplate) pciVbpp5.getCatalogItemInfo().getTemplateAttr();
        String templateName = "";
        for (String taxReqString : argumentCaptor.getAllValues()) {
            System.out.println(taxReqString);
            ServiceTaxRequest taxReq = CommonTestHelper.getJsonFromString(
                    ServiceTaxRequest.class, taxReqString);
            if (taxReq.getClassCode().equalsIgnoreCase(vtVbpp5.getClassCode())) {
                templateName = taxReq.getMsgID();
            }
        }

        System.out.println("When no tax template is present, credit tax calculation will fail..");
        assertThat(templateName).isBlank();
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "Given_ServiceTemplateExist_DefaultTemplateExist_Then_Use_ServiceTemplateTemplate")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber is eligible for a promotion. Promotion has both ServicePromoTaxTemplate and DefaultTaxTemplate.|"             
                +"|When  |AOP is called.|"
                +"|Then  |ServicePromoTaxTemplate will be used call taxapi for promotion.|"})
    // @formatter:on
    public void test_getAOP_Given_ServiceTemplateExist_DefaultTemplateExist_Then_Use_ServiceTemplateTemplate(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");

        AppPropertyProvider.getInstance().setProperty(
                CREDIT_CONSTANTS.AOC_GRANT_OFFERS, CI_EXTERNAL_IDS.VBPP5_AOC_GRANT);
        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.PLUS2VIS22);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.PLUS2VIS22));

        subscription.getBalanceArrayAppender().clear();
        MtxBalanceInfo biMainbalance = CommonTestHelper.getMtxBalanceInfo(
                BALANCE_NAMES.MAIN_BALANCE, null, null, null);
        subscription.getBalanceArrayAppender().add(biMainbalance);
        subscription.setParentGroupCount(1L);
        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscriptionResponse.setParentGroupCount(1L);
        subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));

        doReturn(BigDecimal.valueOf(5).negate()).when(instance).getChargeableAmountForPurchaseOffer(
                any(), eq(CI_EXTERNAL_IDS.VBPP_CORE_REDEEM), any(),
                any(MtxSubscriberSearchData.class));

        MtxResponsePricingCatalogItem pciVbpp5 = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.VBPP5_AOC_GRANT);
        pciVbpp5.getCatalogItemInfo().getMetadataList().forEach(pmi -> {
            if (pmi.getName().endsWith(CI_METADATA.TAX_INPUT)) {
                pmi.setValue(
                        pmi.getValue().replace(
                                pmi.getValue().split(",")[0],
                                "{\"msgID\": \"" + pmi.getName() + "\""));
            }
        });

        MtxResponseMulti responseGroupMulti = new MtxResponseMulti();
        responseGroupMulti.setResult(RESULT_CODES.MTX_SUCCESS);
        responseGroupMulti.setResultText("OK");
        MtxResponseGroup respGrp = new MtxResponseGroup();
        respGrp.setTier("VBPP");
        responseGroupMulti.appendResponseList(respGrp);

        System.out.println(responseGroupMulti.toJson());
        doReturn(responseGroupMulti).when(instance).querySubscriptionGroups(any(), any(), any());
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        String taxRespServiceAsPromo = CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.PLUS2VIS22);
        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxRespServiceAsPromo);

            // method to test
            instance.getAOP(input, output);
        }
        System.out.println(output.toJson());

        VisibleTemplate vtVbpp5 = (VisibleTemplate) pciVbpp5.getCatalogItemInfo().getTemplateAttr();
        String templateName = "";
        for (String taxReqString : argumentCaptor.getAllValues()) {
            System.out.println(taxReqString);
            ServiceTaxRequest taxReq = CommonTestHelper.getJsonFromString(
                    ServiceTaxRequest.class, taxReqString);
            if (taxReq.getClassCode().equalsIgnoreCase(vtVbpp5.getClassCode())) {
                templateName = taxReq.getMsgID();
            }
        }

        System.out.println("If Service Specific Tax Template Exists use it.");
        assertThat(templateName).startsWith("PLUS2VIS22WB");

    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(
            name = "Given_ServiceTemplateExist_DefaultTemplateExist_Then_Use_ServiceTemplateTemplate")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber is eligible for a promotion. Promotion has ServicePromoTaxTemplate only.|"             
                +"|When  |AOP is called.|"
                +"|Then  |ServicePromoTaxTemplate will be used call taxapi for promotion.|"})
    // @formatter:on
    public void test_getAOP_Given_ServiceTemplateExist_DefaultTemplateNo_Then_Use_ServiceTemplate(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");

        AppPropertyProvider.getInstance().setProperty(
                CREDIT_CONSTANTS.AOC_GRANT_OFFERS, CI_EXTERNAL_IDS.VBPP5_AOC_GRANT);
        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.PLUS2VIS22);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.PLUS2VIS22));

        subscription.getBalanceArrayAppender().clear();
        MtxBalanceInfo biMainbalance = CommonTestHelper.getMtxBalanceInfo(
                BALANCE_NAMES.MAIN_BALANCE, null, null, null);
        subscription.getBalanceArrayAppender().add(biMainbalance);
        subscription.setParentGroupCount(1L);
        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
        subscriptionResponse.setParentGroupCount(1L);
        subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));

        doReturn(BigDecimal.valueOf(5).negate()).when(instance).getChargeableAmountForPurchaseOffer(
                any(), eq(CI_EXTERNAL_IDS.VBPP_CORE_REDEEM), any(),
                any(MtxSubscriberSearchData.class));

        MtxResponsePricingCatalogItem pciVbpp5 = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.VBPP5_AOC_GRANT);
        pciVbpp5.getCatalogItemInfo().getMetadataList().forEach(pmi -> {
            if (pmi.getName().equalsIgnoreCase(CI_METADATA.TAX_INPUT)) {
                pmi.setName("Garbage");
            }
            if (pmi.getName().endsWith(CI_METADATA.TAX_INPUT)) {
                pmi.setValue(
                        pmi.getValue().replace(
                                pmi.getValue().split(",")[0],
                                "{\"msgID\": \"" + pmi.getName() + "\""));
            }
        });

        MtxResponseMulti responseGroupMulti = new MtxResponseMulti();
        responseGroupMulti.setResult(RESULT_CODES.MTX_SUCCESS);
        responseGroupMulti.setResultText("OK");
        MtxResponseGroup respGrp = new MtxResponseGroup();
        respGrp.setTier("VBPP");
        responseGroupMulti.appendResponseList(respGrp);

        System.out.println(responseGroupMulti.toJson());
        doReturn(responseGroupMulti).when(instance).querySubscriptionGroups(any(), any(), any());
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        String taxRespServiceAsPromo = CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.PLUS2VIS22);
        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxRespServiceAsPromo);

            // method to test
            instance.getAOP(input, output);
        }
        System.out.println(output.toJson());

        VisibleTemplate vtVbpp5 = (VisibleTemplate) pciVbpp5.getCatalogItemInfo().getTemplateAttr();
        String templateName = "";
        for (String taxReqString : argumentCaptor.getAllValues()) {
            System.out.println(taxReqString);
            ServiceTaxRequest taxReq = CommonTestHelper.getJsonFromString(
                    ServiceTaxRequest.class, taxReqString);
            if (taxReq.getClassCode().equalsIgnoreCase(vtVbpp5.getClassCode())) {
                templateName = taxReq.getMsgID();
            }
        }
        System.out.println("If Service Specific Tax Template Exists use it.");
        assertThat(templateName).startsWith("PLUS2VIS22WB");
    }

    /******************************************************
     * Tax Related Tests End
     *************************************/

    /******************************************************
     * Bulk Test
     ***********************************************/
    @SuppressWarnings({
        "unchecked", "serial"
    })
    @Test
    public void test_getAOP_When_PromotionsPresent_Then_AdviceShouldBeCorrect() throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in offers."
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "AOP response should have correct promotion values. Aop response should have correct mainbalance and payable values."
        };

        Map<String, BigDecimal> priceMap = new HashMap<String, BigDecimal>() {

            {
                put(CI_EXTERNAL_IDS.UNLIMITED, OFFER_PRICES.UNLIMITED);
                put(CI_EXTERNAL_IDS.BASE_CURRENT, OFFER_PRICES.BASE_CURRENT);
                put(CI_EXTERNAL_IDS.PLUS_CURRENT, OFFER_PRICES.PLUS_CURRENT);
                put(CI_EXTERNAL_IDS.WEARABLE, OFFER_PRICES.WEARABLE);
                put(CI_EXTERNAL_IDS.INSURANCE, OFFER_PRICES.INSURANCE);
            }
        };

        OneParameterTest pTests = (tCase) -> {
            td.printDescription();
            TestCase testCase = (TestCase) tCase;
            String stars = "***************************************";
            System.out.println(
                    MessageFormat.format(
                            "{0}Executing Test {1}{2}", stars, testCase.testNum, stars));

            VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
            input.setIncludeTaxDetails("N");
            input.setSubscriberExternalId("123");

            AppPropertyProvider.getInstance().setProperty(
                    CREDIT_CONSTANTS.AOC_GRANT_OFFERS, CI_EXTERNAL_IDS.PARTY_PAY_GRANT);

            List<String> ciExternalIds = Arrays.asList(testCase.baseOffer);
            if (testCase.hasWearable) {
                ciExternalIds.add(CI_EXTERNAL_IDS.WEARABLE);
            }
            if (testCase.hasInsurance) {
                ciExternalIds.add(CI_EXTERNAL_IDS.INSURANCE);
            }
            MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                    ciExternalIds);
            SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                    ciExternalIds);
            MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                    subscriptionResponse);
            emulateMtxResponsePricingCatalogItems(
                    instance,
                    Arrays.asList(
                            testCase.baseOffer, CI_EXTERNAL_IDS.WEARABLE, CI_EXTERNAL_IDS.INSURANCE,
                            CI_EXTERNAL_IDS.REF35_GRANT, CI_EXTERNAL_IDS.PARTY_PAY_GRANT));
            MtxResponseMulti responseMulti = CommonTestHelper.loadJsonMessage(
                    MtxResponseMulti.class, DATA_DIR.PAYMENT_ADVICE
                            + "MtxResponseMulti_ForSubscriberGroupPartPay_Visible_Group_Grant.json");
            BalanceInfo mainBalanceWallet = CommonTestHelper.getBalanceInfo(
                    BALANCE_NAMES.MAIN_BALANCE, null, null, testCase.mainBalance);
            subscriptionResponse.getWalletBalancesAppender().add(mainBalanceWallet);
            subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
            subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
            subscription.getBalanceArrayAppender().clear();
            MtxBalanceInfo biMainBalance = CommonTestHelper.getMtxBalanceInfo(
                    BALANCE_NAMES.MAIN_BALANCE, null, null, testCase.mainBalance);
            subscription.getBalanceArrayAppender().add(biMainBalance);

            int balanceResourceId = 0;
            int balanceId = 100;
            MtxResponseMulti multiGrantBalance = CommonTestHelper.getMtxResponsePricingBalances(
                    null);
            for (TestCasePromo promo : testCase.promoList) {
                MtxResponsePricingCatalogItem ciGrantOffer = emulateMtxResponsePricingCatalogItem(
                        instance, promo.grantOffer);
                VisibleTemplate vtGrant = (VisibleTemplate) ciGrantOffer.getCatalogItemInfo().getTemplateAttr();
                vtGrant.setIncompatiblePromotions(""); // Write a separate test case for
                                                       // incompatibilities.
                promo.redeemOffer = vtGrant.getRedeemOffer();
                if (promo.priority == -1) {
                    promo.priority = vtGrant.getPromotionPriority();
                }
                if (promo.limit == -1 && vtGrant.getPromotionLimit() != null) {
                    promo.limit = vtGrant.getPromotionLimit().intValue();
                }
                if (CREDIT_CONSTANTS.CALCULATION_METHOD_AOC.equalsIgnoreCase(
                        vtGrant.getDiscountCalculationMethod())) {
                    BigDecimal grantAmount = promo.grant > 0
                            ? BigDecimal.valueOf(promo.grant) : BigDecimal.ZERO;
                    doReturn(grantAmount.negate()).when(
                            instance).getChargeableAmountForPurchaseOffer(
                                    any(),
                                    argThat(
                                            (String ciExternalId) -> ciExternalId.equalsIgnoreCase(
                                                    vtGrant.getRedeemOffer())),
                                    any(), any());
                } else if (testCase.grantFileMap.get(promo.grantOffer) != null) {
                    MtxBalanceInfo biGrant = CommonTestHelper.getMtxBalanceInfo(
                            testCase.grantFileMap.get(promo.grantOffer), ++balanceResourceId,
                            ++balanceId);
                    biGrant.setAmount(BigDecimal.valueOf(promo.grant).negate());
                    biGrant.setAvailableAmount(BigDecimal.valueOf(promo.grant));
                    biGrant.setEndTime(TestUtils.getLastDateTimeOfNextMonth());
                    subscription.getBalanceArrayAppender().add(biGrant);
                    if (testCase.balanceFileMap.get(biGrant.getName()) != null) {
                        MtxResponsePricingBalance grantPricing = CommonTestHelper.loadJsonMessage(
                                MtxResponsePricingBalance.class,
                                testCase.balanceFileMap.get(biGrant.getName()));
                        multiGrantBalance.getResponseListAppender().add(grantPricing);
                    }
                    if (testCase.poFileMap.get(promo.grantOffer) != null) {
                        MtxPurchasedOfferInfo poGrant = CommonTestHelper.getMtxPurchasedOfferInfo(
                                testCase.poFileMap.get(promo.grantOffer), balanceResourceId,
                                balanceId);
                        poGrant.setEndTime(TestUtils.getLastDateTimeOfNextMonth());
                        subscription.getPurchasedOfferArrayAppender().add(poGrant);
                    }
                }

                if (testCase.consumeFileMap.get(promo.grantOffer) != null && promo.consumable > 0) {
                    MtxBalanceInfo biConsume = CommonTestHelper.getMtxBalanceInfo(
                            testCase.consumeFileMap.get(promo.grantOffer), balanceResourceId++,
                            balanceId++);
                    biConsume.setAmount(BigDecimal.valueOf(promo.consumable).negate());
                    biConsume.setAvailableAmount(BigDecimal.valueOf(promo.consumable));
                    biConsume.setEndTime(TestUtils.getLastDateTimeOfNextMonth());
                    subscription.getBalanceArrayAppender().add(biConsume);
                }
            }

            VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

            // mocks
            doReturn(responseMulti).when(instance).querySubscriptionGroups(any(), any(), any());
            doReturn("").when(instance).getRoute(any());
            doReturn(null).when(instance).queryDeviceData(any(), any(), any());
            doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
            doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
            doReturn(multiGrantBalance).when(instance).multiRequest(any(), any(), any());
            doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(
                    instance).queryDeviceData(any(), any(), any());
            emulateMtxResponseSubscription(instance, subscription);
            emulateSubscriptionResponse(instance, subscriptionResponse);
            emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
            emulateMtxResponseMulti_CreditBalances(instance, subscription);
            emulateAocServicePurchase(instance);

            System.out.println(subscriptionResponse.toJson());

            // method to test
            instance.getAOP(input, output);
            System.out.println(output.toJson());

            System.out.println(
                    MessageFormat.format(
                            "{0}Asserting Test {1}{2}", stars, testCase.testNum, stars));

            // Sort in descending order. Higher priority number is earlier in queue.
            Collections.sort(
                    testCase.promoList,
                    (TestCasePromo p1, TestCasePromo p2) -> p2.priority.intValue()
                            - p1.priority.intValue());

            double totalConsumablePromo = 0;
            double totalAvailable = 0;
            for (TestCasePromo promo : testCase.promoList) {
                totalConsumablePromo = promo.consumable;
                totalAvailable = totalAvailable + promo.consumable + promo.grant;
                VisibleCredits outputPromo = output.getCredits().stream().filter(
                        vc -> vc.getCreditRedeemableOfferCI().equalsIgnoreCase(
                                promo.redeemOffer)).findFirst().get();
                assertEquals(
                        promo.grant, outputPromo.getAvailableCreditsGrant().doubleValue(), 0.001);
                assertEquals(
                        promo.consumable, outputPromo.getAvailableCreditsConsumable().doubleValue(),
                        0.001);
                assertEquals(
                        promo.grant + promo.consumable, outputPromo.getAvailableCreditsGrant().add(
                                outputPromo.getAvailableCreditsConsumable()).doubleValue(),
                        0.001);
            }

            BigDecimal totalRedeemable = BigDecimal.ZERO;
            BigDecimal totalTransferable = BigDecimal.ZERO;
            for (VisibleCredits promo : output.getCredits()) {
                totalRedeemable = totalRedeemable.add(promo.getRedeemableCredits());
                totalTransferable = totalTransferable.add(promo.getEstimatedTransferableCredits());
            }

            if (totalConsumablePromo >= (priceMap.get(testCase.baseOffer).doubleValue())) {
                assertEquals(
                        priceMap.get(testCase.baseOffer).doubleValue(),
                        totalRedeemable.doubleValue(), 0.001,
                        "Redeemables should be only consumables. Min. Charge ignore.");
                assertEquals(
                        0, totalTransferable.doubleValue(), 0.001, "Grants should not be useable.");
            } else if (totalConsumablePromo >= (priceMap.get(testCase.baseOffer).doubleValue()
                    - testCase.minimumCharge)) {
                assertTrue(
                        totalRedeemable.doubleValue() >= (priceMap.get(
                                testCase.baseOffer).doubleValue() - testCase.minimumCharge),
                        "Redeemables should be only consumables. Min. Charge ignore.");
                assertEquals(
                        0, totalTransferable.doubleValue(), 0.001, "Grants should not be useable.");
            } else if (totalAvailable >= (priceMap.get(testCase.baseOffer).doubleValue())) {
                assertEquals(
                        priceMap.get(testCase.baseOffer).doubleValue() - testCase.minimumCharge,
                        totalRedeemable.doubleValue(), 0.001,
                        "Redeemables should be subject to minimum charge.");
            } else {
                assertEquals(
                        totalAvailable, totalRedeemable.doubleValue(), 0.001,
                        "Redeemables should not be more than available.");
            }

            BigDecimal actualTotalPayables = output.getEstimatedPayableAmount().add(
                    output.getConsumableMainBalanceAmount());
            BigDecimal expectedTotalPayables = testCase.chargeAmount.add(
                    testCase.hasInsurance ? OFFER_PRICES.INSURANCE : BigDecimal.ZERO).add(
                            testCase.hasWearable ? OFFER_PRICES.WEARABLE : BigDecimal.ZERO);
            for (VisibleCredits promo : output.getCredits()) {
                actualTotalPayables = actualTotalPayables.add(promo.getRedeemableCredits());
            }
            assertEquals(
                    expectedTotalPayables.doubleValue(), actualTotalPayables.doubleValue(), 1.0);
            assertEquals(
                    testCase.mainBalance.doubleValue(),
                    output.getAvailableMainBalanceAmount().doubleValue(), 1.0);

            BigDecimal cashAmount = expectedTotalPayables.subtract(totalRedeemable);
            if (cashAmount.compareTo(output.getAvailableMainBalanceAmount()) > 0) {
                assertEquals(
                        output.getAvailableMainBalanceAmount().doubleValue(),
                        output.getConsumableMainBalanceAmount().doubleValue(), 0.001,
                        "All mainbalance should be used.");
            } else {
                assertEquals(
                        cashAmount.doubleValue(),
                        output.getConsumableMainBalanceAmount().doubleValue(), 0.001,
                        "All cash should be paid using mainbalanced.");
            }
        };
        for (TestCase tc : getTestCases()) {
            pTests.test(tc);
        }
    }

    private List<TestCase> getTestCases() {
        List<TestCase> testList = new ArrayList<TestCase>();
        TestCase tc;

        tc = new TestCase();
        tc.testNum = (new Exception()).getStackTrace()[0].getLineNumber() + "";
        tc.baseOffer = CI_EXTERNAL_IDS.UNLIMITED;
        tc.chargeAmount = OFFER_PRICES.UNLIMITED;
        tc.minimumCharge = 5;
        tc.promoList.add(getNewTestCasePromo(CI_EXTERNAL_IDS.GRANT_GOODWILL, 0, 40));
        testList.add(tc);

        tc = new TestCase();
        tc.testNum = (new Exception()).getStackTrace()[0].getLineNumber() + "";
        tc.baseOffer = CI_EXTERNAL_IDS.UNLIMITED;
        tc.chargeAmount = OFFER_PRICES.UNLIMITED;
        tc.minimumCharge = 5;
        tc.mainBalance = BigDecimal.valueOf(30);
        tc.promoList.add(getNewTestCasePromo(CI_EXTERNAL_IDS.GRANT_GOODWILL, 0, 20));
        tc.promoList.add(getNewTestCasePromo(CI_EXTERNAL_IDS.PARTY_PAY_GRANT, 10, 0));
        tc.promoList.add(getNewTestCasePromo(CI_EXTERNAL_IDS.FIRST25_GRANT, 20, 0));
        testList.add(tc);

        tc = new TestCase();
        tc.testNum = (new Exception()).getStackTrace()[0].getLineNumber() + "";
        tc.baseOffer = CI_EXTERNAL_IDS.UNLIMITED;
        tc.chargeAmount = OFFER_PRICES.UNLIMITED;
        tc.minimumCharge = 5;
        tc.mainBalance = BigDecimal.ZERO;
        tc.promoList.add(getNewTestCasePromo(CI_EXTERNAL_IDS.GRANT_GOODWILL, 5, 45));
        testList.add(tc);

        tc = new TestCase();
        tc.testNum = (new Exception()).getStackTrace()[0].getLineNumber() + "";
        tc.baseOffer = CI_EXTERNAL_IDS.UNLIMITED;
        tc.chargeAmount = OFFER_PRICES.UNLIMITED;
        tc.minimumCharge = 5;
        tc.mainBalance = BigDecimal.valueOf(5);
        tc.promoList.add(getNewTestCasePromo(CI_EXTERNAL_IDS.GRANT_GOODWILL, 5, 0));
        tc.promoList.add(getNewTestCasePromo(CI_EXTERNAL_IDS.PARTY_PAY_GRANT, 5, 0));
        tc.promoList.add(getNewTestCasePromo(CI_EXTERNAL_IDS.FIRST25_GRANT, 5, 0));
        testList.add(tc);

        tc = new TestCase();
        tc.testNum = (new Exception()).getStackTrace()[0].getLineNumber() + "";
        tc.baseOffer = CI_EXTERNAL_IDS.UNLIMITED;
        tc.chargeAmount = OFFER_PRICES.UNLIMITED;
        tc.minimumCharge = 5;
        tc.mainBalance = BigDecimal.valueOf(15);
        tc.promoList.add(getNewTestCasePromo(CI_EXTERNAL_IDS.GRANT_GOODWILL, 20, 0));
        tc.promoList.add(getNewTestCasePromo(CI_EXTERNAL_IDS.PARTY_PAY_GRANT, 15, 0));
        tc.promoList.add(getNewTestCasePromo(CI_EXTERNAL_IDS.FIRST25_GRANT, 5, 0));
        testList.add(tc);

        return testList;
    }

    private TestCasePromo getNewTestCasePromo(String grantOffer, double grant, double consumable) {
        TestCasePromo tcp = new TestCasePromo();
        tcp.grantOffer = grantOffer;
        tcp.grant = grant;
        tcp.consumable = consumable;
        return tcp;
    }

    private class TestCasePromo {

        String grantOffer;
        String redeemOffer;
        public double grant = 0;
        public double consumable = 0;
        public Long priority = -1L;
        public int limit = -1;
    }

    @SuppressWarnings("serial")
    private class TestCase {

        public String testNum;
        public final List<TestCasePromo> promoList = new ArrayList<TestCasePromo>();
        public boolean hasWearable = false;
        public boolean hasInsurance = false;
        public int minimumCharge = -1;
        String baseOffer;
        public BigDecimal chargeAmount = BigDecimal.ZERO;
        public BigDecimal mainBalance = BigDecimal.ZERO;

        public final Map<String, String> grantFileMap = new HashMap<String, String>() {

            {
                // GrantOfferName-->GrantBalanceInfo
                put(
                        "Visible_Grant_Goodwill_Credits",
                        DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Goodwill_Grant.json");
                put(
                        "Visible_REF35_Grant",
                        DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_REF35_Grant.json");
                put(
                        "Visible_FIRST25_Grant", DATA_DIR.PAYMENT_ADVICE
                                + "MtxBalanceInfo_Promo_Discount_Grant_FIRST25.json");
            }
        };
        public final Map<String, String> consumeFileMap = new HashMap<String, String>() {

            {
                // GrantOfferName-->ConsumableBalanceInfo
                put(
                        "Visible_Grant_Goodwill_Credits",
                        DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_Goodwill_Consumable.json");
                put(
                        "Visible_REF35_Grant",
                        DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_REF35_Consumable.json");
                put(
                        "Visible_Group_Grant",
                        DATA_DIR.PAYMENT_ADVICE + "MtxBalanceInfo_PartyPay_Consumable.json");
                put(
                        "Visible_FIRST25_Grant", DATA_DIR.PAYMENT_ADVICE
                                + "MtxBalanceInfo_Promo_Discount_Consumable_FIRST25.json");
            }
        };
        public final Map<String, String> balanceFileMap = new HashMap<String, String>() {

            {
                // GrantBalanceName-->PricingBalance -- To get grant offer name from balance
                // attributes
                put(
                        "Goodwill_Credits_Grant",
                        DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingBalance_GoodwillGrant.json");
                put(
                        "Referral_Credits2_Grant",
                        DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingBalance_REF35Grant.json");
                put(
                        "Promo_Discount_Grant",
                        DATA_DIR.PAYMENT_ADVICE + "MtxResponsePricingBalance_First25Grant.json");
            }
        };
        public final Map<String, String> poFileMap = new HashMap<String, String>() {

            {
                // GrantOfferName-->PurchaseOffer -- for subscription based promos
                put(
                        "Visible_FIRST25_Grant",
                        DATA_DIR.COMMON + "VisiblePurchasedOfferInfo_Visible_FIRST25_Grant.json");
            }
        };

    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getAOP_When_AnnualPlusMonthly_Subscription_Then_CorrectCycleDates()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in annual base offer, monthly addon and insurance offers."
        };
        td.when = new String[] {
            "AOP is called. Recurring charge api provides monthly dates for monthly offers and annual dates for annual offers."
        };
        td.then = new String[] {
            "AOP response should have correct cycle dates."
        };
        td.printDescription();

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        List<String> ciExternalIds = Arrays.asList(
                CI_EXTERNAL_IDS.PLUS2ANNUAL, CI_EXTERNAL_IDS.INSURANCE, CI_EXTERNAL_IDS.WEARABLE);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                "1234", ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                "1234", ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        subscriptionResponse.getBillingCycle().setDateOffset(1L);
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(
                        CI_EXTERNAL_IDS.PLUS2ANNUAL, CI_EXTERNAL_IDS.WEARABLE,
                        CI_EXTERNAL_IDS.INSURANCE));

        emulateAocServicePurchase(instance);
        subscription.getBalanceArrayAppender().clear();
        MtxBalanceInfo biMainBalance = CommonTestHelper.getMtxBalanceInfo(
                BALANCE_NAMES.MAIN_BALANCE, null, null, null);
        subscription.getBalanceArrayAppender().add(biMainBalance);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        System.out.println(subscription.toJson());
        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        // Assertions here.

        VisibleOfferDetails baseVOD = output.getVisibleOfferDetailsList().stream().filter(
                vod -> vod.getCatalogItemExternalId().equals(
                        CI_EXTERNAL_IDS.PLUS2ANNUAL)).findFirst().get();
        VisibleOfferDetails insuranceVOD = output.getVisibleOfferDetailsList().stream().filter(
                vod -> vod.getCatalogItemExternalId().equals(
                        CI_EXTERNAL_IDS.INSURANCE)).findFirst().get();
        VisibleOfferDetails addonVOD = output.getVisibleOfferDetailsList().stream().filter(
                vod -> vod.getCatalogItemExternalId().equals(
                        CI_EXTERNAL_IDS.WEARABLE)).findFirst().get();

        MtxTimestamp monthlyStartDate = subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime();
        MtxTimestamp monthlyEndDate = TestUtils.addOneMonth(
                monthlyStartDate, subscriptionResponse.getTimeZone());

        assertEquals(monthlyStartDate.toString(), insuranceVOD.getCycleStartTime());
        assertEquals(monthlyEndDate.toString(), insuranceVOD.getCycleEndTime());
        assertEquals(monthlyStartDate.toString(), addonVOD.getCycleStartTime());
        assertEquals(monthlyEndDate.toString(), addonVOD.getCycleEndTime());
        MtxTimestamp annualStartDate = null;
        MtxTimestamp annualEndDate = null;

        for (MtxPurchasedOfferInfo mpo : subscriptionResponse.getPurchasedOfferArray()) {
            if (CI_EXTERNAL_IDS.PLUS2ANNUAL.equalsIgnoreCase(mpo.getCatalogItemExternalId())) {
                annualStartDate = mpo.getCycleInfo().getCycleEndTime();
                annualEndDate = TestUtils.addOneYear(
                        annualStartDate, subscriptionResponse.getTimeZone());
            }
        }
        assertEquals(annualStartDate.toString(), baseVOD.getCycleStartTime());
        assertEquals(annualEndDate.toString(), baseVOD.getCycleEndTime());
    }

    @Test
    public void test_getAOP_When_MonthlyPlusPreactiveAnnual_Subscription_Then_CorrectCycleDates()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in annual base offer that is preactive, monthly addon and insurance offers."
        };
        td.when = new String[] {
            "AOP is called. Recurring charge api provides monthly dates for monthly offers and annual dates for annual offers."
        };
        td.then = new String[] {
            "AOP response should have correct cycle dates."
        };

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        List<String> activeCiExternalIds = Arrays.asList(
                CI_EXTERNAL_IDS.INSURANCE, CI_EXTERNAL_IDS.WEARABLE);
        List<String> preactiveCiExternalIds = Arrays.asList(CI_EXTERNAL_IDS.PLUS2ANNUAL);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                "1234", activeCiExternalIds, preactiveCiExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                "1234", activeCiExternalIds, preactiveCiExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        subscriptionResponse.getBillingCycle().setDateOffset(1L);
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(
                        CI_EXTERNAL_IDS.PLUS2ANNUAL, CI_EXTERNAL_IDS.WEARABLE,
                        CI_EXTERNAL_IDS.INSURANCE));

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        System.out.println(subscriptionResponse.toJson());
        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        // Assertions here.

        VisibleOfferDetails baseVOD = output.getVisibleOfferDetailsList().stream().filter(
                vod -> vod.getCatalogItemExternalId().equals(
                        CI_EXTERNAL_IDS.PLUS2ANNUAL)).findFirst().get();
        VisibleOfferDetails insuranceVOD = output.getVisibleOfferDetailsList().stream().filter(
                vod -> vod.getCatalogItemExternalId().equals(
                        CI_EXTERNAL_IDS.INSURANCE)).findFirst().get();
        VisibleOfferDetails addonVOD = output.getVisibleOfferDetailsList().stream().filter(
                vod -> vod.getCatalogItemExternalId().equals(
                        CI_EXTERNAL_IDS.WEARABLE)).findFirst().get();

        MtxTimestamp monthlyStartDate = subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime();
        MtxTimestamp monthlyEndDate = TestUtils.addOneMonth(
                monthlyStartDate, subscriptionResponse.getTimeZone());

        assertEquals(monthlyStartDate.toString(), insuranceVOD.getCycleStartTime());
        assertEquals(monthlyEndDate.toString(), insuranceVOD.getCycleEndTime());
        assertEquals(monthlyStartDate.toString(), addonVOD.getCycleStartTime());
        assertEquals(monthlyEndDate.toString(), addonVOD.getCycleEndTime());
        MtxTimestamp annualStartDate = null;
        MtxTimestamp annualEndDate = null;
        for (MtxPurchasedOfferInfo mpo : subscriptionResponse.getPurchasedOfferArray()) {
            if (CI_EXTERNAL_IDS.PLUS2ANNUAL.equalsIgnoreCase(mpo.getCatalogItemExternalId())) {
                annualStartDate = mpo.getAutoActivationTime();
                System.out.println(annualStartDate);
                annualEndDate = TestUtils.addOneYear(
                        annualStartDate, subscriptionResponse.getTimeZone());
            }
        }
        assertEquals(annualStartDate.toString(), baseVOD.getCycleStartTime());
        assertEquals(annualEndDate.toString(), baseVOD.getCycleEndTime());
    }

    @ParameterizedTest(
            name = "When_MonthlyPlusPreactiveMonthly_Subscription_Then_CorrectCycleDates")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given | Subscriber is enrolled in monthly base offer that is preactive, monthly addon and insurance offers.|"
                +"|When  | AOP is called. Recurring charge api provides monthly dates for monthly offers.|"
                +"|Then  | AOP response should have correct cycle dates.|"})
    public void test_getAOP_When_MonthlyPlusPreactiveMonthly_Subscription_Then_CorrectCycleDates(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        List<String> activeCiExternalIds = Arrays.asList(CI_EXTERNAL_IDS.WEARABLE);
        List<String> preactiveCiExternalIds = Arrays.asList(CI_EXTERNAL_IDS.BASE_CURRENT);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                "123", activeCiExternalIds, preactiveCiExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                "123", activeCiExternalIds, preactiveCiExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());

        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(
                instance, Arrays.asList(CI_EXTERNAL_IDS.BASE_CURRENT, CI_EXTERNAL_IDS.WEARABLE));

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        // method to test
        instance.getAOP(input, output);
        System.out.println(testInfo.getDisplayName() + ":" + output.toJson());
        // Assertions here.

        VisibleOfferDetails baseVOD = output.getVisibleOfferDetailsList().stream().filter(
                vod -> vod.getCatalogItemExternalId().equals(
                        CI_EXTERNAL_IDS.BASE_CURRENT)).findFirst().get();
        VisibleOfferDetails addonVOD = output.getVisibleOfferDetailsList().stream().filter(
                vod -> vod.getCatalogItemExternalId().equals(
                        CI_EXTERNAL_IDS.WEARABLE)).findFirst().get();
        
        MtxTimestamp monthlyStartDate = subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime();
        MtxTimestamp monthlyEndDate = TestUtils.addOneMonth(monthlyStartDate, subscriptionResponse.getTimeZone());
        assertEquals(monthlyStartDate.toString(), addonVOD.getCycleStartTime());
        assertEquals(monthlyEndDate.toString(), addonVOD.getCycleEndTime());
        assertEquals(subscriptionResponse.getAtPurchasedOfferArray(1).getAutoActivationTime().toString(), baseVOD.getCycleStartTime());
        assertEquals(monthlyEndDate.toString(), baseVOD.getCycleEndTime());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_getAOP_When_Subscription_HasGift_Then_FixedFeeNotPayable(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in annual base offer that is preactive.", "Has gift amount.",
            "Subscribers tax geocode is subject to fixed fee."
        };
        td.when = new String[] {
            "AOP is called. Taxapi provides fixedfee."
        };
        td.then = new String[] {
            "AOP response should show no payable amount."
        };
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        String giftGrantCi = CI_EXTERNAL_IDS.GIFT_GRANT;
        List<String> preactiveCiExternalIds = Arrays.asList(CI_EXTERNAL_IDS.BASE2ANNUAL);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                "123", null, preactiveCiExternalIds);
        subscription.getBalanceArrayAppender().clear();

        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                null, preactiveCiExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getEmptyMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(
                instance, Arrays.asList(CI_EXTERNAL_IDS.BASE2ANNUAL, giftGrantCi));

        PurchasedOfferInfo poiGiftGrant = CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, giftGrantCi);
        subscriptionResponse.getPurchasedOfferArrayAppender().add(poiGiftGrant);

        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, giftGrantCi, null, BigDecimal.valueOf(150), BigDecimal.valueOf(300));

        MtxBalanceInfo biMainBalance = CommonTestHelper.getMtxBalanceInfo(
                BALANCE_NAMES.MAIN_BALANCE, 1L, 2L, null);
        subscription.getBalanceArrayAppender().add(biMainBalance);

        System.out.println(testInfo.getDisplayName() + ": " + subscription.toJson());

        List<String> balPriList = Arrays.asList(BALANCE_NAMES.GIFT_GRANT);
        emulateMtxResponseMultiFromObject(
                instance, CommonTestHelper.getMtxResponsePricingBalances(balPriList));
        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        String taxRespString = CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.BASE2ANNUAL);

        // method to test
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            ObjectMapper om = TestUtils.getObjectMapper();
            ServiceTaxResponse resp = om.readValue(taxRespString, ServiceTaxResponse.class);
            resp.getTransactionElement().get(0).setTotalFeeAmount(BigDecimal.valueOf(1.81));
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), anyString())).thenReturn(
                            resp.toJson());
            // method to test
            instance.getAOP(input, output);
        }
        System.out.println(testInfo.getDisplayName() + ": " + output.toJson());
        assertEquals(0, output.getEstimatedPayableAmount().doubleValue(), 0.001);
        assertEquals(0, output.getTotalEstimatedAmount().doubleValue(), 0.001);
        assertEquals(
                0, output.getAtVisibleOfferDetailsList(0).getPayableAmount().doubleValue(), 0.001);
    }

    @Test
    public void test_getAOP_When_NotInLastMonth_Then_ZeroForAnnualOffer() throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in annual plus offer.",
            "Today is NOT in Last month of annual service."
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "AOP response should return zero payable amount for annual offer."
        };
        td.printDescription();
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.PLUS2ANNUAL);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                "1234", ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                "1234", ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());

        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.PLUS2ANNUAL));

        emulateAocServicePurchase(instance);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscriptionResponse.getExternalId() + "]").when(instance).getLoggingKey(
                any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateAocServicePurchase(instance);

        System.out.println(subscriptionResponse.toJson());

        String taxApiResp = CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.PLUS2ANNUAL);

        // method to test
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(
                             any(), argumentCaptor.capture())).thenReturn(taxApiResp);
            // method to test
            instance.getAOP(input, output);
        }

        System.out.println(output.toJson());

        // Assertions here
        VisibleOfferDetails baseVOD = output.getVisibleOfferDetailsList().stream().filter(
                vod -> vod.getCatalogItemExternalId().equals(
                        CI_EXTERNAL_IDS.PLUS2ANNUAL)).findFirst().get();
        assertEquals(0, baseVOD.getPayableAmount().intValue());
    }

    @Test
    public void test_getAOP_When_NotInLastMonth_Then_NoTaxesForAnnualOffer() throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in annual plus offer.",
            "Today is NOT in Last month of annual service."
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "AOP response should not return any taxes for annual offer."
        };
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.PLUS2ANNUAL);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                "1234", ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                "1234", ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());

        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.PLUS2ANNUAL));

        emulateAocServicePurchase(instance);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscriptionResponse.getExternalId() + "]").when(instance).getLoggingKey(
                any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateAocServicePurchase(instance);

        System.out.println(subscriptionResponse.toJson());

        String taxApiResp = CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.PLUS2ANNUAL);

        // method to test
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(
                             any(), argumentCaptor.capture())).thenReturn(taxApiResp);
            // method to test
            instance.getAOP(input, output);
        }

        System.out.println(output.toJson());

        // Assertions here
        VisibleOfferDetails baseVOD = output.getVisibleOfferDetailsList().stream().filter(
                vod -> vod.getCatalogItemExternalId().equals(
                        CI_EXTERNAL_IDS.PLUS2ANNUAL)).findFirst().get();
        assertTrue(StringUtils.isBlank(baseVOD.getTaxDetails()));

    }

    @Test
    public void test_getAOP_When_InLastMonth_Then_AnnualOfferWithPayment() throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in annual plus offer.",
            "Today is in Last month of annual service."
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "AOP response should return corerect payable amount for annual offer."
        };
        td.printDescription();

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.PLUS2ANNUAL);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                "1234", ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                "1234", ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());

        MtxTimestamp earlyEndDate = TestUtils.getFirstDateTimeOfNextMonth();
        for (MtxPurchasedOfferInfo mpo : subscriptionResponse.getPurchasedOfferArray()) {
            if (CI_EXTERNAL_IDS.PLUS2ANNUAL.equalsIgnoreCase(mpo.getCatalogItemExternalId())) {
                mpo.getCycleInfo().setCycleEndTime(earlyEndDate);
            }
        }

        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        chargeInfo.getBalanceImpactGroupList().forEach(big -> {
            big.setCycleEndTime(earlyEndDate);
        });
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.PLUS2ANNUAL));

        emulateAocServicePurchase(instance);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscriptionResponse.getExternalId() + "]").when(instance).getLoggingKey(
                any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateAocServicePurchase(instance);

        System.out.println(subscriptionResponse.toJson());

        String taxApiResp = CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.PLUS2ANNUAL);

        // method to test
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(
                             any(), argumentCaptor.capture())).thenReturn(taxApiResp);
            // method to test
            instance.getAOP(input, output);
        }

        System.out.println(output.toJson());

        // Assertions here
        VisibleOfferDetails baseVOD = output.getVisibleOfferDetailsList().stream().filter(
                vod -> vod.getCatalogItemExternalId().equals(
                        CI_EXTERNAL_IDS.PLUS2ANNUAL)).findFirst().get();
        assertEquals(OFFER_PRICES.PLUS2ANNUAL.intValue(), baseVOD.getPayableAmount().intValue());
    }
    
    @ParameterizedTest(name="When_InLastMonth_Then_TaxesForAnnualOffer")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given | Subscriber is enrolled in annual plus offer.|"
                +"|      | Today is in Last month of annual service.|"
                +"|When  | AOP is called|"
                +"|Then  | AOP response should return any taxes for annual offer.|"})
    // @formatter:on
    public void test_getAOP_When_InLastMonth_Then_TaxesForAnnualOffer(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");
        input.setSubscriberExternalId("1234");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.PLUS2ANNUAL);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                input.getSubscriberExternalId(), ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                input.getSubscriberExternalId(), ciExternalIds);

        MtxTimestamp earlyEndDate = TestUtils.getFirstDateTimeOfNextMonth(
                subscriptionResponse.getTimeZone());
        for (MtxPurchasedOfferInfo mpo : subscriptionResponse.getPurchasedOfferArray()) {
            if (CI_EXTERNAL_IDS.PLUS2ANNUAL.equalsIgnoreCase(mpo.getCatalogItemExternalId())) {
                mpo.getCycleInfo().setCycleEndTime(earlyEndDate);
            }
        }

        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        System.out.println("subscriptionResponse: " + subscriptionResponse.toJson());
        chargeInfo.getBalanceImpactGroupList().forEach(big -> {
            big.setCycleEndTime(earlyEndDate);
        });
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.PLUS2ANNUAL));

        emulateAocServicePurchase(instance);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscriptionResponse.getExternalId() + "]").when(instance).getLoggingKey(
                any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateAocServicePurchase(instance);

        System.out.println(subscriptionResponse.toJson());

        String taxApiResp = CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.PLUS2ANNUAL);

        // method to test
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxApiResp);
            // method to test
            instance.getAOP(input, output);
        }

        System.out.println(output.toJson());

        // Assertions here
        VisibleOfferDetails baseVOD = output.getVisibleOfferDetailsList().stream().filter(
                vod -> vod.getCatalogItemExternalId().equals(
                        CI_EXTERNAL_IDS.PLUS2ANNUAL)).findFirst().get();
        assertTrue(StringUtils.isNotBlank(baseVOD.getTaxDetails()));
    }

    @Test
    public void test_getAOP_When_AnnualNotInLastMonth_WearablesPresent_Then_ZeroForAnnualOffer()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in annual plus offer.",
            "Today is NOT in Last month of annual service.", "Subscriber has wearables alse"
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "AOP response should return correct payable amount for wearables."
        };
        td.printDescription();
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        List<String> ciExternalIds = Arrays.asList(
                CI_EXTERNAL_IDS.PLUS2ANNUAL, CI_EXTERNAL_IDS.WEARABLE);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                "1234", ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                "1234", ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(
                instance, Arrays.asList(CI_EXTERNAL_IDS.PLUS2ANNUAL, CI_EXTERNAL_IDS.WEARABLE));

        emulateAocServicePurchase(instance);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        System.out.println(subscription.toJson());
        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        // Assertions here.

        VisibleOfferDetails baseVOD = output.getVisibleOfferDetailsList().stream().filter(
                vod -> vod.getCatalogItemExternalId().equals(
                        CI_EXTERNAL_IDS.PLUS2ANNUAL)).findFirst().get();
        assertEquals(0, baseVOD.getPayableAmount().intValue());
    }

    @Test
    public void test_getAOP_When_AnnualNotInLastMonth_WearablesPresent_Then_NoTaxesForAnnualOffer()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in annual plus offer.",
            "Today is NOT in Last month of annual service.", "Subscriber has wearables alse"
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "AOP response should not correct taxes for wearables."
        };
        td.printDescription();
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");

        List<String> ciExternalIds = Arrays.asList(
                CI_EXTERNAL_IDS.PLUS2ANNUAL, CI_EXTERNAL_IDS.WEARABLE);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                "1234", ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                "1234", ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(
                instance, Arrays.asList(CI_EXTERNAL_IDS.PLUS2ANNUAL, CI_EXTERNAL_IDS.WEARABLE));

        emulateAocServicePurchase(instance);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        System.out.println(subscription.toJson());

        String taxApiResp = CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.PLUS2ANNUAL);

        // method to test
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxApiResp);
            // method to test
            instance.getAOP(input, output);
        }

        System.out.println(output.toJson());

        // Assertions here.
        VisibleOfferDetails baseVOD = output.getVisibleOfferDetailsList().stream().filter(
                vod -> vod.getCatalogItemExternalId().equals(
                        CI_EXTERNAL_IDS.PLUS2ANNUAL)).findFirst().get();
        assertTrue(StringUtils.isBlank(baseVOD.getTaxDetails()));
    }

    @Test
    public void test_getAOP_When_TwoInsurances_Then_AdviceTwoInsurances() throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in two instances of insurance."
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "AOP response should show both insurances."
        };
        td.printDescription();
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        List<String> ciExternalIds = Arrays.asList(
                CI_EXTERNAL_IDS.INSURANCE, CI_EXTERNAL_IDS.INSURANCE);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                "1234", ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                "1234", ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.INSURANCE));

        emulateAocServicePurchase(instance);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        System.out.println(subscription.toJson());

        String taxApiResp = CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.INSURANCE);

        // method to test
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxApiResp);
            // method to test
            instance.getAOP(input, output);
        }

        System.out.println(output.toJson());

        // Assertions here.
        long insuranceCount = output.getVisibleOfferDetailsList().stream().filter(
                vod -> vod.getCatalogItemExternalId().equals(CI_EXTERNAL_IDS.INSURANCE)).count();
        assertEquals(2, insuranceCount);
    }

    @Test
    public void test_getAOP_When_OneActiveInsurance_OneInactiveInsurance_Then_AdviceActiveOnly()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in two instances of insurance.", "Only one instance is active."
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "AOP response should show active insurance only."
        };
        td.printDescription();
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.INSURANCE);
        List<String> inactiveCiExternalIds = Arrays.asList(CI_EXTERNAL_IDS.INSURANCE);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                input.getSubscriberExternalId(), ciExternalIds, null, inactiveCiExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.INSURANCE));

        emulateAocServicePurchase(instance);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        System.out.println(subscription.toJson());

        String taxApiResp = CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.INSURANCE);

        // method to test
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxApiResp);
            // method to test
            instance.getAOP(input, output);
        }

        System.out.println(output.toJson());

        // Assertions here.
        long insuranceCount = output.getVisibleOfferDetailsList().stream().filter(
                vod -> vod.getCatalogItemExternalId().equals(CI_EXTERNAL_IDS.INSURANCE)).count();
        assertEquals(1, insuranceCount);
    }

    @Test()
    @Tag("VER-143")
    public void test_getAOP_When_ApplicableCi_Override_Then_CorrectPromoAssociate(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscriber is enrolled in PlusMonthly.",
            "Subscription based promo has been ApplicableCi overwritten"
        };
        td.when = new String[] {
            "PaymentAdvice is called."
        };
        td.then = new String[] {
            "Response should show promo only if PlusMonthly is final ApplicableCi."
        };

        OneParameterTest pTests = (condition) -> {
            td.printDescription();
            VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
            input.setIncludeTaxDetails("N");

            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.PLUS_CURRENT);
            MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                    ciExternalIds);
            SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                    ciExternalIds);
            input.setSubscriberExternalId(subscriptionResponse.getExternalId());
            MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                    subscriptionResponse);
            emulateMtxResponsePricingCatalogItems(
                    instance, Arrays.asList(
                            CI_EXTERNAL_IDS.PLUS_CURRENT, CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT));

            MtxPurchasedOfferInfo po15OFFN = CommonTestHelper.getMtxPurchasedOfferInfo(
                    subscription, CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT, null, BigDecimal.valueOf(300),
                    null);
            if ("configured-not-enrolled-offer".equalsIgnoreCase(condition.toString())) {
                ((VisiblePurchasedOfferExtension) po15OFFN.getAttr()).setApplicableOfferName(
                        CI_EXTERNAL_IDS.BASE_CURRENT);
            } else if ("not-configured-offer".equalsIgnoreCase(condition.toString())) {
                ((VisiblePurchasedOfferExtension) po15OFFN.getAttr()).setApplicableOfferName("XYZ");
            } else {
                ((VisiblePurchasedOfferExtension) po15OFFN.getAttr()).setApplicableOfferName(
                        CI_EXTERNAL_IDS.PLUS_CURRENT);
            }

            VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

            // mocks
            doReturn("").when(instance).getRoute(any());
            doReturn(null).when(instance).queryDeviceData(any(), any(), any());
            doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
            doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
            doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(
                    instance).queryDeviceData(any(), any(), any());
            emulateMtxResponseSubscription(instance, subscription);
            emulateSubscriptionResponse(instance, subscriptionResponse);
            emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
            emulateMtxResponseMulti_CreditBalances(instance, subscription);
            emulateAocServicePurchase(instance);

            // method to test
            instance.getAOP(input, output);
            System.out.println(output.toJson());
            // Assertions If group credit is 15 and referral is zero then incompatibility was parsed
            // correctly
            if ("configured-not-enrolled-offer".equalsIgnoreCase(condition.toString())) {
                assertTrue(output.getCredits() == null);
            } else {
                assertTrue(output.getCredits() != null);
                assertEquals(
                        CI_EXTERNAL_IDS.PLUS_CURRENT, output.getAtCredits(0).getApplicableCI());
            }
        };

        pTests.test("configured-active-offer");
        pTests.test("configured-not-enrolled-offer");
        pTests.test("not-configured-offer");
    }

    @Test
    @Tag("VER-284")
    public void test_getAOP_When_SubscriberHasPreActiveOffer_Then_CorrectChargeAmount()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in Plus22 that end dates this cycle.",
            "Has downgraded to Base22 that starts next cycle."
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "AOP provides preactive offer in response with chargeamount equal to discount price."
        };
        td.comments = new String[] {
            "MTXVERMA-58", "VER-284", ""
        };
        td.printDescription();
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        List<String> preActiveList = Arrays.asList(CI_EXTERNAL_IDS.BASE3VIS23);
        List<String> enddatedList = Arrays.asList(CI_EXTERNAL_IDS.PLUS3VIS23);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                "1234", null, preActiveList, null, enddatedList);
        subscription.getPurchasedOfferArray().forEach(mpoi -> {
            if (CI_EXTERNAL_IDS.PLUS3VIS23.equals(mpoi.getCatalogItemExternalId())) {
                mpoi.setEndTime(TestUtils.getFirstDateTimeOfNextMonth());
            }
        });

        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                "1234", null, preActiveList, null, enddatedList);
        ;
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        PurchasedOfferInfo poiBase22 = null;
        for (MtxPurchasedOfferInfo poi : subscriptionResponse.getPurchasedOfferArray()) {
            if (CI_EXTERNAL_IDS.PLUS3VIS23.equals(poi.getCatalogItemExternalId())) {
                poi.setEndTime(TestUtils.getFirstDateTimeOfNextMonth());
            }
            if (CI_EXTERNAL_IDS.BASE3VIS23.equals(poi.getCatalogItemExternalId())) {
                poiBase22 = (PurchasedOfferInfo) poi;
            }
        }
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(
                instance, Arrays.asList(CI_EXTERNAL_IDS.PLUS3VIS23, CI_EXTERNAL_IDS.BASE3VIS23));

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        assertEquals(
                ((VisiblePurchasedOfferExtension) poiBase22.getAttr()).getChargeAmount().intValue(),
                output.getVisibleOfferDetailsList().stream().filter(
                        vc -> vc.getCatalogItemExternalId().equalsIgnoreCase(
                                CI_EXTERNAL_IDS.BASE3VIS23)).findFirst().get().getChargeAmount().intValue());
    }

    @SuppressWarnings("unchecked")
    @Test
    @Tag("VER-297")
    public void test_getAOP_When_SubscriberHasActiveOffer_Then_CorrectChargeAmount()
            throws Exception {
        TestDescription td = new TestDescription();
        td.given = new String[] {
            "Subscriber is enrolled in Plus22 that is active now and will be active next cycle."
        };
        td.when = new String[] {
            "AOP is called"
        };
        td.then = new String[] {
            "AOP provides preactive offer in response with chargeamount equal to discount price."
        };
        td.comments = new String[] {
            "VER-297", ""
        };
        td.printDescription();
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription();
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getEmptySubscriptionResponse();
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        String baseOffer = CI_EXTERNAL_IDS.PLUS_CURRENT;
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList());

        subscription.getPurchasedOfferArrayAppender().clear();
        CommonTestHelper.getMtxPurchasedOfferInfo(subscription, baseOffer);

        CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, baseOffer);

        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        chargeInfo.getAtBalanceImpactGroupList(0).getAtBalanceImpactList(
                0).getAtBalanceImpactOfferList(0).getAtBalanceImpactUpdateList(0).setAmount(
                        BigDecimal.valueOf(35));
        chargeInfo.getAtBalanceImpactGroupList(0).getAtBalanceImpactList(
                0).getAtBalanceImpactOfferList(0).getAtBalanceImpactUpdateList(
                        0).setNonProratedAmount(BigDecimal.ZERO);
        chargeInfo.getAtBalanceImpactGroupList(0).getAtBalanceImpactList(0).setImpactAmount(
                BigDecimal.valueOf(35));

        MtxResponseRecurringChargeInfo chargeInfoDummy = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        chargeInfoDummy.getAtBalanceImpactGroupList(0).getAtBalanceImpactList(
                0).getAtBalanceImpactOfferList(0).getAtBalanceImpactUpdateList(0).setAmount(
                        BigDecimal.TEN);
        chargeInfoDummy.getAtBalanceImpactGroupList(0).getAtBalanceImpactList(
                0).getAtBalanceImpactOfferList(0).getAtBalanceImpactUpdateList(
                        0).setNonProratedAmount(BigDecimal.ZERO);
        chargeInfoDummy.getAtBalanceImpactGroupList(0).getAtBalanceImpactList(0).setImpactAmount(
                BigDecimal.TEN);
        chargeInfoDummy.getAtBalanceImpactGroupList(0).getAtBalanceImpactList(
                0).setBalanceResourceId(
                        chargeInfo.getAtBalanceImpactGroupList(0).getAtBalanceImpactList(
                                0).getBalanceResourceId() + 1);
        chargeInfoDummy.getAtBalanceImpactGroupList(0).getAtBalanceImpactList(
                0).setBalanceTemplateName("2535PLUS_Consumable");

        chargeInfo.getAtBalanceImpactGroupList(0).getBalanceImpactListAppender().add(
                chargeInfoDummy.getAtBalanceImpactGroupList(0).getAtBalanceImpactList(0));

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        // doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        assertEquals(45, output.getAtVisibleOfferDetailsList(0).getChargeAmount().intValue());
    }

    @Test
    @Disabled
    @Tag("VER-261")
    public void test_getAop_When_MultiMonthOnly_Then_CorrectCycleDates(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscriber is enrolled in Multimonth."
        };
        td.when = new String[] {
            "PaymentAdvice is called."
        };
        td.then = new String[] {
            "Response should show multimonth dates for multimonth service.",
            "Response should show dates at the top level as per wallet.",
        };
        Assertions.fail();
    }

    @Test
    @Disabled
    @Tag("VER-261")
    public void test_getAop_When_MultiMonthOnly_Preactive_Then_CorrectCycleDates(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscriber is enrolled in Multimonth.",
            "Enrolled multimonth service is in preactive status"
        };
        td.when = new String[] {
            "PaymentAdvice is called."
        };
        td.then = new String[] {
            "Response should show multimonth dates for multimonth service.",
            "Response should monthly dates at the top level as per wallet.",
        };
        Assertions.fail();
    }

    @SuppressWarnings("unchecked")
    @Test
    @Tag("VER-332")
    public void test_getAOP_When_BalanceIsNegative_Then_ConsumableMainBalanceIsZero()
            throws Exception {
        mockSubscriberGroup(instance, null);
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        List<String> ciExternalIds = Arrays.asList(
                CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.INSURANCE);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(
                        CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.GRANT_GOODWILL,
                        CI_EXTERNAL_IDS.INSURANCE));
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        BalanceInfo mainBalanceWallet = CommonTestHelper.getBalanceInfo(
                BALANCE_NAMES.MAIN_BALANCE, null, null, BigDecimal.valueOf(-2000));
        subscriptionResponse.getWalletBalancesAppender().add(mainBalanceWallet);

        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        MtxResponsePurchase aocRespGroupVBPP = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.PAYMENT_ADVICE + "MtxResponsePurchase.json");
        aocRespGroupVBPP.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                0).getBalanceImpactList().forEach(bi -> {
                    // Set all amounts to zero
                    bi.setImpactAmount(BigDecimal.ZERO);
                    bi.getBalanceImpactOfferList().forEach(bioiVbpp -> {
                        bioiVbpp.getBalanceImpactUpdateList().forEach(biui -> {
                            biui.setAmount(BigDecimal.ZERO);
                        });
                    });
                });

        doReturn(aocRespGroupVBPP).when(instance).doSubscriberPurchaseOfferAOC(
                any(), eq(CI_EXTERNAL_IDS.VBPP25_AOC_REDEEM), any(), any());

        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
        String taxApiResp = CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.UNLIMITED);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxApiResp);
            // method to test
            instance.getAOP(input, output);
        }
        System.out.println(output.toJson());
        argumentCaptor.getAllValues().forEach(req -> {
            System.out.println(req);
        });

        assertEquals(0, output.getConsumableMainBalanceAmount().intValue());

    }

    @SuppressWarnings("unchecked")
    @Test
    @Tag("VER-332")
    public void test_getAOP_When_BalanceIsNegative_Then_CorrectPayableAmountBeDisplayed()
            throws Exception {
        mockSubscriberGroup(instance, null);
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        List<String> ciExternalIds = Arrays.asList(
                CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.INSURANCE);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                "1234", ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                "1234", ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(
                        CI_EXTERNAL_IDS.UNLIMITED, CI_EXTERNAL_IDS.GRANT_GOODWILL,
                        CI_EXTERNAL_IDS.INSURANCE));
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        BalanceInfo mainBalanceWallet = CommonTestHelper.getBalanceInfo(
                BALANCE_NAMES.MAIN_BALANCE, null, null, BigDecimal.valueOf(-2000));
        subscriptionResponse.getWalletBalancesAppender().add(mainBalanceWallet);

        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        MtxResponsePurchase aocRespGroupVBPP = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.PAYMENT_ADVICE + "MtxResponsePurchase.json");
        aocRespGroupVBPP.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(
                0).getBalanceImpactList().forEach(bi -> {
                    // Set all amounts to zero
                    bi.setImpactAmount(BigDecimal.ZERO);
                    bi.getBalanceImpactOfferList().forEach(bioiVbpp -> {
                        bioiVbpp.getBalanceImpactUpdateList().forEach(biui -> {
                            biui.setAmount(BigDecimal.ZERO);
                        });
                    });
                });

        doReturn(aocRespGroupVBPP).when(instance).doSubscriberPurchaseOfferAOC(
                any(), eq(CI_EXTERNAL_IDS.VBPP25_AOC_REDEEM), any(), any());

        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
        String taxApiResp = CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.UNLIMITED);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxApiResp);
            // method to test
            instance.getAOP(input, output);
        }
        System.out.println(output.toJson());
        argumentCaptor.getAllValues().forEach(req -> {
            System.out.println(req);
        });

        assertEquals(
                output.getAvailableMainBalanceAmount().abs().add(
                        output.getTotalEstimatedAmount()).intValue(),
                output.getEstimatedPayableAmount().intValue());
    }

    @Test
    @Tag("VER-449")
    public void test_getAOP_When_ZeroDollarOfferOnly_Then_OfferInAdvice(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscriber is enrolled in zero-dollar offer only."
        };
        td.when = new String[] {
            "PaymentAdvice is called."
        };
        td.then = new String[] {
            "Zero dollar offer is in response."
        };

        mockSubscriberGroup(instance, null);
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        List<String> ciExternalIds = Arrays.asList(
                CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);

        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        emulateMtxResponsePricingCatalogItems(
                instance, Arrays.asList(CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION));
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        assertEquals(
                CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION,
                output.getVisibleOfferDetailsList().get(0).getCatalogItemExternalId());
    }

    @Test
    @Tag("VER-449")
    public void test_getAOP_When_ZeroDollarOfferAlso_Then_OfferInAdvice(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscriber is enrolled in zero-dollar offer and other offers."
        };
        td.when = new String[] {
            "PaymentAdvice is called."
        };
        td.then = new String[] {
            "Zero dollar offer is in response."
        };

        mockSubscriberGroup(instance, null);
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        List<String> ciExternalIds = Arrays.asList(
                CI_EXTERNAL_IDS.PLUS3VIS23, CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);

        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(
                        CI_EXTERNAL_IDS.PLUS3VIS23,
                        CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION));
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        String taxApiResp = CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.PLUS3VIS23);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), any())).thenReturn(
                    taxApiResp);
            // method to test
            instance.getAOP(input, output);
        }
        System.out.println(output.toJson());

        boolean foundOffer = false;
        for (VisibleOfferDetails vod : output.getVisibleOfferDetailsList()) {
            if (CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION.equals(
                    vod.getCatalogItemExternalId())) {
                foundOffer = true;
                break;
            }
        }
        assertEquals(true, foundOffer);
    }

    @Test
    @Tags({
        @Tag("VER-449"), @Tag("VER-549")
    })
    public void test_getAOP_When_ZeroDollarOfferAlso_Then_NoTaxesForZeroDollarOffer(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscriber is enrolled in zero-dollar offer and other offers."
        };
        td.when = new String[] {
            "PaymentAdvice is called."
        };
        td.then = new String[] {
            "Zero dollar offer should have taxes as per pricing.", "GLDate should be changed.",
            "Geocode should be changed."
        };

        mockSubscriberGroup(instance, null);
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        List<String> ciExternalIds = Arrays.asList(
                CI_EXTERNAL_IDS.PLUS3VIS23, CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);

        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        Map<String, MtxResponsePricingCatalogItem> pciMap = emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(
                        CI_EXTERNAL_IDS.PLUS3VIS23,
                        CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION));
        MtxResponsePricingCatalogItem pciZero = pciMap.get(
                CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION);
        String zeroTaxResp = "";
        for (MtxPricingMetadataInfo metadata : pciZero.getCatalogItemInfo().getMetadataList()) {
            if (metadata.getName().equalsIgnoreCase(CI_METADATA.ZERO_TAX_RESPONSE)) {
                zeroTaxResp = metadata.getValue();
                break;
            }
        }
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());

        String taxApiResp = CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.PLUS3VIS23);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), any())).thenReturn(
                    taxApiResp);
            // method to test
            instance.getAOP(input, output);
        }
        System.out.println(output.toJson());

        VisibleOfferDetails vod = null;
        String actualGeoCode = "";
        String actualGlDate = "";
        String expectedGlDate = CommonUtils.getDateYYYYMMDDasHiphenString(
                subscriptionResponse.getTimeZone());
        VisibleSubscriberExtension attr = (VisibleSubscriberExtension) subscriptionResponse.getAttr();
        for (VisibleOfferDetails vod1 : output.getVisibleOfferDetailsList()) {
            if (CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION.equals(
                    vod1.getCatalogItemExternalId())) {
                vod = vod1;
                ServiceTaxResponse taxResp = CommonUtils.getServiceTaxResponseFromJsonString(
                        vod.getTaxDetails());
                actualGeoCode = taxResp.getGeocode();
                actualGlDate = taxResp.getGlDate();
                break;
            }
        }
        if (StringUtils.isNotBlank(zeroTaxResp)) {
            assertFalse(StringUtils.isBlank(vod.getTaxDetails()));
            assertEquals(attr.getGeoCode(), actualGeoCode);
            assertEquals(expectedGlDate, actualGlDate);
        } else {
            assertTrue(StringUtils.isBlank(vod.getTaxDetails()));
        }
    }

    @Test
    @Tag("VER-449")
    public void test_getAOP_When_subscriptionPromosAvailable_Then_PromosNotReportedAsOffers(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscriber is enrolled in zero-dollar offer and other offers."
        };
        td.when = new String[] {
            "PaymentAdvice is called. "
        };
        td.then = new String[] {
            "Promo offer should not show up as service offer in response."
        };
        mockSubscriberGroup(instance, null);
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        List<String> ciExternalIds = Arrays.asList(
                CI_EXTERNAL_IDS.PLUS3VIS23, CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        CommonTestHelper.getMtxPurchasedOfferInfo(
                subscription, CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT, null, BigDecimal.valueOf(300),
                null);

        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                subscriptionResponse, CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT, BigDecimal.valueOf(300),
                null, false);

        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(
                        CI_EXTERNAL_IDS.PLUS3VIS23,
                        CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION,
                        CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT));
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());

        String taxApiResp = CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.PLUS3VIS23);
        System.out.println(subscriptionResponse.toJson());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), any())).thenReturn(
                    taxApiResp);
            // method to test
            instance.getAOP(input, output);
        }
        System.out.println(output.toJson());

        boolean foundPromo = false;
        for (VisibleOfferDetails vod1 : output.getVisibleOfferDetailsList()) {
            if (CI_EXTERNAL_IDS.FIFTEEN_OFFN_GRANT.equals(vod1.getCatalogItemExternalId())) {
                foundPromo = true;
                break;
            }
        }
        assertFalse(foundPromo);
    }

    @Test
    @Tag("VER-449")
    public void test_getAOP_When_setupServicesAvailable_Then_setupservicesNotInResponse(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscriber is enrolled in setup services."
        };
        td.when = new String[] {
            "PaymentAdvice is called. "
        };
        td.then = new String[] {
            "setupservices should not show up as service offer in response."
        };

        mockSubscriberGroup(instance, null);
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        List<String> ciExternalIds = Arrays.asList(
                CI_EXTERNAL_IDS.SETUP_SERVICES, CI_EXTERNAL_IDS.PLUS3VIS23,
                CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(
                        CI_EXTERNAL_IDS.PLUS3VIS23,
                        CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION,
                        CI_EXTERNAL_IDS.SETUP_SERVICES));
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());

        String taxApiResp = CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.PLUS3VIS23);
        System.out.println(subscriptionResponse.toJson());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), any())).thenReturn(
                    taxApiResp);
            // method to test
            instance.getAOP(input, output);
        }
        System.out.println(output.toJson());

        boolean foundSetup = false;
        for (VisibleOfferDetails vod1 : output.getVisibleOfferDetailsList()) {
            if (CI_EXTERNAL_IDS.SETUP_SERVICES.equals(vod1.getCatalogItemExternalId())) {
                foundSetup = true;
                break;
            }
        }
        assertFalse(foundSetup);
    }

    @Test
    @Tag("VER-471")
    public void test_getAOP_When_offerEndsBeforeNextCycle_Then_OfferNotInResponse(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscriber is enrolled in free wearableactivation offer that will not be available next cycle."
        };
        td.when = new String[] {
            "PaymentAdvice is called. "
        };
        td.then = new String[] {
            "Free wearable activation should not show up as service offer in response."
        };

        boolean expectedFree = true;
        mockSubscriberGroup(instance, null);
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        List<String> preActiveList = Arrays.asList(
                CI_EXTERNAL_IDS.SETUP_SERVICES, CI_EXTERNAL_IDS.BASE3VIS23,
                CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023);
        List<String> enddatedList = Arrays.asList(
                CI_EXTERNAL_IDS.PLUS3VIS23, CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION);

        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                "1234", null, preActiveList, null, enddatedList);
        MtxTimestamp freeEndTime = TestUtils.addDays(
                subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime(), 7);

        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                "1234", null, preActiveList, null, enddatedList);
        subscription.getPurchasedOfferArray().forEach(mpoi -> {
            if (CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION.equals(
                    mpoi.getCatalogItemExternalId())) {
                mpoi.setEndTime(freeEndTime);
            }
        });

        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        subscriptionResponse.getPurchasedOfferArray().forEach(poi -> {
            if (CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION.equals(
                    poi.getCatalogItemExternalId())) {
                poi.setEndTime(freeEndTime);
            }
        });

        @SuppressWarnings("serial")
        List<String> combinedList = new ArrayList<String>() {

            {
                addAll(preActiveList);
                addAll(enddatedList);
            }
        };
        emulateMtxResponsePricingCatalogItems(instance, combinedList);
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());

        String taxApiResp = CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.PLUS3VIS23);
        System.out.println(subscriptionResponse.toJson());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), any())).thenReturn(
                    taxApiResp);
            // method to test
            instance.getAOP(input, output);
        }
        System.out.println(output.toJson());
        boolean foundActivation = false;
        for (VisibleOfferDetails vod : output.getVisibleOfferDetailsList()) {
            if (CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION.equalsIgnoreCase(
                    vod.getCatalogItemExternalId())) {
                foundActivation = true;
            }
        }
        assertEquals(expectedFree, foundActivation);
    }

    @Test
    @Tag("VER-471")
    public void test_getAOP_When_offerInRecurringCharge_Then_OfferInResponse(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscriber is enrolled in free wearableactivation offer."
        };
        td.when = new String[] {
            "PaymentAdvice is called.  Free wearableactivation offer available in recurring charge."
        };
        td.then = new String[] {
            "Free wearable activation should show up as service offer in response."
        };
        TwoParameterTest pTests = (daysAfterNextBillcycle, expectedInOutput) -> {
            boolean expectedFree = (boolean) expectedInOutput;
            mockSubscriberGroup(instance, null);
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

            VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
            input.setIncludeTaxDetails("Y");

            VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

            List<String> activeList = Arrays.asList(CI_EXTERNAL_IDS.SETUP_SERVICES);
            List<String> preActiveList = Arrays.asList(
                    CI_EXTERNAL_IDS.BASE3VIS23, CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023);
            List<String> enddatedList = Arrays.asList(
                    CI_EXTERNAL_IDS.PLUS3VIS23, CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION);

            SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                    "1234", null, preActiveList, null, enddatedList);
            input.setSubscriberExternalId(subscriptionResponse.getExternalId());
            MtxTimestamp freeEndTime = TestUtils.addDays(
                    subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime(),
                    (int) daysAfterNextBillcycle);
            subscriptionResponse.getPurchasedOfferArray().forEach(poi -> {
                if (CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION.equals(
                        poi.getCatalogItemExternalId())) {
                    poi.setEndTime(freeEndTime);
                }
            });

            MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                    "1234", activeList, preActiveList, null, enddatedList);
            subscription.getPurchasedOfferArray().forEach(mpoi -> {
                if (CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION.equals(
                        mpoi.getCatalogItemExternalId())) {
                    mpoi.setEndTime(freeEndTime);
                }
            });

            MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                    subscriptionResponse);

            @SuppressWarnings("serial")
            List<String> combinedList = new ArrayList<String>() {

                {
                    addAll(preActiveList);
                    addAll(enddatedList);
                }
            };
            emulateMtxResponsePricingCatalogItems(instance, combinedList);
            emulateMtxResponseSubscription(instance, subscription);
            emulateSubscriptionResponse(instance, subscriptionResponse);
            emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
            emulateMtxResponseMulti_CreditBalances(instance, subscription);
            emulateAocServicePurchase(instance);

            doReturn("").when(instance).getRoute(any());
            doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());

            String taxApiResp = CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.PLUS3VIS23);
            System.out.println(chargeInfo.toJson());
            System.out.println(subscriptionResponse.toJson());
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), any())).thenReturn(
                        taxApiResp);
                // method to test
                instance.getAOP(input, output);
            }
            System.out.println(output.toJson());
            boolean foundActivation = false;
            for (VisibleOfferDetails vod : output.getVisibleOfferDetailsList()) {
                if (CI_EXTERNAL_IDS.FREE_WEARABLE_MONTHLY_ACTIVATION.equalsIgnoreCase(
                        vod.getCatalogItemExternalId())) {
                    foundActivation = true;
                }
            }
            assertEquals(expectedFree, foundActivation);
        };
        pTests.test(0, false);
        pTests.test(7, true);
    }

    @Test
    @Tag("MTXVER2TMA-4532")
    public void test_getAOP_When_CatalogHasMonthlyCycleDates_Then_ResponseHasCorrectDates(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscriber is enrolled in free Plus3VIS23WB offer."
        };
        td.when = new String[] {
            "PaymentAdvice is called."
        };
        td.then = new String[] {
            "CycleDates should be correct."
        };
        mockSubscriberGroup(instance, null);
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        List<String> activeList = Arrays.asList(
                CI_EXTERNAL_IDS.SETUP_SERVICES, CI_EXTERNAL_IDS.PLUS3VIS23);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                "1234", activeList);
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getEmptySubscriptionResponse(
                "1234");
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());

        for (String ciExternalId : activeList) {
            CommonTestHelper.getPurchasedOfferInfoForServicOffer(
                    subscriptionResponse, ciExternalId);
        }

        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        emulateMtxResponsePricingCatalogItems(instance, activeList);
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);

        doReturn("").when(instance).getRoute(any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());

        String taxApiResp = CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.PLUS3VIS23);
        System.out.println(subscriptionResponse.toJson());
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(() -> TaxApiClient.getTaxApiResult(any(), any())).thenReturn(
                    taxApiResp);
            // method to test
            instance.getAOP(input, output);
        }
        System.out.println(output.toJson());
        assertEquals(
                subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime().getTime(),
                output.getAtVisibleOfferDetailsList(0).getCycleStartTime());
        assertEquals(
                CommonUtils.getNextCycleEndTime(
                        subscriptionResponse.getBillingCycle(),
                        subscriptionResponse.getTimeZone()).getTime(),
                output.getAtVisibleOfferDetailsList(0).getCycleEndTime());
    }

    @SuppressWarnings("unchecked")
    @Test
    @Tag("VER-612")
    public void test_getAOP_When_Insurance_Cps_Different_Then_Cps_From_Prev_Tax(TestInfo testInfo)
            throws Exception {
        TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[] {
            "Subscriber is enrolled in Insurance offer.", "Has previous tax response."
        };
        td.when = new String[] {
            "PaymentAdvice is called."
        };
        td.then = new String[] {
            "New tax response will take Cps from previous tax response.",
            "Cps from pricing will be ignored."
        };

        TwoParameterTest pTests = (iCp, wCp) -> {
            td.printDescription();

            VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
            input.setIncludeTaxDetails("Y");

            List<String> activeOffers = Arrays.asList(CI_EXTERNAL_IDS.INSURANCE);

            SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                    activeOffers);
            ServiceTaxResponse taxInsJson = CommonTestHelper.getJsonFromString(
                    ServiceTaxResponse.class,
                    ((VisiblePurchasedOfferExtension) subscriptionResponse.getAtPurchasedOfferArray(
                            0).getAttr()).getTaxDetails());

            String insuranceGlRef = "Visible_Device_Insurance_Offer";
            BigDecimal insuranceCp = (BigDecimal) iCp;

            String warrantyGlRef = "Visible_Device_Extended_Warranty_Offer";
            BigDecimal warrantyCp = (BigDecimal) wCp;

            taxInsJson.getTransactionElement().forEach(te -> {
                te.getDpcGroupList().forEach(dgt -> {
                    dgt.getDpcItemList().forEach(dit -> {
                        if (dit.getGlReference().equalsIgnoreCase(insuranceGlRef)) {
                            dit.setcP(insuranceCp);
                        }
                        if (dit.getGlReference().equalsIgnoreCase(warrantyGlRef)) {
                            dit.setcP(warrantyCp);
                        }
                    });
                });
            });
            ((VisiblePurchasedOfferExtension) subscriptionResponse.getAtPurchasedOfferArray(
                    0).getAttr()).setTaxDetails(taxInsJson.toJson());
            MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                    activeOffers);

            input.setSubscriberExternalId(subscriptionResponse.getExternalId());

            emulateMtxResponsePricingCatalogItems(instance, activeOffers);

            subscription.getBalanceArrayAppender().clear();
            MtxBalanceInfo biMainBalance = CommonTestHelper.getMtxBalanceInfo(
                    BALANCE_NAMES.MAIN_BALANCE, null, null, null);
            subscription.getBalanceArrayAppender().add(biMainBalance);

            MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                    subscriptionResponse);

            VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

            // mocks
            doReturn("").when(instance).getRoute(any());
            doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
            doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
            emulateMtxResponseSubscription(instance, subscription);
            emulateSubscriptionResponse(instance, subscriptionResponse);
            emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
            emulateMtxResponseMulti_CreditBalances(instance, subscription);
            emulateAocServicePurchase(instance);

            ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);

            // method to test
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(
                                any(), argumentCaptor.capture())).thenReturn("");
                // method to test
                instance.getAOP(input, output);
            }

            ServiceTaxRequest taxReq = CommonTestHelper.getJsonFromString(
                    ServiceTaxRequest.class, argumentCaptor.getValue());
            BigDecimal actualInsuranceCp = BigDecimal.ZERO;
            BigDecimal actualwarrantyCp = BigDecimal.ZERO;
            for (DpcGroup dg : taxReq.getDpcGroupList()) {
                for (DpcItem di : dg.getDpcItemList()) {
                    if (di.getGlReference().equalsIgnoreCase(insuranceGlRef)) {
                        actualInsuranceCp = di.getcP();
                    }
                    if (di.getGlReference().equalsIgnoreCase(warrantyGlRef)) {
                        actualwarrantyCp = di.getcP();
                    }

                }
            }

            assertEquals(insuranceCp.floatValue(), actualInsuranceCp.floatValue());
            assertEquals(warrantyCp.floatValue(), actualwarrantyCp.floatValue());
        };

        pTests.test(BigDecimal.valueOf(0.5), BigDecimal.valueOf(0.5));
        pTests.test(BigDecimal.valueOf(0), BigDecimal.valueOf(1));
        pTests.test(BigDecimal.valueOf(1), BigDecimal.valueOf(0));
        pTests.test(BigDecimal.valueOf(0.7), BigDecimal.valueOf(0.3));
        pTests.test(BigDecimal.valueOf(0.67), BigDecimal.valueOf(0.33));
    }

    @ParameterizedTest(name = "When_Wearable_or_Base_Then_Cps_From_Pricing")
    @Tag("VER-612")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber is enrolled in wearable or PLUS monthly offer.|"
                +"|      |Has previous tax response.|"
                +"|When  |PaymentAdvice is called.|"
                +"|Then  |New tax response will take Cps from pricing.|"})
    // @formatter:on
    @SuppressWarnings("unchecked")
    public void test_getAOP_When_Wearable_or_Base_Then_Cps_From_Pricing(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        OneParameterTest pTests = (offer) -> {
            td.printDescription();

            VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
            input.setIncludeTaxDetails("Y");

            List<String> activeOffers = Arrays.asList(offer.toString());

            SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                    activeOffers);

            ServiceTaxResponse taxInsJson = CommonTestHelper.getJsonFromString(
                    ServiceTaxResponse.class,
                    ((VisiblePurchasedOfferExtension) subscriptionResponse.getAtPurchasedOfferArray(
                            0).getAttr()).getTaxDetails());

            String data = "Visible_Unlimited_Data";
            BigDecimal dataCp = BigDecimal.valueOf(2);

            String voice = "Visible_Unlimited_Voice";
            BigDecimal voiceCp = BigDecimal.valueOf(2);

            String ldv = "Visible_LD_Voice";
            BigDecimal ldvCp = BigDecimal.valueOf(2);

            String mms = "Visible_Unlimited_MMS";
            BigDecimal mmsCp = BigDecimal.valueOf(2);

            String text = "Visible_Unlimited_Text";
            BigDecimal textCp = BigDecimal.valueOf(2);

            taxInsJson.getTransactionElement().forEach(te -> {
                te.getDpcGroupList().forEach(dgt -> {
                    dgt.getDpcItemList().forEach(dit -> {
                        if (dit.getGlReference().equalsIgnoreCase(data)) {
                            dit.setcP(dataCp);
                        }
                        if (dit.getGlReference().equalsIgnoreCase(voice)) {
                            dit.setcP(voiceCp);
                        }
                        if (dit.getGlReference().equalsIgnoreCase(ldv)) {
                            dit.setcP(ldvCp);
                        }
                        if (dit.getGlReference().equalsIgnoreCase(mms)) {
                            dit.setcP(mmsCp);
                        }
                        if (dit.getGlReference().equalsIgnoreCase(text)) {
                            dit.setcP(textCp);
                        }
                    });
                });
            });
            ((VisiblePurchasedOfferExtension) subscriptionResponse.getAtPurchasedOfferArray(
                    0).getAttr()).setTaxDetails(taxInsJson.toJson());
            MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                    activeOffers);
            System.out.println(taxInsJson.toJson());
            System.out.println(subscriptionResponse.toJson());
            input.setSubscriberExternalId(subscriptionResponse.getExternalId());

            emulateMtxResponsePricingCatalogItems(instance, activeOffers);

            subscription.getBalanceArrayAppender().clear();
            MtxBalanceInfo biMainBalance = CommonTestHelper.getMtxBalanceInfo(
                    BALANCE_NAMES.MAIN_BALANCE, null, null, null);
            subscription.getBalanceArrayAppender().add(biMainBalance);

            MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                    subscriptionResponse);

            VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

            // mocks
            AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
            doReturn("").when(instance).getRoute(any());
            doReturn(null).when(instance).queryDeviceData(any(), any(), any());
            doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
            doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
            doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(
                    instance).queryDeviceData(any(), any(), any());
            emulateMtxResponseSubscription(instance, subscription);
            emulateSubscriptionResponse(instance, subscriptionResponse);
            emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
            emulateMtxResponseMulti_CreditBalances(instance, subscription);
            emulateAocServicePurchase(instance);

            ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);

            // method to test
            try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
                mockedStatic.when(
                        () -> TaxApiClient.getTaxApiResult(
                                any(), argumentCaptor.capture())).thenReturn("");
                // method to test
                instance.getAOP(input, output);
            }

            ServiceTaxRequest taxReq = CommonTestHelper.getJsonFromString(
                    ServiceTaxRequest.class, argumentCaptor.getValue());
            System.out.println(taxReq.toJson());
            BigDecimal actualDataCp = BigDecimal.ZERO;
            BigDecimal actualVoiceCp = BigDecimal.ZERO;
            BigDecimal actualLdvCp = BigDecimal.ZERO;
            BigDecimal actualMmsCp = BigDecimal.ZERO;
            BigDecimal actualTextCp = BigDecimal.ZERO;
            for (DpcGroup dg : taxReq.getDpcGroupList()) {
                for (DpcItem di : dg.getDpcItemList()) {
                    if (di.getGlReference().equalsIgnoreCase(data)) {
                        actualDataCp = di.getcP();
                    }
                    if (di.getGlReference().equalsIgnoreCase(voice)) {
                        actualVoiceCp = di.getcP();
                    }
                    if (di.getGlReference().equalsIgnoreCase(ldv)) {
                        actualLdvCp = di.getcP();
                    }
                    if (di.getGlReference().equalsIgnoreCase(mms)) {
                        actualMmsCp = di.getcP();
                    }
                    if (di.getGlReference().equalsIgnoreCase(text)) {
                        actualTextCp = di.getcP();
                    }
                }
            }

            assertNotEquals(dataCp.floatValue(), actualDataCp.floatValue());
            assertNotEquals(voiceCp.floatValue(), actualVoiceCp.floatValue());
            assertNotEquals(ldvCp.floatValue(), actualLdvCp.floatValue());
            assertNotEquals(mmsCp.floatValue(), actualMmsCp.floatValue());
            assertNotEquals(textCp.floatValue(), actualTextCp.floatValue());
        };

        // pTests.test(CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023);
        pTests.test(CI_EXTERNAL_IDS.PLUS3VIS23);
    }

    @ParameterizedTest(name = "When_AnnualPlan_ZeroPay_SubscriptionPromo_Then_PromoClassCode")
    @Tag("VER-632")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given | Subscription has annual plan that is not due for renewals.|"
                +"|      | Has some subscription based promotions|"
                +"|When  | Payment Advice requested for next month.|"
                +"|Then  | Provide response with promo class codes.|"})
    // @formatter:on
    public void test_getAOP_When_AnnualPlan_ZeroPay_SubscriptionPromo_Then_PromoClassCode(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");
        input.setSubscriberExternalId("1234");

        List<String> ciExternalIds = Arrays.asList(
                CI_EXTERNAL_IDS.PLUS3ANNUAL, CI_EXTERNAL_IDS.GENERIC_GRANT);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                input.getSubscriberExternalId(), ciExternalIds);
        CommonTestHelper.setSubscriberBalanceAmount(
                subscription, BALANCE_NAMES.GENERIC_GRANT, BigDecimal.valueOf(25));
        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                input.getSubscriberExternalId(), ciExternalIds);

        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponsePricingCatalogItems(instance, ciExternalIds);

        emulateAocServicePurchase(instance);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscriptionResponse.getExternalId() + "]").when(instance).getLoggingKey(
                any());
        doReturn(chargeInfo).when(api).subscriberEstimateRecurringCharge(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateAocServicePurchase(instance);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);

        System.out.println(subscriptionResponse.toJson());

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());

        assertEquals(TAX_CLASS_CODES.GENRIC, output.getAtCredits(0).getClassCode());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name = "When_AnnualPlan_ZeroPay_OneTimeCredit_Then_PromoClassCode")
    @Tag("VER-632")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has annual plan that is not due for renewals.|"
                +"|      |Has some onetime credits like goodwill or referrals|"
                +"|When  |Payment Advice requested for next month.|"
                +"|Then  |Provide response with promo class codes.|"})
    // @formatter:on
    public void test_getAOP_When_AnnualPlan_ZeroPay_OneTimeCredit_Then_PromoClassCode(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");
        input.setSubscriberExternalId("1234");

        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(
                        CI_EXTERNAL_IDS.PLUS3ANNUAL, CI_EXTERNAL_IDS.GRANT_GOODWILL,
                        CI_EXTERNAL_IDS.GOODWILL_REDEEM));

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.PLUS3ANNUAL);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                input.getSubscriberExternalId(), ciExternalIds);
        MtxBalanceInfo goodGrant = CommonTestHelper.getMtxBalanceInfo(
                BALANCE_NAMES.GOODWILL_GRANT, BigDecimal.valueOf(25));
        subscription.getBalanceArrayAppender().add(goodGrant);

        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                input.getSubscriberExternalId(), ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        subscriptionResponse.getBillingCycle().setDateOffset(1L);
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        emulateAocServicePurchase(instance);
        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        assertEquals(TAX_CLASS_CODES.GOODWILL, output.getAtCredits(0).getClassCode());
    }

    @ParameterizedTest(name = "When_AnnualPlan_ZeroPay_AocCredit_Then_PromoClassCode")
    @Tag("VER-632")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has annual plan that is not due for renewals.|"
                +"|      |Has some aoc credits like VBPP or Chime|"
                +"|When  |Payment Advice requested for next month.|"
                +"|Then  |Provide response with promo class codes.|"})
    // @formatter:on
    public void test_getAOP_When_AnnualPlan_ZeroPay_AocCredit_Then_PromoClassCode(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        AppPropertyProvider.getInstance().setProperty(
                CREDIT_CONSTANTS.AOC_GRANT_OFFERS, CI_EXTERNAL_IDS.VBPP5_AOC_GRANT);
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");
        input.setSubscriberExternalId("1234");

        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.PLUS3ANNUAL);
        MtxResponsePricingCatalogItem pci = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.VBPP5_AOC_GRANT);
        VisibleTemplate vt = (VisibleTemplate) pci.getCatalogItemInfo().getTemplateAttr();
        vt.setApplicableOfferName(CI_EXTERNAL_IDS.PLUS3ANNUAL);

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.PLUS3ANNUAL);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                input.getSubscriberExternalId(), ciExternalIds);
        subscription.setParentGroupCount(1L);
        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));

        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                input.getSubscriberExternalId(), ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        subscriptionResponse.getBillingCycle().setDateOffset(1L);
        subscriptionResponse.setParentGroupCount(1L);
        subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));

        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        MtxResponseMulti responseGroupMulti = new MtxResponseMulti();
        responseGroupMulti.setResult(RESULT_CODES.MTX_SUCCESS);
        responseGroupMulti.setResultText("OK");
        MtxResponseGroup respGrp = new MtxResponseGroup();
        respGrp.setTier("VBPP");
        responseGroupMulti.appendResponseList(respGrp);
        doReturn(responseGroupMulti).when(instance).querySubscriptionGroups(any(), any(), any());
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(BigDecimal.valueOf(5).negate()).when(instance).getChargeableAmountForPurchaseOffer(
                any(), eq(CI_EXTERNAL_IDS.VBPP_CORE_REDEEM), any(),
                any(MtxSubscriberSearchData.class));
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);
        // emulateAocServicePurchase(instance);
        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
        assertEquals(TAX_CLASS_CODES.VBPPCORE, output.getAtCredits(0).getClassCode());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name = "test_getAoP_When_DeviceNoType_Then_ReportAsServiceDevice")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber has service device. Devicetype is not set|"
                +"|When  |Api is called.|"
                +"|Then  |AoP should return service device.|"})
    // @formatter:on    
    public void test_getAoP_When_DeviceNoType_Then_ReportAsServiceDevice(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.PLUS3VIS23WB);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);

        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        subscriptionResponse.getDeviceIdArrayAppender().add(new MtxObjectId("1-2-3-4"));
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());

        System.out.println(subscriptionResponse.toJson());

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();
        // mocks

        MtxResponseDevice device = CommonTestHelper.getMtxResponseDevice_Default();
        ((VisibleDeviceExtension) device.getAttr()).setDeviceType(null);
        doReturn(device).when(instance).queryDeviceData(any(), any(), any());

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItems(instance, ciExternalIds);

        doReturn("").when(instance).getRoute(any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);

        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);

        emulateAocServicePurchase(instance);

        // method to test
        instance.getAOP(input, output);

        System.out.println(output.toJson());

        assertEquals(
                DEVICE_CONSTANTS.DEVICE_TYPE_SERVICE,
                output.getAtSubscriberDevices(0).getDeviceType());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name = "test_getAoP_When_DeviceTypeService_Then_ReportAsServiceDevice")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber has service device.|"
                +"|When  |Api is called.|"
                +"|Then  |AoP should return service device.|"})
    // @formatter:on    
    public void test_getAoP_When_DeviceTypeService_Then_ReportAsServiceDevice(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.PLUS3VIS23WB);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);

        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        subscriptionResponse.getDeviceIdArrayAppender().add(new MtxObjectId("1-2-3-4"));
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());

        System.out.println(subscriptionResponse.toJson());

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();
        // mocks
        MtxResponseDevice device = CommonTestHelper.getMtxResponseDevice_Default();
        ((VisibleDeviceExtension) device.getAttr()).setDeviceType(
                DEVICE_CONSTANTS.DEVICE_TYPE_SERVICE);
        doReturn(device).when(instance).queryDeviceData(any(), any(), any());

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItems(instance, ciExternalIds);

        doReturn("").when(instance).getRoute(any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);

        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);

        emulateAocServicePurchase(instance);

        // method to test
        instance.getAOP(input, output);

        System.out.println(output.toJson());

        assertEquals(
                DEVICE_CONSTANTS.DEVICE_TYPE_SERVICE,
                output.getAtSubscriberDevices(0).getDeviceType());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name = "test_getAoP_When_DeviceTypeWearable_Then_ReportAsWearableDevice")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber has wearable device.|"
                +"|When  |Api is called.|"
                +"|Then  |AoP should return wearable device.|"})
    // @formatter:on    
    public void test_getAoP_When_DeviceTypeWearable_Then_ReportAsWearableDevice(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.PLUS3VIS23WB);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);

        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        subscriptionResponse.getDeviceIdArrayAppender().add(new MtxObjectId("1-2-3-4"));
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());

        System.out.println(subscriptionResponse.toJson());

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();
        // mocks
        MtxResponseDevice device = CommonTestHelper.getMtxResponseDevice_Wearable();
        doReturn(device).when(instance).queryDeviceData(any(), any(), any());

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItems(instance, ciExternalIds);

        doReturn("").when(instance).getRoute(any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);

        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);

        emulateAocServicePurchase(instance);

        // method to test
        instance.getAOP(input, output);

        System.out.println(output.toJson());

        assertEquals(
                DEVICE_CONSTANTS.DEVICE_TYPE_WEARABLE,
                output.getAtSubscriberDevices(0).getDeviceType());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name = "test_getAoP_When_DeviceTypeWearable_NoAccessNumber_Then_Error")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber has wearable device. Device has no access number|"
                +"|When  |Api is called.|"
                +"|Then  |AoP error|"})
    // @formatter:on    
    public void test_getAoP_When_DeviceTypeWearable_NoAccessNumber_Then_Error(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.PLUS3VIS23WB);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);

        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        subscriptionResponse.getDeviceIdArrayAppender().add(new MtxObjectId("1-2-3-4"));
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());

        System.out.println(subscriptionResponse.toJson());

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();
        // mocks
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        doReturn("").when(instance).getRoute(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_NoAccessArray()).when(
                instance).queryDeviceData(any(), any(), any());
        emulateMtxResponsePricingCatalogItems(instance, ciExternalIds);
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);

        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);

        emulateAocServicePurchase(instance);

        // method to test
        Exception exception = assertThrows(
                PaymentAdviceException.class, () -> instance.getAOP(input, output));
        exception.printStackTrace();

        System.out.println(output.toJson());

        assertTrue(
                exception.getMessage().contains(
                        "Device present without MDN. MDN could not be determined."));
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name = "test_getAoP_When_DeviceTypeService_NoAccessNumber_Then_Error")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber has service device. Device has no access number|"
                +"|When  |Api is called.|"
                +"|Then  |AoP error|"})
    // @formatter:on    
    public void test_getAoP_When_DeviceTypeService_NoAccessNumber_Then_Error(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.PLUS3VIS23WB);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);

        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        subscriptionResponse.getDeviceIdArrayAppender().add(new MtxObjectId("1-2-3-4"));
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());

        System.out.println(subscriptionResponse.toJson());

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        MtxResponseDevice device = CommonTestHelper.getMtxResponseDevice_NoAccessArray();
        doReturn(device).when(instance).queryDeviceData(any(), any(), any());
        doReturn("").when(instance).getRoute(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_NoAccessArray()).when(
                instance).queryDeviceData(any(), any(), any());

        emulateMtxResponsePricingCatalogItems(instance, ciExternalIds);
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);

        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);

        emulateAocServicePurchase(instance);

        // method to test
        Exception exception = assertThrows(
                PaymentAdviceException.class, () -> instance.getAOP(input, output));
        exception.printStackTrace();

        System.out.println(output.toJson());

        assertTrue(
                exception.getMessage().contains(
                        "Device present without MDN. MDN could not be determined."));
    }

    @ParameterizedTest(name = "test_getAoP_When_NoGeocode_Then_Error")
    @Tag("Tax")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber.Subscriber has no geocode.|"                        
                +"|When  |Api is called with a service and with no geocode.|"
                +"|Then  |AoP should return error.|"})
    // @formatter:on    
    public void test_getAoP_When_NoGeocode_Then_Error(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.PLUS3VIS23WB);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        ((VisibleSubscriberExtension) subscription.getAttr()).setGeoCode(null);
        ((VisiblePurchasedOfferExtension) subscription.getAtPurchasedOfferArray(
                0).getAttr()).setTaxDetails("");

        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        ((VisibleSubscriberExtension) subscriptionResponse.getAttr()).setGeoCode(null);
        ((VisiblePurchasedOfferExtension) subscriptionResponse.getAtPurchasedOfferArray(
                0).getAttr()).setTaxDetails("");

        System.out.println(subscriptionResponse.toJson());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItems(instance, ciExternalIds);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateAocServicePurchase(instance);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), any(String.class))).thenReturn("");
            // method to test
            instance.getAOP(input, output);
        }

        System.out.println(output.toJson());

        assertTrue(
                output.getResultText().contains(
                        "ERROR: No valid geocode passed for tax calculation"));
    }

    @ParameterizedTest(name = "test_getAoP_When_GifterGeocodeOnly_Then_Error")
    @Tag("Tax")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber has no geocode. And previous tax is from Gifter.|"
                +"|When  |Api is called with a service and with no geocode.|"
                +"|Then  |AoP should return error.|"})
    // @formatter:on    
    public void test_getAoP_When_GifterGeocodeOnly_Then_Error(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.PLUS3VIS23WB);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);
        ((VisibleSubscriberExtension) subscription.getAttr()).setGeoCode(null);
        String taxAsString = ((VisiblePurchasedOfferExtension) subscription.getAtPurchasedOfferArray(
                0).getAttr()).getTaxDetails();
        ServiceTaxResponse taxResp = CommonTestHelper.getServiceTaxResponseFromString(taxAsString);
        taxResp.setMsgID(TAX_CONSTANTS.MSG_PREFIX_GIFT_TAX + "|" + "Gifter#1");
        ((VisiblePurchasedOfferExtension) subscription.getAtPurchasedOfferArray(
                0).getAttr()).setTaxDetails(taxResp.toJson());

        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        ((VisibleSubscriberExtension) subscriptionResponse.getAttr()).setGeoCode(null);
        ((VisiblePurchasedOfferExtension) subscriptionResponse.getAtPurchasedOfferArray(
                0).getAttr()).setTaxDetails(taxResp.toJson());

        System.out.println(subscriptionResponse.toJson());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItems(instance, ciExternalIds);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateAocServicePurchase(instance);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), any(String.class))).thenReturn("");
            // method to test
            instance.getAOP(input, output);
        }

        System.out.println(output.toJson());

        assertTrue(
                output.getResultText().contains(
                        "ERROR: No valid geocode passed for tax calculation"));
    }

    @ParameterizedTest(name = "test_getAoP_When_BadTaxResponse_Then_Error")
    @Tag("Tax")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber.|"                        
                +"|When  |Api is called. Taxapi returned bad response.|"
                +"|Then  |AoP should return error.|"})
    // @formatter:on    
    public void test_getAoP_When_BadTaxResponse_Then_Error(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.PLUS3VIS23WB);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);

        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());

        System.out.println(subscriptionResponse.toJson());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItems(instance, ciExternalIds);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateAocServicePurchase(instance);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), any(String.class))).thenReturn("xyz");
            // method to test
            instance.getAOP(input, output);
        }

        System.out.println(output.toJson());

        assertTrue(output.getResultText().contains("Error while calculating service tax"));
    }

    @ParameterizedTest(name = "test_getAOP_When_MultipleRecurringEvents_Then_NoError")
    @Tag("VER-696")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscription has PLUS3VIS23WBA plan that is due for renewals.|"
                +"|When  |Payment Advice requested for next month.|"
                +"|Then  |Provide response for full payment.|"})
    // @formatter:on
    public void test_getAOP_When_MultipleRecurringEvents_Then_NoError(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");
        input.setSubscriberExternalId("1234");

        emulateMtxResponsePricingCatalogItem(instance, CI_EXTERNAL_IDS.PLUS3ANNUAL);

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.PLUS3ANNUAL);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                input.getSubscriberExternalId(), ciExternalIds);

        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                input.getSubscriberExternalId(), ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        subscriptionResponse.getBillingCycle().setDateOffset(1L);

        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + subscription.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, subscription);

        // method to test
        instance.getAOP(input, output);
        System.out.println(output.toJson());
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest(name = "test_getAoP_When_PayerExists_Then_AdviceHasPayerId")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber has payer. Payer and Beneficiary are in same group with Beneficiary-Payer relation.|"
                +"|When  |Api is called.|"
                +"|Then  |AoP should return payer id.|"})
    // @formatter:on    
    public void test_getAoP_When_PayerExists_Then_AdviceHasPayerId(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("N");

        List<String> ciExternalIds = List.of(CI_EXTERNAL_IDS.PLUS3VIS23WB);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);

        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        subscriptionResponse.getDeviceIdArrayAppender().add(new MtxObjectId("1-2-3-4"));
        subscriptionResponse.setParentGroupCount(1L);
        subscriptionResponse.appendParentGroupIdArray(new MtxObjectId("1-2-3-5"));

        input.setSubscriberExternalId(subscriptionResponse.getExternalId());

        System.out.println(subscriptionResponse.toJson());

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();
        // mocks

        MtxResponseDevice device = CommonTestHelper.getMtxResponseDevice_Default();
        ((VisibleDeviceExtension) device.getAttr()).setDeviceType(null);
        doReturn(device).when(instance).queryDeviceData(any(), any(), any());

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItems(instance, ciExternalIds);

        doReturn("").when(instance).getRoute(any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);

        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);

        emulateAocServicePurchase(instance);

        String payerExternalID = "12345";
        MtxResponseMulti responseGroupMulti = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseGroup respGrp = CommonTestHelper.getMtxResponseGroupCA(
                subscriptionResponse.getExternalId(), "CAGroup",
                List.of(subscriptionResponse.getObjectId().toString(), "1-2-3-4", "6-7-8-9"),
                List.of("Ben:" + subscriptionResponse.getExternalId() + "#Pay:" + payerExternalID));
        responseGroupMulti.appendResponseList(respGrp);

        System.out.println(responseGroupMulti.toJson());
        doReturn(responseGroupMulti).when(instance).querySubscriptionGroups(any(), any(), any());

        // method to test
        instance.getAOP(input, output);

        System.out.println(output.toJson());

        assertEquals(payerExternalID, output.getPayerExternalId());
    }

    @ParameterizedTest(
            name = "test_getAoP_Given_MmOfferEndsLate_PreactiveStartsLate_When_NoMainbalanceImpact_Then_MmOfferInResponse")
    @Tag("MultiMonth")
    @Tag("VER-852")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber has a multimonth offer that has end date. Preactive offer starts later than next month.|"
                +"|When  |Api is called. Recurring charge has no mainbalance impact.|"
                +"|Then  |AoP should return details for multimonth offer.|"})
    // @formatter:on    
    public void test_getAoP_Given_MmOfferEndsLate_PreactiveStartsLate_When_NoMainbalanceImpact_Then_MmOfferInResponse(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        List<String> activeCiIds = Arrays.asList(CI_EXTERNAL_IDS.BASE6MONTH25);
        List<String> preActiveCiIds = Arrays.asList(CI_EXTERNAL_IDS.BASE3VIS23);
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setSubscriberExternalId("1234");
        input.setIncludeTaxDetails("N");
        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                input.getSubscriberExternalId(), activeCiIds, preActiveCiIds);
        MtxTimestamp mmEndDate = subscription.getAtPurchasedOfferArray(
                0).getCycleInfo().getCycleEndTime();
        subscription.getAtPurchasedOfferArray(0).setEndTime(mmEndDate);
        subscription.getAtPurchasedOfferArray(1).setAutoActivationTime(mmEndDate);

        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                input.getSubscriberExternalId(), activeCiIds, preActiveCiIds);
        subscriptionResponse.getAtPurchasedOfferArray(0).setEndTime(mmEndDate);
        subscriptionResponse.getAtPurchasedOfferArray(1).setAutoActivationTime(mmEndDate);
        System.out.println(subscriptionResponse.toJson());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        emulateMtxResponsePricingCatalogItems(
                instance, List.of(CI_EXTERNAL_IDS.BASE6MONTH25, CI_EXTERNAL_IDS.BASE3VIS23));
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateAocServicePurchase(instance);

        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());

        // method to test
        instance.getAOP(input, output);
        printUnitTest(input.toJson());
        printUnitTest(output.toJson());

        MtxPurchasedOfferInfo po = subscriptionResponse.getAtPurchasedOfferArray(0);// Active offer
                                                                                    // is first
                                                                                    // offer
        VisiblePurchasedOfferExtension poAttr = (VisiblePurchasedOfferExtension) po.getAttr();

        VisibleOfferDetails vod = output.getAtVisibleOfferDetailsList(0);

        assertEquals(po.getCatalogItemExternalId(), vod.getCatalogItemExternalId());
        assertEquals(po.getResourceId() + "", vod.getResourceId());
        assertEquals(poAttr.getChargeAmount().intValue(), vod.getChargeAmount().intValue());
        assertEquals(
                poAttr.getPaidCycleStartDate().getTime(), vod.getPaidCycleStartDate().getTime());
        assertEquals(0, vod.getPayableAmount().intValue());
        assertEquals(po.getOfferStatusDescription(), vod.getStatus());
        assertEquals(po.getCycleInfo().getCycleEndTime().getTime(), vod.getCycleStartTime());
        assertEquals(
                TestUtils.addMonths(
                        po.getCycleInfo().getCycleEndTime(), 6,
                        subscriptionResponse.getTimeZone()).getTime(),
                vod.getCycleEndTime());
    }

    @ParameterizedTest(
            name = "test_getAoP_Given_MmOfferEndsNext_PreactiveStartsNext_When_NoMainbalanceImpact_Then_PreactiveInResponse")
    @Tag("MultiMonth")
    @Tag("VER-852")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber has a multimonth offer that has end date. Preactive offer starts NEXT month|"
                +"|When  |Api is called. Recurring charge has no mainbalance impact.|"
                +"|Then  |AoP should return details for preactive offer.|"})
    // @formatter:on    
    public void test_getAoP_Given_MmOfferEndsNext_PreactiveStartsNext_When_NoMainbalanceImpact_Then_PreactiveInResponse(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        List<String> activeCiIds = Arrays.asList(CI_EXTERNAL_IDS.BASE6MONTH25);
        List<String> preActiveCiIds = Arrays.asList(CI_EXTERNAL_IDS.BASE3VIS23);
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setSubscriberExternalId("1234");
        input.setIncludeTaxDetails("N");
        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                input.getSubscriberExternalId(), activeCiIds, preActiveCiIds);
        MtxTimestamp mmEndDate = subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime();
        subscriptionResponse.getAtPurchasedOfferArray(0).setEndTime(mmEndDate);
        subscriptionResponse.getAtPurchasedOfferArray(1).setAutoActivationTime(mmEndDate);

        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                input.getSubscriberExternalId(), activeCiIds, preActiveCiIds);
        subscription.getAtPurchasedOfferArray(0).setEndTime(mmEndDate);
        subscription.getAtPurchasedOfferArray(1).setAutoActivationTime(mmEndDate);

        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        emulateMtxResponsePricingCatalogItems(
                instance, List.of(CI_EXTERNAL_IDS.BASE6MONTH25, CI_EXTERNAL_IDS.BASE3VIS23));
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateAocServicePurchase(instance);

        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());

        // method to test
        instance.getAOP(input, output);
        printUnitTest(input.toJson());
        printUnitTest(output.toJson());

        MtxPurchasedOfferInfo po = subscriptionResponse.getAtPurchasedOfferArray(1);// Preactive
                                                                                    // offer is
                                                                                    // second offer
        VisiblePurchasedOfferExtension poAttr = (VisiblePurchasedOfferExtension) po.getAttr();

        VisibleOfferDetails vod = output.getAtVisibleOfferDetailsList(0);

        assertEquals(po.getCatalogItemExternalId(), vod.getCatalogItemExternalId());
        assertEquals(po.getResourceId() + "", vod.getResourceId());
        assertEquals(poAttr.getChargeAmount().intValue(), vod.getChargeAmount().intValue());
        assertEquals(
                poAttr.getPaidCycleStartDate().getTime(), vod.getPaidCycleStartDate().getTime());
        assertEquals(poAttr.getChargeAmount().intValue(), vod.getPayableAmount().intValue());
        assertEquals(po.getOfferStatusDescription(), vod.getStatus());
        assertEquals(mmEndDate.getTime(), vod.getCycleStartTime());
        assertEquals(
                TestUtils.addMonths(mmEndDate, 1, subscriptionResponse.getTimeZone()).getTime(),
                vod.getCycleEndTime());
    }

    @ParameterizedTest(
            name = "test_getAoP_Given_MmOfferEndsLate_NoPreactive_When_NoMainbalanceImpact_Then_MMOfferResponse")
    @Tag("MultiMonth")
    @Tag("VER-852")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber has a multimonth offer that has end date later than a month. Not enrolled in preactive offer.|"
                +"|When  |Api is called. Recurring charge has no mainbalance impact.|"
                +"|Then  |AoP should return details for MMOffer offer.|"})
    // @formatter:on    
    public void test_getAoP_Given_MmOfferEndsLate_NoPreactive_When_NoMainbalanceImpact_Then_MMOfferResponse(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        List<String> activeCiIds = Arrays.asList(CI_EXTERNAL_IDS.BASE6MONTH25);
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setSubscriberExternalId("1234");
        input.setIncludeTaxDetails("N");
        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                input.getSubscriberExternalId(), activeCiIds);
        MtxTimestamp mmEndDate = subscription.getAtPurchasedOfferArray(
                0).getCycleInfo().getCycleEndTime();
        subscription.getAtPurchasedOfferArray(0).setEndTime(mmEndDate);

        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                input.getSubscriberExternalId(), activeCiIds);
        subscriptionResponse.getAtPurchasedOfferArray(0).setEndTime(mmEndDate);
        System.out.println(subscriptionResponse.toJson());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        emulateMtxResponsePricingCatalogItems(instance, List.of(CI_EXTERNAL_IDS.BASE6MONTH25));
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateAocServicePurchase(instance);

        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());

        // method to test
        instance.getAOP(input, output);
        printUnitTest(input.toJson());
        printUnitTest(output.toJson());

        MtxPurchasedOfferInfo po = subscriptionResponse.getAtPurchasedOfferArray(0);// Active offer
                                                                                    // is first
                                                                                    // offer
        VisiblePurchasedOfferExtension poAttr = (VisiblePurchasedOfferExtension) po.getAttr();

        VisibleOfferDetails vod = output.getAtVisibleOfferDetailsList(0);

        assertEquals(po.getCatalogItemExternalId(), vod.getCatalogItemExternalId());
        assertEquals(po.getResourceId() + "", vod.getResourceId());
        assertEquals(poAttr.getChargeAmount().intValue(), vod.getChargeAmount().intValue());
        assertEquals(
                poAttr.getPaidCycleStartDate().getTime(), vod.getPaidCycleStartDate().getTime());
        assertEquals(0, vod.getPayableAmount().intValue());
        assertEquals(po.getOfferStatusDescription(), vod.getStatus());
        assertEquals(po.getCycleInfo().getCycleEndTime().getTime(), vod.getCycleStartTime());
        assertEquals(
                TestUtils.addMonths(
                        po.getCycleInfo().getCycleEndTime(), 6,
                        subscriptionResponse.getTimeZone()).getTime(),
                vod.getCycleEndTime());
    }

    @ParameterizedTest(
            name = "test_getAoP_Given_MmOfferEndsSoon_NoPreactive_When_NoMainbalanceImpact_Then_EmptyResponse")
    @Tag("MultiMonth")
    @Tag("VER-852")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber has a multimonth offer that has end date less than a month|"
                +"|When  |Api is called. Recurring charge has no mainbalance impact.|"
                +"|Then  |AoP should return emty response.|"})
    // @formatter:on    
    public void test_getAoP_Given_MmOfferEndsSoon_NoPreactive_When_NoMainbalanceImpact_Then_EmptyResponse(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        List<String> activeCiIds = Arrays.asList(CI_EXTERNAL_IDS.BASE6MONTH25);
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setSubscriberExternalId("1234");
        input.setIncludeTaxDetails("N");
        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                input.getSubscriberExternalId(), activeCiIds);
        MtxTimestamp mmEndDate = subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime();
        subscriptionResponse.getAtPurchasedOfferArray(0).setEndTime(mmEndDate);

        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                input.getSubscriberExternalId(), activeCiIds);
        subscription.getAtPurchasedOfferArray(0).setEndTime(mmEndDate);

        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        emulateMtxResponsePricingCatalogItems(instance, List.of(CI_EXTERNAL_IDS.BASE6MONTH25));
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateAocServicePurchase(instance);

        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());

        // method to test
        instance.getAOP(input, output);
        printUnitTest(input.toJson());
        printUnitTest(output.toJson());

        assertEquals(RESULT_CODES.MTX_SUCCESS, output.getResult());
        assertEquals(0, output.getTotalEstimatedAmount().intValue());
    }

    @ParameterizedTest(
            name = "test_getAoP_Given_MmOffer_And_Addon_When_AddonOnlyMainbalanceImpact_Then_BothOffersInResponse")
    @Tag("MultiMonth")
    @Tag("VER-852")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber has a multimonth offer that has end date. Also has monthly addon offer.|"
                +"|When  |Api is called. Recurring charge has mainbalance impact for addon only.|"
                +"|Then  |AoP should return details for both offers.|"})
    // @formatter:on    
    public void test_getAoP_Given_MmOffer_And_Addon_When_AddonOnlyMainbalanceImpact_Then_BothOffersInResponse(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        List<String> activeCiIds = Arrays.asList(
                CI_EXTERNAL_IDS.BASE6MONTH25, CI_EXTERNAL_IDS.WEARABLE_MONTHLY_2023);
        List<String> preActiveCiIds = Arrays.asList(CI_EXTERNAL_IDS.BASE3VIS23);
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setSubscriberExternalId("1234");
        input.setIncludeTaxDetails("N");
        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                input.getSubscriberExternalId(), activeCiIds, preActiveCiIds);
        MtxTimestamp mmEndDate = subscription.getAtPurchasedOfferArray(
                0).getCycleInfo().getCycleEndTime();
        subscription.getAtPurchasedOfferArray(0).setEndTime(mmEndDate);
        subscription.getAtPurchasedOfferArray(2).setAutoActivationTime(mmEndDate);

        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                input.getSubscriberExternalId(), activeCiIds, preActiveCiIds);
        subscriptionResponse.getAtPurchasedOfferArray(0).setEndTime(mmEndDate);
        subscriptionResponse.getAtPurchasedOfferArray(2).setAutoActivationTime(mmEndDate);
        System.out.println(subscriptionResponse.toJson());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        emulateMtxResponsePricingCatalogItems(
                instance, List.of(CI_EXTERNAL_IDS.BASE6MONTH25, CI_EXTERNAL_IDS.BASE3VIS23));
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateAocServicePurchase(instance);

        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());

        // method to test
        instance.getAOP(input, output);
        printUnitTest(input.toJson());
        printUnitTest(output.toJson());

        MtxPurchasedOfferInfo po1 = subscriptionResponse.getAtPurchasedOfferArray(0);
        VisibleOfferDetails vod1 = output.getAtVisibleOfferDetailsList(1);
        assertEquals(po1.getCatalogItemExternalId(), vod1.getCatalogItemExternalId());
        assertEquals(po1.getResourceId() + "", vod1.getResourceId());

        MtxPurchasedOfferInfo po2 = subscriptionResponse.getAtPurchasedOfferArray(1);
        VisibleOfferDetails vod2 = output.getAtVisibleOfferDetailsList(0);
        assertEquals(po2.getCatalogItemExternalId(), vod2.getCatalogItemExternalId());
        assertEquals(po2.getResourceId() + "", vod2.getResourceId());
    }

    @ParameterizedTest(
            name = "test_getAoP_When_InsurancHasVendorPayable_Then_TaxRequestHasVendorPayable")
    @Tag("Tax")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber has insurance offer that has vendor payable non prorated.|"                        
                +"|When  |Api is called.|"
                +"|Then  |AoP should call taxapi with vendor payable.|"})
    // @formatter:on    
    public void test_getAoP_When_InsurancHasVendorPayable_Then_TaxRequestHasVendorPayable(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");

        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.INSURANCE);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);

        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());

        System.out.println(subscriptionResponse.toJson());
        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItems(instance, ciExternalIds);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateAocServicePurchase(instance);

        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.INSURANCE));
            // method to test
            instance.getAOP(input, output);
        }

        ServiceTaxResponse taxRespServiceAsPromoJson = CommonTestHelper.getJsonFromString(
                ServiceTaxResponse.class, argumentCaptor.getValue());
        System.out.println(argumentCaptor.getValue());
        assertNotNull(taxRespServiceAsPromoJson.getVendorPayable());
        assertNotNull(taxRespServiceAsPromoJson.getVendorPayableNonProrated());
    }

    @ParameterizedTest(
            name = "test_getAoP_When_InsurancHasVendorPayable_Then_TaxRequestHasVendorPayable")
    @Tag("Tax")
    @Tag("VER-830")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Insurance offer tax of last month has vendor payable non prorated.|"                        
                +"|When  |AoP is called.|"
                +"|Then  |AoP should call taxapi with (vendor_payable == vendor_payable_non_prorated).|"
                +"|Comments |AoP is for full month. Prorated and nonprorated values should be equal.|"})
    // @formatter:on    
    public void test_getAoP_When_LastMonthHasVendorPayable_Then_VendorPayable_Equals_VendorPayableNonProrated(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");

        BigDecimal vendorPayable = BigDecimal.ONE;
        BigDecimal vendorPayableNonProrated = BigDecimal.valueOf(8);
        List<String> ciExternalIds = Arrays.asList(CI_EXTERNAL_IDS.INSURANCE);
        MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription(
                ciExternalIds);

        SubscriptionResponse subscriptionResponse = CommonTestHelper.getSubscriptionResponse(
                ciExternalIds);
        input.setSubscriberExternalId(subscriptionResponse.getExternalId());
        VisiblePurchasedOfferExtension attr = (VisiblePurchasedOfferExtension) subscriptionResponse.getAtPurchasedOfferArray(
                0).getAttr();
        ServiceTaxResponse lastMonthTaxResponse = CommonTestHelper.getJsonFromString(
                ServiceTaxResponse.class, attr.getTaxDetails());
        lastMonthTaxResponse.setDiscountPrice(
                CommonTestHelper.getOfferPrice(CI_EXTERNAL_IDS.INSURANCE));
        lastMonthTaxResponse.setVendorPayableNonProrated(vendorPayableNonProrated);
        lastMonthTaxResponse.setVendorPayable(vendorPayable);
        attr.setTaxDetails(lastMonthTaxResponse.toJson());
        System.out.println(lastMonthTaxResponse.toJsonPretty());

        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                subscriptionResponse);

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponsePricingCatalogItems(instance, ciExternalIds);

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();
        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        emulateMtxResponseSubscription(instance, subscription);
        emulateSubscriptionResponse(instance, subscriptionResponse);
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateAocServicePurchase(instance);

        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.INSURANCE));
            // method to test
            instance.getAOP(input, output);
        }
        printUnitTest(output.toJson());
        ServiceTaxRequest taxRequestAdvice = CommonTestHelper.getJsonFromString(
                ServiceTaxRequest.class, argumentCaptor.getValue());
        printUnitTest(taxRequestAdvice.toJsonPretty());
        assertEquals(
                vendorPayableNonProrated.floatValue(),
                taxRequestAdvice.getVendorPayable().floatValue());
        assertEquals(
                vendorPayableNonProrated.floatValue(),
                taxRequestAdvice.getVendorPayableNonProrated().floatValue());
    }

    @SuppressWarnings({
        "unchecked"
    })
    @ParameterizedTest(name = "test_getAOP_Given_HasPayer_Then_TaxWithPayerGeoDocde")
    @Tag("Tax")
    @Tag("VER-771")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given |Subscriber gets paid by payer for recurring services.|"                        
                +"|When  |Api is called.|"
                +"|Then  |AoP should call taxapi with payers geocode.|"})
    // @formatter:on    

    public void test_getAOP_Given_HasPayer_Then_TaxWithPayerGeoDocde(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        String payerGeoCode = "ELBISIVNOZIREV";

        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");
        input.setSubscriberExternalId("12345");

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        String payerExternalID = "67890";
        List<String> ciExternalIds = List.of(CI_EXTERNAL_IDS.PRO25);
        MtxObjectId caGroupId = new MtxObjectId("1-2-3-4");

        SubscriptionResponse benSubResponse = CommonTestHelper.getSubscriptionResponse(
                input.getSubscriberExternalId(), ciExternalIds);
        benSubResponse.getParentGroupIdArrayAppender().add(caGroupId);
        SubscriptionResponse paySubResponse = CommonTestHelper.getEmptySubscriptionResponse(
                payerExternalID);
        paySubResponse.getParentGroupIdArrayAppender().add(caGroupId);
        VisibleSubscriberExtension attr = (VisibleSubscriberExtension) paySubResponse.getAttr();
        attr.setGeoCode(payerGeoCode);

        doReturn(benSubResponse).doReturn(paySubResponse).when(instance).querySubscriptionByRQT(
                any(), any(), any());

        MtxResponseSubscription benSub = CommonTestHelper.getMtxResponseSubscription(
                input.getSubscriberExternalId(), ciExternalIds);
        benSub.getParentGroupIdArrayAppender().add(caGroupId);
        doReturn(benSub).doReturn(paySubResponse).when(instance).querySubscriptionData(
                any(), any());

        MtxResponseMulti responseGroupMulti = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseGroup respGrp = CommonTestHelper.getMtxResponseGroupCA(
                benSubResponse.getExternalId(), "CAGroup",
                List.of(benSubResponse.getObjectId().toString(), "1-2-3-4", "6-7-8-9"),
                List.of("Ben:" + benSubResponse.getExternalId() + "#Pay:" + payerExternalID));
        responseGroupMulti.appendResponseList(respGrp);
        doReturn(responseGroupMulti).when(instance).querySubscriptionGroups(any(), any(), any());

        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                benSubResponse);

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, benSub);
        emulateAocServicePurchase(instance);
        emulateMtxResponsePricingCatalogItems(instance, Arrays.asList(CI_EXTERNAL_IDS.PRO25));
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + benSub.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());

        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
        String taxApiResp = CommonTestHelper.getTaxApiResp(CI_EXTERNAL_IDS.PRO25);

        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxApiResp);
            // method to test
            instance.getAOP(input, output);
        }
        System.out.println(output.toJson());
        argumentCaptor.getAllValues().forEach(taxReq -> {
            System.out.println(taxReq);
        });

        ObjectMapper om = TestUtils.getObjectMapper();
        ServiceTaxRequest req = om.readValue(
                argumentCaptor.getAllValues().get(0), ServiceTaxRequest.class);
        System.out.println(
                testInfo.getDisplayName() + " : " + req.getMsgID() + "-" + req.getGeocode());

        assertEquals(payerGeoCode, req.getGeocode());
        assertTrue(req.getMsgID().contains("Payer:" + payerExternalID));
    }

    @SuppressWarnings({
        "unchecked"
    })
    @ParameterizedTest(name = "test_getAOP_Given_HasPayer_Has_Promos_Then_TaxWithPayerGeoDocde")
    @Tag("Tax")
    @Tag("VER-771")
    // @formatter:off
    @CsvSource(delimiter = '|', value={
                 "|Given|Subscriber has promos.|"
                +"|     |Subscriber gets paid by payer for recurring services.|"
                +"|When |Api is called.|"
                +"|Then |AoP should call taxapi with payers geocode, for promos.|"})
    // @formatter:on    
    public void test_getAOP_Given_HasPayer_Has_Promos_Then_TaxWithPayerGeoDocde(ArgumentsAccessor acceptance)
            throws Exception {
        TestDescription td = new TestDescription(testInfo, acceptance);
        td.printDescription();
        String payerGeoCode = "ELBISIVNOZIREV";
        VisibleRequestPaymentAdviceService input = new VisibleRequestPaymentAdviceService();
        input.setIncludeTaxDetails("Y");
        input.setSubscriberExternalId("12345");

        VisibleResponsePaymentAdviceService output = new VisibleResponsePaymentAdviceService();

        String payerExternalID = "67890";
        String baseService = CI_EXTERNAL_IDS.PLUS_CURRENT;
        List<String> ciExternalIds = List.of(baseService);
        MtxObjectId caGroupId = new MtxObjectId("1-2-3-4");

        SubscriptionResponse benSubResponse = CommonTestHelper.getSubscriptionResponse(
                input.getSubscriberExternalId(), ciExternalIds);
        benSubResponse.getParentGroupIdArrayAppender().add(caGroupId);
        SubscriptionResponse paySubResponse = CommonTestHelper.getEmptySubscriptionResponse(
                payerExternalID);
        paySubResponse.getParentGroupIdArrayAppender().add(caGroupId);
        VisibleSubscriberExtension attr = (VisibleSubscriberExtension) paySubResponse.getAttr();
        attr.setGeoCode(payerGeoCode);

        doReturn(benSubResponse).doReturn(paySubResponse).when(instance).querySubscriptionByRQT(
                any(), any(), any());

        MtxResponseSubscription benSub = CommonTestHelper.getMtxResponseSubscription(
                input.getSubscriberExternalId(), ciExternalIds);
        benSub.getParentGroupIdArrayAppender().add(caGroupId);
        doReturn(benSub).doReturn(paySubResponse).when(instance).querySubscriptionData(
                any(), any());

        MtxResponseMulti responseGroupMulti = CommonTestHelper.getEmptyMtxResponseMulti();
        MtxResponseGroup respGrp = CommonTestHelper.getMtxResponseGroupCA(
                benSubResponse.getExternalId(), "CAGroup",
                List.of(benSubResponse.getObjectId().toString(), "1-2-3-4", "6-7-8-9"),
                List.of("Ben:" + benSubResponse.getExternalId() + "#Pay:" + payerExternalID));
        responseGroupMulti.appendResponseList(respGrp);
        doReturn(responseGroupMulti).when(instance).querySubscriptionGroups(any(), any(), any());

        AppPropertyProvider.getInstance().setProperty(CREDIT_CONSTANTS.AOC_GRANT_OFFERS, "");

        MtxResponseRecurringChargeInfo chargeInfo = CommonTestHelper.getMtxResponseRecurringChargeInfo(
                benSubResponse);

        emulateMtxResponsePricingCatalogItems(
                instance,
                Arrays.asList(baseService, CI_EXTERNAL_IDS.GRANT_GOODWILL));

        MtxBalanceInfo mbiGoodGrant = CommonTestHelper.getMtxBalanceInfoForPromoGrant(
                CI_EXTERNAL_IDS.GRANT_GOODWILL, BigDecimal.valueOf(20));
        benSub.getBalanceArrayAppender().add(mbiGoodGrant);
        MtxBalanceInfo mbiGoodConsump = CommonTestHelper.getMtxBalanceInfoForPromoConsumable(
                CI_EXTERNAL_IDS.GRANT_GOODWILL, BigDecimal.ZERO);
        benSub.getBalanceArrayAppender().add(mbiGoodConsump);

        MtxResponsePricingCatalogItem pciGoodwill = emulateMtxResponsePricingCatalogItem(
                instance, CI_EXTERNAL_IDS.GRANT_GOODWILL);
        VisibleTemplate vtGoodwill = (VisibleTemplate) pciGoodwill.getCatalogItemInfo().getTemplateAttr();
        vtGoodwill.setTaxResponseUnchanged("N");

        // mocks
        doReturn("").when(instance).getRoute(any());
        doReturn(null).when(instance).queryDeviceData(any(), any(), any());
        doReturn("[" + benSub.getExternalId() + "]").when(instance).getLoggingKey(any());
        doReturn(CommonTestHelper.getMtxResponseDevice_Default()).when(instance).queryDeviceData(
                any(), any(), any());
        emulateMtxResponseRecurringChargeInfo(api, chargeInfo);
        emulateMtxResponseMulti_CreditBalances(instance, benSub);
        emulateAocServicePurchase(instance);

        ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);
        String taxRespServiceAsPromo = CommonTestHelper.getTaxApiResp(baseService);
        try (MockedStatic<TaxApiClient> mockedStatic = Mockito.mockStatic(TaxApiClient.class)) {
            mockedStatic.when(
                    () -> TaxApiClient.getTaxApiResult(any(), argumentCaptor.capture())).thenReturn(
                            taxRespServiceAsPromo);
            instance.getAOP(input, output);
        }
        System.out.println(testInfo.getDisplayName() + " : " + input.toJson());
        System.out.println(testInfo.getDisplayName() + " : " + output.toJson());
        
        argumentCaptor.getAllValues().forEach(req -> {
            System.out.println(testInfo.getDisplayName() + " : " + req);
        });

        ObjectMapper om = TestUtils.getObjectMapper();
        ServiceTaxRequest req = om.readValue(
                argumentCaptor.getAllValues().get(1), ServiceTaxRequest.class);
        System.out.println(
                testInfo.getDisplayName() + " : " + req.getMsgID() + "-" + req.getGeocode());

        assertEquals(payerGeoCode, req.getGeocode());
        assertTrue(req.getMsgID().contains("Payer:" + payerExternalID));
    }

    private void printUnitTest(Object msg) {
        System.out.println(testInfo.getDisplayName() + ":" + msg);
    }
}
