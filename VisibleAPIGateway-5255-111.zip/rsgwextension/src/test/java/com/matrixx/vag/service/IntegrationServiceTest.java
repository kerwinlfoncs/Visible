package com.matrixx.vag.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import com.matrixx.datacontainer.MtxObjectId;
import com.matrixx.datacontainer.SubscriberManagementApi;
import com.matrixx.datacontainer.mdc.BalanceInfo;
import com.matrixx.datacontainer.mdc.MtxBalanceImpactInfo;
import com.matrixx.datacontainer.mdc.MtxBalanceImpactInfoGroup;
import com.matrixx.datacontainer.mdc.MtxBalanceInfo;
import com.matrixx.datacontainer.mdc.MtxBraintreeResponseExtension;
import com.matrixx.datacontainer.mdc.MtxPurchasedOfferData;
import com.matrixx.datacontainer.mdc.MtxRequestMulti;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberAddPaymentMethod;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberModifyPaymentMethod;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberRemovePaymentMethod;
import com.matrixx.datacontainer.mdc.MtxRequiredBalanceInfo;
import com.matrixx.datacontainer.mdc.MtxResponse;
import com.matrixx.datacontainer.mdc.MtxResponseAdd;
import com.matrixx.datacontainer.mdc.MtxResponseCancel;
import com.matrixx.datacontainer.mdc.MtxResponseDevice;
import com.matrixx.datacontainer.mdc.MtxResponseMulti;
import com.matrixx.datacontainer.mdc.MtxResponsePaymentHistory;
import com.matrixx.datacontainer.mdc.MtxResponsePaymentMethodInfo;
import com.matrixx.datacontainer.mdc.MtxResponsePricingBillingCycle;
import com.matrixx.datacontainer.mdc.MtxResponsePricingCatalogItem;
import com.matrixx.datacontainer.mdc.MtxResponsePricingOffer;
import com.matrixx.datacontainer.mdc.MtxResponsePurchase;
import com.matrixx.datacontainer.mdc.MtxResponseRecharge;
import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import com.matrixx.datacontainer.mdc.MtxResponseUser;
import com.matrixx.datacontainer.mdc.MtxResponseWallet;
import com.matrixx.datacontainer.mdc.MtxSubscriberSearchData;
import com.matrixx.datacontainer.mdc.SubscriptionResponse;
import com.matrixx.datacontainer.mdc.VisibleRiskData;
import com.matrixx.datacontainer.rest.RestQueryTerm;
import com.matrixx.platform.JsonObject;
import com.matrixx.vag.CommonTestHelper;
import com.matrixx.vag.TestDescription;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.Constants.PAYMENT_CONSTANTS;
import com.matrixx.vag.common.Constants.REQUEST_QUERY_TERM_PREFIX;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.common.TestConstants.BALANCE_NAMES;
import com.matrixx.vag.common.TestConstants.CI_EXTERNAL_IDS;
import com.matrixx.vag.common.TestConstants.DATA_DIR;
import com.matrixx.vag.common.request.builder.MtxPurchasedOfferDataBuilder;
import com.matrixx.vag.exception.VisibleUnitTestException;
import com.matrixx.vag.subscriber.service.SubscriberService;
import com.matrixx.vag.util.MDCTest;

public class IntegrationServiceTest extends MDCTest {
	@Spy
	@InjectMocks
	private final IntegrationService instance = new SubscriberService();
	
	@Mock
    private SubscriberManagementApi api;
    
    @BeforeEach
    public void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);
    }

    //Use PaymentAdviceService for convenience of testing

    @Test
    public void getRiskDataTests()
            throws IOException, VisibleUnitTestException {

        MtxResponseMulti multiManualPay = CommonTestHelper.loadJsonMessage(
                MtxResponseMulti.class,
                "src/test/resources/data/manualpay/MtxResponseMulti_ManualPay_MTXTAX_400.json");
        int rechargeIndex = 0;

        IntegrationService instance = Mockito.mock(IntegrationService.class, Mockito.CALLS_REAL_METHODS);
        
        VisibleRiskData riskData = instance.getRiskData(multiManualPay.getResponseList(), rechargeIndex);
        assertEquals(PAYMENT_CONSTANTS.DEFAULT_RISK_DATA, riskData.getRiskDataDeviceDataCaptured());
        riskData = instance.getRiskData(multiManualPay.getResponseList(), -1);
        assertEquals(PAYMENT_CONSTANTS.DEFAULT_RISK_DATA, riskData.getRiskDataDeviceDataCaptured());
        riskData = instance.getRiskData(
                multiManualPay.getResponseList(), multiManualPay.getResponseList().size());
        assertEquals(PAYMENT_CONSTANTS.DEFAULT_RISK_DATA, riskData.getRiskDataDeviceDataCaptured());

        // When Braintree response is available:
        MtxBraintreeResponseExtension braintreeResponse = new MtxBraintreeResponseExtension();
        braintreeResponse.setRiskDataId("12345");
        braintreeResponse.setRiskDataDecision("Sample");
        braintreeResponse.setRiskDataDeviceDataCaptured(true);
        MtxResponseRecharge rechargeResp = (MtxResponseRecharge) multiManualPay.getResponseList().get(
                rechargeIndex);
        rechargeResp.setPaymentGatewayResponseAttr(braintreeResponse);
        riskData = instance.getRiskData(multiManualPay.getResponseList(), rechargeIndex);
        assertEquals("0", riskData.getRiskDataDeviceDataCaptured());
        assertEquals(braintreeResponse.getRiskDataId(), riskData.getRiskDataId());

        braintreeResponse.setRiskDataId(null);
        braintreeResponse.setRiskDataDeviceDataCaptured(false);
        riskData = instance.getRiskData(multiManualPay.getResponseList(), rechargeIndex);
        assertEquals("1", riskData.getRiskDataDeviceDataCaptured());
        assertNull(riskData.getRiskDataId());
    }

    @Test
    // Testing getCurrencyAmount method in Integration Service
    public void test_getCurrencyAmount_NoError_CurrencyAmountReturned() throws Exception {
    	
        //IntegrationService instance = Mockito.mock(IntegrationService.class, Mockito.CALLS_REAL_METHODS);
        
        MtxResponsePurchase aocResp = CommonTestHelper.loadJsonMessage(
                MtxResponsePurchase.class, DATA_DIR.PAYMENT_ADVICE + "MtxResponsePurchase.json");
        ArrayList<MtxBalanceImpactInfoGroup> bigl = aocResp.getPurchaseInfoArray().get(
                0).getBalanceImpactGroupList();
        BigDecimal currencyAmount = CommonUtils.getCurrencyAmount(bigl);

        BigDecimal expectedCurrencyAmount = BigDecimal.ZERO;

        for (MtxBalanceImpactInfoGroup biig : bigl) {
            for (MtxBalanceImpactInfo bii : biig.getBalanceImpactList()) {
                if (bii.getBalanceClassId().longValue() == 840) {
                    expectedCurrencyAmount = expectedCurrencyAmount.add(bii.getImpactAmount());
                }
            }
        }

        assertEquals(expectedCurrencyAmount.doubleValue(), currencyAmount.doubleValue(), 0.01);
    }
    
	@SuppressWarnings("unchecked")
	@Test
    public void test_getAocCurrencyBalanceImpactInfo_When_Always_Then_ReturnCurrencyBalancesOnly(TestInfo testInfo) throws Exception {
    	TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[]	{"IntegrationService.getAocCurrencyBalanceImpactInfo Method"};
        td.when = new String[]{"Always.", };
        td.then = new String[]{"Currency balances are returned. Other balances are dropped."};
        td.printDescription();
		MtxPurchasedOfferDataBuilder poDataBuilder =
    			(new MtxPurchasedOfferDataBuilder())                		
    			.withOfferExternalId(CI_EXTERNAL_IDS.PLUS3ANNUAL)
    			.withAmount(BigDecimal.valueOf(395));
    	
    	MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
    	searchData.setExternalId("1234");

        Map<String, BigDecimal> balImpactMap = new HashMap<String, BigDecimal>();
        balImpactMap.put("Visible_MultiMonth_Counter", BigDecimal.ONE);
        balImpactMap.put("Visible_FreeTP_Counter", BigDecimal.ONE);
        MtxResponsePurchase mainResponse = CommonTestHelper.getMtxResponsePurchaseMultiBalance(CI_EXTERNAL_IDS.PLUS3ANNUAL, BigDecimal.ZERO, null);
        MtxRequiredBalanceInfo rbi = new MtxRequiredBalanceInfo();
        rbi.setResourceId(1L);
        rbi.setTemplateId(BigInteger.valueOf(2));
        mainResponse.getAtPurchaseInfoArray(0).getRequiredBalanceArrayAppender().add(rbi);
        
        List<MtxBalanceImpactInfoGroup> temp = new ArrayList<MtxBalanceImpactInfoGroup>();
        MtxResponsePurchase counterResponse = CommonTestHelper.getMtxResponsePurchaseMultiBalance(CI_EXTERNAL_IDS.PLUS3VIS23, BigDecimal.ZERO, null,balImpactMap, true);
        mainResponse.getAtPurchaseInfoArray(0).getBalanceImpactGroupList().forEach(biig->{
        	temp.add(biig);
        });
        counterResponse.getAtPurchaseInfoArray(0).getBalanceImpactGroupList().forEach(biig->{
        	temp.add(biig);
        });
        mainResponse.getAtPurchaseInfoArray(0).getBalanceImpactGroupListAppender().addAll(temp);
        
        doReturn(mainResponse).when(api).subscriberPurchaseOffer(any());

        System.out.println(mainResponse.toJson());
        
    	MtxResponsePurchase aoc = instance.getAocCurrencyBalanceImpactInfo("[1234]",
        		CI_EXTERNAL_IDS.PLUS3ANNUAL, poDataBuilder.build(), "1234");
    	List<String> balList = new ArrayList<String>();
    	aoc.getAtPurchaseInfoArray(0).getAtBalanceImpactGroupList(0).getBalanceImpactList().forEach(bii->{
    		balList.add(bii.getBalanceTemplateName());
    	});
        assertFalse(balList.contains("Visible_MultiMonth_Counter"));
        assertFalse(balList.contains("Visible_FreeTP_Counter"));
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
    public void test_querySubscriptionByRQT_When_Always_Then_ReturnCurrencyBalances(TestInfo testInfo) throws Exception {
    	TestDescription td = new TestDescription();
        td.testInfo = testInfo;
        td.given = new String[]	{"IntegrationService.querySubscriptionByRQT Method"};
        td.when = new String[]{"Always."};
        td.then = new String[]{"Mainbalance is returned in wallet balances.", "Purchased offer is returned with catalog item"};
        td.comments = new String[]{"Not able to tes due to No Visibility of protected method postCallTransform."};
        td.printDescription();
        String subscriptionExternalId = "123";
        RestQueryTerm rqt = new RestQueryTerm(REQUEST_QUERY_TERM_PREFIX.EXTERNAL_ID+subscriptionExternalId);

        SubscriptionResponse subResp = CommonTestHelper.getSubscriptionResponse(subscriptionExternalId,Arrays.asList(CI_EXTERNAL_IDS.BASE3VIS23)); 
        BalanceInfo bi1 = CommonTestHelper.getBalanceInfo(BALANCE_NAMES.GIFT_CONSUMABLE, 1l, 2l, BigDecimal.TEN);
        subResp.getWalletBalancesAppender().add(bi1);
        
        doAnswer(new Answer() {            
			public Object answer(InvocationOnMock invocation) {
                return null;
            }})
         .when(instance).service_subscription_query(any(),any(),any(),any(),any());
        doReturn(subResp).when(instance).callSubscriptionResponseTransform(any());
        
        System.out.println(td.getTestMethod()+" From Engine:"+subResp.toJson());
        SubscriptionResponse resp = instance.querySubscriptionByRQT("","",rqt);
        
        JsonObject jo = new JsonObject();
        resp.getAtPurchasedOfferArray(0).toJson(jo);
        assertNull(jo.get("BundleDetails"));
        assertNull(jo.get("OfferDetails"));
        assertNull(jo.get("MetadataList"));
        assertEquals("United States dollar",resp.getAtWalletBalances(0).getClassName());
	}
	
	@Test
    public void test_querySubscriptionByObjectId_When_EngineReturnsSub_Then_Success(TestInfo testInfo) throws Exception {
    	TestDescription td = new TestDescription();
    	td.testInfo = testInfo;
    	td.when = new String[] { "Engine returns sub."};
    	td.then = new String[] { "No Exception." };
    	td.printDescription();

		doReturn(new SubscriptionResponse()).when(instance).querySubscriptionByRQT(any(),any(),any());
		SubscriptionResponse resp = instance.querySubscriptionByObjectId("","","");
		assertNotNull(resp);
	}
	
	@Test
    public void test_querySubscriptionByExternalId_When_EngineReturnsSub_Then_Success(TestInfo testInfo) throws Exception {
    	TestDescription td = new TestDescription();
    	td.testInfo = testInfo;
    	td.when = new String[] { "Engine returns sub."};
    	td.then = new String[] { "No Exception." };
    	td.printDescription();

		doReturn(new SubscriptionResponse()).when(instance).querySubscriptionByRQT(any(),any(),any());
		SubscriptionResponse resp = instance.querySubscriptionByExternalId("","","");
		assertNotNull(resp);
	}
	
	@Test
    public void test_querySubscriptionData_When_EngineReturnsSub_Then_Success(TestInfo testInfo) throws Exception {
    	TestDescription td = new TestDescription();
    	td.testInfo = testInfo;
    	td.when = new String[] { "Engine returns sub."};
    	td.then = new String[] { "No Exception." };
    	td.printDescription();

		doReturn(new MtxResponseSubscription()).when(api).subscriptionQuery(any());
		MtxResponseSubscription resp = instance.querySubscriptionData("","");
		assertNotNull(resp);
	}
	
	@Test
    public void test_queryUserByObjectId_When_EngineReturnsUser_Then_Success(TestInfo testInfo) throws Exception {
    	TestDescription td = new TestDescription();
    	td.testInfo = testInfo;
    	td.when = new String[] { "Engine returns user."};
    	td.then = new String[] { "No Exception." };
    	td.printDescription();

		doReturn(new MtxResponseUser()).when(api).userQuery(any());
		MtxResponseUser resp = instance.queryUserByObjectId("",null);
		assertNotNull(resp);
	}

	@Test
    public void test_queryUserByObjectId_When_EngineException_Then_Exception(TestInfo testInfo) throws Exception {
    	TestDescription td = new TestDescription();
    	td.testInfo = testInfo;
    	td.when = new String[] { "Engine does not return user."};
    	td.then = new String[] { "Exception." };
    	td.printDescription();
		
        doThrow(new RuntimeException("Test Message")).when(api).userQuery(any());
    	MtxResponseUser resp = instance.queryUserByObjectId("",null);
        System.out.println(td.getTestMethod()+":"+resp.toJson());

        assertEquals("Test Message",resp.getResultText());
        assertEquals(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,resp.getResult());
    }

	@Test
    public void test_querySubscriptionDataByObjectId_When_EngineReturnsSub_Then_Success(TestInfo testInfo) throws Exception {
    	TestDescription td = new TestDescription();
    	td.testInfo = testInfo;
    	td.when = new String[] { "Engine returns sub."};
    	td.then = new String[] { "No Exception." };
    	td.printDescription();

		doReturn(new MtxResponseSubscription()).when(api).subscriptionQuery(any());
		MtxResponseSubscription resp = instance.querySubscriptionDataByObjectId("","1-2-3-4");
		assertNotNull(resp);
	}
	
	@Test
	 public void test_querySubscriptionDataByObjectId_When_EngineReturnsNull_Then_Error(TestInfo testInfo) throws Exception {
    	TestDescription td = new TestDescription();
    	td.testInfo = testInfo;
    	td.when = new String[] { "Engine returns sub."};
    	td.then = new String[] { "No Exception." };
    	td.printDescription();

		doReturn((MtxResponseSubscription)null).when(api).subscriptionQuery(any());
		MtxResponseSubscription resp = instance.querySubscriptionDataByObjectId("","1-2-3-4");
		assertNull(resp);
	}

	@SuppressWarnings("unchecked")
	@Test
    public void test_querySubscriptionGroups_When_EngineReturnsGroup_Then_Success(TestInfo testInfo) throws Exception {
    	TestDescription td = new TestDescription();
    	td.testInfo = testInfo;
    	td.when = new String[] { "Engine returns group."};
    	td.then = new String[] { "No Exception." };
    	td.printDescription();

		doReturn(new MtxResponseMulti()).when(instance).multiRequest(any(),any(),any());
		MtxResponseSubscription subscription = CommonTestHelper.getMtxResponseSubscription();
        subscription.getBalanceArrayAppender().clear();
        MtxBalanceInfo biMainbalance = CommonTestHelper.getMtxBalanceInfo(BALANCE_NAMES.MAIN_BALANCE, null, null, null);
        subscription.getBalanceArrayAppender().add(biMainbalance);
        subscription.setParentGroupCount(1L);
        subscription.appendParentGroupIdArray(new MtxObjectId("1-2-3-4"));
		MtxResponseMulti resp = instance.querySubscriptionGroups("","", subscription);
		assertNotNull(resp);
	}
	
	@Test
    public void test_querySubscriptionWallet_When_EngineReturnsWallet_Then_Success(TestInfo testInfo) throws Exception {
    	TestDescription td = new TestDescription();
    	td.testInfo = testInfo;
    	td.when = new String[] { "Engine returns wallet."};
    	td.then = new String[] { "No Exception." };
    	td.printDescription();

		doReturn(new MtxResponseWallet()).when(api).subscriberQueryWallet(any(),any());
        MtxResponseWallet resp = instance.querySubscriptionWallet("","", "");
		assertNotNull(resp);
	}
	
	@Test
    public void test_querySubscriberPaymentHistory_When_EngineReturnsHistory_Then_Success(TestInfo testInfo) throws Exception {
    	TestDescription td = new TestDescription();
    	td.testInfo = testInfo;
    	td.when = new String[] { "Engine returns payment history."};
    	td.then = new String[] { "No Exception." };
    	td.printDescription();

		doReturn(new MtxResponsePaymentHistory()).when(api).subscriberQueryPaymentHistory(any(),any());
		MtxSubscriberSearchData sd= new MtxSubscriberSearchData(); 
		MtxResponsePaymentHistory resp = instance.querySubscriberPaymentHistory("","", sd);
		assertNotNull(resp);
	}

	@Test
    public void test_queryDeviceData_When_EngineReturnsDevice_Then_Success(TestInfo testInfo) throws Exception {
    	TestDescription td = new TestDescription();
    	td.testInfo = testInfo;
    	td.when = new String[] { "Engine returns device data."};
    	td.then = new String[] { "No Exception." };
    	td.printDescription();

		doReturn(new MtxResponseDevice()).when(api).deviceQuery(any(),any());
		MtxResponseDevice resp = instance.queryDeviceData("","", new MtxObjectId("1-2-3-4"));
		assertNotNull(resp);
	}
	
	@Test
    public void test_queryPricingOffer_When_EngineReturnsPricing_Then_Success(TestInfo testInfo) throws Exception {
    	TestDescription td = new TestDescription();
    	td.testInfo = testInfo;
    	td.when = new String[] { "Engine returns pricing data."};
    	td.then = new String[] { "No Exception." };
    	td.printDescription();

    	MtxResponsePricingCatalogItem pci = CommonTestHelper.getMtxResponsePricingCatalogItem(CI_EXTERNAL_IDS.PLUS3VIS23);
		doReturn(pci).when(instance).queryPricingCatalogItem(any(),any(),any());
		doReturn(new MtxResponsePricingOffer()).when(api).pricingQueryOffer(any(),any());
		MtxResponsePricingOffer resp = instance.queryPricingOffer("","","");
		assertNotNull(resp);
	}
	
	@Test
    public void test_queryPricingProductOffer_When_EngineReturnsPricing_Then_Success(TestInfo testInfo) throws Exception {
    	TestDescription td = new TestDescription();
    	td.testInfo = testInfo;
    	td.when = new String[] { "Engine returns pricing data."};
    	td.then = new String[] { "No Exception." };
    	td.printDescription();

		doReturn(new MtxResponsePricingOffer()).when(api).pricingQueryOffer(any(),any());
		MtxResponsePricingOffer resp = instance.queryPricingProductOffer("","", BigInteger.ONE);
		assertNotNull(resp);
	}
	
	@Test
    public void test_queryPricingCatalogItem_When_EngineReturnsPricing_Then_Success(TestInfo testInfo) throws Exception {
    	TestDescription td = new TestDescription();
    	td.testInfo = testInfo;
    	td.when = new String[] { "Engine returns pricing data."};
    	td.then = new String[] { "No Exception." };
    	td.printDescription();

		doReturn(new MtxResponsePricingCatalogItem()).when(api).pricingQueryCatalogItem(any(),any());
		MtxResponsePricingCatalogItem resp = instance.queryPricingCatalogItem("","", "");
		assertNotNull(resp);
	}
	
	@Test
    public void test_multiRequest_When_EngineReturnsResponse_Then_Success(TestInfo testInfo) throws Exception {
    	TestDescription td = new TestDescription();
    	td.testInfo = testInfo;
    	td.when = new String[] { "Engine returns pricing data."};
    	td.then = new String[] { "No Exception." };
    	td.printDescription();

		doReturn(new MtxResponseMulti()).when(api).multi(any(),any());
		MtxResponseMulti resp = instance.multiRequest("","",new MtxRequestMulti());
		assertNotNull(resp);
	}
	
	@Test
    public void test_doSubscriberCancelOfferAOC_When_EngineReturnsAoc_Then_Success(TestInfo testInfo) throws Exception {
    	TestDescription td = new TestDescription();
    	td.testInfo = testInfo;
    	td.when = new String[] { "Engine returns pricing aoc."};
    	td.then = new String[] { "No Exception." };
    	td.printDescription();

		doReturn(new MtxResponseCancel()).when(api).subscriberCancelOffer(any(),any());
		MtxSubscriberSearchData sd= new MtxSubscriberSearchData(); 
		MtxResponseCancel resp = instance.doSubscriberCancelOfferAOC("","",1l,2l,sd);
		assertNotNull(resp);
	}
	
	@Test
    public void test_doSubscriberPurchaseOfferAOC_When_EngineReturnsAoc_Then_Success(TestInfo testInfo) throws Exception {
    	TestDescription td = new TestDescription();
    	td.testInfo = testInfo;
    	td.when = new String[] { "Engine returns pricing aoc."};
    	td.then = new String[] { "No Exception." };
    	td.printDescription();

		doReturn(new MtxResponsePurchase()).when(api).subscriberPurchaseOffer(any());
		MtxSubscriberSearchData sd= new MtxSubscriberSearchData(); 
		MtxResponsePurchase resp = instance.doSubscriberPurchaseOfferAOC("","",new MtxPurchasedOfferData(),sd);
		assertNotNull(resp);
	}

	@Test
    public void test_doSubscriberRemovePaymentMethod_When_EngineReturnsSuccess_Then_Success(TestInfo testInfo) throws Exception {
    	TestDescription td = new TestDescription();
    	td.testInfo = testInfo;
    	td.when = new String[] { "Engine returns success."};
    	td.then = new String[] { "No Exception." };
    	td.printDescription();

		doReturn(new MtxResponse()).when(api).subscriberRemovePaymentMethod(any(),any());
		MtxResponse resp = instance.doSubscriberRemovePaymentMethod("","",new MtxRequestSubscriberRemovePaymentMethod());
		assertNotNull(resp);
	}

	@Test
    public void test_doSubscriberAddPaymentMethod_When_EngineReturnsSuccess_Then_Success(TestInfo testInfo) throws Exception {
    	TestDescription td = new TestDescription();
    	td.testInfo = testInfo;
    	td.when = new String[] { "Engine returns success."};
    	td.then = new String[] { "No Exception." };
    	td.printDescription();

		doReturn(new MtxResponseAdd()).when(api).subscriberAddPaymentMethod(any(),any());
		MtxResponseAdd resp = instance.doSubscriberAddPaymentMethod("","",new MtxRequestSubscriberAddPaymentMethod());
		assertNotNull(resp);
	}

	@Test
    public void test_getPaymentMethodInfo_When_EngineReturnsSuccess_Then_Success(TestInfo testInfo) throws Exception {
    	TestDescription td = new TestDescription();
    	td.testInfo = testInfo;
    	td.when = new String[] { "Engine returns success."};
    	td.then = new String[] { "No Exception." };
    	td.printDescription();

		doReturn(new MtxResponsePaymentMethodInfo()).when(api).subscriberQueryPaymentMethod(any(),any());		
		MtxResponsePaymentMethodInfo resp = instance.getPaymentMethodInfo(new MtxObjectId("1-2-3-4"),"","");
		assertNotNull(resp);
	}	
	
	@Test
    public void test_queryPaymentMethodInfo_When_EngineReturnsSuccess_Then_Success(TestInfo testInfo) throws Exception {
    	TestDescription td = new TestDescription();
    	td.testInfo = testInfo;
    	td.when = new String[] { "Engine returns success."};
    	td.then = new String[] { "No Exception." };
    	td.printDescription();

		doReturn(new MtxResponsePaymentMethodInfo()).when(api).subscriberQueryPaymentMethod(any(),any());		
		MtxResponsePaymentMethodInfo resp = instance.queryPaymentMethodInfo("","","");
		assertNotNull(resp);
	}
	
	@Test
    public void test_doSubscriberModifyPaymentMethod_When_EngineReturnsSuccess_Then_Success(TestInfo testInfo) throws Exception {
    	TestDescription td = new TestDescription();
    	td.testInfo = testInfo;
    	td.when = new String[] { "Engine returns success."};
    	td.then = new String[] { "No Exception." };
    	td.printDescription();

		doReturn(new MtxResponse()).when(api).subscriberModifyPaymentMethod(any(),any());		
		MtxResponse resp = instance.doSubscriberModifyPaymentMethod("","",new MtxRequestSubscriberModifyPaymentMethod());
		assertNotNull(resp);
	}
	
	@Test
    public void test_getPricingBillingCycle_When_EngineReturnsSuccess_Then_Success(TestInfo testInfo) throws Exception {
    	TestDescription td = new TestDescription();
    	td.testInfo = testInfo;
    	td.when = new String[] { "Engine returns success."};
    	td.then = new String[] { "No Exception." };
    	td.printDescription();

		doReturn(new MtxResponsePricingBillingCycle()).when(api).pricingQueryBillingCycle(any());		
		MtxResponsePricingBillingCycle resp = instance.getPricingBillingCycle("1234",BigInteger.valueOf(0));
		assertNotNull(resp);
	}	

}
