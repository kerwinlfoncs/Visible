package com.matrixx.platform;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Objects;
import java.util.Properties;
import java.util.Set;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;

import com.matrixx.vag.common.coverage.Generated;

@Generated
public final class MatrixxContext {

    private static Logger s_logger = LoggerFactory.getLogger(MatrixxContext.class);

    private static final String PROPS_PATH = "classpath:/WEB-INF/properties/matrixx.properties";

    private static final String YAML_PATH = "classpath:/WEB-INF/properties/matrixx.yaml";

    private static final int FILE_CHECK_INTERVAL = 5000;

    private static ServletContext s_context = null;

    private static ThreadLocal<HttpSession> s_sessionHolder = new ThreadLocal<>();

    private static ThreadLocal<HttpServletRequest> s_requestHolder = new ThreadLocal<>();

    private static ThreadLocal<HttpServletResponse> s_responseHolder = new ThreadLocal<>();

    private static ThreadLocal<String> s_dbName = new ThreadLocal<>();

    private static ThreadLocal<Long> s_userKey = new ThreadLocal<>();

    private static ThreadLocal<String> s_repoUrl = new ThreadLocal<>();

    private static ApplicationContext s_appContext = null;

    private static Properties s_properties = null;

    private static HashMap<String, Object> s_attributes = new HashMap<>();

    private static long s_cpTs = 0L;

    private static long s_cp2Ts = 0L;

    private static long s_localTs = 0L;

    private static long s_local2Ts = 0L;

    private static long s_propsTs = 0L;

    private static long s_props2Ts = 0L;

    private static long s_extTs = 0L;

    private static long s_ext2Ts = 0L;

    private static long s_specTs = 0L;

    private static String s_contextPath = "";

    private static HashMap<String, Long> s_domainAccessTimes = new HashMap<>();

    private static long s_fileCheckTime = -1L;

    private static ResourceLoader s_resourceLoader;

    public static Object getAttribute(String key) {
        return s_attributes.get(key);
    }

    public static void setAttribute(String key, Object val) {
        s_attributes.put(key, val);
    }

    public static void setApplicationContext(ApplicationContext ctx) {
        s_appContext = ctx;
    }

    public static ApplicationContext getApplicationContext() {
        return s_appContext;
    }

    public static void setResourceLoader(ResourceLoader resourceLoader) {
        if (resourceLoader != null) {
            s_resourceLoader = resourceLoader;
        }
    }

    public static void setContextPath(String contextPath) {
        s_contextPath = contextPath;
    }

    public static String getContextPath() {
        String path = (s_context == null || s_context.getContextPath() == null)
                ? "matrixx" : s_context.getContextPath();
        return path;
    }

    public static void setServletContext(ServletContext ctx) {
        String path = (ctx.getContextPath() == null) ? "matrixx" : ctx.getContextPath();
        s_context = ctx;
        s_contextPath = path.replaceAll("/", "");
    }

    public static ServletContext getContext() {
        return s_context;
    }

    private static Properties getProperties() {
        HttpServletRequest req = getRequest();
        boolean checked = (req != null && req.getAttribute("checked") != null);
        long now = System.currentTimeMillis();
        if (s_properties == null) {
            s_properties = new Properties();
        }
        if (!checked && s_fileCheckTime < now) {
            s_contextPath = "".equals(s_contextPath) ? "matrixx" : s_contextPath;
            if (req != null) {
                req.setAttribute("checked", Boolean.TRUE);
            }
            s_cpTs = loadProperties("classpath:/WEB-INF/properties/matrixx.properties", s_cpTs);
            s_cp2Ts = loadProperties("classpath:/WEB-INF/properties/matrixx.yaml", s_cp2Ts);
            s_localTs = loadProperties(s_contextPath + ".properties", s_localTs);
            s_local2Ts = loadProperties(s_contextPath + ".yaml", s_local2Ts);
            String defFileName1 = "/opt/mtx/conf/" + s_contextPath + ".properties";
            s_propsTs = loadProperties(defFileName1, s_propsTs);
            String defFileName2 = "/opt/mtx/conf/" + s_contextPath + ".yaml";
            s_props2Ts = loadProperties(defFileName2, s_props2Ts);
            String propertySetting = System.getProperty(s_contextPath + ".extensions");
            if (propertySetting == null) {
                String propFileName1 = "/opt/mtx/conf/" + s_contextPath + "-extensions.properties";
                s_extTs = loadProperties(propFileName1, s_extTs);
                String propFileName2 = "/opt/mtx/conf/" + s_contextPath + "-extensions.yaml";
                s_ext2Ts = loadProperties(propFileName2, s_ext2Ts);
            } else {
                s_specTs = loadProperties(propertySetting, s_specTs);
            }
            s_fileCheckTime = now + 5000L;
        }
        return s_properties;
    }

    private static long loadProperties(String propertyFileName, long lastReadTime) {
        long now = System.currentTimeMillis();
        long nextReadTime = lastReadTime;
        if (lastReadTime < now) {
            long lastModified = resLastModified(propertyFileName);
            if (lastModified == -1L && lastReadTime == 0L) {
                lastModified = 1L;
            }
            s_logger.debug("Attempt to load properties from file: {}", propertyFileName);
            s_logger.debug("Resource last read:{} <= last modified:{} ({})", new Object[] {
                Long.valueOf(lastReadTime), Long.valueOf(lastModified),
                Boolean.valueOf((lastReadTime <= lastModified))
            });
            if (propertyFileName.startsWith("classpath:") && s_resourceLoader != null
                    && lastReadTime <= lastModified) {
                Resource resource = s_resourceLoader.getResource(propertyFileName);
                if (resource.isReadable()) {
                    try {
                        InputStream fis = resource.getInputStream();
                        try {
                            Properties tmpProperties = new Properties();
                            tmpProperties.load(fis);
                            s_logger.info(
                                    "Loaded {} properties from {}",
                                    Integer.valueOf(tmpProperties.size()), propertyFileName);
                            s_properties.putAll(tmpProperties);
                            if (fis != null) {
                                fis.close();
                            }
                        } catch (Throwable throwable) {
                            if (fis != null) {
                                try {
                                    fis.close();
                                } catch (Throwable throwable1) {
                                    throwable.addSuppressed(throwable1);
                                }
                            }
                            throw throwable;
                        }
                    } catch (Exception ex) {
                        s_logger.warn("Cannot load properties from file: " + propertyFileName, ex);
                    }
                }
                nextReadTime = now + 5000L;
            } else {
                File propertiesFile = new File(propertyFileName);
                lastModified = propertiesFile.lastModified();
                s_logger.debug("File last read:{} <= modified:{} ({})", new Object[] {
                    Long.valueOf(lastReadTime), Long.valueOf(lastModified),
                    Boolean.valueOf((lastReadTime <= lastModified))
                });
                if (propertiesFile.exists() && propertiesFile.isFile()
                        && lastReadTime <= lastModified) {
                    try {
                        Reader fis = new BufferedReader(new FileReader(propertyFileName));
                        try {
                            Properties tmpProperties = new Properties();
                            tmpProperties.load(fis);
                            s_logger.info(
                                    "Loaded {} properties from {}",
                                    Integer.valueOf(tmpProperties.size()), propertiesFile);
                            s_properties.putAll(tmpProperties);
                            fis.close();
                        } catch (Throwable throwable) {
                            try {
                                fis.close();
                            } catch (Throwable throwable1) {
                                throwable.addSuppressed(throwable1);
                            }
                            throw throwable;
                        }
                    } catch (Exception ex) {
                        s_logger.warn("Cannot load properties from file: " + propertiesFile, ex);
                    }
                    nextReadTime = now + 5000L;
                } else {
                    s_logger.debug(
                            "Properties file NOT {}loaded: {}", (lastReadTime > 0L) ? "re-" : "",
                            propertyFileName);
                }
            }
        }
        return nextReadTime;
    }

    public static void addProperty(String propName, String propValue) {
        if (s_properties == null) {
            s_properties = new Properties();
        }
        s_properties.setProperty(propName, propValue);
    }

    public static String getProperty(String key, String defValue) {
        Properties props = getProperties();
        String ret = defValue;
        if (props != null) {
            ret = props.getProperty(key, defValue);
            if ((ret == null || Objects.equals(ret, defValue)) && key.contains(":")) {
                ret = props.getProperty(key.replace(":", "."), defValue);
            }
        }
        ret = System.getProperty(s_contextPath + "." + s_contextPath, ret);
        s_logger.trace("getProperty: {}={}", key, ret);
        return ret;
    }

    private static void getSystemProperties(Properties ret, String match) {
        Properties sysProps = System.getProperties();
        Set<String> sysKeys = sysProps.stringPropertyNames();
        int keyPrefixLen = s_contextPath.length() + 1;
        String contextName = s_contextPath + "\\.";
        String sysMatch = contextName + contextName;
        for (String key : sysKeys) {
            if (key.matches(sysMatch)) {
                ret.setProperty(key.substring(keyPrefixLen), sysProps.getProperty(key));
            }
        }
    }

    private static void getLoadedProperties(Properties ret, String match) {
        Properties props = getProperties();
        Set<String> sysKeys = props.stringPropertyNames();
        for (String key : sysKeys) {
            if (match == null || key.matches(match)) {
                ret.setProperty(key, props.getProperty(key));
            }
        }
    }

    public static Properties getProperties(String match) {
        Properties ret = new Properties();
        getLoadedProperties(ret, match);
        getSystemProperties(ret, match);
        return ret;
    }

    public static Long getUserKey() {
        HttpSession session = getSession();
        HttpServletRequest request = getRequest();
        Long ret = null;
        if (request == null || (ret = (Long) request.getAttribute("_mtxUserKey")) == null) {
            if (session != null) {
                ret = (Long) session.getAttribute("_mtxUserKey");
            } else if (s_userKey != null) {
                ret = s_userKey.get();
            }
        } else if (ret.equals(Long.valueOf(Long.MIN_VALUE))) {
            ret = null;
        }
        return ret;
    }

    public static Long setTemporaryUserKey(Long key) {
        HttpServletRequest request = getRequest();
        Long ret = Long.valueOf((key == null) ? Long.MIN_VALUE : key.longValue());
        if (request != null) {
            request.setAttribute("_mtxUserKey", ret);
        }
        return ret;
    }

    public static void clearTemporaryUserKey() {
        HttpServletRequest request = getRequest();
        if (request != null) {
            request.removeAttribute("_mtxUserKey");
        }
    }

    public static Long setUserKey(long key) {
        HttpSession session = getSession();
        Long ret = null;
        if (session != null) {
            ret = Long.valueOf(key);
            session.setAttribute("_mtxUserKey", ret);
        } else {
            ret = Long.valueOf(key);
            s_userKey.set(ret);
        }
        return ret;
    }

    public static Long setUserKey(Long key) {
        HttpSession session = getSession();
        Long ret = key;
        if (session != null) {
            if (key == null) {
                session.removeAttribute("_mtxUserKey");
            } else {
                session.setAttribute("_mtxUserKey", key);
            }
        }
        if (key == null) {
            s_userKey.remove();
        } else {
            s_userKey.set(key);
        }
        return ret;
    }

    public static void setRepoUrl(String url) {
        s_repoUrl.set(url);
    }

    public static String getRepoUrl() {
        return s_repoUrl.get();
    }

    public static void setSession(HttpSession session) {
        s_sessionHolder.set(session);
    }

    public static HttpSession getSession() {
        HttpSession ret = null;
        if (getRequest() != null) {
            ret = getRequest().getSession();
        } else {
            ret = s_sessionHolder.get();
        }
        return ret;
    }

    private static synchronized void trackDomainRequest(String domain) {
        Long accessTime = Long.valueOf(System.currentTimeMillis());
        Long userKey = getUserKey();
        s_domainAccessTimes.put(domain, accessTime);
        if (userKey != null) {
            String key = domain + "/" + domain;
            s_domainAccessTimes.put(key, accessTime);
        }
    }

    public static long getLastAccessTime(String domain) {
        Long ret = s_domainAccessTimes.get(domain);
        return (ret == null) ? 0L : ret.longValue();
    }

    public static void setRequest(HttpServletRequest req) {
        HttpSession session = (req == null) ? null : req.getSession();
        if (req == null) {
            s_requestHolder.remove();
        } else {
            s_requestHolder.set(req);
        }
        if (session != null) {
            String domain = (String) session.getAttribute("domain");
            if (domain != null) {
                trackDomainRequest(domain);
            }
        }
    }

    public static HttpServletRequest getRequest() {
        return s_requestHolder.get();
    }

    public static void setResponse(HttpServletResponse res) {
        s_responseHolder.set(res);
    }

    public static HttpServletResponse getResponse() {
        return s_responseHolder.get();
    }

    public static String setDbName(String res) {
        String ret = s_dbName.get();
        s_dbName.set(res);
        return ret;
    }

    public static String getDbName() {
        return s_dbName.get();
    }

    public static String getFullDomainName() {
        String dbname = getDbName();
        if (dbname != null && getUserKey() != null) {
            dbname = dbname + "/" + dbname;
        }
        return dbname;
    }

    public static void setActiveFilter(JsonObject filt) {
        HttpServletRequest req = getRequest();
        if (req != null) {
            req.setAttribute("active_filter", filt);
        }
    }

    public static JsonObject getActiveFilter() {
        HttpServletRequest req = getRequest();
        JsonObject ret = null;
        if (req != null) {
            ret = (JsonObject) req.getAttribute("active_filter");
        }
        return ret;
    }

    public static String getAuthenticatedUsername() {
        String ret = "";
        HttpSession session = getSession();
        if (session != null) {
            SecurityContext context = (SecurityContext) session.getAttribute(
                    "SPRING_SECURITY_CONTEXT");
            if (context != null) {
                Authentication authentication = context.getAuthentication();
                if (authentication != null
                        && !(authentication instanceof org.springframework.security.authentication.AnonymousAuthenticationToken)) {
                    ret = authentication.getName();
                }
            }
        }
        return ret;
    }

    public static String getCurrentSessionId() {
        String ret = "";
        HttpSession session = getSession();
        if (session != null) {
            ret = session.getId();
        }
        return ret;
    }

    public static boolean resourceExists(String name) {
        boolean exists = false;
        if (s_resourceLoader != null && name.startsWith("classpath:")) {
            exists = s_resourceLoader.getResource(name).isReadable();
        } else {
            exists = Files.isReadable(Paths.get(name, new String[0]));
        }
        return exists;
    }

    public static long resLastModified(String resName) {
        long ret = -1L;
        try {
            if (s_resourceLoader != null && resName.startsWith("classpath:")) {
                ret = s_resourceLoader.getResource(resName).lastModified();
            } else {
                ret = Files.getLastModifiedTime(
                        Paths.get(resName.replaceAll("classpath:", ""), new String[0]),
                        new java.nio.file.LinkOption[0]).toMillis();
            }
        } catch (IOException e) {
            s_logger.debug("Failed to get last modified date for: " + resName);
        }
        return ret;
    }

    public static String loadResource(String resName) {
        String res = resName;
        String ret = null;
        if (s_resourceLoader != null && res.startsWith("classpath:")) {
            Resource resource = s_resourceLoader.getResource(res);
            if (resource.isReadable()) {
                s_logger.debug("loadResource: loading resource={}", res);
                try {
                    ret = new String(Files.readAllBytes(Paths.get(resource.getFilename())));
                } catch (IOException e) {
                    s_logger.debug("loadResource: Failed to load resource: {}", resource);
                }
            } else {
                res = res.replace("classpath:", "");
                s_logger.debug("loadResource: resource not available={}", res);
            }
        }
        if (ret == null) {
            s_logger.debug("loadResource: loading file={}", res);
            Path absPath = Paths.get(resName, new String[0]).toAbsolutePath();
            try {
                ret = new String(Files.readAllBytes(absPath));
            } catch (IOException e) {
                s_logger.debug("loadResource: Failed to load resource: {}", absPath);
            }
        }
        s_logger.debug("loadResource: loaded={}", Boolean.valueOf((ret != null)));
        return ret;
    }

    public static InputStream getResourceAsStream(String name) throws IOException {
        InputStream ret;
        if (s_resourceLoader != null && name.startsWith("classpath:")) {
            ret = s_resourceLoader.getResource(name).getInputStream();
        } else {
            ret = Files.newInputStream(
                    Paths.get(name, new String[0]), new java.nio.file.OpenOption[0]);
        }
        return ret;
    }
    
    public static Object newInstance(Class clazz) {
       Object ret = null;
       if (clazz != null) {
    	   String name = clazz.getName();
    	   try {
    		   Constructor<Object> cons = clazz.getDeclaredConstructor();
    	       if (cons != null) {
    	    	   ret = cons.newInstance();    	
    	       }
    	   } catch (Exception var4) {
               LogUtils.ERROR(s_logger, name);
          }
       }
    	 
       return ret;
    }
    
    public static Object newInstance(String name) {
    	Object ret = null;
    	if (name != null) {
    		try {
    			Class clazz = Class.forName(name);
    	        Constructor<Object> cons = clazz.getDeclaredConstructor();
    	        if (cons != null) {
    	        	ret = cons.newInstance();
    	        }
    		} catch (Exception var4) {
    			LogUtils.ERROR(s_logger, name);
    		}      
    	}
    	 
    	return ret;
    }

}
