package com.matrixx.rsgateway.custom.filter;

import com.matrixx.platform.*;
import com.matrixx.rsgateway.services.BaseFilter;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static com.matrixx.platform.LogUtils.INFO;

@Component("PurchasedOffersFilter")
public class VisiblePurchasedOffersFilter extends BaseFilter implements IRestFilter {
    /**
     * hold the spring app context
     */
    protected ApplicationContext m_appContext = null;
    private static final Logger m_logger = LoggerFactory.getLogger(VisiblePurchasedOffersFilter.class);

    /**
     * set the application context
     *
     * @param ctx ApplicationContext
     */
    @Autowired
    public void setApplicationContext(ApplicationContext ctx) {
        m_appContext = ctx;
    }

    /**
     * filter a list of offers so that the result only includes purchasable offers
     *
     * @param filterInfo JsonObject - holds the information about the filtering
     *                   being performed
     * @param input      JsonObject
     * @return JsonObject
     */
    public JsonObject filter(JsonObject filterInfo, JsonObject input) {
        INFO(m_logger, filterInfo.toString());
        String filterFieldName = filterInfo != null ? filterInfo.getString("FilterFieldName") : null;
        String filterFieldValue = filterInfo != null ? filterInfo.getString("FilterFieldValue") : null;
        String ResponseOfferFieldCsv = filterInfo != null ? filterInfo.getString("ResponseOfferFieldList") : null;

        List<String> offerFieldList = null;
        if (StringUtils.isNotBlank(ResponseOfferFieldCsv)) {
            String[] offerFieldArray = ResponseOfferFieldCsv.split(",");
            offerFieldList = Arrays.stream(offerFieldArray).collect(Collectors.toList());
        }

        JsonObject output = new JsonObject();
        output.attribute("$", input.get("$"));
        output.attribute("ExternalId", input.get("ExternalId"));
        //output.attribute("ObjectId", input.get("ObjectId"));
        ArrayList<JsonObject> offerArray = input.getArray("PurchasedOfferArray");
        ArrayList<JsonObject> outputOfferArray = new ArrayList<JsonObject>();
        output.attribute("PurchasedOfferArray", outputOfferArray);

        if (offerArray != null) {
            for (int i = offerArray.size() - 1; i >= 0; i--) {
                JsonObject child = offerArray.get(i);
                if (child.get("CatalogItemExternalId") == null || StringUtils.isBlank(child.get("CatalogItemExternalId").toString())) {
                    continue;
                }
                JsonObject child1 = null;
                if (StringUtils.isNotBlank(filterFieldName) && StringUtils.isNotBlank(filterFieldValue) &&
                        ("notnull".equalsIgnoreCase(filterFieldValue)
                                || "not null".equalsIgnoreCase(filterFieldValue)
                                || "!null".equalsIgnoreCase(filterFieldValue))) {
                    //Include offer if filter field is not null
                	if (child.get(filterFieldName) != null) {
                		child1 = new JsonObject();	
                	}                    
                } else if (StringUtils.isNotBlank(filterFieldName) && StringUtils.isNotBlank(filterFieldValue) && "null".equalsIgnoreCase(filterFieldValue)) {
                    //Include offer if filter field is null
                    child1 = new JsonObject();
                } else if (StringUtils.isNotBlank(filterFieldName) && StringUtils.isNotBlank(filterFieldValue)) {
                    if (child.get(filterFieldName) != null && child.get(filterFieldName).toString().equalsIgnoreCase(filterFieldValue)) {
                        //Include offer if filter field matches input param
                        child1 = new JsonObject();
                    }
                }
                if (child1 != null) {
                    if (offerFieldList == null || offerFieldList.isEmpty()) {
                        child1 = child;
                    } else {
                        child1.attribute("CatalogItemExternalId", child.get("CatalogItemExternalId"));
                        child1.attribute("$", child.get("$"));
                        for (String fld : offerFieldList) {
                            if (child.get(fld) != null) {
                                child1.attribute(fld, child.get(fld).toString());
                            }
                        }
                    }
                    outputOfferArray.add(child1);
                }
            }
        }
        return output;
    }


    public static ArrayList<XmlNode> searchTag(XmlNode rootNode, String tagName) {
        ArrayList<XmlNode> foundNodes = new ArrayList<>();
        INFO(m_logger, "Found Nodes: " + foundNodes);
        searchTagHelper(rootNode, tagName, foundNodes);
        return foundNodes;
    }

    private static void searchTagHelper(XmlNode node, String tagName, ArrayList<XmlNode> foundNodes) {
        if (node != null && node.getName() != null && node.getName().equals(tagName)) {
            foundNodes.add(node);
            INFO(m_logger, "Inside function: " + node.getName());
        }
        for (XmlNode child : node.getChildren()) {
            searchTagHelper(child, tagName, foundNodes);
        }
    }

    private static String getAttributeValue(XmlNode child, String name) {
        XmlNode attribute = null;
        if (child != null) {
            attribute = child.find(name);
        }
        String attributeValue = null;
        if (attribute != null) {
            attributeValue = attribute.getTextContent();
        }
        return attributeValue;
    }

    /**
     * filter a list of offers so that the result only includes purchasable offers
     *
     * @param filterInfo XmlNode - holds the information about the filtering
     *                   being performed
     * @param input      XmlNode
     * @return XmlNode
     */
    public XmlNode filter(JsonObject filterInfo, XmlNode input) {
        INFO(m_logger, filterInfo.toString());
        String filterFieldName = filterInfo != null ? filterInfo.getString("FilterFieldName") : null;
        String filterFieldValue = filterInfo != null ? filterInfo.getString("FilterFieldValue") : null;
        String ResponseOfferFieldCsv = filterInfo != null ? filterInfo.getString("ResponseOfferFieldList") : null;

        List<String> offerFieldList = null;
        if (StringUtils.isNotBlank(ResponseOfferFieldCsv)) {
            String[] offerFieldArray = ResponseOfferFieldCsv.split(",");
            offerFieldList = Arrays.stream(offerFieldArray).collect(Collectors.toList());
        }

        XmlNode output = new XmlNode();
        output.setName("MtxResponseSubscription");
        output.addChild(input.find("ExternalId"));
        ArrayList<XmlNode> offerArray = searchTag(input, "MtxPurchasedOfferInfo");
        ArrayList<XmlNode> outputOfferArray = new ArrayList<XmlNode>();
        INFO(m_logger, offerFieldList + "");


        if (offerArray != null) {
            for (int i = offerArray.size() - 1; i >= 0; i--) {
                XmlNode child = offerArray.get(i);
                if (child.find("CatalogItemExternalId") == null || StringUtils.isBlank(child.find("CatalogItemExternalId").toString())) {
                    continue;
                }
                XmlNode child1 = null;
                if (StringUtils.isNotBlank(filterFieldName) && StringUtils.isNotBlank(filterFieldValue) &&
                        ("notnull".equalsIgnoreCase(filterFieldValue)
                                || "not null".equalsIgnoreCase(filterFieldValue)
                                || "!null".equalsIgnoreCase(filterFieldValue))) {
                    //Include offer if filter field is not null
                	if (child.find(filterFieldName) != null) {
                		child1 = new XmlNode();	
                	}                    
                } else if (StringUtils.isNotBlank(filterFieldName) && StringUtils.isNotBlank(filterFieldValue) && "null".equalsIgnoreCase(filterFieldValue)) {
                    //Include offer if filter field is null
                    child1 = new XmlNode();
                } else if (StringUtils.isNotBlank(filterFieldName) && StringUtils.isNotBlank(filterFieldValue)) {
                    if (child.find(filterFieldName) != null && filterFieldValue.equalsIgnoreCase(getAttributeValue(child, filterFieldName))) {
                        //Include offer if filter field matches input param
                        child1 = new XmlNode();
                    }
                }
                if (child1 != null) {

                    if (offerFieldList == null || offerFieldList.isEmpty()) {
                        child1 = child;
                    } else {
                        child1.addChild(child.find("CatalogItemExternalId"));
                        for (String fld : offerFieldList) {
                            if (getAttributeValue(child, fld) != null) {
                                child1.addNode(child.find(fld));
                            }
                        }
                    }
                    outputOfferArray.add(child1);
                    if (outputOfferArray != null) {
                        for (XmlNode node : outputOfferArray) {
                            if (node != null)
                                node.setName("MtxPurchasedOfferInfo");
                        }
                    }
                }
            }
			if(outputOfferArray != null)  {
				for (XmlNode node : outputOfferArray) {
					if (node != null) {
						output.append("PurchasedOfferArray", node);
					}
				}
			}
        }
        return output;
    }

}