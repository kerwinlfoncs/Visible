package com.matrixx.rsgateway.custom;

import static com.matrixx.platform.LogUtils.DEBUG;
import static com.matrixx.platform.LogUtils.ENTER;
import static com.matrixx.platform.LogUtils.ERROR;
import static com.matrixx.platform.LogUtils.LEAVE;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.matrixx.datacontainer.mdc.ManualPayRequest;
import com.matrixx.datacontainer.mdc.ManualPayResponse;
import com.matrixx.datacontainer.mdc.MtxRequest;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberModify;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberPurchaseOffer;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberRecharge;
import com.matrixx.datacontainer.mdc.MtxResponse;
import com.matrixx.datacontainer.mdc.SacModifyRequest;
import com.matrixx.datacontainer.mdc.SacModifyResponse;
import com.matrixx.datacontainer.mdc.SacResponse;
import com.matrixx.datacontainer.mdc.VisibleApiEventData;
import com.matrixx.datacontainer.mdc.VisibleGiftServiceResponse;
import com.matrixx.datacontainer.mdc.VisibleMultiRequest;
import com.matrixx.datacontainer.mdc.VisibleMultiRequestPurchaseService;
import com.matrixx.datacontainer.mdc.VisibleMultiResponsePurchaseService;
import com.matrixx.datacontainer.mdc.VisibleRequestAutoPay;
import com.matrixx.datacontainer.mdc.VisibleRequestCaLink;
import com.matrixx.datacontainer.mdc.VisibleRequestCaUnlink;
import com.matrixx.datacontainer.mdc.VisibleRequestCancelDeviceSwap;
import com.matrixx.datacontainer.mdc.VisibleRequestChangeService;
import com.matrixx.datacontainer.mdc.VisibleRequestChangeServiceAdvice;
import com.matrixx.datacontainer.mdc.VisibleRequestChargeNrf;
import com.matrixx.datacontainer.mdc.VisibleRequestDeviceSwap;
import com.matrixx.datacontainer.mdc.VisibleRequestFinanceDevice;
import com.matrixx.datacontainer.mdc.VisibleRequestGetConfig;
import com.matrixx.datacontainer.mdc.VisibleRequestGiftService;
import com.matrixx.datacontainer.mdc.VisibleRequestPaymentAdviceService;
import com.matrixx.datacontainer.mdc.VisibleRequestPurchaseDevice;
import com.matrixx.datacontainer.mdc.VisibleRequestPurchaseService;
import com.matrixx.datacontainer.mdc.VisibleRequestQuoteAdviceService;
import com.matrixx.datacontainer.mdc.VisibleRequestRecharge;
import com.matrixx.datacontainer.mdc.VisibleRequestRefundService;
import com.matrixx.datacontainer.mdc.VisibleRequestReloadConfig;
import com.matrixx.datacontainer.mdc.VisibleRequestReturnFinancedDevice;
import com.matrixx.datacontainer.mdc.VisibleRequestReturnPurchasedDevice;
import com.matrixx.datacontainer.mdc.VisibleRequestReverseNrf;
import com.matrixx.datacontainer.mdc.VisibleRequestSacSetUpPayment;
import com.matrixx.datacontainer.mdc.VisibleResponseAutoPay;
import com.matrixx.datacontainer.mdc.VisibleResponseCaLink;
import com.matrixx.datacontainer.mdc.VisibleResponseCaUnlink;
import com.matrixx.datacontainer.mdc.VisibleResponseCancelDeviceSwap;
import com.matrixx.datacontainer.mdc.VisibleResponseChangeService;
import com.matrixx.datacontainer.mdc.VisibleResponseChangeServiceAdvice;
import com.matrixx.datacontainer.mdc.VisibleResponseChargeNrf;
import com.matrixx.datacontainer.mdc.VisibleResponseDeviceSwap;
import com.matrixx.datacontainer.mdc.VisibleResponseFinanceDevice;
import com.matrixx.datacontainer.mdc.VisibleResponseGetConfig;
import com.matrixx.datacontainer.mdc.VisibleResponseMulti;
import com.matrixx.datacontainer.mdc.VisibleResponsePaymentAdviceService;
import com.matrixx.datacontainer.mdc.VisibleResponsePurchaseDevice;
import com.matrixx.datacontainer.mdc.VisibleResponsePurchaseService;
import com.matrixx.datacontainer.mdc.VisibleResponseQuoteAdviceService;
import com.matrixx.datacontainer.mdc.VisibleResponseRecharge;
import com.matrixx.datacontainer.mdc.VisibleResponseRefundService;
import com.matrixx.datacontainer.mdc.VisibleResponseReturnFinancedDevice;
import com.matrixx.datacontainer.mdc.VisibleResponseReturnPurchasedDevice;
import com.matrixx.datacontainer.mdc.VisibleResponseReverseNrf;
import com.matrixx.datacontainer.mdc.VisibleResponseSacSetUpPayment;
import com.matrixx.vag.advice.service.PaymentAdviceService;
import com.matrixx.vag.common.Constants.AOP_CONSTANTS;
import com.matrixx.vag.common.Constants.GENERIC_CONSTANTS;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.config.service.ConfigService;
import com.matrixx.vag.device.service.DeviceService;
import com.matrixx.vag.exception.VisibleServiceException;
import com.matrixx.vag.payment.service.AutoPayService;
import com.matrixx.vag.payment.service.ManualPayService;
import com.matrixx.vag.payment.service.VisibleRechargeService;
import com.matrixx.vag.sac.service.SacService;
import com.matrixx.vag.subscriber.service.ChangeService;
import com.matrixx.vag.subscriber.service.GiftService;
import com.matrixx.vag.subscriber.service.RefundService;
import com.matrixx.vag.subscriber.service.RefundServiceV3;
import com.matrixx.vag.subscriber.service.SubscriberService;

/**
 * Business API extension class. In cases of exception, this class would populate the HTTP status
 * code in the exception block - currently being done only for SAC methods. In future any other
 * methods would need it, they should be added here.
 *
 * @author cgi
 */
@Configuration
public class VisibleServices {

    private static final Logger m_logger = LoggerFactory.getLogger(VisibleServices.class);

    @Autowired
    ManualPayService manualPayService;

    @Autowired
    AutoPayService autoPayService;

    @Autowired
    SacService sacService;

    @Autowired
    DeviceService deviceService;

    @Autowired
    SubscriberService subscriberService;

    @Autowired
    RefundService refundService;

    @Autowired
    RefundServiceV3 refundServiceV3;
    
    @Autowired
    PaymentAdviceService paymentAdviceService;

    @Autowired
    GiftService giftService;

    @Autowired
    ChangeService changeService;
    
    @Autowired
    ConfigService configService;

    @Autowired
    VisibleRechargeService rechargeService;

    @Bean(name = "VisibleServices")
    VisibleServices getService() {
        return new VisibleServices();
    }

    String exMsgFormat = "SubscriptionExternalID: %s Error Message: %s";

    /**
     * Manual payment extension handler.
     *
     * @param searchTerm
     * @param input
     * @param output
     * @return
     */
    public int manualPay(ManualPayRequest input, ManualPayResponse output) {
        ENTER(m_logger, "ManualPay");
        int rc = 0;
        try {
            DEBUG(m_logger, "Received Request: \n" + input.toJson());
            filterApiEventData(input);
            VisibleResponsePaymentAdviceService aopOutput = null;

            if (GENERIC_CONSTANTS.YES.equalsIgnoreCase(input.getValidatePayment())) {
                aopOutput = calculateAOPForManualPay(input);
            }
            manualPayService.manualPay(input, output, aopOutput);
        } catch (VisibleServiceException e) {
            String resultText = e.getMessage();
            ERROR(m_logger, "ManualPay: " + resultText);
            output.setResult(e.getResultCode());
            output.setResultText(
                    String.format(
                            exMsgFormat, input.getSubscriberSearchDataExternalId(), resultText));
        } catch (Exception e) {
            String resultText = "Internal error - " + e.getMessage();
            ERROR(m_logger, "ManualPay: " + resultText, e);
            output.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            output.setResultText(
                    String.format(
                            exMsgFormat, input.getSubscriberSearchDataExternalId(), resultText));
        }
        DEBUG(m_logger, "Received Response: \n" + output.toJson());
        return LEAVE(rc, m_logger, "ManualPay");
    }

    public int autoPay(VisibleRequestAutoPay input, VisibleResponseAutoPay output) {
        ENTER(m_logger, "AutoPay");
        int rc = 0;
        try {
            DEBUG(m_logger, "Received Request: \n" + input.toJson());
            filterApiEventData(input);
            autoPayService.autoPay(input, output);
        } catch (VisibleServiceException e) {
            String resultText = e.getMessage();
            ERROR(m_logger, "AutoPay: " + resultText);
            output.setSubscriptionExternalId("" + input.getSubscriptionExternalId());
            output.setResult(e.getResultCode());
            output.setResultText(
                    String.format(exMsgFormat, input.getSubscriptionExternalId(), resultText));
        } catch (Exception e) {
            String resultText = "Internal error - " + e.getMessage();
            ERROR(m_logger, "AutoPay: " + resultText, e);
            output.setSubscriptionExternalId("" + input.getSubscriptionExternalId());
            output.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            output.setResultText(
                    String.format(exMsgFormat, input.getSubscriptionExternalId(), resultText));
        }

        DEBUG(m_logger, "Received Response: \n" + output.toJson());
        return LEAVE(rc, m_logger, "AutoPay");
    }

    public int visibleRecharge(VisibleRequestRecharge request, VisibleResponseRecharge response) {
        ENTER(m_logger, "VisibleRecharge");
        int rc = 0;
        try {
            DEBUG(m_logger, "Received Request: \n" + request.toJson());
            filterApiEventData(request);
            rechargeService.recharge(request, response);
        } catch (VisibleServiceException e) {
            String resultText = e.getMessage();
            ERROR(m_logger, "VisibleRecharge: " + resultText);
            if(request.getSubscriberSearchData()!=null && request.getSubscriberSearchData().getExternalId()!=null) {
                response.setSubscriptionExternalId(request.getSubscriberSearchData().getExternalId());
                response.setResultText(
                        String.format(exMsgFormat, request.getSubscriberSearchData().getExternalId(), resultText));
            }else {
                response.setResultText(resultText);
            }            
            response.setResult(e.getResultCode());
        } catch (Exception e) {
            String resultText = "Internal error - " + e.getMessage();
            ERROR(m_logger, "VisibleRecharge: " + resultText, e);
            if(request.getSubscriberSearchData()!=null && request.getSubscriberSearchData().getExternalId()!=null) {
                response.setSubscriptionExternalId(request.getSubscriberSearchData().getExternalId());
                response.setResultText(
                        String.format(exMsgFormat, request.getSubscriberSearchData().getExternalId(), resultText));
            }else {
                response.setResultText(resultText);
            } 
        }

        DEBUG(m_logger, "Received Response: \n" + response.toJson());
        return LEAVE(rc, m_logger, "VisibleRecharge");
    }

    /**
     * Significant Account Change (SAC) extension handler.
     *
     * @param output
     * @param objectId
     * @param customerId
     * @param nonce
     * @return
     */
    public int sacAddPayment(SacResponse output, String objectId, String customerId, String nonce) {
        ENTER(m_logger, "SacAdd");
        int rc = 0;
        try {
            DEBUG(
                    m_logger, "Received Request: \n" + "SAC Request\n    Object ID = " + objectId
                            + "\n    Customer ID = " + customerId + "\n    Nonce = " + nonce);
            sacService.sacAddPayment(output, objectId, customerId, nonce);
        } catch (VisibleServiceException e) {
            String resultText = e.getMessage();
            ERROR(m_logger, "SacAdd: " + resultText);
            output.setResult(e.getResultCode());
            output.setResultText(resultText);
            output.setstatusCode(e.getResultCode().intValue());
            output.setstatus(resultText);
        } catch (Exception e) {
            String resultText = "Internal error - " + e.getMessage();
            ERROR(m_logger, "SacAdd: " + resultText, e);
            output.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            output.setResultText(resultText);
            output.setstatusCode(500);
            output.setstatus(resultText);
        }
        DEBUG(m_logger, "Received Response: \n" + output.toJson());
        return LEAVE(rc, m_logger, "SacAdd");
    }

    /**
     * Significant Account Change (SAC) extension handler.
     *
     * @param output
     * @param objectId
     * @param resourceId
     * @return
     * @return
     */
    public int sacDeletePaymentOnResourceId(SacResponse output, String objectId, long resourceId) {
        ENTER(m_logger, "SacDeletePaymentOnResourceId");
        int rc = 0;
        try {
            DEBUG(
                    m_logger, "Received Request: \n" + "SAC Request\n    Object ID = " + objectId
                            + "\n    Payment Resource Id = " + resourceId);
            sacService.sacDeletePaymentOnResourceId(output, objectId, resourceId);
        } catch (VisibleServiceException e) {
            String resultText = e.getMessage();
            ERROR(m_logger, "SacDelete: " + resultText);
            output.setResult(e.getResultCode());
            output.setResultText(resultText);
            // We copy the result code as the status code in case of exception.
            output.setstatusCode(e.getResultCode().intValue());
            output.setstatus(resultText);
        } catch (Exception e) {
            String resultText = "Internal error - " + e.getMessage();
            ERROR(m_logger, "SacDelete: " + resultText, e);
            output.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            // We copy the result code as the status code in case of exception.
            output.setResultText(resultText);
            output.setstatusCode(500);
            output.setstatus(resultText);
        }
        DEBUG(m_logger, "Received Response: \n" + output.toJson());
        return LEAVE(rc, m_logger, "SacDelete");
    }

    /**
     * Significant Account Change (SAC) extension handler.
     *
     * @param input
     * @param output
     * @return
     */
    public int sacModifyPayment(SacModifyRequest input, SacModifyResponse output) {
        ENTER(m_logger, "sacModifyPayment");
        int rc = 0;
        try {
            DEBUG(m_logger, "Received Request: \n" + input.toJson());
            filterApiEventData(input);
            sacService.sacModifyPayment(input, output);
        } catch (Exception e) {
            String resultText = "Internal error - " + e.getMessage();
            ERROR(m_logger, "SacModify: " + resultText, e);
            output.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            output.setResultText(resultText);
        }
        DEBUG(m_logger, "Received Response: \n" + output.toJson());
        return LEAVE(rc, m_logger, "SacModify");
    }

    /**
     * Significant Account Change (SAC) extension handler.
     *
     * @param output
     * @param objectId
     * @param resourceId
     * @return
     */

    public int sacCurrentPayment(SacResponse output, String objectId, long resourceId) {
        ENTER(m_logger, "sacCurrentPayment");
        int rc = 0;
        try {
            DEBUG(
                    m_logger, "Received Request: \n" + "SAC Request\n    Object ID = " + objectId
                            + "\n    Payment Resource Id = " + resourceId);
            sacService.sacCurrentPayment(output, objectId, resourceId);
        } catch (VisibleServiceException e) {
            String resultText = e.getMessage();
            ERROR(m_logger, "sacCurrentPayment: " + resultText);
            output.setResult(e.getResultCode());
            output.setResultText(resultText);
            output.setstatusCode(e.getResultCode().intValue());
            output.setstatus(resultText);
        } catch (Exception e) {
            String resultText = "Internal error - " + e.getMessage();
            ERROR(m_logger, "sacCurrentPayment: " + resultText, e);
            output.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            output.setResultText(resultText);
        }
        DEBUG(m_logger, "Received Response: \n" + output.toJson());
        return LEAVE(rc, m_logger, "sacCurrentPayment");
    }

    /**
     * SacAddDefaultPayment extension handler.
     *
     * @param searchTerm
     * @param input
     * @param output
     * @return
     */
    public int sacSetUpPayment(VisibleRequestSacSetUpPayment input,
                               VisibleResponseSacSetUpPayment output) {
        ENTER(m_logger, "SacSetUpPayment");
        int rc = 0;
        try {
            DEBUG(m_logger, "Received Request: \n" + input.toJson());
            filterApiEventData(input);
            sacService.sacSetUpPayment(input, output);
        } catch (VisibleServiceException e) {
            String resultText = e.getMessage();
            ERROR(m_logger, "SacSetUpPayment: " + resultText);
            output.setResult(e.getResultCode());
            output.setResultText(resultText);
        } catch (Exception e) {
            String resultText = "Internal error - " + e.getMessage();
            ERROR(m_logger, "SacSetUpPayment: " + resultText, e);
            output.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            output.setResultText(resultText);
        }
        DEBUG(m_logger, "Received Response: \n" + output.toJson());
        return LEAVE(rc, m_logger, "SacSetUpPayment");
    }

    public int sacLinkCa(VisibleRequestCaLink input,
                         VisibleResponseCaLink output) {
        ENTER(m_logger, "sacLinkCa");
        int rc = 0;
        try {
            DEBUG(m_logger, "Received Request: \n" + input.toJson());
            filterApiEventData(input);
            sacService.sacLinkCa(input, output);
        } catch (VisibleServiceException e) {
            String resultText = e.getMessage();
            ERROR(m_logger, "sacLinkCa: " + resultText);
        } catch (Exception e) {
            String resultText = "Internal error - " + e.getMessage();
            ERROR(m_logger, "sacLinkCa: " + resultText, e);
            output.setResult(RESULT_CODES.HTTP_INTERNAL_ERROR);
            output.setResultText(resultText);
        }
        DEBUG(m_logger, "Received Response: \n" + output.toJson());
        return LEAVE(rc, m_logger, "sacLinkCa");
    }

    public int sacUnlinkCa(VisibleRequestCaUnlink input,
                           VisibleResponseCaUnlink output) {
        ENTER(m_logger, "sacUnlinkCa");
        int rc = 0;
        try {
            DEBUG(m_logger, "Received Request: \n" + input.toJson());
            filterApiEventData(input);
            sacService.sacUnlinkCa(input, output);
        } catch (VisibleServiceException e) {
            String resultText = e.getMessage();
            ERROR(m_logger, "sacUnlinkCa: " + resultText);
        } catch (Exception e) {
            String resultText = "Internal error - " + e.getMessage();
            ERROR(m_logger, "sacUnlinkCa: " + resultText, e);
            output.setResult(RESULT_CODES.HTTP_INTERNAL_ERROR);
            output.setResultText(resultText);
        }
        DEBUG(m_logger, "Received Response: \n" + output.toJson());
        return LEAVE(rc, m_logger, "sacUnlinkCa");
    }

    /**
     * Device purchase extension handler.
     *
     * @param searchTerm
     * @param input
     * @param output
     * @return
     */
    public int purchaseDevice(VisibleRequestPurchaseDevice input,
                              VisibleResponsePurchaseDevice output) {
        ENTER(m_logger, "PurchaseDevice");
        int rc = 0;
        try {
            DEBUG(m_logger, "Received Request: \n" + input.toJson());
            filterApiEventData(input);
            deviceService.purchaseDevice(input, output);
        } catch (VisibleServiceException e) {
            String resultText = e.getMessage();
            ERROR(m_logger, "PurchaseDevice: " + resultText);
            output.setResult(e.getResultCode());
            output.setResultText(resultText);
        } catch (Exception e) {
            String resultText = "Internal error - " + e.getMessage();
            ERROR(m_logger, "PurchaseDevice: " + resultText, e);
            output.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            output.setResultText(resultText);
        }
        DEBUG(m_logger, "Received Response: \n" + output.toJson());
        return LEAVE(rc, m_logger, "PurchaseDevice");
    }

    /**
     * Return purchased device extension handler.
     *
     * @param searchTerm
     * @param input
     * @param output
     * @return
     */
    public int returnPurchasedDevice(VisibleRequestReturnPurchasedDevice input,
                                     VisibleResponseReturnPurchasedDevice output) {
        ENTER(m_logger, "ReturnPurchasedDevice");
        int rc = 0;
        try {
            DEBUG(m_logger, "Received Request: \n" + input.toJson());
            filterApiEventData(input);
            deviceService.returnPurchasedDevice(input, output);
        } catch (VisibleServiceException e) {
            String resultText = e.getMessage();
            ERROR(m_logger, "ReturnPurchasedDevice: " + resultText);
            output.setResult(e.getResultCode());
            output.setResultText(
                    "SubscriberExternalID: " + input.getSubscriberExternalId() + " Error Message: "
                            + resultText);
        } catch (Exception e) {
            String resultText = "Internal error - " + e.getMessage();
            ERROR(m_logger, "ReturnPurchasedDevice: " + resultText, e);
            output.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            output.setResultText(
                    "SubscriberExternalID: " + input.getSubscriberExternalId() + " Error Message: "
                            + resultText);
        }
        DEBUG(m_logger, "Received Response: \n" + output.toJson());
        return LEAVE(rc, m_logger, "ReturnPurchasedDevice");
    }

    /**
     * Device finance extension handler.
     *
     * @param searchTerm
     * @param input
     * @param output
     * @return
     */
    public int financeDevice(VisibleRequestFinanceDevice input,
                             VisibleResponseFinanceDevice output) {
        ENTER(m_logger, "FinanceDevice");
        int rc = 0;
        try {
            DEBUG(m_logger, "Received Request: \n" + input.toJson());
            filterApiEventData(input);
            deviceService.financeDevice(input, output);
        } catch (VisibleServiceException e) {
            String resultText = e.getMessage();
            ERROR(m_logger, "FinanceDevice: " + resultText);
            output.setResult(e.getResultCode());
            output.setResultText(
                    "SubscriberExternalID: " + input.getSubscriberExternalId() + " Error Message: "
                            + resultText);
        } catch (Exception e) {
            String resultText = "Internal error - " + e.getMessage();
            ERROR(m_logger, "FinanceDevice: " + resultText, e);
            output.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            output.setResultText(
                    "SubscriberExternalID: " + input.getSubscriberExternalId() + " Error Message: "
                            + resultText);
        }
        DEBUG(m_logger, "Received Response: \n" + output.toJson());
        return LEAVE(rc, m_logger, "FinanceDevice");
    }

    /**
     * Return financed device extension handler.
     *
     * @param searchTerm
     * @param input
     * @param output
     * @return
     */
    public int returnFinancedDevice(VisibleRequestReturnFinancedDevice input,
                                    VisibleResponseReturnFinancedDevice output) {
        ENTER(m_logger, "ReturnFinancedDevice");
        int rc = 0;
        try {
            DEBUG(m_logger, "Received Request: \n" + input.toJson());
            filterApiEventData(input);
            deviceService.returnFinancedDevice(input, output);
        } catch (VisibleServiceException e) {
            String resultText = e.getMessage();
            ERROR(m_logger, "ReturnFinancedDevice: " + resultText);
            output.setResult(e.getResultCode());
            output.setResultText(resultText);
        } catch (Exception e) {
            String resultText = "Internal error - " + e.getMessage();
            ERROR(m_logger, "ReturnFinancedDevice: " + resultText, e);
            output.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            output.setResultText(resultText);
        }
        DEBUG(m_logger, "Received Response: \n" + output.toJson());
        return LEAVE(rc, m_logger, "ReturnFinancedDevice");
    }

    /**
     * Service purchase extension handler.
     *
     * @param searchTerm
     * @param input
     * @param output
     * @return
     */
    public int purchaseService(VisibleRequestPurchaseService input,
                               VisibleResponsePurchaseService output) {
        ENTER(m_logger, "PurchaseService");
        int rc = 0;
        try {
            DEBUG(m_logger, "Received Request: \n" + input.toJson());
            filterApiEventData(input);
            subscriberService.purchaseService(input, output);
        } catch (VisibleServiceException e) {
            String resultText = e.getMessage();
            ERROR(m_logger, "PurchaseService: " + resultText);
            output.setResult(e.getResultCode());
            output.setResultText(
                    String.format(exMsgFormat, input.getSubscriberExternalId(), resultText));
        } catch (Exception e) {
            String resultText = "Internal error - " + e.getMessage();
            ERROR(m_logger, "PurchaseService: " + resultText, e);
            output.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            output.setResultText(
                    String.format(exMsgFormat, input.getSubscriberExternalId(), resultText));
        }
        DEBUG(m_logger, "Received Response: \n" + output.toJson());
        return LEAVE(rc, m_logger, "PurchaseService");
    }

    public int purchaseMultiService(VisibleMultiRequestPurchaseService input,
                                    VisibleMultiResponsePurchaseService output) {
        ENTER(m_logger, "PurchaseMultiService");
        int rc = 0;
        try {
            DEBUG(m_logger, "Received Request: \n" + input.toJson());
            filterApiEventData(input);
            subscriberService.purchaseMultiService(input, output);
        } catch (VisibleServiceException e) {
            String resultText = e.getMessage();
            ERROR(m_logger, "PurchaseMultiService: " + resultText);
            output.setResult(e.getResultCode());
            output.setResultText(
                    String.format(exMsgFormat, input.getSubscriberExternalId(), resultText));
        } catch (Exception e) {
            String resultText = "Internal error - " + e.getMessage();
            ERROR(m_logger, "PurchaseMultiService: " + resultText, e);
            output.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            output.setResultText(
                    String.format(exMsgFormat, input.getSubscriberExternalId(), resultText));
        }
        DEBUG(m_logger, "Received Response: \n" + output.toJson());
        return LEAVE(rc, m_logger, "PurchaseMultiService");
    }

    /**
     * Service refund extension handler version 2.
     *
     * @param searchTerm
     * @param input
     * @param output
     * @return
     */

    public int refundServiceV2(VisibleRequestRefundService input,
                               VisibleResponseRefundService output) {
        ENTER(m_logger, "RefundService");
        int rc = 0;
        try {
            DEBUG(m_logger, "Received Request: \n" + input.toJson());
            filterApiEventData(input);
            refundService.refundServiceV2(input, output);
        } catch (VisibleServiceException e) {
            String resultText = e.getMessage();
            ERROR(m_logger, "RefundService: " + resultText);
            output.setResult(e.getResultCode());
            output.setResultText(
                    String.format(exMsgFormat, input.getSubscriberExternalId(), resultText));
        } catch (Exception e) {
            String resultText = "Internal error - " + e.getMessage();
            ERROR(m_logger, "RefundService: " + resultText, e);
            output.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            output.setResultText(
                    String.format(exMsgFormat, input.getSubscriberExternalId(), resultText));
        }
        DEBUG(m_logger, "Received Response: \n" + output.toJson());
        return LEAVE(rc, m_logger, "RefundService");
    }

    /**
     * Service refund extension handler version 3.(Connected Accounts onwards.)
     *
     * @param searchTerm
     * @param input
     * @param output
     * @return
     */

    public int refundServiceV3(VisibleRequestRefundService input,
                               VisibleResponseRefundService output) {
        ENTER(m_logger, "RefundService");
        int rc = 0;
        try {
            DEBUG(m_logger, "Received Request: \n" + input.toJson());
            filterApiEventData(input);
            refundServiceV3.refundService(input, output);
        } catch (VisibleServiceException e) {
            String resultText = e.getMessage();
            ERROR(m_logger, "RefundService: " + resultText);
            output.setResult(e.getResultCode());
            output.setResultText(
                    String.format(exMsgFormat, input.getSubscriberExternalId(), resultText));
        } catch (Exception e) {
            String resultText = "Internal error - " + e.getMessage();
            ERROR(m_logger, "RefundService: " + resultText, e);
            output.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            output.setResultText(
                    String.format(exMsgFormat, input.getSubscriberExternalId(), resultText));
        }
        DEBUG(m_logger, "Received Response: \n" + output.toJson());
        return LEAVE(rc, m_logger, "RefundService");
    }

    public int changeService(VisibleRequestChangeService input,
                             VisibleResponseChangeService output) {
        ENTER(m_logger, "ChangeService");
        int rc = 0;
        try {
            DEBUG(m_logger, "Received Request: \n" + input.toJson());
            filterApiEventData(input);
            changeService.changeBaseOfferService(input, output);
        } catch (VisibleServiceException e) {
            String resultText = e.getMessage();
            ERROR(m_logger, "ChangeService: " + resultText);
            output.setSubscriptionExternalId("" + input.getSubscriptionExternalId());
            output.setResult(e.getResultCode());
            output.setResultText(
                    String.format(exMsgFormat, input.getSubscriptionExternalId(), resultText));
        } catch (Exception e) {
            String resultText = "Internal error - " + e.getMessage();
            ERROR(m_logger, "ChangeService: " + resultText, e);
            output.setSubscriptionExternalId("" + input.getSubscriptionExternalId());
            output.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            output.setResultText(
                    String.format(exMsgFormat, input.getSubscriptionExternalId(), resultText));
        }
        DEBUG(m_logger, "Received Response: \n" + output.toJson());
        return LEAVE(rc, m_logger, "ChangeService");
    }

    /**
     * @param input
     * @param output
     * @return
     */
    public int paymentAdvice(VisibleRequestPaymentAdviceService input,
                             VisibleResponsePaymentAdviceService output) {
        ENTER(m_logger, "PaymentAdvice");
        int rc = 0;
        try {
            DEBUG(m_logger, "Received Request: \n" + input.toJson());
            filterApiEventData(input);
            paymentAdviceService.getAOP(input, output);
        } catch (VisibleServiceException e) {
            String resultText = e.getMessage();
            ERROR(m_logger, "PaymentAdviceService: " + resultText);
            output.setSubscriberExternalId("" + input.getSubscriberExternalId());
            output.setResult(e.getResultCode());
            output.setResultText(
                    String.format(exMsgFormat, input.getSubscriberExternalId(), resultText));
        } catch (Exception e) {
            String resultText = "Internal error - " + e.getMessage();
            ERROR(m_logger, "PaymentAdviceService: " + resultText, e);
            output.setSubscriberExternalId("" + input.getSubscriberExternalId());
            output.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            output.setResultText(
                    String.format(exMsgFormat, input.getSubscriberExternalId(), resultText));
        }
        DEBUG(m_logger, "Received Response: \n" + output.toJson());
        return LEAVE(rc, m_logger, "AdviceOfPayment");
    }

    /**
     * Cancel Device Swap
     *
     * @param input
     * @param output
     * @return
     */
    public int cancelDeviceSwap(VisibleRequestCancelDeviceSwap input,
                                VisibleResponseCancelDeviceSwap output) {
        ENTER(m_logger, "CancelDeviceSwap");
        int rc = 0;
        try {
            DEBUG(m_logger, "Received Request: \n" + input.toJson());
            filterApiEventData(input);
            deviceService.cancelDeviceSwap(input, output);
        } catch (VisibleServiceException e) {
            String resultText = e.getMessage();
            ERROR(m_logger, "CancelDeviceSwap: " + resultText);
            output.setResult(e.getResultCode());
            output.setResultText(resultText);
        } catch (Exception e) {
            String resultText = "Internal error - " + e.getMessage();
            ERROR(m_logger, "CancelDeviceSwap: " + resultText, e);
            output.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            output.setResultText(resultText);
        }
        DEBUG(m_logger, "Received Response: \n" + output.toJson());
        return LEAVE(rc, m_logger, "CancelDeviceSwap");
    }

    /**
     * Charge Non Return fee if the old deviuce is not returned
     *
     * @param input
     * @param output
     * @return
     */

    public int chargeNonReturnFee(VisibleRequestChargeNrf input, VisibleResponseChargeNrf output) {
        ENTER(m_logger, "ChargeNonReturnFee");
        int rc = 0;
        try {
            DEBUG(m_logger, "Received Request: \n" + input.toJson());
            filterApiEventData(input);
            deviceService.chargeNonReturnFee(input, output);
        } catch (VisibleServiceException e) {
            String resultText = e.getMessage();
            ERROR(m_logger, "ChargeNonReturnFee: " + resultText);
            output.setResult(e.getResultCode());
            output.setResultText(resultText);
        } catch (Exception e) {
            String resultText = "Internal error - " + e.getMessage();
            ERROR(m_logger, "Charge non return fee: " + resultText, e);
            output.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            output.setResultText(resultText);
        }
        DEBUG(m_logger, "Received Response: \n" + output.toJson());
        return LEAVE(rc, m_logger, "ChargeNonReturnFee");
    }

    public int reverseNonReturnFee(VisibleRequestReverseNrf input,
                                   VisibleResponseReverseNrf output) {
        ENTER(m_logger, "ReverseNonReturnFee");
        int rc = 0;
        try {
            DEBUG(m_logger, "Received Request: \n" + input.toJson());
            filterApiEventData(input);
            deviceService.reverseNonReturnFee(input, output);
        } catch (VisibleServiceException e) {
            String resultText = e.getMessage();
            ERROR(m_logger, "ReverseNonReturnFee: " + resultText);
            output.setResult(e.getResultCode());
            output.setResultText(resultText);
        } catch (Exception e) {
            String resultText = "Internal error - " + e.getMessage();
            ERROR(m_logger, "ReverseNonReturnFee: " + resultText, e);
            output.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            output.setResultText(resultText);
        }
        DEBUG(m_logger, "Received Response: \n" + output.toJson());
        return LEAVE(rc, m_logger, "ReverseNonReturnFee");
    }

    /**
     * Reload system configuration.
     *
     * @param input
     * @param output
     * @return
     */
    public int reloadConfig(VisibleRequestReloadConfig input, MtxResponse output) {
        ENTER(m_logger, "ReloadConfig");
        int rc = 0;
        try {
            DEBUG(m_logger, "Received Request: \n" + input.toJson());
            filterApiEventData(input);
            configService.reloadConfig(input, output);
        } catch (Exception e) {
            String resultText = "Internal error - " + e.getMessage();
            ERROR(m_logger, "ReloadConfig: " + resultText, e);
            output.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            output.setResultText(resultText);
        }
        DEBUG(m_logger, "Received Response: \n" + output.toJson());
        return LEAVE(rc, m_logger, "ReloadConfig");
    }

    /**
     * Device finance extension handler.
     *
     * @param searchTerm
     * @param input
     * @param output
     * @return
     */
    public int deviceSwap(VisibleRequestDeviceSwap input, VisibleResponseDeviceSwap output) {
        ENTER(m_logger, "DeviceSwap");
        int rc = 0;
        try {
            DEBUG(m_logger, "Received Request: \n" + input.toJson());
            filterApiEventData(input);
            deviceService.deviceSwap(input, output);
        } catch (VisibleServiceException e) {
            String resultText = e.getMessage();
            ERROR(m_logger, "Device swap: " + resultText);
            output.setResult(e.getResultCode());
            output.setResultText(resultText);
        } catch (Exception e) {
            String resultText = "Internal error - " + e.getMessage();
            ERROR(m_logger, "FinanceDevice: " + resultText, e);
            output.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            output.setResultText(resultText);
        }
        DEBUG(m_logger, "Received Response: \n" + output.toJson());
        return LEAVE(rc, m_logger, "DeviceSwap");
    }

    public int quoteAdvice(VisibleRequestQuoteAdviceService input,
                           VisibleResponseQuoteAdviceService output) {
        ENTER(m_logger, "QuoteAdvice");
        int rc = 0;
        try {
            DEBUG(m_logger, "Received Request: \n" + input.toJson());
            filterApiEventData(input);
            paymentAdviceService.getQuoteAdvice(input, output);
        } catch (VisibleServiceException e) {
            String resultText = e.getMessage();
            ERROR(m_logger, "QuoteAdviceService: " + resultText);
            output.setSubscriberExternalId("" + input.getSubscriberExternalId());
            output.setResult(e.getResultCode());
            output.setResultText(
                    String.format(exMsgFormat, input.getSubscriberExternalId(), resultText));
        } catch (Exception e) {
            String resultText = "Internal error - " + e.getMessage();
            ERROR(m_logger, "QuoteAdviceService: " + resultText, e);
            output.setSubscriberExternalId("" + input.getSubscriberExternalId());
            output.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            output.setResultText(
                    String.format(exMsgFormat, input.getSubscriberExternalId(), resultText));
        }
        DEBUG(m_logger, "Received Response: \n" + output.toJson());
        return LEAVE(rc, m_logger, "QuoteAdvice");
    }

    public int changeServiceAdvice(VisibleRequestChangeServiceAdvice input,
                                   VisibleResponseChangeServiceAdvice output) {
        ENTER(m_logger, "ChangeServiceAdvice");
        int rc = 0;
        try {
            DEBUG(m_logger, "Received Request: \n" + input.toJson());
            filterApiEventData(input);
            paymentAdviceService.getChangeServiceAdvice(input, output);
        } catch (VisibleServiceException e) {
            String resultText = e.getMessage();
            ERROR(m_logger, "ChangeServiceAdvice: " + resultText);
            output.setSubscriptionExternalId("" + input.getSubscriptionExternalId());
            output.setResult(e.getResultCode());
            output.setResultText(
                    String.format(exMsgFormat, input.getSubscriptionExternalId(), resultText));
        } catch (Exception e) {
            String resultText = "Internal error - " + e.getMessage();
            ERROR(m_logger, "ChangeServiceAdvice: " + resultText, e);
            output.setSubscriptionExternalId("" + input.getSubscriptionExternalId());
            output.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            output.setResultText(
                    String.format(exMsgFormat, input.getSubscriptionExternalId(), resultText));
        }
        DEBUG(m_logger, "Received Response: \n" + output.toJson());
        return LEAVE(rc, m_logger, "ChangeServiceAdvice");
    }

    /**
     * Execute the given gift service request.
     *
     * @param input
     *            - VisibleRequestGiftService
     * @param output
     *            - VisibleGiftServiceResponse
     * @return
     */
    public int giftService(VisibleRequestGiftService input, VisibleGiftServiceResponse output)
            throws Exception {
        ENTER(m_logger, "GiftService");
        int rc = 0;
        try {
            DEBUG(m_logger, "Received Request: \n" + input.toJson());
            filterApiEventData(input);
            giftService.giftSubscriber(input, output);
        } catch (Exception e) {
            String resultText = "Internal error - " + e.getMessage();
            ERROR(m_logger, "GiftService: " + resultText, e);
            output.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            output.setResultText(String.format(exMsgFormat, input.getGifteeExternalId(), resultText));
        }
        DEBUG(m_logger, "Received Response: \n" + output.toJson());
        return LEAVE(rc, m_logger, "GiftService");
    }

    /**
     * Execute the given multi-request.
     *
     * @param input
     *            - VisibleMultiRequest
     * @param output
     *            - VisibleResponseMulti
     * @return
     */
    public int executeVisibleMultiRequest(VisibleMultiRequest input, VisibleResponseMulti output) {

        ENTER(m_logger, "VisibleMultiRequest");
        String subscriberExternalID = null;
        if (StringUtils.isNotBlank(input.getSubscriberExternalId())) {
            subscriberExternalID = input.getSubscriberExternalId();
        } else {
            for (MtxRequest singleRequest : input.getRequestList()) {
                if (singleRequest.getMdcName().equalsIgnoreCase(
                        "MtxRequestSubscriberPurchaseOffer")) {
                    MtxRequestSubscriberPurchaseOffer spo = (MtxRequestSubscriberPurchaseOffer) singleRequest;
                    if (StringUtils.isNotBlank(spo.getSubscriberSearchData().getExternalId())) {
                        subscriberExternalID = spo.getSubscriberSearchData().getExternalId();
                    }
                } else if (singleRequest.getMdcName().equalsIgnoreCase(
                        "MtxRequestSubscriberModify")) {
                    MtxRequestSubscriberModify sm = (MtxRequestSubscriberModify) singleRequest;
                    if (StringUtils.isNotBlank(sm.getSubscriberSearchData().getExternalId())) {
                        subscriberExternalID = sm.getSubscriberSearchData().getExternalId();
                    }
                } else if (singleRequest.getMdcName().equalsIgnoreCase(
                        "MtxRequestSubscriberRecharge")) {
                    MtxRequestSubscriberRecharge sr = (MtxRequestSubscriberRecharge) singleRequest;
                    if (StringUtils.isNotBlank(sr.getSubscriberSearchData().getExternalId())) {
                        subscriberExternalID = sr.getSubscriberSearchData().getExternalId();
                    }
                }
            }
        }

        int rc = 0;
        try {
            DEBUG(m_logger, "Received Request: \n" + input.toJson());
            filterApiEventData(input);
            subscriberService.executeMultiRequest(input, output);
        } catch (VisibleServiceException e) {
            String resultText = e.getMessage();
            ERROR(m_logger, "Visible Multi Request: " + resultText);
            output.setResult(e.getResultCode());
            output.setResultText(String.format(exMsgFormat, subscriberExternalID, resultText));
        } catch (Exception e) {
            String resultText = "Internal error - " + e.getMessage();
            ERROR(m_logger, "Visible Multi Request: " + resultText, e);
            output.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            output.setResultText(String.format(exMsgFormat, subscriberExternalID, resultText));
        }
        DEBUG(m_logger, "Received Response: \n" + output.toJson());
        return LEAVE(rc, m_logger, "VisibleMultiRequest");
    }

    /**
     * get properties from rsgateway.properties
     *
     * @param input
     * @param output
     * @return
     */
    public int getConfig(VisibleRequestGetConfig input, VisibleResponseGetConfig output) {
        ENTER(m_logger, "GetConfig");
        int rc = 0;
        try {
            DEBUG(m_logger, "Received Request: \n" + input.toJson());
            filterApiEventData(input);
            configService.getConfig(input, output);
        } catch (Exception e) {
            String resultText = "Internal error - " + e.getMessage();
            ERROR(m_logger, "GetConfigService: " + resultText, e);
            output.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            output.setResultText(resultText);
        }
        DEBUG(m_logger, "Received Response: \n" + output.toJson());
        return LEAVE(rc, m_logger, "GetConfig");
    }

    /**
     * This method is to re-calculate AOP for manual pay stale data conditions.
     *
     * @param request
     * @return
     */
    private VisibleResponsePaymentAdviceService calculateAOPForManualPay(ManualPayRequest request) {
        VisibleRequestPaymentAdviceService aopInput = new VisibleRequestPaymentAdviceService();
        // Call AOP without taxability.
        aopInput.setIncludeTaxDetails(GENERIC_CONSTANTS.NO);
        aopInput.setSubscriberExternalId(request.getSubscriberSearchDataExternalId());
        aopInput.setRequestType(AOP_CONSTANTS.REQUEST_TYPE_DETAIL);
        VisibleResponsePaymentAdviceService aopOutput = new VisibleResponsePaymentAdviceService();
        paymentAdvice(aopInput, aopOutput);
        return aopOutput;
    }
    
    private void filterApiEventData(MtxRequest req) {
        if(req.getApiEventData()!=null && !(req.getApiEventData() instanceof VisibleApiEventData)){
            req.setApiEventData(new VisibleApiEventData());
        }
    }
}
