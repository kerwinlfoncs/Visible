package com.matrixx.vag.common.request.builder;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.matrixx.datacontainer.mdc.MtxPurchasedOfferData;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberPurchaseOffer;
import com.matrixx.datacontainer.mdc.MtxSubscriberSearchData;

public class MtxRequestSubscriberPurchaseOfferBuilder {
	String subscriberExternalId;
	MtxSubscriberSearchData searchData;
    List<MtxPurchasedOfferData> offerDataList = new ArrayList<MtxPurchasedOfferData>();
    
	public MtxRequestSubscriberPurchaseOffer build() {
		
		if(searchData==null) {
			this.searchData = new MtxSubscriberSearchData();	
		}
		
		if(StringUtils.isNotBlank(subscriberExternalId) && StringUtils.isBlank(searchData.getExternalId())) {
			this.searchData.setExternalId(subscriberExternalId);	
		}	
		
        MtxRequestSubscriberPurchaseOffer subPurchaseOffer = new MtxRequestSubscriberPurchaseOffer();
        subPurchaseOffer.setSubscriberSearchData(searchData);

        for (MtxPurchasedOfferData offerData : offerDataList) {
            subPurchaseOffer.appendOfferRequestArray(offerData);
        }
        
        return subPurchaseOffer;
	}
	
	public MtxRequestSubscriberPurchaseOfferBuilder withSubscriberExternalId(String subscriberExternalId) {
		if(StringUtils.isNotBlank(subscriberExternalId)) {
			this.subscriberExternalId = subscriberExternalId;	
		}		
		return this;
	}
	
	public MtxRequestSubscriberPurchaseOfferBuilder withSearchData(MtxSubscriberSearchData searchData) {
		if(searchData!=null) {
			this.searchData = searchData;	
		}		
		return this;
	}
	
	public MtxRequestSubscriberPurchaseOfferBuilder withOfferData(MtxPurchasedOfferData offerData) {
		if(offerData != null) {
			this.offerDataList.add(offerData);
		}
		return this;
	}
}
