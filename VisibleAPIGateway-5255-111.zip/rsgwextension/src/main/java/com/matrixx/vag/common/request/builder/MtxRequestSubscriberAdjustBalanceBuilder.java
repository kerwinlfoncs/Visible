package com.matrixx.vag.common.request.builder;

import java.math.BigDecimal;

import org.apache.commons.lang3.StringUtils;

import com.matrixx.datacontainer.mdc.MtxRequestSubscriberAdjustBalance;
import com.matrixx.datacontainer.mdc.MtxSubscriberSearchData;
import com.matrixx.vag.common.Constants.MATRIXX_CONSTANTS;
import com.matrixx.vag.common.coverage.Generated;

@Generated
public class MtxRequestSubscriberAdjustBalanceBuilder {

    String subscriberExternalId;
    Long balanceResourceId;
    BigDecimal amount;
    String reason;
    public MtxRequestSubscriberAdjustBalance build() {

        MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();

        if (StringUtils.isNotBlank(subscriberExternalId)) {
            searchData.setExternalId(subscriberExternalId);
        }
        MtxRequestSubscriberAdjustBalance adjBal = new MtxRequestSubscriberAdjustBalance();
        adjBal.setSubscriberSearchData(searchData);
        if (StringUtils.isNotBlank(reason)) {
            adjBal.setReason(reason);
        }
        if (balanceResourceId!=null) {
            adjBal.setBalanceResourceId(balanceResourceId);
        }
        if (amount!=null) {
            adjBal.setAmount(amount.abs());
            adjBal.setAdjustType(amount.signum() >= 0 
                    ? MATRIXX_CONSTANTS.BALANCE_ADJUSTMENT_TYPE_CREDIT 
                    : MATRIXX_CONSTANTS.BALANCE_ADJUSTMENT_TYPE_DEBIT);
        }
        
        return adjBal;
    }
    
    public MtxRequestSubscriberAdjustBalanceBuilder withSubscriberExternalId(String subscriberExternalId) {
        if (StringUtils.isNotBlank(subscriberExternalId)) {
            this.subscriberExternalId = subscriberExternalId;
        }
        return this;
    }
    
    public MtxRequestSubscriberAdjustBalanceBuilder withReason(String reason) {
        if (StringUtils.isNotBlank(reason)) {
            this.reason = reason;
        }
        return this;
    }
    
    public MtxRequestSubscriberAdjustBalanceBuilder withBalanceResourceId(Long balanceResourceId) {
        if (balanceResourceId!=null) {
            this.balanceResourceId = balanceResourceId;
        }
        return this;
    }

    public MtxRequestSubscriberAdjustBalanceBuilder withAmount(BigDecimal amount) {
        if (amount!=null) {
            this.amount = amount;
        }
        return this;
    }
}
