/**
 * 
 */
package com.matrixx.vag.exception;

import com.matrixx.vag.common.Constants.RESULT_CODES;

/**
 * @author mnguyen
 *
 */
public class MissingRequestParametersException extends InvalidRequestException {

    private static final long serialVersionUID = -5161077206928100185L;

    public MissingRequestParametersException(String message) {
        super(RESULT_CODES.HTTP_BAD_REQUEST, message);
    }
    
    public MissingRequestParametersException(Long resultCode, String message) {
        super(resultCode, message);
    }
}
