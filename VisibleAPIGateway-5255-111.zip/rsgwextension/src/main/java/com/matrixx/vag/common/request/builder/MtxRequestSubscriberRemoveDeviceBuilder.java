package com.matrixx.vag.common.request.builder;

import com.matrixx.datacontainer.mdc.MtxDeviceSearchData;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberRemoveDevice;
import com.matrixx.vag.common.coverage.Generated;

@Generated
public class MtxRequestSubscriberRemoveDeviceBuilder {
	MtxDeviceSearchData searchData;
    public MtxRequestSubscriberRemoveDevice build() {
		if(searchData==null) {
			this.searchData = new MtxDeviceSearchData();	
		}
		MtxRequestSubscriberRemoveDevice device = new MtxRequestSubscriberRemoveDevice();
    	device.setDeviceSearchData(searchData);
    	return device;
    }
}
