package com.matrixx.vag.advice.model;

import com.matrixx.datacontainer.mdc.VisibleReverseCredit;

public class VisibleReverseCreditInternal extends VisibleReverseCredit{
    public enum DontReverseCode {
        ZERO_DELTA, NO_DELTA_PROMOS 
    }
    
	private DontReverseCode noReverseReason ;

	public DontReverseCode getNoReverseReason() {
		return noReverseReason;
	}

	public void setNoReverseReason(DontReverseCode noReverseReason) {
		this.noReverseReason = noReverseReason;
	}
}
