/**
 * 
 */
package com.matrixx.vag.exception;

import com.matrixx.vag.common.Constants.RESULT_CODES;

/**
 * @author mnguyen
 */
public class InvalidRequestParameterException extends InvalidRequestException {

    private static final long serialVersionUID = 5888239349416968033L;

    /**
     * @param message
     */
    public InvalidRequestParameterException(String message) {
        super(RESULT_CODES.HTTP_BAD_REQUEST, message);
    }

    /**
     * @param message
     * @param cause
     */
    public InvalidRequestParameterException(String message, Throwable cause) {
        super(RESULT_CODES.HTTP_BAD_REQUEST, message, cause);
    }

}
