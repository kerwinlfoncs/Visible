package com.matrixx.vag.subscriber.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.matrixx.datacontainer.MtxObjectId;
import com.matrixx.datacontainer.MtxTimestamp;
import com.matrixx.datacontainer.mdc.*;
import com.matrixx.platform.MatrixxContext;
import com.matrixx.vag.advice.service.PaymentAdviceService;
import com.matrixx.vag.common.*;
import com.matrixx.vag.common.Constants.*;
import com.matrixx.vag.common.coverage.Generated;
import com.matrixx.vag.common.request.builder.MtxPurchasedOfferDataBuilder;
import com.matrixx.vag.common.request.builder.MtxRequestSubscriberAdjustBalanceBuilder;
import com.matrixx.vag.common.request.builder.MtxRequestSubscriberCancelOfferBuilder;
import com.matrixx.vag.common.request.builder.MtxRequestSubscriberModifyOfferBuilder;
import com.matrixx.vag.common.request.builder.MtxRequestSubscriberPurchaseOfferBuilder;
import com.matrixx.vag.common.request.builder.MtxRequestSubscriberRefundPaymentBuilder;
import com.matrixx.vag.common.request.builder.MtxRequestSubscriptionModifyBuilder;
import com.matrixx.vag.config.AppPropertyParser;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.exception.CommonUtilsException;
import com.matrixx.vag.exception.IntegrationServiceException;
import com.matrixx.vag.exception.InvalidRequestException;
import com.matrixx.vag.exception.MtxResponseException;
import com.matrixx.vag.exception.PaymentAdviceException;
import com.matrixx.vag.exception.RefundServiceException;
import com.matrixx.vag.exception.RefundServiceException;
import com.matrixx.vag.exception.VisibleServiceException;
import com.matrixx.vag.service.IntegrationService;
import com.matrixx.vag.subscriber.service.model.RefundEventInfo;
import com.matrixx.vag.subscriber.service.model.RefundPaymentInfo;
import com.matrixx.vag.tax.client.TaxApiClient;
import com.matrixx.vag.tax.model.ServiceTaxRequest;
import com.matrixx.vag.tax.model.ServiceTaxResponse;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.beans.IntrospectionException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.*;
import java.util.Map.Entry;

import static com.matrixx.platform.LogUtils.*;
import static com.matrixx.vag.common.Constants.MATRIXX_CONSTANTS.CHRG_PURCHASE_FULL_AMOUNT;

@SuppressWarnings("unused")
@Configuration
public class RefundServiceV3 extends IntegrationService {

    private RequestValidator requestValidator;

    private final ObjectMapper objectMapper = new ObjectMapper();

    private String ROUTE;
    private String REFUND_TYPE;
    private static final String REC_EVENT_SET = "RecEventSet";
    private static final String CHARGE_MAP = "ChargeMap";
    private static final String REFUND_EVENT_MAP = "REFUND_EVENT_MAP";
    private static final String CATALOG_ITEM_RESOURCE_ID = "CatalogItemResourceId";
    private static final String MAINBALANCE_RESOURCE_ID = "MainbalanceResourceId";
    private static final String PAYMENT_RESOURCE_ID = "PaymentResourceId";
    private static final String GIFTER_EXTERNAL_ID = "GifterExternalId";
    private static final String SECONDARY_EVENT_ID = "SecondaryEventId";
    private static final String REFUND_AMOUNT = "MainBalanceImpact";

    // private static final String CANCEL_SERVICES_NO = "0";
    // private static final String CANCEL_SERVICES_YES = "1";

    private static final String ROUNDING_ERROR_ADJUSTMENT = "rounding_error_adjustment";
    private static final String UNKNOWN_REFUND_TYPE = " Unknown refund type";

    private static final Logger m_logger = LoggerFactory.getLogger(RefundServiceV3.class);

    @Generated
    @Bean(name = "RefundServiceV3")
    RefundServiceV3 getService() {
        return new RefundServiceV3();
    }

    /**
     * Constructor.
     */
    public RefundServiceV3() {
        this.requestValidator = new RequestValidator();
    }

    public void refundService(VisibleRequestRefundService input,
                              VisibleResponseRefundService output)
            throws Exception {
        // Determine routing data
        this.ROUTE = getRoute(MatrixxContext.getRequest());

        this.REFUND_TYPE = StringUtils.isBlank(input.getRefundType())
                ? "" : input.getRefundType().trim();
        if (StringUtils.isBlank(this.REFUND_TYPE)
                || SUBSCRIBER_SERVICE_CONSTANTS.BILL_CYCLE_FLAT.equalsIgnoreCase(
                        this.REFUND_TYPE)) {
            // Refund types 0-BillCycleFlat 1-BillCycleProrataInsurance 2-RemorseFlatInsurance
            try {
                refundServiceDefaultV3(input, output);
            } catch (Exception e) {
                output.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
                output.setResultText(
                        "SubscriberExternalID: " + input.getSubscriberExternalId()
                                + " Error Message: " + e.getMessage());
            }
        } else if (SUBSCRIBER_SERVICE_CONSTANTS.BILL_CYCLE_PRORATE.equalsIgnoreCase(
                this.REFUND_TYPE)
                || SUBSCRIBER_SERVICE_CONSTANTS.REMORSE_FLAT.equalsIgnoreCase(this.REFUND_TYPE)) {
            try {
                refundServiceInsuranceV3(input, output);
            } catch (Exception e) {
                output.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
                output.setResultText(
                        "SubscriberExternalID: " + input.getSubscriberExternalId()
                                + " Error Message: " + e.getMessage());
            }
        } else if (SUBSCRIBER_SERVICE_CONSTANTS.GIFT_SERVICE_REFUND.equalsIgnoreCase(
                this.REFUND_TYPE)) {
            try {
                refundServiceGiftV3(input, output);
            } catch (RefundServiceException | InvalidRequestException | MtxResponseException rse) {
                output.setResult(rse.getResultCode());
                output.setResultText(
                        "SubscriberExternalID: " + input.getSubscriberExternalId()
                                + " Error Message: " + rse.getMessage());
            } catch (Exception e) {
                output.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
                output.setResultText(
                        "SubscriberExternalID: " + input.getSubscriberExternalId()
                                + " Error Message: " + e.getMessage());
            }
        } else {
            throw new RefundServiceException(
                    RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, " SubscriberExternalID: "
                            + input.getSubscriberExternalId() + UNKNOWN_REFUND_TYPE);
        }
    }

    private boolean isCancelService(VisibleRequestRefundService input) {
        if (input.getCancelServices() != null) {
            return (input.getCancelServices() != null && input.getCancelServices().trim().equals(
                    SUBSCRIBER_SERVICE_CONSTANTS.REFUND_CANCEL_YES)) ? true : false;
        } else {
            return false;
        }
    }

    private void refundServiceDefaultV3(VisibleRequestRefundService input,
                                        VisibleResponseRefundService output)
            throws Exception {

        // Setup the logging key
        String loggingKey = getLoggingKey(input.getSubscriberExternalId());

        // Validate the request
        requestValidator.validateRefundRequestV3(loggingKey, input);

        // service cancellation
        final boolean serviceCancellation = isCancelService(input);

        // Query the subscriber data in MATRIXX. This is required to find devices attached to the
        // service for deleting any active sessions.
        DEBUG(m_logger, loggingKey + "Querying subscriber data in MATRIXX");
        MtxResponseSubscription benSub = querySubscriptionData(
                loggingKey, input.getSubscriberExternalId());

        CommonUtils.validateMtxResponse(
                loggingKey, LOG_MESSAGES.FAILED_TO_QUERY_SUBSCRIBER, benSub);

        Map<String, MtxRecurringEvent> recEventMap = new HashMap<String, MtxRecurringEvent>();
        Map<String, MtxPaymentAuthorizationEvent> payAuthEventMap = new HashMap<String, MtxPaymentAuthorizationEvent>();

        queryEventsByEventIds(loggingKey, input, recEventMap, payAuthEventMap);
        if (recEventMap == null || recEventMap.isEmpty()) {
            throw new RefundServiceException(
                    RESULT_CODES.HTTP_INTERNAL_ERROR,
                    LOG_MESSAGES.SUPPLIED_RECURRING_EVENTS_NOT_FOUND);
        }
        if (payAuthEventMap == null || payAuthEventMap.isEmpty()) {
            throw new RefundServiceException(
                    RESULT_CODES.HTTP_INTERNAL_ERROR,
                    LOG_MESSAGES.SUPPLIED_PAYAUTH_EVENTS_NOT_FOUND);
        }

        Long mainBalanceResourceId = getMainBalanceResourceId(loggingKey, benSub.getExternalId());
        // Locate the recurring charge event for the service offer and determine the refund amount
        // and build the adjustment reason.
        Map<String, Object> parseRecEventMap = parseRecurringEvents(
                loggingKey, recEventMap, input, mainBalanceResourceId);

        Long catalogItemResourceId = (Long) parseRecEventMap.get(CATALOG_ITEM_RESOURCE_ID);
        @SuppressWarnings("unchecked")
        HashMap<AbstractMap.SimpleImmutableEntry<String, Long>, BigDecimal> chargeMap = (HashMap<AbstractMap.SimpleImmutableEntry<String, Long>, BigDecimal>) parseRecEventMap.get(
                CHARGE_MAP);

        @SuppressWarnings("unchecked")
        Map<String, RefundEventInfo> refundEventInfoMap = (HashMap<String, RefundEventInfo>) parseRecEventMap.get(
                REFUND_EVENT_MAP);

        @SuppressWarnings("unchecked")
        HashSet<String> recEventSet = (HashSet<String>) parseRecEventMap.get(REC_EVENT_SET);

        // Need to determine the payment resource ID if refund amount is greater than zero
        BigDecimal refundAmountOutputMsg = BigDecimal.ZERO;

        // Get Pay Auth Events first
        // Compare Subscriber External Id and decide if payment was NOT done by beneficiary
        // Record Payers External Id to use it for refund.
        LinkedHashMap<RefundPaymentInfo, BigDecimal> paymentMap = getPaymentDetailsForPaymentAuthEventIds(
                loggingKey, input, payAuthEventMap, refundEventInfoMap);
        // Here we have PayAuthEvent. Use that get initiatorId/InitiatorId.
        // Query Wallet of payer to get mainbalanceResourceId. That should be used to do balance
        // adjustment before payment.
        for (RefundPaymentInfo rpi : paymentMap.keySet()) {
            if (rpi.getRei().getPayerExternalId().equalsIgnoreCase(
                    input.getSubscriberExternalId())) {
                rpi.getRei().setPayerMainbalanceResourceId(mainBalanceResourceId);
            } else {
                rpi.getRei().setPayerMainbalanceResourceId(
                        getMainBalanceResourceId(loggingKey, rpi.getRei().getPayerExternalId()));
            }
        }

        // Create a multi-request containing all the operations required to handle the refund
        // service as a single transaction
        DEBUG(m_logger, loggingKey + "Creating refund service transaction");
        MtxRequestMulti multiReq = new MtxRequestMulti();
        MtxRequestMulti multiReqSingleRefund = new MtxRequestMulti();
        MtxRequestMulti multiReqNonRefund = new MtxRequestMulti();

        String adjReason = "";
        if (StringUtils.isNotBlank(input.getRefundServiceOrderInfo().getReverseTax())
                && input.getRefundServiceOrderInfo().getReverseTax().equalsIgnoreCase("N")) {
            adjReason = CommonUtils.getPartialReversalPrefixDetails(recEventSet);
        } else {
            adjReason = CommonUtils.getReversalDetails(recEventSet);
        }

        for (Entry<AbstractMap.SimpleImmutableEntry<String, Long>, BigDecimal> chargeEntry : chargeMap.entrySet()) {
            // Adjustment and refund requests to be added only for main balances and not referrals
            if (chargeEntry.getValue().signum() != 0
                    && chargeEntry.getKey().getValue().longValue() == mainBalanceResourceId.longValue()) {
                // 2. Add the refund operation to the multi-request if balance is mainbalance
                addRefundRequestsV3(
                        loggingKey, input, chargeEntry.getValue(), paymentMap, multiReq, adjReason);
                refundAmountOutputMsg = refundAmountOutputMsg.add(
                        chargeEntry.getValue().setScale(2, RoundingMode.HALF_UP));
            }
        }

        // 3. Add the delete session operations to the multi-request
        if (serviceCancellation && benSub.getDeviceIdArray() != null
                && !benSub.getDeviceIdArray().isEmpty()) {
            for (MtxObjectId deviceId : benSub.getDeviceIdArray()) {
                multiReq.appendRequestList(getDeviceDeleteSessionRequest(deviceId));
            }
        }

        // 4. Add the cancel offer operation to the multi-request
        if (serviceCancellation) {
            // @formatter:off
            MtxRequestSubscriberCancelOfferBuilder builder = (new MtxRequestSubscriberCancelOfferBuilder())
                    .withSubscriberExternalId(input.getSubscriberExternalId().trim())
                    .withResourceId(catalogItemResourceId);
            // @formatter:on
            multiReq.appendRequestList(builder.build());
        }

        String refundAmountInfoOutputMsg = "";
        // Send the multi-request to MATRIXX and receive the multi-response
        MtxResponseMulti multiResp;
        int refundReqCount = 0;
        for (MtxRequest req : multiReq.getRequestList()) {
            if (!req.getMdcName().equals(MtxRequestSubscriberRefundPayment.class.getSimpleName())) {
                multiReqNonRefund.appendRequestList(req);
            } else {
                refundReqCount++;
            }
        }
        MtxRequestMulti cumulativePurchaseMulti = new MtxRequestMulti();
        if (refundReqCount == 1) {
            for (MtxRequest req : multiReq.getRequestList()) {
                if (req.getMdcName().equals(
                        MtxRequestSubscriberRefundPayment.class.getSimpleName())) {
                    MtxRequestSubscriberRefundPayment refundReq = (MtxRequestSubscriberRefundPayment) req;
                    multiReqNonRefund.appendRequestList(refundReq);
                    cumulativePurchaseMulti.appendRequestList(
                            getCumulativeReversePurchaseRequest(refundReq, input, loggingKey));
                }
            }
        }

        multiResp = multiRequest(loggingKey, this.ROUTE, multiReqNonRefund);
        CommonUtils.validateMtxResponse(
                loggingKey, LOG_MESSAGES.FAILED_TO_REFUND_SERVICE, multiResp);
        for (MtxResponse response : multiResp.getResponseList()) {
            if (response.getMdcName().equals(MtxResponseRefundPayment.class.getSimpleName())) {
                refundAmountInfoOutputMsg = ((MtxResponseRefundPayment) response).getRefundInfo().getRefundTime()
                        + "";
            }
        }

        if (refundReqCount > 1) {
            for (MtxRequest req : multiReq.getRequestList()) {
                if (req.getMdcName().equals(
                        MtxRequestSubscriberRefundPayment.class.getSimpleName())) {
                    MtxRequestSubscriberRefundPayment refundReq = (MtxRequestSubscriberRefundPayment) req;
                    multiReqSingleRefund.appendRequestList(refundReq);
                    cumulativePurchaseMulti.appendRequestList(
                            getCumulativeReversePurchaseRequest(refundReq, input, loggingKey));
                    multiResp = multiRequest(loggingKey, this.ROUTE, multiReqSingleRefund);
                    CommonUtils.validateMtxResponse(
                            loggingKey, LOG_MESSAGES.FAILED_TO_REFUND_SERVICE, multiResp);
                    for (MtxResponse response : multiResp.getResponseList()) {
                        if (response.getMdcName().equals(
                                MtxResponseRefundPayment.class.getSimpleName())) {
                            refundAmountInfoOutputMsg = ((MtxResponseRefundPayment) response).getRefundInfo().getRefundTime()
                                    + "";
                        }
                    }
                }
                multiReqSingleRefund = new MtxRequestMulti();
            }
        }
        // Execute cumulative reverse purchase requests for multi
        executeCumulativeReversePurchaseForRefunds(loggingKey, cumulativePurchaseMulti);

        // Prepare the API response
        output.setResult(multiResp.getResult());
        output.setResultText(
                "SubscriberExternalID: " + input.getSubscriberExternalId() + " Response: "
                        + multiResp.getResultText());

        // Referral Credit change - This should be amount refunded to mainbalance only.
        output.setRefundedAmount(
                (refundAmountOutputMsg.setScale(2, RoundingMode.HALF_UP)).toPlainString());
        output.setRefundAmountInfo(refundAmountInfoOutputMsg);
    }

    private Long getMainBalanceResourceId(String loggingKey, String subExternalId)
            throws MtxResponseException {
        String methodKey = loggingKey + " getMainBalanceResourceId: ";
        DEBUG(m_logger, loggingKey + "Querying subscriber wallet in MATRIXX");
        MtxResponseWallet wallet = querySubscriptionWallet(loggingKey, this.ROUTE, subExternalId);
        CommonUtils.validateMtxResponse(
                loggingKey, LOG_MESSAGES.FAILED_TO_QUERY_SUBSCRIBER_WALLET, wallet);
        Long mainBalanceResourceId = null;
        for (MtxBalanceInfo bInfo : wallet.getBalanceArray()) {
            if (bInfo.getContainer().getName().equals(MtxBalanceInfoSimple.class.getSimpleName())) {
                MtxBalanceInfoSimple bis = (MtxBalanceInfoSimple) bInfo;
                if (bis.getIsMainBalance()) {
                    return bInfo.getResourceId();
                }
            }
        }
        return null;
    }

    private void refundServiceInsuranceV3(VisibleRequestRefundService input,
                                          VisibleResponseRefundService output)
            throws Exception {

        // Setup the logging key
        String loggingKey = getLoggingKey(input.getSubscriberExternalId());
        String localKey = loggingKey + " refundServiceInsuranceV3: ";

        // Validate the request
        requestValidator.validateRefundRequestV3(loggingKey, input);

        Long mainBalanceResourceId = getMainBalanceResourceId(
                loggingKey, input.getSubscriberExternalId());

        Map<String, MtxRecurringEvent> recEventMap = new HashMap<String, MtxRecurringEvent>();
        Map<String, MtxPaymentAuthorizationEvent> payAuthEventMap = new HashMap<String, MtxPaymentAuthorizationEvent>();

        queryEventsByEventIds(loggingKey, input, recEventMap, payAuthEventMap);
        if (recEventMap == null || recEventMap.isEmpty()) {
            throw new RefundServiceException(
                    RESULT_CODES.HTTP_BAD_REQUEST,
                    LOG_MESSAGES.SUPPLIED_RECURRING_EVENTS_NOT_FOUND);
        }
        if (payAuthEventMap == null || payAuthEventMap.isEmpty()) {
            throw new RefundServiceException(
                    RESULT_CODES.HTTP_BAD_REQUEST,
                    LOG_MESSAGES.SUPPLIED_RECURRING_EVENTS_NOT_FOUND);
        }

        // Locate the recurring charge event for the service offer and determine the refund amount
        // and build the adjustment reason.
        Map<String, Object> parseRecEventMap = parseRecurringEvents(
                loggingKey, recEventMap, input, mainBalanceResourceId);

        Long catalogItemResourceId = (Long) parseRecEventMap.get(CATALOG_ITEM_RESOURCE_ID);

        @SuppressWarnings("unchecked")
        Map<AbstractMap.SimpleImmutableEntry<String, Long>, BigDecimal> chargeMap = (HashMap<AbstractMap.SimpleImmutableEntry<String, Long>, BigDecimal>) parseRecEventMap.get(
                CHARGE_MAP);

        @SuppressWarnings("unchecked")
        Map<String, RefundEventInfo> refundEventInfoMap = (HashMap<String, RefundEventInfo>) parseRecEventMap.get(
                REFUND_EVENT_MAP);

        @SuppressWarnings("unchecked")
        HashSet<String> recEventSet = (HashSet<String>) parseRecEventMap.get(REC_EVENT_SET);

        VisiblePurchasedOfferExtension vpoXtn = (VisiblePurchasedOfferExtension) parseRecEventMap.get(
                VisiblePurchasedOfferExtension.class.getSimpleName());

        LinkedHashMap<RefundPaymentInfo, BigDecimal> paymentMap = getPaymentDetailsForPaymentAuthEventIds(
                loggingKey, input, payAuthEventMap, refundEventInfoMap);
        for (RefundPaymentInfo rpi : paymentMap.keySet()) {
            if (rpi.getRei().getPayerExternalId().equalsIgnoreCase(
                    input.getSubscriberExternalId())) {
                rpi.getRei().setPayerMainbalanceResourceId(mainBalanceResourceId);
            } else {
                rpi.getRei().setPayerMainbalanceResourceId(
                        getMainBalanceResourceId(loggingKey, rpi.getRei().getPayerExternalId()));
            }
        }

        // Create a multi-request containing all the operations required to handle the refund
        // service as a single transaction
        String adjReason = CommonUtils.getReversalDetails(recEventSet);

        // Create a multi-request containing all the operations required to handle the refund
        // service as a single transaction
        MtxResponseMulti multiRespRefundService = new MtxResponseMulti();

        BigDecimal refundAmountOutputMsg = BigDecimal.ZERO;
        String refundAmountInfoOutputMsg = "";

        if (input.getRefundType().equals(SUBSCRIBER_SERVICE_CONSTANTS.REMORSE_FLAT)) {
            Map<String, Object> refundMap = doRemorseRefundV3(
                    loggingKey, chargeMap, paymentMap, adjReason, mainBalanceResourceId,
                    catalogItemResourceId, input);
            multiRespRefundService = (MtxResponseMulti) refundMap.get(
                    MtxResponseMulti.class.getSimpleName());
            refundAmountOutputMsg = (BigDecimal) refundMap.get("RefundAmountOutputMsg");
            refundAmountInfoOutputMsg = (String) refundMap.get("RefundAmountInfoOutputMsg");
        } else if (input.getRefundType().equals(SUBSCRIBER_SERVICE_CONSTANTS.BILL_CYCLE_PRORATE)) {
            Map<String, Object> refundMap = doProratedRefundV3(
                    loggingKey, this.ROUTE, paymentMap, adjReason, mainBalanceResourceId,
                    catalogItemResourceId, vpoXtn, input);
            multiRespRefundService = (MtxResponseMulti) refundMap.get(
                    MtxResponseMulti.class.getSimpleName());
            refundAmountOutputMsg = (BigDecimal) refundMap.get("RefundAmountOutputMsg");
            refundAmountInfoOutputMsg = (String) refundMap.get("RefundAmountInfoOutputMsg");
        }
        // Prepare the API response
        output.setResult(multiRespRefundService.getResult());
        output.setResultText(
                "SubscriberExternalID: " + input.getSubscriberExternalId() + " Response: "
                        + multiRespRefundService.getResultText());
        output.setRefundAmountInfo(refundAmountInfoOutputMsg);

        output.setRefundedAmount(
                (refundAmountOutputMsg.setScale(2, RoundingMode.HALF_UP)).toPlainString());
    }

    private Map<String, MtxRecurringEvent> queryRecurringHistoryForEventIds(String loggingKey,
                                                                            List<String> recurringEventIdsList)
            throws MtxResponseException {
        String methodKey = loggingKey + " queryRecurringHistoryForEventIds: ";
        INFO(m_logger, methodKey + "Querying recurring history by event id list in MATRIXX");

        Map<String, MtxEvent> eventTable = queryEvents(loggingKey, recurringEventIdsList);
        Map<String, MtxRecurringEvent> recurringEventTable = new HashMap<String, MtxRecurringEvent>();
        eventTable.forEach((k, v) -> {
            recurringEventTable.put(k, (MtxRecurringEvent) v);
        });
        return recurringEventTable;
    }

    private Map<String, MtxEvent> querySecondaryEventsByEventIds(String loggingKey,
                                                                 String route,
                                                                 List<String> secondaryEventIdsList)
            throws MtxResponseException {
        String methodKey = loggingKey + " querySecondaryEventsByEventIds: ";
        INFO(m_logger, methodKey + "Querying secondary events by event id in MATRIXX");

        Map<String, MtxEvent> eventTable = queryEvents(loggingKey, secondaryEventIdsList);
        return eventTable;
    }

    private void queryEventsByEventIds(String loggingKey,
                                       VisibleRequestRefundService request,
                                       Map<String, MtxRecurringEvent> recEventMap,
                                       Map<String, MtxPaymentAuthorizationEvent> payAuthEventMap)
            throws MtxResponseException {
        String methodKey = loggingKey + " queryEventsByEventIds: ";
        INFO(m_logger, methodKey + "Querying history by event id list in MATRIXX");

        List<String> eventList = new ArrayList<String>();
        List<String> reList = new ArrayList<String>();
        List<String> paeList = new ArrayList<String>();
        for (RefundServiceEventGroup eg : request.getEventGroupList()) {
            eventList.add(eg.getRecurringEventId());
            reList.add(eg.getRecurringEventId());
            for (String peid : eg.getPaymentAuthorizationEventIds()) {
                eventList.add(peid);
                paeList.add(peid);
            }
        }

        Map<String, MtxEvent> eventTable = queryEvents(loggingKey, eventList);
        for (Map.Entry<String, MtxEvent> entry : CommonUtils.emptyIfNull(eventTable.entrySet())) {
            if (reList.contains(entry.getKey())) {
                recEventMap.put(entry.getKey(), (MtxRecurringEvent) entry.getValue());
            }
            if (paeList.contains(entry.getKey())) {
                payAuthEventMap.put(
                        entry.getKey(), (MtxPaymentAuthorizationEvent) entry.getValue());
            }
        }
    }

    private Map<String, MtxEvent> queryEvents(String loggingKey, List<String> eventIdsList)
            throws MtxResponseException {
        String methodKey = loggingKey + " queryEvents: ";
        String eventIds = String.join(",", eventIdsList);
        Map<String, MtxEvent> eventTable = new HashMap<String, MtxEvent>();
        EventQueryResponseEvents response = queryEventListByEventIds(
                loggingKey, this.ROUTE, eventIds);

        CommonUtils.validateMtxResponse(methodKey, LOG_MESSAGES.FAILED_TO_QUERY_EVENTS, response);
        for (EventQueryEventInfo eventInfo : CommonUtils.emptyIfNull(response.getEventList())) {
            eventTable.put(eventInfo.getEventDetails().getEventId(), eventInfo.getEventDetails());
        }
        INFO(m_logger, methodKey + "Retrieved " + eventTable.size() + " event(s)");

        return eventTable;
    }

    private Map<String, Object> parseRecurringEvents(String loggingKey,
                                                     Map<String, MtxRecurringEvent> eventTable,
                                                     VisibleRequestRefundService input,
                                                     long benMainBalanceResourceId)
            throws RefundServiceException {
        String methodKey = loggingKey + " parseRecurringEvents: ";

        Map<String, Object> retMap = new HashMap<String, Object>();
        Long catalogItemResourceId = null;
        int finalCatalogItemIndex = -1;
        String finalCatalogItemExternalId = null;
        // HashMap<Long, BigDecimal> chargeMap = new HashMap<Long, BigDecimal>();
        Map<AbstractMap.SimpleImmutableEntry<String, Long>, BigDecimal> chargeMap = new HashMap<AbstractMap.SimpleImmutableEntry<String, Long>, BigDecimal>();
        Map<String, RefundEventInfo> refundEventMap = new HashMap<String, RefundEventInfo>();

        HashSet<String> recEventSet = new HashSet<String>();
        VisiblePurchasedOfferExtension vpoXtn = null;
        Boolean parseXtn = SUBSCRIBER_SERVICE_CONSTANTS.BILL_CYCLE_PRORATE.equalsIgnoreCase(
                this.REFUND_TYPE)
                || SUBSCRIBER_SERVICE_CONSTANTS.REMORSE_FLAT.equalsIgnoreCase(this.REFUND_TYPE);

        for (MtxRecurringEvent recurringEvent : eventTable.values()) {
            int catalogItemIndex = -1; // workaround to avoid event mixup
            String catalogItemExternalId = null;

            if (recurringEvent.getChargeList() == null
                    || recurringEvent.getChargeList().isEmpty()) {
                continue;
            }

            // Append the event ID to the adjustment reason (required by the GL processor for
            // return/reversal trigger)
            recEventSet.add(recurringEvent.getEventId());

            for (MtxEventCharge charge : recurringEvent.getChargeList()) {
                if (charge.getAmount() == null || charge.getAmount().signum() == 0) {
                    // Zero charges need not be refunded.
                    continue;
                }

                // Charge-sni->OfferIndex-->Offer-->BundleIndex-->Bundle-->CatalogItemIndex-->CatalogItem
                // Catalog item is supplied in input. If it is supplied then skip other catalog
                // items.
                if (charge.getAppliedOfferIndex() == null
                        || recurringEvent.getAppliedOfferArray().size() <= charge.getAppliedOfferIndex()) {
                    continue;
                }
                MtxEventAppliedOffer offer = recurringEvent.getAtAppliedOfferArray(
                        charge.getAppliedOfferIndex());
                if (recurringEvent.getAppliedCatalogItemArray() == null
                        || recurringEvent.getAppliedCatalogItemArray().isEmpty()) {
                    // ci = null;
                } else if (offer.getAppliedBundleIndex() != null
                        && recurringEvent.getAppliedBundleArray().size() > offer.getAppliedBundleIndex()) {
                    MtxEventAppliedBundle bundle = recurringEvent.getAtAppliedBundleArray(
                            offer.getAppliedBundleIndex());
                    if (bundle.getAppliedCatalogItemIndex() != null
                            && recurringEvent.getAppliedCatalogItemArray().size() > bundle.getAppliedCatalogItemIndex()) {
                        catalogItemIndex = bundle.getAppliedCatalogItemIndex();
                    }
                } else if (offer.getAppliedCatalogItemIndex() != null
                        && recurringEvent.getAppliedCatalogItemArray().size() > offer.getAppliedCatalogItemIndex()) {
                    catalogItemIndex = offer.getAppliedCatalogItemIndex();
                }

                if (catalogItemIndex >= 0) {
                    MtxEventAppliedCatalogItem ci = recurringEvent.getAtAppliedCatalogItemArray(
                            catalogItemIndex);
                    catalogItemExternalId = ci.getCatalogItemExternalId();
                    // Catalog item is supplied in input. If it is supplied then skip other catalog
                    // items.
                    if (!("" + catalogItemExternalId).equals(
                            "" + input.getRefundServiceOrderInfo().getServiceOfferExternalId())) {
                        continue;
                    }
                    catalogItemResourceId = ci.getCatalogItemResourceId();
                    finalCatalogItemIndex = catalogItemIndex;
                    finalCatalogItemExternalId = catalogItemExternalId;
                }
                // }
                // Charge-->BalanceUpdateIndex-->BalanceUpdate
                if (charge.getBalanceUpdateIndex() != null
                        && recurringEvent.getBalanceUpdateArray().size() > charge.getBalanceUpdateIndex()) {
                    MtxBalanceUpdate balanceUpdate = recurringEvent.getAtBalanceUpdateArray(
                            charge.getBalanceUpdateIndex());
                    // Record the refund amount for OrderFlatRefund. For Prorated Refund
                    // this amount will be derived from Offer Cancel.
                    if (benMainBalanceResourceId == balanceUpdate.getBalanceResourceId()) {
                        chargeMap.put(
                                new AbstractMap.SimpleImmutableEntry<>(
                                        recurringEvent.getEventId(),
                                        balanceUpdate.getBalanceResourceId()),
                                charge.getAmount());
                        RefundEventInfo rei = new RefundEventInfo();
                        rei.setBeneficiaryMainbalanceResourceId(
                                balanceUpdate.getBalanceResourceId());
                        rei.setMainBalanceChargeAmount(charge.getAmount());
                        rei.setRecurringEventId(recurringEvent.getEventId());
                        refundEventMap.put(recurringEvent.getEventId(), rei);
                    }
                }
            }

            DEBUG(
                    m_logger,
                    methodKey + "catalogItemResourceId of refund: " + catalogItemResourceId);
            DEBUG(
                    m_logger, methodKey + "CatalogItemIndex of refund as per recurring event: "
                            + finalCatalogItemIndex);
            DEBUG(
                    m_logger,
                    methodKey + "CatalogItemExternalId of refund: " + finalCatalogItemExternalId);
            if (parseXtn != null && parseXtn && catalogItemExternalId != null
                    && catalogItemResourceId != null) {
                for (MtxEventAppliedBundle bundle : CommonUtils.emptyIfNull(
                        recurringEvent.getAppliedBundleArray())) {
                    if ((bundle.getAppliedCatalogItemIndex() == finalCatalogItemIndex)
                            && (bundle.getPurchasedBundleAttr() != null)) {
                        vpoXtn = (VisiblePurchasedOfferExtension) bundle.getPurchasedBundleAttr();
                    }
                }
                if (vpoXtn == null) {
                    for (MtxEventAppliedOffer offer : CommonUtils.emptyIfNull(
                            recurringEvent.getAppliedOfferArray())) {
                        if ((offer.getAppliedCatalogItemIndex() == finalCatalogItemIndex)
                                && (offer.getPurchasedOfferAttr() != null)) {
                            vpoXtn = (VisiblePurchasedOfferExtension) offer.getPurchasedOfferAttr();
                        }
                    }
                }
            }

            if (!this.REFUND_TYPE.equals(SUBSCRIBER_SERVICE_CONSTANTS.REMORSE_FLAT)) {
                break;
            }

        }

        if (chargeMap.size() == 0) {
            DEBUG(m_logger, methodKey + LOG_MESSAGES.VALID_CHARGES_WITH_BALANCE_UPDATES_NOT_FOUND);
            throw new RefundServiceException(
                    RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,
                    LOG_MESSAGES.VALID_CHARGES_WITH_BALANCE_UPDATES_NOT_FOUND);
        }

        if (catalogItemResourceId == null) {
            DEBUG(m_logger, methodKey + LOG_MESSAGES.CATALOG_ITEM_RESOURCE_NOT_FOUND);
            throw new RefundServiceException(
                    RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,
                    LOG_MESSAGES.CATALOG_ITEM_RESOURCE_NOT_FOUND);
        }
        retMap.put(CATALOG_ITEM_RESOURCE_ID, catalogItemResourceId);
        retMap.put(CHARGE_MAP, chargeMap);
        retMap.put(REFUND_EVENT_MAP, refundEventMap);
        retMap.put(REC_EVENT_SET, recEventSet);
        retMap.put(VisiblePurchasedOfferExtension.class.getSimpleName(), vpoXtn);
        return retMap;
    }

    private LinkedHashMap<RefundPaymentInfo, BigDecimal> getPaymentDetailsForPaymentAuthEventIds(String loggingKey,
                                                                                                 VisibleRequestRefundService input,
                                                                                                 Map<String, MtxPaymentAuthorizationEvent> paytAuthMap,
                                                                                                 Map<String, RefundEventInfo> refundEventInfoMap)
            throws MtxResponseException, RefundServiceException {
        String methodKey = loggingKey + " getPaymentDetailsForPaymentAuthEventIds: ";

        LinkedHashMap<RefundPaymentInfo, BigDecimal> paymentMap = new LinkedHashMap<RefundPaymentInfo, BigDecimal>();
        TreeMap<String, MtxPaymentInfo> tmpMap = new TreeMap<String, MtxPaymentInfo>();
        DEBUG(m_logger, methodKey + "Querying subscriber payment history in MATRIXX");

        for (MtxPaymentAuthorizationEvent payAuthEvent : paytAuthMap.values()) {
            MtxResponsePaymentHistory paymentHistory = querySubscriberPaymentHistoryByExternalId(
                    loggingKey, this.ROUTE, payAuthEvent.getInitiatorExternalId());
            CommonUtils.validateMtxResponse(
                    loggingKey, LOG_MESSAGES.FAILED_TO_QUERY_PAYMENT_HISTORY, paymentHistory);

            BigDecimal payAuthCap = AppPropertyProvider.getInstance().getBigDecimal(
                    SUBSCRIBER_SERVICE_CONSTANTS.SERVICE_REFUND_PAYAUTH_CAP);
            for (MtxPaymentInfo pInfo : CommonUtils.emptyIfNull(
                    paymentHistory.getPaymentInfoList())) {
                if (pInfo.getAuthorizationEventId() != null
                        && paytAuthMap.keySet().contains(pInfo.getAuthorizationEventId())) {
                    tmpMap.put(pInfo.getAuthorizationEventId(), pInfo);
                }
            }
        }

        if (tmpMap == null || tmpMap.isEmpty() || tmpMap.size() < paytAuthMap.size()) {
            Long resultCode = RESULT_CODES.HTTP_INTERNAL_ERROR;
            String message = LOG_MESSAGES.FAILED_TO_GET_MATCHING_PAYMENT_HISTORY_FOR_PAY_AUTH_EVENT_IDS;
            throw new RefundServiceException(resultCode, message);
        }

        // Map is sorted in decending order and add amount to match
        for (Entry<String, MtxPaymentInfo> entry : tmpMap.descendingMap().entrySet()) {
            MtxPaymentInfo pInfo = entry.getValue();
            BigDecimal authorizationAmount = pInfo.getAuthorizationAmount();
            for (MtxPaymentRefundInfo rInfo : CommonUtils.emptyIfNull(pInfo.getRefundInfoList())) {
                authorizationAmount = authorizationAmount.subtract(rInfo.getRefundAmount());
            }
            if (authorizationAmount.signum() == 1) {
                RefundPaymentInfo rpi = new RefundPaymentInfo(pInfo);
                MtxPaymentAuthorizationEvent payAuthEvent = paytAuthMap.get(entry.getKey());
                rpi.setPayAuthEvent(payAuthEvent);

                for (RefundServiceEventGroup rse : input.getEventGroupList()) {
                    if (!rse.getPaymentAuthorizationEventIds().contains(entry.getKey())) {
                        continue;
                    }
                    RefundEventInfo rei = refundEventInfoMap.get(rse.getRecurringEventId());
                    rei.setPaymentAuthorizationEventId(entry.getKey());
                    rei.setPayerExternalId(payAuthEvent.getInitiatorExternalId());
                    rpi.setRei(rei);
                }

                paymentMap.put(rpi, authorizationAmount);
            }
        }
        return paymentMap;
    }

    private LinkedHashMap<RefundPaymentInfo, BigDecimal> getPaymentDetailsForPaymentAuthEventIds(String loggingKey,
                                                                                                 String subscriptionExternalId,
                                                                                                 ArrayList<String> paymentAuthEventIds)
            throws MtxResponseException, RefundServiceException {
        String methodKey = loggingKey + " getPaymentDetailsForPaymentAuthEventIds: ";
        LinkedHashMap<RefundPaymentInfo, BigDecimal> paymentMap = new LinkedHashMap<RefundPaymentInfo, BigDecimal>();
        DEBUG(m_logger, methodKey + "Querying subscriber payment history in MATRIXX");
        MtxResponsePaymentHistory paymentHistory = querySubscriberPaymentHistoryByExternalId(
                loggingKey, this.ROUTE, subscriptionExternalId);
        CommonUtils.validateMtxResponse(
                loggingKey, LOG_MESSAGES.FAILED_TO_QUERY_PAYMENT_HISTORY, paymentHistory);
        // Get paymentInfo for the events paymentAuthEvents
        TreeMap<String, MtxPaymentInfo> tmpMap = new TreeMap<String, MtxPaymentInfo>();
        BigDecimal payAuthCap = AppPropertyProvider.getInstance().getBigDecimal(
                SUBSCRIBER_SERVICE_CONSTANTS.SERVICE_REFUND_PAYAUTH_CAP);

        for (MtxPaymentInfo pInfo : CommonUtils.emptyIfNull(paymentHistory.getPaymentInfoList())) {
            if (pInfo.getAuthorizationEventId() != null
                    && paymentAuthEventIds.contains(pInfo.getAuthorizationEventId())) {
                tmpMap.put(pInfo.getAuthorizationEventId(), pInfo);
            }
        }

        if (tmpMap == null || tmpMap.isEmpty() || tmpMap.size() < paymentAuthEventIds.size()) {
            Long resultCode = RESULT_CODES.HTTP_INTERNAL_ERROR;
            String message = LOG_MESSAGES.FAILED_TO_GET_MATCHING_PAYMENT_HISTORY_FOR_PAY_AUTH_EVENT_IDS;
            throw new RefundServiceException(resultCode, message);
        }

        // Map is sorted in decending order and add amount to match
        for (Entry<String, MtxPaymentInfo> entry : tmpMap.descendingMap().entrySet()) {
            MtxPaymentInfo pInfo = entry.getValue();
            BigDecimal authorizationAmount = pInfo.getAuthorizationAmount();
            for (MtxPaymentRefundInfo rInfo : CommonUtils.emptyIfNull(pInfo.getRefundInfoList())) {
                authorizationAmount = authorizationAmount.subtract(rInfo.getRefundAmount());
            }
            if (authorizationAmount.signum() == 1) {
                RefundPaymentInfo rpi = new RefundPaymentInfo(pInfo);
                paymentMap.put(rpi, authorizationAmount);
            }
        }

        return paymentMap;
    }

    private MtxRequestMulti addRefundRequestsV3(String loggingKey,
                                                VisibleRequestRefundService input,
                                                BigDecimal chargeAmount,
                                                LinkedHashMap<RefundPaymentInfo, BigDecimal> paymentMap,
                                                MtxRequestMulti multiReqRefundService,
                                                String adjReason)
            throws RefundServiceException, Exception {

        BigDecimal remainingAmount = chargeAmount;
        DEBUG(m_logger, loggingKey + "addRefundRequestsV3");

        for (Entry<RefundPaymentInfo, BigDecimal> paymentEntry : paymentMap.entrySet()) {
            if (paymentEntry.getKey().areFundsNotAvailable()) {
                continue;
            }
            BigDecimal refundAmount = BigDecimal.ZERO;
            if (remainingAmount.compareTo(paymentEntry.getValue()) == -1
                    || remainingAmount.compareTo(paymentEntry.getValue()) == 0) {
                refundAmount = remainingAmount;
            } else {
                refundAmount = paymentEntry.getValue();
            }
            remainingAmount = remainingAmount.subtract(paymentEntry.getValue());
            // @formatter:off
            MtxRequestSubscriberAdjustBalanceBuilder builderAdj = (new MtxRequestSubscriberAdjustBalanceBuilder())
                    .withSubscriberExternalId(paymentEntry.getKey().getPayAuthEvent().getInitiatorExternalId())
                    .withBalanceResourceId(paymentEntry.getKey().getRei().getPayerMainbalanceResourceId())
                    .withAmount(refundAmount.setScale(BRAINTREE_CONSTANTS.BT_AMOUNT_PRECISION, RoundingMode.HALF_UP))
                    .withReason(adjReason);
            // @formatter:on
            multiReqRefundService.appendRequestList(builderAdj.build());

            Map<String, String> offerAttributes = getOfferAttributes(
                    loggingKey, this.ROUTE,
                    input.getRefundServiceOrderInfo().getServiceOfferExternalId().trim());
            // @formatter:off
            MtxRequestSubscriberRefundPaymentBuilder builderRef = (new MtxRequestSubscriberRefundPaymentBuilder())
                    .withSubscriberExternalId(paymentEntry.getKey().getPayAuthEvent().getInitiatorExternalId())
                    .withPaymentMethodResourceId(paymentEntry.getKey().getMtxPaymentInfo().getResourceId())
                    .withAmount(refundAmount.setScale(BRAINTREE_CONSTANTS.BT_AMOUNT_PRECISION,RoundingMode.HALF_UP))
                    .withReason(offerAttributes.get(ATTR_NAME_REFUND_REASON))
                    .withInfo(adjReason);
            // @formatter:on

            multiReqRefundService.appendRequestList(builderRef.build());
            paymentEntry.getKey().addToBlockedFunds(
                    refundAmount.setScale(
                            BRAINTREE_CONSTANTS.BT_AMOUNT_PRECISION, RoundingMode.HALF_UP));
            remainingAmount = remainingAmount.add(
                    refundAmount.setScale(
                            BRAINTREE_CONSTANTS.BT_AMOUNT_PRECISION,
                            RoundingMode.HALF_UP)).subtract(refundAmount);
            if (remainingAmount.signum() != 1) {
                break;
            }
        }
        if (remainingAmount.signum() == 1) {
            throw new RefundServiceException(
                    RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,
                    LOG_MESSAGES.INSUFFICIENT_AUTHORIZATION_AMOUNT);
        }

        return multiReqRefundService;
    }

    /**
     * Preparing cumulative reverse purchase request for Refund
     *
     * @param refundReq
     * @param searchData
     * @param input
     * @param loggingKey
     * @return
     */
    private MtxRequestSubscriberPurchaseOffer getCumulativeReversePurchaseRequest(MtxRequestSubscriberRefundPayment refundReq,
                                                                                  VisibleRequestRefundService input,
                                                                                  String loggingKey) {
        DEBUG(
                m_logger, loggingKey + "Refund request found for amount : " + refundReq.getAmount()
                        + " .So preparing cumulative reverse purchase request");

        String reversePaymentOfferExternalId = AppPropertyProvider.getInstance().getString(
                OFFER_CONSTANTS.OFFER_EXTERNAL_ID_VISIBLE_REVERSE_SERVICE_PAYMENTS);
        // @formatter:off
        MtxPurchasedOfferData cumulativeRefundOfferData = (new MtxPurchasedOfferDataBuilder())
                .withOfferExternalId(reversePaymentOfferExternalId)
                .withOrderId(input.getRefundServiceOrderInfo().getReturnOrderId())
                .withAmount(refundReq.getAmount().setScale(BRAINTREE_CONSTANTS.BT_AMOUNT_PRECISION, RoundingMode.HALF_UP))
                .withInfo(refundReq.getInfo())
                .build();
        return (new MtxRequestSubscriberPurchaseOfferBuilder())
                .withSubscriberExternalId(input.getSubscriberExternalId())
                .withOfferData(cumulativeRefundOfferData)
                .build();
       // @formatter:on
    }

    /**
     * Executes cumulativeReversePurchase request individually
     *
     * @param loggingKey
     * @param route
     * @param cumulativePurchaseMulti
     * @throws RefundServiceException
     */
    private void executeCumulativeReversePurchaseForRefunds(String loggingKey,
                                                            MtxRequestMulti cumulativePurchaseMulti) {
        MtxResponseMulti cumulativeMultiResp;

        if (cumulativePurchaseMulti != null) {
            MtxRequestMulti multiRequestSingleCumulativeReveresePurchase = new MtxRequestMulti();
            for (MtxRequest req : cumulativePurchaseMulti.getRequestList()) {
                MtxRequestSubscriberPurchaseOffer cumulativePurchaseReq = (MtxRequestSubscriberPurchaseOffer) req;
                multiRequestSingleCumulativeReveresePurchase.appendRequestList(
                        cumulativePurchaseReq);
                VisiblePurchasedOfferExtension cumulativeOfferExtension = ((VisiblePurchasedOfferExtension) cumulativePurchaseReq.getOfferRequestArray().get(
                        0).getAttr());
                cumulativeMultiResp = multiRequest(
                        loggingKey, this.ROUTE, multiRequestSingleCumulativeReveresePurchase);
                if (cumulativeMultiResp == null
                        || cumulativeMultiResp.getResult() != RESULT_CODES.MTX_SUCCESS) {
                    String message = LOG_MESSAGES.FAILED_TO_PURCHASE_REVERSE_CUMULATIVE_OFFER
                            + " for amount : " + cumulativeOfferExtension.getChargeAmount() + " "
                            + (cumulativeMultiResp != null
                                    ? " - " + cumulativeMultiResp.getResultText() : "");
                    WARN(m_logger, loggingKey + message);
                }

                multiRequestSingleCumulativeReveresePurchase = new MtxRequestMulti();
            }
        }
    }

    private Map<String, Object> doRemorseRefundV3(String loggingKey,
                                                  Map<AbstractMap.SimpleImmutableEntry<String, Long>, BigDecimal> chargeMap,
                                                  LinkedHashMap<RefundPaymentInfo, BigDecimal> paymentMap,
                                                  String adjReason,
                                                  Long mainBalanceResourceId,
                                                  Long catalogItemResourceId,
                                                  VisibleRequestRefundService input)
            throws Exception {
        String taxApiResult = "";
        Map<String, Object> retMap = new HashMap<String, Object>();
        MtxRequestMulti multiReq = new MtxRequestMulti();
        MtxRequestMulti multiReqSingleRefund = new MtxRequestMulti();
        MtxRequestMulti multiReqNonRefund = new MtxRequestMulti();

        MtxResponseMulti multiResp = new MtxResponseMulti();
        BigDecimal refundAmountOutputMsg = BigDecimal.ZERO;
        String refundAmountInfoOutputMsg = "";
        // Creating multirequest For FlatFromOrderDate
        // cancel amount gets added to mainbalance. Reduce it before adjustment.
        // 20250522 - Veeresh - Balance Adjustment Amount is incorrect. BalanceAdjustment can
        // not of sum of all charges over upto three months.

        for (Entry<AbstractMap.SimpleImmutableEntry<String, Long>, BigDecimal> chargeEntry : chargeMap.entrySet()) {
            if (chargeEntry.getValue().signum() != 0) {

                BigDecimal balanceAdjustAmount = chargeEntry.getValue();

                if (balanceAdjustAmount.signum() != 0) {
                    if (chargeEntry.getKey().getValue().longValue() == mainBalanceResourceId.longValue()) {
                        // 2. Add the refund operation to the multi-request
                        multiReq = addRefundRequestsV3(
                                loggingKey, input, chargeEntry.getValue(), paymentMap, multiReq,
                                adjReason);
                    }
                }
                refundAmountOutputMsg = refundAmountOutputMsg.add(
                        chargeEntry.getValue().setScale(2, RoundingMode.HALF_UP));
            }
        }

        if (isCancelService(input)) {
            // @formatter:off
            MtxRequestSubscriberCancelOfferBuilder builder = (new MtxRequestSubscriberCancelOfferBuilder())
                    .withSubscriberExternalId(input.getSubscriberExternalId().trim())
                    .withResourceId(catalogItemResourceId);
           // @formatter:on
            multiReq.appendRequestList(builder.build());
        }

        for (MtxRequest req : multiReq.getRequestList()) {
            if (!req.getMdcName().equals(MtxRequestSubscriberRefundPayment.class.getSimpleName())) {
                multiReqNonRefund.appendRequestList(req);
            }
        }
        multiResp = multiRequest(loggingKey, multiReqNonRefund);
        CommonUtils.validateMtxResponse(
                loggingKey, LOG_MESSAGES.FAILED_TO_REFUND_SERVICE, multiResp);
        for (MtxRequest req : multiReq.getRequestList()) {
            if (req.getMdcName().equals(MtxRequestSubscriberRefundPayment.class.getSimpleName())) {
                multiReqSingleRefund.appendRequestList(req);
                multiResp = multiRequest(loggingKey, multiReqSingleRefund);
                if (multiResp == null || multiResp.getResult() != RESULT_CODES.MTX_SUCCESS) {
                    Long resultCode = multiResp != null
                            ? multiResp.getResult() : RESULT_CODES.HTTP_INTERNAL_ERROR;
                    String message = LOG_MESSAGES.FAILED_TO_REFUND_SERVICE
                            + (multiResp != null ? " - " + multiResp.getResultText() : "");
                    WARN(m_logger, loggingKey + message);
                    throw new RefundServiceException(resultCode, message);
                } else {
                    for (MtxResponse response : multiResp.getResponseList()) {
                        if (response.getMdcName().equals(
                                MtxResponseRefundPayment.class.getSimpleName())) {
                            refundAmountInfoOutputMsg = ((MtxResponseRefundPayment) response).getRefundInfo().getRefundTime()
                                    + "";
                        }
                    }
                }
            }
            multiReqSingleRefund = new MtxRequestMulti();
        }

        retMap.put(MtxResponseMulti.class.getSimpleName(), multiResp);
        retMap.put("RefundAmountInfoOutputMsg", refundAmountInfoOutputMsg);
        retMap.put("RefundAmountOutputMsg", refundAmountOutputMsg);
        return retMap;
    }

    private Map<String, Object> doProratedRefundV3(String loggingKey,
                                                   String route,
                                                   LinkedHashMap<RefundPaymentInfo, BigDecimal> paymentMap,
                                                   String adjReason,
                                                   Long mainBalanceResourceId,
                                                   Long catalogItemResourceId,
                                                   VisiblePurchasedOfferExtension vpoXtn,
                                                   VisibleRequestRefundService input)
            throws Exception {
        final String localKey = loggingKey + " doProratedRefundV3: ";
        boolean serviceCancellation = isCancelService(input);
        String taxApiResult = "";
        Map<String, Object> retMap = new HashMap<String, Object>();
        MtxRequestMulti multiReq = new MtxRequestMulti();
        // Split request into multiple multirequests - This is a dirty workaround as multiple
        // refunds in multicall is not working
        MtxRequestMulti multiReqSingleRefund = new MtxRequestMulti();
        MtxRequestMulti multiReqNonRefund = new MtxRequestMulti();
        MtxResponseMulti multiResp = new MtxResponseMulti();
        BigDecimal refundAmountOutputMsg = BigDecimal.ZERO;
        String refundAmountInfoOutputMsg = "";
        String taxTemplate = "";

        // Call cancellation in advisory mode and get amount
        Map<Long, BigDecimal> cancelImpactMap = new HashMap<Long, BigDecimal>();

        MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
        searchData.setExternalId(input.getSubscriberExternalId());
        cancelImpactMap = getRefundAmountFromCancelAOC(
                loggingKey, route, catalogItemResourceId, MATRIXX_CONSTANTS.CANCEL_TYPE_SCALED,
                searchData);

        ServiceTaxRequest taxApiRequest = new ServiceTaxRequest();

        ServiceTaxResponse taxDetailsFromEvent = objectMapper.readValue(
                vpoXtn.getTaxDetails(), ServiceTaxResponse.class);

        if (serviceCancellation && (taxDetailsFromEvent != null)) {

            MtxResponsePricingCatalogItem pricingCI = queryPricingCatalogItem(
                    loggingKey, route,
                    input.getRefundServiceOrderInfo().getServiceOfferExternalId().trim());

            if (pricingCI != null && pricingCI.getCatalogItemInfo() != null
                    && pricingCI.getCatalogItemInfo().getMetadataList() != null) {
                for (MtxPricingMetadataInfo pmi : pricingCI.getCatalogItemInfo().getMetadataList()) {
                    taxTemplate = pmi.getValue();
                }
                if (StringUtils.isNotBlank(taxTemplate)) {
                    taxApiRequest = CommonUtils.getServiceTaxRequestFromJsonString(taxTemplate);
                } else {
                    WARN(m_logger, localKey + StringUtils.SPACE + "TaxDetails are not available");
                    return null;
                }
            }

            if (taxDetailsFromEvent.getGeocode() != null) {
                taxApiRequest.setGeocode(taxDetailsFromEvent.getGeocode());
            }
        }

        // Creating multirequest For BillCycleProrated
        for (Entry<Long, BigDecimal> cancelImpact : CommonUtils.emptyIfNull(cancelImpactMap.entrySet())) {
            if (cancelImpact.getValue().signum() != 0) {
                if (cancelImpact.getKey().longValue() == mainBalanceResourceId.longValue()) {
                    // Add the refund operation to the multi-request.
                    multiReq = addRefundRequestsWithDeltaAdjustmentsV3(
                            loggingKey, route, input, cancelImpact.getKey(),
                            cancelImpact.getValue().abs(), paymentMap, multiReq, adjReason);

                    if (serviceCancellation) {
                        SimpleDateFormat dateFormat = new SimpleDateFormat(
                                TAX_CONSTANTS.GL_DATE_FORMAT);
                        Date currentDate = new Date();
                        dateFormat.format(currentDate);
                        taxApiRequest.setGlDate(dateFormat.format(currentDate));
                        taxApiRequest.setDiscountPrice(cancelImpact.getValue().abs());
                        taxApiRequest.setGrossPrice(cancelImpact.getValue().abs());

                        if (taxDetailsFromEvent.getVendorPayableNonProrated() != null
                                && taxDetailsFromEvent.getVendorPayableNonProrated().signum() > 0) {
                            taxApiRequest.setVendorPayableNonProrated(
                                    taxDetailsFromEvent.getVendorPayableNonProrated());
                            BigDecimal vendorPayable = cancelImpact.getValue().abs().multiply(
                                    taxDetailsFromEvent.getVendorPayableNonProrated()).divide(
                                            vpoXtn.getChargeAmount(),
                                            TAX_CONSTANTS.TAX_API_DISPLAY_PRECISION,
                                            RoundingMode.HALF_UP);

                            DEBUG(
                                    m_logger, localKey
                                            + "VendorPayable = CancelAmount/ChargeAmount*VendorPayableNonProrated = "
                                            + cancelImpact.getValue().abs() + "/"
                                            + vpoXtn.getChargeAmount() + "*"
                                            + taxDetailsFromEvent.getVendorPayableNonProrated()
                                            + "=" + vendorPayable);

                            taxApiRequest.setVendorPayable(vendorPayable);
                        }

                        try {
                            // Call Tax API. Any tax error dusring cancellation should not block
                            // refund.
                            taxApiResult = TaxApiClient.getTaxApiResult(
                                    loggingKey, objectMapper.writeValueAsString(taxApiRequest));
                            vpoXtn.setTaxDetails(taxApiResult);
                        } catch (Exception e) {
                            StringWriter errors = new StringWriter();
                            e.printStackTrace(new PrintWriter(errors));
                            WARN(m_logger, errors.toString());
                        }
                    }
                }
                refundAmountOutputMsg = refundAmountOutputMsg.add(
                        cancelImpact.getValue().abs().setScale(2, RoundingMode.HALF_UP));
            }
        }
        if (serviceCancellation) {
            // add multirequest to cancel with tax amount Charges can be many but cancellation
            // will be for one catalog item only Modify offer / bundle to update tax details
            multiReq.appendRequestList(
                    CommonUtils.getSubscriberModifyOfferRequest(
                            searchData, catalogItemResourceId, vpoXtn));
            // @formatter:off
            MtxRequestSubscriberCancelOfferBuilder cob = (new MtxRequestSubscriberCancelOfferBuilder())
                    .withSubscriberExternalId(input.getSubscriberExternalId())
                    .withChargeCancelProrationType(MATRIXX_CONSTANTS.CANCEL_TYPE_SCALED)
                    .withProrationCatalogItemResourceId(catalogItemResourceId);
            // @formatter:on
            multiReq.appendRequestList(cob.build());
        }

        for (MtxRequest req : multiReq.getRequestList()) {
            if (req.getMdcName().equals(MtxRequestSubscriberAdjustBalance.class.getSimpleName())
                    && (serviceCancellation)) {
                MtxRequestSubscriberAdjustBalance adjReq = new MtxRequestSubscriberAdjustBalance(
                        req.getContainer());
                multiReqNonRefund.appendRequestList(req);
                // if (!adjReason.equalsIgnoreCase(adjReq.getReason())) {
                // // Let rounding adjustments only. Prorated Refund puts money by cancellation. No
                // // full adjustment needed.
                // multiReqNonRefund.appendRequestList(req);
                // }
            } else if (!req.getMdcName().equals(
                    MtxRequestSubscriberRefundPayment.class.getSimpleName())) {
                multiReqNonRefund.appendRequestList(req);
            }
        }
        multiResp = multiRequest(loggingKey, route, multiReqNonRefund);

        CommonUtils.validateMtxResponse(
                loggingKey, LOG_MESSAGES.FAILED_TO_REFUND_SERVICE, multiResp);

        for (MtxRequest req : multiReq.getRequestList()) {
            if (req.getMdcName().equals(MtxRequestSubscriberRefundPayment.class.getSimpleName())) {
                multiReqSingleRefund.appendRequestList(req);

                multiResp = multiRequest(loggingKey, route, multiReqSingleRefund);
                if (multiResp == null || multiResp.getResult() != RESULT_CODES.MTX_SUCCESS) {
                    Long resultCode = multiResp != null
                            ? multiResp.getResult() : RESULT_CODES.HTTP_INTERNAL_ERROR;
                    String message = LOG_MESSAGES.FAILED_TO_REFUND_SERVICE
                            + (multiResp != null ? " - " + multiResp.getResultText() : "");
                    WARN(m_logger, loggingKey + message);
                    throw new RefundServiceException(resultCode, message);
                } else {
                    for (MtxResponse response : multiResp.getResponseList()) {
                        if (response.getMdcName().equals(
                                MtxResponseRefundPayment.class.getSimpleName())) {
                            refundAmountInfoOutputMsg = ((MtxResponseRefundPayment) response).getRefundInfo().getRefundTime()
                                    + "";
                        }
                    }
                }
            }

            multiReqSingleRefund = new MtxRequestMulti();
        }

        retMap.put(MtxResponseMulti.class.getSimpleName(), multiResp);
        retMap.put("RefundAmountInfoOutputMsg", refundAmountInfoOutputMsg);
        retMap.put("RefundAmountOutputMsg", refundAmountOutputMsg);
        return retMap;
    }

    private MtxRequestMulti addRefundRequestsWithDeltaAdjustmentsV3(String loggingKey,
                                                                    String route,
                                                                    VisibleRequestRefundService input,
                                                                    Long balanceResourceId,
                                                                    BigDecimal chargeAmount,
                                                                    LinkedHashMap<RefundPaymentInfo, BigDecimal> paymentMap,
                                                                    MtxRequestMulti multiReqRefundService,
                                                                    String adjReason)
            throws RefundServiceException, IntegrationServiceException {
        BigDecimal remainingAmount = chargeAmount;
        DEBUG(m_logger, loggingKey + "addRefundRequestsWithDeltaAdjustmentsV3");

        // BigDecimal roundOffDeltaAmount = BigDecimal.ZERO;
        boolean isCancelInsurance = isCancelService(input);
        for (Entry<RefundPaymentInfo, BigDecimal> paymentEntry : paymentMap.entrySet()) {
            BigDecimal cancelAmountToBeneficiary = BigDecimal.ZERO;//
            if (paymentEntry.getKey().areFundsNotAvailable()) {
                continue;
            }
            BigDecimal refundAmount = BigDecimal.ZERO;

            if (remainingAmount.compareTo(paymentEntry.getValue()) == -1
                    || remainingAmount.compareTo(paymentEntry.getValue()) == 0) {
                refundAmount = remainingAmount;
            } else {
                refundAmount = paymentEntry.getValue();
            }
            remainingAmount = remainingAmount.subtract(paymentEntry.getValue());
            BigDecimal btRefundAmount = refundAmount.setScale(
                    BRAINTREE_CONSTANTS.BT_AMOUNT_PRECISION, RoundingMode.HALF_UP);
            BigDecimal deltaAmount = btRefundAmount.subtract(refundAmount);
            cancelAmountToBeneficiary = cancelAmountToBeneficiary.add(btRefundAmount);

            Map<String, String> offerAttributes = getOfferAttributes(
                    loggingKey, route,
                    input.getRefundServiceOrderInfo().getServiceOfferExternalId().trim());

            // @formatter:off
            MtxRequestSubscriberRefundPaymentBuilder refundBuilder = (new MtxRequestSubscriberRefundPaymentBuilder())
                    .withSubscriberExternalId(paymentEntry.getKey().getPayAuthEvent().getInitiatorExternalId())
                    .withPaymentMethodResourceId(paymentEntry.getKey().getMtxPaymentInfo().getResourceId())
                    .withAmount(btRefundAmount)
                    .withReason(offerAttributes.get(ATTR_NAME_REFUND_REASON))
                    .withInfo(adjReason);
            // @formatter:on
            multiReqRefundService.appendRequestList(refundBuilder.build());

            remainingAmount = remainingAmount.add(deltaAmount);
            // Update round-off delta
            // roundOffDeltaAmount = roundOffDeltaAmount.add(deltaAmount);
            if (paymentEntry.getKey().getPayAuthEvent().getInitiatorExternalId().equalsIgnoreCase(
                    input.getSubscriberExternalId())) {
                // if(GENERIC_CONSTANTS.NO.equalsIgnoreCase(input.getCancelServices())) {
                if (!isCancelInsurance) {
                    // @formatter:off
                    //Adjust beneficiary main balance to have enough money 
                    MtxRequestSubscriberAdjustBalanceBuilder payerAdj = (new MtxRequestSubscriberAdjustBalanceBuilder())
                            .withSubscriberExternalId(input.getSubscriberExternalId())
                            .withBalanceResourceId(balanceResourceId)
                            .withAmount(btRefundAmount)
                            .withReason(adjReason);
                    // @formatter:on
                    multiReqRefundService.appendRequestList(payerAdj.build());
                }
                // Paid by beneficiary-self. Put enough money so that beneficiary mainbalance will
                // be able to handle rouding error
                // else if(!GENERIC_CONSTANTS.NO.equalsIgnoreCase(input.getCancelServices()) &&
                // deltaAmount.signum()!=0) {
                else if (isCancelInsurance && deltaAmount.signum() != 0) {
                    // @formatter:off                
                    MtxRequestSubscriberAdjustBalanceBuilder benAdjDelta = (new MtxRequestSubscriberAdjustBalanceBuilder())
                            .withSubscriberExternalId(input.getSubscriberExternalId())
                            .withBalanceResourceId(balanceResourceId)
                            .withAmount(deltaAmount)
                            .withReason(ROUNDING_ERROR_ADJUSTMENT);
                    // @formatter:on
                    multiReqRefundService.appendRequestList(benAdjDelta.build());
                }
            } else {

                // @formatter:off
                //Adjust payer main balance to have enough money 
                MtxRequestSubscriberAdjustBalanceBuilder payerAdj = (new MtxRequestSubscriberAdjustBalanceBuilder())
                        .withSubscriberExternalId(paymentEntry.getKey().getPayAuthEvent().getInitiatorExternalId())
                        .withBalanceResourceId(paymentEntry.getKey().getRei().getPayerMainbalanceResourceId())
                        .withAmount(btRefundAmount)
                        .withReason(adjReason);
                // @formatter:on
                multiReqRefundService.appendRequestList(payerAdj.build());

                // if(!GENERIC_CONSTANTS.NO.equalsIgnoreCase(input.getCancelServices())) {
                if (isCancelInsurance) {
                    // paid by payer. Reduce entire cancellation amount from beneficiary
                    // @formatter:off
                    MtxRequestSubscriberAdjustBalanceBuilder benAdj = (new MtxRequestSubscriberAdjustBalanceBuilder())
                            .withSubscriberExternalId(input.getSubscriberExternalId())
                            .withBalanceResourceId(balanceResourceId)
                            .withAmount(refundAmount.negate())
                            .withReason(adjReason);
                    // @formatter:on
                    multiReqRefundService.appendRequestList(benAdj.build());
                }
            }
            paymentEntry.getKey().addToBlockedFunds(btRefundAmount);
            DEBUG(
                    m_logger,
                    loggingKey + "Refund amount: " + refundAmount + " Rounded refund amount: "
                            + btRefundAmount + " Delta: " + deltaAmount);
            if (remainingAmount.signum() != 1) {
                break;
            }
        }
        if (remainingAmount.signum() == 1) {
            throw new RefundServiceException(
                    RESULT_CODES.HTTP_INTERNAL_ERROR,
                    LOG_MESSAGES.INSUFFICIENT_AUTHORIZATION_AMOUNT);
        }

        return multiReqRefundService;
    }

    private void refundServiceGiftV3(VisibleRequestRefundService input,
                                     VisibleResponseRefundService output)
            throws InvalidRequestException, MtxResponseException, RefundServiceException {

        // Setup the logging key
        String loggingKey = getLoggingKey(input.getSubscriberExternalId());
        String methodKey = loggingKey + " refundServiceGift: ";

        // Validate the request
        requestValidator.validateRefundRequestV3(loggingKey, input);
        // Query Giftee recurring events
        Map<String, MtxRecurringEvent> recEventMap = queryRecurringHistoryForEventIds(
                loggingKey, List.of(input.getAtEventGroupList(0).getRecurringEventId()));
        if (recEventMap == null || recEventMap.isEmpty()) {
            INFO(m_logger, methodKey + LOG_MESSAGES.SUPPLIED_RECURRING_EVENTS_NOT_FOUND);
            throw new RefundServiceException(
                    RESULT_CODES.HTTP_BAD_REQUEST,
                    LOG_MESSAGES.SUPPLIED_RECURRING_EVENTS_NOT_FOUND);
        }

        Map<String, Object> giftRefundInfo = new HashMap<String, Object>();
        parseRecurringEventsForGift(loggingKey, recEventMap, input, giftRefundInfo);
        String gifterExternalId = (String) giftRefundInfo.get(GIFTER_EXTERNAL_ID);
        // Query Gifter Transfer Balance and Payauth events
        String[] gifterEventTypes = {
            EVENT_TYPES.BALANCE_TRANSFER
        };
        Map<String, EventQueryEventInfo> gifterEventTable = querySubscriberEventsByType(
                loggingKey, this.ROUTE, gifterExternalId, gifterEventTypes);
        if (gifterEventTable == null || gifterEventTable.isEmpty()) {
            String msg = LOG_MESSAGES.NO_GIFTER_EVENTS + gifterExternalId;
            INFO(m_logger, methodKey + LOG_MESSAGES.NO_GIFTER_EVENTS);
            throw new RefundServiceException(RESULT_CODES.HTTP_INTERNAL_ERROR, msg);
        }

        parseGifterEvents(loggingKey, this.ROUTE, gifterEventTable, input, giftRefundInfo);
        INFO(
                m_logger,
                methodKey + LOG_MESSAGES.GIFT_AMOUNT_TO_REFUND + giftRefundInfo.get(REFUND_AMOUNT));
        MtxRequestMulti multiReq = getGiftRefundMultirequest(loggingKey, input, giftRefundInfo);

        MtxResponseMulti multiResp = multiRequest(loggingKey, this.ROUTE, multiReq);
        CommonUtils.validateMtxResponse(
                loggingKey, LOG_MESSAGES.FAILED_TO_REFUND_GIFT_SERVICE, multiResp);
        output.setResult(multiResp.getResult());
        output.setResultText(
                "SubscriptionExternalID: " + input.getSubscriberExternalId() + " Response: "
                        + multiResp.getResultText());
        output.setRefundAmountInfo(
                "{" + "GifterExternalID:" + gifterExternalId + "," + "RefundAmount:"
                        + giftRefundInfo.get(REFUND_AMOUNT) + "}");

    }

    private MtxRequestMulti getGiftRefundMultirequest(String loggingKey,
                                                      VisibleRequestRefundService input,
                                                      Map<String, Object> giftRefundInfo) {
        String methodKey = loggingKey + " getGiftRefundMultirequest: ";
        MtxRequestMulti multiReq = new MtxRequestMulti();
        String adjReason = CommonUtils.getReversalDetailsForEventId(
                input.getAtEventGroupList(0).getRecurringEventId());
        Long mainbalanceResourceId = (Long) giftRefundInfo.get(MAINBALANCE_RESOURCE_ID);
        Long catalogItemResourceId = (Long) giftRefundInfo.get(CATALOG_ITEM_RESOURCE_ID);
        Long paymentResourceId = (Long) giftRefundInfo.get(PAYMENT_RESOURCE_ID);
        BigDecimal refundAmount = (BigDecimal) giftRefundInfo.get(REFUND_AMOUNT);
        String gifterExternalId = (String) giftRefundInfo.get(GIFTER_EXTERNAL_ID);

        // @formatter:off
        MtxRequestSubscriberAdjustBalanceBuilder adjBuilder = (new MtxRequestSubscriberAdjustBalanceBuilder())
                .withSubscriberExternalId(gifterExternalId)
                .withBalanceResourceId(mainbalanceResourceId)
                .withAmount(refundAmount)
                .withReason(adjReason);
        // @formatter:on
        multiReq.appendRequestList(adjBuilder.build());

        // @formatter:off
        MtxRequestSubscriberRefundPaymentBuilder refBuilder = (new MtxRequestSubscriberRefundPaymentBuilder())
                .withSubscriberExternalId(gifterExternalId)
                .withPaymentMethodResourceId(paymentResourceId)
                .withAmount(refundAmount.setScale(BRAINTREE_CONSTANTS.BT_AMOUNT_PRECISION,RoundingMode.HALF_UP))
                .withReason(SUBSCRIBER_SERVICE_CONSTANTS.GIFT_REFUND_REASON)
                .withInfo(adjReason);
        // @formatter:on
        multiReq.appendRequestList(refBuilder.build());

        // @formatter:off
        MtxRequestSubscriberCancelOfferBuilder builder = (new MtxRequestSubscriberCancelOfferBuilder())
                .withSubscriberExternalId(input.getSubscriberExternalId().trim())
                .withResourceId(catalogItemResourceId);
        // @formatter:on
        multiReq.appendRequestList(builder.build());
        return multiReq;
    }

    private void parseRecurringEventsForGift(String loggingKey,
                                             Map<String, MtxRecurringEvent> eventTable,
                                             VisibleRequestRefundService input,
                                             Map<String, Object> giftRefundInfo)
            throws RefundServiceException {
        String methodKey = loggingKey + " parseRecurringEventsForGift: ";
        Long catalogItemResourceId = null;
        String gifterExternalId = null;
        HashSet<String> recEventSet = new HashSet<String>();
        VisiblePurchasedOfferExtension vpoXtn = null;

        for (MtxRecurringEvent event : eventTable.values()) {
            String catalogItemExternalId = null;

            MtxRecurringEvent recurringEvent = (MtxRecurringEvent) event;

            // Append the event ID to the adjustment reason (required by the GL processor for
            // return/reversal trigger)
            recEventSet.add(recurringEvent.getEventId());

            for (MtxEventAppliedCatalogItem ci : CommonUtils.emptyIfNull(
                    recurringEvent.getAppliedCatalogItemArray())) {
                if (!input.getRefundServiceOrderInfo().getServiceOfferExternalId().trim().equalsIgnoreCase(
                        ci.getCatalogItemExternalId())) {
                    continue;
                }
                catalogItemResourceId = ci.getCatalogItemResourceId();
                INFO(
                        m_logger,
                        methodKey + "catalogItemResourceId of refund: " + catalogItemResourceId);

                if (recurringEvent.getApiEventData() == null
                        || !(recurringEvent.getApiEventData() instanceof VisibleApiEventData)) {
                    INFO(m_logger, methodKey + LOG_MESSAGES.NO_GIFTER_API_EVENT_DATA);
                    throw new RefundServiceException(
                            RESULT_CODES.HTTP_INTERNAL_ERROR,
                            LOG_MESSAGES.NO_GIFTER_API_EVENT_DATA);
                }
                VisibleApiEventData aed = (VisibleApiEventData) recurringEvent.getApiEventData();
                gifterExternalId = aed.getGifterGlobalKey();
                INFO(m_logger, methodKey + "gifterExternalId external id: " + gifterExternalId);
            }
        }

        if (catalogItemResourceId == null) {
            INFO(m_logger, methodKey + LOG_MESSAGES.CATALOG_ITEM_RESOURCE_NOT_FOUND);
            throw new RefundServiceException(
                    RESULT_CODES.HTTP_INTERNAL_ERROR, LOG_MESSAGES.CATALOG_ITEM_RESOURCE_NOT_FOUND);
        }
        if (StringUtils.isBlank(gifterExternalId)) {
            INFO(m_logger, methodKey + LOG_MESSAGES.GIFTER_INFO_NOT_FOUND);
            throw new RefundServiceException(
                    RESULT_CODES.HTTP_INTERNAL_ERROR, LOG_MESSAGES.GIFTER_INFO_NOT_FOUND);
        }

        giftRefundInfo.put(CATALOG_ITEM_RESOURCE_ID, catalogItemResourceId);
        giftRefundInfo.put(GIFTER_EXTERNAL_ID, gifterExternalId);
        giftRefundInfo.put(REC_EVENT_SET, recEventSet);
    }

    private void parseGifterEvents(String loggingKey,
                                   String route,
                                   Map<String, EventQueryEventInfo> eventTable,
                                   VisibleRequestRefundService input,
                                   Map<String, Object> giftRefundInfo)
            throws RefundServiceException, MtxResponseException {
        String methodKey = loggingKey + " parseGifterEvents: ";
        boolean foundPayAuth = false;
        BigDecimal payAuthAmount = null;
        BigDecimal tbAmount = null;
        LinkedHashMap<RefundPaymentInfo, BigDecimal> paymentMap = getPaymentDetailsForPaymentAuthEventIds(
                loggingKey, (String) giftRefundInfo.get(GIFTER_EXTERNAL_ID),
                input.getAtEventGroupList(0).getPaymentAuthorizationEventIds());

        if (paymentMap == null || paymentMap.size() == 0) {
            String message = LOG_MESSAGES.FAILED_TO_QUERY_PAYMENT_HISTORY_GIFTER;
            INFO(m_logger, methodKey + message);
            throw new RefundServiceException(RESULT_CODES.HTTP_INTERNAL_ERROR, message);
        }

        for (RefundPaymentInfo mpi : paymentMap.keySet()) {
            giftRefundInfo.put(PAYMENT_RESOURCE_ID, mpi.getMtxPaymentInfo().getResourceId());
            payAuthAmount = mpi.getMtxPaymentInfo().getAuthorizationAmount();
        }

        boolean foundSec = false;
        List<String> secondaryEvents = new ArrayList<String>();
        for (EventQueryEventInfo event : eventTable.values()) {
            if (!(event.getEventDetails() instanceof MtxBalanceTransferEvent)) {
                continue;
            }
            MtxBalanceTransferEvent tbEvent = (MtxBalanceTransferEvent) event.getEventDetails();
            INFO(m_logger, methodKey + "Secondary Event:" + tbEvent.getAtSecondaryEventIdList(0));
            secondaryEvents.add(tbEvent.getAtSecondaryEventIdList(0));
            Map<String, MtxEvent> secEventTable = querySecondaryEventsByEventIds(
                    loggingKey, route, secondaryEvents);

            for (MtxEvent event1 : secEventTable.values()) {
                if (!(event1 instanceof MtxSecondaryEvent)) {
                    continue;
                }
                MtxSecondaryEvent secEvent = (MtxSecondaryEvent) event1;

                if (secEvent.getWalletOwnerExternalId().equalsIgnoreCase(
                        input.getSubscriberExternalId())) {
                    foundSec = true;
                    giftRefundInfo.put(SECONDARY_EVENT_ID, secEvent.getEventId());
                    break;
                }
            }

            if (foundSec) {
                for (MtxBalanceImpactInfo bii : CommonUtils.emptyIfNull(
                        event.getBalanceImpactList())) {
                    if (bii.getIsMainBalance()) {
                        tbAmount = bii.getImpactAmount();
                        giftRefundInfo.put(MAINBALANCE_RESOURCE_ID, bii.getBalanceResourceId());
                        break;
                    }
                }
            }
        }

        if (!foundSec) {
            INFO(m_logger, methodKey + LOG_MESSAGES.NO_SECONDARY_EVENT_GIFT);
            throw new RefundServiceException(
                    RESULT_CODES.HTTP_INTERNAL_ERROR, LOG_MESSAGES.NO_SECONDARY_EVENT_GIFT);
        }

        if (payAuthAmount == null || tbAmount == null || payAuthAmount.compareTo(tbAmount) != 0) {
            INFO(m_logger, methodKey + LOG_MESSAGES.GIFT_AMOUNT_MISMATCH);
            throw new RefundServiceException(
                    RESULT_CODES.HTTP_CONFLICT, LOG_MESSAGES.GIFT_AMOUNT_MISMATCH);
        }
        giftRefundInfo.put(REFUND_AMOUNT, tbAmount);
    }

    private Map<String, EventQueryEventInfo> querySubscriberEventsByType(String loggingKey,
                                                                         String route,
                                                                         String subscriptionExternalId,
                                                                         String[] eventTypes)
            throws MtxResponseException {
        String methodKey = loggingKey + " querySubscriberEventsByType: ";
        Map<String, EventQueryEventInfo> eventTable = new TreeMap<String, EventQueryEventInfo>();

        INFO(m_logger, loggingKey + "Querying event history for subscriber in MATRIXX");

        EventQueryResponseEvents response = querySubscriptionEventList(
                route, subscriptionExternalId, eventTypes);
        CommonUtils.validateMtxResponse(loggingKey, LOG_MESSAGES.FAILED_TO_QUERY_EVENTS, response);
        for (EventQueryEventInfo eventInfo : CommonUtils.emptyIfNull(response.getEventList())) {
            eventTable.put(eventInfo.getEventDetails().getEventId(), eventInfo);
        }
        INFO(
                m_logger,
                methodKey + "Retrieved " + eventTable.size() + " event(s) for the subscription");

        return eventTable;
    }

}
