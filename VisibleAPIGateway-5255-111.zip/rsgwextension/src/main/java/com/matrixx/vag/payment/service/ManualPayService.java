package com.matrixx.vag.payment.service;

import static com.matrixx.platform.LogUtils.DEBUG;
import static com.matrixx.platform.LogUtils.ENTER;
import static com.matrixx.platform.LogUtils.INFO;
import static com.matrixx.platform.LogUtils.WARN;

import java.beans.IntrospectionException;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.matrixx.datacontainer.MtxObjectId;
import com.matrixx.datacontainer.MtxPhone;
import com.matrixx.datacontainer.mdc.*;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.matrixx.datacontainer.Field;
import com.matrixx.datacontainer.MtxDate;

import com.matrixx.platform.MatrixxContext;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.Constants;
import com.matrixx.vag.common.Constants.BRAINTREE_CONSTANTS;
import com.matrixx.vag.common.Constants.CREDIT_CONSTANTS;
import com.matrixx.vag.common.Constants.DEVICE_CONSTANTS;
import com.matrixx.vag.common.Constants.EXCEPTION_MESSAGES;
import com.matrixx.vag.common.Constants.GENERIC_CONSTANTS;
import com.matrixx.vag.common.Constants.LOG_MESSAGES;
import com.matrixx.vag.common.Constants.MANUAL_PAY;
import com.matrixx.vag.common.Constants.OFFER_CONSTANTS;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.common.Constants.SUBSCRIBER_SERVICE_CONSTANTS;
import com.matrixx.vag.common.request.builder.MtxPurchasedOfferDataBuilder;
import com.matrixx.vag.common.request.builder.MtxRechargeExtensionBuilder;
import com.matrixx.vag.common.request.builder.MtxRequestSubscriberRechargeBuilder;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.exception.CommonUtilsException;
import com.matrixx.vag.exception.IntegrationServiceException;
import com.matrixx.vag.exception.ManualPayException;
import com.matrixx.vag.service.IntegrationService;

/**
 * @author Unico
 */
@Configuration
public class ManualPayService extends IntegrationService {

    private static final String DONT_OVERWRITE_CREDIT_TAX_DETAILS = "N";
    private static final Logger m_logger = LoggerFactory.getLogger(ManualPayService.class);

    @Bean(name = "ManualPayService")
    ManualPayService getService() {
        return new ManualPayService();
    }

    protected void validateResponse(String loggingKey, String errorContext, MtxResponse response)
            throws ManualPayException {
    	final String methodName = "validateResponse: ";
        if (response == null) {
            WARN(m_logger, loggingKey + methodName + errorContext + " - response is null");
            throw new ManualPayException(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, errorContext);
        }
        if (!response.getResult().equals(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS)) {
            String message = errorContext + " - " + response.getResultText();
            WARN(m_logger, loggingKey + methodName +message);
            throw new ManualPayException(response.getResult(), message);
        }
    }

    /**
     * Prepares the SubscriberModifyOffer request for the referral credit tax details. Obtains the
     * resourceID for the main visible offer by looking into the subscriber's purchased offers.
     *
     * @param request
     * @param loggingKey
     * @param subscriberSearchData
     * @param offerExternalId
     * @param responseSubscriber
     * @param creditTaxDetails
     * @param creditTaxUpdatableOffers
     * @return
     * @throws ManualPayException
     */
    private MtxRequestSubscriberModifyOffer getSubscriberModifyOfferRequest(ManualPayRequest request,
                                                                            String loggingKey,
                                                                            MtxSubscriberSearchData subscriberSearchData,
                                                                            MtxResponseSubscription responseSubscriber,
                                                                            CatalogItemUpdate ciUpdate)
                                                                                   throws ManualPayException {
    	final String methodName = "getSubscriberModifyOfferRequest: ";
        // Find the resource ID for the main visible offer from the subscriber's purchased offers:
        if (responseSubscriber.getPurchasedOfferArray() == null
                || responseSubscriber.getPurchasedOfferArray().isEmpty()) {
        	WARN(m_logger, loggingKey + methodName + "Subscriber has no purchased offer.");
            throw new ManualPayException("Subscriber has no purchased offer.");
        }
        
        VisiblePurchasedOfferExtension visiblePurchasedOfferExtension = ciUpdate.getPurchasedOfferExtension();
        ciUpdate.getCreditTaxList().forEach(taxString -> {
        	if (StringUtils.isNotBlank(taxString)) {
        		visiblePurchasedOfferExtension.appendCreditTaxDetailsArray(taxString.trim());
            }
        });
        // Set Subscriber group count from the first entry passed on from AOP
        updateAdditionalInfoOnOffer(request, loggingKey, visiblePurchasedOfferExtension, responseSubscriber);

        String orderId  = CommonUtils.getCurrentOrderId(responseSubscriber,ciUpdate.getCatalogItemExternalId());
        String yymmddOrderId = CommonUtils.getNewOrderId(orderId);
        visiblePurchasedOfferExtension.setOrderId(yymmddOrderId);

        INFO(m_logger,
                methodName + "Updated orderId is : " + visiblePurchasedOfferExtension.getOrderId());

        return CommonUtils.getSubscriberModifyOfferRequest(
                subscriberSearchData, ciUpdate.getResourceId(), visiblePurchasedOfferExtension); 
    }

    /**
     * Perform manual pay. returns the 0 if success, otherwise if a fail Does a transfer by
     * Purchasing the offer. Any applicable credit tax details would be updated. Recharge using
     * credit card if applicable.
     *
     * @param request
     * @param response
     * @param aopOutput
     * @return
     * @throws IntegrationServiceException
     * @throws CommonUtilsException
     * @throws IntrospectionException
     * @throws InvocationTargetException 
     * @throws IllegalArgumentException 
     * @throws IllegalAccessException 
     * @throws InstantiationException 
     * @throws SecurityException 
     * @throws NoSuchMethodException 
     */
    public int manualPay(ManualPayRequest request,
                         ManualPayResponse response,
                         VisibleResponsePaymentAdviceService aopOutput)
                                 throws IntegrationServiceException, CommonUtilsException, IntrospectionException, NoSuchMethodException, SecurityException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
    	final String methodName = "manualPay: ";
        Instant start = Instant.now();
        ENTER(m_logger, "getSubscriber");
        // Setup the logging key
        String loggingKey = getLoggingKey(request.getSubscriberSearchDataExternalId());

        // 1. Validate the request
        RequestValidator.validateRequest(loggingKey, request);

        INFO(m_logger, loggingKey + methodName+ "request: " + request.toJson() + ", aopOutput: " + aopOutput);
        // 2. Check if aop recalculation was required, and if so perform input data re-validation
        // with current AOP calculation.
        if (aopOutput != null) {
            RequestValidator.validateForStaleAdviceCalculations(request, aopOutput, loggingKey);
        }

        // Determine routing data
        String route = getRoute(MatrixxContext.getRequest());
        
        // 3. Fetch subscriber details
        MtxResponseSubscription responseSubscriber = getSubscriberDetails(
                loggingKey, route, request.getSubscriberSearchDataExternalId());

        // Validate that the subscriber is allowed to do manual pay (check allowed status)
        validateSubscriberForManualPay(responseSubscriber);

        final MtxRequestMulti multiRequestObject = new MtxRequestMulti();

        String purchaseTimestamp = CommonUtils.getTimestampAsString(0);

        MtxSubscriberSearchData subscriberSearchData = new MtxSubscriberSearchData();
        subscriberSearchData.setExternalId(request.getSubscriberSearchDataExternalId());

        // 1. Process PurchaseOffer Request
        List<MtxRequestSubscriberPurchaseOffer> purchaseOffer = processCreditsAndPreparePurchaseOfferRequest(
                request, loggingKey, route, purchaseTimestamp, subscriberSearchData);
        CommonUtils.addRequestsToMulti(multiRequestObject, purchaseOffer);
        INFO(m_logger,
                loggingKey + methodName + "Added purchase offer request to Multirequest -  : " + multiRequestObject.toJson());

        boolean creditCardChargeAmountNonZero = request.getPayNow() != null
                && CommonUtils.checkIfNonZero(request.getPayNow().getChargeAmount());

        boolean usingCashPayment = request.getCashPaymentDetails() != null;

        boolean usingPayNow = false;

        int creditCardRechargeIndex = -1;
        if (creditCardChargeAmountNonZero) {
            usingPayNow = true;
            creditCardRechargeIndex = processRecharge(
            		loggingKey, route, request, subscriberSearchData, multiRequestObject,
                    purchaseTimestamp, responseSubscriber, usingPayNow);
        }
        int cashPaymentRechargeIndex = -1;
        if (usingCashPayment) {
            usingPayNow = false;
            cashPaymentRechargeIndex = processRecharge(
            		loggingKey, route, request, subscriberSearchData, multiRequestObject,
                    purchaseTimestamp, responseSubscriber, usingPayNow);
        }

        // 3. Set transfer tax details
        MtxResponseWallet subscriberWallet = querySubscriptionWallet(loggingKey, route, responseSubscriber.getExternalId());
        validateResponse(loggingKey, EXCEPTION_MESSAGES.FAILED_TO_QUERY_SUBSCRIBER_WALLET, subscriberWallet);
        
        List<CatalogItemUpdate> ciUpdateList = new ArrayList<CatalogItemUpdate>(); 
        if (request.getVisibleOfferDetailsList() != null) {
            ENTER(m_logger,  methodName + "modifyPurchase");
            for (VisibleOfferDetails offer : request.getVisibleOfferDetailsList()) {

                VisiblePurchasedOfferExtension visiblePurchasedOfferExtension = new VisiblePurchasedOfferExtension();
                if (request.getAttrData() != null) {
                    visiblePurchasedOfferExtension = CommonUtils.cloneVisiblePurchasedOfferExtension(request.getAttrData());
                }
                addPaidCycleStartDate(loggingKey, visiblePurchasedOfferExtension, subscriberWallet);
                INFO(m_logger,
                     methodName + "Setting offer's tax details into purchased offer: " + offer.getCatalogItemExternalId()
                     +StringUtils.SPACE+ "Resource id of purchased offer: " + Long.valueOf(offer.getResourceId())
                     +StringUtils.SPACE+ "Tax Details: " + offer.getTaxDetails());
                visiblePurchasedOfferExtension.setTaxDetails(offer.getTaxDetails());

                //update orderID in visiblePurchaseOfferExtension

                ArrayList<MtxPurchasedOfferInfo> offerArray = responseSubscriber.getPurchasedOfferArray();
                String orderId="";
                String yymmddOrderId="";

                if(offerArray != null) {
                    for(MtxPurchasedOfferInfo offerInfo : offerArray) {
                        //Check if it is a service.
                        if (StringUtils.isBlank(offerInfo.getCatalogItemExternalId())) {
                            continue;
                        }
                        if (offerInfo.getAttr() == null) {
                            continue;
                        }
                        VisiblePurchasedOfferExtension offerExtn = (VisiblePurchasedOfferExtension) offerInfo.getAttr();
                        if (StringUtils.isBlank(offerExtn.getOrderId())) {
                            continue;
                        } else {
                            orderId = offerExtn.getOrderId();
                        }
                        break;
                    }
                }

                String origOrderId = orderId;

                if (StringUtils.isNotBlank(orderId) && (orderId.contains("-"))) {
                    String[] orderIdOrg = orderId.split("-");
                    origOrderId = orderIdOrg[1];
                }

                yymmddOrderId = StringUtils.isNotBlank(origOrderId)? CommonUtils.getDateYYMMDDString() + "-" + origOrderId: "";

                visiblePurchasedOfferExtension.setOrderId(yymmddOrderId);

                INFO(m_logger,
                        methodName + "Updated visiblePurchasedOfferExtension is : " + visiblePurchasedOfferExtension.toJson());

                MtxRequestSubscriberModifyOffer modifyOffer = CommonUtils.getSubscriberModifyOfferRequest(
                        subscriberSearchData, Long.valueOf(offer.getResourceId()),
                        visiblePurchasedOfferExtension);

                INFO(m_logger,
                        loggingKey + methodName  
                        + "Adding modify request to Multirequest -  : "
                        + modifyOffer.toJson());
                CommonUtils.addRequestToMulti(multiRequestObject, modifyOffer);

                // Set Subscriber group count from the first entry passed on from AOP
                updateAdditionalInfoOnOffer(
                        request, loggingKey, visiblePurchasedOfferExtension, responseSubscriber);
                
                if (DONT_OVERWRITE_CREDIT_TAX_DETAILS.equalsIgnoreCase(request.getUpdateTaxString())) {
                	INFO(m_logger, loggingKey + methodName
                			+"Credit tax details will not be cleared as per request parameter UpdateTaxString: "
                			+request.getUpdateTaxString());
                }else {
                    // Ensure all previous credit tax details are erased.
                    clearAllCreditTaxDetails(loggingKey, offer.getCatalogItemExternalId(), visiblePurchasedOfferExtension);                        	
                }

                ciUpdateList.add(CatalogItemUpdate.createCatalogItemUpdate(offer.getCatalogItemExternalId(), Long.parseLong(offer.getResourceId()))
                .withPurchasedOfferExtension(visiblePurchasedOfferExtension));
                
                INFO(m_logger,
                     loggingKey + methodName + "Adding purchase offer : "
                                + visiblePurchasedOfferExtension.toJson()
                                + "  for offerCiId: " + offer.getCatalogItemExternalId());
            }
        }

        // 4. Process Credit Tax details
        List<MtxRequestSubscriberModifyOffer> modifyOffers = processCreditTaxDetails(
                request, ciUpdateList, loggingKey,
                subscriberSearchData, responseSubscriber);

        if (!modifyOffers.isEmpty()) {
            INFO(
                    m_logger,
                    loggingKey + methodName + "Adding credit tax details modify request to Multirequest -  : "
                            + modifyOffers);
            CommonUtils.addRequestsToMulti(multiRequestObject, modifyOffers);
        }
        addSubscriberModifyToSetPaymentDate(
                loggingKey, subscriberSearchData, multiRequestObject,
                cashPaymentRechargeIndex, subscriberWallet);

        //setApiEventData
        multiRequestObject.setApiEventData(request.getApiEventData());

        // 5. Execute Multi request with all above processed requests.
        MtxResponseMulti multiResponse = multiRequest(loggingKey, route, multiRequestObject);

        String resultText = multiResponse.getResultText();

        Long result = multiResponse.getResult();

        if (multiResponse.getResponseList() != null) {
            VisibleRiskData vrd = getRiskData(
                    multiResponse.getResponseList(), creditCardRechargeIndex);
            response.setRiskData(vrd);
        }

        response.setResult(result);
        response.setResultText(resultText);
        INFO(m_logger, loggingKey + methodName + "result -  : " + result + " result text -  : " + resultText);

        Instant end = Instant.now();
        INFO(m_logger, loggingKey + methodName + "Execution Time -  : " + Duration.between(start, end));

        return result.intValue();
    }

    private boolean checkForCashPaymentZeroRecharge(final MtxRequestMulti multiRequestObject,
                                                    int cashPaymentRechargeIndex) {
        boolean isCashPaymentZeroRecharge = false;
        if (cashPaymentRechargeIndex != -1) {
            MtxRequestSubscriberRecharge rechargeReq = (MtxRequestSubscriberRecharge) multiRequestObject.getRequestList().get(
                    cashPaymentRechargeIndex);
            if (rechargeReq.getAmount().signum() == 0) {
                isCashPaymentZeroRecharge = true;
            }
        }
        return isCashPaymentZeroRecharge;
    }

    private void addSubscriberModifyToSetPaymentDate(String loggingKey,
                                                     MtxSubscriberSearchData subscriberSearchData,
                                                     final MtxRequestMulti multiRequestObject,
                                                     int cashPaymentRechargeIndex,
                                                     MtxResponseWallet wallet)
                                                             throws ManualPayException {
    	final String methodName = "addSubscriberModifyToSetPaymentDate: ";
        boolean isCashPaymentZeroRecharge = checkForCashPaymentZeroRecharge(
                multiRequestObject, cashPaymentRechargeIndex);
        if (!isCashPaymentZeroRecharge) {
            if (wallet.getBillingCycle().getCurrentPeriodEndTime() != null) {
                DEBUG(
                        m_logger,
                        loggingKey + methodName + "Setting billCycle currentPeriodEndTime as PaymentDate : "
                                + wallet.getBillingCycle().getCurrentPeriodEndTime());

                MtxRequestSubscriberModify subscriberModifyReq = new MtxRequestSubscriberModify();
                VisibleSubscriberExtension subscriberExt = new VisibleSubscriberExtension();
                subscriberExt.setPaymentDate(wallet.getBillingCycle().getCurrentPeriodEndTime());
                subscriberModifyReq.setAttr(subscriberExt);
                subscriberModifyReq.setSubscriberSearchData(subscriberSearchData);
                multiRequestObject.appendRequestList(subscriberModifyReq);
            }
        } else {
            DEBUG(
                    m_logger,
                    loggingKey + methodName + "Cash Payment Zero recharge - so not updating paymentDate");
        }
    }
      
    private void addPaidCycleStartDate(String loggingKey, 
                                       VisiblePurchasedOfferExtension purchaseOfferExt, 
                                       MtxResponseWallet wallet) 
                                               throws ManualPayException {
    	final String methodName = "addPaidCycleStartDate: ";
        if (wallet.getBillingCycle().getCurrentPeriodEndTime() != null) {
            DEBUG(m_logger, 
                    loggingKey + methodName + 
                    "Setting PayCycleStartDate from billCycle currentPeriodEndTime: " + wallet.getBillingCycle().getCurrentPeriodEndTime());
            			    			    			
            String mtxWalletTimestamp = wallet.getBillingCycle().getCurrentPeriodEndTime().toString();
            MtxDate mtxTimestampToMtxDate = new MtxDate(mtxWalletTimestamp);
            INFO(m_logger,
            		loggingKey + methodName +
                    "Converting String to MtxDate - mtxTimestampToMtxDate :" + mtxTimestampToMtxDate.toString());
            purchaseOfferExt.setPaidCycleStartDate(mtxTimestampToMtxDate);    			
        }
    }    	

    /**
     * Do the recharge on to the main balance. (Cash payment / Credit card - payNow)
     *
     * @param request
     * @param loggingKey
     * @param subscriberSearchData
     * @param multiRequestObject
     * @param purchaseTimestamp
     * @param responseSubscriber
     * @param usingPayNow
     * @return
     * @throws CommonUtilsException
     * @throws IntrospectionException
     */
    private int processRecharge(String loggingKey,
                                String route,
                                ManualPayRequest request,
                                MtxSubscriberSearchData subscriberSearchData,
                                final MtxRequestMulti multiRequestObject,
                                String purchaseTimestamp,
                                MtxResponseSubscription responseSubscriber,
                                boolean usingPayNow)
            throws CommonUtilsException, IntrospectionException, ManualPayException {
    	final String methodName = "processRecharge: ";
        int rechargeIndex = -1;
        ENTER(m_logger, methodName);

        String baseRatePlan = null;
        BigDecimal basePlanAmount = null;
        BigDecimal basePayableAmount = null;
        String baseMDN = null;
        String wearableMDN = null;
        String wearableRatePlan = null;
        BigDecimal wearablePlanAmount = null;        
        BigDecimal wearablePayableAmount = null;

        Map<String, VisibleOfferDetails> vodMap = new HashMap<String, VisibleOfferDetails>();
        for (VisibleOfferDetails vod : CommonUtils.emptyIfNull(
                request.getVisibleOfferDetailsList())) {
            vodMap.put(vod.getCatalogItemExternalId(), vod);
        }  

        String reason = request.getReason();
        if (StringUtils.isEmpty(reason)) {
            reason = AppPropertyProvider.getInstance().getString(
                    SUBSCRIBER_SERVICE_CONSTANTS.SERVICE_PURCHASE_REASON_MANUAL_PAY);
        }

        ArrayList<MtxPurchasedOfferInfo> offerArray = responseSubscriber.getPurchasedOfferArray();        
        String orderId="";
        String yymmddOrderId="";
        
        for (MtxPurchasedOfferInfo offerInfo : CommonUtils.emptyIfNull(offerArray)) {
            //Base service loop
            if (StringUtils.isBlank(offerInfo.getCatalogItemExternalId())) {
                continue;
            }
            if (offerInfo.getAttr() == null) {
                continue;
            }
            VisiblePurchasedOfferExtension offerExtn = (VisiblePurchasedOfferExtension) offerInfo.getAttr();
            if (StringUtils.isNotBlank(offerExtn.getOrderId())) {
                orderId = offerExtn.getOrderId();
            }            

            VisibleOfferDetails vod = vodMap.get(offerInfo.getCatalogItemExternalId());
            if (vod == null) {
                continue;
            }
            if(OFFER_CONSTANTS.OFFER_TYPE_BASE.equalsIgnoreCase(vod.getOfferType())) {
                baseRatePlan = offerInfo.getCatalogItemExternalId();
                basePlanAmount = offerExtn.getChargeAmount();
                basePayableAmount = vod.getPayableAmount(); 
            }
            if(OFFER_CONSTANTS.OFFER_TYPE_ADDON.equalsIgnoreCase(vod.getOfferType())) {
                wearableRatePlan = offerInfo.getCatalogItemExternalId();
                wearablePlanAmount = offerExtn.getChargeAmount();
                wearablePayableAmount = vod.getPayableAmount(); 
            }            
        }

        ArrayList<MtxObjectId> deviceArrayId = responseSubscriber.getDeviceIdArray();

        for (MtxObjectId deviceId : CommonUtils.emptyIfNull(deviceArrayId)) {
            if (deviceId == null) {
                continue;
            }
            MtxResponseDevice device = queryDeviceData(loggingKey, route, deviceId);            
            if (device == null) {
                continue;
            }
            VisibleDeviceExtension deviceExtn = (VisibleDeviceExtension) device.getAttr();
            if (deviceExtn == null) {
                continue;
            }
            if (StringUtils.isNotBlank(wearableRatePlan)
                    && DEVICE_CONSTANTS.DEVICE_TYPE_WEARABLE.equalsIgnoreCase(
                            deviceExtn.getDeviceType())) {
                wearableMDN = getMDN(deviceExtn.getAccessNumberArray());
                if (StringUtils.isBlank(wearableMDN)) {
                    throw new ManualPayException(EXCEPTION_MESSAGES.WEARABLE_MDN_ERROR);
                }
            } else if (StringUtils.isNotBlank(baseRatePlan)
                    && !DEVICE_CONSTANTS.DEVICE_TYPE_WEARABLE.equalsIgnoreCase(
                            deviceExtn.getDeviceType())) {
                baseMDN = getMDN(deviceExtn.getAccessNumberArray());
                if (StringUtils.isBlank(baseMDN)) {
                    throw new ManualPayException(EXCEPTION_MESSAGES.SERVICE_MDN_ERROR);
                }
            }
        }
        
        String origOrderId = orderId;

        if (StringUtils.isNotBlank(orderId) && (orderId.contains("-"))) {
            String[] orderIdOrg = orderId.split("-");
            origOrderId = orderIdOrg[1];
        }

        yymmddOrderId = StringUtils.isNotBlank(origOrderId)? CommonUtils.getDateYYMMDDString() + "-" + origOrderId: "";

        MtxChargeMethodData chargeMethodDataForRecharge = new MtxChargeMethodData();
        if (usingPayNow) {
            handleFraudInfo(loggingKey, request, chargeMethodDataForRecharge, yymmddOrderId, reason );
        } else {
            chargeMethodDataForRecharge.setChargeMethod(
                    Constants.MATRIXX_CONSTANTS.CHRG_METHOD_PAY_ON_ACC);
        }

        // 2. Process Recharge request if applicable
        boolean isPaymentUsingRecharge = AppPropertyProvider.getInstance().getBoolean(
                SUBSCRIBER_SERVICE_CONSTANTS.SERVICE_PAYMENT_USING_RECHARGE,
                SUBSCRIBER_SERVICE_CONSTANTS.SERVICE_PAYMENT_USING_RECHARGE_DEFAULT_VALUE);

        if (!isPaymentUsingRecharge) {
        	return rechargeIndex;
        }

        BigDecimal rechargeAmount = null;

        if (request.getPayNow() != null && request.getPayNow().getChargeAmount() != null) {
            rechargeAmount = request.getPayNow().getChargeAmount().setScale(
            		BRAINTREE_CONSTANTS.BT_AMOUNT_PRECISION, RoundingMode.HALF_UP);
        } else if (request.getCashPaymentDetails() != null) {
            rechargeAmount = request.getCashPaymentDetails().getrecharge_amount() != null
                    ? request.getCashPaymentDetails().getrecharge_amount().setScale(
                    		BRAINTREE_CONSTANTS.BT_AMOUNT_PRECISION, RoundingMode.HALF_UP)
                            : new BigDecimal(0).setScale(BRAINTREE_CONSTANTS.BT_AMOUNT_PRECISION, RoundingMode.HALF_UP);
        }
        if (rechargeAmount != null) {
            String infoString = null;
            boolean isCashPayment = false;
            // Set the Json structure to ManualPay only in case of cash payments
            if (request.getCashPaymentDetails() != null
                    && request.getCashPaymentDetails().getAttributes() != null) {
                VisibleInfo info = prepareVisibleInfoStructure(
                        request.getCashPaymentDetails(), purchaseTimestamp, loggingKey);
                infoString = info.toJson();
                infoString = infoString.replaceAll("\\s", "");
                infoString = infoString.replaceAll("\\n", "");
                isCashPayment = true;
            } else {
                infoString = purchaseTimestamp;
            }

         // @formatter:off
            MtxRechargeExtensionBuilder rechargeExtensionBuilder = (new MtxRechargeExtensionBuilder())
                    .withOrderId(yymmddOrderId)
                    .withRechargeExtData(request.getRechargeAttr());

            if (StringUtils.isNotBlank(baseMDN)
                    && CommonUtils.zeroIfNull(basePayableAmount).signum() > 0) {
                rechargeExtensionBuilder.withRatePlan(baseRatePlan)
                    .withPlanAmount(basePlanAmount)
                    .withServiceMDN(baseMDN);
            }

                    
            boolean hasWearableDevice = StringUtils.isNotBlank(wearableMDN);
            boolean hasWearableOffer = StringUtils.isNotBlank(wearableRatePlan);
            
            boolean isStandaloneWearable = hasWearableDevice  
                    && CommonUtils.zeroIfNull(wearablePayableAmount).signum() > 0;
                    
            boolean notStandaloneWearable = hasWearableDevice && hasWearableOffer && CommonUtils.zeroIfNull(wearablePayableAmount).signum() <= 0;                    
            boolean isFreeWearable = notStandaloneWearable && CommonUtils.zeroIfNull(basePayableAmount).signum() > 0;
            
            if (isStandaloneWearable || isFreeWearable) {
                rechargeExtensionBuilder.withWearableRatePlan(wearableRatePlan)
                    .withWearablePlanAmount(wearablePlanAmount)
                    .withWearableMDN(wearableMDN);
            }            
            
            MtxRequestSubscriberRechargeBuilder rechBuilder = (new MtxRequestSubscriberRechargeBuilder())
                    .withSubscriberExternalId(responseSubscriber.getExternalId())
                    .withAmount(rechargeAmount)
                    .withPayNow(usingPayNow)
                    .withReason(reason)
                    .withInfo(infoString)
                    .withChargeMethodData(chargeMethodDataForRecharge)
                    .withAttr(rechargeExtensionBuilder.build());
            // @formatter:on
            MtxRequestSubscriberRecharge rechargeReq = rechBuilder.build(); 
            INFO(
                    m_logger,
                    loggingKey + methodName + "Adding recharge request to Multirequest -  : " + rechargeReq.toJson());
            CommonUtils.addRequestToMulti(multiRequestObject, rechargeReq);
            rechargeIndex = multiRequestObject.getRequestList().size() - 1;

            if (isCashPayment
                    && (request.getVisibleOfferDetailsList() == null
                    || request.getVisibleOfferDetailsList().isEmpty())
                    && rechargeAmount.signum() > 0) {
                addCumulativeRechargePurchaseToMulti(
                        loggingKey, subscriberSearchData, multiRequestObject, purchaseTimestamp,
                        rechargeAmount);
            } else {
                addCumulativeRechargePurchaseForServiceOffer(
                		loggingKey, route, request,  subscriberSearchData, multiRequestObject,
                        purchaseTimestamp, rechargeAmount);
            }

        }

        return rechargeIndex;
    }

    private String getMDN(ArrayList<MtxPhone> accessNumberArray) {
        for (MtxPhone accessNum : CommonUtils.emptyIfNull(accessNumberArray)) {
            if (accessNum != null) {
                return accessNum.toString();

            }
        }
        return null;
    }

    /**
     * Add cumulative recharge purchase for the service purchase
     *
     * @param request
     * @param loggingKey
     * @param subscriberSearchData
     * @param multiRequestObject
     * @param purchaseTimestamp
     * @param rechargeAmount
     */
    private void addCumulativeRechargePurchaseForServiceOffer(String loggingKey,
                                                              String route,
                                                              ManualPayRequest request,
                                                              MtxSubscriberSearchData subscriberSearchData,
                                                              final MtxRequestMulti multiRequestObject,
                                                              String purchaseTimestamp,
                                                              BigDecimal rechargeAmount) {
        if (request.getVisibleOfferDetailsList() == null
                || request.getVisibleOfferDetailsList().isEmpty()) {
            return;
        }

        for (VisibleOfferDetails offerDetails : request.getVisibleOfferDetailsList()) {
            if (StringUtils.isBlank(offerDetails.getCatalogItemExternalId())) {
                continue;
            }
            if (offerDetails.getPayableAmount().signum() <= 0) {
                continue;
            }
            MtxResponsePricingCatalogItem pci = queryPricingCatalogItem(
                    loggingKey, route, offerDetails.getCatalogItemExternalId());
            if (pci.getCatalogItemInfo() != null
                    && pci.getCatalogItemInfo().getTemplateAttr() != null
                    && pci.getCatalogItemInfo().getTemplateAttr() instanceof VisibleTemplate) {
                VisibleTemplate vt = (VisibleTemplate) pci.getCatalogItemInfo().getTemplateAttr();
                if (vt.getOfferType() != null
                        && OFFER_CONSTANTS.OFFER_TYPE_BASE.equalsIgnoreCase(vt.getOfferType())) {
                    if (offerDetails.getPayableAmount() != null) {
                        if (offerDetails.getPayableAmount().signum() > 0) {
                            addCumulativeRechargePurchaseToMulti(
                                    loggingKey, subscriberSearchData, multiRequestObject,
                                    purchaseTimestamp, offerDetails.getPayableAmount());
                        }
                    } else {
                        if (rechargeAmount.signum() > 0) {
                            addCumulativeRechargePurchaseToMulti(
                                    loggingKey, subscriberSearchData, multiRequestObject,
                                    purchaseTimestamp, rechargeAmount);
                        }
                    }
                    break;
                }
            }
        }
    }

    /**
     * Add cumulative recharge purchase to multi
     *
     * @param loggingKey
     * @param subscriberSearchData
     * @param multiRequestObject
     * @param purchaseTimestamp
     * @param rechargeAmount
     */
    private void addCumulativeRechargePurchaseToMulti(String loggingKey,
                                                      MtxSubscriberSearchData subscriberSearchData,
                                                      final MtxRequestMulti multiRequestObject,
                                                      String purchaseTimestamp,
                                                      BigDecimal rechargeAmount) {
    	final String methodName = "addCumulativeRechargePurchaseToMulti: ";
        // Add cumulative recharge purchase offer request to multi
        String cumulativeRechargeOfferExternalId = AppPropertyProvider.getInstance().getString(
                OFFER_CONSTANTS.OFFER_EXTERNAL_ID_VISIBLE_SERVICE_CHARGES);

        MtxPurchasedOfferData cumulativeChargesOfferData = getPurchasedOfferData(
                cumulativeRechargeOfferExternalId, null, null, rechargeAmount, null, null, null,
                null, purchaseTimestamp);
        MtxRequestSubscriberPurchaseOffer cumulChrgPurchaseReq = getSubscriberPurchaseOfferRequest(
                subscriberSearchData, cumulativeChargesOfferData);
        INFO(
                m_logger, loggingKey + methodName + "Adding cumulative recharge request to Multirequest -  : "
                        + cumulChrgPurchaseReq.toJson());
        CommonUtils.addRequestToMulti(multiRequestObject, cumulChrgPurchaseReq);
    }

    /**
     * @param request
     * @param loggingKey
     * @param visiblePurchasedOfferExtension
     */
    private void updateAdditionalInfoOnOffer(ManualPayRequest request,
                                             String loggingKey,
                                             VisiblePurchasedOfferExtension visiblePurchasedOfferExtension,
                                             MtxResponseSubscription subscriber) {
    	final String methodName = "setAdditionalInfoOnOffer: ";
    	if (request.getSubscriberGroups() == null || request.getSubscriberGroups().isEmpty()) {
    		return;
    	}

        VisibleGroup vg = request.getSubscriberGroups().get(0);
        if (vg.getSubscriberMemberCount()!=null && vg.getSubscriberMemberCount() > 0) {
            DEBUG(m_logger,
                  loggingKey + methodName +
                  "Setting group member count to purchase offer extension: "+ vg.getSubscriberMemberCount());
            visiblePurchasedOfferExtension.setGroupMemberCount(vg.getSubscriberMemberCount());
        }
        if(StringUtils.isNotBlank(vg.getGroupName())) {
            DEBUG(m_logger,
                  loggingKey + methodName +
                  "Setting group name to purchase offer extension: "+ vg.getGroupName());
            visiblePurchasedOfferExtension.setGroupName(vg.getGroupName());
        }
        if(StringUtils.isNotBlank(vg.getGroupTier())) {
            DEBUG(m_logger,
                  loggingKey + methodName +
                  "Setting group tier to purchase offer extension: "+ vg.getGroupTier());
            visiblePurchasedOfferExtension.setGroupTier(vg.getGroupTier());
        }
        
        VisibleSubscriberExtension subExtn = (VisibleSubscriberExtension)subscriber.getAttr();
        if(StringUtils.isNotBlank(subExtn.getBrand())) {
            DEBUG(m_logger,
                  loggingKey + methodName +
                  "Setting brand to purchase offer extension: "+ subExtn.getBrand());
            visiblePurchasedOfferExtension.setBrand(subExtn.getBrand());
        }
    }

    /**
     * Prepare the VisibleInfo structure to be set in the Info field of recharge event, with cash
     * payment details and of course the purchaseTimeStamp legacy field.
     *
     * @param cashPayment
     * @param purchaseTimestamp
     * @param loggingKey
     * @return
     */
    private VisibleInfo prepareVisibleInfoStructure(VisibleCashPayment cashPayment,
                                                    String purchaseTimestamp,
                                                    String loggingKey) {
    	final String methodName = "prepareVisibleInfoStructure: ";
        VisibleInfo info = new VisibleInfo();
        info.setTimeStamp(new BigInteger(purchaseTimestamp));
        if (cashPayment != null && cashPayment.getAttributes() != null) {
            for (VisibleAttribute attrib : cashPayment.getAttributes()) {
                if (attrib.getName() != null && attrib.getValue() != null) {
                    long keyIndex = info.getContainer().lookupKey(attrib.getName());
                    if (keyIndex >= 0L) { // Valid field
                        Integer intVal = null;
                        // We dont know the data type of the field. So try to parse it.
                        try {
                            intVal = Integer.parseInt(attrib.getValue());
                            info.setInteger(keyIndex, intVal);
                        } catch (Exception e) {
                            Long longVal = null;
                            try {
                                longVal = Long.parseLong(attrib.getValue());
                                info.setLong(keyIndex, longVal);
                            } catch (Exception e1) {
                                Double doubleVal = null;
                                try {
                                    doubleVal = Double.parseDouble(attrib.getValue());
                                    info.setBigDecimal(keyIndex, new BigDecimal(doubleVal));
                                } catch (Exception e2) {
                                    // By default, set as string.
                                    try {
                                        info.setString(keyIndex, attrib.getValue());
                                    } catch (Exception e3) {
                                        @SuppressWarnings("rawtypes")
                                        Field errorField = info.getContainer().getField(keyIndex);
                                        WARN(
                                                m_logger,
                                                loggingKey + methodName + "Error setting the field - "
                                                        + (errorField != null
                                                        ? errorField.getName() : "Unknown")
                                                        + " : " + e3.getMessage());
                                    }
                                }
                            }
                        }
                    } else {
                        WARN(
                                m_logger,
                                loggingKey + methodName + "Error setting the field - " + attrib.getValue()
                                + " : No such field in VisibleInfo structure.");
                    }
                }
            }
        }
        return info;
    }

    /**
     * Adds the fraud info to the charge method data if fraud info is present on the request.
     *
     * @param request
     * @param chargeMethodDataForRecharge
     * @throws CommonUtilsException
     * @throws IntrospectionException
     */
    private void handleFraudInfo(String loggingKey,
                                 ManualPayRequest request,
                                 MtxChargeMethodData chargeMethodDataForRecharge, String yymmddOrderId, String reason)
                                         throws CommonUtilsException, IntrospectionException {
        if (request.getPayNow() != null && request.getPayNow().getPurchaseFraudInfo() != null) {

            VisibleFraudHomeAddress fraudBillingAddress = request.getPayNow().getPurchaseFraudInfo().getFraudHomeAddress();

            VisibleFraudShippingAddress fraudShippingAddress = request.getPayNow().getPurchaseFraudInfo().getFraudShippingAddress();

            VisibleFraudDeviceInfo fraudDeviceInfo = new VisibleFraudDeviceInfo();

            if (request.getPayNow().getPurchaseFraudInfo().getFraudDeviceInfo() != null) {
                fraudDeviceInfo = request.getPayNow().getPurchaseFraudInfo().getFraudDeviceInfo();
            }

            String fraudTransInfo = request.getPayNow().getPurchaseFraudInfo().getTransactionType();

            List<VisibleAttribute> paymentGatewayAttributes = new ArrayList<VisibleAttribute>();
            if (request.getPayNow().getPurchaseFraudInfo().getPaymentGatewayAttributes() != null
                    && !request.getPayNow().getPurchaseFraudInfo().getPaymentGatewayAttributes().isEmpty()) {
                paymentGatewayAttributes = request.getPayNow().getPurchaseFraudInfo().getPaymentGatewayAttributes();
            }

            boolean recOverride = StringUtils.isNotBlank(request.getVisibleRecurringOverride())
            		&& GENERIC_CONSTANTS.YES.equalsIgnoreCase(request.getVisibleRecurringOverride());

            CommonUtils.addFraudInfoAndPaymentInfoToChargeMethodData(
                    chargeMethodDataForRecharge, fraudBillingAddress, fraudShippingAddress,
                    fraudDeviceInfo, fraudTransInfo, recOverride,
                    paymentGatewayAttributes, loggingKey, request.getPayNow().getPaymentMethod(),
                    request.getPayNow().getPaymentInfo(),
                    request.getPayNow().getPaymentGatewayId(),
                    yymmddOrderId,
                    reason);

        }
    }

    private MtxResponseSubscription getSubscriberDetails(String loggingKey,
                                                         String route,
                                                         String subscriberExternalId)
		throws IntegrationServiceException, NoSuchMethodException, SecurityException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{	
		// Prepare subscriber search data
		MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
		searchData.setExternalId(subscriberExternalId);
		
		MtxResponseSubscription subscriber = querySubscriptionData(loggingKey, subscriberExternalId);
		CommonUtils.validateResponse(
		loggingKey, LOG_MESSAGES.LOG_FAILED_TO_QUERY_SUBSCRIBER, m_logger, ManualPayException.class,
		subscriber);
		
		return subscriber;
	}
    /**
     * Validate that the subscriber can do manual pay
     *
     * @param subscriber
     * @throws Exception
     */
    private void validateSubscriberForManualPay(MtxResponseSubscription subscriber)
            throws ManualPayException {
        // Read from properties, just if in-case empty, default from predefined enum
        final String ALLOWABLE_SUBSCR_STATS = AppPropertyProvider.getInstance().getString(
                MANUAL_PAY.ALLOWABLE_SUBSCR_STATS);

        String[] allowableSubscrStats = ALLOWABLE_SUBSCR_STATS.split(",");
        boolean bAllowedStat = false;
        for (String allowedStat : allowableSubscrStats) {
            if (allowedStat.equalsIgnoreCase(subscriber.getStatusDescription())) {
                bAllowedStat = true;
                break;
            }
        }
        if (!bAllowedStat) {
            throw new ManualPayException(
                    AppPropertyProvider.getInstance().getString(
                            MANUAL_PAY.ALLOWABLE_SUBSCR_STATS_ERR_MSG));
        }
    }

    /**
     * Prepare the Purchase request for the offer, and as well prepare the reason codes in the
     * hashmap to be used in rest of manual pay flow.
     *
     * @param request
     * @param loggingKey
     * @param route
     * @param purchaseTimestamp
     * @param subscriberSearchData
     * @return
     * @throws IntegrationServiceException
     */
    private List<MtxRequestSubscriberPurchaseOffer> processCreditsAndPreparePurchaseOfferRequest(ManualPayRequest request,
                                                                                                 String loggingKey,
                                                                                                 String route,
                                                                                                 String purchaseTimestamp,
                                                                                                 MtxSubscriberSearchData subscriberSearchData)
                                                                                                         throws IntegrationServiceException {
        List<MtxRequestSubscriberPurchaseOffer> purchaseOfferReqs = new ArrayList<>();
        if (request.getCredits() == null || request.getCredits().isEmpty()) {
        	return purchaseOfferReqs;	
        }

        for (VisibleCreditsManualPay credit : request.getCredits()) {
            //As per VER-6 clarifications by Gopal, now AOC credits can be partially redeemed. 
            //Hence we need to supply credit numbers to AOC credits also. 
            if (credit.getApprovedTransferableCredits() != null && credit.getApprovedTransferableCredits().signum() != 0) {                 
                MtxPurchasedOfferDataBuilder podb = (new MtxPurchasedOfferDataBuilder())
                		.withOfferExternalId(credit.getCreditRedeemableOfferCI())
                		.withAmount(credit.getApprovedTransferableCredits())
                		.withGoodType(credit.getRedeemableGoodType())
                        .withCoreBasePlanCI(credit.getApplicableCI())
                		.withInfo(purchaseTimestamp)
                		.withCreditReason(credit.getRedeemableGoodType());
                if(credit.getApplicableCreditsPercentage()!=null && credit.getApplicableCreditsPercentage().signum()>0) {
                	podb.withCreditGrantType(CREDIT_CONSTANTS.GRANT_TYPE_PERCENTAGE);
                }
                		
                purchaseOfferReqs.add(getSubscriberPurchaseOfferRequest(subscriberSearchData, podb.build()));
            }
        }

        return purchaseOfferReqs;
    }

    /**
     * Prepare Credit Tax Details request
     *
     * @param request
     * @param purchaseOffersToUpdateTax
     * @param creditTaxDetailFieldNames
     * @param loggingKey
     * @param subscriberSearchData
     * @param responseSubscriber
     * @return
     * @throws ManualPayException 
     * @throws Exception
     */
    private List<MtxRequestSubscriberModifyOffer> 
    			processCreditTaxDetails(ManualPayRequest request,
                                        List<CatalogItemUpdate> ciUpdateList,
                                        String loggingKey,
                                        MtxSubscriberSearchData subscriberSearchData,
                                        MtxResponseSubscription responseSubscriber) throws ManualPayException{
    	final String methodName = "processCreditTaxDetails";

    	List<CatalogItemUpdate> missingUpdates = new ArrayList<CatalogItemUpdate>(); 
        List<MtxRequestSubscriberModifyOffer> subscriberModifyOffers = new ArrayList<>();
        if (request.getCredits() != null && !request.getCredits().isEmpty()) {
            for (VisibleCreditsManualPay credit : request.getCredits()) {
            	CatalogItemUpdate ciToUpdate = null;
            	for(CatalogItemUpdate ci:ciUpdateList) {
            		if(ci.getCatalogItemExternalId().equalsIgnoreCase(credit.getApplicableCI())) {
            			ciToUpdate = ci;            			
            			break;
            		}
            	}            	
            	
                if (ciToUpdate != null) {
                	VisiblePurchasedOfferExtension offerExtensionToUpdate = ciToUpdate.getPurchasedOfferExtension();
//                	clearLegacyTaxDetailsForCreditField(
//                        		loggingKey, offerExtensionToUpdate, responseSubscriber, credit.getApplicableCI());
                	DEBUG(m_logger, loggingKey + methodName +StringUtils.SPACE+ "Found offer to be updated with promo tax details.: "+ciToUpdate.getCatalogItemExternalId()+"-"+ciToUpdate.getResourceId());
                	addToCreditTaxDetailInArray(offerExtensionToUpdate, credit);
                } else {
                	CatalogItemUpdate missingUpdate = null; 
                	for(CatalogItemUpdate pair:missingUpdates) {
                		if(pair.getCatalogItemExternalId().equalsIgnoreCase(credit.getApplicableCI())) {
                			missingUpdate = pair;
                			break;
                		}
                	}

                	if(missingUpdate == null) {
                		missingUpdate = CatalogItemUpdate.createCatalogItemUpdate(loggingKey, credit.getApplicableCI(), responseSubscriber);
                		
                		missingUpdates.add(missingUpdate);
                	}                	
                	
                	missingUpdate.addCreditTaxList(credit.getTaxDetails());
                }
            }

            for(CatalogItemUpdate mu:missingUpdates) {
            	VisiblePurchasedOfferExtension visiblePurchasedOfferExtension = new VisiblePurchasedOfferExtension();
                if (request.getAttrData() != null) {
                    visiblePurchasedOfferExtension = request.getAttrData();
                }
            	mu.setVisiblePurchasedOfferExtension(visiblePurchasedOfferExtension);
                MtxRequestSubscriberModifyOffer subscriberModifyOffer = getSubscriberModifyOfferRequest(
                        request, loggingKey, subscriberSearchData, responseSubscriber, mu);
                if (subscriberModifyOffer != null) {
                    subscriberModifyOffers.add(subscriberModifyOffer);
                    DEBUG(m_logger, loggingKey + methodName + subscriberModifyOffer.toJson());
                }            	            	
            }
        }
        return subscriberModifyOffers;
    }

    /**
     * Clear all existing credit tax details of the given offer.
     *
     * @param poExtn
     */
    @SuppressWarnings("unchecked")
    private void clearAllCreditTaxDetails(String loggingKey,
    									  String offerCi,
    									  VisiblePurchasedOfferExtension poExtn) {
    	final String methodKey = loggingKey +" clearAllCreditTaxDetails: ";
    	INFO(m_logger, methodKey + "Clearing credit tax details for purchased offer: "+ offerCi);
    	if (poExtn.getCreditTaxDetailsArray() != null) {            
            poExtn.getCreditTaxDetailsArray().clear();
        }         
        poExtn.getCreditTaxDetailsArrayAppender().add(StringUtils.EMPTY);
    }

//    /**
//     * Clear the legacy field TaxDetailsForCredit Fetch original offer from subscriber object and
//     * check if it had a taxdetail for credit..
//     *
//     * @param offerExtension
//     * @param responseSubscriber
//     * @param offerExternalIdToUpdate
//     */    
//    private void clearLegacyTaxDetailsForCreditField(String loggingKey,
//                                                     VisiblePurchasedOfferExtension offerExtension,
//                                                     MtxResponseSubscription responseSubscriber,
//                                                     String offerExternalIdToUpdate) {
//    	final String methodName = "clearLegacyTaxDetailsForCreditField: ";
//        List<MtxPurchasedOfferInfo> subscriberPurchaseOffers = responseSubscriber.getPurchasedOfferArray();
//        boolean legacyFieldExists = false;
//        if (subscriberPurchaseOffers != null) {
//            for (MtxPurchasedOfferInfo info : subscriberPurchaseOffers) {
//                MtxPurchasedOfferExtension offerExt = info.getAttr();
//                if (offerExternalIdToUpdate.equalsIgnoreCase(info.getCatalogItemExternalId())
//                        && offerExt instanceof VisiblePurchasedOfferExtension) {
//                    VisiblePurchasedOfferExtension ext = (VisiblePurchasedOfferExtension) offerExt;
//                    legacyFieldExists = StringUtils.isNotEmpty(ext.getTaxDetailsForCredit());
//                    break;
//                }
//            }
//        }
//        if (legacyFieldExists) {
//            INFO(m_logger,
//            		loggingKey+ methodName + "Clearing legacy deprecated field TaxDetailsForCredit for "+ offerExternalIdToUpdate);
//            offerExtension.setTaxDetailsForCredit("");
//        }
//    }

    private void addToCreditTaxDetailInArray(VisiblePurchasedOfferExtension updateExtension,
            VisibleCreditsManualPay credit)
                    throws ManualPayException {
    	final String methodName = "addToCreditTaxDetailInArray: ";
        INFO(
                m_logger, methodName + "offerToUpdate.getCreditTaxDetailsArray ="
                        + updateExtension.getCreditTaxDetailsArray());
       
        updateExtension.appendCreditTaxDetailsArray(credit.getTaxDetails());
        INFO(m_logger, methodName + "Added new credit tax details..: " + updateExtension.toJson());
        
        /* Remove any empty credit tax strings */
        boolean foundEmptyTaxString = false;
        // Copy tax strings
        ArrayList<String> creditTaxStringArray = new ArrayList<String>();
        for (String taxString : updateExtension.getCreditTaxDetailsArray()) {
            if (StringUtils.isNotBlank(taxString)) {
                creditTaxStringArray.add(taxString);
            } else {
                foundEmptyTaxString = true;
            }
        }
        // Clear empty tax strings if they were found
        if (foundEmptyTaxString && updateExtension.getCreditTaxDetailsArray()!= null && updateExtension.getCreditTaxDetailsArray().size()>0) {
        	//If there us only item in array and it is empty then do not clear it. Otherwise credittaxdetailarray will never get cleared.
            updateExtension.getCreditTaxDetailsArray().clear();
            for (String taxString : creditTaxStringArray) {
                updateExtension.appendCreditTaxDetailsArray(taxString);
            }
        }
    }    
}
