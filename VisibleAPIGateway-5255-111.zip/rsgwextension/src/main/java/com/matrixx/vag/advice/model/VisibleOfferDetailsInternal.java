package com.matrixx.vag.advice.model;

import com.matrixx.datacontainer.MtxTimestamp;
import com.matrixx.datacontainer.mdc.VisibleOfferDetails;
import com.matrixx.platform.JsonObject;

public class VisibleOfferDetailsInternal extends VisibleOfferDetails {

    private MtxTimestamp purchaseOfferEndTime;
    private MtxTimestamp purchaseCycleEndTime;

    public MtxTimestamp getPurchaseOfferEndTime() {
        return purchaseOfferEndTime;
    }

    public void setPurchaseOfferEndTime(MtxTimestamp purchaseOfferEndTime) {
        this.purchaseOfferEndTime = purchaseOfferEndTime;
    }

    public MtxTimestamp getPurchaseCycleEndTime() {
        return purchaseCycleEndTime;
    }

    public void setPurchaseCycleEndTime(MtxTimestamp purchaseCycleEndTime) {
        this.purchaseCycleEndTime = purchaseCycleEndTime;
    }

    public String toJson() {
        JsonObject obj = new JsonObject();
        String ret = null;
        this.toJson(obj);
        ret = obj.toString();
        return ret;
    }
}
