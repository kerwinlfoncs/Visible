package com.matrixx.vag.advice.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL) // Ignore unused fields to reduce payload size.
public class Incompatibility {
	@JsonProperty("ClassCode")
    private String classCode;
	@JsonProperty("Condition")
    private IncompatibilityCondition condition;
	
	Incompatibility() {
    }
	
    public String getClassCode() {
		return classCode;
	}

	public void setClassCode(String classCode) {
		this.classCode = classCode;
	}

	public IncompatibilityCondition getCondition() {
		return condition;
	}

	public void setCondition(IncompatibilityCondition condition) {
		this.condition = condition;
	}

    public String toJson() {
    	ObjectMapper mapper = new ObjectMapper();
    	try {
			return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(this);
		} catch (JsonProcessingException e) {
			return null;
		}
    }

}