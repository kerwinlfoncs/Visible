package com.matrixx.vag.common.request.builder;

import com.matrixx.datacontainer.mdc.MtxDeviceSearchData;
import com.matrixx.datacontainer.mdc.MtxRequestDeviceDelete;
import com.matrixx.vag.common.coverage.Generated;

@Generated
public class MtxRequestDeviceDeleteBuilder {
	MtxDeviceSearchData searchData;
    public MtxRequestDeviceDelete build() {
		if(searchData==null) {
			this.searchData = new MtxDeviceSearchData();	
		}
		MtxRequestDeviceDelete device = new MtxRequestDeviceDelete();
    	device.setDeviceSearchData(searchData);
    	return device;
    }
}
