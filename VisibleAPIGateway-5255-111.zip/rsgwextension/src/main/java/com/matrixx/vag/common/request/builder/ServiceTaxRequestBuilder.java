package com.matrixx.vag.common.request.builder;

import java.io.IOException;
import java.math.BigDecimal;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.coverage.Generated;
import com.matrixx.vag.tax.model.ServiceTaxRequest;

@Generated
public class ServiceTaxRequestBuilder {

    String requestTemplate;
    String geoCode;
    String planID;
    String brand;
    
    BigDecimal grossPrice;
    BigDecimal discountPrice;
    BigDecimal vendorPayableNonProrated;
    BigDecimal vendorPayable;
    
    public ServiceTaxRequest build() throws JsonParseException, JsonMappingException, IOException {
        ServiceTaxRequest retVal;
        if (StringUtils.isNotBlank(requestTemplate)) {
            ObjectMapper mapper = CommonUtils.getObjectMapper();
            retVal = mapper.readValue(requestTemplate, ServiceTaxRequest.class);
        } else {
            retVal = new ServiceTaxRequest();
        }
        
        if (StringUtils.isNotBlank(geoCode)) {
            retVal.setGeocode(geoCode);
        }

        if (StringUtils.isNotBlank(planID)) {
            retVal.setPlanID(planID);
        }

        if (StringUtils.isNotBlank(brand)) {
            retVal.setBrand(brand);
        }

        if (grossPrice!=null) {
            retVal.setGrossPrice(grossPrice);
        }else {
            retVal.setGrossPrice(discountPrice);
        }

        if (discountPrice!=null) {
            retVal.setDiscountPrice(discountPrice);
        }

        if (vendorPayableNonProrated!=null) {
            retVal.setVendorPayableNonProrated(vendorPayableNonProrated);
        }
        
        if (vendorPayable!=null) {
            retVal.setVendorPayable(vendorPayable);
        }
        return retVal;
    }

    public ServiceTaxRequestBuilder withRequestTemplate(String requestTemplate) {
        if (StringUtils.isNotBlank(requestTemplate)) {
            this.requestTemplate = requestTemplate;
        }
        return this;
    }
    
    public ServiceTaxRequestBuilder withGeoCode(String geoCode) {
        if (StringUtils.isNotBlank(geoCode)) {
            this.geoCode = geoCode;
        }
        return this;
    }

    public ServiceTaxRequestBuilder withPlanID(String planID) {
        if (StringUtils.isNotBlank(planID)) {
            this.planID = planID;
        }
        return this;
    }

    public ServiceTaxRequestBuilder withBrand(String brand) {
        if (StringUtils.isNotBlank(brand)) {
            this.brand = brand;
        }
        return this;
    }

    public ServiceTaxRequestBuilder withVendorPayableNonProrated(BigDecimal vendorPayableNonProrated) {
        if (vendorPayableNonProrated!=null) {
            this.vendorPayableNonProrated = vendorPayableNonProrated;
        }
        return this;
    }

    public ServiceTaxRequestBuilder withVendorPayable(BigDecimal vendorPayable) {
        if (vendorPayable!=null) {
            this.vendorPayable = vendorPayable;
        }
        return this;
    }

    public ServiceTaxRequestBuilder withDiscountPrice(BigDecimal discountPrice) {
        if (discountPrice!=null) {
            this.discountPrice = discountPrice;
        }
        return this;
    }

    public ServiceTaxRequestBuilder withGrossPrice(BigDecimal grossPrice) {
        if (grossPrice!=null) {
            this.grossPrice = grossPrice;
        }
        return this;
    }

}
