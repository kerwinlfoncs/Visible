package com.matrixx.vag.exception;

/**
 * Exception thrown upon encountering an error with processing subscriber offers.
 *
 * @author unico
 */
public class PaymentAdviceException extends IntegrationServiceException {

    private static final long serialVersionUID = 5376007462937047858L;

    public PaymentAdviceException(Long resultCode, String message) {
        super(resultCode, message);
    }
}
