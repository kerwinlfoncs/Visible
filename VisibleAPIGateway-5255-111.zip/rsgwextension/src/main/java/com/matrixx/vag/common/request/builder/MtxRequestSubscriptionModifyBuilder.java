package com.matrixx.vag.common.request.builder;

import org.apache.commons.lang3.StringUtils;

import com.matrixx.datacontainer.mdc.MtxRequestSubscriptionModify;
import com.matrixx.datacontainer.mdc.MtxSubscriptionSearchData;
import com.matrixx.datacontainer.mdc.VisibleSubscriberExtension;

public class MtxRequestSubscriptionModifyBuilder {

    String subscriberExternalId;
    MtxSubscriptionSearchData searchData;
    VisibleSubscriberExtension existingAttr;
    String cycleLength;

    boolean needExtn = false;

    public MtxRequestSubscriptionModify build() {
        VisibleSubscriberExtension attr = null;

        if (searchData == null) {
            this.searchData = new MtxSubscriptionSearchData();
        }

        if (StringUtils.isNotBlank(subscriberExternalId)
                && StringUtils.isBlank(searchData.getExternalId())) {
            this.searchData.setExternalId(subscriberExternalId);
        }

        MtxRequestSubscriptionModify subMod = new MtxRequestSubscriptionModify();
        subMod.setSubscriptionSearchData(searchData);

        if (this.existingAttr != null) {
            attr = this.existingAttr;
        } else if (needExtn) {
            attr = new VisibleSubscriberExtension();
        }

        if (StringUtils.isNotBlank(cycleLength)) {
            attr.setCycleLength(cycleLength);
        }

        subMod.setAttr(attr);

        return subMod;
    }

    public MtxRequestSubscriptionModifyBuilder withSubscriberExternalId(String subscriberExternalId) {
        if (StringUtils.isNotBlank(subscriberExternalId)) {
            this.subscriberExternalId = subscriberExternalId;
        }
        return this;
    }

    public MtxRequestSubscriptionModifyBuilder withSearchData(MtxSubscriptionSearchData searchData) {
        if (searchData != null) {
            this.searchData = searchData;
        }
        return this;
    }

    public MtxRequestSubscriptionModifyBuilder withAttr(VisibleSubscriberExtension attr) {
        if (attr != null) {
            this.existingAttr = attr;
        }
        return this;
    }

    public MtxRequestSubscriptionModifyBuilder withCycleLength(String cycleLength) {
        if (StringUtils.isNotBlank(cycleLength)) {
            this.cycleLength = cycleLength;
            needExtn = true;
        }
        return this;
    }
}
