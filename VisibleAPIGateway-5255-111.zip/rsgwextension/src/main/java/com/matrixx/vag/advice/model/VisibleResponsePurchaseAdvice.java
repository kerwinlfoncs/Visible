package com.matrixx.vag.advice.model;

import java.util.ArrayList;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.matrixx.datacontainer.mdc.VisibleResponsePaymentAdviceService;

public class VisibleResponsePurchaseAdvice extends VisibleResponsePaymentAdviceService {

    ArrayList<VisibleOfferDetailsInternal> vodList = new ArrayList<VisibleOfferDetailsInternal>();

    public ArrayList<VisibleOfferDetailsInternal> getVodList() {
        return vodList;
    }

    public void appendToVodList(VisibleOfferDetailsInternal vod) {
        vodList.add(vod);
    }

    public String toJson() {
        ObjectMapper mapper = new ObjectMapper();
        try {
            return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(this);
        } catch (JsonProcessingException e) {
            return null;
        }
    }
}
