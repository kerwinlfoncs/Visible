package com.matrixx.vag.common.request.builder;

import com.matrixx.datacontainer.MtxDate;
import com.matrixx.datacontainer.MtxTimestamp;
import com.matrixx.datacontainer.mdc.MtxPurchasedItemCycleData;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberModifyOffer;
import com.matrixx.datacontainer.mdc.MtxSubscriberSearchData;
import com.matrixx.datacontainer.mdc.VisiblePurchasedOfferExtension;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;

/**
 * Defines property names and constants used by the API gateway.
 *
 * @author unico
 */
public class MtxRequestSubscriberModifyOfferBuilder {

    String subscriberExternalId;
    String taxDetails;
    String purchaseServiceType;
    String orderId;
    String groupName;
    String groupTier;
    String classCode;
    String promotionName;

    Long groupMemberCount;
    Long resourceId;

    BigDecimal chargeAmount;
    BigDecimal promotionLimit;

    MtxTimestamp endTime;

    MtxDate paidCycleStartDate;

    Set<String> creditTaxDetailsArray = new HashSet<String>();

    MtxPurchasedItemCycleData cycleData;// = new MtxPurchasedItemCycleData();
    MtxTimestamp cycleEndTime;

    VisiblePurchasedOfferExtension existingAttr;

    MtxSubscriberSearchData searchData;

    boolean needExtn = false;

    public MtxRequestSubscriberModifyOffer build() {

        VisiblePurchasedOfferExtension attr = null;

        if (this.existingAttr != null) {
            attr = this.existingAttr;
        } else if (needExtn) {
            attr = new VisiblePurchasedOfferExtension();
        }

        if (searchData == null) {
            this.searchData = new MtxSubscriberSearchData();
        }

        if (StringUtils.isNotBlank(subscriberExternalId)
                && StringUtils.isBlank(searchData.getExternalId())) {
            this.searchData.setExternalId(subscriberExternalId);
        }

        if (chargeAmount != null) {
            attr.setChargeAmount(chargeAmount);
        }

        if (StringUtils.isNotBlank(taxDetails)) {
            attr.setTaxDetails(taxDetails);
        }

        if (StringUtils.isNotBlank(purchaseServiceType)) {
            attr.setPurchaseServiceType(purchaseServiceType);
        }

        if (paidCycleStartDate != null) {
            attr.setPaidCycleStartDate(paidCycleStartDate);
        }

        if (StringUtils.isNotBlank(orderId)) {
            attr.setOrderId(orderId);
        }

        if (StringUtils.isNotBlank(groupName)) {
            attr.setGroupName(groupName);
        }

        if (StringUtils.isNotBlank(groupTier)) {
            attr.setGroupTier(groupTier);
        }

        if (groupMemberCount != null) {
            attr.setGroupMemberCount(groupMemberCount);
        }

        if (StringUtils.isNotBlank(classCode)) {
            attr.setClassCode(classCode);
        }

        if (StringUtils.isNotBlank(promotionName)) {
            attr.setPromotionName(promotionName);
        }

        if (promotionLimit != null && promotionLimit.signum() > 0) {
            attr.setPromotionLimit(promotionLimit);
        }

        if ((this.creditTaxDetailsArray != null && !this.creditTaxDetailsArray.isEmpty())
                && (attr.getCreditTaxDetailsArray() == null
                        || attr.getCreditTaxDetailsArray().isEmpty())) {
            for (String taxString : this.creditTaxDetailsArray) {
                if (StringUtils.isNotBlank(taxString)) {
                    attr.getCreditTaxDetailsArrayAppender().add(taxString);
                }
            }
        }

        MtxRequestSubscriberModifyOffer modifyOffer = new MtxRequestSubscriberModifyOffer();
        modifyOffer.setAttr(attr);
        modifyOffer.setSubscriberSearchData(searchData);

        if (resourceId != null) {
            modifyOffer.setResourceId(resourceId);
        }

        if (endTime != null) {
            modifyOffer.setEndTime(endTime);
        }

        if (cycleEndTime != null) {
            if (cycleData == null) {
                cycleData = new MtxPurchasedItemCycleData();
            }
            cycleData.setCycleEndTime(cycleEndTime);
        }

        if (cycleData != null) {
            modifyOffer.setCycleData(cycleData);
        }

        return modifyOffer;
    }

    public MtxRequestSubscriberModifyOfferBuilder withAttr(VisiblePurchasedOfferExtension attr) {
        if (attr != null) {
            this.existingAttr = attr;
        }
        return this;
    }

    public MtxRequestSubscriberModifyOfferBuilder withSubscriberExternalId(String subscriberExternalId) {
        if (StringUtils.isNotBlank(subscriberExternalId)) {
            this.subscriberExternalId = subscriberExternalId;
        }
        return this;
    }

    public MtxRequestSubscriberModifyOfferBuilder withSearchData(MtxSubscriberSearchData searchData) {
        if (searchData != null) {
            this.searchData = searchData;
        }
        return this;
    }

    public MtxRequestSubscriberModifyOfferBuilder withResourceId(Long resourceId) {
        if (resourceId != null) {
            this.resourceId = resourceId;
        }
        return this;
    }

    public MtxRequestSubscriberModifyOfferBuilder withEndTime(MtxTimestamp endTime) {
        if (endTime != null) {
            this.endTime = endTime;
        }
        return this;
    }

    public MtxRequestSubscriberModifyOfferBuilder withChargeAmount(BigDecimal chargeAmount) {
        if (chargeAmount != null) {
            this.chargeAmount = chargeAmount;
            needExtn = true;
        }
        return this;
    }

    public MtxRequestSubscriberModifyOfferBuilder withTaxDetails(String taxDetails) {
        if (StringUtils.isNotBlank(taxDetails)) {
            this.taxDetails = taxDetails;
            needExtn = true;
        }
        return this;
    }

    public MtxRequestSubscriberModifyOfferBuilder withCreditTaxDetails(String creditTaxDetails) {
        if (StringUtils.isNotBlank(creditTaxDetails)) {
            this.creditTaxDetailsArray.add(creditTaxDetails);
            needExtn = true;
        }
        return this;
    }

    // public MtxRequestSubscriberModifyOfferBuilder withCycleData(MtxPurchasedItemCycleData
    // cycleData) {
    // if(cycleData != null) {
    // this.cycleData = cycleData;
    // }
    // return this;
    // }

    public MtxRequestSubscriberModifyOfferBuilder withCycleEndTime(MtxTimestamp cycleEndTime) {
        if (cycleEndTime != null) {
            this.cycleEndTime = cycleEndTime;
        }
        return this;
    }

    public MtxRequestSubscriberModifyOfferBuilder withPurchaseServiceType(String purchaseServiceType) {
        if (StringUtils.isNotBlank(purchaseServiceType)) {
            this.purchaseServiceType = purchaseServiceType;
            needExtn = true;
        }
        return this;
    }

    public MtxRequestSubscriberModifyOfferBuilder withPaidCycleStartDate(MtxDate paidCycleStartDate) {
        if (paidCycleStartDate != null) {
            this.paidCycleStartDate = paidCycleStartDate;
            needExtn = true;
        }
        return this;
    }

    public MtxRequestSubscriberModifyOfferBuilder withOrderId(String orderId) {
        if (StringUtils.isNotBlank(orderId)) {
            this.orderId = orderId;
            needExtn = true;
        }
        return this;
    }

    public MtxRequestSubscriberModifyOfferBuilder withGroupName(String groupName) {
        if (StringUtils.isNotBlank(groupName)) {
            this.groupName = groupName;
            needExtn = true;
        }
        return this;
    }

    public MtxRequestSubscriberModifyOfferBuilder withGroupTier(String groupTier) {
        if (StringUtils.isNotBlank(groupTier)) {
            this.groupTier = groupTier;
            needExtn = true;
        }
        return this;
    }

    public MtxRequestSubscriberModifyOfferBuilder withGroupMemberCount(Long groupMemberCount) {
        if (resourceId != null) {
            this.groupMemberCount = groupMemberCount;
        }
        return this;
    }

    public MtxRequestSubscriberModifyOfferBuilder withClassCode(String classCode) {
        if (StringUtils.isNotBlank(classCode)) {
            this.classCode = classCode;
            needExtn = true;
        }
        return this;
    }

    public MtxRequestSubscriberModifyOfferBuilder withPromotionName(String promotionName) {
        if (StringUtils.isNotBlank(promotionName)) {
            this.promotionName = promotionName;
            needExtn = true;
        }
        return this;
    }

    public MtxRequestSubscriberModifyOfferBuilder withPromotionLimit(BigDecimal promotionLimit) {
        if (promotionLimit != null) {
            this.promotionLimit = promotionLimit;
            needExtn = true;
        }
        return this;
    }
}
