package com.matrixx.vag.subscriber.service;

import com.matrixx.datacontainer.MtxTimestamp;
import com.matrixx.datacontainer.mdc.*;
import com.matrixx.platform.MatrixxContext;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.Constants;
import com.matrixx.vag.common.Constants.TAX_CONSTANTS;
import com.matrixx.vag.common.request.builder.*;
import com.matrixx.vag.exception.GiftServiceException;
import com.matrixx.vag.service.IntegrationService;
import com.matrixx.vag.tax.model.ServiceTaxResponse;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.naming.ConfigurationException;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.ZoneId;

import static com.matrixx.platform.LogUtils.INFO;
import static com.matrixx.platform.LogUtils.WARN;

@Configuration
public class GiftService extends IntegrationService {

    private final RequestValidator requestValidator;

    private static final Logger m_logger = LoggerFactory.getLogger(GiftService.class);

    @Bean(name = "GiftService")
    GiftService getService() {
        return new GiftService();
    }

    public GiftService() {
        this.requestValidator = new RequestValidator();
    }

    public void giftSubscriber(VisibleRequestGiftService input, VisibleGiftServiceResponse output)
            throws Exception {

        // Setup the logging key
        String loggingKey = getLoggingKey(input.getGifterExternalId());
        final String methodKey = loggingKey + " giftSubscriber: ";

        // Determine routing data
        String route = getRoute(MatrixxContext.getRequest());

        // Validate the request
        requestValidator.validateRequest(loggingKey, input);

        // Get Subscription Details
        SubscriptionResponse gifterSubsRes = querySubscriptionByExternalId(
                loggingKey, route, input.getGifterExternalId());
        SubscriptionResponse gifteeSubsRes = querySubscriptionByExternalId(
                loggingKey, route, input.getGifteeExternalId());

        // Get Subscriber search Data
        MtxSubscriberSearchData gifterSearchData = new MtxSubscriberSearchData();
        gifterSearchData.setExternalId(input.getGifterExternalId());

        MtxSubscriberSearchData gifteeSearchData = new MtxSubscriberSearchData();
        gifteeSearchData.setExternalId(input.getGifteeExternalId());

        // Create Multi Request
        MtxRequestMulti multiReqGiftService = new MtxRequestMulti();

        BigDecimal giftAmount = BigDecimal.ZERO;
        Long resourceId = null;
        Long targetResourceId = null;
        String reason = null;
        String taxDetails = null;
        String creditTaxDetails = null;
        BigDecimal chargeAmount;
        String orderID = null;
        String serviceOfferExternalId = null;
        ServiceTaxResponse gifterTaxResponse;
        boolean isActiveSubscriber = false;
        boolean isChrgAmntUpdated = false;
        ZoneId zoneId = null;
        String cycleLength = null;
        MtxTimestamp cycleStartTime = null;
        MtxTimestamp cycleEndTime = null;

        if (gifteeSubsRes.getTimeZone() != null) {
            zoneId = ZoneId.of(gifteeSubsRes.getTimeZone());
        }
        LocalDate today = LocalDate.now(zoneId);

        // Validate Giftee's Mandatory params
        requestValidator.validateRequest(loggingKey, gifteeSubsRes);

        // Set Parameters for Balance Transfer request
        if (input.getGiftingServiceInfo() != null) {
            reason = input.getGiftingServiceInfo().getTransferBalanceReason();
            giftAmount = input.getGiftingServiceInfo().getServiceGrossPrice();
            serviceOfferExternalId = input.getGiftingServiceInfo().getCatalogItemExternalId();
        }

        for (BalanceInfo bi : CommonUtils.emptyIfNull(gifterSubsRes.getWalletBalances())) {
            if (bi.getIsMainBalance()) {
                resourceId = bi.getResourceId();
                break;
            }
        }

        for (BalanceInfo bi : gifteeSubsRes.getWalletBalances()) {
            if (bi.getIsMainBalance()) {
                targetResourceId = bi.getResourceId();
                break;
            }
        }

        for (MtxPurchasedOfferInfo offerArray : CommonUtils.emptyIfNull(
                gifteeSubsRes.getPurchasedOfferArray())) {
            if (offerArray.getProductOfferExternalId() != null
                    && !offerArray.getProductOfferExternalId().equalsIgnoreCase(
                            Constants.CI_EXTERNAL_IDS.SETUP_SERVICES))
                isActiveSubscriber = true;
        }

        if (isActiveSubscriber) {
            Long resultCode = Constants.RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR;
            String message = "Giftee is an active subscriber";
            WARN(m_logger, loggingKey + message);
            throw new GiftServiceException(resultCode, message);
        }

        // store Giftee's orderID from input
        orderID = input.getAttrData().getOrderId();

        EventQueryResponseEvents eventList = queryRechargeEvents(input.getGifterExternalId());
        for (EventQueryEventInfo eventInfo : CommonUtils.emptyIfNull(eventList.getEventList())) {
            if (eventInfo.getEventDetails() == null) {
                continue;
            }
            MtxEvent rechgInfo = eventInfo.getEventDetails();
            if (rechgInfo instanceof MtxRechargeEvent) {
                MtxRechargeEvent rechargeEvent = (MtxRechargeEvent) rechgInfo;
                if (rechargeEvent.getRechargeAttr() != null) {
                    VisibleRechargeExtension pre = (VisibleRechargeExtension) rechargeEvent.getRechargeAttr();
                    INFO(m_logger, methodKey + " Recharge event Attribute: " + pre);
                    taxDetails = pre.getGiftTaxDetails();
                    creditTaxDetails = pre.getGiftCreditTaxDetails();
                }
            }
        }

        // Fetch Tax Details
        if (taxDetails != null && CommonUtils.isServiceTaxResponseValid(taxDetails)) {
            gifterTaxResponse = CommonUtils.getServiceTaxResponseFromJsonString(taxDetails);
            gifterTaxResponse.setGlDate(String.valueOf(today));
            gifterTaxResponse.setMsgID(
                    TAX_CONSTANTS.MSG_PREFIX_GIFT_TAX + "|" + input.getGifterExternalId());
            taxDetails = gifterTaxResponse.toJson();

            INFO(
                    m_logger,
                    methodKey + "Tax details from Recharge event: " + gifterTaxResponse.toJson());
        } else {
            if (taxDetails != null && !CommonUtils.isServiceTaxResponseValid(taxDetails)) {
                Long resultCode = Constants.RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR;
                String message = "Tax details is in incorrect json format";
                WARN(m_logger, loggingKey + message);
                throw new GiftServiceException(resultCode, message);
            } else {
                Long resultCode = Constants.RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR;
                String message = "Failed to fetch Tax details from Recharge event";
                WARN(m_logger, loggingKey + message);
                throw new GiftServiceException(resultCode, message);
            }

        }

        // Set Cycle length Attr
        MtxResponsePricingCatalogItem pci = queryPricingCatalogItem(
                loggingKey, route, input.getGiftingServiceInfo().getCatalogItemExternalId());
        if (gifteeSubsRes.getBillingCycle() != null
                && gifteeSubsRes.getBillingCycle().getCurrentPeriodStartTime() != null) {
            cycleStartTime = gifteeSubsRes.getBillingCycle().getCurrentPeriodStartTime();
            if (pci.getCatalogItemInfo().getCyclePeriod() != null
                    && pci.getCatalogItemInfo().getCyclePeriodInterval() != null
                    && gifteeSubsRes.getTimeZone() != null) {
                cycleEndTime = CommonUtils.getCycleEndDate(
                        cycleStartTime, gifteeSubsRes.getTimeZone(),
                        pci.getCatalogItemInfo().getCyclePeriod(),
                        pci.getCatalogItemInfo().getCyclePeriodInterval(),
                        gifteeSubsRes.getBillingCycle());
            }
        }

        if (cycleStartTime != null && cycleEndTime != null && gifteeSubsRes.getTimeZone() != null) {
            MtxTimestamp monthBeforeNextCycle = CommonUtils.subtractOneMonth(
                    cycleEndTime, gifteeSubsRes.getTimeZone());
            if (monthBeforeNextCycle.longValue() > cycleStartTime.longValue()) {
                cycleLength = Constants.CYCLE_LENGTHS.YEAR;
            }
        }

        if (StringUtils.isBlank(cycleLength)) {
            cycleLength = Constants.CYCLE_LENGTHS.MONTH;
        }

        MtxRequestSubscriptionModifyBuilder smb = (new MtxRequestSubscriptionModifyBuilder()).withSubscriberExternalId(
                input.getGifteeExternalId()).withCycleLength(cycleLength);
        MtxRequestSubscriptionModify sm = smb.build();
        INFO(
                m_logger, methodKey + "Add " + MtxRequestSubscriptionModify.class.getSimpleName()
                        + " request to update cycle length attribute: " + sm.toJson());
        multiReqGiftService.appendRequestList(sm);

        // Calculate Charge Amount in case of promotions
        if ((creditTaxDetails != null) && CommonUtils.isServiceTaxResponseValid(creditTaxDetails)) {
            ServiceTaxResponse creditGifterTaxResponse = CommonUtils.getServiceTaxResponseFromJsonString(
                    creditTaxDetails);
            INFO(
                    m_logger, methodKey + "Credit Tax details from Recharge event: "
                            + creditGifterTaxResponse.toJson());

            chargeAmount = calculateChargeAmount(taxDetails, creditTaxDetails, loggingKey);
            if (chargeAmount.compareTo(BigDecimal.ZERO) == 1) {
                giftAmount = chargeAmount;
                isChrgAmntUpdated = true;
                INFO(
                        m_logger,
                        methodKey + "Value of ChargeAmount in case of promotions" + giftAmount);
            }
        }

        // Transfer Balance Request
        MtxRequestSubscriberTransferBalanceBuilder stbb = (new MtxRequestSubscriberTransferBalanceBuilder()).withSubscriberSearchData(
                gifterSearchData).withTargetSubscriberSearchData(gifteeSearchData).withResourceId(
                        resourceId).withTargetResourceId(targetResourceId).withGiftAmount(
                                giftAmount).withReason(reason);

        MtxRequestSubscriberTransferBalance stb = stbb.build();
        multiReqGiftService.appendRequestList(stb);

        // Purchase Service
        MtxPurchasedOfferDataBuilder pob = (new MtxPurchasedOfferDataBuilder()).withOfferExternalId(
                serviceOfferExternalId).withAmount(giftAmount).withTaxDetails(
                        taxDetails).withOrderId(orderID).withCreditTaxDetails(creditTaxDetails);

        MtxRequestSubscriberPurchaseOfferBuilder spob = (new MtxRequestSubscriberPurchaseOfferBuilder()).withSubscriberExternalId(
                input.getGifteeExternalId()).withOfferData(pob.build());

        MtxRequestSubscriberPurchaseOffer po = spob.build();

        INFO(
                m_logger,
                methodKey + "Add MtxRequestSubscriberPurchaseOffer request to enroll in new offer: "
                        + po.toJson());
        multiReqGiftService.appendRequestList(po);

        // Set API Event Data
        if (input.getApiEventData() != null) {
            VisibleApiEventData aed = (VisibleApiEventData) input.getApiEventData();
            aed.setGifterGlobalKey(input.getGifterExternalId());
            multiReqGiftService.setApiEventData(aed);
        } else {
            VisibleApiEventData apiEveDa = new VisibleApiEventData();
            apiEveDa.setGifterGlobalKey(input.getGifterExternalId());
            multiReqGiftService.setApiEventData(apiEveDa);
        }

        // Send the multi-request to MATRIXX and receive the multi-response
        MtxResponseMulti multiRespGiftService = multiRequest(
                loggingKey, route, multiReqGiftService);

        // Revert the Charge Amount to original value
        if (isChrgAmntUpdated) {
            MtxRequestMulti multiReqModify = new MtxRequestMulti();
            multiReqModify.setApiEventData(input.getApiEventData());
            restoreOfferPrice(loggingKey, multiReqModify, multiRespGiftService, input, taxDetails);
            MtxResponseMulti multiRespModify = multiRequest(loggingKey, route, multiReqModify);
        }

        if (multiRespGiftService == null
                || multiRespGiftService.getResult() != Constants.RESULT_CODES.MTX_SUCCESS) {
            Long resultCode = multiRespGiftService != null
                    ? multiRespGiftService.getResult()
                    : Constants.RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR;
            String message = "Failed to gift service" + (multiRespGiftService != null
                    ? " - " + multiRespGiftService.getResultText() : "");
            WARN(m_logger, loggingKey + message);
            throw new GiftServiceException(resultCode, message);
        }

        // Prepare the API response
        output.setGifterExternalId(input.getGifterExternalId());
        output.setGifteeExternalId(input.getGifteeExternalId());
        output.setGiftAmount(giftAmount);
        output.setResult(multiRespGiftService.getResult());
        output.setResultText(multiRespGiftService.getResultText());
    }

    // The function calculates Charge amount in case of promotions
    private BigDecimal calculateChargeAmount(String taxDetails,
                                             String creditTaxDetails,
                                             String loggingKey)
            throws ConfigurationException, IOException {
        final String methodKey = loggingKey + " calculateChargeAmount: ";
        BigDecimal serviceTaxChrgAmount;
        BigDecimal creditTaxChrgAmount;
        BigDecimal chargeAmount = BigDecimal.ZERO;
        ServiceTaxResponse taxResponse = CommonUtils.getServiceTaxResponseFromJsonString(
                taxDetails);
        ServiceTaxResponse creditTaxResponse = CommonUtils.getServiceTaxResponseFromJsonString(
                creditTaxDetails);

        serviceTaxChrgAmount = taxResponse.getDiscountPrice();
        creditTaxChrgAmount = creditTaxResponse.getDiscountPrice();

        if (serviceTaxChrgAmount.compareTo(creditTaxChrgAmount) == 1) {
            chargeAmount = serviceTaxChrgAmount.subtract(creditTaxChrgAmount);
        }

        return chargeAmount;
    }

    // The function aims to set the discount price to its original value after gifting is completed
    private void restoreOfferPrice(String loggingKey,
                                   MtxRequestMulti multiReqModify,
                                   MtxResponseMulti multiReqGiftService,
                                   VisibleRequestGiftService input,
                                   String taxDetails)
            throws GiftServiceException, ConfigurationException, IOException {

        long resourceId = -1;
        ServiceTaxResponse taxResponse = CommonUtils.getServiceTaxResponseFromJsonString(
                taxDetails);

        for (MtxResponse resp : multiReqGiftService.getResponseList()) {
            if (resp instanceof MtxResponsePurchase) {
                MtxResponsePurchase purchaseResp = (MtxResponsePurchase) resp;
                for (MtxPurchaseInfo pi : purchaseResp.getPurchaseInfoArray()) {
                    if (StringUtils.isNotBlank(pi.getCatalogItemExternalId())
                            && input.getGiftingServiceInfo().getCatalogItemExternalId().equalsIgnoreCase(
                                    pi.getCatalogItemExternalId())) {
                        resourceId = pi.getResourceId();
                        break;
                    }
                }
            }
            if (resourceId >= 0) {
                break;
            }
        }
        if (resourceId < 0) {
            throw new GiftServiceException(
                    Constants.RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,
                    "ResourceId of the newly purchased offer could not be located.");
        }

        MtxRequestSubscriberModifyOfferBuilder mob = (new MtxRequestSubscriberModifyOfferBuilder()).withResourceId(
                resourceId).withSubscriberExternalId(input.getGifteeExternalId()).withChargeAmount(
                        taxResponse.getDiscountPrice());

        MtxRequestSubscriberModifyOffer modOffer = mob.build();
        INFO(
                m_logger,
                loggingKey
                        + "Add MtxRequestSubscriberModifyOffer request to restore Price of Newly Purchased Offer: "
                        + modOffer.toJson());

        multiReqModify.appendRequestList(modOffer);
    }

}
