package com.matrixx.vag.exception;

/**
 * Exception thrown upon encountering an error with processing subscriber offers.
 *
 * @author unico
 */
public class DeviceServiceException extends IntegrationServiceException {

    private static final long serialVersionUID = 6166519745348508177L;

    public DeviceServiceException(Long resultCode, String message) {
        super(resultCode, message);
    }
}
