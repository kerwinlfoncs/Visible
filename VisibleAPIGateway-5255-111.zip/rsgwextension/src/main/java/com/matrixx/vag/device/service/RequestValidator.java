package com.matrixx.vag.device.service;

import com.matrixx.datacontainer.MtxPhone;
import com.matrixx.datacontainer.mdc.*;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.exception.InvalidRequestException;
import com.matrixx.vag.exception.InvalidRequestParameterException;
import com.matrixx.vag.exception.MissingRequestParametersException;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import static com.matrixx.platform.LogUtils.DEBUG;

/**
 * Validate incoming requests.
 *
 * @author unico
 */
public class RequestValidator {

    public final static String DATE_FORMAT = "yyyy-MM-dd";

    private static final Logger m_logger = LoggerFactory.getLogger(RequestValidator.class);

    /**
     * Validate the purchase device request.
     *
     * @param request
     * @throws InvalidRequestException
     */
    void validateRequest(String loggingKey, VisibleRequestPurchaseDevice request)
            throws InvalidRequestException {

        DEBUG(m_logger, loggingKey + "Validating device purchase request");

        String missingMandatoryParamName = null;
        if (StringUtils.isEmpty(request.getSubscriberExternalId())) {
            missingMandatoryParamName = "SubscriberExternalId";

        } else if (request.getPurchaseOrderInfo() == null) {
            missingMandatoryParamName = "PurchaseOrderInfo";
        } else if (StringUtils.isEmpty(request.getPurchaseOrderInfo().getOrderId())) {
            missingMandatoryParamName = "PurchaseOrderInfo.OrderId";
        } else if (StringUtils.isEmpty(request.getPurchaseOrderInfo().getPaymentMethod())) {
            missingMandatoryParamName = "PurchaseOrderInfo.PaymentMethod";
        } else if (request.getPurchaseDeviceInfo() == null) {
            missingMandatoryParamName = "PurchaseDeviceInfo";
        } else if (StringUtils.isEmpty(request.getPurchaseDeviceInfo().getDeviceSku())) {
            missingMandatoryParamName = "PurchaseDeviceInfo.DeviceSku";
        } else if (StringUtils.isEmpty(
                request.getPurchaseDeviceInfo().getDeviceOfferExternalId())) {
            missingMandatoryParamName = "PurchaseDeviceInfo.DeviceOfferExternalId";
            // } else if
            // (StringUtils.isEmpty(request.getPurchaseDeviceInfo().getDeviceGrossPrice())) {
            // missingMandatoryParamName = "PurchaseDeviceInfo.DeviceGrossPrice";
        } else if (StringUtils.isEmpty(request.getPurchaseDeviceInfo().getDeviceDiscountPrice())) {
            missingMandatoryParamName = "PurchaseDeviceInfo.DeviceDiscountPrice";
            // } else if (StringUtils.isEmpty(request.getPurchaseDeviceInfo().getDeviceTotalTax()))
            // { missingMandatoryParamName = "PurchaseDeviceInfo.DeviceTotalTax";
        } else if (StringUtils.isEmpty(request.getPurchaseDeviceInfo().getDeviceTaxDetails())) {
            missingMandatoryParamName = "PurchaseDeviceInfo.DeviceTaxDetails";
        } else if (StringUtils.isEmpty(
                request.getPurchaseDeviceInfo().getDeviceProvidesService())) {
            missingMandatoryParamName = "PurchaseDeviceInfo.DeviceProvidesService";
        } else if (StringUtils.isEmpty(request.getPurchaseDeviceInfo().getDeviceDetails())) {
            missingMandatoryParamName = "PurchaseDeviceInfo.DeviceDetails";

        } else if (request.getPurchaseShippingInfo() == null) {
            missingMandatoryParamName = "PurchaseShippingInfo";
        } else if (StringUtils.isEmpty(request.getPurchaseShippingInfo().getShippingSku())) {
            missingMandatoryParamName = "PurchaseShippingInfo.ShippingSku";
            // } else if
            // (StringUtils.isEmpty(request.getPurchaseShippingInfo().getShippingGeocode())) {
            // missingMandatoryParamName = "PurchaseShippingInfo.ShippingGeocode";
        } else if (StringUtils.isEmpty(request.getPurchaseShippingInfo().getShipToBid())) {
            missingMandatoryParamName = "PurchaseShippingInfo.ShipToBid";
        } else if (StringUtils.isEmpty(
                request.getPurchaseShippingInfo().getShippingOfferExternalId())) {
            missingMandatoryParamName = "PurchaseShippingInfo.ShippingOfferExternalId";
            // } else if
            // (StringUtils.isEmpty(request.getPurchaseShippingInfo().getShippingGrossPrice())) {
            // missingMandatoryParamName = "PurchaseShippingInfo.ShippingGrossPrice";
        } else if (StringUtils.isEmpty(
                request.getPurchaseShippingInfo().getShippingDiscountPrice())) {
            missingMandatoryParamName = "PurchaseShippingInfo.ShippingDiscountPrice";
            // } else if
            // (StringUtils.isEmpty(request.getPurchaseShippingInfo().getShippingTotalTax())) {
            // missingMandatoryParamName = "PurchaseShippingInfo.ShippingTotalTax";
        } else if (StringUtils.isEmpty(request.getPurchaseShippingInfo().getShippingTaxDetails())) {
            missingMandatoryParamName = "PurchaseShippingInfo.ShippingTaxDetails";
        } else {
            if (request.getPurchaseFraudInfo() != null) {

                if (request.getPurchaseFraudInfo().getFraudHomeAddress() == null) {
                    missingMandatoryParamName = "PurchaseFraudInfo.FraudHomeAddress";
                } else if (request.getPurchaseFraudInfo().getFraudShippingAddress() == null) {
                    missingMandatoryParamName = "PurchaseFraudInfo.FraudShippingAddress";
                } else if (request.getPurchaseFraudInfo().getTransactionType() == null) {
                    missingMandatoryParamName = "PurchaseFraudInfo.TransactionType";
                }
            }
            // Validate the device purchase price
            try {
                new BigDecimal(request.getPurchaseDeviceInfo().getDeviceDiscountPrice());
            } catch (NumberFormatException e) {
                throw new InvalidRequestException(
                		RESULT_CODES.RESULT_CODE_CUSTOM_INVALID_REQUEST_PARAMETERS,
                        "Invalid value specified for parameter: PurchaseDeviceInfo.DeviceDiscountPrice - "
                                + e.getMessage());
            }

            // Validate the shipping cost
            try {
                new BigDecimal(request.getPurchaseShippingInfo().getShippingDiscountPrice());
            } catch (NumberFormatException e) {
                throw new InvalidRequestException(
                		RESULT_CODES.RESULT_CODE_CUSTOM_INVALID_REQUEST_PARAMETERS,
                        "Invalid value specified for parameter: PurchaseShippingInfo.ShippingDiscountPrice - "
                                + e.getMessage());
            }

            if (StringUtils.isNotEmpty(request.getPurchaseOrderInfo().getDeferredSettlement())) {
                if (!request.getPurchaseOrderInfo().getDeferredSettlement().equals("Y")
                        && !request.getPurchaseOrderInfo().getDeferredSettlement().equals("N")) {
                    throw new InvalidRequestException(
                    		RESULT_CODES.RESULT_CODE_CUSTOM_INVALID_REQUEST_PARAMETERS,
                            "Invalid value specified for parameter: PurchaseOrderInfo.DeferredSettlement");
                }
                if (request.getPurchaseOrderInfo().getDeferredSettlementTimeout() == null) {
                    DEBUG(
                            m_logger, loggingKey
                                    + "Payment settlement timeout is not set. System default will be used");
                } else {
                    if (request.getPurchaseOrderInfo().getDeferredSettlementTimeout() <= 0) {
                        throw new InvalidRequestException(
                        		RESULT_CODES.RESULT_CODE_CUSTOM_INVALID_REQUEST_PARAMETERS,
                                "Invalid value specified for parameter: PurchaseOrderInfo.DeferredSettlementTimeout");
                    }
                }

                if (request.getPurchaseOrderInfo().getDeferredSettlementTimeoutAction() == null) {
                    DEBUG(
                            m_logger, loggingKey
                                    + "Payment settlement timeout action is not set. System default will be used");
                } else {
                    if (request.getPurchaseOrderInfo().getDeferredSettlementTimeoutAction() != 1
                            && request.getPurchaseOrderInfo().getDeferredSettlementTimeoutAction() != 2) {
                        throw new InvalidRequestException(
                        		RESULT_CODES.RESULT_CODE_CUSTOM_INVALID_REQUEST_PARAMETERS,
                                "Invalid value specified for parameter: PurchaseOrderInfo.DeferredSettlementTimeoutAction");
                    }
                }
            }
            // Validate the device access number and IMSI if present (will not be present for
            // non-service providing devices)
            try {
                // Determine the device type
                DeviceType deviceType = DeviceType.valueOf(
                        request.getPurchaseDeviceInfo().getDeviceProvidesService());

                if (deviceType == DeviceType.sp) {
                    // Validate the device access number
                    if (StringUtils.isEmpty(
                            request.getPurchaseDeviceInfo().getDeviceAccessNumber())) {
                        throw new InvalidRequestException(
                        		RESULT_CODES.RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS,
                                "PurchaseDeviceInfo.DeviceAccessNumber must be specified for service providing device");
                    } else {
                        try {
                            new MtxPhone(request.getPurchaseDeviceInfo().getDeviceAccessNumber());
                        } catch (Exception e) {
                            throw new InvalidRequestException(
                            		RESULT_CODES.RESULT_CODE_CUSTOM_INVALID_REQUEST_PARAMETERS,
                                    "Invalid value specified for parameter: PurchaseDeviceInfo.DeviceAccessNumber - "
                                            + e.getMessage());
                        }
                    }

                    // Validate the IMSI
                    if (StringUtils.isEmpty(request.getPurchaseDeviceInfo().getDeviceIMSI())) {
                        throw new InvalidRequestException(
                        		RESULT_CODES.RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS,
                                "PurchaseDeviceInfo.DeviceIMSI must be specified for service providing device");
                    } else {
                        try {
                            new MtxPhone(request.getPurchaseDeviceInfo().getDeviceIMSI());
                        } catch (Exception e) {
                            throw new InvalidRequestException(
                            		RESULT_CODES.RESULT_CODE_CUSTOM_INVALID_REQUEST_PARAMETERS,
                                    "Invalid value specified for parameter: PurchaseDeviceInfo.DeviceIMSI - "
                                            + e.getMessage());
                        }
                    }
                }
            } catch (IllegalArgumentException e) {
                throw new InvalidRequestException(
                		RESULT_CODES.RESULT_CODE_CUSTOM_INVALID_REQUEST_PARAMETERS,
                        "Invalid value specified for parameter: PurchaseDeviceInfo.DeviceProvidesService - "
                                + e.getMessage());
            }
        }

        if (missingMandatoryParamName != null) {
            throw new InvalidRequestException(
            		RESULT_CODES.RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS,
                    "Missing mandatory parameter: " + missingMandatoryParamName);
        }
    }

    /**
     * Validate the return purchased device request.
     *
     * @param request
     * @throws InvalidRequestException
     */
    void validateRequest(String loggingKey, VisibleRequestReturnPurchasedDevice request)
            throws InvalidRequestException {

        DEBUG(m_logger, loggingKey + "Validating return purchased device request");

        String missingMandatoryParamName = null;
        if (StringUtils.isEmpty(request.getSubscriberExternalId())) {
            missingMandatoryParamName = "SubscriberExternalId";

        } else if (request.getReturnPurchaseOrderInfo() == null) {
            missingMandatoryParamName = "ReturnPurchaseOrderInfo";
        } else if (StringUtils.isEmpty(request.getReturnPurchaseOrderInfo().getReturnOrderId())) {
            missingMandatoryParamName = "ReturnPurchaseOrderInfo.ReturnOrderId";
        } else if (   ArrayUtils.isEmpty(request.getReturnPurchaseOrderInfo().getOriginalOrderIds().toArray())        		   
        		   || StringUtils.isBlank(request.getReturnPurchaseOrderInfo().getOriginalOrderIds().get(0))) {
            missingMandatoryParamName = "ReturnPurchaseOrderInfo.OriginalOrderIds";
        } else if (StringUtils.isEmpty(
                request.getReturnPurchaseOrderInfo().getOriginalOrderDate())) {
            missingMandatoryParamName = "ReturnPurchaseOrderInfo.OriginalOrderDate";
        } /*else if (StringUtils.isEmpty(
                request.getReturnPurchaseOrderInfo().getDeviceProvidesService())) {
            missingMandatoryParamName = "ReturnPurchaseOrderInfo.DeviceProvidesService";
        }*/ else {
            // Validate the original order date
            DateFormat dtf = new SimpleDateFormat(DATE_FORMAT);
            try {
                dtf.parse(request.getReturnPurchaseOrderInfo().getOriginalOrderDate());
            } catch (ParseException e) {
                throw new InvalidRequestException(
                		RESULT_CODES.RESULT_CODE_CUSTOM_INVALID_REQUEST_PARAMETERS,
                        "Invalid value specified for parameter: ReturnPurchaseOrderInfo.OriginalOrderDate - "
                                + e.getMessage());
            }

            // Validate the device instance ID if present (will not be present for non-service
            // providing devices)
            /*try {
                // Determine the device type
                DeviceType deviceType = DeviceType.valueOf(
                        request.getReturnPurchaseOrderInfo().getDeviceProvidesService());

                if (deviceType == DeviceType.sp) {
                    // Validate the device instance ID
                    if (StringUtils.isEmpty(
                            request.getReturnPurchaseOrderInfo().getDeviceInstanceId())) {
                        throw new InvalidRequestException(
                                IntegrationService.RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS,
                                "ReturnPurchaseOrderInfo.DeviceInstanceId must be specified for service providing device");
                    }
                }
            } catch (IllegalArgumentException e) {
                throw new InvalidRequestException(
                        IntegrationService.RESULT_CODE_CUSTOM_INVALID_REQUEST_PARAMETERS,
                        "Invalid value specified for parameter: ReturnPurchaseOrderInfo.DeviceProvidesService - "
                                + e.getMessage());
            }*/
        }

        if (missingMandatoryParamName != null) {
            throw new InvalidRequestException(
            		RESULT_CODES.RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS,
                    "Missing mandatory parameter: " + missingMandatoryParamName);
        }
    }

    /**
     * Validate the finance device request.
     *
     * @param request
     * @throws InvalidRequestException
     */
    void validateRequest(String loggingKey, VisibleRequestFinanceDevice request)
            throws InvalidRequestException {

        DEBUG(m_logger, loggingKey + "Validating device finance request");

        String missingMandatoryParamName = null;
        if (StringUtils.isEmpty(request.getSubscriberExternalId())) {
            missingMandatoryParamName = "SubscriberExternalId";

        } else if (request.getFinanceOrderInfo() == null) {
            missingMandatoryParamName = "FinanceOrderInfo";
        } else if (StringUtils.isEmpty(request.getFinanceOrderInfo().getOrderId())) {
            missingMandatoryParamName = "FinanceOrderInfo.OrderId";
        } else if (StringUtils.isEmpty(request.getFinanceOrderInfo().getChargeId())) {
            missingMandatoryParamName = "FinanceOrderInfo.ChargeId";

        } else if (request.getFinanceDeviceInfo() == null) {
            missingMandatoryParamName = "FinanceDeviceInfo";
        } else if (StringUtils.isEmpty(request.getFinanceDeviceInfo().getDeviceSku())) {
            missingMandatoryParamName = "FinanceDeviceInfo.DeviceSku";
        } else if (StringUtils.isEmpty(request.getFinanceDeviceInfo().getDeviceOfferExternalId())) {
            missingMandatoryParamName = "FinanceDeviceInfo.DeviceOfferExternalId";
            // } else if
            // (StringUtils.isEmpty(request.getFinanceDeviceInfo().getDeviceGrossPrice())) {
            // missingMandatoryParamName = "FinanceDeviceInfo.DeviceGrossPrice";
        } else if (StringUtils.isEmpty(request.getFinanceDeviceInfo().getDeviceDiscountPrice())) {
            missingMandatoryParamName = "FinanceDeviceInfo.DeviceDiscountPrice";
        } else if (StringUtils.isEmpty(request.getFinanceDeviceInfo().getDeviceFinanceAmount())) {
            missingMandatoryParamName = "FinanceDeviceInfo.DeviceFinanceAmount";
            // } else if (StringUtils.isEmpty(request.getFinanceDeviceInfo().getDeviceTotalTax()))
            // { missingMandatoryParamName = "FinanceDeviceInfo.DeviceTotalTax";
        } else if (StringUtils.isEmpty(request.getFinanceDeviceInfo().getDeviceTaxDetails())) {
            missingMandatoryParamName = "FinanceDeviceInfo.DeviceTaxDetails";
        } else if (StringUtils.isEmpty(request.getFinanceDeviceInfo().getDeviceProvidesService())) {
            missingMandatoryParamName = "FinanceDeviceInfo.DeviceProvidesService";
        } else if (StringUtils.isEmpty(request.getFinanceDeviceInfo().getDeviceDetails())) {
            missingMandatoryParamName = "FinanceDeviceInfo.DeviceDetails";

        } else if (request.getFinanceShippingInfo() == null) {
            missingMandatoryParamName = "FinanceShippingInfo";
        } else if (StringUtils.isEmpty(request.getFinanceShippingInfo().getShippingSku())) {
            missingMandatoryParamName = "FinanceShippingInfo.ShippingSku";
            // } else if
            // (StringUtils.isEmpty(request.getFinanceShippingInfo().getShippingGeocode())) {
            // missingMandatoryParamName = "FinanceShippingInfo.ShippingGeocode";
        } else if (StringUtils.isEmpty(request.getFinanceShippingInfo().getShipToBid())) {
            missingMandatoryParamName = "FinanceShippingInfo.ShipToBid";
        } else if (StringUtils.isEmpty(
                request.getFinanceShippingInfo().getShippingOfferExternalId())) {
            missingMandatoryParamName = "FinanceShippingInfo.ShippingOfferExternalId";
            // } else if
            // (StringUtils.isEmpty(request.getFinanceShippingInfo().getShippingGrossPrice())) {
            // missingMandatoryParamName = "FinanceShippingInfo.ShippingGrossPrice";
        } else if (StringUtils.isEmpty(
                request.getFinanceShippingInfo().getShippingDiscountPrice())) {
            missingMandatoryParamName = "FinanceShippingInfo.ShippingDiscountPrice";
            // } else if
            // (StringUtils.isEmpty(request.getFinanceShippingInfo().getShippingTotalTax())) {
            // missingMandatoryParamName = "FinanceShippingInfo.ShippingTotalTax";
        } else if (StringUtils.isEmpty(request.getFinanceShippingInfo().getShippingTaxDetails())) {
            missingMandatoryParamName = "FinanceShippingInfo.ShippingTaxDetails";

        } else {
            // Validate the device purchase price
            try {
                new BigDecimal(request.getFinanceDeviceInfo().getDeviceDiscountPrice());
            } catch (NumberFormatException e) {
                throw new InvalidRequestException(
                		RESULT_CODES.RESULT_CODE_CUSTOM_INVALID_REQUEST_PARAMETERS,
                        "Invalid value specified for parameter: FinanceDeviceInfo.DeviceDiscountPrice - "
                                + e.getMessage());
            }

            // Validate the device finance fee
            try {
                new BigDecimal(request.getFinanceDeviceInfo().getDeviceFinanceAmount());
            } catch (NumberFormatException e) {
                throw new InvalidRequestException(
                		RESULT_CODES.RESULT_CODE_CUSTOM_INVALID_REQUEST_PARAMETERS,
                        "Invalid value specified for parameter: FinanceDeviceInfo.DeviceFinanceAmount - "
                                + e.getMessage());
            }

            // Validate the shipping cost
            try {
                new BigDecimal(request.getFinanceShippingInfo().getShippingDiscountPrice());
            } catch (NumberFormatException e) {
                throw new InvalidRequestException(
                		RESULT_CODES.RESULT_CODE_CUSTOM_INVALID_REQUEST_PARAMETERS,
                        "Invalid value specified for parameter: FinanceShippingInfo.ShippingDiscountPrice - "
                                + e.getMessage());
            }

            // Validate the device access number and IMSI if present (will not be present for
            // non-service providing devices)
            try {
                // Determine the device type
                DeviceType deviceType = DeviceType.valueOf(
                        request.getFinanceDeviceInfo().getDeviceProvidesService());

                if (deviceType == DeviceType.sp) {
                    // Validate the device access number
                    if (StringUtils.isEmpty(
                            request.getFinanceDeviceInfo().getDeviceAccessNumber())) {
                        throw new InvalidRequestException(
                        		RESULT_CODES.RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS,
                                "FinanceDeviceInfo.DeviceAccessNumber must be specified for service providing device");
                    } else {
                        try {
                            new MtxPhone(request.getFinanceDeviceInfo().getDeviceAccessNumber());
                        } catch (Exception e) {
                            throw new InvalidRequestException(
                            		RESULT_CODES.RESULT_CODE_CUSTOM_INVALID_REQUEST_PARAMETERS,
                                    "Invalid value specified for parameter: FinanceDeviceInfo.DeviceAccessNumber - "
                                            + e.getMessage());
                        }
                    }

                    // Validate the IMSI
                    if (StringUtils.isEmpty(request.getFinanceDeviceInfo().getDeviceIMSI())) {
                        throw new InvalidRequestException(
                        		RESULT_CODES.RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS,
                                "FinanceDeviceInfo.DeviceIMSI must be specified for service providing device");
                    } else {
                        try {
                            new MtxPhone(request.getFinanceDeviceInfo().getDeviceIMSI());
                        } catch (Exception e) {
                            throw new InvalidRequestException(
                            		RESULT_CODES.RESULT_CODE_CUSTOM_INVALID_REQUEST_PARAMETERS,
                                    "Invalid value specified for parameter: FinanceDeviceInfo.DeviceIMSI - "
                                            + e.getMessage());
                        }
                    }
                }
            } catch (IllegalArgumentException e) {
                throw new InvalidRequestException(
                		RESULT_CODES.RESULT_CODE_CUSTOM_INVALID_REQUEST_PARAMETERS,
                        "Invalid value specified for parameter: FinanceDeviceInfo.DeviceProvidesService - "
                                + e.getMessage());
            }
        }

        if (missingMandatoryParamName != null) {
            throw new InvalidRequestException(
            		RESULT_CODES.RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS,
                    "Missing mandatory parameter: " + missingMandatoryParamName);
        }
    }

    /**
     * Validate the return financed device request.
     *
     * @param request
     * @throws InvalidRequestException
     */
    void validateRequest(String loggingKey, VisibleRequestReturnFinancedDevice request)
            throws InvalidRequestException {

        DEBUG(m_logger, loggingKey + "Validating return purchased device request");

        String missingMandatoryParamName = null;
        if (StringUtils.isEmpty(request.getSubscriberExternalId())) {
            missingMandatoryParamName = "SubscriberExternalId";

        } else if (request.getReturnFinanceOrderInfo() == null) {
            missingMandatoryParamName = "ReturnFinanceOrderInfo";
        } else if (StringUtils.isEmpty(request.getReturnFinanceOrderInfo().getReturnOrderId())) {
            missingMandatoryParamName = "ReturnFinanceOrderInfo.ReturnOrderId";
        } else if (StringUtils.isEmpty(request.getReturnFinanceOrderInfo().getOriginalOrderId())) {
            missingMandatoryParamName = "ReturnFinanceOrderInfo.OriginalOrderId";
        } else if (StringUtils.isEmpty(
                request.getReturnFinanceOrderInfo().getOriginalOrderDate())) {
            missingMandatoryParamName = "ReturnFinanceOrderInfo.OriginalOrderDate";
        } else if (StringUtils.isEmpty(request.getReturnFinanceOrderInfo().getChargeId())) {
            missingMandatoryParamName = "ReturnFinanceOrderInfo.ChargeId";
        } else if (StringUtils.isEmpty(
                request.getReturnFinanceOrderInfo().getDeviceProvidesService())) {
            missingMandatoryParamName = "ReturnFinanceOrderInfo.DeviceProvidesService";
        } else {
            // Validate the original order date
            DateFormat dtf = new SimpleDateFormat(DATE_FORMAT);
            try {
                dtf.parse(request.getReturnFinanceOrderInfo().getOriginalOrderDate());
            } catch (ParseException e) {
                throw new InvalidRequestException(
                		RESULT_CODES.RESULT_CODE_CUSTOM_INVALID_REQUEST_PARAMETERS,
                        "Invalid value specified for parameter: ReturnFinanceOrderInfo.OriginalOrderDate - "
                                + e.getMessage());
            }

            // Validate the device instance ID if present (will not be present for non-service
            // providing devices)
            try {
                // Determine the device type
                DeviceType deviceType = DeviceType.valueOf(
                        request.getReturnFinanceOrderInfo().getDeviceProvidesService());

                if (deviceType == DeviceType.sp) {
                    // Validate the device instance ID
                    if (StringUtils.isEmpty(
                            request.getReturnFinanceOrderInfo().getDeviceInstanceId())) {
                        throw new InvalidRequestException(
                        		RESULT_CODES.RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS,
                                "ReturnFinanceOrderInfo.DeviceInstanceId must be specified for service providing device");
                    }
                }
            } catch (IllegalArgumentException e) {
                throw new InvalidRequestException(
                		RESULT_CODES.RESULT_CODE_CUSTOM_INVALID_REQUEST_PARAMETERS,
                        "Invalid value specified for parameter: ReturnFinanceOrderInfo.DeviceProvidesService - "
                                + e.getMessage());
            }
        }

        if (missingMandatoryParamName != null) {
            throw new InvalidRequestException(
            		RESULT_CODES.RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS,
                    "Missing mandatory parameter: " + missingMandatoryParamName);
        }
    }

    static public void validateBigDecimalValue(String field, String value)
            throws InvalidRequestParameterException {
        try {
            new BigDecimal(value);
        } catch (NumberFormatException e) {
            StringBuilder message = new StringBuilder();
            message.append("Invalid value specified for parameter: ").append(field).append(
                    " - ").append(e.getMessage());
            throw new InvalidRequestParameterException(message.toString());
        }
    }

    static public void validateRequest(String loggingKey, VisibleRequestDeviceSwap request)
            throws InvalidRequestException {

        DEBUG(m_logger, loggingKey + "Validating device swap request");
        String missingMandatoryParamName = null;

        // Validating mandatory fields
        if (StringUtils.isEmpty(request.getSubscriberExternalId())) {
            missingMandatoryParamName = "SubscriberExternalId";
        } else if (request.getPurchaseOrderInfo() == null) {
            missingMandatoryParamName = "PurchaseOrderInfo";
        } else if (StringUtils.isEmpty(request.getPurchaseOrderInfo().getOrderId())) {
            missingMandatoryParamName = "PurchaseOrderInfo.OrderId";
        } else if (request.getDeviceSwapInfo() == null) {
            missingMandatoryParamName = "DeviceSwapInfo";
        } else if (StringUtils.isEmpty(request.getDeviceSwapInfo().getNewDeviceSku())) {
            missingMandatoryParamName = "DeviceSwapInfo.NewDeviceSku";
        } else if (StringUtils.isEmpty(
                request.getDeviceSwapInfo().getDeviceSwapOfferExternalId())) {
            missingMandatoryParamName = "DeviceSwapInfo.DeviceSwapOfferExternalId";
        } else if (StringUtils.isEmpty(request.getDeviceSwapInfo().getNewDeviceCOGS())) {
            missingMandatoryParamName = "DeviceSwapInfo.NewDeviceCOGS";
        } else if (StringUtils.isEmpty(request.getDeviceSwapInfo().getRecurringServiceCharge())) {
            missingMandatoryParamName = "DeviceSwapInfo.RecurringServiceCharge";
        } else if (StringUtils.isEmpty(request.getDeviceSwapInfo().getNewDeviceTaxDetails())) {
            missingMandatoryParamName = "DeviceSwapInfo.NewDeviceTaxDetails";
        } else if (StringUtils.isEmpty(request.getDeviceSwapInfo().getNewDeviceDetails())) {
            missingMandatoryParamName = "DeviceSwapInfo.NewDeviceDetails";
        } else if (StringUtils.isEmpty(
                request.getDeviceSwapInfo().getSwappedDeviceResidualValue())) {
            missingMandatoryParamName = "DeviceSwapInfo.SwappedDeviceResidualValue";
        } else if (request.getDeviceSwapShippingInfo() == null) {
            missingMandatoryParamName = "DeviceSwapShippingInfo";
        } else if (StringUtils.isEmpty(request.getDeviceSwapShippingInfo().getShipToBid())) {
            missingMandatoryParamName = "DeviceSwapShippingInfo.ShipToBid";
        }
        // validating the values:
        else {
            validateBigDecimalValue(
                    "DeviceSwapInfo.RecurringServiceCharge",
                    request.getDeviceSwapInfo().getRecurringServiceCharge());
            validateBigDecimalValue(
                    "DeviceSwapInfo.SwappedDeviceResidualValue",
                    request.getDeviceSwapInfo().getSwappedDeviceResidualValue());
            validateBigDecimalValue(
                    "DeviceSwapInfo.NewDeviceCOGS", request.getDeviceSwapInfo().getNewDeviceCOGS());
        }

        if (missingMandatoryParamName != null) {
            throw new MissingRequestParametersException(
                    "Missing mandatory parameter: " + missingMandatoryParamName);
        }
    }

    void validateRequest(String loggingKey, VisibleRequestCancelDeviceSwap request)
            throws InvalidRequestException {

        DEBUG(m_logger, loggingKey + "Validating cancel device swap request");

        String missingMandatoryParamName = null;
        if (StringUtils.isEmpty(request.getSubscriberExternalId())) {
            missingMandatoryParamName = "SubscriberExternalId";
        } else if (request.getCancelDeviceSwapOrderInfo() == null) {
            missingMandatoryParamName = "CancelDeviceSwapOrderInfo";
        } else if (StringUtils.isEmpty(request.getCancelDeviceSwapOrderInfo().getReturnOrderId())) {
            missingMandatoryParamName = "CancelDeviceSwapOrderInfo.ReturnOrderId";
        } else if (StringUtils.isEmpty(
                request.getCancelDeviceSwapOrderInfo().getOriginalOrderId())) {
            missingMandatoryParamName = "CancelDeviceSwapOrderInfo.OriginalOrderId";
        } else if (StringUtils.isEmpty(
                request.getCancelDeviceSwapOrderInfo().getDeviceSwapOfferExternalId())) {
            missingMandatoryParamName = "CancelDeviceSwapOrderInfo.DeviceSwapOfferExternalId";

        } else if (!StringUtils.isEmpty(
                request.getCancelDeviceSwapOrderInfo().getOriginalOrderDate())) {
            DateFormat dtf = new SimpleDateFormat(DATE_FORMAT);

            try {
                dtf.parse(request.getCancelDeviceSwapOrderInfo().getOriginalOrderDate());
            } catch (ParseException e) {
                throw new InvalidRequestException(
                		RESULT_CODES.RESULT_CODE_CUSTOM_INVALID_REQUEST_PARAMETERS,
                        "Invalid value specified for parameter: VisibleRequestCancelDeviceSwap.CancelDeviceSwapOrderInfo.OriginalOrderDate - "
                                + e.getMessage());
            }
        }

        if (missingMandatoryParamName != null) {
            throw new InvalidRequestException(
            		RESULT_CODES.RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS,
                    "Missing mandatory parameter: " + missingMandatoryParamName);
        }
    }

    /**
     * Validate the charge Nrf request
     *
     * @param request
     * @throws InvalidRequestException
     */
    void validateRequest(String loggingKey, VisibleRequestChargeNrf request)
            throws InvalidRequestException {

        DEBUG(m_logger, loggingKey + "Validating device Charge Nrf request");
        String missingMandatoryParamName = null;
        if (StringUtils.isEmpty(request.getSubscriberExternalId())) {
            missingMandatoryParamName = "SubscriberExternalId";
        } else if (request.getNrfOrderInfo() == null) {
            missingMandatoryParamName = "NrfOrderInfo";
        } else if (StringUtils.isEmpty(request.getNrfOrderInfo().getOrderId())) {
            missingMandatoryParamName = "NrfOrderInfo.OrderId";
        } else if (StringUtils.isEmpty(request.getNrfOrderInfo().getPaymentMethod())) {
            missingMandatoryParamName = "NrfOrderInfo.PaymentMethod";

        } else if (request.getNrfOfferInfo() == null) {
            missingMandatoryParamName = "NrfOfferInfo";
        } else if (StringUtils.isEmpty(request.getNrfOfferInfo().getOfferSku())) {
            missingMandatoryParamName = "NrfOfferInfo.OfferSku";
        } else if (StringUtils.isEmpty(request.getNrfOfferInfo().getOfferExternalId())) {
            missingMandatoryParamName = "NrfOfferInfo.OfferExternalId()";
        } else if (StringUtils.isEmpty(request.getNrfOfferInfo().getOfferDiscountPrice())) {
            missingMandatoryParamName = "NrfOfferInfo.OfferDiscountPrice()";
        } else if (StringUtils.isEmpty(request.getNrfOfferInfo().getOfferTaxDetails())) {
            missingMandatoryParamName = "NrfOfferInfo.OfferTaxDetails";
        } else if (StringUtils.isEmpty(request.getNrfOfferInfo().getOfferTotalTax())) {
            missingMandatoryParamName = "NrfOfferInfo.OfferTotalTax";
        } else if (StringUtils.isEmpty(request.getNrfOfferInfo().getOfferDetails())) {
            missingMandatoryParamName = "NrfOfferInfo.OfferDetails";
        } else if (request.getNrfShippingInfo() == null) {
            missingMandatoryParamName = "NrfShippingInfo";
        } else if (StringUtils.isEmpty(request.getNrfShippingInfo().getShipToBid())) {
            missingMandatoryParamName = "NrfShippingInfo.ShipToBid";
        } else {
            if (request.getNrfFraudInfo() != null) {

                if (request.getNrfFraudInfo().getFraudHomeAddress() == null) {
                    missingMandatoryParamName = "NrfFraudInfo.FraudHomeAddress";
                } else if (request.getNrfFraudInfo().getFraudShippingAddress() == null) {
                    missingMandatoryParamName = "NrfFraudInfo.FraudShippingAddress";
                } else if (request.getNrfFraudInfo().getTransactionType() == null) {
                    missingMandatoryParamName = "NrfFraudInfo.TransactionType";
                }
            }
            // Validate the purchase price
            try {
                new BigDecimal(request.getNrfOfferInfo().getOfferDiscountPrice());
            } catch (NumberFormatException e) {
                throw new InvalidRequestException(
                		RESULT_CODES.RESULT_CODE_CUSTOM_INVALID_REQUEST_PARAMETERS,
                        "Invalid value specified for parameter: getNrfOfferInfo.OfferDiscountPrice - "
                                + e.getMessage());
            }
            // Validate the Offer Total Tax
            try {
                new BigDecimal(request.getNrfOfferInfo().getOfferTotalTax());
            } catch (NumberFormatException e) {
                throw new InvalidRequestException(
                		RESULT_CODES.RESULT_CODE_CUSTOM_INVALID_REQUEST_PARAMETERS,
                        "Invalid value specified for parameter: getNrfOfferInfo.OfferTotalTax - "
                                + e.getMessage());
            }
        }

        if (missingMandatoryParamName != null) {
            throw new InvalidRequestException(
            		RESULT_CODES.RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS,
                    "Missing mandatory parameter: " + missingMandatoryParamName);
        }
    }

    void validateRequest(String loggingKey, VisibleRequestReverseNrf request)
            throws InvalidRequestException {

        DEBUG(m_logger, loggingKey + "Validating reverse NRF request");

        String missingMandatoryParamName = null;
        if (StringUtils.isEmpty(request.getSubscriberExternalId())) {
            missingMandatoryParamName = "SubscriberExternalId";
        } else if (request.getCancelNrfOrderInfo() == null) {
            missingMandatoryParamName = "CancelNrfOrderInfo";
        } else if (StringUtils.isEmpty(request.getCancelNrfOrderInfo().getReturnOrderId())) {
            missingMandatoryParamName = "CancelNrfOrderInfo.ReturnOrderId";
        } else if (StringUtils.isEmpty(request.getCancelNrfOrderInfo().getOriginalOrderId())) {
            missingMandatoryParamName = "CancelNrfOrderInfo.OriginalOrderId";
        } else if (StringUtils.isEmpty(request.getCancelNrfOrderInfo().getOfferExternalId())) {
            missingMandatoryParamName = "CancelNrfOrderInfo.OfferExternalId";
        } else if (!StringUtils.isEmpty(request.getCancelNrfOrderInfo().getOriginalOrderDate())) {
            DateFormat dtf = new SimpleDateFormat(DATE_FORMAT);
            try {
                dtf.parse(request.getCancelNrfOrderInfo().getOriginalOrderDate());
            } catch (ParseException e) {
                throw new InvalidRequestException(
                		RESULT_CODES.RESULT_CODE_CUSTOM_INVALID_REQUEST_PARAMETERS,
                        "Invalid value specified for parameter: VisibleRequestReverseNrf.CancelNrfOrderInfo.OriginalOrderDate - "
                                + e.getMessage());
            }
        }

        if (missingMandatoryParamName != null) {
            throw new InvalidRequestException(
            		RESULT_CODES.RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS,
                    "Missing mandatory parameter: " + missingMandatoryParamName);
        }
    }

}
