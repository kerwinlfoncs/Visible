package com.matrixx.vag.subscriber.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.matrixx.datacontainer.MtxTimestamp;
import com.matrixx.datacontainer.mdc.*;
import com.matrixx.platform.MatrixxContext;
import com.matrixx.vag.advice.service.PaymentAdviceService;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.Constants.*;
import com.matrixx.vag.common.coverage.Generated;
import com.matrixx.vag.common.request.builder.*;
import com.matrixx.vag.config.AppPropertyParser;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.exception.*;
import com.matrixx.vag.service.IntegrationService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.beans.IntrospectionException;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import static com.matrixx.platform.LogUtils.*;
import static com.matrixx.vag.common.Constants.MATRIXX_CONSTANTS.CHRG_PURCHASE_FULL_AMOUNT;

@SuppressWarnings("unused")
@Configuration
public class ChangeService extends IntegrationService {

    @Autowired
    private PaymentAdviceService paymentAdviceService;

    private RequestValidator requestValidator;
    private static final Logger m_logger = LoggerFactory.getLogger(ChangeService.class);

    @Generated
    @Bean(name = "ChangeService")
    ChangeService getService() {
        return new ChangeService();
    }

    /**
     * Constructor.
     */
    public ChangeService() {
        this.requestValidator = new RequestValidator();
    }

    @SuppressWarnings("unchecked")
    public void changeBaseOfferService(VisibleRequestChangeService input,
                                       VisibleResponseChangeService output)
            throws Exception {
        // get logging key and route
        output.setSubscriptionExternalId(input.getSubscriptionExternalId());
        String loggingKey = getSubscriptionLoggingKey(input.getSubscriptionExternalId());
        String route = getRoute(MatrixxContext.getRequest());
        final String methodKey = loggingKey + " changeBaseOfferService: ";

        MtxRequestSubscriberModifyOffer modOffer = null;

        requestValidator.validateRequest(loggingKey, input);
        MtxResponseSubscription subscription = querySubscriptionData(
                loggingKey, input.getSubscriptionExternalId());
        VisibleRequestChangeServiceAdvice adviceRequest = new VisibleRequestChangeServiceAdvice();
        VisibleResponseChangeServiceAdvice adviceResponse = new VisibleResponseChangeServiceAdvice();

        adviceRequest.setSubscriptionExternalId(input.getSubscriptionExternalId());
        adviceRequest.setNewCatalogItemExternalId(
                input.getChangeOfferInfo().getNewCatalogItem().getCatalogItemExternalId());
        adviceRequest.setDiscountPrice(
                input.getChangeOfferInfo().getNewCatalogItem().getDiscountPrice());
        adviceRequest.setIncludePaymentAdvice(GENERIC_CONSTANTS.YES);

        for (VisibleChangeServicePromo csp : CommonUtils.emptyIfNull(input.getNewPromotionList())) {
            adviceRequest.getNewPromotionListAppender().add(csp);
        }

        for (VisibleDeltaPromo dp : CommonUtils.emptyIfNull(input.getDeltaPromotionList())) {
            adviceRequest.getDeltaPromotionListAppender().add(dp);
        }

        paymentAdviceService.getAdviceForChangeService(adviceRequest, adviceResponse, subscription);
        INFO(m_logger, methodKey + " ChangeServiceAdvice : " + adviceResponse.toJson());

        if (adviceResponse.getRechargeAmount().signum() > 0) {
            ERROR(
                    m_logger, methodKey + "Error based on RechargeAmount." + StringUtils.SPACE
                            + LOG_MESSAGES.NOT_ENOUGH_BALANCE_TO_CHANGE_SERVICE);
            output.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            output.setResultText(
                    "SubscriptionExternalID: " + input.getSubscriptionExternalId()
                            + " Error Message: "
                            + LOG_MESSAGES.NOT_ENOUGH_BALANCE_TO_CHANGE_SERVICE);
            return;
        }
        List<String> immediateAnnualChangeTypes = AppPropertyParser.getStringList(
                CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_REALIGN_CYCLE_LIST);
        List<String> immediateMonthlyChangeTypes = AppPropertyParser.getStringList(
                CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_IMMEDIATE_START_CSV_LIST);
        List<String> immediateChangeTypes = new ArrayList<String>();
        immediateChangeTypes.addAll(immediateMonthlyChangeTypes);
        immediateChangeTypes.addAll(immediateAnnualChangeTypes);

        MtxTimestamp realignCycleEndDate = getRealignCycleEndDate(loggingKey, adviceResponse);

        VisibleApiEventData vaed = (VisibleApiEventData) input.getApiEventData();
        MtxRequestMulti multiReqPurchase = new MtxRequestMulti();
        if (realignCycleEndDate != null && vaed != null) {
            vaed.setAnnualUpgradeCycleEndDate(realignCycleEndDate.getTime());
        } else if (realignCycleEndDate != null && vaed == null) {
            vaed = new VisibleApiEventData();
            vaed.setAnnualUpgradeCycleEndDate(realignCycleEndDate.getTime());
        }

        multiReqPurchase.setApiEventData(vaed);
        addReversePromoRequests(loggingKey, multiReqPurchase, adviceResponse);
        addCancelPromoRequests(loggingKey, subscription, multiReqPurchase, adviceResponse);
        addNewPromoGrantRequests(loggingKey, input, multiReqPurchase, adviceResponse);
        addRedeemPromoRequestForDeltaCycle(loggingKey, multiReqPurchase, input, adviceResponse);
        MtxTimestamp currentTime = CommonUtils.getCurrentTimeInZone(subscription.getTimeZone());
        // MtxTimestamp.longValue() does not provide epoch milli. It is timezone adjusted value. Do
        // not compare it with epoch milli.
        if (adviceResponse.getCurrentCatalogItem().getEndDate() != null
                && adviceResponse.getCurrentCatalogItem().getEndDate().longValue() > currentTime.longValue()) {
            INFO(
                    m_logger,
                    methodKey + "AS-IS offer EndDateTime: "
                            + adviceResponse.getCurrentCatalogItem().getEndDate()
                            + " is later than current DateTime: " + currentTime
                            + ". Offer will be EndDated.");
            addEndDateOfferRequest(loggingKey, multiReqPurchase, input, adviceResponse);
        } else {
            INFO(
                    m_logger,
                    methodKey + "AS-IS offer EndDateTime: "
                            + adviceResponse.getCurrentCatalogItem().getEndDate()
                            + " is NOT later than current DateTime: " + currentTime
                            + ". Offer will be cancelled.");
            addCancelCurrentOfferRequest(loggingKey, multiReqPurchase, adviceResponse);
        }

        addPurchaseOfferRequest(loggingKey, multiReqPurchase, input, adviceResponse, currentTime);
        MtxResponseMulti multiRespPurchase = multiRequest(loggingKey, route, multiReqPurchase);
        CommonUtils.validateMtxResponse(
                loggingKey,
                LOG_MESSAGES.FAILED_TO_CHANGE_SERVICE + " New service could not be purchased.",
                multiRespPurchase);

        MtxRequestMulti multiReqModify = new MtxRequestMulti();
        multiReqModify.setApiEventData(vaed);

        // checking logic for Travel pass Annual plan upgrade
        if (adviceResponse.getChangeType() != null
                && immediateChangeTypes.contains(adviceResponse.getChangeType())) {
            addGlobalPassAjdustRequests(loggingKey, multiReqModify, adviceResponse);
        }

        addRedeemPromoRequestForNextCycle(loggingKey, multiReqModify, input, adviceResponse);
        addOfferPriceRestoreRequest(
                loggingKey, multiReqModify, multiRespPurchase, input, adviceResponse);

        MtxResponseMulti multiRespModify = multiRequest(loggingKey, route, multiReqModify);
        CommonUtils.validateMtxResponse(
                loggingKey,
                LOG_MESSAGES.FAILED_TO_CHANGE_SERVICE
                        + " Price of purchased service could not be restored to full amount.",
                multiRespModify);

        output.setResult(RESULT_CODES.MTX_SUCCESS);
        if (adviceResponse.getResultText().contains(
                LOG_MESSAGES.FUTURE_GRANT_AMOUNT_IGNORED_1001)) {
            output.setResultText(adviceResponse.getResultText());
        } else {
            output.setResultText("OK");
        }
        output.setNewCatalogItem(input.getChangeOfferInfo().getNewCatalogItem());
        adviceResponse.getCurrentCatalogItem().getAttributesAppender().clear();
        output.setOldCatalogItem(adviceResponse.getCurrentCatalogItem());
    }

    private void addOfferPriceRestoreRequest(String loggingKey,
                                             MtxRequestMulti multiReqModify,
                                             MtxResponseMulti multiRespPurchase,
                                             VisibleRequestChangeService input,
                                             VisibleResponseChangeServiceAdvice adviceResponse)
            throws SubscriberServiceException {
        final String localKey = loggingKey + "addOfferPriceRestoreRequest: ";
        long resourceId = -1;

        for (MtxResponse resp : multiRespPurchase.getResponseList()) {
            if (resp instanceof MtxResponsePurchase) {
                MtxResponsePurchase purchaseResp = (MtxResponsePurchase) resp;
                for (MtxPurchaseInfo pi : purchaseResp.getPurchaseInfoArray()) {
                    if (StringUtils.isNotBlank(pi.getCatalogItemExternalId())
                            && input.getChangeOfferInfo().getNewCatalogItem().getCatalogItemExternalId().equalsIgnoreCase(
                                    pi.getCatalogItemExternalId())) {
                        resourceId = pi.getResourceId();
                        break;
                    }
                }
            }
            if (resourceId >= 0) {
                break;
            }
        }
        if (resourceId < 0) {
            throw new SubscriberServiceException(
                    RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,
                    "ResourceId of the newly purchased offer could not be located.");
        }

        input.getChangeOfferInfo().getNewCatalogItem().setResourceId(resourceId);

        //@formatter:off
        MtxRequestSubscriberModifyOfferBuilder mob = (new MtxRequestSubscriberModifyOfferBuilder())
                .withResourceId(resourceId)
                .withSubscriberExternalId(input.getSubscriptionExternalId())
                .withChargeAmount(input.getChangeOfferInfo().getNewCatalogItem().getDiscountPrice());
        //@formatter:on

        MtxTimestamp realignCycleEndDate = getRealignCycleEndDate(loggingKey, adviceResponse);

        if (realignCycleEndDate != null) {
            // Modify Cycle End time when moving from annual base to annual plus
            mob.withCycleEndTime(realignCycleEndDate);
            DEBUG(
                    m_logger, localKey + "Modified end date for " + adviceResponse.getChangeType()
                            + adviceResponse.getChangeCycle().getCycleEndTime());
        }

        if (input.getChangeOfferInfo().getAttrData() != null) {
            mob.withAttr(input.getChangeOfferInfo().getAttrData());
        }

        if (adviceResponse.getNextCycle() != null) {
            mob.withPurchaseServiceType(
                    PAYMENT_CONSTANTS.PURCHASE_SERVICE_TYPE_RENEWAL).withPaidCycleStartDate(
                            adviceResponse.getPaidCycleStartDate());

            if (StringUtils.isNotBlank(adviceResponse.getNextCycle().getTaxDetails())) {
                mob.withTaxDetails(adviceResponse.getNextCycle().getTaxDetails());
            }
            if (adviceResponse.getNextCycle().getCredits() != null
                    && !adviceResponse.getNextCycle().getCredits().isEmpty()) {
                for (VisibleCredits promo : adviceResponse.getNextCycle().getCredits()) {
                    if (StringUtils.isNotBlank(promo.getTaxDetails())) {
                        mob.withCreditTaxDetails(promo.getTaxDetails());
                    }
                }
            }
        }

        MtxRequestSubscriberModifyOffer modOffer = mob.build();
        INFO(
                m_logger, localKey
                        + "Add MtxRequestSubscriberModifyOffer request to restore Price of Newly Purchased Offer: "
                        + modOffer.toJson());
        multiReqModify.appendRequestList(modOffer);

        String cycleLength = "";
        if (adviceResponse.getNextCyclePaymentAdvice() != null
                && adviceResponse.getNextCyclePaymentAdvice().getVisibleOfferDetailsList() != null
                && !adviceResponse.getNextCyclePaymentAdvice().getVisibleOfferDetailsList().isEmpty()) {
            for (VisibleOfferDetails vod : adviceResponse.getNextCyclePaymentAdvice().getVisibleOfferDetailsList()) {
                if (!OFFER_CONSTANTS.OFFER_TYPE_BASE.equalsIgnoreCase(vod.getOfferType())) {
                    continue;
                }
                LocalDate ldStart = LocalDate.parse(
                        vod.getCycleStartTime().substring(0, vod.getCycleStartTime().indexOf("T")));
                LocalDate ldEnd = LocalDate.parse(
                        vod.getCycleEndTime().substring(0, vod.getCycleStartTime().indexOf("T")));
                if (ldStart.plusYears(1).isBefore(ldEnd) || ldStart.plusYears(1).isEqual(ldEnd)) {
                    cycleLength = CYCLE_LENGTHS.YEAR;
                } else if (ldStart.plusMonths(1).isBefore(ldEnd)) {
                    cycleLength = CYCLE_LENGTHS.MULTI_MONTH;
                } else {
                    cycleLength = CYCLE_LENGTHS.MONTH;
                }
            }
        }
        if (StringUtils.isNotBlank(cycleLength)) {
            MtxRequestSubscriptionModifyBuilder smb = (new MtxRequestSubscriptionModifyBuilder()).withSubscriberExternalId(
                    input.getSubscriptionExternalId()).withCycleLength(cycleLength);
            MtxRequestSubscriptionModify sm = smb.build();
            INFO(
                    m_logger, localKey + "Add " + MtxRequestSubscriptionModify.class.getSimpleName()
                            + " request to update cycle length attribute: " + sm.toJson());
            multiReqModify.appendRequestList(sm);
        }

    }

    private MtxTimestamp getRealignCycleEndDate(String loggingKey,
                                                VisibleResponseChangeServiceAdvice adviceResponse) {
        List<String> realignList = AppPropertyParser.getStringList(
                CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_REALIGN_CYCLE_LIST);
        if (adviceResponse.getChangeCycle() != null
                && adviceResponse.getChangeCycle().getCycleEndTime() != null
                && !adviceResponse.getChangeType().isEmpty()
                && realignList.contains(adviceResponse.getChangeType())) {
            return adviceResponse.getChangeCycle().getCycleEndTime();
        } else {
            return null;
        }

    }

    private void addPurchaseOfferRequest(String loggingKey,
                                         MtxRequestMulti multiReq,
                                         VisibleRequestChangeService input,
                                         VisibleResponseChangeServiceAdvice adviceResponse,
                                         MtxTimestamp currentTime)
            throws CommonUtilsException, IntrospectionException {
        final String methodKey = loggingKey + " addPurchaseOfferRequest: ";
        INFO(m_logger, methodKey);
        if (adviceResponse.getPreactiveCatalogItem() != null) {
            // @formatter:off
            MtxRequestSubscriberCancelOfferBuilder cobPreactive = (new MtxRequestSubscriberCancelOfferBuilder())
                    .withSubscriberExternalId(adviceResponse.getSubscriptionExternalId())
                    .withResourceId(adviceResponse.getPreactiveCatalogItem().getResourceId());
            // @formatter:on            
            MtxRequestSubscriberCancelOffer canPreactive = cobPreactive.build();
            INFO(
                    m_logger,
                    methodKey
                            + " Add MtxRequestSubscriberCancelOffer request to cancel preactive offer: "
                            + canPreactive.toJson());
            multiReq.appendRequestList(cobPreactive.build());
        }

        // @formatter:off
        MtxPurchasedOfferDataBuilder pob = (new MtxPurchasedOfferDataBuilder())
                .withOfferExternalId(adviceResponse.getNewCatalogItem().getCatalogItemExternalId())
                .withOfferChangeType(adviceResponse.getChangeType())
                .withAmount(adviceResponse.getChangeCycle().getTotalAmount())
                .withGoodType(adviceResponse.getNewCatalogItem().getGoodType())
                .withInfo(System.currentTimeMillis() + "")
                .withChargePurchaseProrationType(CHRG_PURCHASE_FULL_AMOUNT);
        // @formatter:on
        if (adviceResponse.getNewCatalogItem().getStartDate() != null
                && adviceResponse.getNewCatalogItem().getStartDate().longValue() > currentTime.longValue()) {
            INFO(
                    m_logger,
                    methodKey + " TO-BE offer StartDateTime: "
                            + adviceResponse.getNewCatalogItem().getStartDate()
                            + " is later than current DateTime: " + currentTime
                            + ". Offer will be Pre-active.");
            pob.withAutoActivationTime(adviceResponse.getNewCatalogItem().getStartDate());
            pob.withPreActiveState(true);
        }

        if (StringUtils.isNoneBlank(adviceResponse.getChangeCycle().getTaxDetails())) {
            pob.withTaxDetails(adviceResponse.getChangeCycle().getTaxDetails());
        }

        if (input.getChangeOfferInfo().getAttrData() != null) {
            pob.withOfferExtn(input.getChangeOfferInfo().getAttrData());
        }

        MtxRequestSubscriberPurchaseOfferBuilder spob = (new MtxRequestSubscriberPurchaseOfferBuilder()).withSubscriberExternalId(
                input.getSubscriptionExternalId()).withOfferData(pob.build());

        MtxRequestSubscriberPurchaseOffer po = spob.build();

        INFO(
                m_logger,
                methodKey + "Add MtxRequestSubscriberPurchaseOffer request to enroll in new offer: "
                        + po.toJson());
        multiReq.appendRequestList(po);
    }

    private void addRedeemPromoRequestForNextCycle(String loggingKey,
                                                   MtxRequestMulti multiReq,
                                                   VisibleRequestChangeService input,
                                                   VisibleResponseChangeServiceAdvice adviceResponse)
            throws CommonUtilsException, IntrospectionException {
        final String methodName = "addRedeemPromoRequestForNextCycle: ";
        INFO(m_logger, loggingKey + methodName);
        if (adviceResponse.getNextCycle() != null
                && adviceResponse.getNextCycle().getCredits() != null
                && !adviceResponse.getNextCycle().getCredits().isEmpty()) {
            addRedeemPromoRequests(
                    loggingKey, multiReq, input, adviceResponse.getNextCycle().getCredits());
        }
    }

    private void addRedeemPromoRequestForDeltaCycle(String loggingKey,
                                                    MtxRequestMulti multiReq,
                                                    VisibleRequestChangeService input,
                                                    VisibleResponseChangeServiceAdvice adviceResponse)
            throws CommonUtilsException, IntrospectionException {
        final String methodKey = loggingKey + " addRedeemPromoRequestForDeltaCycle: ";
        INFO(m_logger, methodKey);
        if (adviceResponse.getChangeCycle().getCredits() != null
                && !adviceResponse.getChangeCycle().getCredits().isEmpty()) {
            addRedeemPromoRequests(
                    loggingKey, multiReq, input, adviceResponse.getChangeCycle().getCredits());
        }
    }

    private void addRedeemPromoRequests(String loggingKey,
                                        MtxRequestMulti multiReq,
                                        VisibleRequestChangeService input,
                                        List<VisibleCredits> promoList)
            throws CommonUtilsException, IntrospectionException {
        final String methodName = "addRedeemPromoRequests: ";
        // if (promoList != null && !promoList.isEmpty()) {
        for (VisibleCredits credit : CommonUtils.emptyIfNull(promoList)) {
            if (credit.getEstimatedTransferableCredits().signum() > 0) {
                // @formatter:off
                MtxPurchasedOfferDataBuilder mob = (new MtxPurchasedOfferDataBuilder())
                        .withAmount(credit.getEstimatedTransferableCredits())
                        .withCoreBasePlanCI(credit.getApplicableCI())
                        .withCreditReason(credit.getRedeemableGoodType())
                        .withGoodType(credit.getRedeemableGoodType())
                        .withOfferExternalId(credit.getCreditRedeemableOfferCI());
                // @formatter:on
                if (input.getChangeOfferInfo().getAttrData() != null) {
                    mob.withOfferExtn(input.getChangeOfferInfo().getAttrData());
                }

                MtxRequestSubscriberPurchaseOfferBuilder rob = (new MtxRequestSubscriberPurchaseOfferBuilder()).withSubscriberExternalId(
                        input.getSubscriptionExternalId()).withOfferData(mob.build());

                MtxRequestSubscriberPurchaseOffer redeemOffer = rob.build();

                INFO(
                        m_logger,
                        loggingKey + methodName
                                + " Add MtxRequestSubscriberPurchaseOffer request to move promotions to consumable balance: "
                                + redeemOffer.toJson());
                multiReq.appendRequestList(redeemOffer);
            }
        }
        // }
    }

    private void addEndDateOfferRequest(String loggingKey,
                                        MtxRequestMulti multiReq,
                                        VisibleRequestChangeService input,
                                        VisibleResponseChangeServiceAdvice adviceResponse) {
        final String methodName = "addEndDateOfferRequest: ";
        MtxRequestSubscriberModifyOfferBuilder mob = (new MtxRequestSubscriberModifyOfferBuilder()).withResourceId(
                adviceResponse.getCurrentCatalogItem().getResourceId()).withSubscriberExternalId(
                        input.getSubscriptionExternalId()).withEndTime(
                                adviceResponse.getCurrentCatalogItem().getEndDate());
        MtxRequestSubscriberModifyOffer modOffer = mob.build();
        INFO(
                m_logger,
                loggingKey + methodName
                        + " Add  MtxRequestSubscriberModifyOffer request to EndDate Enrolled Offer: "
                        + modOffer.toJson());
        multiReq.appendRequestList(modOffer);
    }

    private void addReversePromoRequests(String loggingKey,
                                         MtxRequestMulti multiReq,
                                         VisibleResponseChangeServiceAdvice adviceResponse) {
        final String methodName = "addReversePromoRequests: ";
        if (adviceResponse.getNextCycle() != null
                && adviceResponse.getNextCycle().getReverseCredits() != null
                && !adviceResponse.getNextCycle().getReverseCredits().isEmpty()) {
            MtxResponseOneTimeOffer redeemOffers = querySubscriptionOneTimeOffer(
                    loggingKey, adviceResponse.getSubscriptionExternalId());
            for (VisibleReverseCredit rc : adviceResponse.getNextCycle().getReverseCredits()) {
                // if (redeemOffers != null && redeemOffers.getOneTimeOfferArray() != null) {
                for (MtxPurchasedOfferInfo redeemOffer : CommonUtils.emptyIfNull(
                        redeemOffers.getOneTimeOfferArray())) {
                    if (redeemOffer.getCatalogItemExternalId().equalsIgnoreCase(
                            rc.getRedeemableOfferCI())) {
                        MtxRequestSubscriberCancelOfferBuilder cob = (new MtxRequestSubscriberCancelOfferBuilder()).withSubscriberExternalId(
                                adviceResponse.getSubscriptionExternalId());
                        cob.withResourceId(redeemOffer.getResourceId());
                        MtxRequestSubscriberCancelOffer canOffer = cob.build();
                        INFO(
                                m_logger,
                                loggingKey + methodName
                                        + " Add MtxRequestSubscriberCancelOffer request to move promotions out of consumable balance: "
                                        + canOffer.toJson());
                        multiReq.appendRequestList(canOffer);
                        break;
                    }
                }
                // }
            }
        }
    }

    private void addCancelPromoRequests(String loggingKey,
                                        MtxResponseSubscription subscription,
                                        MtxRequestMulti multiReq,
                                        VisibleResponseChangeServiceAdvice adviceResponse)
            throws IntegrationServiceException, NoSuchMethodException, SecurityException,
            InstantiationException, IllegalAccessException, IllegalArgumentException,
            InvocationTargetException {
        final String methodName = "addCancelPromoRequests: ";

        CommonUtils.validateResponse(
                loggingKey, EXCEPTION_MESSAGES.FAILED_TO_QUERY_SUBSCRIPTION, m_logger,
                PaymentAdviceException.class, subscription);

        if (adviceResponse.getNonRedeemableCredits() == null
                || adviceResponse.getNonRedeemableCredits().isEmpty()) {
            return;
        }

        if (subscription.getPurchasedOfferArray() == null
                || subscription.getPurchasedOfferArray().isEmpty()) {
            return;
        }

        for (VisibleNonRedeemableCredit nrc : adviceResponse.getNonRedeemableCredits()) {
            for (MtxPurchasedOfferInfo poi : subscription.getPurchasedOfferArray()) {
                if (!nrc.getGrantOfferCI().equalsIgnoreCase(poi.getCatalogItemExternalId())) {
                    continue;
                }
                VisiblePurchasedOfferExtension grantAttr = (VisiblePurchasedOfferExtension) poi.getAttr();
                if (grantAttr != null && StringUtils.isNotBlank(grantAttr.getApplicableOfferName())
                        && !grantAttr.getApplicableOfferName().contains(
                                adviceResponse.getCurrentCatalogItem().getCatalogItemExternalId())) {
                    continue;
                }
                MtxRequestSubscriberCancelOfferBuilder cob = (new MtxRequestSubscriberCancelOfferBuilder()).withSubscriberExternalId(
                        adviceResponse.getSubscriptionExternalId());
                cob.withResourceId(poi.getResourceId());
                MtxRequestSubscriberCancelOffer canOffer = cob.build();
                INFO(
                        m_logger,
                        loggingKey + methodName
                                + " Add MtxRequestSubscriberCancelOffer request to cancel grant offer: "
                                + canOffer.toJson());
                multiReq.appendRequestList(canOffer);
                break;
            }
        }
    }

    private void addNewPromoGrantRequests(String loggingKey,
                                          VisibleRequestChangeService request,
                                          MtxRequestMulti multiReq,
                                          VisibleResponseChangeServiceAdvice adviceResponse) {
        final String methodName = "addNewPromoGrantRequests: ";
        // if (adviceResponse.getNewRedeemableCredits() != null
        // && !adviceResponse.getNewRedeemableCredits().isEmpty()) {
        for (VisibleChangeServiceCredit csc : CommonUtils.emptyIfNull(
                adviceResponse.getNewRedeemableCredits())) {
            boolean cancel = false, modify = false, purchase = false;

            if (csc.getResourceId() != null && csc.getResourceId() > 0
                    && StringUtils.isNotBlank(csc.getGrantOfferCI())) {
                for (VisibleChangeServicePromo newPromo : CommonUtils.emptyIfNull(
                        request.getNewPromotionList())) {
                    if (csc.getGrantOfferCI().equalsIgnoreCase(newPromo.getGrantOfferCI())
                            && !GENERIC_CONSTANTS.NO.equalsIgnoreCase(
                                    newPromo.getResetExistingPromo())) {
                        cancel = true;
                        purchase = true;
                    }
                }
                if (!cancel) {
                    modify = true;
                }
            } else {
                purchase = true;
            }
            if (cancel) {
                MtxRequestSubscriberCancelOfferBuilder cob = (new MtxRequestSubscriberCancelOfferBuilder()).withSubscriberExternalId(
                        adviceResponse.getSubscriptionExternalId()).withResourceId(
                                csc.getResourceId());

                MtxRequestSubscriberCancelOffer canOffer = cob.build();
                INFO(
                        m_logger,
                        loggingKey + methodName
                                + " Add MtxRequestSubscriberCancelOffer request to reset existing promo: "
                                + canOffer.toJson());
                multiReq.appendRequestList(cob.build());
            }
            if (modify) {
                MtxRequestSubscriberModifyOfferBuilder smob = (new MtxRequestSubscriberModifyOfferBuilder()).withSubscriberExternalId(
                        adviceResponse.getSubscriptionExternalId()).withResourceId(
                                csc.getResourceId());
                if (StringUtils.isNotBlank(csc.getClassCode())) {
                    smob.withClassCode(csc.getClassCode());
                }
                if (StringUtils.isNotBlank(csc.getPromotionName())) {
                    smob.withPromotionName(csc.getPromotionName());
                }
                if (csc.getPromotionLimit() != null && csc.getPromotionLimit().signum() > 0) {
                    smob.withPromotionLimit(csc.getPromotionLimit());
                }

                MtxRequestSubscriberModifyOffer modifyGrantOffer = smob.build();
                INFO(
                        m_logger,
                        loggingKey + methodName
                                + " Add MtxRequestSubscriberModifyOffer request to modify promotion : "
                                + modifyGrantOffer.toJson());
                multiReq.appendRequestList(modifyGrantOffer);
            }
            if (purchase) {
                MtxPurchasedOfferDataBuilder podb = (new MtxPurchasedOfferDataBuilder()).withOfferExternalId(
                        csc.getGrantOfferCI());

                if (csc.getGrantAmount() != null && csc.getGrantAmount().signum() > 0) {
                    podb.withAmount(csc.getGrantAmount());
                } else {
                    podb.withAmount(BigDecimal.ZERO);
                }

                if (StringUtils.isNotBlank(csc.getClassCode())) {
                    podb.withClassCode(csc.getClassCode());
                }
                if (StringUtils.isNotBlank(csc.getPromotionName())) {
                    podb.withPromotionName(csc.getPromotionName());
                }
                if (csc.getPromotionLimit() != null && csc.getPromotionLimit().signum() > 0) {
                    podb.withPromotionLimit(csc.getPromotionLimit());
                }

                MtxRequestSubscriberPurchaseOfferBuilder pob = (new MtxRequestSubscriberPurchaseOfferBuilder()).withSubscriberExternalId(
                        adviceResponse.getSubscriptionExternalId()).withOfferData(podb.build());

                MtxRequestSubscriberPurchaseOffer grantOffer = pob.build();
                INFO(
                        m_logger,
                        loggingKey + methodName
                                + " Add MtxRequestSubscriberPurchaseOffer request to give new promotion : "
                                + grantOffer.toJson());
                multiReq.appendRequestList(grantOffer);
            }
        }
        // }
    }

    private void addCancelCurrentOfferRequest(String loggingKey,
                                              MtxRequestMulti multiReq,
                                              VisibleResponseChangeServiceAdvice adviceResponse) {
        final String methodName = "addCancelCurrentOfferRequest: ";
        MtxRequestSubscriberCancelOfferBuilder cobActive = (new MtxRequestSubscriberCancelOfferBuilder()).withSubscriberExternalId(
                adviceResponse.getSubscriptionExternalId()).withResourceId(
                        adviceResponse.getCurrentCatalogItem().getResourceId());

        MtxRequestSubscriberCancelOffer canActive = cobActive.build();
        INFO(
                m_logger,
                loggingKey + methodName
                        + " Add MtxRequestSubscriberCancelOffer request to cancel enrolled offer: "
                        + canActive.toJson());
        multiReq.appendRequestList(cobActive.build());
    }

    private void addGlobalPassAjdustRequests(String loggingKey,
                                             MtxRequestMulti multiReqModify,
                                             VisibleResponseChangeServiceAdvice adviceResponse) {
        final String methodKey = loggingKey + " addGlobalPassAjdustRequests: ";
        INFO(m_logger, methodKey + "Enter");
        MtxResponseSubscription subscriptionAfterChange = querySubscriptionData(
                loggingKey, adviceResponse.getSubscriptionExternalId());
        BigDecimal tpCounterAsIs = BigDecimal.ZERO;
        BigDecimal tpCounterToBe = BigDecimal.ZERO;
        Long resourceId = null;
        String gpBalanceName = AppPropertyProvider.getInstance().getString(
                BALANCE_CONSTANTS.BALANCE_NAME_GLOBAL_PASS).trim();

        for (MtxBalanceInfo bi : subscriptionAfterChange.getBalanceArray()) {
            if (bi.getName().trim().equalsIgnoreCase(gpBalanceName)) {
                tpCounterAsIs = bi.getAmount();
                resourceId = bi.getResourceId();
                break;
            }
        }

        for (VisibleAttribute attr : CommonUtils.emptyIfNull(
                adviceResponse.getNewCatalogItem().getAttributes())) {
            if (CHANGE_SERVICE_CONSTANTS.ATTRIBUTE_NAME_FREE_GLOBAL_PASS.equalsIgnoreCase(
                    attr.getName())) {
                tpCounterToBe = BigDecimal.valueOf(Long.parseLong(attr.getValue()));
                break;
            }
        }

        // run adjust balance as a part of second multi request to adjust TravelPass Counter
        // balance
        if (resourceId != null && tpCounterAsIs.signum() != 0
                && tpCounterAsIs.compareTo(tpCounterToBe) == 1) {
            BigDecimal amount = tpCounterAsIs.subtract(tpCounterToBe);
            // @formatter:off
            MtxRequestSubscriberAdjustBalanceBuilder adjBuilder = (new MtxRequestSubscriberAdjustBalanceBuilder())
                    .withSubscriberExternalId(adviceResponse.getSubscriptionExternalId())
                    .withBalanceResourceId(resourceId)
                    .withAmount(amount)
                    .withReason(adviceResponse.getChangeType());
            // @formatter:on
            multiReqModify.appendRequestList(adjBuilder.build());
            INFO(
                    m_logger,
                    methodKey + "Adjust balance request" + "TpCounterAsIs: " + tpCounterAsIs
                            + "TpCounterToBe: " + tpCounterToBe + "Amount: " + amount);

            // @formatter:off
            MtxPurchasedOfferDataBuilder podb = (new MtxPurchasedOfferDataBuilder())
                    .withOfferExternalId(OFFER_CONSTANTS.GPGL_CURLY_ADJUST_OFFER_NAME)
                    .withGoodType(CHANGE_SERVICE_CONSTANTS.GOOD_TYPE_ADJ_GPGL)
                    .withPlanID(CHANGE_SERVICE_CONSTANTS.PLAN_ID_ADJ_GPGL);
            MtxRequestSubscriberPurchaseOfferBuilder pob = (new MtxRequestSubscriberPurchaseOfferBuilder()).withSubscriberExternalId(
                    adviceResponse.getSubscriptionExternalId()).withOfferData(podb.build());
           // @formatter:on

            multiReqModify.appendRequestList(pob.build());
            INFO(
                    m_logger, methodKey + "Adjust GP GL balance request to be in sync with "
                            + BALANCE_CONSTANTS.BALANCE_NAME_GLOBAL_PASS);
        }
    }

}
