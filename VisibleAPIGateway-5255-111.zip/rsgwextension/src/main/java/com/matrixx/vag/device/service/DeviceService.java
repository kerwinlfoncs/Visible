package com.matrixx.vag.device.service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonObject;
import com.matrixx.datacontainer.MtxObjectId;
import com.matrixx.datacontainer.MtxTimestamp;
import com.matrixx.datacontainer.mdc.*;
import com.matrixx.platform.MatrixxContext;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.Constants.*;
import com.matrixx.vag.config.AppPropertyParser;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.exception.*;
import com.matrixx.vag.service.IntegrationService;
import org.apache.camel.spring.util.ReflectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.IOException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import static com.matrixx.platform.LogUtils.*;

/**
 * Provides a customized version of the Purchase Device operation based on a new implementation of
 * the MtxRequestSubscriberPurchaseOffer to perform additional logic to redeem voucher (if present)
 * and provision the PCRF based on the offer the subscriber has selected and any existing offers
 * they may already have.
 *
 * @author unico
 */
@SuppressWarnings("unused")
@Configuration
public class DeviceService extends IntegrationService {

    private static final String REFUND_REASON = "Device return";
    private final RequestValidator requestValidator;

    public static final String FAILED_TO_FIND_ORIG_ORDER = "Failed to find original order for subscriber";
    public static final String FAILED_TO_FIND_BALANCE_RESOURCE_ID = "Failed to determine refund balance resource ID for subscriber";
    private static final String INFO = "INFO";
    private static final String GOOD_TYPE = "GOOD_TYPE";
    private static final String EXTERNAL_ID = "EXTERNAL_ID";
    private static final String EVENT_SUMMARY = "EVENT_SUMMARY";
    private static final String EVENT_IDS = "EVENT_IDS";
    private static final String SHIP_TO_BID = "SHIP_TO_BID";
    private static final String BALANCE_RESOURCE_ID = "BALANCE_RESOURCE_ID";
    private static final String REFUNDABLE_AMOUNT = "REFUNDABLE_AMOUNT";
    private static final String RECHARGE_REASON = "RECHARGE_REASON";
    private static final String AUTH_EVENT_ID = "AUTH_EVENT_ID";
    private static final String MISSING_PURCHASE_HISTORY = "Missing purchase history for subscriber";
    public static final String FAILED_TO_DETERMINE_DEVICE_INSTANCE_ID = "Failed to determine device instance ID";
    public static final String FAILED_TO_CHARGE_NON_RETURN_FEE = "Failed to charge non return fee";
    public static final String FAILED_TO_QUERY_RECCURING_HISTORY = "Failed to query recurring history for subscriber";
    public static final String CREATE_FINANCE_DEVICE_TXN = "Creating finance device transaction";

    public static final String LOG_QUERY_SUBSCRIBER_DATA_IN_MATRIXX = "Querying subscriber data in MATRIXX";
    public static final String LOG_FAILED_TO_QUERY_SUBSCRIBER = "Failed to query subscriber";
    public static final String LOG_FAILED_MULTI = "Error in Multirequest";
    public static final String LOG_FAILED_TO_QUERY_PAYMENT_HISTORY = "Failed to query payment history for subscriber";
    public static final String LOG_FAILED_TO_FINANCE_DEVICE = "Failed to finance device ";
    public static final String LOG_FAILED_TO_DETERMINE_HOME_BID = "Failed to determine home BID for subscriber";
    public static final String LOG_FAILED_TO_DETERMINE_SHIP_BID = "Failed to determine ship BID for subscriber";

    public static final String LOG_MISSING_PURCHASE_HISTORY = "Missing purchase history for subscriber";
    public static final String LOG_PAYAUTH_NOT_FOUND = "Failed to determine original payment authorization event ID for subscriber";
    public static final String LOG_PAYMENT_RESOURCE_ID_NOT_FOUND = "Failed to determine payment resource ID for subscriber";
    public static final String LOG_OFFER_CATLOG_NOT_FOUND = "Failed to fetch the catalog item details of the offer,";

    public static final String OFFER_ATTR_FOR_DEVICE_SWAP_EQUIPMENT_REASON = ATTR_NAME_GOOD_TYPE;
    public static final String OFFER_ATTR_DEVICE_SWAP_EQUIPMENT_DELTA_REASON = "606_Adjustment_Reason";
    public static final String OFFER_ATTR_DEVICE_SWAP_SERVICE_DELTA_REASON = "606_revenue_adjustment_recognition";

    public static final int DIVIDE_QUOTIENT_SCALE = 3;
    public static final int DIVIDE_ROUNDING_MODE = BigDecimal.ROUND_HALF_EVEN;

    public static final String ERROR_FAILED_TO_RETRIEVE_SUBSCRIBER_WALLET = "Failed to query wallet data for subscriber ";

    private static final int CHARGE_METHOD_PAY_NOW = 2;

    private final static ObjectMapper objectMapper = new ObjectMapper();

    private static final Logger m_logger = LoggerFactory.getLogger(DeviceService.class);

    @Bean(name = "DeviceService")
    DeviceService getService() {
        return new DeviceService();
    }

    /**
     * Constructor.
     */
    public DeviceService() {
        this.requestValidator = new RequestValidator();
    }

    /**
     * Device purchase extension handler.
     *
     * @param input
     *            input
     * @param output
     *            output
     * @throws Exception
     */
    public void purchaseDevice(VisibleRequestPurchaseDevice input,
                               VisibleResponsePurchaseDevice output)
                                       throws Exception {

        // Setup the logging key
        String loggingKey = getLoggingKey(input.getSubscriberExternalId());

        // Determine routing data
        String route = getRoute(MatrixxContext.getRequest());

        // Validate the request
        requestValidator.validateRequest(loggingKey, input);

        // Determine the total cost of the device purchase including shipping price
        // 1. Calculate device amount deviceAmount = DeviceDiscountPrice + DeviceTotalTax
        // 2. Calculate shipping amount shippingAmount = ShippingDiscountPrice + ShippingTotalTax
        BigDecimal deviceDiscountPrice = new BigDecimal(
                input.getPurchaseDeviceInfo().getDeviceDiscountPrice());
        BigDecimal shippingDiscountPrice = new BigDecimal(
                input.getPurchaseShippingInfo().getShippingDiscountPrice());
        BigDecimal deviceTotalTax = new BigDecimal(
                input.getPurchaseDeviceInfo().getDeviceTotalTax());
        BigDecimal shippingTotalTax = new BigDecimal(
                input.getPurchaseShippingInfo().getShippingTotalTax());

        BigDecimal deviceAmount = (deviceDiscountPrice.add(deviceTotalTax)).setScale(
        		BRAINTREE_CONSTANTS.BT_AMOUNT_PRECISION, RoundingMode.HALF_UP);

        BigDecimal shippingAmount = (shippingDiscountPrice.add(shippingTotalTax)).setScale(
        		BRAINTREE_CONSTANTS.BT_AMOUNT_PRECISION, RoundingMode.HALF_UP);

        INFO(m_logger, loggingKey + "Device Amount " + deviceAmount);
        INFO(m_logger, loggingKey + "Shipping Amount " + shippingAmount);

        // Prepare subscriber search data
        MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
        searchData.setExternalId(input.getSubscriberExternalId());

        // 3. Query the subscriber data in MATRIXX
        DEBUG(m_logger, loggingKey + "Querying subscriber data in MATRIXX");
        MtxResponseSubscription subscriber = querySubscriptionData(loggingKey, input.getSubscriberExternalId());
        if (subscriber == null
                || subscriber.getResult() != RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS) {
            Long resultCode = subscriber != null
                    ? subscriber.getResult() : RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR;
                    String message = "Failed to query subscriber"
                            + (subscriber != null ? " - " + subscriber.getResultText() : "");
                    throw new DeviceServiceException(resultCode, message);
        }

        // 4. Create a multi-request containing all the operations required to handle the device
        // purchase as a single transaction
        DEBUG(m_logger, loggingKey + "Creating purchase device transaction");
        MtxRequestMulti multiReqPurchaseDevice = new MtxRequestMulti();
        int multiIndex = 0;
        int createDeviceIndexTracker = 0;

        // Add Setup_Mainbalance (dummy) Offer before recharge
        String setupOffer = AppPropertyProvider.getInstance().getString(
                OFFER_CONSTANTS.OFFER_PURCHASE_SETUP_MAINBALANCE_OFFER);
        MtxPurchasedOfferData setUpMainBalanceOfferData = getPurchasedOfferData(
                setupOffer, input.getPurchaseOrderInfo().getOrderId(), null, BigDecimal.ZERO, null,
                null, null);
        multiReqPurchaseDevice.appendRequestList(
                getSubscriberPurchaseOfferRequest(searchData, setUpMainBalanceOfferData));
        multiIndex++;

        // 5. If Ship-to-BID is not equal to Home-BID, modify subscriber to change GL Center to
        // Ship-to-BID
        String homeBid = null;
        String origGlCenter = CommonUtils.getSubscriberGlCenter(subscriber);
        boolean glCenterChanged = false;
        if (subscriber.getAttr() != null
                && subscriber.getAttr() instanceof VisibleSubscriberExtension) {
            homeBid = ((VisibleSubscriberExtension) subscriber.getAttr()).gethomeBID();
            if (homeBid == null) {
                WARN(m_logger, loggingKey + LOG_FAILED_TO_DETERMINE_HOME_BID);
            } else {
                if (!homeBid.equals(origGlCenter)) {

                    WARN(
                            m_logger, loggingKey + "Subscriber data mismatch. GL Centre: "
                                    + origGlCenter + ", Home BID: " + homeBid);
                }
                if (!input.getPurchaseShippingInfo().getShipToBid().equals(homeBid)) {
                    DEBUG(
                            m_logger,
                            loggingKey + "Temporarily modifying subscriber GL Centre from "
                                    + origGlCenter + " to "
                                    + input.getPurchaseShippingInfo().getShipToBid());

                    multiReqPurchaseDevice.appendRequestList(
                            getSubscriberModifyRequest(
                                    searchData, input.getPurchaseShippingInfo().getShipToBid()));
                    glCenterChanged = true;
                    multiIndex++;
                }
            }
        } else {
            WARN(m_logger, loggingKey + LOG_FAILED_TO_DETERMINE_HOME_BID);
        }

        // 6. Prepare charge method data for purchases
        MtxChargeMethodData chargeMethodData = new MtxChargeMethodData();

        if (input.getPurchaseFraudInfo() != null) {

            VisibleFraudHomeAddress fraudBillingAddress = new VisibleFraudHomeAddress();
            fraudBillingAddress = input.getPurchaseFraudInfo().getFraudHomeAddress();

            VisibleFraudShippingAddress fraudShippingAddress = new VisibleFraudShippingAddress();
            fraudShippingAddress = input.getPurchaseFraudInfo().getFraudShippingAddress();

            VisibleFraudDeviceInfo fraudDeviceInfo = new VisibleFraudDeviceInfo();

            if (input.getPurchaseFraudInfo().getFraudDeviceInfo() != null) {
                fraudDeviceInfo = input.getPurchaseFraudInfo().getFraudDeviceInfo();
            }
            List<VisibleAttribute> paymentGatewayAttributes = new ArrayList<VisibleAttribute>();
            if (input.getPurchaseFraudInfo().getPaymentGatewayAttributes() != null
                    && !input.getPurchaseFraudInfo().getPaymentGatewayAttributes().isEmpty()) {
                paymentGatewayAttributes = input.getPurchaseFraudInfo().getPaymentGatewayAttributes();
            }

            CommonUtils.addFraudInfoToChargeMethodData(
                    chargeMethodData, fraudBillingAddress, fraudShippingAddress, fraudDeviceInfo,
                    input.getPurchaseFraudInfo().getTransactionType(),
                    BRAINTREE_CONSTANTS.BT_VISIBLE_RECURRING_OVERRIDE_FLAG, paymentGatewayAttributes, loggingKey);

        }
        String payGatewayId = null;
        String payInfo = null;
        String payMethod;
        payMethod = input.getPurchaseOrderInfo().getPaymentMethod();
        if (input.getPurchaseOrderInfo().getPaymentInfo() != null) {
            payInfo = input.getPurchaseOrderInfo().getPaymentInfo();
        }
        if (input.getPurchaseOrderInfo().getPaymentGatewayId() != null) {
            payGatewayId = input.getPurchaseOrderInfo().getPaymentGatewayId();
        }
        addPaymentInfoToChargeMethodData(chargeMethodData, payMethod, payInfo, payGatewayId);

        // Add the device create and link operations to the multi-request if the purchase is for
        // a service providing device
        DeviceType deviceType = DeviceType.valueOf(
                input.getPurchaseDeviceInfo().getDeviceProvidesService());

        if (deviceType == DeviceType.sp) {

            // 7a. If devicetype is sp, add create device request to Multi
            createDeviceIndexTracker = multiIndex;
            multiReqPurchaseDevice.appendRequestList(
                    getDeviceCreateRequest(
                            input.getPurchaseDeviceInfo().getDeviceAccessNumber(),
                            input.getPurchaseDeviceInfo().getDeviceIMSI()));
            multiIndex++;

            // 7b. If devicetype is sp, assign device to subscriber
            multiReqPurchaseDevice.appendRequestList(
                    getSubscriberAddDeviceRequest(searchData, createDeviceIndexTracker));
            multiIndex++;
        }

        // 8. create purchase offer request for Visible_Device with deviceAmount (charges for total
        // device amount, incl tax). Add good_type and Info to purchase request
        // i. good_type = purchase_device (unique string to identify offer)
        // ii. Info = timestamp (unique identifier for transaction)

        String deviceTimestamp = (new Date()).getTime() + "";
        String deviceGoodType = AppPropertyProvider.getInstance().getString(
                DEVICE_CONSTANTS.DEVICE_DIRECT_PURCHASE_GOOD_TYPE_PURCHASE_DEVICE);
        MtxPurchasedOfferData deviceOfferData = getPurchasedOfferData(
                input.getPurchaseDeviceInfo().getDeviceOfferExternalId(),
                input.getPurchaseOrderInfo().getOrderId(),
                input.getPurchaseDeviceInfo().getDeviceSku(), deviceAmount,
                input.getPurchaseDeviceInfo().getDeviceTaxDetails(),
                input.getPurchaseDeviceInfo().getDeviceDetails(), null, deviceGoodType,
                deviceTimestamp);
        chargeMethodData.setChargeMethod(CHARGE_METHOD_PAY_NOW);
        if (StringUtils.isNotEmpty(input.getPurchaseOrderInfo().getDeferredSettlement())) {
            chargeMethodData.setDeferredSettlement(
                    input.getPurchaseOrderInfo().getDeferredSettlement().equalsIgnoreCase("Y"));
            if (input.getPurchaseOrderInfo().getDeferredSettlementTimeout() != null) {
                chargeMethodData.setDeferredSettlementTimeout(
                        Long.valueOf(input.getPurchaseOrderInfo().getDeferredSettlementTimeout()));
            }
            if (input.getPurchaseOrderInfo().getDeferredSettlementTimeoutAction() != null) {
                chargeMethodData.setDeferredSettlementTimeoutAction(
                        Long.valueOf(
                                input.getPurchaseOrderInfo().getDeferredSettlementTimeoutAction()));
            }

        }
        multiReqPurchaseDevice.appendRequestList(
                getSubscriberPurchaseOfferRequest(searchData, chargeMethodData, deviceOfferData));
        multiIndex++;

        // 9. create purchase offer request for Visible_Device_Shipping with deviceAmount (charges
        // for total
        // device amount, incl tax). Add good_type and Info to purchase request
        // i. good_type = purchase_device (unique string to identify offer)
        // ii. Info = timestamp (unique identifier for transaction. add 1 to make sure it will not
        // be same as info for device purchase)

        String shippingTimestamp = ((new Date()).getTime() + 1) + "";

        String deviceShippingGoodType = AppPropertyProvider.getInstance().getString(
                DEVICE_CONSTANTS.DEVICE_DIRECT_PURCHASE_GOOD_TYPE_PURCHASE_SHIPPING);
        MtxPurchasedOfferData shippingOfferData = getPurchasedOfferData(
                input.getPurchaseShippingInfo().getShippingOfferExternalId(),
                input.getPurchaseOrderInfo().getOrderId(),
                input.getPurchaseShippingInfo().getShippingSku(), shippingAmount,
                input.getPurchaseShippingInfo().getShippingTaxDetails(), null, null,
                deviceShippingGoodType, shippingTimestamp);

        multiReqPurchaseDevice.appendRequestList(
                getSubscriberPurchaseOfferRequest(searchData, chargeMethodData, shippingOfferData));
        multiIndex++;

        // 10. If Bid change was done in previous steps then Revert it
        if (glCenterChanged) {
            multiReqPurchaseDevice.appendRequestList(
                    getSubscriberModifyRequest(searchData, origGlCenter));
            multiIndex++;
        }
        // 11. Send the multi-request to MATRIXX and receive the multi-response
        MtxResponseMulti multiRespPurchaseDevice = multiRequest(
                loggingKey, route, multiReqPurchaseDevice);

        if (multiRespPurchaseDevice == null
                || multiRespPurchaseDevice.getResult() != RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS) {
            Long resultCode = multiRespPurchaseDevice != null
                    ? multiRespPurchaseDevice.getResult()
                            : RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR;
                    String message = "Failed to purchase device " + (multiRespPurchaseDevice != null
                            ? " - " + multiRespPurchaseDevice.getResultText() : "");
                    WARN(m_logger, loggingKey + message);
                    throw new DeviceServiceException(resultCode, message);
        }

        // 12. Prepare the API response
        output.setResult(multiRespPurchaseDevice.getResult());
        output.setResultText(multiRespPurchaseDevice.getResultText());
        if ("Y".equalsIgnoreCase(input.getPurchaseOrderInfo().getDeferredSettlement())) {
            if (input.getPurchaseOrderInfo().getDeferredSettlementTimeout() != null) {
                output.setPaymentAuthorizationExpiryTime(
                        ZonedDateTime.now().plusHours(
                                input.getPurchaseOrderInfo().getDeferredSettlementTimeout()).format(
                                        DateTimeFormatter.ofPattern(
                                                DEVICE_CONSTANTS.DEVICE_DIRECT_PURCHASE_PAY_AUTH_EXPIRY_DATE_FORMAT)));
            } else {
                output.setPaymentAuthorizationExpiryTime(
                        ZonedDateTime.now().plusDays(
                                AppPropertyProvider.getInstance().getLong(
                                        DEVICE_CONSTANTS.DEVICE_DIRECT_PURCHASE_PAY_AUTH_EXPIRY)).format(
                                                DateTimeFormatter.ofPattern(
                                                        DEVICE_CONSTANTS.DEVICE_DIRECT_PURCHASE_PAY_AUTH_EXPIRY_DATE_FORMAT)));
            }
        }
        ArrayList<MtxResponse> responseList = multiRespPurchaseDevice.getResponseList();
        if (responseList != null && !responseList.isEmpty()) {
            // For service providing device purchases, determine the instance ID of the device
            // created and populate it in the response
            if (deviceType == DeviceType.sp) {
                if (responseList.get(createDeviceIndexTracker) instanceof MtxResponseCreate) {
                    MtxResponseCreate createResp = (MtxResponseCreate) responseList.get(
                            createDeviceIndexTracker);
                    if (createResp.getObjectId() != null) {
                        output.setDeviceInstanceId(createResp.getObjectId().toString());
                    }
                }
                if (output.getDeviceInstanceId() == null) {
                    WARN(m_logger, loggingKey + "Failed to determine device instance ID");
                }
            }
            // Populate Risk details in response from Recharge operation response
            if (responseList.get(1) instanceof MtxResponsePurchase) {
                MtxResponsePurchase purchaseDeviceResp = (MtxResponsePurchase) responseList.get(1);
                VisibleRiskData riskData = new VisibleRiskData();
                if (purchaseDeviceResp.getPaymentGatewayResponseAttr() != null) {
                    MtxBraintreeResponseExtension btr = ((MtxBraintreeResponseExtension) purchaseDeviceResp.getPaymentGatewayResponseAttr());

                    riskData.setRiskDataId(
                            (btr.getRiskDataId() != null) ? btr.getRiskDataId() : null);
                    riskData.setRiskDataDecision(
                            (btr.getRiskDataDecision() != null) ? btr.getRiskDataDecision() : null);
                    riskData.setRiskDataDeviceDataCaptured(
                            (btr.getRiskDataDeviceDataCaptured() != null)
                            ? (btr.getRiskDataDeviceDataCaptured() ? "0" : "1") : "1");
                } else {
                    riskData.setRiskDataId(null);
                    riskData.setRiskDataDecision(null);
                    riskData.setRiskDataDeviceDataCaptured("1");
                }
                output.setRiskData(riskData);
            }
            if (output.getRiskData() == null) {
                WARN(m_logger, loggingKey + "Failed to determine Risk Data");
            }
        }
    }

    /**
     * Return purchased device extension handler.
     *
     * @param input
     *            input
     * @param output
     *            output
     * @throws Exception
     */
    
public void returnPurchasedDevice(VisibleRequestReturnPurchasedDevice input,
        VisibleResponseReturnPurchasedDevice output)
                throws Exception {

    	// Setup the logging key
        String loggingKey = getLoggingKey(input.getSubscriberExternalId());

        // Determine routing data
        String route = getRoute(MatrixxContext.getRequest());

        // Validate the request
        requestValidator.validateRequest(loggingKey, input);        

        // Prepare subscriber search data
        MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
        searchData.setExternalId(input.getSubscriberExternalId());

        // Query purchase history for the subscriber for the original order date
        Map<String, MtxEvent> eventTable = querySubscriberPurchaseHistory(
                loggingKey, route, searchData,
                input.getReturnPurchaseOrderInfo().getOriginalOrderDate());

        if (eventTable == null || eventTable.isEmpty()) {
            throw new DeviceServiceException(
            		RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,
                    "Missing purchase history for subscriber");
        }

        String authEventId = null;
        Long refundBalanceResourceId = null;
        BigDecimal totalRefundAmount = BigDecimal.ZERO;
        StringBuilder adjReason = new StringBuilder();
        adjReason.append(CommonUtils.REVERSAL_PREFIX);
      
        String parentOrderId = null;
        
        //All individual orders should belong to same parent order - otherwise Error -- Check
        //All individual orders should have same payment authorization event id - Otherwise Error -- Check
        //If settlement event does not exist for some orders and exists for some other then - Error -- Check        
        //Search for settlement event 
        //If settlement event exists for all orders and authorization amount is less than sum of all order amounts then - Error -- Check
        //If settlement event exists for all orders and (settlement amount - Already refunded Amount) is less than sum of all order amounts then - Error -- Check
        //If settlement event exists for all orders and (settlement amount - Already refunded Amount) is more than sum of all order amounts then - Refund each order in a separate multi
        //If settlement event does not exist for any order and authorization amount matches sum of all order amounts then - void 
        
        //Future development - Discuss this with Matrixx / Gopal
        //Excluding shipping or any non-refundable amount from settled amount before refund.
        
        Map<String, PurchaseDeviceOrder> orderDetailsMap = new HashMap<String,PurchaseDeviceOrder>();
        Map<String, MtxRequestMulti> multiMap = new HashMap<String,MtxRequestMulti>();
        input.getReturnPurchaseOrderInfo().getOriginalOrderIds().forEach(ooi->{
        	orderDetailsMap.put(ooi, null);
        	multiMap.put(ooi, null);
        });
        
        List<MtxPurchaseEvent> purchaseEventsWithOffers = eventTable.values().stream().filter(event-> event instanceof MtxPurchaseEvent).map(event -> (MtxPurchaseEvent) event)
        		.filter(pe->pe.getAppliedOfferArray() != null && !pe.getAppliedOfferArray().isEmpty())
        		.collect(Collectors.toList());
		for (MtxPurchaseEvent purchaseEvent : purchaseEventsWithOffers) {
			Iterator<MtxEventAppliedOffer> itr = purchaseEvent.getAppliedOfferArray().iterator();
			MtxEventAppliedOffer offerInfo;
			VisiblePurchasedOfferExtension offerExtn;			

			// @formatter:off
			while (itr.hasNext()
					&& (offerInfo = itr.next()).getPurchasedOfferAttr() instanceof VisiblePurchasedOfferExtension
					&& (offerExtn = (VisiblePurchasedOfferExtension) offerInfo.getPurchasedOfferAttr()).getOrderId() != null
					&& input.getReturnPurchaseOrderInfo().getOriginalOrderIds().contains(offerExtn.getOrderId())
				  ) {
			// @formatter:on	
				if(orderDetailsMap.get(offerExtn.getOrderId())==null) {
					orderDetailsMap.put(offerExtn.getOrderId(), new PurchaseDeviceOrder(offerExtn.getOrderId()));	
				}				
				PurchaseDeviceOrder pdo = orderDetailsMap.get(offerExtn.getOrderId());					
				
				// Fetch the offerCatalog External Id and Validate it.
				String catalogItemExternalId = extractOfferCatalogExternalId(purchaseEvent, offerInfo);
				if (catalogItemExternalId == null) {
					throw new DeviceServiceException(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,
							LOG_OFFER_CATLOG_NOT_FOUND + " " + catalogItemExternalId);
				}
				// Only process offers that are allowed to be refunded
				if (isRefundableOffer(loggingKey, route, catalogItemExternalId)) {

					// Assumption: Refundable flag will take care of excluding Shipping and Shipping taxes.
					pdo.addRefundAmount(offerExtn.getChargeAmount());
					totalRefundAmount = totalRefundAmount.add(offerExtn.getChargeAmount());					
					
					DEBUG(m_logger, loggingKey + "Offer: " + offerInfo.getProductOfferExternalId()
							+ " is refundable. Refund amount: " + offerExtn.getChargeAmount());

					// Record the payment authorization event ID. 
					// And in case of multiple orders validate that payment authorization is same for all
					if (purchaseEvent.getPaymentAuthEventId() != null) {
						if(StringUtils.isNotBlank(authEventId) && !authEventId.equalsIgnoreCase(purchaseEvent.getPaymentAuthEventId())) {
							throw new DeviceServiceException(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,
									"All refunds should be from same payment authorization");
						}
						authEventId = purchaseEvent.getPaymentAuthEventId();
					}
					
					if (StringUtils.isNoneBlank(offerExtn.getParentOrderId())) {
						if(StringUtils.isNotBlank(parentOrderId) && !parentOrderId.equalsIgnoreCase(offerExtn.getParentOrderId())) {
							throw new DeviceServiceException(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,
									"All individual orders should belong to same parent order");
						}						
						parentOrderId = offerExtn.getParentOrderId();
						pdo.setParentOrderId(parentOrderId);
					}
					
					// Record the refund balance resource Id
					if (purchaseEvent.getBalanceUpdateArray() != null
							&& !purchaseEvent.getBalanceUpdateArray().isEmpty()) {
						refundBalanceResourceId = purchaseEvent.getAtBalanceUpdateArray(0).getBalanceResourceId();
						pdo.setRefundBalanceResourceId(refundBalanceResourceId);
					}

					// Append the event ID to the adjustment reason (required by the GL processor for return/reversal trigger)
					adjReason.append(" ").append(purchaseEvent.getEventId());
					pdo.appendEventIdToRefundAdjustmentReason(purchaseEvent.getEventId());
					
					// If there is a refund then we need to track BID. This should be be later
					// compared with subscribers homeBID
					if (purchaseEvent.getGlCenter() != null) {
						pdo.setShipToBid(purchaseEvent.getGlCenter());
						DEBUG(m_logger, loggingKey + "PurchaseEvent: " + purchaseEvent.getEventId()+" GLCenter: "+purchaseEvent.getGlCenter());
					}

				} else {
					DEBUG(m_logger, loggingKey + "Offer: " + offerInfo.getProductOfferExternalId()
							+ " is not refundable. Non-refund amount: " + offerExtn.getChargeAmount());
				}
			}
		}

		for(Entry<String, PurchaseDeviceOrder> entry : orderDetailsMap.entrySet()) {
	        if (entry.getValue()==null) {
	            throw new DeviceServiceException(
	            		RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,
	                    "Failed to find original order "+entry.getKey() +" for subscriber");
	        }
		}
		
        // Need to determine the payment resource ID if refund amount is greater than zero
        Long paymentResourceId = null;
        String settlementEventId = null;
        if (totalRefundAmount.signum() != 0) {
            if (authEventId == null) {
                throw new DeviceServiceException(
                		RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,
                        "Failed to determine original payment authorization event ID for subscriber");
            } else if (refundBalanceResourceId == null) {
                throw new DeviceServiceException(
                		RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,
                        "Failed to determine refund balance resource ID for subscriber");
            }

            // Query payment history for the subscriber
            DEBUG(m_logger, loggingKey + "Querying subscriber payment history in MATRIXX");
            MtxResponsePaymentHistory paymentHistory = querySubscriberPaymentHistory(
                    loggingKey, route, searchData);
            if (paymentHistory == null
                    || paymentHistory.getResult() != RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS) {
                Long resultCode = paymentHistory != null
                        ? paymentHistory.getResult()
                                : RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR;
                        String message = "Failed to query payment history for subscriber"
                                + (paymentHistory != null ? " - " + paymentHistory.getResultText() : "");
                        throw new DeviceServiceException(resultCode, message);
            }

            // Locate the payment info associated with the payment authorization event. This
            // contains the payment amount and the payment resource ID required for processing the
            // refund
            BigDecimal availableAmount = BigDecimal.ZERO;
            if (paymentHistory.getPaymentInfoList() != null
                    && !paymentHistory.getPaymentInfoList().isEmpty()) {
                for (MtxPaymentInfo paymentInfo : paymentHistory.getPaymentInfoList()) {
                    if (paymentInfo.getAuthorizationEventId().equals(authEventId)) {
                        paymentResourceId = paymentInfo.getResourceId();
                        settlementEventId = paymentInfo.getSettlementEventId();   
                        availableAmount = availableAmount.add(paymentInfo.getAuthorizationAmount());

                        if (paymentInfo.getAuthorizationAmount().compareTo(totalRefundAmount)<0) {
                            throw new DeviceServiceException(
                            		RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,
                                    "Refund amount more than authorization amount to return orders / devices for subscriber");
                        }
                        if(paymentInfo.getRefundInfoList() != null) {
                            for(MtxPaymentRefundInfo rInfo: paymentInfo.getRefundInfoList()) {
                            	//Account for any partial refunds in past
                            	availableAmount = availableAmount.subtract(rInfo.getRefundAmount());
                            }                        	
                        }

                        break;
                    }
                }
            }

            if (paymentResourceId == null) {
                throw new DeviceServiceException(
                		RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,
                        "Failed to determine payment resource ID for subscriber");
            }
            if (availableAmount.compareTo(totalRefundAmount)<0) {
                throw new DeviceServiceException(
                		RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,
                        "Not enough funds to return orders / devices for subscriber");
            }
            
            if (StringUtils.isBlank(settlementEventId) &&  availableAmount.compareTo(totalRefundAmount)>0) {
                throw new DeviceServiceException(
                		RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,
                        "Partial refund is not possible for deferred / not-settled payments.");
            }
            
            INFO(
                    m_logger,
                    loggingKey + "Refund - Balance resource ID: " + refundBalanceResourceId
                    + ", Amount: " + totalRefundAmount + ", Reason: " + adjReason
                    + ", Payment resource ID: " + paymentResourceId);
        } else {
            INFO(m_logger, loggingKey + "Refund amount is zero - no refund required");
        }
        
        MtxResponseSubscription subscriber = querySubscriptionData(loggingKey, input.getSubscriberExternalId());
        if (subscriber == null
                || subscriber.getResult() != RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS) {
            Long resultCode = subscriber != null
                    ? subscriber.getResult()
                            : RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR;
                    String message = "Failed to query subscriber"
                            + (subscriber != null ? " - " + subscriber.getResultText() : "");
                    throw new SubscriberServiceException(resultCode, message);
        }

        if(StringUtils.isBlank(settlementEventId)) {
            DEBUG(m_logger, loggingKey + "Creating return purchased device transaction for parent order id "+ parentOrderId);
            MtxRequestMulti multiReqReturnPurchasedDevice = new MtxRequestMulti();            

            // Add the main balance adjustment operation for the charged amount to the
            // multi-request
            multiReqReturnPurchasedDevice.appendRequestList(
                    getSubscriberAdjustBalanceRequest(
                            searchData, refundBalanceResourceId, totalRefundAmount,
                            adjReason.toString()));
            
            // Add the refund operation to the multi-request
            multiReqReturnPurchasedDevice.appendRequestList(
                    getSubscriberRefundRequest(
                            searchData, paymentResourceId, totalRefundAmount, REFUND_REASON,
                            adjReason.toString()));
            
            // Send the multi-request to MATRIXX and receive the multi-response
            MtxResponseMulti multiRespReturnPurchasedDevice = multiRequest(
                    loggingKey, route, multiReqReturnPurchasedDevice);
            if (multiRespReturnPurchasedDevice == null
                    || multiRespReturnPurchasedDevice.getResult() != RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS) {
                Long resultCode = multiRespReturnPurchasedDevice != null
                        ? multiRespReturnPurchasedDevice.getResult()
                                : RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR;
                        String message = "Failed to return purchased devices for ParentOrderId "+parentOrderId;                        
                        WARN(m_logger, loggingKey + message);                        
                        throw new DeviceServiceException(resultCode, message);
            }
            // Prepare the API response
            output.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
            output.setResultText("SubscriberExternalID: " + input.getSubscriberExternalId() + " Matrix Response: "+ MATRIXX_CONSTANTS.RESULT_TEXT_MTX_SUCCESS);
            return;            
        }
        
        Iterator<String> itr = input.getReturnPurchaseOrderInfo().getOriginalOrderIds().iterator();
        
        while (StringUtils.isNotBlank(settlementEventId) && itr.hasNext()) {
        	String homeBid = null;
        	String origOrderId = itr.next();
            // Create a multi-request containing all the operations required to handle the return
            // purchased device as a single transaction
            DEBUG(m_logger, loggingKey + "Creating return purchased device transaction for order id "+origOrderId);
            MtxRequestMulti multiReqReturnPurchasedDevice = new MtxRequestMulti();            
            multiMap.put(origOrderId, multiReqReturnPurchasedDevice);         	
            boolean glCenterChanged = false;
            String origGlCenter = null;
            PurchaseDeviceOrder orderDetails = orderDetailsMap.get(origOrderId);
            
            if (orderDetails.getRefundAmount().signum() != 0) {
                // If Ship-to-BID is not equal to Home-BID, modify subscriber to change GL Center to
                // Ship-to-BID
                if (subscriber.getGlCenter() != null) {
                    origGlCenter = subscriber.getGlCenter();
                }
            
                if (subscriber.getAttr() != null
                        && subscriber.getAttr() instanceof VisibleSubscriberExtension) {
                    homeBid = ((VisibleSubscriberExtension) subscriber.getAttr()).gethomeBID();
                    if (homeBid == null) {
                        WARN(m_logger, loggingKey + LOG_FAILED_TO_DETERMINE_HOME_BID);
                    } else {
                        if (!homeBid.equals(origGlCenter)) {
                            WARN(
                                    m_logger, loggingKey + "Subscriber data mismatch. GL Centre: "
                                            + origGlCenter + ", Home BID: " + homeBid);
                        }
                        DEBUG(m_logger, loggingKey + " ShipToBID: "+orderDetails.getShipToBid()+" origGlCenter"+origGlCenter);
                        if (orderDetails.getShipToBid() != null && (!orderDetails.getShipToBid().equals(homeBid) || homeBid == null)) {
                            DEBUG(
                                    m_logger,
                                    loggingKey + "Temporarily modifying subscriber GL Centre from "
                                            + origGlCenter + " to " + orderDetails.getShipToBid());
                            multiReqReturnPurchasedDevice.appendRequestList(
                                    getSubscriberModifyRequest(searchData, orderDetails.getShipToBid()));
                            glCenterChanged = true;
                        }
                    }
                } else {
                    WARN(m_logger, loggingKey + LOG_FAILED_TO_DETERMINE_HOME_BID);
                }
                
                // Add the main balance adjustment operation for the charged amount to the
                // multi-request
                multiReqReturnPurchasedDevice.appendRequestList(
                        getSubscriberAdjustBalanceRequest(
                                searchData, orderDetails.getRefundBalanceResourceId(), orderDetails.getRefundAmount(),
                                orderDetails.getRefundAdjustmentReason()));

                // Add the refund operation to the multi-request
                multiReqReturnPurchasedDevice.appendRequestList(
                        getSubscriberRefundRequest(
                                searchData, paymentResourceId, orderDetails.getRefundAmount(), REFUND_REASON,
                                orderDetails.getRefundAdjustmentReason()));
                
                //Undo GL center change
                if (glCenterChanged) {
                    multiReqReturnPurchasedDevice.appendRequestList(
                            getSubscriberModifyRequest(searchData, origGlCenter));
                }
     
            }
        }
               
        /*MtxRequestMulti multiReqReturnDisableDevice = getRemoveDeviceRequests(loggingKey, route, input.getSubscriberExternalId() 
        		,input.getReturnPurchaseOrderInfo().getDeviceInstanceIds(), subscriber.getDeviceIdArray());        
               
        if(multiMap.size() == 1) {
        	//If there is only one order to be returned, no need to have second transaction for disabling devices.
            if(multiReqReturnDisableDevice!=null&&multiReqReturnDisableDevice.getRequestList()!=null&&multiReqReturnDisableDevice.getRequestList().size()>0) {
            	for(MtxRequest req:multiReqReturnDisableDevice.getRequestList()) {
            		((MtxRequestMulti)multiMap.values().toArray()[0]).appendRequestList(req);
            	}
            }        	
        }*/
        
        List<String> returnedOrders = new ArrayList<String>();
        for(Entry<String, MtxRequestMulti> entry:multiMap.entrySet()) {
            // Send the multi-request to MATRIXX and receive the multi-response
            MtxResponseMulti multiRespReturnPurchasedDevice = multiRequest(
                    loggingKey, route, entry.getValue());
            if (multiRespReturnPurchasedDevice == null
                    || multiRespReturnPurchasedDevice.getResult() != RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS) {
                Long resultCode = multiRespReturnPurchasedDevice != null
                        ? multiRespReturnPurchasedDevice.getResult()
                                : RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR;
                        String message = ((returnedOrders.size()>0)?"Returned Orders:" + StringUtils.join(returnedOrders, ","):"") +"Failed to return purchased device "
                                + (multiRespReturnPurchasedDevice != null
                                ? " - " + multiRespReturnPurchasedDevice.getResultText() : "");
                        
                        WARN(m_logger, loggingKey + message);                        
                        throw new DeviceServiceException(resultCode, message);
            }else {
            	INFO(m_logger, loggingKey + entry.getKey() + " returned");
            	returnedOrders.add(entry.getKey());
            }
        }

        INFO(m_logger, loggingKey +  "All orders returned");                       

        // Prepare the API response
        output.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
        output.setResultText(MATRIXX_CONSTANTS.RESULT_TEXT_MTX_SUCCESS);
    }

	/**
	 * Method to get device disable and delete request for return purchansed device.
	 * @param loggingKey
	 * @param route
	 * @param subscriberExternalId
	 * @param removeDeviceInstanceIds
	 * @return
	 * @throws DeviceServiceException 
	 */
	/*private MtxRequestMulti getRemoveDeviceRequests(String loggingKey, String route, String subscriberExternalId, List<String> removeDeviceInstanceIds, List<MtxObjectId> subscriberDeviceInstanceIds) throws DeviceServiceException {
	    // Create a separate multi request for Device inactivation        
	    DEBUG(m_logger, loggingKey + "Creating multirequest to inactivate devices ");
	    MtxRequestMulti multiReqReturnDisableDevice = new MtxRequestMulti();            
        MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
        searchData.setExternalId(subscriberExternalId);
        List<String> normSdiidList = subscriberDeviceInstanceIds.stream().map(oid->oid.getId().replaceAll(":-:", "::").replaceAll("-", ":")).collect(Collectors.toList());
        DEBUG(m_logger, loggingKey + "normSdiidList: "+normSdiidList);
	    for(String iid: removeDeviceInstanceIds) {
	        // Put the remove and delete device operations to the multi-request if the purchase was for a service providing service
	    	String normRdiid = iid.replaceAll(":-:", "::").replaceAll("-", ":");	    	
	    	DEBUG(m_logger, loggingKey + "normRdiid: "+normRdiid);
	        if(normSdiidList.contains(iid)||normSdiidList.contains(normRdiid)) {
	            MtxObjectId deviceId = new MtxObjectId(iid);	            	            
	            // Query the device to determine whether device status need to be updated
	            // (device can not be deleted if active)
	            DEBUG(m_logger, loggingKey + "Querying device data in MATRIXX");
	            MtxResponseDevice device = queryDeviceData(loggingKey, route, deviceId);
	            if (device == null
	                    || device.getResult() != IntegrationService.RESULT_CODE_CUSTOM_SUCCESS) {
	                Long resultCode = device != null
	                        ? device.getResult() : IntegrationService.RESULT_CODE_CUSTOM_INTERNAL_ERROR;
	                        String message = "Failed to query device"
	                                + (device != null ? " - " + device.getResultText() : "");
	                        throw new DeviceServiceException(resultCode, message);                                        	
	            }	            
	            if ( device.getDeviceType() == DeviceType.sp.ordinal()) {
		            // Operation for removing the device from subscriber
		            multiReqReturnDisableDevice.appendRequestList(
		                    getSubscriberRemoveDeviceRequest(searchData, deviceId));
		
		            // Operation for modifying the device status if necessary
		            final Integer DEVICE_STATUS_ACTIVE = 1;
		            final Integer DEVICE_STATUS_INACTIVE = 2;
		            if (DEVICE_STATUS_ACTIVE.equals(device.getStatus())) {
		            	multiReqReturnDisableDevice.appendRequestList(
		                        getDeviceModifyRequest(deviceId, DEVICE_STATUS_INACTIVE));
		            }
		
		            // Operation for deleting the device and terminate any active sessions
		            multiReqReturnDisableDevice.appendRequestList(getDeviceDeleteRequest(deviceId));	            	
	            }	
	        }        	
	    }
	    DEBUG(m_logger, loggingKey + "multirequest to inactivate devices: "+multiReqReturnDisableDevice.toJson());
	    return multiReqReturnDisableDevice;
	}*/

    /**
     * Validates the response from Matrixx.
     *
     * @param originatingClass
     * @param loggingKey
     * @param errorContext
     * @param response
     * @throws DeviceServiceException
     *             if response is null or result code is not success.
     */
    protected void validateResponse(String loggingKey, String errorContext, MtxResponse response)
            throws DeviceServiceException

    {
        if (response == null) {
            WARN(m_logger, loggingKey + errorContext + " - response is null");
            throw new DeviceServiceException(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, errorContext);
        }
        if (!response.getResult().equals(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS)) {
            String message = errorContext + " - " + response.getResultText();
            WARN(m_logger, loggingKey + message);
            throw new DeviceServiceException(response.getResult(), message);
        }
    }

    /**
     * Queries the subscriber.
     *
     * @param loggingKey
     * @param route
     * @param searchData
     * @return
     * @throws DeviceServiceException
     *             if response is null or result code is not success.
     */
    protected MtxResponseSubscription getSubscriber(String loggingKey,
                                                  String route,
                                                  String subscriberExternalID)
                                                          throws DeviceServiceException {
        DEBUG(m_logger, loggingKey + DeviceService.LOG_QUERY_SUBSCRIBER_DATA_IN_MATRIXX);

        MtxResponseSubscription subscriber = querySubscriptionData(loggingKey, subscriberExternalID);
        validateResponse(loggingKey, LOG_FAILED_TO_QUERY_SUBSCRIBER, subscriber);
        return subscriber;
    }

    /**
     * Handles the Ship-to-BID. If Ship-to-BID is not equal to Home-BID, modify subscriber to change
     * GL Center to Ship-to-BID
     *
     * @param loggingKey
     *            the logging key
     * @param searchData
     *            the search data
     * @param subscriber
     *            the subscriber's object
     * @param multiReqFinanceDevice
     *            The Multi Request message
     * @param shipToBid
     *            the request Ship-to-BID
     * @return true if the GL Center change request was applied. Otherwise, false.
     */
    protected boolean handleShippingGLCenterChange(String loggingKey,
                                                   MtxSubscriberSearchData searchData,
                                                   MtxResponseSubscription subscriber,
                                                   MtxRequestMulti multiReqFinanceDevice,
                                                   String shipToBid) {
        String homeBid = null;
        String origGlCenter = CommonUtils.getSubscriberGlCenter(subscriber);
        if (subscriber.getAttr() != null
                && subscriber.getAttr() instanceof VisibleSubscriberExtension) {
            homeBid = ((VisibleSubscriberExtension) subscriber.getAttr()).gethomeBID();
            if (homeBid == null) {
                WARN(m_logger, loggingKey + LOG_FAILED_TO_DETERMINE_HOME_BID);
            } else {
                if (!homeBid.equals(origGlCenter)) {
                    WARN(
                            m_logger, loggingKey + "Subscriber data mismatch. GL Centre: "
                                    + origGlCenter + ", Home BID: " + homeBid);
                }
                if (shipToBid == null) {
                    WARN(m_logger, loggingKey + LOG_FAILED_TO_DETERMINE_SHIP_BID);
                } else if (!shipToBid.equals(homeBid)) {
                    DEBUG(
                            m_logger,
                            loggingKey + "Temporarily modifying subscriber GL Centre from "
                                    + origGlCenter + " to " + shipToBid);

                    multiReqFinanceDevice.appendRequestList(
                            getSubscriberModifyRequest(searchData, shipToBid));
                    return true;
                }
            }
        } else {
            WARN(m_logger, loggingKey + LOG_FAILED_TO_DETERMINE_HOME_BID);
        }

        return false;
    }

    /**
     * Device finance extension handler.
     *
     * @param input
     *            input
     * @param output
     *            output
     * @throws Exception
     */
    public void financeDevice(VisibleRequestFinanceDevice input,
                              VisibleResponseFinanceDevice output)
                                      throws Exception {

        int createDeviceIndexTracker = 0;
        int multiIndex = 0;
        MtxChargeMethodData chargeMethodOnAccount = new MtxChargeMethodData();
        chargeMethodOnAccount.setChargeMethod(1);// On account

        // Setup the logging key
        String loggingKey = getLoggingKey(input.getSubscriberExternalId());

        // Determine routing data
        String route = getRoute(MatrixxContext.getRequest());

        // Validate the request
        requestValidator.validateRequest(loggingKey, input);

        // 1. Calculate the device amount to add to Mainbalance
        // netDeviceAmount = DeviceDiscountPrice + DeviceTotalTax - DeviceFinanceAmount
        // grossDeviceAmount = DeviceDiscountPrice + DeviceTotalTax
        // 2. Calculate the fee amount to add to Mainbalance
        // feeAmount = DeviceFinanceAmount
        // 3. Calculate the shipping amount to add to Mainbalance
        // shippingAmount = ShippingDiscountPrice + ShippingTotalTax
        BigDecimal deviceDiscountPrice = new BigDecimal(
                input.getFinanceDeviceInfo().getDeviceDiscountPrice());

        BigDecimal deviceFinanceAmount = new BigDecimal(
                input.getFinanceDeviceInfo().getDeviceFinanceAmount());
        BigDecimal deviceTotalTax = new BigDecimal(
                input.getFinanceDeviceInfo().getDeviceTotalTax());
        BigDecimal netDeviceAmount = deviceDiscountPrice.add(deviceTotalTax).subtract(
                deviceFinanceAmount);
        BigDecimal deviceAmountPurchase = deviceDiscountPrice.add(deviceTotalTax);
        INFO(m_logger, loggingKey + "Device amount: " + netDeviceAmount);

        BigDecimal shippingDiscountPrice = new BigDecimal(
                input.getFinanceShippingInfo().getShippingDiscountPrice());
        BigDecimal shippingTotalTax = new BigDecimal(
                input.getFinanceShippingInfo().getShippingTotalTax());
        BigDecimal shippingAmount = shippingDiscountPrice.add(shippingTotalTax);
        INFO(m_logger, loggingKey + "Shipping amount: " + shippingAmount);

        // Prepare subscriber search data
        MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
        searchData.setExternalId(input.getSubscriberExternalId());

        // Query the subscriber data in MATRIXX
        MtxResponseSubscription subscriber = getSubscriber(loggingKey, route, input.getSubscriberExternalId());

        // Create a multi-request containing all the operations required to handle the device
        // finance as a single transaction
        DEBUG(m_logger, loggingKey + DeviceService.CREATE_FINANCE_DEVICE_TXN);
        MtxRequestMulti multiReqFinanceDevice = new MtxRequestMulti();

        // Setup mainbalance
        String setupOffer = AppPropertyProvider.getInstance().getString(
                OFFER_CONSTANTS.OFFER_PURCHASE_SETUP_MAINBALANCE_OFFER);
        MtxPurchasedOfferData setUpMainBalanceOfferData = getPurchasedOfferData(
                setupOffer, input.getFinanceOrderInfo().getOrderId(), null, BigDecimal.ZERO, null,
                null, null);
        multiReqFinanceDevice.appendRequestList(
                getSubscriberPurchaseOfferRequest(
                        searchData, chargeMethodOnAccount, setUpMainBalanceOfferData));
        multiIndex++;
        // If Ship-to-BID is not equal to Home-BID, modify subscriber to change GL Center to
        // Ship-to-BID
        String origGlCenter = CommonUtils.getSubscriberGlCenter(subscriber);
        boolean glCenterChanged = handleShippingGLCenterChange(
                loggingKey, searchData, subscriber, multiReqFinanceDevice,
                input.getFinanceShippingInfo().getShipToBid());
        if (glCenterChanged) {
            multiIndex++;
        }

        
        //Key for below fldMap should be name of a field o MDC VisiblePurchasedOffer 
        Map<String, String> devFldMap = new HashMap<String, String>();
        Map<String, String> shpFldMap = new HashMap<String, String>();
        Map<String, String> affirmFldMap = new HashMap<String, String>();
        Set<String> propSet = new HashSet<String>();
        Set<String> avoidSet = new HashSet<String>(Arrays.asList("container","mdcName","class","mdc"));
        
        for (PropertyDescriptor propertyDescriptor : Introspector.getBeanInfo(
        		VisiblePurchasedOfferExtension.class).getPropertyDescriptors()) {
        	//get list of values from Extension 
        	if(propertyDescriptor.getPropertyType()!=null && !avoidSet.contains(propertyDescriptor.getName())) {
        		propSet.add(propertyDescriptor.getName());        		
        	}
        }

        for (PropertyDescriptor propertyDescriptor : Introspector.getBeanInfo(
        		VisibleFinanceOrderInfo.class).getPropertyDescriptors()) {
        	//get list of matching values from input and add to extension
        	if(propertyDescriptor.getPropertyType()!=null && propSet.contains(propertyDescriptor.getName()) && !avoidSet.contains(propertyDescriptor.getName())) {
        		Method method = ReflectionUtils.findMethod(VisibleFinanceOrderInfo.class, "get"+StringUtils.capitalize(propertyDescriptor.getName()));
        		DEBUG( m_logger, loggingKey + "Get "+ StringUtils.capitalize(propertyDescriptor.getName())+" from "+VisibleFinanceOrderInfo.class.getSimpleName());
        		
        		devFldMap.put(StringUtils.capitalize(propertyDescriptor.getName()), (String)ReflectionUtils.invokeMethod(method,input.getFinanceOrderInfo()));
        		shpFldMap.put(StringUtils.capitalize(propertyDescriptor.getName()), (String)ReflectionUtils.invokeMethod(method,input.getFinanceOrderInfo()));
        		affirmFldMap.put(StringUtils.capitalize(propertyDescriptor.getName()), (String)ReflectionUtils.invokeMethod(method,input.getFinanceOrderInfo()));
        	}
        }

        for (PropertyDescriptor propertyDescriptor : Introspector.getBeanInfo(
        		VisibleFinanceDeviceInfo.class).getPropertyDescriptors()) {
        	//get list of matching values from input and add to extension
        	if(propertyDescriptor.getPropertyType()!=null && propSet.contains(propertyDescriptor.getName()) && !avoidSet.contains(propertyDescriptor.getName())) {
        		Method method = ReflectionUtils.findMethod(VisibleFinanceDeviceInfo.class, "get"+StringUtils.capitalize(propertyDescriptor.getName()));
        		DEBUG( m_logger, loggingKey + "Get "+ StringUtils.capitalize(propertyDescriptor.getName())+" from "+VisibleFinanceDeviceInfo.class.getSimpleName());
        		
        		devFldMap.put(StringUtils.capitalize(propertyDescriptor.getName()), (String)ReflectionUtils.invokeMethod(method,input.getFinanceDeviceInfo()));
        		shpFldMap.put(StringUtils.capitalize(propertyDescriptor.getName()), (String)ReflectionUtils.invokeMethod(method,input.getFinanceDeviceInfo()));
        		affirmFldMap.put(StringUtils.capitalize(propertyDescriptor.getName()), (String)ReflectionUtils.invokeMethod(method,input.getFinanceDeviceInfo()));
        		
        	}
        } 
        
        // Add new variable to capture timestamp
        // 4a. Capture a high precision timestamp (at least milliseconds)
        // 4b. Call MtxRequestSubscriberPurchaseOffer for Visible_Device_Finance_Fee with feeAmount
        // (grants fee to Mainbalance)
        // i. GoodType = affirm_fee
        // ii. Info = timestamp
        // feeAmount should not be negated.
        String feeTimestamp = (new Date()).getTime() + "";

        affirmFldMap.put("Sku", input.getFinanceDeviceInfo().getDeviceSku());
        affirmFldMap.put("ChargeAmount", deviceFinanceAmount.toPlainString());
        affirmFldMap.put("GoodType", AppPropertyProvider.getInstance().getString(DEVICE_CONSTANTS.DEVICE_FINANCE_PURCHASE_GOOD_TYPE_AFFIRM_FEE));
        affirmFldMap.put("Info", feeTimestamp.toString());        
        affirmFldMap.put("TaxDetails", getShippingGeoCodeAsTaxString(loggingKey, input));
        
        MtxPurchasedOfferData deviceFinanceOfferData = CommonUtils.getPurchasedOfferData(
        		AppPropertyProvider.getInstance().getString(OFFER_CONSTANTS.OFFER_EXTERNAL_ID_DEVICE_FINANCE_FEE), 
        		affirmFldMap);
        multiReqFinanceDevice.appendRequestList(

                getSubscriberPurchaseOfferRequest(
                        searchData, chargeMethodOnAccount, deviceFinanceOfferData));
        multiIndex++;

        // 4c. Capture a high precision timestamp (at least milliseconds)
        // 4d. Call MtxRequestSubscriberRecharge with deviceAmount (grants net device amount to
        // Mainbalance, incl tax)
        // i. Reason = finance_device
        // ii. Info = timestamp
        // Add a sequence number to the TS value going into the InfoTimeStamp field. The timestamp
        // value is not granular enough (things take less than 1 ms) to generate a unique value to
        // link the recharge and the purchase. So instead of generating a second timestamp via a
        // call for the shipping InfoTimeStamp value and maybe getting the same value, just add an
        // incrementor digit.
        // For example if TS = 1532910607654, recharge/device purchase InfoTimeStamp =
        // 1532910607655, recharge/shipping purchase InfoTimeStamp = 1532910607656

        BigInteger deviceTimestamp = new BigInteger(((new Date()).getTime() + 1) + "");
        multiReqFinanceDevice.appendRequestList(
                CommonUtils.getSubscriberRechargeRequest(
                        searchData, chargeMethodOnAccount,
                        AppPropertyProvider.getInstance().getString(
                                DEVICE_CONSTANTS.DEVICE_FINANCE_PURCHASE_REASON_FINANCE_DEVICE),
                        deviceTimestamp.toString(), netDeviceAmount,input.getFinanceOrderInfo().getOrderId()));
        multiIndex++;

        // Add the device create and link operations to the multi-request if the finance is for
        // a service providing device
        DeviceType deviceType = DeviceType.valueOf(
                input.getFinanceDeviceInfo().getDeviceProvidesService());

        if (deviceType == DeviceType.sp) {
            // Operation for creating the device
            createDeviceIndexTracker = multiIndex;
            multiReqFinanceDevice.appendRequestList(
                    getDeviceCreateRequest(
                            input.getFinanceDeviceInfo().getDeviceAccessNumber(),
                            input.getFinanceDeviceInfo().getDeviceIMSI()));
            multiIndex++;
            // Operation for adding the device to the subscriber
            multiReqFinanceDevice.appendRequestList(
                    getSubscriberAddDeviceRequest(searchData, createDeviceIndexTracker));
            multiIndex++;
        }

        // 4e. Call MtxRequestSubscriberPurchaseOffer for Visible_Device with deviceAmount (charges
        // for total device amount, incl tax)
        // i. GoodType = finance_device
        // ii. Info = timestamp       
        
      //get list of values from input that do not match with extension attribute names and add to extension
        devFldMap.put("Sku", input.getFinanceDeviceInfo().getDeviceSku());
        devFldMap.put("ChargeAmount", deviceAmountPurchase.toPlainString());
        devFldMap.put("GoodType", AppPropertyProvider.getInstance().getString(DEVICE_CONSTANTS.DEVICE_FINANCE_PURCHASE_GOOD_TYPE_FINANCE_DEVICE));
        devFldMap.put("Info", deviceTimestamp.toString());        
        devFldMap.put("TaxDetails", input.getFinanceDeviceInfo().getDeviceTaxDetails());
                       
        MtxPurchasedOfferData deviceOfferData = CommonUtils.getPurchasedOfferData(input.getFinanceDeviceInfo().getDeviceOfferExternalId(), devFldMap);
        multiReqFinanceDevice.appendRequestList(
                getSubscriberPurchaseOfferRequest(
                        searchData, chargeMethodOnAccount, deviceOfferData));
        multiIndex++;

        // 4f. Capture a high precision timestamp (at least milliseconds)
        // 4g. Call MtxRequestSubscriberRecharge with shippingAmount (grants shipping amount to
        // Mainbalance)
        // i. Reason = finance_shipping
        // ii. Info = timestamp
        // Add a sequence number to the TS value going into the InfoTimeStamp field. The timestamp
        // value is not granular enough (things take less than 1 ms) to generate a unique value to
        // link the recharge and the purchase. So instead of generating a second timestamp via a
        // call for the shipping InfoTimeStamp value and maybe getting the same value, just add an
        // incrementor digit.
        // For example if TS = 1532910607654, recharge/device purchase InfoTimeStamp =
        // 1532910607655, recharge/shipping purchase InfoTimeStamp = 1532910607656
        BigInteger shippingTimestamp = new BigInteger(((new Date()).getTime() + 2) + "");       
        multiReqFinanceDevice.appendRequestList(
                CommonUtils.getSubscriberRechargeRequest(
                        searchData, chargeMethodOnAccount,
                        AppPropertyProvider.getInstance().getString(
                                DEVICE_CONSTANTS.DEVICE_FINANCE_PURCHASE_REASON_FINANCE_SHIPPING),
                        shippingTimestamp.toString(), shippingAmount,input.getFinanceOrderInfo().getOrderId()));
        multiIndex++;
        /**
         * 4h. Call MtxRequestSubscriberPurchaseOffer for Visible_Device_Shipping with
         * shippingAmount (charges shipping amount) i. GoodType = finance_shipping ii. Info =
         * timestamp
         */
      
        
        //shpFldMap.put("OrderId", input.getFinanceOrderInfo().getOrderId());
        //shpFldMap.put("ChargeId", input.getFinanceOrderInfo().getChargeId());       
        shpFldMap.put("Sku", input.getFinanceShippingInfo().getShippingSku());
        shpFldMap.put("ChargeAmount", shippingAmount.toPlainString());
        shpFldMap.put("GoodType", AppPropertyProvider.getInstance().getString(DEVICE_CONSTANTS.DEVICE_FINANCE_PURCHASE_GOOD_TYPE_FINANCE_SHIPPING));
        shpFldMap.put("Info", shippingTimestamp.toString());        
        shpFldMap.put("TaxDetails", input.getFinanceShippingInfo().getShippingTaxDetails());
        //shpFldMap.put("DeviceDetails", input.getFinanceDeviceInfo().getDeviceDetails());        
                       
        MtxPurchasedOfferData shippingOfferData = CommonUtils.getPurchasedOfferData(input.getFinanceShippingInfo().getShippingOfferExternalId(), shpFldMap);

        multiReqFinanceDevice.appendRequestList(
                getSubscriberPurchaseOfferRequest(
                        searchData, chargeMethodOnAccount, shippingOfferData));
        multiIndex++;
        // 6. if Ship-to-BID is not equal to Home-BID, modify subscriber to change GL Center back to
        // Home-BID
        // if (homeBid != null && !input.getFinanceShippingInfo().getShipToBid().equals(homeBid)) {
        if (glCenterChanged) {
            multiReqFinanceDevice.appendRequestList(
                    getSubscriberModifyRequest(searchData, origGlCenter));
            multiIndex++;
        }
        
        multiReqFinanceDevice.setApiEventData(input.getApiEventData());
        // Send the multi-request to MATRIXX and receive the multi-response
        MtxResponseMulti multiRespFinanceDevice = multiRequest(
                loggingKey, route, multiReqFinanceDevice);
        validateResponse(loggingKey, LOG_FAILED_TO_FINANCE_DEVICE, multiRespFinanceDevice);

        // Prepare the API response
        output.setResult(multiRespFinanceDevice.getResult());
        output.setResultText("SubscriberExternalID: "+subscriber.getExternalId()+" Matrix Response: "+multiRespFinanceDevice.getResultText());

        ArrayList<MtxResponse> responseList = multiRespFinanceDevice.getResponseList();
        if (responseList != null && !responseList.isEmpty()) {
            // For service providing device purchases, determine the instance ID of the device
            // created and populate it in the response
            if (deviceType == DeviceType.sp) {
                if (responseList.get(createDeviceIndexTracker) instanceof MtxResponseCreate) {
                    MtxResponseCreate createResp = (MtxResponseCreate) responseList.get(
                            createDeviceIndexTracker);
                    if (createResp.getObjectId() != null) {
                        output.setDeviceInstanceId(createResp.getObjectId().toString());
                    }
                }
                if (output.getDeviceInstanceId() == null) {
                    WARN(
                            m_logger,
                            loggingKey + DeviceService.FAILED_TO_DETERMINE_DEVICE_INSTANCE_ID);
                }
            }
        }
    }

    /**
     * Get shipping geocode as jsonString to set it as taxString
     *
     * @param geoCode
     * @return
     */
    private String getShippingGeoCodeAsTaxString(String loggingKey,
                                                 VisibleRequestFinanceDevice input) {
        JsonObject geoCodeAsTaxDetail = new JsonObject();
        String geoCodeAsTaxString = null;
        String shippingGeoCodeKey = AppPropertyProvider.getInstance().getString(
                DEVICE_CONSTANTS.DEVICE_FINANCE_PURCHASE_SHIPPING_GEOCODE_KEY);
        if (!StringUtils.isEmpty(input.getFinanceShippingInfo().getShippingGeocode())
                && shippingGeoCodeKey != null) {
            geoCodeAsTaxDetail.addProperty(
                    AppPropertyProvider.getInstance().getString(
                            DEVICE_CONSTANTS.DEVICE_FINANCE_PURCHASE_SHIPPING_GEOCODE_KEY),
                    input.getFinanceShippingInfo().getShippingGeocode());
            geoCodeAsTaxString = geoCodeAsTaxDetail.toString();
            DEBUG(
                    m_logger,
                    loggingKey + "Shipping GeoCode is available so setting it as TaxString "
                            + geoCodeAsTaxString);
        } else if (shippingGeoCodeKey == null) {
            DEBUG(
                    m_logger,
                    loggingKey + "Shipping GeoCode key is not available in rsgateway.properties ");
        } else if (StringUtils.isEmpty(input.getFinanceShippingInfo().getShippingGeocode())) {
            DEBUG(
                    m_logger,
                    loggingKey + "Shipping GeoCode is not available in the input request ");
        }
        return geoCodeAsTaxString;
    }

    /**
     * Return financed device extension handler.
     *
     * @param input
     *            input
     * @param output
     *            output
     * @throws Exception
     */
    public void returnFinancedDevice(VisibleRequestReturnFinancedDevice input,
                                     VisibleResponseReturnFinancedDevice output)
                                             throws Exception {

        // Setup the logging key
        String loggingKey = getLoggingKey(input.getSubscriberExternalId());

        // Determine routing data
        String route = getRoute(MatrixxContext.getRequest());

        // Validate the request
        requestValidator.validateRequest(loggingKey, input);

        // Prepare subscriber search data
        MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
        searchData.setExternalId(input.getSubscriberExternalId());

        // Query purchase history for the subscriber for the original order date
        Map<String, MtxEvent> eventTable = querySubscriberPurchaseHistory(
                loggingKey, route, searchData,
                input.getReturnFinanceOrderInfo().getOriginalOrderDate());

        if (eventTable == null || eventTable.isEmpty()) {
            throw new DeviceServiceException(
            		RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,
                    "Missing purchase history for subscriber");
        }

        // Locate the original purchase event(s) with the matching order ID to obtain the associated
        // payment authorization event ID. Also determine the refund balance resource ID and the
        // refund amount and build the adjustment reason.
        // String authEventId = null;
        Long refundBalanceResourceId = null;
        BigDecimal refundAmount = BigDecimal.ZERO;
        String adjReason = CommonUtils.REVERSAL_PREFIX;
        boolean originalOrderFound = false;
        String homeBid = null;
        String shipToBid = null;

        ArrayList<ArrayList<String>> purEventMetadataList = new ArrayList<ArrayList<String>>();
        ArrayList<String> reversibleOffers = new ArrayList<String>();
        reversibleOffers.add(
                AppPropertyProvider.getInstance().getString(
                        OFFER_CONSTANTS.OFFER_EXTERNAL_ID_DEVICE_FINANCE_FEE));
        reversibleOffers.add(
                AppPropertyProvider.getInstance().getString(
                        OFFER_CONSTANTS.OFFER_EXTERNAL_ID_VISIBLE_DEVICE));

        for (MtxEvent event : eventTable.values()) {
            if (event instanceof MtxPurchaseEvent) {
                MtxPurchaseEvent purchaseEvent = (MtxPurchaseEvent) event;
                if (purchaseEvent.getAppliedOfferArray() != null
                        && !purchaseEvent.getAppliedOfferArray().isEmpty()) {
                    for (MtxEventAppliedOffer offerInfo : purchaseEvent.getAppliedOfferArray()) {
                        MtxPurchasedOfferExtension extn = offerInfo.getPurchasedOfferAttr();
                        if (extn instanceof VisiblePurchasedOfferExtension) {
                            VisiblePurchasedOfferExtension offerExtn = (VisiblePurchasedOfferExtension) extn;

                            if (offerExtn.getOrderId() != null && offerExtn.getOrderId().equals(
                                    input.getReturnFinanceOrderInfo().getOriginalOrderId())) {
                                // Fetch the offerCatalog External Id and Validate it.
                                String catalogItemExternalId = extractOfferCatalogExternalId(event, offerInfo);
                                if(catalogItemExternalId == null) {
                                    throw new DeviceServiceException(
                                    		RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,
                                            LOG_OFFER_CATLOG_NOT_FOUND);
                                }
                                // Only process offers that are allowed to be refunded
                                if (isRefundableOffer(
                                        loggingKey, route, catalogItemExternalId)) {
                                    // Assumption: Refundable flag will take care of excluding
                                    // Shipping and Shipping taxes.
                                    refundAmount = refundAmount.add(offerExtn.getChargeAmount());
                                    DEBUG(
                                            m_logger,
                                            loggingKey + "Offer: "
                                                    + offerInfo.getProductOfferExternalId()
                                                    + " is refundable. Refund amount: "
                                                    + offerExtn.getChargeAmount());

                                    // Record the refund balance resource Id
                                    if (purchaseEvent.getBalanceUpdateArray() != null
                                            && !purchaseEvent.getBalanceUpdateArray().isEmpty()) {
                                        refundBalanceResourceId = purchaseEvent.getAtBalanceUpdateArray(
                                                0).getBalanceResourceId();
                                    }

                                    // If there is a refund then we need to track BID. This should
                                    // be be later compared with subscribers homeBID
                                    if (purchaseEvent.getGlCenter() != null) {
                                        shipToBid = purchaseEvent.getGlCenter();
                                    }

                                } else {
                                    DEBUG(
                                            m_logger,
                                            loggingKey + "Offer: "
                                                    + offerInfo.getProductOfferExternalId()
                                                    + " is not refundable. Non-refund amount: "
                                                    + offerExtn.getChargeAmount());
                                }
                                originalOrderFound = true;

                                if (reversibleOffers.contains(
                                        offerInfo.getProductOfferExternalId())) {
                                    adjReason = adjReason + ' ' + purchaseEvent.getEventId();
                                    ArrayList<String> purEventMetadata = new ArrayList<String>();
                                    purEventMetadata.add(offerInfo.getProductOfferExternalId());
                                    purEventMetadata.add(offerExtn.getGoodType());
                                    purEventMetadata.add(offerExtn.getInfo());
                                    purEventMetadataList.add(purEventMetadata);
                                }
                            }
                        }
                    }
                }
            }
        }

        if (purEventMetadataList.size() > 0) {
            for (MtxEvent event : eventTable.values()) {
                if (event instanceof MtxRechargeEvent) {
                    MtxRechargeEvent rechargeEvent = (MtxRechargeEvent) event;
                    for (ArrayList<String> purMetadata : purEventMetadataList) {
                        if (purMetadata.get(1).equals(rechargeEvent.getReason())
                                && purMetadata.get(2).equals(rechargeEvent.getInfo())) {
                            adjReason = adjReason + ' ' + rechargeEvent.getEventId();
                        }

                    }
                }
            }
        }

        if (!originalOrderFound) {
            throw new DeviceServiceException(
            		RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,
                    "Failed to find original order for subscriber");
        }

        if (refundAmount.signum() != 0) {

            if (refundBalanceResourceId == null) {
                throw new DeviceServiceException(
                		RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,
                        "Failed to determine refund balance resource ID for subscriber");
            }

            // Query payment history for the subscriber
            DEBUG(m_logger, loggingKey + "Querying subscriber payment history in MATRIXX");

            INFO(
                    m_logger,
                    loggingKey + "Refund - Balance resource ID: " + refundBalanceResourceId
                    + ", Amount: " + refundAmount + ", Reason: " + adjReason);
        } else {
            INFO(m_logger, loggingKey + "Refund amount is zero - no refund required");
        }

        // Create a multi-request containing all the operations required to handle the return
        // purchased device as a single transaction
        DEBUG(m_logger, loggingKey + "Creating return purchased device transaction");
        MtxRequestMulti multiReqReturnFinancedDevice = new MtxRequestMulti();
        String origGlCenter = null;
        boolean glCenterChanged = false;
        if (refundAmount.signum() != 0) {

            MtxResponseSubscription subscriber = querySubscriptionData(loggingKey, input.getSubscriberExternalId());
            if (subscriber == null
                    || subscriber.getResult() != RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS) {
                Long resultCode = subscriber != null
                        ? subscriber.getResult()
                                : RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR;
                        String message = "Failed to query subscriber"
                                + (subscriber != null ? " - " + subscriber.getResultText() : "");
                        throw new SubscriberServiceException(resultCode, message);
            }

            // If Ship-to-BID is not equal to Home-BID, modify subscriber to change GL Center to
            // Ship-to-BID
            if (subscriber.getGlCenter() != null) {
                origGlCenter = subscriber.getGlCenter();
            }
            if (subscriber.getAttr() != null
                    && subscriber.getAttr() instanceof VisibleSubscriberExtension) {
                homeBid = ((VisibleSubscriberExtension) subscriber.getAttr()).gethomeBID();
                if (homeBid == null) {
                    WARN(m_logger, loggingKey + LOG_FAILED_TO_DETERMINE_HOME_BID);
                } else {
                    if (!homeBid.equals(origGlCenter)) {
                        WARN(
                                m_logger, loggingKey + "Subscriber data mismatch. GL Centre: "
                                        + origGlCenter + ", Home BID: " + homeBid);
                    }
                    if (shipToBid != null && (!shipToBid.equals(homeBid) || homeBid == null)) {
                        DEBUG(
                                m_logger,
                                loggingKey + "Temporarily modifying subscriber GL Centre from "
                                        + origGlCenter + " to " + shipToBid);
                        multiReqReturnFinancedDevice.appendRequestList(
                                getSubscriberModifyRequest(searchData, shipToBid));
                        glCenterChanged = true;
                    }
                }
            } else {
                WARN(m_logger, loggingKey + LOG_FAILED_TO_DETERMINE_HOME_BID);
            }

            // 1. Add the main balance adjustment operation for the charged amount to the
            // multi-request
            // Note: For returns, the adjustment amount should be hard coded to $0. The
            // gl_processor figures out what the amount should be from the original events.
            multiReqReturnFinancedDevice.appendRequestList(
                    getSubscriberAdjustBalanceRequest(
                            searchData, refundBalanceResourceId,
                            BigDecimal.ZERO.setScale(BRAINTREE_CONSTANTS.BT_AMOUNT_PRECISION), adjReason));

        }

        // 4. Add the remove and delete device operations to the multi-request if the purchase was
        // for a service providing device
        DeviceType deviceType = DeviceType.valueOf(
                input.getReturnFinanceOrderInfo().getDeviceProvidesService());

        if (deviceType == DeviceType.sp) {
            MtxObjectId deviceId = new MtxObjectId(
                    input.getReturnFinanceOrderInfo().getDeviceInstanceId());

            // Query the device to determine whether device status need to be updated
            // (device can not be deleted if active)
            DEBUG(m_logger, loggingKey + "Querying device data in MATRIXX");
            MtxResponseDevice device = queryDeviceData(loggingKey, route, deviceId);
            if (device == null
                    || device.getResult() != RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS) {
                Long resultCode = device != null
                        ? device.getResult() : RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR;
                        String message = "Failed to query subscriber"
                                + (device != null ? " - " + device.getResultText() : "");
                        throw new DeviceServiceException(resultCode, message);
            }

            // Operation for removing the device from subscriber
            multiReqReturnFinancedDevice.appendRequestList(
                    getSubscriberRemoveDeviceRequest(searchData, deviceId));

            // Operation for modifying the device status if necessary
            final Integer DEVICE_STATUS_ACTIVE = 1;
            final Integer DEVICE_STATUS_INACTIVE = 2;
            if (DEVICE_STATUS_ACTIVE.equals(device.getStatus())) {
                multiReqReturnFinancedDevice.appendRequestList(
                        getDeviceModifyRequest(deviceId, DEVICE_STATUS_INACTIVE));
            }

            // Operation for deleting the device and terminate any active sessions
            multiReqReturnFinancedDevice.appendRequestList(getDeviceDeleteRequest(deviceId));
        }
        // If Ship-to-BID is not equal to Home-BID, modify subscriber to change GL Center back to
        // Home-BID.
        // This is to revert BID change if it was applied due to difference in home and ship-to
        // addresses
        // These two are tightly linked steps. These are workaround steps.
        // if (shipToBid != null && (!shipToBid.equals(homeBid) || homeBid == null)) {
        if (glCenterChanged) {
            multiReqReturnFinancedDevice.appendRequestList(
                    getSubscriberModifyRequest(searchData, origGlCenter));
        }
        // Send the multi-request to MATRIXX and receive the multi-response
        MtxResponseMulti multiRespReturnFinancedDevice = multiRequest(
                loggingKey, route, multiReqReturnFinancedDevice);

        if (multiRespReturnFinancedDevice == null
                || multiRespReturnFinancedDevice.getResult() != RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS) {
            Long resultCode = multiRespReturnFinancedDevice != null
                    ? multiRespReturnFinancedDevice.getResult()
                            : RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR;
                    String message = "Failed to return financed device "
                            + (multiRespReturnFinancedDevice != null
                            ? " - " + multiRespReturnFinancedDevice.getResultText() : "");
                    WARN(m_logger, loggingKey + message);
                    throw new DeviceServiceException(resultCode, message);
        }

        // Prepare the API response
        output.setResult(multiRespReturnFinancedDevice.getResult());
        output.setResultText(multiRespReturnFinancedDevice.getResultText());
    }

    private String getAdjustmentReason(Map<String, Object> eventData) {
        Set<String> origEventIds = (Set<String>) eventData.get(EVENT_IDS);
        String adjReason = CommonUtils.getReversalDetails(origEventIds);
        return adjReason;
    }

    private Map<String, Object> getEventData(String loggingKey,
                                             String route,
                                             List<String> reversibleOffers,
                                             Map<String, MtxEvent> eventTable,
                                             String originalOrderId)
                                                     throws DeviceServiceException {
        Map<String, Object> retMap = new HashMap<String, Object>();
        ArrayList<Map<String, String>> purEventMetadataList = new ArrayList<Map<String, String>>();
        BigDecimal refundableAmount = BigDecimal.ZERO;
        boolean originalOrderFound = false;
        Long refundBalanceResourceId = null;
        String authEventId = null;
        String shipToBid = null;
        Set<String> eventIds = new HashSet<String>();

        for (MtxEvent event : eventTable.values()) {
            if (event instanceof MtxPurchaseEvent) {
                MtxPurchaseEvent purchaseEvent = (MtxPurchaseEvent) event;
                if (purchaseEvent.getAppliedOfferArray() != null
                        && !purchaseEvent.getAppliedOfferArray().isEmpty()) {
                    for (MtxEventAppliedOffer offerInfo : purchaseEvent.getAppliedOfferArray()) {

                        MtxPurchasedOfferExtension extn = offerInfo.getPurchasedOfferAttr();
                        if (extn instanceof VisiblePurchasedOfferExtension) {
                            VisiblePurchasedOfferExtension offerExtn = (VisiblePurchasedOfferExtension) extn;

                            if (offerExtn.getOrderId() != null
                                    && offerExtn.getOrderId().equals(originalOrderId)) {
                                // Fetch the offerCatalog External Id and Validate it.
                                String catalogItemExternalId = extractOfferCatalogExternalId(event, offerInfo);
                                if(catalogItemExternalId == null) {
                                    throw new DeviceServiceException(
                                    		RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,
                                            LOG_OFFER_CATLOG_NOT_FOUND);
                                }
                                // Only process offers that are allowed to be refunded
                                if (isRefundableOffer(
                                        loggingKey, route, catalogItemExternalId)) {
                                    // Assumption: Refundable flag will take care of excluding
                                    // Shipping and Shipping taxes.
                                    refundableAmount = refundableAmount.add(
                                            offerExtn.getChargeAmount());
                                    DEBUG(
                                            m_logger,
                                            loggingKey + "Offer: "
                                                    + offerInfo.getProductOfferExternalId()
                                                    + " is refundable. Refund amount: "
                                                    + offerExtn.getChargeAmount());

                                    // Record the refund balance resource Id
                                    if (purchaseEvent.getBalanceUpdateArray() != null
                                            && !purchaseEvent.getBalanceUpdateArray().isEmpty()) {
                                        refundBalanceResourceId = purchaseEvent.getAtBalanceUpdateArray(
                                                0).getBalanceResourceId();
                                    }

                                    // If there is a refund then we need to track BID. This should
                                    // be be later compared with subscribers homeBID
                                    if (purchaseEvent.getGlCenter() != null) {
                                        shipToBid = purchaseEvent.getGlCenter();
                                    }

                                    // Record the payment authorization event ID
                                    if (purchaseEvent.getPaymentAuthEventId() != null) {
                                        authEventId = purchaseEvent.getPaymentAuthEventId();
                                    }

                                } else {
                                    DEBUG(
                                            m_logger,
                                            loggingKey + "Offer: "
                                                    + offerInfo.getProductOfferExternalId()
                                                    + " is not refundable. Non-refund amount: "
                                                    + offerExtn.getChargeAmount());
                                }
                                originalOrderFound = true;

                                if (reversibleOffers.contains(
                                        offerInfo.getProductOfferExternalId())) {
                                    eventIds.add(purchaseEvent.getEventId());
                                    Map<String, String> purEventData = new HashMap<String, String>();
                                    purEventData.put(
                                            EXTERNAL_ID, offerInfo.getProductOfferExternalId());
                                    purEventData.put(GOOD_TYPE, offerExtn.getGoodType());
                                    purEventData.put(INFO, offerExtn.getInfo());
                                    purEventMetadataList.add(purEventData);
                                }
                            }
                        }
                    }
                }
            }
        }

        StringBuffer rechargeReason = new StringBuffer("");
        if (purEventMetadataList.size() > 0) {
            for (MtxEvent event : eventTable.values()) {
                if (event instanceof MtxRechargeEvent) {
                    MtxRechargeEvent rechargeEvent = (MtxRechargeEvent) event;
                    for (Map<String, String> purEventData : purEventMetadataList) {
                        if (purEventData.get(INFO).equals(rechargeEvent.getInfo())) {
                            eventIds.add(rechargeEvent.getEventId());
                            rechargeReason.append(rechargeEvent.getReason() + "|");
                            if (authEventId == null) {
                                authEventId = rechargeEvent.getPaymentAuthEventId();
                            }
                        }
                    }
                }
            }
        }

        if (!originalOrderFound) {
            throw new DeviceServiceException(
            		RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,
                    FAILED_TO_FIND_ORIG_ORDER);
        }

        if (refundableAmount.signum() != 0 && refundBalanceResourceId == null) {
            throw new DeviceServiceException(
            		RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,
                    FAILED_TO_FIND_BALANCE_RESOURCE_ID);
        }

        retMap.put(EVENT_SUMMARY, purEventMetadataList);
        retMap.put(EVENT_IDS, eventIds);
        retMap.put(SHIP_TO_BID, shipToBid);
        retMap.put(BALANCE_RESOURCE_ID, refundBalanceResourceId);
        retMap.put(REFUNDABLE_AMOUNT, refundableAmount);
        retMap.put(RECHARGE_REASON, rechargeReason.toString());
        if (authEventId != null) {
            retMap.put(AUTH_EVENT_ID, authEventId);
        }
        return retMap;

    }

    /**
     * Returns the External Id of the catalog item associated with an offer.
     * @param event
     * @param offerInfo
     * @return
     */
    private String extractOfferCatalogExternalId(MtxEvent event, MtxEventAppliedOffer offerInfo) {
        Integer catalogIetmIndex = offerInfo.getAppliedCatalogItemIndex();
        String catalogItemExternalId = null;
        if(catalogIetmIndex > -1) {
            MtxEventAppliedCatalogItem catalogItem = ((MtxPurchaseEvent) event).getAtAppliedCatalogItemArray(catalogIetmIndex);
            if(catalogItem != null) {
                catalogItemExternalId = catalogItem.getCatalogItemExternalId();
            }
        }
        return catalogItemExternalId;
    }

    private Map<String, MtxEvent> querySubscriberPurchaseHistory(String loggingKey,
                                                                 String route,
                                                                 MtxSubscriberSearchData searchData,
                                                                 String searchDate)
                                                                         throws DeviceServiceException {
        final String[] searchEventTypes = new String[] {
            EVENT_TYPES.RECHARGE, EVENT_TYPES.PURCHASE
        };
        return querySubscriberEventHistory(
                loggingKey, route, searchData, searchDate, searchEventTypes);
    }

    private Map<String, MtxEvent> querySubscriberEventHistory(String loggingKey,
                                                              String route,
                                                              MtxSubscriberSearchData searchData,
                                                              String searchDate,
                                                              String[] searchEventTypes)
                                                                      throws DeviceServiceException {
        // Parse the original order date
        long searchDateEpoch = 0;
        if (!StringUtils.isEmpty(searchDate)) {
            try {
                searchDateEpoch = new SimpleDateFormat(RequestValidator.DATE_FORMAT).parse(
                        searchDate).getTime();
            } catch (ParseException e) {
                // Will not be thrown. Request field has already been validated
                searchDateEpoch = 0;
            }
        }
        Map<String, MtxEvent> eventTable = new HashMap<String, MtxEvent>();

        DEBUG(m_logger, loggingKey + "Querying event history for subscriber in MATRIXX");

        EventQueryResponseEvents response;
        if (searchDateEpoch > 0) {
            response = querySubscriberEventList(
                    route, "ExternalId+" + searchData.getExternalId(), searchEventTypes,
                    new MtxTimestamp(searchDateEpoch));
        } else {
            response = querySubscriberEventList(
                    route, "ExternalId+" + searchData.getExternalId(), searchEventTypes);
        }

        if (response == null
                || response.getResult() != RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS) {
            Long resultCode = response != null
                    ? response.getResult() : RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR;
                    String message = FAILED_TO_QUERY_RECCURING_HISTORY
                            + (response != null ? " - " + response.getResultText() : "");
                    throw new DeviceServiceException(resultCode, message);
        }

        if (response.getEventList() != null) {
            for (EventQueryEventInfo eventInfo : response.getEventList()) {
                eventTable.put(
                        eventInfo.getEventDetails().getEventId(), eventInfo.getEventDetails());
            }
        }
        DEBUG(
                m_logger,
                loggingKey + "Retrieved " + eventTable.size() + " event(s) for the subscriber");

        if (eventTable == null || eventTable.isEmpty()) {
            throw new DeviceServiceException(
            		RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, MISSING_PURCHASE_HISTORY);
        }

        return eventTable;

    }

    /**
     * Returns the attribute's value from the offer.
     *
     * @param offerAttributes
     * @param offerName
     * @param attributeName
     * @return the value for the attribute if found.
     * @throws DeviceServiceException
     *             if attribute was not found.
     */
    public static String getOfferAttribute(Map<String, String> offerAttributes,
                                           String offerName,
                                           String attributeName)
                                                   throws DeviceServiceException {

        String value = offerAttributes.get(attributeName);
        if (value == null) {
            throw new DeviceServiceException(
            		RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,
                    "Attribute " + attributeName + " not found for offer " + offerName);
        }
        return value;
    }

    /**
     * Charge NRF extension handler.
     *
     * @param input
     *            input
     * @param output
     *            output
     * @throws Exception
     */
    public void chargeNonReturnFee(VisibleRequestChargeNrf input, VisibleResponseChargeNrf output)
            throws Exception {

        boolean isPaymentUsingRecharge = AppPropertyProvider.getInstance().getBoolean(
                DEVICE_CONSTANTS.DEVICE_PAYMENT_USING_RECHARGE,
                DEVICE_CONSTANTS.DEVICE_PAYMENT_USING_RECHARGE_DEFAULT_VALUE);
        // Setup the logging key
        String loggingKey = getLoggingKey(input.getSubscriberExternalId());

        MtxChargeMethodData chargeMethodOnAccount = new MtxChargeMethodData();
        chargeMethodOnAccount.setChargeMethod(1);// On account
        // Determine routing data
        String route = getRoute(MatrixxContext.getRequest());

        // Validate the request
        requestValidator.validateRequest(loggingKey, input);
        BigDecimal chargeAmount = new BigDecimal(input.getNrfOfferInfo().getOfferDiscountPrice());

        DEBUG(m_logger, loggingKey + "Charge Amount " + chargeAmount);

        // Prepare subscriber search data.Query the subscriber data in MATRIXX
        MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
        searchData.setExternalId(input.getSubscriberExternalId());
        MtxResponseSubscription subscriber = getSubscriber(loggingKey, route, input.getSubscriberExternalId());

        // Create a multi-request containing operations required to charge non return fee
        // purchase as a single transaction
        DEBUG(m_logger, loggingKey + "Creating charge non return fee transaction");
        MtxRequestMulti multiReqChargeNrf = new MtxRequestMulti();
        int rechargeIndex = 0;
        // MultiRequest operation 1
        // If Ship-to-BID is not equal to Home-BID, modify subscriber to change GL Center to
        // Ship-to-BID

        String origGlCenter = CommonUtils.getSubscriberGlCenter(subscriber);
        boolean glCenterChanged = handleShippingGLCenterChange(
                loggingKey, searchData, subscriber, multiReqChargeNrf,
                input.getNrfShippingInfo().getShipToBid());

        // MultiRequest operation 2
        // Capture a high precision timestamp (at least milliseconds)
        // Call MtxRequestSubscriberRecharge with offerAmount(incl of tax)
        // Get recharge reason from offer attributes.

        MtxChargeMethodData chargeMethodDataForRecharge = new MtxChargeMethodData();
        if (input.getNrfFraudInfo() != null) {

            VisibleFraudHomeAddress fraudBillingAddress = new VisibleFraudHomeAddress();
            fraudBillingAddress = input.getNrfFraudInfo().getFraudHomeAddress();

            VisibleFraudShippingAddress fraudShippingAddress = new VisibleFraudShippingAddress();
            fraudShippingAddress = input.getNrfFraudInfo().getFraudShippingAddress();

            VisibleFraudDeviceInfo fraudDeviceInfo = new VisibleFraudDeviceInfo();

            if (input.getNrfFraudInfo().getFraudDeviceInfo() != null) {
                fraudDeviceInfo = input.getNrfFraudInfo().getFraudDeviceInfo();
            }

            List<VisibleAttribute> paymentGatewayAttributes = new ArrayList<VisibleAttribute>();
            if (input.getNrfFraudInfo().getPaymentGatewayAttributes() != null
                    && !input.getNrfFraudInfo().getPaymentGatewayAttributes().isEmpty()) {
                paymentGatewayAttributes = input.getNrfFraudInfo().getPaymentGatewayAttributes();
            }

            CommonUtils.addFraudInfoToChargeMethodData(
                    chargeMethodDataForRecharge, fraudBillingAddress, fraudShippingAddress,
                    fraudDeviceInfo, input.getNrfFraudInfo().getTransactionType(),
                    BRAINTREE_CONSTANTS.BT_VISIBLE_RECURRING_OVERRIDE_FLAG, paymentGatewayAttributes, loggingKey);

        }
        String payGatewayId = null;
        String payInfo = null;
        String payMethod;
        payMethod = input.getNrfOrderInfo().getPaymentMethod();
        if (input.getNrfOrderInfo().getPaymentInfo() != null) {
            payInfo = input.getNrfOrderInfo().getPaymentInfo();
        }
        if (input.getNrfOrderInfo().getPaymentGatewayId() != null) {
            payGatewayId = input.getNrfOrderInfo().getPaymentGatewayId();
        }

        CommonUtils.addPaymentInfoToChargeMethodData(
                chargeMethodDataForRecharge, input.getNrfOrderInfo().getPaymentMethod(),
                input.getNrfOrderInfo().getPaymentInfo(),
                input.getNrfOrderInfo().getPaymentGatewayId());

        Map<String, String> offerAttributes = getOfferAttributes(
                loggingKey, route, input.getNrfOfferInfo().getOfferExternalId());
        String chargeReason = offerAttributes.get(ATTR_NAME_GOOD_TYPE);
        String offerTimestamp = (new Date()).getTime() + "";

        if (isPaymentUsingRecharge) {
            boolean payNow = true;

            multiReqChargeNrf.appendRequestList(
                    getSubscriberRechargeRequest(
                            searchData, chargeMethodDataForRecharge, chargeReason, offerTimestamp,
                            chargeAmount, payNow, input.getNrfOrderInfo().getOrderId()));
            rechargeIndex = multiReqChargeNrf.getRequestList().size() - 1;
        }
        // MultiRequest operation 3
        // . Call MtxRequestSubscriberPurchaseOffer for chargeOffer with chargeAmount
        // i.Get gooodType from offer attributes
        // ii. Info = timestamp
        String chargeGoodType = offerAttributes.get(ATTR_NAME_GOOD_TYPE);
        MtxPurchasedOfferData offerData = getPurchasedOfferData(
                input.getNrfOfferInfo().getOfferExternalId(), input.getNrfOrderInfo().getOrderId(),
                input.getNrfOfferInfo().getOfferSku(), chargeAmount,
                input.getNrfOfferInfo().getOfferTaxDetails(),
                input.getNrfOfferInfo().getOfferDetails(), null, chargeGoodType, offerTimestamp);
        multiReqChargeNrf.appendRequestList(
                getSubscriberPurchaseOfferRequest(searchData, chargeMethodOnAccount, offerData));

        // MultiRequest operation 3
        // If Ship-to-BID is not equal to home BID, modify subscriber to change GL Center back
        // to origGlCenter.
        if (glCenterChanged) {
            multiReqChargeNrf.appendRequestList(
                    getSubscriberModifyRequest(searchData, origGlCenter));

        }

        // Send the multi-request to MATRIXX and receive the multi-response
        MtxResponseMulti multiRespChargeNrf = multiRequest(loggingKey, route, multiReqChargeNrf);
        // get Braintree error codes from rsgateway.properties
        List<Long> braintreeErrorCodes = AppPropertyParser.getLongList(
                AppPropertyProvider.getInstance(), BRAINTREE_CONSTANTS.BRAINTREE_ERROR_CODES_LIST);

        if (multiRespChargeNrf != null
                && multiRespChargeNrf.getResult() != RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS
                && isPaymentUsingRecharge) {

            if (multiRespChargeNrf.getResponseList() != null
                    && multiRespChargeNrf.getResponseList().size() > 0
                    && multiRespChargeNrf.getResponseList().get(
                            rechargeIndex) instanceof MtxResponseRecharge) {

                DEBUG(m_logger, loggingKey + "Check if recharge failed with braintree error");

                MtxResponseRecharge rechargeRes = (MtxResponseRecharge) multiRespChargeNrf.getResponseList().get(
                        rechargeIndex);

                if (rechargeRes.getResult() != RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS
                        && braintreeErrorCodes.contains(rechargeRes.getResult())) {
                    DEBUG(m_logger, loggingKey + "Recharge failed with braintree error");

                    multiRespChargeNrf = callMultiWithBadDebtChanges(
                            loggingKey, route, searchData, multiReqChargeNrf, // rechargeIndex,
                            offerAttributes.get(ATTR_NAME_RECHARGE_REASON_NRF_BAD_DEBT),
                            chargeMethodOnAccount, chargeAmount.subtract(
                                    new BigDecimal(input.getNrfOfferInfo().getOfferTotalTax())),
                            input.getNrfOrderInfo().getOrderId());

                } else {
                    DEBUG(
                            m_logger,
                            loggingKey + "The error in braintree is not a braintree error");
                }

            } else if (braintreeErrorCodes.contains(multiRespChargeNrf.getResult())) {
                DEBUG(
                        m_logger, loggingKey
                        + "ResponseList is not present in MtxResponseMulti, but the error is a braintree error ");
                DEBUG(m_logger, loggingKey + "Applying bad debt changes");

                multiRespChargeNrf = callMultiWithBadDebtChanges(
                        loggingKey, route, searchData, multiReqChargeNrf, // rechargeIndex,
                        offerAttributes.get(ATTR_NAME_RECHARGE_REASON_NRF_BAD_DEBT),
                        chargeMethodOnAccount, chargeAmount.subtract(
                                new BigDecimal(input.getNrfOfferInfo().getOfferTotalTax())),
                        input.getNrfOrderInfo().getOrderId());

            } else {
                DEBUG(m_logger, loggingKey + "The error is not a braintree error ");

            }

        }
        validateResponse(loggingKey, FAILED_TO_CHARGE_NON_RETURN_FEE, multiRespChargeNrf);

        // Prepare the API response
        output.setResult(multiRespChargeNrf.getResult());
        output.setResultText(multiRespChargeNrf.getResultText());

        ArrayList<MtxResponse> responseList = multiRespChargeNrf.getResponseList();
        if (responseList != null && !responseList.isEmpty()) {

            // Populate Risk details in response from Recharge operation response
            if (isPaymentUsingRecharge) {

                output.setRiskData(getRiskData(responseList, rechargeIndex));

            }

        }
    }

    /**
     * Modify multirequest for nrf bad debt scenario and get multiresponse
     *
     * @param loggingKey
     * @param route
     * @param searchData
     * @param multiReqChargeNrf
     * @param rechargeIndex
     * @param rechargeReasonBadDebt
     * @param chargeMethodOnAccount
     * @param newCharge
     * @param taxDetails
     * @return
     * @throws DeviceServiceException
     * @throws IOException
     * @throws JsonMappingException
     * @throws JsonParseException
     */
    private MtxResponseMulti callMultiWithBadDebtChanges(String loggingKey,
                                                         String route,
                                                         MtxSubscriberSearchData searchData,
                                                         MtxRequestMulti multiReqChargeNrf,
                                                         String rechargeReasonBadDebt,
                                                         MtxChargeMethodData chargeMethodOnAccount,
                                                         BigDecimal newCharge,
                                                         String orderId)
                                                                 throws DeviceServiceException, JsonParseException, JsonMappingException, IOException {

        String badDebtInfo = (new Date()).getTime() + "";
        MtxResponseMulti multiRespChargeNrf = new MtxResponseMulti();
        boolean purchReqNotFound = true;
        for (int i = 0; i < multiReqChargeNrf.getRequestList().size(); i++) {
            MtxRequest req = multiReqChargeNrf.getRequestList().get(i);
            if (req.getMdcName().equalsIgnoreCase("MtxRequestSubscriberPurchaseOffer")) {
                purchReqNotFound = false;

                MtxRequestSubscriberPurchaseOffer oldReq = (MtxRequestSubscriberPurchaseOffer) req;

                MtxPurchasedOfferData offerData = oldReq.getOfferRequestArray().get(0);
                VisiblePurchasedOfferExtension offerXtn = (VisiblePurchasedOfferExtension) offerData.getAttr();

                offerXtn.setChargeAmount(newCharge);
                offerXtn.setTaxDetails(null);
                offerXtn.setInfo(badDebtInfo);
                offerData.setAttr(offerXtn);

                MtxRequestSubscriberPurchaseOffer purBadDebt = getSubscriberPurchaseOfferRequest(
                        searchData, chargeMethodOnAccount, offerData);

                DEBUG(
                        m_logger, loggingKey
                        + "Replacing purchase request in multi with new purchase request without Taxes and new taxless price.");

                multiReqChargeNrf.getRequestListAppender().getArray().set(i, purBadDebt);
            }
        }

        if (purchReqNotFound) {
            throw new DeviceServiceException(
            		RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,
                    "Purchase request not found in Multirequest");
        }

        boolean rechReqNotFound = true;
        for (int i = 0; i < multiReqChargeNrf.getRequestList().size(); i++) {
            MtxRequest req = multiReqChargeNrf.getRequestList().get(i);
            if (req.getMdcName().equalsIgnoreCase("MtxRequestSubscriberRecharge")) {
                rechReqNotFound = false;
                MtxRequestSubscriberRecharge rechargeReqBadDebt = getSubscriberRechargeRequest(
                        searchData, chargeMethodOnAccount, rechargeReasonBadDebt, badDebtInfo,
                        newCharge, orderId);
                DEBUG(
                        m_logger, loggingKey
                        + "Replacing recharge request in multi with new recharge request without Paynow and charge method as pay on account");

                multiReqChargeNrf.getRequestListAppender().getArray().set(i, rechargeReqBadDebt);
            }
        }

        if (rechReqNotFound) {
            throw new DeviceServiceException(
            		RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,
                    "Recharge request not found in Multirequest");
        }
        DEBUG(m_logger, loggingKey + "Calling multi again");

        multiRespChargeNrf = multiRequest(loggingKey, route, multiReqChargeNrf);

        return multiRespChargeNrf;
    }

    /**
     * Method to cancel device swap. Exposed as cance_device_swap api. This method does a zero
     * amount adjustment with correct event ids. GLProcessor program will use event ids to get
     * correct amounts. With those amounts in GL, cancel process completes. This api will not cancel
     * any of the offers with subscriber.
     *
     * @param input
     * @param output
     * @throws Exception
     */
    public void cancelDeviceSwap(VisibleRequestCancelDeviceSwap input,
                                 VisibleResponseCancelDeviceSwap output)
                                         throws Exception {

        // Setup the logging key
        String loggingKey = getLoggingKey(input.getSubscriberExternalId());

        // Determine routing data
        String route = getRoute(MatrixxContext.getRequest());

        // Validate the request
        requestValidator.validateRequest(loggingKey, input);

        // Prepare subscriber search data
        MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
        searchData.setExternalId(input.getSubscriberExternalId());

        // Query purchase history for the subscriber for the original order date
        Map<String, MtxEvent> eventTable = querySubscriberPurchaseHistory(
                loggingKey, route, searchData,
                input.getCancelDeviceSwapOrderInfo().getOriginalOrderDate());

        Map<String, Object> eventData = getEventData(
                loggingKey, route,
                Arrays.asList(input.getCancelDeviceSwapOrderInfo().getDeviceSwapOfferExternalId()),
                eventTable, input.getCancelDeviceSwapOrderInfo().getOriginalOrderId());

        String adjReason = getAdjustmentReason(eventData);
        String shipBid = null;
        if (eventData.get(SHIP_TO_BID) != null) {
            shipBid = eventData.get(SHIP_TO_BID).toString();
        }
        // Create a multi-request containing all the operations required to handle the return
        // purchased device as a single transaction
        DEBUG(m_logger, loggingKey + "Creating return purchased device transaction");
        MtxRequestMulti multiReqCancelDeviceSwap = new MtxRequestMulti();
        String origGlCenter = null;
        boolean glCenterChanged = false;
        if (((BigDecimal) eventData.get(REFUNDABLE_AMOUNT)).signum() != 0) {
            MtxResponseSubscription subscriber = getSubscriber(loggingKey, route, input.getSubscriberExternalId());
            // 1. Add ModifySubscriber request to GLCenter based on Ship-to-BID, Home-BID, and
            // Center
            origGlCenter = CommonUtils.getSubscriberGlCenter(subscriber);

            glCenterChanged = handleShippingGLCenterChange(
                    loggingKey, searchData, subscriber, multiReqCancelDeviceSwap, shipBid);
        }
        // 2. Add the main balance adjustment operation for the charged amount to the multi-request
        // Note: For returns, the adjustment amount should be hard coded to $0. The
        // gl_processor figures out what the amount should be from the original events.
        // Device_Swap Adjustment will be handled by GL Processor based on event_ids of Recharge and
        // Purchase of Device_Swap.
        // Equipment Revenue 606 Adjustment will also be handled by GL processor based on event id
        // of Recharge and Purchase of 606_Adjustment
        multiReqCancelDeviceSwap.appendRequestList(
                getSubscriberAdjustBalanceRequest(
                        searchData, (Long) eventData.get(BALANCE_RESOURCE_ID),
                        BigDecimal.ZERO.setScale(BRAINTREE_CONSTANTS.BT_AMOUNT_PRECISION), adjReason));

        if (glCenterChanged) {
            // 3. Add ModifySubscriber request to revert GLCenter change
            multiReqCancelDeviceSwap.appendRequestList(
                    getSubscriberModifyRequest(searchData, origGlCenter));
        }

        // Send the multi-request to MATRIXX and receive the multi-response
        MtxResponseMulti multiRespCancelDeviceSwap = multiRequest(
                loggingKey, route, multiReqCancelDeviceSwap);
        validateResponse(loggingKey, LOG_FAILED_MULTI, multiRespCancelDeviceSwap);

        // Prepare the API response
        output.setResult(multiRespCancelDeviceSwap.getResult());
        output.setResultText(multiRespCancelDeviceSwap.getResultText());
    }

    /**
     * Finds the main balance resource id from the subscriber's wallet.
     *
     * @param loggingKey
     * @param route
     * @param searchData
     * @return the main balance id if main balance exists. Otherwise, null.
     * @throws DeviceServiceException
     */
    protected Long getMainBalanceResourceId(String loggingKey,
                                            String route,
                                            MtxSubscriberSearchData searchData)
                                                    throws DeviceServiceException {
        MtxResponseWallet wallet = querySubscriptionWallet(loggingKey, route, searchData.getExternalId());
        validateResponse(
                loggingKey, ERROR_FAILED_TO_RETRIEVE_SUBSCRIBER_WALLET + searchData.getExternalId(),
                wallet);
        for (MtxBalanceInfo balance : wallet.getBalanceArray()) {
            if (balance instanceof MtxBalanceInfoSimple) {
                MtxBalanceInfoSimple balanceInfo = (MtxBalanceInfoSimple) balance;
                if (balanceInfo.getIsMainBalance()) {
                    return balanceInfo.getResourceId();
                }
            }
        }
        WARN(
                this.m_logger, loggingKey + "Unable to find the main balance info for subscriber "
                        + searchData.getExternalId());
        //if (DebugEnabled(this.getClass())) {
            DEBUG(
                    this.m_logger, loggingKey + "Wallet data for subscriber "
                            + searchData.getExternalId() + ":\n" + wallet.toJson());
        //}
        return null;
    }

    /**
     * Process the device swap request.
     *
     * @param input
     * @param output
     * @throws InvalidRequestException
     *             if input is invalid
     * @throws DeviceServiceException
     *             if internal error was detected
     * @throws IntegrationServiceException
     *             if device swap offer was not found
     * @throws TaxApiException 
     */
    public void deviceSwap(VisibleRequestDeviceSwap input, VisibleResponseDeviceSwap output)
            throws InvalidRequestException, DeviceServiceException, IntegrationServiceException, TaxApiException, IOException {

        MtxChargeMethodData chargeMethodOnAccount = new MtxChargeMethodData();
        chargeMethodOnAccount.setChargeMethod(1);// On account

        // Setup the logging key
        String loggingKey = getLoggingKey(input.getSubscriberExternalId());

        // Determine routing data
        String route = getRoute(MatrixxContext.getRequest());

        // Validate the request
        RequestValidator.validateRequest(loggingKey, input);

        // Prepare subscriber search data
        MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
        searchData.setExternalId(input.getSubscriberExternalId());

        // Service Transaction Price = recurringServiceCharge:
        final BigDecimal serviceTransactionPrice = new BigDecimal(
                input.getDeviceSwapInfo().getRecurringServiceCharge());

        // Service SSP = Service Transaction Price
        final BigDecimal serviceSSP = new BigDecimal(
                input.getDeviceSwapInfo().getRecurringServiceCharge());

        // Equipment SSP = NewDeviceCOGS
        final BigDecimal equipmentSSP = new BigDecimal(
                input.getDeviceSwapInfo().getNewDeviceCOGS());
        // Equipment Transaction Price = NewDeviceCOGS - Swapped Device Residual Value
        final BigDecimal swappedDeviceResidualValue = new BigDecimal(
                input.getDeviceSwapInfo().getSwappedDeviceResidualValue());
        final BigDecimal equipmentTransactionPrice = equipmentSSP.subtract(
                swappedDeviceResidualValue);

        boolean applyRecharges = (equipmentTransactionPrice.compareTo(BigDecimal.ZERO) == 0)
                ? false : true;
        // Service SSP+Equipment SSP
        final BigDecimal netSSP = serviceSSP.add(equipmentSSP);
        // Service TP+EquipmentTP
        final BigDecimal netTransactionPrice = serviceTransactionPrice.add(
                equipmentTransactionPrice);

        // Service Adjusted Transaction Price = (Service SSP/(Service SSP+Equipment SSP))*(Service
        // TP+EquipmentTP)
        BigDecimal serviceAdjustedTransPrice = serviceSSP.divide(
                netSSP, DIVIDE_QUOTIENT_SCALE, DIVIDE_ROUNDING_MODE);
        serviceAdjustedTransPrice = serviceAdjustedTransPrice.multiply(netTransactionPrice);
        // Equipment Adjusted Transaction Price = (Equipment SSP/(Service SSP+Equipment
        // SSP))*(Service TP+EquipmentTP)
        BigDecimal equipAdjustedTransPrice = equipmentSSP.divide(
                netSSP, DIVIDE_QUOTIENT_SCALE, DIVIDE_ROUNDING_MODE);
        equipAdjustedTransPrice = equipAdjustedTransPrice.multiply(netTransactionPrice);

        //if (DebugEnabled(this.getClass())) {
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.append("equipmentTransactionPrice: ").append(
                    equipmentTransactionPrice).append(", ").append("netSSP: ").append(
                            netSSP).append(", ").append("netTransactionPrice: ").append(
                                    netTransactionPrice).append(", ").append(
                                            "serviceAdjustedTransPrice: ").append(
                                                    serviceAdjustedTransPrice).append(", ").append(
                                                            "equipAdjustedTransPrice: ").append(
                                                                    equipAdjustedTransPrice);
            DEBUG(this.m_logger, strBuilder.toString());
        //}

        MtxRequestMulti multiReqSwapDevice = new MtxRequestMulti();
        // Add Setup_Mainbalance (dummy) Offer before recharge
        String setupOffer = AppPropertyProvider.getInstance().getString(
                OFFER_CONSTANTS.OFFER_PURCHASE_SETUP_MAINBALANCE_OFFER);
        MtxPurchasedOfferData setUpMainBalanceOfferData = getPurchasedOfferData(
                setupOffer, input.getPurchaseOrderInfo().getOrderId(), null, BigDecimal.ZERO, null,
                null, null);
        multiReqSwapDevice.appendRequestList(
                getSubscriberPurchaseOfferRequest(searchData, setUpMainBalanceOfferData));

        // 1. Query the subscriber data in MATRIXX
        MtxResponseSubscription subscriber = getSubscriber(loggingKey, route, input.getSubscriberExternalId());

        String deviceTimestamp = CommonUtils.getTimestampAsString(0);

        // 2. Check values of ShipToBid, HomeBid and GlCenter and change GLCenter if need be.
        String origGlCenter = CommonUtils.getSubscriberGlCenter(subscriber);
        boolean glCenterChanged = handleShippingGLCenterChange(
                loggingKey, searchData, subscriber, multiReqSwapDevice,
                input.getDeviceSwapShippingInfo().getShipToBid());

        // 3. Get Reason Code from offer Attributes of Device Swap offer.:
        // NOTE: IntegrationServiceException will be thrown if offer was not found
        String offerID = input.getDeviceSwapInfo().getDeviceSwapOfferExternalId();
        Map<String, String> offerAttributes = getOfferAttributes(loggingKey, route, offerID);

        // 4. Recharge for Equipment Transaction Price (Logic is similar to Purchase Financed
        // Device)
        final String EQUIPMENT_PURCHASE_GOOD_TYPE = getOfferAttribute(
                offerAttributes, offerID, OFFER_ATTR_FOR_DEVICE_SWAP_EQUIPMENT_REASON);
        String taxApiResult = null;
        if (applyRecharges) {
            multiReqSwapDevice.appendRequestList(
                    getSubscriberRechargeRequest(
                            searchData, chargeMethodOnAccount, EQUIPMENT_PURCHASE_GOOD_TYPE,
                            deviceTimestamp, equipmentTransactionPrice, ""));

            // 5. Calculate service delta, get Tax and set it as tax string for device_swap offer
            // Service Delta = Service TP - Service ATP
            BigDecimal serviceDelta = serviceTransactionPrice.subtract(
                    serviceAdjustedTransPrice).abs();

            taxApiResult = getServiceTaxDetails(
                    subscriber, equipmentTransactionPrice, equipmentTransactionPrice, serviceDelta,
                    offerID, OFFER_ATTR_DEVICE_SWAP_SERVICE_DELTA_REASON, SERVICE_TYPE_SERVICE,
                    loggingKey, route);
        }

        // 6. Purchase Device Swap Offer
        MtxPurchasedOfferData deviceOfferData = getPurchasedOfferData(
                input.getDeviceSwapInfo().getDeviceSwapOfferExternalId(),
                input.getPurchaseOrderInfo().getOrderId(),
                input.getDeviceSwapInfo().getNewDeviceSku(), equipmentTransactionPrice,
                taxApiResult, input.getDeviceSwapInfo().getNewDeviceDetails(), null,
                EQUIPMENT_PURCHASE_GOOD_TYPE, deviceTimestamp);
        multiReqSwapDevice.appendRequestList(
                getSubscriberPurchaseOfferRequest(
                        searchData, chargeMethodOnAccount, deviceOfferData));

        if (applyRecharges) {
            // 7. Recharge with the equipment delta and purchase
            // Equipment Delta = Equipment TP - Equipment ATP
            BigDecimal equipmentDelta = equipmentTransactionPrice.subtract(
                    equipAdjustedTransPrice).abs();
            String equipRechargeTimestamp = CommonUtils.getTimestampAsString(1);

            final String EQUIPMENT_DELTA_REASON = getOfferAttribute(
                    offerAttributes, offerID, OFFER_ATTR_DEVICE_SWAP_EQUIPMENT_DELTA_REASON);

            multiReqSwapDevice.appendRequestList(
                    getSubscriberRechargeRequest(
                            searchData, chargeMethodOnAccount, EQUIPMENT_DELTA_REASON,
                            //input.getPurchaseOrderInfo().getOrderId()
                            equipRechargeTimestamp, equipmentDelta, ""));

            MtxPurchasedOfferData repurchaseOfferData = getPurchasedOfferData(
                    input.getDeviceSwapInfo().getDeviceSwapOfferExternalId(),
                    input.getPurchaseOrderInfo().getOrderId(),
                    input.getDeviceSwapInfo().getNewDeviceSku(), equipmentDelta, null,
                    input.getDeviceSwapInfo().getNewDeviceDetails(), null, EQUIPMENT_DELTA_REASON,
                    equipRechargeTimestamp);
            multiReqSwapDevice.appendRequestList(
                    getSubscriberPurchaseOfferRequest(
                            searchData, chargeMethodOnAccount, repurchaseOfferData));

        }
        // 8. Revert GL Center change if applicable (ref action 2)
        if (glCenterChanged) {
            multiReqSwapDevice.appendRequestList(
                    getSubscriberModifyRequest(searchData, origGlCenter));
        }

        // Send the multi-request to MATRIXX and receive the multi-response
        MtxResponseMulti multiRespFinanceDevice = multiRequest(
                loggingKey, route, multiReqSwapDevice);
        validateResponse(loggingKey, LOG_FAILED_TO_FINANCE_DEVICE, multiRespFinanceDevice);

        // Prepare the API response
        output.setResult(multiRespFinanceDevice.getResult());
        output.setResultText(multiRespFinanceDevice.getResultText());
    }

    public void reverseNonReturnFee(VisibleRequestReverseNrf input,
                                    VisibleResponseReverseNrf output)
                                            throws Exception {
        // Setup the logging key
        String loggingKey = getLoggingKey(input.getSubscriberExternalId());

        // Determine routing data
        String route = getRoute(MatrixxContext.getRequest());

        // Validate the request
        requestValidator.validateRequest(loggingKey, input);

        // 1. Get Subscriber details.
        // Prepare subscriber search data
        MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
        searchData.setExternalId(input.getSubscriberExternalId());
        MtxResponseSubscription subscriber = getSubscriber(loggingKey, route, input.getSubscriberExternalId());

        // 2. Get Event Data details for Adjustment and Purchase events.
        Map<String, MtxEvent> eventTable = querySubscriberPurchaseHistory(
                loggingKey, route, searchData,
                input.getCancelNrfOrderInfo().getOriginalOrderDate());

        if (eventTable == null || eventTable.isEmpty()) {
            throw new DeviceServiceException(
            		RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,
                    LOG_MISSING_PURCHASE_HISTORY);
        }

        Map<String, Object> eventData = getEventData(
                loggingKey, route,
                Arrays.asList(input.getCancelNrfOrderInfo().getOfferExternalId()), eventTable,
                input.getCancelNrfOrderInfo().getOriginalOrderId());

        // Create a multi-request containing all the operations required to handle the return
        // purchased device as a single transaction
        DEBUG(m_logger, loggingKey + "Creating reverse NRF transaction");
        MtxRequestMulti multiReqNrf = new MtxRequestMulti();
        String origGlCenter = null;
        boolean glCenterChanged = false;
        String adjReason = getAdjustmentReason(eventData);
        String rechargeReason = eventData.get(RECHARGE_REASON).toString();
        String shipBid = null;
        if (eventData.get(SHIP_TO_BID) != null) {
            shipBid = eventData.get(SHIP_TO_BID).toString();
        }

        Map<String, String> offerAttributes = getOfferAttributes(
                loggingKey, route, input.getCancelNrfOrderInfo().getOfferExternalId());

        if (rechargeReason.contains(offerAttributes.get(ATTR_NAME_RECHARGE_BAD_DEBT))) {
            // If recharge was done using bad debt then no refund. Adjust balance with reason code
            // from offer attributes of NRF offer.
            // Note: For returns, the adjustment amount should be hard coded to $0. The gl_processor
            // figures out what the amount should be from the original events.
            multiReqNrf.appendRequestList(
                    getSubscriberAdjustBalanceRequest(
                            searchData, (Long) eventData.get(BALANCE_RESOURCE_ID),
                            BigDecimal.ZERO.setScale(BRAINTREE_CONSTANTS.BT_AMOUNT_PRECISION), adjReason));
        } else {
            if (((BigDecimal) eventData.get(REFUNDABLE_AMOUNT)).signum() != 0) {
                // 3. Based on values of HomeBid, ShipToBid and GLCenter change value of GLCenter.
                if (subscriber.getGlCenter() != null) {
                    origGlCenter = subscriber.getGlCenter();
                }
                glCenterChanged = handleShippingGLCenterChange(
                        loggingKey, searchData, subscriber, multiReqNrf, shipBid);

                // 4.Adjust Balance for NRF.
                BigDecimal refundAmount = (BigDecimal) eventData.get(REFUNDABLE_AMOUNT);
                multiReqNrf.appendRequestList(
                        getSubscriberAdjustBalanceRequest(
                                searchData, (Long) eventData.get(BALANCE_RESOURCE_ID),
                                refundAmount.setScale(BRAINTREE_CONSTANTS.BT_AMOUNT_PRECISION), adjReason));

                // 5. Get original method of payment. Refund NRF.
                // Need to determine the payment resource ID if refund amount is greater than zero
                Long paymentResourceId = null;
                if (eventData.get(AUTH_EVENT_ID) == null) {
                    throw new DeviceServiceException(
                    		RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,
                            LOG_PAYAUTH_NOT_FOUND);
                }
                // Query payment history for the subscriber
                DEBUG(m_logger, loggingKey + "Querying subscriber payment history in MATRIXX");
                MtxResponsePaymentHistory paymentHistory = querySubscriberPaymentHistory(
                        loggingKey, route, searchData);
                validateResponse(loggingKey, LOG_FAILED_TO_QUERY_PAYMENT_HISTORY, paymentHistory);
                // Locate the payment info associated with the payment authorization event. This
                // contains the payment amount and the payment resource ID required for
                // processing the refund
                if (paymentHistory.getPaymentInfoList() != null
                        && !paymentHistory.getPaymentInfoList().isEmpty()) {
                    for (MtxPaymentInfo paymentInfo : paymentHistory.getPaymentInfoList()) {
                        if (paymentInfo.getAuthorizationEventId().equals(
                                eventData.get(AUTH_EVENT_ID))) {
                            paymentResourceId = paymentInfo.getResourceId();
                            break;
                        }
                    }
                }

                if (paymentResourceId == null) {
                    throw new DeviceServiceException(
                    		RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,
                            LOG_PAYMENT_RESOURCE_ID_NOT_FOUND);
                }

                INFO(
                        m_logger,
                        loggingKey + "Refund - Balance resource ID: "
                                + eventData.get(BALANCE_RESOURCE_ID) + ", Amount: " + refundAmount
                                + ", Reason: " + adjReason + ", Payment resource ID: "
                                + paymentResourceId);

                multiReqNrf.appendRequestList(
                        getSubscriberRefundRequest(
                                searchData, paymentResourceId,
                                refundAmount.setScale(BRAINTREE_CONSTANTS.BT_AMOUNT_PRECISION, RoundingMode.HALF_UP),
                                offerAttributes.get(ATTR_NAME_REFUND_REASON), adjReason));

            } else {
                INFO(m_logger, loggingKey + "Refund amount is zero - no refund required");
            }

        }

        if (glCenterChanged) {
            // 6. Revert GLCenter change as applicable.Add ModifySubscriber request to revert
            // GLCenter change
            multiReqNrf.appendRequestList(getSubscriberModifyRequest(searchData, origGlCenter));
        }

        // Send the multi-request to MATRIXX and receive the multi-response
        MtxResponseMulti multiRespNrf = multiRequest(loggingKey, route, multiReqNrf);
        validateResponse(loggingKey, LOG_FAILED_MULTI, multiRespNrf);

        // Prepare the API response
        output.setResult(multiRespNrf.getResult());
        output.setResultText(multiRespNrf.getResultText());
    }

}
