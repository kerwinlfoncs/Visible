package com.matrixx.vag.tax.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL) // Ignore unused fields to reduce payload size.
public class DpcItemTax {

    private String dpcItem;
    @JsonSerialize(using = TaxBigDecimalSerializer.class)
    private BigDecimal cP;
    private String taxTreatment;
    private String classCode;
    private String geocode;
    @JsonSerialize(using = TaxBigDecimalSerializer.class)
    private BigDecimal grossPrice;
    @JsonSerialize(using = TaxBigDecimalSerializer.class)
    private BigDecimal discountPrice;
    @JsonSerialize(using = TaxBigDecimalSerializer.class)
    private BigDecimal vendorCost;
    private String glReference;
    private String noticeText;
    @JsonSerialize(using = TaxBigDecimalSerializer.class)
    private BigDecimal dpcItemTaxAmount;
    @JsonSerialize(using = TaxBigDecimalSerializer.class)
    private BigDecimal dpcItemFeeAmount;
    @JsonSerialize(using = TaxBigDecimalSerializer.class)
    private BigDecimal dpcItemNetRevenue;
    private final List<TaxItem> taxItemList = new ArrayList<TaxItem>();

    public String getDpcItem() {
        return dpcItem;
    }

    public void setDpcItem(String dpcItem) {
        this.dpcItem = dpcItem;
    }

    public BigDecimal getcP() {
        return cP;
    }

    public void setcP(BigDecimal cP) {
        this.cP = cP;
    }

    public String getGlReference() {
        return glReference;
    }

    public void setGlReference(String glReference) {
        this.glReference = glReference;
    }

    public BigDecimal getDpcItemTaxAmount() {
        return dpcItemTaxAmount;
    }

    public void setDpcItemTaxAmount(BigDecimal dpcItemTaxAmount) {
        this.dpcItemTaxAmount = dpcItemTaxAmount;
    }

    public BigDecimal getDpcItemFeeAmount() {
        return dpcItemFeeAmount;
    }

    public void setDpcItemFeeAmount(BigDecimal dpcItemFeeAmount) {
        this.dpcItemFeeAmount = dpcItemFeeAmount;
    }

    public BigDecimal getDpcItemNetRevenue() {
        return dpcItemNetRevenue;
    }

    public void setDpcItemNetRevenue(BigDecimal dpcItemNetRevenue) {
        this.dpcItemNetRevenue = dpcItemNetRevenue;
    }

    public List<TaxItem> getTaxItemList() {
        return taxItemList;
    }

    public String getTaxTreatment() {
        return taxTreatment;
    }

    public void setTaxTreatment(String taxTreatment) {
        this.taxTreatment = taxTreatment;
    }

    public String getClassCode() {
        return classCode;
    }

    public void setClassCode(String classCode) {
        this.classCode = classCode;
    }

    public String getGeocode() {
        return geocode;
    }

    public void setGeocode(String geocode) {
        this.geocode = geocode;
    }

    public BigDecimal getGrossPrice() {
        return grossPrice;
    }

    public void setGrossPrice(BigDecimal grossPrice) {
        this.grossPrice = grossPrice;
    }

    public BigDecimal getVendorCost() {
        return vendorCost;
    }

    public void setVendorCost(BigDecimal vendorCost) {
        this.vendorCost = vendorCost;
    }

    public BigDecimal getDiscountPrice() {
        return discountPrice;
    }

    public void setDiscountPrice(BigDecimal discountPrice) {
        this.discountPrice = discountPrice;
    }

    public String getNoticeText() {
        return noticeText;
    }

    public void setNoticeText(String noticeText) {
        this.noticeText = noticeText;
    }

    public String toJson() {
        ObjectMapper mapper = new ObjectMapper();
        try {
                        return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(this).replaceAll("[\\r\\n]", "");
                } catch (JsonProcessingException e) {
                        return null;
                }
    }
    
    public String toJsonPretty() {
        ObjectMapper mapper = new ObjectMapper();
        try {
                        return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(this);
                } catch (JsonProcessingException e) {
                        return null;
                }
    }
}
