package com.matrixx.vag.common.request.builder;

import com.matrixx.datacontainer.mdc.MtxDeviceSearchData;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberAddDevice;
import com.matrixx.vag.common.coverage.Generated;

@Generated
public class MtxRequestSubscriberAddDeviceBuilder {
	MtxDeviceSearchData searchData;
    public MtxRequestSubscriberAddDevice build() {
		if(searchData==null) {
			this.searchData = new MtxDeviceSearchData();	
		}
		MtxRequestSubscriberAddDevice device = new MtxRequestSubscriberAddDevice();
    	device.setDeviceSearchData(searchData);
    	return device;
    }
}
