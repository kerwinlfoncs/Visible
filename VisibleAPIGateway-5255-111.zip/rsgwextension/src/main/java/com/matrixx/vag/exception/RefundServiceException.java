package com.matrixx.vag.exception;

/**
 * Exception thrown upon encountering an error with processing subscriber offers.
 *
 * @author unico
 */
public class RefundServiceException extends IntegrationServiceException {

    private static final long serialVersionUID = 4431886402810595938L;

    public RefundServiceException(Long resultCode, String message) {
        super(resultCode, message);
    }
}
