#### Template Attributes that can be over-written while grant purchase
* ClassCode
* ConsumableBalanceName
* CreditGrantType
* ApplicableGrantPercentage <- ChargeAmount
* CreditIncludeFlagName
* CreditIncludeFlagValues
* PromotionIsTaxable
* PromotionName
* PromotionPriority (Ideally this should be in sync with balance priority. We are not aware of any use cases to do overriding.)
* RedeemGoodType
* RedeemOffer (Overriding offer should be configured in pricing)
* MinimumCharge
* PromotionLimit
* IncompatiblePromotions
* TaxResponseUnchanged
#### Template Attributes that can NOT be over-written while grant purchase
* ApplicableOfferName
* DiscountCalculationMethod
* OfferType
* IgnoreTax_ForPayableAmount
* CreditIncludeAttributeValues
