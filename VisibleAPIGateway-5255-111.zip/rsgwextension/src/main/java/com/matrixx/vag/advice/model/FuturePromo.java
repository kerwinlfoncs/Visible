package com.matrixx.vag.advice.model;

import java.math.BigDecimal;

import com.matrixx.datacontainer.mdc.VisibleChangeServicePromo;
import com.matrixx.datacontainer.mdc.VisibleFuturePromo;
import com.matrixx.datacontainer.mdc.VisiblePromoExtension;

public class FuturePromo {

    final String grantOfferCI;
    final BigDecimal grantAmount;
    final VisiblePromoExtension attr;

    public FuturePromo(String grantOfferCI, BigDecimal grantAmount, VisiblePromoExtension attr) {
        super();
        this.grantOfferCI = grantOfferCI;
        this.grantAmount = grantAmount;
        this.attr = attr;
    }

    public String getGrantOfferCI() {
        return grantOfferCI;
    }

    public BigDecimal getGrantAmount() {
        return grantAmount;
    }

    public VisiblePromoExtension getAttr() {
        return attr;
    }
    
    public static FuturePromo getFuturePromoFromChangeServicePromo(VisibleChangeServicePromo csp) {
        return new FuturePromo(csp.getGrantOfferCI(), csp.getGrantAmount(), csp.getAttr());        
    }
    
    public static FuturePromo getFuturePromoFromVisibleFuturePromo(VisibleFuturePromo fp) {
        return new FuturePromo(fp.getGrantOfferCI(), fp.getGrantAmount(), fp.getAttr());        
    }
}
