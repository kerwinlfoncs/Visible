package com.matrixx.vag.amq.client;

import static com.matrixx.platform.LogUtils.INFO;
import static com.matrixx.platform.LogUtils.WARN;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.matrixx.datacontainer.mdc.MtxResponse;
import com.matrixx.vag.common.Constants.ACTIVE_MQ_CONSTANTS;
import com.matrixx.vag.common.Constants.AUTOPAY_CONSTANTS;
import com.matrixx.vag.common.Constants.MATRIXX_CONSTANTS;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.common.Constants.SAC_NOTIFICATION_CONSTANTS;
import com.matrixx.vag.common.coverage.Generated;
import com.matrixx.vag.config.AppPropertyProvider;

@Generated
public class ActiveMQClient {

    private static final Logger m_logger = LoggerFactory.getLogger(ActiveMQClient.class);

    public static MtxResponse sendAuopayMessage(String loggingKey,
                                                String msgBody,
                                                String correlationId) {
        String qName = AppPropertyProvider.getInstance().getString(
                AUTOPAY_CONSTANTS.PROP_MSG_QUEUE);
        return putOnQueue(loggingKey, qName, msgBody, correlationId);
    }

    public static MtxResponse sendSacMessage(String loggingKey, String msgBody) {
        String qName = AppPropertyProvider.getInstance().getString(
                SAC_NOTIFICATION_CONSTANTS.SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_MSG_QUEUE);
        return putOnQueue(loggingKey, qName, msgBody, "");
    }

    public static MtxResponse putOnQueue(String loggingKey,
                                         String qName,
                                         String msgBody,
                                         String correlationId) {
        String methodKey = loggingKey + " putOnQueue: ";
        INFO(m_logger, methodKey);

        MtxResponse respMsg = new MtxResponse();
        respMsg.setResultText(MATRIXX_CONSTANTS.RESULT_TEXT_MTX_SUCCESS);
        respMsg.setResult(RESULT_CODES.MTX_SUCCESS);

        Connection connection = null;
        try {
            INFO(
                    m_logger,
                    methodKey + "Message to be sent: " + msgBody);
            String host = AppPropertyProvider.getInstance().getString(
                    ACTIVE_MQ_CONSTANTS.PROP_AMQ_MSG_HOST);
            String port = AppPropertyProvider.getInstance().getString(
                    ACTIVE_MQ_CONSTANTS.PROP_AMQ_MSG_PORT);
            String protocol = ACTIVE_MQ_CONSTANTS.AMQ_CONNECTION_PROTOCOL;

            // create ConnectionFactory and establish connection
            INFO(
                    m_logger, methodKey + "Connection to be established - " + protocol + host + ":" + port);
            ConnectionFactory factory = new ActiveMQConnectionFactory(protocol + host + ":" + port);
            connection = factory.createConnection();
            INFO(m_logger, methodKey + "Established connection.");

            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);

            INFO(m_logger, methodKey + "Message Queue: " + qName);
            Queue queue = session.createQueue(qName);
            javax.jms.MessageProducer producer = session.createProducer(queue);

            // Create and send the message
            TextMessage msg = session.createTextMessage();
            msg.setText(msgBody);
            if (StringUtils.isNotBlank(correlationId)) {
                msg.setJMSCorrelationID(correlationId);
            }
            producer.send(msg);
            INFO(m_logger, methodKey + "Message sent.");
        } catch (JMSException e) {
            respMsg.setResultText(ExceptionUtils.getStackTrace(e));
            respMsg.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
        } finally {
            if (connection != null) {
                try {
                    INFO(
                            m_logger,
                            methodKey + "closing connection");
                    connection.close();
                } catch (JMSException ex) {
                    WARN(
                            m_logger,
                            methodKey + "Couldn't close JMSConnection: "
                                    + ExceptionUtils.getStackTrace(ex));
                    respMsg.setResultText(ExceptionUtils.getStackTrace(ex));
                    respMsg.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
                }
            }
        }
        return respMsg;
    }
}
