package com.matrixx.vag.config;

import com.matrixx.vag.common.Constants.*;
import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.configuration2.ex.ConfigurationException;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

/**
 * Parser used to check that all the mandatory application properties are present.
 *
 * @author unico
 */
public class AppPropertyParser {

    public static void validateProperties(PropertiesConfiguration props)
            throws ConfigurationException {

        String[] propertyNames = new String[] {
            VISIBLE_EXTN_CONSTANTS.VISIBLE_MULTI_REQUESTS_NUMBER_MAX, //
            TAX_CONSTANTS.TAX_ON_SERVICES_API_ENDPOINT, //            
            
            DEVICE_CONSTANTS.DEVICE_PAYMENT_USING_RECHARGE, //
            DEVICE_CONSTANTS.DEVICE_DIRECT_PURCHASE_GOOD_TYPE_PURCHASE_DEVICE, //
            DEVICE_CONSTANTS.DEVICE_DIRECT_PURCHASE_GOOD_TYPE_PURCHASE_SHIPPING, //
            DEVICE_CONSTANTS.DEVICE_FINANCE_PURCHASE_REASON_FINANCE_DEVICE, //
            DEVICE_CONSTANTS.DEVICE_FINANCE_PURCHASE_REASON_FINANCE_SHIPPING, //
            DEVICE_CONSTANTS.DEVICE_FINANCE_PURCHASE_GOOD_TYPE_AFFIRM_FEE, //
            DEVICE_CONSTANTS.DEVICE_FINANCE_PURCHASE_GOOD_TYPE_FINANCE_DEVICE, //
            DEVICE_CONSTANTS.DEVICE_FINANCE_PURCHASE_GOOD_TYPE_FINANCE_SHIPPING, //

            SUBSCRIBER_SERVICE_CONSTANTS.SERVICE_PAYMENT_USING_RECHARGE, //
            SUBSCRIBER_SERVICE_CONSTANTS.SERVICE_PURCHASE_REASON_MANUAL_PAY, //
            SUBSCRIBER_SERVICE_CONSTANTS.SERVICE_REFUND_PAYAUTH_CAP, //

            BALANCE_CONSTANTS.BALANCE_NAME_VISIBLE_DEV_SWAP, //
            BALANCE_CONSTANTS.BALANCE_NAME_GLOBAL_PASS,//
            BALANCE_CONSTANTS.MAINBALANCE_USAGE_PRIORITY_LIST, //

            OFFER_CONSTANTS.OFFER_PURCHASE_SETUP_MAINBALANCE_OFFER, //
            OFFER_CONSTANTS.OFFER_EXTERNAL_ID_DEVICE_FINANCE_FEE, //            
            OFFER_CONSTANTS.OFFER_EXTERNAL_ID_VISIBLE_SERVICE_CHARGES, //
            OFFER_CONSTANTS.OFFER_EXTERNAL_ID_VISIBLE_REVERSE_SERVICE_PAYMENTS, //
            OFFER_CONSTANTS.CI_EXTERNAL_ID_PBLINK, //
            
            ACTIVE_MQ_CONSTANTS.PROP_AMQ_MSG_HOST, //
            ACTIVE_MQ_CONSTANTS.PROP_AMQ_MSG_PORT, //

            NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_NOTIFICATION_NAME_KEY, //
            NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_OBJECT_TYPE_KEY, //
            NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_OBJECT_TYPE_VALUE, //
            NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_OBJECT_EXTERNAL_ID_KEY, //
            NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_PAYMENT_METHOD_NAME_KEY, //
            NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_STATUS_KEY, //
            NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_STATUS_VALUE, //
            NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_STATUS_DESCRIPTION_KEY, //
            NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_NOTIFICATION_TYPE_KEY, //
            NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_NOTIFICATION_ID_KEY, //
            NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_PAYMENT_PREFERENCE_KEY, //
                        
            SAC_NOTIFICATION_CONSTANTS.SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_DELETE_PAYMENT_NOTIFICATION_NAME, //
            SAC_NOTIFICATION_CONSTANTS.SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_DELETE_PAYMENT_NOTIFICATION_TYPE, //
            SAC_NOTIFICATION_CONSTANTS.SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_DELETE_PAYMENT_STATUS_DESCRIPTION, //
            SAC_NOTIFICATION_CONSTANTS.SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_ADD_PAYMENT_NOTIFICATION_NAME, //
            SAC_NOTIFICATION_CONSTANTS.SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_ADD_PAYMENT_NOTIFICATION_TYPE, //
            SAC_NOTIFICATION_CONSTANTS.SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_ADD_PAYMENT_STATUS_DESCRIPTION, //
            SAC_NOTIFICATION_CONSTANTS.SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_CURRENT_PAYMENT_NOTIFICATION_NAME, //
            SAC_NOTIFICATION_CONSTANTS.SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_CURRENT_PAYMENT_NOTIFICATION_TYPE, //
            SAC_NOTIFICATION_CONSTANTS.SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_CURRENT_PAYMENT_STATUS_DESCRIPTION, //
            SAC_NOTIFICATION_CONSTANTS.SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_MODIFY_PAYMENT_PREFERENCE_NAME, //
            SAC_NOTIFICATION_CONSTANTS.SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_MODIFY_PAYMENT_PREFERENCE_TYPE, //
            SAC_NOTIFICATION_CONSTANTS.SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_MODIFY_PAYMENT_PREFERENCE_DESC, //
            SAC_NOTIFICATION_CONSTANTS.SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_MSG_QUEUE, //

            BRAINTREE_CONSTANTS.BRAINTREE_ERROR_CODES_LIST, //

            MANUAL_PAY.ALLOWABLE_SUBSCR_STATS, //
            MANUAL_PAY.ALLOWABLE_SUBSCR_STATS_ERR_MSG, //
            
            AUTOPAY_CONSTANTS.PROP_DELTA_HOURS,
            AUTOPAY_CONSTANTS.PROP_RETRY_WAIT_HOURS,
            AUTOPAY_CONSTANTS.PROP_MSG_QUEUE            
        };

        String[] propertyPrefixes = new String[] {
        		CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_NAME_PROP_PREFIX	
        };

        String[] defaultAsSpace = new String[] {        		
        	CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_REALIGN_CYCLE_LIST,
                CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_IMMEDIATE_START_CSV_LIST,
                CHANGE_SERVICE_CONSTANTS.CI_DISALLOWED_AS_TARGET_LIST,
                CHANGE_SERVICE_CONSTANTS.DELTA_FREE_CLASS_CODE_UPPER_CASE_LIST,
                CHANGE_SERVICE_CONSTANTS.DELTA_ONLY_TARGET_LIST,
                TAX_CONSTANTS.USE_CPS_FROM_LAST_TAX,
                PAYMENT_CONSTANTS.PURCHASE_SERVICE_TYPE_FOR_PBLINK_CSV_LIST
        };
        
        for (String propertyName : propertyNames) {
            String propertyValue = null;
            try {
                propertyValue = props.getString(propertyName);
            } catch (NoSuchElementException e) {
                // Fall through
            }

            // Check for missing mandatory properties
            switch (propertyName) {
                case DEVICE_CONSTANTS.DEVICE_PAYMENT_USING_RECHARGE:
                case SUBSCRIBER_SERVICE_CONSTANTS.SERVICE_PAYMENT_USING_RECHARGE: {
                    break;
                }
                default: {
                    if (StringUtils.isEmpty(propertyValue)) {
                        throw new ConfigurationException(
                                "Mandatory application configuration property '" + propertyName
                                        + "' is missing");
                    }
                    break;
                }
            }
            if (StringUtils.isEmpty(propertyValue)) {
                continue;
            }

            // Perform specific property validation
            switch (propertyName) {

                case BRAINTREE_CONSTANTS.BRAINTREE_ERROR_CODES_LIST: {
                    getLongList(props, BRAINTREE_CONSTANTS.BRAINTREE_ERROR_CODES_LIST);
                    break;
                }
                // Validate BigDecimal properties
                case SUBSCRIBER_SERVICE_CONSTANTS.SERVICE_REFUND_PAYAUTH_CAP: {
                    validateBigDecimal(propertyName, propertyValue);
                    break;
                }

                default: {
                    break;
                }
            }
        }
                
       for (String propPrefix : propertyPrefixes) {
	        Iterator<String> propItr = null;
	        try {
	        	propItr = props.getKeys();
	        } catch (NoSuchElementException e) {
	            // Fall through
	        }
	        
	        boolean foundPrefix = false;
	        while(propItr.hasNext()) {
	        	String propKey = propItr.next();
	        	if(propKey.startsWith(propPrefix)) {
	        		foundPrefix = true;	
	        	}
	        }
	       	        
	        if(!foundPrefix) {
	            throw new ConfigurationException(
	                    "Mandatory application configuration properties with prefix " + propPrefix
	                            + " are missing");            	
	        }            
       }

       List<String> missingOptionalKeyList = new ArrayList<String>();
       for (String optProp : defaultAsSpace) {
	        Iterator<String> propItr = null;
	        try {
	        	propItr = props.getKeys();
	        } catch (NoSuchElementException e) {
	            // Fall through
	        }
	        
	        boolean foundProp = false;
	        while(propItr.hasNext()) {
	        	String propKey = propItr.next();
	        	if(propKey.equalsIgnoreCase(optProp)) {
	        		foundProp = true;	
	        	}
	        }
	       	        
	        if(!foundProp) {
	        	missingOptionalKeyList.add(optProp);
	        }            
      }
       
       for(String missingProp:missingOptionalKeyList) {
    	   //If an optional property is missing set it to space. This will remove missing property exceptions. 
    	   props.setProperty(missingProp, StringUtils.SPACE);
       }

    }

    /**
     * Returns a flat list (separated by a comma) of property value as a BigInteger list.
     *
     * @param props
     * @param propertyName
     * @return the list if property is found. Otherwise, null.
     * @throws ConfigurationException
     */
    public static List<Long> getLongList(PropertiesConfiguration props, String propertyName)
            throws ConfigurationException {

        if (props.containsKey(propertyName)) {
            List<Long> list = new ArrayList<Long>();
            String[] values = props.getString(propertyName).split(",");
            if (values == null || values.length == 0) {
                throw new ConfigurationException(
                        "Empty list of values specified for application configuration property '"
                                + propertyName + "'");
            }
            for (String value : values) {
                try {                	
                    list.add(Long.parseLong(value.trim()));
                } catch (NumberFormatException e) {
                    throw new ConfigurationException(
                            "Invalid list value '" + value
                                    + "' specified in application configuration property '"
                                    + propertyName + "' - Exception: " + e.getClass().getName()
                                    + " " + e.getMessage());
                }
            }
            return list;
        }
        return null;
    }

    public static List<String> getStringList(String propertyName){
    	PropertiesConfiguration props  = AppPropertyProvider.getInstance();
    	List<String> list = new ArrayList<String>();
        if (props.containsKey(propertyName)) {            
            String[] values = props.getString(propertyName).split(",");
            //We could use props.getStringArray(propertyName). But not have enough time to test it thoroughly.
            if (values != null && values.length > 0) {
                for (String value : values) {
                    list.add(value.trim());
                }                
            }
        }
        return list;
    }
    
    /**
     * Validates the property value as BigDecimal
     *
     * @param propertyName
     * @param propertyValue
     * @throws ConfigurationException
     */
    public static void validateBigDecimal(String propertyName, String propertyValue)
            throws ConfigurationException {
        if (propertyValue != null) {
            try {
                new BigDecimal(propertyValue);
            } catch (NumberFormatException ex) {
                throw new ConfigurationException(
                        "Invalid value '" + propertyValue
                                + "' for application configuration property '" + propertyName
                                + "' - Failed to convert to BigDecimal. Exception: "
                                + ex.getClass().getName() + " " + ex.getMessage());
            }
        }
    }
}
