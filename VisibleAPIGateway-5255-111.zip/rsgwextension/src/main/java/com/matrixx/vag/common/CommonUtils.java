/**
 *
 */
package com.matrixx.vag.common;

import static com.matrixx.platform.LogUtils.DEBUG;
import static com.matrixx.platform.LogUtils.WARN;

import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;
import java.util.AbstractMap.SimpleEntry;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;

import javax.naming.ConfigurationException;

import org.apache.camel.spring.util.ReflectionUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonGenerator.Feature;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.matrixx.datacontainer.BaseContainer;
import com.matrixx.datacontainer.DataContainer;
import com.matrixx.datacontainer.DataContainerFactory;
import com.matrixx.datacontainer.MtxDate;
import com.matrixx.datacontainer.MtxObjectId;
import com.matrixx.datacontainer.MtxPhone;
import com.matrixx.datacontainer.MtxTime;
import com.matrixx.datacontainer.MtxTimestamp;
import com.matrixx.datacontainer.mdc.MtxAddressData;
import com.matrixx.datacontainer.mdc.MtxBalanceImpactInfo;
import com.matrixx.datacontainer.mdc.MtxBalanceImpactInfoGroup;
import com.matrixx.datacontainer.mdc.MtxBalanceInfo;
import com.matrixx.datacontainer.mdc.MtxBillingCycleInfo;
import com.matrixx.datacontainer.mdc.MtxBraintreeResponseExtension;
import com.matrixx.datacontainer.mdc.MtxChargeMethodData;
import com.matrixx.datacontainer.mdc.MtxPaymentMethodInfo;
import com.matrixx.datacontainer.mdc.MtxPurchaseInfo;
import com.matrixx.datacontainer.mdc.MtxPurchasedOfferData;
import com.matrixx.datacontainer.mdc.MtxPurchasedOfferInfo;
import com.matrixx.datacontainer.mdc.MtxRequest;
import com.matrixx.datacontainer.mdc.MtxRequestMulti;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberModifyOffer;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberPurchaseOffer;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberRecharge;
import com.matrixx.datacontainer.mdc.MtxResponse;
import com.matrixx.datacontainer.mdc.MtxResponseDevice;
import com.matrixx.datacontainer.mdc.MtxResponseMulti;
import com.matrixx.datacontainer.mdc.MtxResponsePaymentMethodInfo;
import com.matrixx.datacontainer.mdc.MtxResponsePurchase;
import com.matrixx.datacontainer.mdc.MtxResponseRecharge;
import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import com.matrixx.datacontainer.mdc.MtxSubscriberSearchData;
import com.matrixx.datacontainer.mdc.VisibleAttribute;
import com.matrixx.datacontainer.mdc.VisibleBraintreeChargeMethodExtension;
import com.matrixx.datacontainer.mdc.VisibleDeviceExtension;
import com.matrixx.datacontainer.mdc.VisibleFraudDeviceInfo;
import com.matrixx.datacontainer.mdc.VisibleFraudHomeAddress;
import com.matrixx.datacontainer.mdc.VisibleFraudShippingAddress;
import com.matrixx.datacontainer.mdc.VisiblePurchasedOfferExtension;
import com.matrixx.datacontainer.mdc.VisibleRechargeExtension;
import com.matrixx.datacontainer.mdc.VisibleRiskData;
import com.matrixx.datacontainer.mdc.VisibleSubscriberExtension;
import com.matrixx.platform.JsonObject;
import com.matrixx.vag.common.Constants.BALANCE_CONSTANTS;
import com.matrixx.vag.common.Constants.CYCLE_PERIODS;
import com.matrixx.vag.common.Constants.DATE_POLICY;
import com.matrixx.vag.common.Constants.DEVICE_CONSTANTS;
import com.matrixx.vag.common.Constants.GENERIC_CONSTANTS;
import com.matrixx.vag.common.Constants.MATRIXX_CONSTANTS;
import com.matrixx.vag.common.Constants.OFFER_CONSTANTS;
import com.matrixx.vag.common.Constants.PAYMENT_CONSTANTS;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.exception.CommonUtilsException;
import com.matrixx.vag.exception.IntegrationServiceException;
import com.matrixx.vag.exception.MtxResponseException;
import com.matrixx.vag.tax.model.ServiceTaxRequest;
import com.matrixx.vag.tax.model.ServiceTaxResponse;

/**
 * @author mnguyen
 */
public class CommonUtils {

    public static final String VISIBLE_RECURRING_OVERRIDE = "VisibleRecurringOverride";
    public static final String TRANSACTION_TYPE = "TransactionType";
    public static final String REVERSAL_PREFIX = "$Reversal";
    public static final String PARTIAL_REVERSAL_PREFIX = "$PartialReversal";
    private static final Logger m_logger = LoggerFactory.getLogger(CommonUtils.class);

    /**
     *
     */
    private CommonUtils() {
        // Static utility class
    }

    /**
     * Return a flat string containing the set of values
     *
     * @param prefix
     * @param values
     * @return null if collection is not specified or is empty. Otherwise, the collection as a flat
     *         string.
     */
    public static String getFlatString(String prefix, Set<String> values) {
        if (values == null || values.size() == 0) {
            return null;
        }

        StringBuilder strBuilder = new StringBuilder();
        strBuilder.append(prefix);
        for (Object value : values) {
            strBuilder.append(" ").append(value.toString());
        }
        return strBuilder.toString();
    }

    public static String getReversalDetailsForEventId(String eventId) {
        Set<String> eventSet = Set.of(eventId);
        return getFlatString(REVERSAL_PREFIX, eventSet);
    }
    
    public static String getReversalDetails(Set<String> eventIds) {
        return getFlatString(REVERSAL_PREFIX, eventIds);
    }

    public static String getPartialReversalPrefixDetails(Set<String> eventIds) {
        return getFlatString(PARTIAL_REVERSAL_PREFIX, eventIds);
    }

    /**
     * Checks if the value is defined and is non zero.
     *
     * @param value
     * @return true if value is non zero. Otherwise, false when value is undefined or is zero.
     */
    public static boolean checkIfNonZero(BigDecimal value) {
        return (value != null && value.compareTo(BigDecimal.ZERO) != 0);
    }

    public static String readResponse(InputStream inputStream) throws IOException {
        BufferedReader in = null;
        StringBuilder strBuilder = new StringBuilder();

        try {
            in = new BufferedReader(new InputStreamReader(inputStream));

            String line;
            while ((line = in.readLine()) != null) {
                strBuilder.append(line).append("\n");
            }
        } catch (IOException ex) {
            throw ex;
        } finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (Exception ex) {
                // Do nothing - we tried...
            }

        }
        return strBuilder.toString().trim();
    }

    /**
     * Attempts to get the error message from the connection.
     *
     * @param connection
     * @return
     */
    public static String getHttpErrorMessage(HttpURLConnection connection) {
        String errorResponse = null;

        try {
            errorResponse = readResponse(connection.getErrorStream());
        } catch (IOException ex) {
            WARN(m_logger, "Failed to read error message.");
        }

        return errorResponse;
    }

    /**
     * Generic method to convert String to json.
     *
     * @param jsonString
     * @return the json file.
     * @throws IOException
     * @throws JsonMappingException
     * @throws JsonParseException
     */
    public static ServiceTaxRequest getServiceTaxRequestFromJsonString(String jsonString)
            throws JsonParseException, JsonMappingException, IOException {
        return getObjectMapper().readValue(jsonString, ServiceTaxRequest.class);
    }

    /**
     * Generic method to convert String to json.
     *
     * @param jsonString
     * @return the json file.
     * @throws IOException
     * @throws JsonMappingException
     * @throws JsonParseException
     */
    public static ServiceTaxResponse getServiceTaxResponseFromJsonString(String jsonString)
            throws ConfigurationException, JsonParseException, JsonMappingException, IOException {
        return getObjectMapper().readValue(jsonString, ServiceTaxResponse.class);
    }

    /**
     * Get geo code from subscriber attributes
     *
     * @param subscriber
     * @return
     */
    public static String getSubscriberGeoCode(MtxResponseSubscription subscriber) {
        if (subscriber.getAttr() != null) {
            return ((VisibleSubscriberExtension) subscriber.getAttr()).getGeoCode();
        } else {
            return null;
        }
    }

    public static String getSubscriberGlCenter(MtxResponseSubscription subscriber) {
        String glCenter = null;
        if (subscriber.getGlCenter() != null) {
            // VM Only fix
            glCenter = subscriber.getGlCenter();
        }
        return glCenter;
    }

    /**
     * Get the property name in a standard way.. Check if suffix is provided, in which case, append
     * the standard '.' character and get the property.
     *
     * @param prefix
     * @param suffix
     * @return
     */
    public static String getPropertyName(String prefix, String suffix) {
        String result = prefix;
        if (suffix != null && !suffix.isEmpty()) {
            result = prefix + GENERIC_CONSTANTS.DOT + suffix;
        }
        return result;
    }

    /**
     * Adds the list of requests to the multi (if the request list is not null).
     *
     * @param multiRequestObject
     * @param requests
     */
    public static void addRequestsToMulti(final MtxRequestMulti multiRequestObject,
                                          List<? extends MtxRequest> requests) {
        if (requests != null) {
            requests.forEach(request -> {
                addRequestToMulti(multiRequestObject, request);
            });
        }
    }

    /**
     * Add the request to the multi if the request is not null.
     *
     * @param multiRequestObject
     * @param request
     */
    public static void addRequestToMulti(final MtxRequestMulti multiRequestObject,
                                         MtxRequest request) {
        if (request != null) {
            multiRequestObject.appendRequestList(request);
        }
    }

    /**
     * Gets the timestamp as string.
     *
     * @param incrementValue
     *            additional increment value if necessary
     * @return timestamp as string value.
     */
    public static String getTimestampAsString(int incrementValue) {
        long timestamp = (new Date()).getTime() + incrementValue;
        return Long.toString(timestamp);
    }

    /*
     * Gets date as string Formatted in YYMMDD
     */

    public static String getDateYYMMDDString() {
        Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("yyMMdd");
        return formatter.format(date);
    }

    public static String getDateYYYYMMDDasHiphenString(String timezone) {

        ZonedDateTime zonedDateTime;
        if (StringUtils.isNotBlank(timezone)) {
            zonedDateTime = ZonedDateTime.now(ZoneId.of(timezone));
        } else {
            zonedDateTime = ZonedDateTime.now();
        }

        return DateTimeFormatter.ofPattern("yyyy-MM-dd").format(zonedDateTime);
    }

    public static long getCurrentTimeMillis() {
        return System.currentTimeMillis();
    }

    public static MtxTimestamp getCurrentTimeInZone(String timeZoneString) {
        LocalDateTime rightNow = LocalDateTime.now();
        ZoneId timeZone = ZoneId.of(timeZoneString);
        ZoneOffset timeZoneOffset = timeZone.getRules().getOffset(rightNow);
        ZonedDateTime zonedDateTime = ZonedDateTime.now(ZoneId.of(timeZoneString));
        return new MtxTimestamp(zonedDateTime.toLocalDateTime() + "" + timeZoneOffset);
    }

    public static boolean isInFuture(MtxTimestamp refTime, String timeZoneString) {
        MtxTimestamp nowTime= getCurrentTimeInZone(timeZoneString);        
        return refTime.longValue()>nowTime.longValue();
    }
    
    public static ZonedDateTime getZonedDateTimeNow(String timezone) {
        ZonedDateTime zonedDateTime;
        if (StringUtils.isNotBlank(timezone)) {
            zonedDateTime = ZonedDateTime.now(ZoneId.of(timezone));
        } else {
            zonedDateTime = ZonedDateTime.now();
        }
        return zonedDateTime;
    }

    public static ZonedDateTime getZonedDateTimeNow(ZoneId zoneId) {
        ZonedDateTime zonedDateTime;
        if (zoneId != null) {
            zonedDateTime = ZonedDateTime.now(zoneId);
        } else {
            zonedDateTime = ZonedDateTime.now();
        }
        return zonedDateTime;
    }

    public static int compareDateAndTimestamp(MtxDate date,
                                             MtxTimestamp timestamp) {
        //Assume both are in same timezone
        LocalDate fromDate= LocalDate.parse(date.getTime());
        LocalDate fromTime= LocalDate.parse(timestamp.getTime().split("T")[0]);
        if(fromDate.isAfter(fromTime)) {
            return 1;
        }else if(fromDate.isBefore(fromTime)) {
            return -1;
        }else {
            return 0;
        }
    }

    public static int compareMtxDates(MtxDate date1,
                                      MtxDate date2) {
         //Assume both are in same timezone
         LocalDate localDate1= LocalDate.parse(date1.getTime());
         LocalDate localDate2= LocalDate.parse(date2.getTime());
         if(localDate1.isAfter(localDate2)) {
             return 1;
         }else if(localDate1.isBefore(localDate2)) {
             return -1;
         }else {
             return 0;
         }
     }

    public static int compareMtxTimestampsIgnoreTime(MtxTimestamp date1,
                                      MtxTimestamp date2) {
        //Assume both are in same timezone
        LocalDate localDate1= LocalDate.parse(date1.getTime().split("T")[0]);
        LocalDate localDate2= LocalDate.parse(date2.getTime().split("T")[0]);
        if(localDate1.isAfter(localDate2)) {
            return 1;
        }else if(localDate1.isBefore(localDate2)) {
            return -1;
        }else {
            return 0;
        }
     }
    public static MtxTimestamp getMtxTimestampTodayZeroHours(MtxTimestamp cycleStartTime,
                                                             String defaultTimeZone) {
        ZoneId zoneId = getZoneIdForMtxTimestamp(cycleStartTime, defaultTimeZone);
        LocalDateTime ldt = LocalDate.now(zoneId).atStartOfDay();
        return getMtxTimestampFromLocalDatetime(ldt, zoneId); 
        
    }

    public static MtxDate getToday(MtxTimestamp refTimestamp, String defaultTimeZone) {
        ZoneId timeZone = getZoneIdForMtxTimestamp(refTimestamp, defaultTimeZone);
        Instant instant = Instant.now();
        ZonedDateTime zonedInstant = ZonedDateTime.ofInstant(instant, timeZone);
        return new MtxDate(
                zonedInstant.getYear() + "-" + zonedInstant.getMonthValue() + "-"
                        + zonedInstant.getDayOfMonth());
    }

    public static ZonedDateTime getZonedDateTimeFromMtxTimestamp(MtxTimestamp timestamp,
                                                                 String defaultTimeZone) {
        ZoneId timeZone = getZoneIdForMtxTimestamp(timestamp, defaultTimeZone);
        String[] timestampSplit = timestamp.getTime().split("T");
        String[] dateSplit = timestampSplit[0].split("-");
        int year = Integer.parseInt(dateSplit[0]);
        int month = Integer.parseInt(dateSplit[1]);
        int dayOfMonth = Integer.parseInt(dateSplit[2]);
        
        String[] timeSplit = timestampSplit[1].split(":");
        int hour = Integer.parseInt(timeSplit[0]);
        int minute = Integer.parseInt(timeSplit[1]);
        String[] a = timeSplit[2].split("\\.");
        int second = Integer.parseInt(a[0]);
        
        ZonedDateTime zTimestamp = ZonedDateTime.of(
                year, month, dayOfMonth, hour, minute, second, 0, timeZone);
        return zTimestamp;
    }

    public static ZonedDateTime getZonedDateTimeFromString(String dateTime, String timezone) {
        ZoneId timeZone;        
        if (StringUtils.isNotBlank(timezone)) {
            timeZone = ZoneId.of(timezone);
        } else {
            timeZone = ZoneId.systemDefault();
        }
        return LocalDateTime.parse(dateTime, DateTimeFormatter.ISO_DATE_TIME).atZone(timeZone);
    }

    public static MtxTimestamp getCycleEndDate(MtxTimestamp cycleStartTime,
                                               String timeZone,
                                               long cyclePeriod,
                                               long cyclePeriodInterval,
                                               MtxBillingCycleInfo bCycle) { 
        String[] timestampSplit = cycleStartTime.getTime().split("T");
        String[] timeSplit = timestampSplit[1].split(":");
        int hour = Integer.parseInt(timeSplit[0]);
        int minute = Integer.parseInt(timeSplit[1]);
        String[] a = timeSplit[2].split("\\.");
        int second = Integer.parseInt(a[0]);

        String isoDateString = timestampSplit[0];
        LocalDateTime startDate = LocalDate.parse(isoDateString).atStartOfDay().plusHours(hour).plusMinutes(minute).plusSeconds(second);
        
        long interval = (cyclePeriodInterval < 1) ? 1 : cyclePeriodInterval;
        LocalDateTime endDate;
        if (CYCLE_PERIODS.YEARLY == cyclePeriod) {
            endDate = startDate.plusYears(interval);
        } else {
            endDate = startDate.plusMonths(interval);
        }

        if (bCycle != null && DATE_POLICY.OFFSET_FROM_START == bCycle.getDatePolicy()
                && bCycle.getDateOffset() != null && bCycle.getDateOffset() > 0) {
            LocalDateTime tempEndDate = endDate.with(TemporalAdjusters.lastDayOfMonth());
            if (bCycle.getDateOffset() > tempEndDate.getDayOfMonth()) {
                endDate = tempEndDate;
            } else if (bCycle.getDateOffset() > endDate.getDayOfMonth()) {
                endDate = tempEndDate.withDayOfMonth(bCycle.getDateOffset().intValue());
            }
        }
        return getMtxTimestampFromLocalDatetime(endDate, ZoneId.of(timeZone));
    }

    public static int getDaysRemainingInCycle(MtxTimestamp cycleEndTime, String defaultTimeZone) {
        ZoneId timeZone = getZoneIdForMtxTimestamp(cycleEndTime,defaultTimeZone);
        // Parse end date using string parsing. Keep this as last resort if nothing works.
        // Creating zoned date time from MtxTimestamp has challenges
        String[] endTimeSplit = cycleEndTime.getTime().split("T");

        String[] dateSplit = endTimeSplit[0].split("-");
        int year = Integer.parseInt(dateSplit[0]);
        int month = Integer.parseInt(dateSplit[1]);
        int dayOfMonth = Integer.parseInt(dateSplit[2]);

        String[] timeSplit = endTimeSplit[1].split(":");
        int hour = Integer.parseInt(timeSplit[0]);
        int minute = Integer.parseInt(timeSplit[1]);
        String[] a = timeSplit[2].split("\\.");
        int second = Integer.parseInt(a[0]);
        ZonedDateTime zEndTime = ZonedDateTime.of(
                year, month, dayOfMonth, hour, minute, second, 0, timeZone);

        ZonedDateTime zCurTime = getZonedDateTimeNow(timeZone);

        DEBUG(m_logger, "getDaysRemainingInCycle: " + "Based on CycleEndTime: " + zEndTime);
        DEBUG(m_logger, "getDaysRemainingInCycle: " + "Based on CurrentTime: " + zCurTime);

        return (int) zCurTime.truncatedTo(ChronoUnit.DAYS).until(
                zEndTime.truncatedTo(ChronoUnit.DAYS), ChronoUnit.DAYS);
    }

    public static long getCycleMonths(long cyclePeriod,
                                      long cyclePeriodInterval) {
        if (CYCLE_PERIODS.MONTHLY == cyclePeriod) {
            return cyclePeriodInterval;
        } else if (CYCLE_PERIODS.YEARLY == cyclePeriod) {
            return cyclePeriodInterval*12;
        } else {
            return 0;
        }
    }

    public static int getDaysInCycleForEndTime(MtxTimestamp cycleEndTime,
                                               String defaultTimeZone,
                                               long cyclePeriod,
                                               long cyclePeriodInterval) {
        ZoneId timeZone = getZoneIdForMtxTimestamp(cycleEndTime, defaultTimeZone);
        Instant instant = Instant.ofEpochMilli(cycleEndTime.longValue());
        ZonedDateTime zEndTime = ZonedDateTime.ofInstant(instant, timeZone);

        long interval = (cyclePeriodInterval < 1) ? 1 : cyclePeriodInterval;
        ZonedDateTime zStartTime;

        if (CYCLE_PERIODS.MONTHLY == cyclePeriod) {
            zStartTime = zEndTime.minusMonths(interval);
        } else if (CYCLE_PERIODS.YEARLY == cyclePeriod) {
            zStartTime = zEndTime.minusYears(interval);
        } else if (CYCLE_PERIODS.WEEKLY == cyclePeriod) {
            zStartTime = zEndTime.minusWeeks(interval);
        } else if (CYCLE_PERIODS.DAILY == cyclePeriod) {
            zStartTime = zEndTime.minusDays(interval);
        } else if (CYCLE_PERIODS.HOURLY == cyclePeriod) {
            zStartTime = zEndTime.minusHours(interval);
        } else {
            zStartTime = zEndTime.minusMinutes(interval);
        }

        return (int) zStartTime.until(zEndTime, ChronoUnit.DAYS);
    }

    public static MtxTimestamp subtractOneMonth(MtxTimestamp refDateTime, String defaultTimeZone) {        
        ZoneId zoneId = getZoneIdForMtxTimestamp(refDateTime, defaultTimeZone);
        LocalDate refLocalDate = LocalDate.parse(refDateTime.getTime().split("T")[0]);
        LocalDateTime minusMonth = refLocalDate.atTime(LocalTime.MIDNIGHT).minusMonths(1);
        return getMtxTimestampFromLocalDatetime(minusMonth, zoneId);
    }

    public static MtxTimestamp getNextCycleEndTime(MtxBillingCycleInfo bCycle,
                                                   String subscriptionTimeZone) {
        MtxTimestamp startOfNext = bCycle.getCurrentPeriodEndTime(); 
        String[] timestampSplit = startOfNext.getTime().split("T");
        String[] timeSplit = timestampSplit[1].split(":");
        int hour = Integer.parseInt(timeSplit[0]);
        int minute = Integer.parseInt(timeSplit[1]);
        String[] a = timeSplit[2].split("\\.");
        int second = Integer.parseInt(a[0]);
        
        String timeZone = subscriptionTimeZone;
        if(StringUtils.isBlank(timeZone)) {
            timeZone = ZoneId.systemDefault().toString();
        }
        LocalDate localStartOfNext = LocalDate.parse(timestampSplit[0]);
        LocalDateTime localDateTimeStartOfNext = localStartOfNext.atStartOfDay().plusHours(hour).plusMinutes(minute).plusSeconds(second); 
        LocalDateTime localDateTimeEndOfNext = localDateTimeStartOfNext.plusMonths(1); 
       
        ZoneId zoneId;
        if(subscriptionTimeZone!=null) {
            zoneId = ZoneId.of(subscriptionTimeZone);
        }else {
            zoneId = ZoneId.systemDefault();
        }
               
        if (DATE_POLICY.OFFSET_FROM_START == bCycle.getDatePolicy()
                && bCycle.getDateOffset() != null && bCycle.getDateOffset() > 0) {
            LocalDateTime localEndOfNextMonth = localDateTimeEndOfNext.with(
                    TemporalAdjusters.lastDayOfMonth());
            if (bCycle.getDateOffset() >= localEndOfNextMonth.getDayOfMonth()) {
                localDateTimeEndOfNext = localEndOfNextMonth;
            } else if (bCycle.getDateOffset() > localDateTimeEndOfNext.getDayOfMonth()) {
                localDateTimeEndOfNext = localDateTimeEndOfNext.withDayOfMonth(
                        bCycle.getDateOffset().intValue());
            }
        }
               
        return getMtxTimestampFromLocalDatetime(localDateTimeEndOfNext, zoneId);
    }

    public static MtxTimestamp getNextToNextCycleEndTime(MtxBillingCycleInfo bCycle,
                                                         String defaultTimeZone) {
        MtxTimestamp startOfNext = bCycle.getCurrentPeriodEndTime();
        String startOfNexString = startOfNext.getTime();
        startOfNexString = startOfNexString.substring(0,25);
        LocalDateTime localStartOfNext = LocalDateTime.parse(startOfNexString);
        ZoneId timeZone=getZoneIdForMtxTimestamp(startOfNext, defaultTimeZone);
        
        LocalDateTime localEndOfNextToNextCycle = localStartOfNext.plusMonths(2);
        if (DATE_POLICY.OFFSET_FROM_START == bCycle.getDatePolicy()
                && bCycle.getDateOffset() != null && bCycle.getDateOffset() > 0) {
            LocalDateTime localEndOfNextToNextMonth = localEndOfNextToNextCycle.with(
                    TemporalAdjusters.lastDayOfMonth());
            if (bCycle.getDateOffset() > localEndOfNextToNextMonth.getDayOfMonth()) {
                localEndOfNextToNextCycle = localEndOfNextToNextMonth;
            } else if (bCycle.getDateOffset() > localEndOfNextToNextCycle.getDayOfMonth()) {
                localEndOfNextToNextCycle = localEndOfNextToNextMonth.withDayOfMonth(
                        bCycle.getDateOffset().intValue());
            }
        }

        return getMtxTimestampFromLocalDatetime(localEndOfNextToNextCycle, timeZone);
    }

    /**
     * create MtxRequestSubscriberRecharge object with provided details
     *
     * @param searchData
     * @param chargeMethodData
     * @param reason
     * @param info
     * @param amount
     * @param orderId
     * @return
     */
    public static MtxRequestSubscriberRecharge getSubscriberRechargeRequest(MtxSubscriberSearchData searchData,
                                                                            MtxChargeMethodData chargeMethodData,
                                                                            String reason,
                                                                            String info,
                                                                            BigDecimal amount,
                                                                            String orderId) {
        MtxRequestSubscriberRecharge subRecharge = new MtxRequestSubscriberRecharge();
        if (StringUtils.isNotBlank(orderId)) {
            VisibleRechargeExtension visRechargeExtn = new VisibleRechargeExtension();
            visRechargeExtn.setOrderId(orderId);
            subRecharge.setRechargeAttr(visRechargeExtn);
        }
        subRecharge.setSubscriberSearchData(searchData);
        subRecharge.setAmount(amount);
        subRecharge.setReason(reason);
        subRecharge.setInfo(info);
        subRecharge.setChargeMethodData(chargeMethodData);
        return subRecharge;
    }

    public static void addPaymentInfoToChargeMethodData(MtxChargeMethodData chargeMethodData,
                                                        String paymentMethod,
                                                        String paymentInfo,
                                                        String paymentGatewayId) {

        if (!StringUtils.isEmpty(paymentGatewayId)
                && StringUtils.isNumeric(paymentGatewayId.trim())) {
            chargeMethodData.setPaymentGatewayId(Long.valueOf(paymentGatewayId.trim()));
        }

        // If PaymentMethod==2 then PaymentInfo is nonce
        if (paymentMethod.trim().equals(MATRIXX_CONSTANTS.PAYMENT_METHOD_TOKEN)
                && !StringUtils.isEmpty(paymentInfo)) {
            chargeMethodData.setPaymentGatewayOneTimeToken(paymentInfo.trim());
        }

        // If PaymentMethod==1 then PaymentInfo is PaymentMethodResourceId
        if (paymentMethod.trim().equals(MATRIXX_CONSTANTS.PAYMENT_METHOD_REGISTERED)
                && !StringUtils.isEmpty(paymentInfo) && StringUtils.isNumeric(paymentInfo.trim())) {
            chargeMethodData.setPaymentMethodResourceId(Long.valueOf(paymentInfo));
        }

    }

    public static void addFraudInfoToChargeMethodData(MtxChargeMethodData chargeMethodData,
                                                      VisibleFraudHomeAddress fraudBillingAddress,
                                                      VisibleFraudShippingAddress fraudShippingAddress,
                                                      VisibleFraudDeviceInfo fraudDeviceInfo,
                                                      String transactionType,
                                                      boolean visibleRecurringOverride,
                                                      List<VisibleAttribute> paymentGatewayAttributes,
                                                      String loggingKey)
            throws CommonUtilsException, IntrospectionException {
        VisibleAttribute vatt = new VisibleAttribute();
        vatt.setName(TRANSACTION_TYPE);
        vatt.setValue(transactionType);
        paymentGatewayAttributes.add(vatt);

        VisibleAttribute varo = new VisibleAttribute();
        varo.setName(VISIBLE_RECURRING_OVERRIDE);
        varo.setValue(visibleRecurringOverride + "");
        paymentGatewayAttributes.add(varo);
        addFraudInfoToChargeMethodData(
                chargeMethodData, fraudBillingAddress, fraudShippingAddress, fraudDeviceInfo,
                paymentGatewayAttributes, loggingKey);
    }

    public static void addFraudInfoToChargeMethodData(MtxChargeMethodData chargeMethodData,
                                                      VisibleFraudHomeAddress fraudBillingAddress,
                                                      VisibleFraudShippingAddress fraudShippingAddress,
                                                      VisibleFraudDeviceInfo fraudDeviceInfo,
                                                      List<VisibleAttribute> udfList,
                                                      String loggingKey)
            throws CommonUtilsException, IntrospectionException {

        VisibleBraintreeChargeMethodExtension chargeMethodExt = new VisibleBraintreeChargeMethodExtension();

        HashMap<String, String> udfTypes = new HashMap<String, String>();

        for (PropertyDescriptor propertyDescriptor : Introspector.getBeanInfo(
                VisibleBraintreeChargeMethodExtension.class).getPropertyDescriptors()) {

            udfTypes.put(
                    propertyDescriptor.getName().toUpperCase(),
                    propertyDescriptor.getPropertyType().getSimpleName());
        }

        for (VisibleAttribute udf : udfList) {
            if (udfTypes.containsKey(udf.getName().toUpperCase())) {
                DEBUG(
                        m_logger, loggingKey + "Adding UDF paramter : - " + udf.getName()
                                + " : Value is : " + udf.getValue());
                setContainerField(
                        chargeMethodExt, udf.getName(), udfTypes.get(udf.getName().toUpperCase()),
                        udf.getValue());
            }
        }

        // Fraud billing Address
        MtxAddressData billingAddress = new MtxAddressData();
        if (!StringUtils.isEmpty(fraudBillingAddress.getFirstName())) {
            billingAddress.setFirstName(fraudBillingAddress.getFirstName());
        }
        if (!StringUtils.isEmpty(fraudBillingAddress.getLastName())) {
            billingAddress.setLastName(fraudBillingAddress.getLastName());
        }
        if (!StringUtils.isEmpty(fraudBillingAddress.getCompany())) {
            billingAddress.setCompany(fraudBillingAddress.getCompany());
        }
        if (!StringUtils.isEmpty(fraudBillingAddress.getStreetAddress())) {
            billingAddress.setStreetAddress(fraudBillingAddress.getStreetAddress());
        }
        if (!StringUtils.isEmpty(fraudBillingAddress.getExtendedAddress())) {
            billingAddress.setExtendedAddress(fraudBillingAddress.getExtendedAddress());
        }
        if (!StringUtils.isEmpty(fraudBillingAddress.getLocality())) {
            billingAddress.setLocality(fraudBillingAddress.getLocality());
        }
        if (!StringUtils.isEmpty(fraudBillingAddress.getRegion())) {
            billingAddress.setRegion(fraudBillingAddress.getRegion());
        }
        if (!StringUtils.isEmpty(fraudBillingAddress.getPostalCode())) {
            billingAddress.setPostalCode(fraudBillingAddress.getPostalCode());
        }
        if (!StringUtils.isEmpty(fraudBillingAddress.getCountryCode())) {
            billingAddress.setCountryCode(fraudBillingAddress.getCountryCode());
        }

        chargeMethodExt.setBillingAddress(billingAddress);

        // Fraud Shipping Address
        MtxAddressData shippingAddress = new MtxAddressData();
        if (!StringUtils.isEmpty(fraudShippingAddress.getFirstName())) {
            shippingAddress.setFirstName(fraudShippingAddress.getFirstName());
        }
        if (!StringUtils.isEmpty(fraudShippingAddress.getLastName())) {
            shippingAddress.setLastName(fraudShippingAddress.getLastName());
        }
        if (!StringUtils.isEmpty(fraudShippingAddress.getCompany())) {
            shippingAddress.setCompany(fraudShippingAddress.getCompany());
        }
        if (!StringUtils.isEmpty(fraudShippingAddress.getStreetAddress())) {
            shippingAddress.setStreetAddress(fraudShippingAddress.getStreetAddress());
        }
        if (!StringUtils.isEmpty(fraudShippingAddress.getExtendedAddress())) {
            shippingAddress.setExtendedAddress(fraudShippingAddress.getExtendedAddress());
        }
        if (!StringUtils.isEmpty(fraudShippingAddress.getLocality())) {
            shippingAddress.setLocality(fraudShippingAddress.getLocality());
        }
        if (!StringUtils.isEmpty(fraudShippingAddress.getRegion())) {
            shippingAddress.setRegion(fraudShippingAddress.getRegion());
        }
        if (!StringUtils.isEmpty(fraudShippingAddress.getPostalCode())) {
            shippingAddress.setPostalCode(fraudShippingAddress.getPostalCode());
        }
        if (!StringUtils.isEmpty(fraudShippingAddress.getCountryCode())) {
            shippingAddress.setCountryCode(fraudShippingAddress.getCountryCode());
        }
        if (!StringUtils.isEmpty(fraudDeviceInfo.getDeviceData())) {
            chargeMethodExt.setDeviceData(fraudDeviceInfo.getDeviceData());
        }

        chargeMethodExt.setShippingAddress(shippingAddress);

        chargeMethodData.setChargeMethodAttr(chargeMethodExt);
    }

    public static void addFraudInfoAndPaymentInfoToChargeMethodData(MtxChargeMethodData chargeMethodData,
                                                                    VisibleFraudHomeAddress fraudBillingAddress,
                                                                    VisibleFraudShippingAddress fraudShippingAddress,
                                                                    VisibleFraudDeviceInfo fraudDeviceInfo,
                                                                    String transactionType,
                                                                    boolean visibleRecurringOverride,
                                                                    List<VisibleAttribute> paymentGatewayAttributes,
                                                                    String loggingKey,
                                                                    String paymentMethod,
                                                                    String paymentInfo,
                                                                    String paymentGatewayId,
                                                                    String orderId,
                                                                    String paymentReason)
            throws CommonUtilsException, IntrospectionException {
        VisibleAttribute vatt = new VisibleAttribute();
        vatt.setName(TRANSACTION_TYPE);
        vatt.setValue(transactionType);
        paymentGatewayAttributes.add(vatt);

        VisibleAttribute varo = new VisibleAttribute();
        varo.setName(VISIBLE_RECURRING_OVERRIDE);

        varo.setValue(visibleRecurringOverride + "");
        paymentGatewayAttributes.add(varo);
        addFraudInfoAndPaymentInfoToChargeMethodData(
                chargeMethodData, fraudBillingAddress, fraudShippingAddress, fraudDeviceInfo,
                paymentGatewayAttributes, loggingKey, paymentMethod, paymentInfo, paymentGatewayId,
                orderId, paymentReason);
    }

    public static void addFraudInfoAndPaymentInfoToChargeMethodData(MtxChargeMethodData chargeMethodData,
                                                                    VisibleFraudHomeAddress fraudBillingAddress,
                                                                    VisibleFraudShippingAddress fraudShippingAddress,
                                                                    VisibleFraudDeviceInfo fraudDeviceInfo,
                                                                    List<VisibleAttribute> udfList,
                                                                    String loggingKey,
                                                                    String paymentMethod,
                                                                    String paymentInfo,
                                                                    String paymentGatewayId,
                                                                    String orderId,
                                                                    String paymentReason)
            throws CommonUtilsException, IntrospectionException {

        VisibleBraintreeChargeMethodExtension chargeMethodExt = new VisibleBraintreeChargeMethodExtension();

        HashMap<String, String> udfTypes = new HashMap<String, String>();

        for (PropertyDescriptor propertyDescriptor : Introspector.getBeanInfo(
                VisibleBraintreeChargeMethodExtension.class).getPropertyDescriptors()) {

            udfTypes.put(
                    propertyDescriptor.getName().toUpperCase(),
                    propertyDescriptor.getPropertyType().getSimpleName());
        }

        chargeMethodExt.setVisibleRecurringOverride(false);

        for (VisibleAttribute udf : udfList) {
            if (udfTypes.containsKey(udf.getName().toUpperCase())) {
                DEBUG(
                        m_logger, loggingKey + "Adding UDF paramter : - " + udf.getName()
                                + " : Value is : " + udf.getValue());
                setContainerField(
                        chargeMethodExt, udf.getName(), udfTypes.get(udf.getName().toUpperCase()),
                        udf.getValue());
            }

            if (VISIBLE_RECURRING_OVERRIDE.equalsIgnoreCase(udf.getName().toUpperCase())
                    && Boolean.TRUE.toString().equalsIgnoreCase(udf.getValue().trim())) {
                chargeMethodExt.setVisibleRecurringOverride(true);
            }
        }

        // Fraud billing Address
        MtxAddressData billingAddress = new MtxAddressData();
        if (!StringUtils.isEmpty(fraudBillingAddress.getFirstName())) {
            billingAddress.setFirstName(fraudBillingAddress.getFirstName());
        }
        if (!StringUtils.isEmpty(fraudBillingAddress.getLastName())) {
            billingAddress.setLastName(fraudBillingAddress.getLastName());
        }
        if (!StringUtils.isEmpty(fraudBillingAddress.getCompany())) {
            billingAddress.setCompany(fraudBillingAddress.getCompany());
        }
        if (!StringUtils.isEmpty(fraudBillingAddress.getStreetAddress())) {
            billingAddress.setStreetAddress(fraudBillingAddress.getStreetAddress());
        }
        if (!StringUtils.isEmpty(fraudBillingAddress.getExtendedAddress())) {
            billingAddress.setExtendedAddress(fraudBillingAddress.getExtendedAddress());
        }
        if (!StringUtils.isEmpty(fraudBillingAddress.getLocality())) {
            billingAddress.setLocality(fraudBillingAddress.getLocality());
        }
        if (!StringUtils.isEmpty(fraudBillingAddress.getRegion())) {
            billingAddress.setRegion(fraudBillingAddress.getRegion());
        }
        if (!StringUtils.isEmpty(fraudBillingAddress.getPostalCode())) {
            billingAddress.setPostalCode(fraudBillingAddress.getPostalCode());
        }
        if (!StringUtils.isEmpty(fraudBillingAddress.getCountryCode())) {
            billingAddress.setCountryCode(fraudBillingAddress.getCountryCode());
        }

        chargeMethodExt.setBillingAddress(billingAddress);

        // Fraud Shipping Address
        MtxAddressData shippingAddress = new MtxAddressData();
        if (!StringUtils.isEmpty(fraudShippingAddress.getFirstName())) {
            shippingAddress.setFirstName(fraudShippingAddress.getFirstName());
        }
        if (!StringUtils.isEmpty(fraudShippingAddress.getLastName())) {
            shippingAddress.setLastName(fraudShippingAddress.getLastName());
        }
        if (!StringUtils.isEmpty(fraudShippingAddress.getCompany())) {
            shippingAddress.setCompany(fraudShippingAddress.getCompany());
        }
        if (!StringUtils.isEmpty(fraudShippingAddress.getStreetAddress())) {
            shippingAddress.setStreetAddress(fraudShippingAddress.getStreetAddress());
        }
        if (!StringUtils.isEmpty(fraudShippingAddress.getExtendedAddress())) {
            shippingAddress.setExtendedAddress(fraudShippingAddress.getExtendedAddress());
        }
        if (!StringUtils.isEmpty(fraudShippingAddress.getLocality())) {
            shippingAddress.setLocality(fraudShippingAddress.getLocality());
        }
        if (!StringUtils.isEmpty(fraudShippingAddress.getRegion())) {
            shippingAddress.setRegion(fraudShippingAddress.getRegion());
        }
        if (!StringUtils.isEmpty(fraudShippingAddress.getPostalCode())) {
            shippingAddress.setPostalCode(fraudShippingAddress.getPostalCode());
        }
        if (!StringUtils.isEmpty(fraudShippingAddress.getCountryCode())) {
            shippingAddress.setCountryCode(fraudShippingAddress.getCountryCode());
        }
        if (!StringUtils.isEmpty(fraudDeviceInfo.getDeviceData())) {
            chargeMethodExt.setDeviceData(fraudDeviceInfo.getDeviceData());
        }

        chargeMethodExt.setShippingAddress(shippingAddress);

        if (!StringUtils.isEmpty(paymentGatewayId)
                && StringUtils.isNumeric(paymentGatewayId.trim())) {
            chargeMethodData.setPaymentGatewayId(Long.valueOf(paymentGatewayId.trim()));
        }

        // If PaymentMethod==2 then PaymentInfo is nonce
        if (paymentMethod.trim().equals(MATRIXX_CONSTANTS.PAYMENT_METHOD_TOKEN)
                && !StringUtils.isEmpty(paymentInfo)) {
            chargeMethodData.setPaymentGatewayOneTimeToken(paymentInfo.trim());
        }

        // If PaymentMethod==1 then PaymentInfo is PaymentMethodResourceId
        if (paymentMethod.trim().equals(MATRIXX_CONSTANTS.PAYMENT_METHOD_REGISTERED)
                && !StringUtils.isEmpty(paymentInfo) && StringUtils.isNumeric(paymentInfo.trim())) {
            chargeMethodData.setPaymentMethodResourceId(Long.valueOf(paymentInfo));
        }

        // chargeMethodExt.setVisibleRecurringOverride(false);

        boolean chargeMethodAttrExists = false;
        if (StringUtils.isNoneBlank(orderId)) {
            chargeMethodExt.setOrderId(orderId);
            chargeMethodAttrExists = true;
        }

        if (StringUtils.isNoneBlank(paymentReason)) {
            chargeMethodExt.setPaymentReason(paymentReason);
            chargeMethodAttrExists = true;
        }

        if (chargeMethodAttrExists) {
            chargeMethodData.setChargeMethodAttr(chargeMethodExt);
        }
    }

    /**
     * Obtain a subscriber purchase offer request.
     *
     * @param ciExternalId
     * @param poExtnFldMap
     * @return
     * @throws CommonUtilsException
     * @throws IntrospectionException
     */
    public static MtxPurchasedOfferData getPurchasedOfferData(String ciExternalId,
                                                              Map<String, String> poExtnFldMap)
            throws CommonUtilsException, IntrospectionException {

        HashMap<String, String> fldTypes = new HashMap<String, String>();
        for (PropertyDescriptor propertyDescriptor : Introspector.getBeanInfo(
                VisiblePurchasedOfferExtension.class).getPropertyDescriptors()) {
            if (propertyDescriptor.getPropertyType() != null) {
                fldTypes.put(
                        propertyDescriptor.getName().toUpperCase(),
                        propertyDescriptor.getPropertyType().getSimpleName());
            }
        }

        VisiblePurchasedOfferExtension poExtn = new VisiblePurchasedOfferExtension();
        for (Entry<String, String> entry : poExtnFldMap.entrySet()) {
            if (StringUtils.isNotBlank(entry.getValue())) {
                setContainerField(
                        poExtn, entry.getKey(), fldTypes.get(entry.getKey().toUpperCase()),
                        entry.getValue());
            }
        }

        MtxPurchasedOfferData offerData = new MtxPurchasedOfferData();
        offerData.setExternalId(ciExternalId);
        DEBUG(m_logger, " : " + "poExtn for " + ciExternalId + ":" + poExtn.toJson());
        offerData.setAttr(poExtn);

        return offerData;
    }

    public static MtxPurchasedOfferInfo getPurchasedOfferInfo(String loggingKey,
                                                              MtxResponseSubscription subscriber,
                                                              String catalogItemExternalId) {
        final String methodName = "getPurchasedOfferInfo: ";
        if (subscriber.getPurchasedOfferArray() == null
                || subscriber.getPurchasedOfferArray().isEmpty()) {
            WARN(m_logger, loggingKey + methodName + "Subscriber has no purchased offer.");
            return null;
        }

        for (MtxPurchasedOfferInfo poi : subscriber.getPurchasedOfferArray()) {
            if (StringUtils.isBlank(poi.getCatalogItemExternalId())) {
                continue;
            }

            if (!catalogItemExternalId.equalsIgnoreCase(poi.getCatalogItemExternalId())) {
                continue;
            }

            if (!isOfferActiveOnDate(
                    loggingKey, m_logger, poi, new MtxTimestamp((new Date()).getTime()))) {
                continue;
            }

            return poi;
        }

        WARN(
                m_logger,
                loggingKey + methodName + "Subscriber does not have active purchased offer "
                        + catalogItemExternalId);
        return null;
    }

    @SuppressWarnings("static-access")
    public static VisiblePurchasedOfferExtension cloneVisiblePurchasedOfferExtension(VisiblePurchasedOfferExtension sourceObj)
            throws CommonUtilsException, IntrospectionException {
        if (sourceObj == null) {
            return null;
        }
        VisiblePurchasedOfferExtension retObj = new VisiblePurchasedOfferExtension();
        DataContainerFactory dcf = DataContainerFactory.getInstance().getInstance();
        DataContainer dc = new DataContainer(dcf);
        JsonObject jsonInput = new JsonObject();
        jsonInput.parse(sourceObj.toJson());
        dc.readFrom(jsonInput);
        retObj.readFrom(dc);
        return retObj;
    }

    public static String getContainerFieldAsString(BaseContainer container, String fldName)
            throws IntrospectionException {
        for (PropertyDescriptor propertyDescriptor : Introspector.getBeanInfo(
                container.getClass()).getPropertyDescriptors()) {
            // get list of values from Extension
            if (fldName.trim().equalsIgnoreCase(propertyDescriptor.getName())) {
                Method method = ReflectionUtils.findMethod(
                        container.getClass(),
                        "get" + StringUtils.capitalize(propertyDescriptor.getName()));
                return (String) ReflectionUtils.invokeMethod(method, container);
            }
        }
        return "";
    }

    private static void setContainerField(BaseContainer container,
                                          String fldName,
                                          String fldType,
                                          String fldValue)
            throws CommonUtilsException {

        switch (fldType) {
            case "String":
                container.setString(container.getContainer().lookupKey(fldName), fldValue);
                break;
            case "Boolean":
                container.setBoolean(
                        container.getContainer().lookupKey(fldName),
                        Boolean.parseBoolean(fldValue));
                break;
            case "Long":
                container.setLong(container.getContainer().lookupKey(fldName), Long.parseLong(fldValue));
                break;
            case "Integer":
                container.setInteger(
                        container.getContainer().lookupKey(fldName), Integer.parseInt(fldValue));
                break;
            case "BigInteger":
                container.setBigInteger(
                        container.getContainer().lookupKey(fldName), new BigInteger(fldValue));
                break;
            case "BigDecimal":
                container.setBigDecimal(
                        container.getContainer().lookupKey(fldName), new BigDecimal(fldValue));
                break;
            case "MtxDate":
                container.setMtxDate(
                        container.getContainer().lookupKey(fldName), new MtxDate(fldValue));
                break;
            case "MtxTime":
                container.setMtxTime(
                        container.getContainer().lookupKey(fldName), new MtxTime(fldValue));

                break;
            case "MtxTimestamp":
                container.setMtxTimestamp(
                        container.getContainer().lookupKey(fldName), new MtxTimestamp(fldValue));
                break;
            case "MtxObjectId":
                container.setMtxObjectId(
                        container.getContainer().lookupKey(fldName), new MtxObjectId(fldValue));
                break;

            case "Blob":
                WARN(
                        m_logger,
                        " : " + "Blob can not be set as container field. Allowed datatypes are String, Boolean, Long, Integer, BigInteger, BigDecimal, MtxDate, MtxTime, MtxTimestamp and MtxObjectId");
                throw new CommonUtilsException(
                        RESULT_CODES.HTTP_INTERNAL_ERROR,
                        "Blob can not be set as container field. Allowed datatypes are String, Boolean, Long, Integer, BigInteger, BigDecimal, MtxDate, MtxTime, MtxTimestamp and MtxObjectId");
            case "struct":
                WARN(
                        m_logger,
                        " : " + "struct can not be set as UDF. Allowed datatypes are String, Boolean, Long, Integer, BigInteger, BigDecimal, MtxDate, MtxTime, MtxTimestamp and MtxObjectId");
                throw new CommonUtilsException(
                        RESULT_CODES.HTTP_INTERNAL_ERROR,
                        "struct can not be set as container field. Allowed datatypes are String, Boolean, Long, Integer, BigInteger, BigDecimal, MtxDate, MtxTime, MtxTimestamp and MtxObjectId");
            default:
                break;
        }
    }

    public static void validateResponse(String loggingKey,
                                        String errorContext,
                                        Logger m_logger,
                                        Class<? extends IntegrationServiceException> exceptionClass,
                                        MtxResponse response)
            throws IntegrationServiceException, NoSuchMethodException, SecurityException,
            InstantiationException, IllegalAccessException, IllegalArgumentException,
            InvocationTargetException

    {
        Constructor<?> exceptionConstructor = exceptionClass.getConstructor(
                Long.class, String.class);
        Long resultCode = null;
        String message = null;
        if (response == null) {
            resultCode = RESULT_CODES.HTTP_INTERNAL_ERROR;
            message = errorContext + " - response is null";
        } else if (response.getResult() == null) {
            resultCode = RESULT_CODES.HTTP_INTERNAL_ERROR;
            message = errorContext + " - response has no result code";
        } else if (!response.getResult().equals(RESULT_CODES.MTX_SUCCESS)) {
            message = errorContext + " - " + response.getResultText();
            resultCode = response.getResult();
        } else if (response instanceof MtxResponseMulti) {
            MtxResponseMulti multiResp = (MtxResponseMulti) response;
            if (multiResp.getResponseList() == null || multiResp.getResponseList().isEmpty()) {
                resultCode = multiResp.getResult();
                message = "Multiresponse has no results"
                        + (multiResp != null ? " - " + multiResp.getResultText() : "");
            }
        }
        if (resultCode != null) {
            WARN(m_logger, loggingKey + " : " + message);
            throw exceptionClass.cast(exceptionConstructor.newInstance(resultCode, message));
        }
    }

    public static boolean isOfferActiveOnDate(String loggingKey,
                                              Logger m_logger,
                                              MtxPurchasedOfferInfo poi,
                                              MtxTimestamp refTimestamp) {
        final String methodKey = loggingKey + " isOfferActive: ";
        DEBUG(m_logger, methodKey);
        if (!OFFER_CONSTANTS.OFFER_STATUS_ACTIVE.equalsIgnoreCase(
                poi.getOfferStatusDescription().toString())) {
            DEBUG(
                    m_logger,
                    methodKey + poi.getProductOfferExternalId() + " is not an active offer.");
            return false;
        }
        if (poi.getStartTime() != null
                && poi.getStartTime().longValue() > refTimestamp.longValue()) {
            DEBUG(m_logger, methodKey + poi.getProductOfferExternalId() + " future offer.");
            return false;
        }
        if (poi.getEndTime() != null && poi.getEndTime().longValue() <= refTimestamp.longValue()) {
            DEBUG(m_logger, methodKey + poi.getProductOfferExternalId() + " ended offer.");
            return false;
        }
        if (poi.getCancelTime() != null
                && poi.getCancelTime().longValue() <= refTimestamp.longValue()) {
            DEBUG(m_logger, methodKey + poi.getProductOfferExternalId() + " cancelled offer.");
            return false;
        }

        return true;
    }

    public static boolean isOfferPreActive(String loggingKey,
                                           Logger m_logger,
                                           MtxPurchasedOfferInfo poi,
                                           MtxTimestamp billCycleEnd) {
        final String methodKey = loggingKey + " isOfferPreActive: ";
        if (!OFFER_CONSTANTS.OFFER_STATUS_PRE_ACTIVE.equalsIgnoreCase(
                poi.getOfferStatusDescription().toString())) {
            DEBUG(
                    m_logger,
                    methodKey + poi.getProductOfferExternalId() + " is not a preactive offer.");
            return false;
        } else {
            if (poi.getAutoActivationTime() != null
                    && poi.getAutoActivationTime().longValue() <= billCycleEnd.longValue()) {
                DEBUG(
                        m_logger, methodKey + poi.getProductOfferExternalId()
                                + " gets activated on or before end of Bill Cycle.");
                return true;
            }

            if (poi.getStartTime() != null
                    && poi.getStartTime().longValue() <= billCycleEnd.longValue()) {
                DEBUG(
                        m_logger, methodKey + poi.getProductOfferExternalId()
                                + " starts on or before Bill Cycle End.");
                return true;
            }
            DEBUG(
                    m_logger, methodKey + poi.getProductOfferExternalId()
                            + " does not start before Bill Cycle End.");

            return false;
        }
    }

    public static boolean willOfferBeActive(String loggingKey,
                                            Logger m_logger,
                                            MtxPurchasedOfferInfo poi,
                                            MtxTimestamp refTimestamp) {
        final String methodKey = loggingKey + "willOfferBeActive: ";

        List<String> validStatus = Arrays.asList(
                OFFER_CONSTANTS.OFFER_STATUS_PRE_ACTIVE.toUpperCase(),
                OFFER_CONSTANTS.OFFER_STATUS_ACTIVE.toUpperCase());
        if (!validStatus.contains(poi.getOfferStatusDescription().toUpperCase())) {
            DEBUG(
                    m_logger, methodKey + poi.getCatalogItemExternalId()
                            + " is neither preactive nor active now. Offer will not be active.");
            return false;
        }

        if (poi.getEndTime() != null && poi.getEndTime().longValue() <= refTimestamp.longValue()) {
            DEBUG(
                    m_logger,
                    methodKey + poi.getCatalogItemExternalId() + " ends by: " + refTimestamp);
            return false;
        }

        if (poi.getStartTime() != null
                && poi.getStartTime().longValue() > refTimestamp.longValue()) {
            DEBUG(
                    m_logger,
                    methodKey + poi.getCatalogItemExternalId() + " starts after: " + refTimestamp);
            return false;
        }

        if (poi.getAutoActivationTime() != null
                && poi.getAutoActivationTime().longValue() > refTimestamp.longValue()) {
            DEBUG(
                    m_logger, methodKey + poi.getCatalogItemExternalId() + " activates after: "
                            + refTimestamp);
            return false;
        }

        return true;
    }

    public static BigDecimal getBalanceAmount(MtxBalanceInfo bInfo) {
        return bInfo.getAmount().negate();
    }

    public static BigDecimal getBalanceAmountOnDate(MtxBalanceInfo bInfo,
                                                    MtxTimestamp refTimestamp) {
        if (refTimestamp == null) {
            return bInfo.getAmount().negate();
        } else if (bInfo.getEndTime() == null) {
            return bInfo.getAmount().negate();
        } else if (refTimestamp != null && bInfo.getEndTime() != null
                && refTimestamp.longValue() < bInfo.getEndTime().longValue()) {
            return bInfo.getAmount().negate();
        } else {
            return BigDecimal.ZERO;
        }
    }

    public static boolean isBalanceActiveOnDate(String loggingKey,
                                                Logger m_logger,
                                                MtxBalanceInfo bInfo,
                                                MtxTimestamp refTimestamp) {
        final String methodName = "getBalanceActiveOnDate: ";
        if (bInfo.getStartTime() != null
                && bInfo.getStartTime().longValue() > refTimestamp.longValue()) {
            DEBUG(
                    m_logger, loggingKey + methodName + StringUtils.SPACE + bInfo.getName()
                            + " future balance.");
            return false;
        }
        if (bInfo.getEndTime() != null
                && bInfo.getEndTime().longValue() <= refTimestamp.longValue()) {
            DEBUG(
                    m_logger, loggingKey + methodName + StringUtils.SPACE + bInfo.getName()
                            + " ended balance.");
            return false;
        }

        return true;
    }

    public static boolean isServiceTaxResponseValid(String jsonString) {
        try {
            (new Gson()).fromJson(jsonString, ServiceTaxResponse.class);
            return true;
        } catch (Exception ex) {
            return false;
        }
    }

    public static MtxRequestSubscriberModifyOffer getSubscriberModifyOfferRequest(MtxSubscriberSearchData searchData,
                                                                                  Long resourceId,
                                                                                  VisiblePurchasedOfferExtension attr) {
        MtxRequestSubscriberModifyOffer subModifyOffer = new MtxRequestSubscriberModifyOffer();
        subModifyOffer.setSubscriberSearchData(searchData);
        subModifyOffer.setResourceId(resourceId);
        subModifyOffer.setAttr(attr);
        return subModifyOffer;
    }

    public static ObjectMapper getObjectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(Feature.WRITE_BIGDECIMAL_AS_PLAIN, true);
        return objectMapper;
    }

    public static MtxPaymentMethodInfo getCurrentPaymentMethodFromApiResponse(MtxResponsePaymentMethodInfo paymentMethodInfoRes) {
        MtxPaymentMethodInfo currentPaymentMethodInfo = null;
        if (paymentMethodInfoRes != null
                && paymentMethodInfoRes.getPaymentMethodInfoList() != null) {
            ArrayList<MtxPaymentMethodInfo> paymentMethodList = paymentMethodInfoRes.getPaymentMethodInfoList();
            for (MtxPaymentMethodInfo paymentMethodInfo : paymentMethodList) {
                if (paymentMethodInfo.getIsDefault() != null && paymentMethodInfo.getIsDefault()) {
                    currentPaymentMethodInfo = paymentMethodInfo;
                    return currentPaymentMethodInfo;
                }
            }
        }
        return currentPaymentMethodInfo;
    }

    public static String getCurrentOrderId(MtxResponseSubscription subscription, String catalogItemExternalId) {
        ArrayList<MtxPurchasedOfferInfo> offerArray = subscription.getPurchasedOfferArray();
        String orderId = "";
        if(offerArray != null) {
            for(MtxPurchasedOfferInfo offerInfo : offerArray) {
                //Check if it is a service.
                if (StringUtils.isBlank(offerInfo.getCatalogItemExternalId())) {
                    continue;
                }
                if (StringUtils.isBlank(catalogItemExternalId) && !offerInfo.getCatalogItemExternalId().equalsIgnoreCase(catalogItemExternalId)) {
                    continue;
                }
                if (offerInfo.getAttr() == null) {
                    continue;
                }
                VisiblePurchasedOfferExtension offerExtn = (VisiblePurchasedOfferExtension) offerInfo.getAttr();
                if (StringUtils.isBlank(offerExtn.getOrderId())) {
                    continue;
                } else {
                    orderId = offerExtn.getOrderId();
                }
                break;
            }
        }
        return orderId;
    }
    
    public static String getNewOrderId(String oldOrderId) {
        String noHyphenId = "";
        if (StringUtils.isNotBlank(oldOrderId)) {
            if (oldOrderId.contains("-")) {
                String[] orderIdOrg = oldOrderId.split("-");
                noHyphenId = orderIdOrg[1];
            } else {
                noHyphenId = oldOrderId;
            }
        } else {
            noHyphenId = RandomStringUtils.randomAlphanumeric(16);
        }

        String newOrderId = CommonUtils.getDateYYMMDDString() + "-" + noHyphenId;
        return newOrderId;
    }

    public static void validateMtxResponse(String loggingKey, String errorContext, MtxResponse response)
            throws MtxResponseException{
        String methodKey = loggingKey + " validateMtxResponse: ";
        if (response == null) {
            WARN(m_logger, methodKey + errorContext + " - response is null");
            throw new MtxResponseException(RESULT_CODES.HTTP_NOT_FOUND, errorContext);
        }
        if (!response.getResult().equals(RESULT_CODES.MTX_SUCCESS)) {
            String message = errorContext + " - " + response.getResultText();
            WARN(m_logger, methodKey + message);
            throw new MtxResponseException(response.getResult(), message);
        }
    }
    
    public static BigDecimal getCurrencyAmount(MtxResponsePurchase responsePurchase) {
        BigDecimal currencyAmount = BigDecimal.ZERO;
        if (responsePurchase.getPurchaseInfoArray() != null
                && !responsePurchase.getPurchaseInfoArray().isEmpty()) {
            for (MtxPurchaseInfo purchaseInfoItem : responsePurchase.getPurchaseInfoArray()) {
                currencyAmount = currencyAmount.add(
                        getCurrencyAmount(
                                purchaseInfoItem.getBalanceImpactGroupList()));
            }
        }
        return currencyAmount;
    }
    public static BigDecimal getCurrencyAmount(ArrayList<MtxBalanceImpactInfoGroup> bigl) {
        BigDecimal retVal = BigDecimal.ZERO;
        if (bigl != null && !bigl.isEmpty()) {
            for (MtxBalanceImpactInfoGroup balanceImpGrpItem : bigl) {
                if (balanceImpGrpItem.getBalanceImpactList() != null
                        && !balanceImpGrpItem.getBalanceImpactList().isEmpty()) {
                    for (MtxBalanceImpactInfo balanceImpInfoItem : balanceImpGrpItem.getBalanceImpactList()) {
                        if (balanceImpInfoItem.getImpactAmount() != null
                                // Group Discount impact amount is shown as negative. Main balance
                                // is shown as positive. Hence != or abs
                                && balanceImpInfoItem.getImpactAmount().signum() != 0
                                && balanceImpInfoItem.getBalanceClassId() != null
                                && balanceImpInfoItem.getBalanceClassId().longValue() == BALANCE_CONSTANTS.BALANCE_CLASS_ID_USD) {
                            retVal = retVal.add(balanceImpInfoItem.getImpactAmount());
                        }
                    }
                }
            }
        }
        return retVal;
    }
    
    public static VisibleRiskData getRiskData(ArrayList<MtxResponse> responseList, int rechargeIndex) {
        VisibleRiskData riskData = new VisibleRiskData();
        MtxResponseRecharge rechargeResp = null;
        String riskDataDeviceData = PAYMENT_CONSTANTS.DEFAULT_RISK_DATA;

        // Use the braintree values if available:
        if (rechargeIndex >= 0 && rechargeIndex < responseList.size()
                && responseList.get(rechargeIndex) instanceof MtxResponseRecharge) {
            rechargeResp = (MtxResponseRecharge) responseList.get(rechargeIndex);

            if (rechargeResp.getPaymentGatewayResponseAttr() != null) {
                MtxBraintreeResponseExtension btr = ((MtxBraintreeResponseExtension) rechargeResp.getPaymentGatewayResponseAttr());

                if (btr.getRiskDataId() != null) {
                    riskData.setRiskDataId(btr.getRiskDataId());
                }
                if (btr.getRiskDataDecision() != null) {
                    riskData.setRiskDataDecision(btr.getRiskDataDecision());
                }
                if (btr.getRiskDataDeviceDataCaptured() != null) {
                    riskDataDeviceData = btr.getRiskDataDeviceDataCaptured() ? "0" : "1";
                }
            }
        }

        riskData.setRiskDataDeviceDataCaptured(riskDataDeviceData);
        return riskData;
    }
    
    public static SimpleEntry<String, MtxPhone> getMDN(String loggingKey,
                                                       MtxResponseDevice device) {
        String methodKey = loggingKey + " getMDN: ";
        DEBUG(m_logger, methodKey);
        if (device == null || device.getAttr() == null) {
            DEBUG(m_logger, methodKey+"No device MDN available.");
            return null;
        }
        VisibleDeviceExtension deviceExtn = (VisibleDeviceExtension) device.getAttr();
        if (StringUtils.isNotBlank(deviceExtn.getDeviceType())
                && deviceExtn.getDeviceType().equalsIgnoreCase(
                        DEVICE_CONSTANTS.DEVICE_TYPE_WEARABLE)) {
            for (MtxPhone accessNum : emptyIfNull(deviceExtn.getAccessNumberArray())) {
                if (accessNum != null) {
                    return new SimpleEntry<String, MtxPhone>(
                            DEVICE_CONSTANTS.DEVICE_TYPE_WEARABLE, accessNum);
                }
            }

        } else {
            for (MtxPhone accessNum : emptyIfNull(deviceExtn.getAccessNumberArray())) {
                if (accessNum != null) {
                    return new SimpleEntry<String, MtxPhone>(
                            DEVICE_CONSTANTS.DEVICE_TYPE_SERVICE, accessNum);
                }
            }
        }
        return null;
    }
    
    public static <K,V> Map<K,V> emptyIfNull(Map<K,V> inputMap) {
        return Optional.ofNullable(inputMap).orElse(Collections.emptyMap());
    }

    public static <K,V> Collection<V> emptyValuesIfNull(Map<K,V> inputMap) {
        return Optional.ofNullable(inputMap.values()).orElse(Collections.emptyList());
    }
    
    public static <T> Collection<T> emptyIfNull(Collection<T> inputList) {
        return Optional.ofNullable(inputList).orElse(Collections.emptyList());
    }
    
    public static <T> boolean emptyOrNull(Collection<T> inputList) {
        return (inputList == null || inputList.isEmpty());
    }
    
    public static BigDecimal zeroIfNull(BigDecimal input) {
        return input==null?BigDecimal.ZERO:input;
    }

    public static Long zeroIfNull(Long input) {
        return input==null?Long.valueOf(0):input;
    }

    public static Long minusHighIfNull(Long input) {
        return input==null?-9999:input;
    }

    public static String blankIfNull(String input) {
        return ""+input;
    }

    public static void doNothing() {
        // This method does nothing
    }
    
    public static boolean csvContainsIgnoreCase(String csvString, String standloneString) {
        if(StringUtils.isBlank(csvString)) {
            return false;
        }else {
            return Arrays.stream(csvString.split(","))
                    .anyMatch(element -> element.trim().equalsIgnoreCase(standloneString.trim()));            
        }
    }

    public static MtxRequestSubscriberPurchaseOffer getSubscriberPurchaseOfferRequest(MtxSubscriberSearchData searchData,
                                                                               MtxPurchasedOfferData... offerDataList) {

        MtxRequestSubscriberPurchaseOffer subPurchaseOffer = new MtxRequestSubscriberPurchaseOffer();
        subPurchaseOffer.setSubscriberSearchData(searchData);

        for (MtxPurchasedOfferData offerData : offerDataList) {
            subPurchaseOffer.appendOfferRequestArray(offerData);
        }
        return subPurchaseOffer;
    }
    
    private static ZoneId getZoneIdForMtxTimestamp(MtxTimestamp refDateTime,
                                                   String timeZone) {
        ZoneId zoneId;
        if (StringUtils.isNotBlank(timeZone)) {
            zoneId = ZoneId.of(timeZone);
        } else if (refDateTime.getOffset() != null) {
            LocalDateTime offsetLDT = refDateTime.getOffset().toLocalDateTime();
            String offset = refDateTime.getOffsetSign() + String.format("%02d", offsetLDT.getHour())
                    + ":" + String.format("%02d", offsetLDT.getMinute());
            zoneId = ZoneId.of(offset);
        } else {
            zoneId = ZoneId.systemDefault();
        }
        return zoneId;
    }
    
    private static MtxTimestamp getMtxTimestampFromLocalDatetime(LocalDateTime ldt, ZoneId timeZone) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(MATRIXX_CONSTANTS.MTX_DATE_TIME_FORMAT);
        String zdtString = ldt.atZone(timeZone).format(formatter);
        if(zdtString.endsWith("+00:00")) {
            zdtString=zdtString.replace("+00:00", "Z");
        }       
        return new MtxTimestamp(zdtString);
    }
    

}
