package com.matrixx.vag.advice.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.matrixx.datacontainer.mdc.MtxPricingMetadataInfo;
import com.matrixx.datacontainer.mdc.VisibleTemplate;
import com.matrixx.vag.common.Constants.CI_METADATA;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.exception.PaymentAdviceException;

public class GlobalCreditStage {

    public enum TaxMethod {
        UNCHANGED, SUBTRACTION 
    }
    
    private final String grantOfferCi;  
    
    private String applicableCiCsv;
    private String classCode;
    private String consumableBalanceName;
    private String creditIncludeFlagName ;
    private String creditTaxBaseOfferRequestTemplate;
    private String creditGrantType;    
    private String discountCalculationMethod;
    private String grantBalanceName;
    private String grantOfferType;    
    private String promotionName;    
    private String redeemGoodType;
    private String redeemOfferCi;
    
    private BigDecimal applicableGrantPercentage;
    private BigDecimal availableCredits = BigDecimal.ZERO;
    private BigDecimal availableCreditsConsumable = BigDecimal.ZERO;
    private BigDecimal availableCreditsGrant = BigDecimal.ZERO;;
    private BigDecimal futureCreditsGrant = BigDecimal.ZERO;
    private BigDecimal consumablesUnavailableToChangeService = BigDecimal.ZERO;

	private BigDecimal creditCap = BigDecimal.ZERO;
	private BigDecimal creditCapOrig = BigDecimal.ZERO;
    private BigDecimal minimumCharge;
    
    private Boolean ignoreTax_ForPayableAmount;
    private boolean noCap;
    private boolean noCapOrig;
    private boolean promotionIsTaxable;
    private boolean postChangeServicePromo;

	private long creditPriority;
    private long redeemOrder;
    
    private TaxMethod taxCalculationMethod;
    
    private Set<String> creditIncludeFlagValues;

    private IncompatibilityList incompatiblePromotions;
    
    Map<String, CreditStage> creditMap = new HashMap<String, CreditStage>(); 
    
    private List<MtxPricingMetadataInfo> taxTemplates = new ArrayList<MtxPricingMetadataInfo>();
    private Set<String> creditIncludeAttributeValues = new HashSet<String>();
    private VisibleTemplate visibleTemplate = new VisibleTemplate(); 
    
    public GlobalCreditStage(String grantOfferCi,VisibleTemplate visibleTemplate) {
        this.grantOfferCi = grantOfferCi;
        this.visibleTemplate = visibleTemplate;
        setTaxCalculationMethodFromTaxResponseUnchanged("");
        this.creditIncludeFlagValues = new HashSet<String>();
    	setNoCap(true); 
    	setPromotionIsTaxable(false);
    	setPostChangeServicePromo(false);
    	setMinimumCharge(null);
        setApplicableGrantPercentage(null);
        setCreditPriority(-1); 
        setRedeemOrder(-1);
        setIncompatiblePromotions(null);
    }
    
	public String getGrantOfferCi() {
		return grantOfferCi;
	}
    
	public void addOrReplaceCreditStage(CreditStage cs) throws PaymentAdviceException {
		if(cs.getApplicableCiExternalId().split(",").length>1) {
			throw (new PaymentAdviceException(RESULT_CODES.HTTP_INTERNAL_ERROR, "ApplicableCI should not have comma. Create separate CreditStages"));
		}else {
			creditMap.put(cs.getApplicableCiExternalId(), cs);	
		}
	}

	public String getApplicableCiCsv() {
		return applicableCiCsv;
	}

	public void setApplicableCiCsv(String applicableCiCsv) {
		this.applicableCiCsv = applicableCiCsv;
	}
	
	public String getClassCode() {
		return classCode;
	}

	public void setClassCode(String classCode) {
		this.classCode = classCode.trim();
	}
	
	public String getConsumableBalanceName() {
		return consumableBalanceName;
	}

	public void setConsumableBalanceName(String consumableBalanceName) {
		this.consumableBalanceName = consumableBalanceName.trim();
	}

	public String getCreditIncludeFlagName() {
		return creditIncludeFlagName;
	}

	public void setCreditIncludeFlagName(String creditIncludeFlagName) {
		this.creditIncludeFlagName = creditIncludeFlagName.trim();
	}
	
	public String getCreditTaxBaseOfferRequestTemplate() {
		return creditTaxBaseOfferRequestTemplate;
	}

	public void setCreditTaxBaseOfferRequestTemplate(String creditTaxBaseOfferRequestTemplate) {
		this.creditTaxBaseOfferRequestTemplate = creditTaxBaseOfferRequestTemplate.trim();
	}
	
	public String getCreditGrantType() {
		return creditGrantType;
	}

	public void setCreditGrantType(String creditGrantType) {
		this.creditGrantType = creditGrantType.trim();
	}
	
	public String getDiscountCalculationMethod() {
		return discountCalculationMethod;
	}

	public void setDiscountCalculationMethod(String discountCalculationMethod) {
		this.discountCalculationMethod = discountCalculationMethod.trim();
	}
	
	public Map<String, CreditStage> getCreditMap() {
		return creditMap;
	}

	public String getGrantBalanceName() {
		return grantBalanceName;
	}

	public void setGrantBalanceName(String grantBalanceName) {
		this.grantBalanceName = grantBalanceName.trim();
	}

	public String getGrantOfferType() {
		return grantOfferType;
	}

	public void setGrantOfferType(String grantOfferType) {
		this.grantOfferType = grantOfferType.trim();
	}

	public String getPromotionName() {
		return promotionName;
	}

	public void setPromotionName(String promotionName) {
		this.promotionName = promotionName.trim();	
	}

	public String getRedeemGoodType() {
		return redeemGoodType;
	}

	public void setRedeemGoodType(String redeemGoodType) {
		this.redeemGoodType = redeemGoodType.trim();
	}
	
	public String getRedeemOfferCi() {
		return redeemOfferCi;
	}

	public void setRedeemOfferCi(String redeemOfferCi) {
		this.redeemOfferCi = redeemOfferCi.trim();
	}

	public TaxMethod getTaxCalculationMethod() {
		return taxCalculationMethod;
	}

	public void setTaxCalculationMethodFromTaxResponseUnchanged(String TaxResponseUnchanged) {
		
		if("Y".equalsIgnoreCase(TaxResponseUnchanged.trim())) {
			this.taxCalculationMethod = TaxMethod.UNCHANGED;	
		}else {
			this.taxCalculationMethod = TaxMethod.SUBTRACTION;
		}		
	}

	public BigDecimal getApplicableGrantPercentage() {
		return applicableGrantPercentage;
	}

	public void setApplicableGrantPercentage(BigDecimal applicableGrantPercentage) {
		this.applicableGrantPercentage = applicableGrantPercentage;
	}
	
	public BigDecimal getAvailableCredits() {
		return availableCredits;
	}

	public void setAvailableCredits(BigDecimal availableCredits) {
		this.availableCredits = availableCredits;
	}
	
	public BigDecimal getAvailableCreditsConsumable() {
		return availableCreditsConsumable;
	}

	public void setAvailableCreditsConsumable(BigDecimal availableCreditsConsumable) {
		this.availableCreditsConsumable = availableCreditsConsumable;
		setAvailableCredits(availableCreditsConsumable.add(availableCreditsGrant));
	}

	public BigDecimal getAvailableCreditsGrant() {
		return availableCreditsGrant;
	}

	public void setAvailableCreditsGrant(BigDecimal availableCreditsGrant) {
        this.availableCreditsGrant = availableCreditsGrant;
        setAvailableCredits(this.availableCreditsConsumable.add(this.availableCreditsGrant));
    }
	
	public void addPercentageGrantToAvailableCreditsGrant(BigDecimal percentageGrant) {
        this.availableCreditsGrant = availableCreditsGrant.add(percentageGrant);
        setAvailableCredits(this.availableCreditsConsumable.add(this.availableCreditsGrant));
    }

	public void subtractPercentageGrantFromAvailableCreditsGrant(BigDecimal percentageGrant) {
        this.availableCreditsGrant = availableCreditsGrant.subtract(percentageGrant).max(BigDecimal.ZERO);
        setAvailableCredits(this.availableCreditsConsumable.add(this.availableCreditsGrant));
    }

	public void addAocGrantToAvailableCreditsGrant(BigDecimal aocGrant) {
        this.availableCreditsGrant = availableCreditsGrant.add(aocGrant);
        setAvailableCredits(this.availableCreditsConsumable.add(this.availableCreditsGrant));
    }

	public void subtractAocGrantFromAvailableCreditsGrant(BigDecimal aocGrant) {
        this.availableCreditsGrant = availableCreditsGrant.subtract(aocGrant).max(BigDecimal.ZERO);
        setAvailableCredits(this.availableCreditsConsumable.add(this.availableCreditsGrant));
    }
	
	public BigDecimal getFutureCreditsGrant() {
		return futureCreditsGrant;
	}

	public void addFutureGrantToGlobalGrant(BigDecimal futureGrant) {
        this.availableCreditsGrant = this.availableCreditsGrant.add(futureGrant);
        this.futureCreditsGrant = this.futureCreditsGrant.add(futureGrant);
        setAvailableCredits(this.availableCreditsConsumable.add(this.availableCreditsGrant));
    }

	public void subtractFutureGrantFromGlobalGrant(BigDecimal futureGrant) {
        this.availableCreditsGrant = this.availableCreditsGrant.subtract(futureGrant).max(BigDecimal.ZERO);
        this.futureCreditsGrant = this.futureCreditsGrant.subtract(futureGrant).max(BigDecimal.ZERO);
        setAvailableCredits(this.availableCreditsConsumable.add(this.availableCreditsGrant));
    }

	public void setAvailableCreditsGrantFromPercentageGrants() {
		BigDecimal percentageGrants = BigDecimal.ZERO;
		for(CreditStage cs:this.creditMap.values()) {
			percentageGrants = percentageGrants.add(cs.getPercentageGrant());
		}
		setAvailableCredits(this.availableCreditsConsumable.add(this.availableCreditsGrant));
	}
	
	public BigDecimal getCreditCap() {
		return creditCap;
	}

    public void setCreditCap(BigDecimal creditCap) {
        this.creditCap = creditCap;
        if (creditCap.signum() > 0) {
            setNoCap(false);
        }
    }	

	public BigDecimal getMinimumCharge() {
		return minimumCharge;
	}

	public void setMinimumCharge(BigDecimal minimumCharge) {
		this.minimumCharge = minimumCharge;
	}

	public Boolean getIgnoreTax_ForPayableAmount() {
		return ignoreTax_ForPayableAmount;
	}

	public void setIgnoreTax_ForPayableAmount(String ignoreTax_ForPayableAmount) {
		if (ignoreTax_ForPayableAmount.trim().equalsIgnoreCase("true")) {
			this.ignoreTax_ForPayableAmount = true;
		} else if (ignoreTax_ForPayableAmount.trim().equalsIgnoreCase("false")) {
			this.ignoreTax_ForPayableAmount = false;
		} else {
			this.ignoreTax_ForPayableAmount = null;
		}
	}
	
	public boolean isNoCap() {
		return noCap;
	}

	public void setNoCap(boolean noCap) {
		this.noCap = noCap;
	}


	public boolean isNoCapOrig() {
		return noCapOrig;
	}

	public void setNoCapOrig(boolean noCapOrig) {
		this.noCapOrig = noCapOrig;
	}

	public boolean isPromotionIsTaxable() {
		return promotionIsTaxable;
	}

	public void setPromotionIsTaxable(boolean promotionIsTaxable) {
		this.promotionIsTaxable = promotionIsTaxable;
	}
    
    public boolean isPostChangeServicePromo() {
		return postChangeServicePromo;
	}

	public void setPostChangeServicePromo(boolean postChangeServicePromo) {
		this.postChangeServicePromo = postChangeServicePromo;
	}
	
	public long getCreditPriority() {
		return creditPriority;
	}

	public void setCreditPriority(long creditPriority) {
		this.creditPriority = creditPriority;
	}
	
	public long getRedeemOrder() {
		return redeemOrder;
	}

	public void setRedeemOrder(long redeemOrder) {
		this.redeemOrder = redeemOrder;
	}

	public Set<String> getCreditIncludeFlagValues() {
		return creditIncludeFlagValues;
	}

	public void addCreditIncludeFlagValues(String values) {
		String[] splitVal = values.split(",");
		for(int i=0;i<splitVal.length;i++) {
			if(StringUtils.isNotBlank(splitVal[i])) {
				this.creditIncludeFlagValues.add(splitVal[i].trim());			
			}			
		}
	}

	public void clearCreditIncludeFlagValues() {
		this.creditIncludeFlagValues = new HashSet<String>();		
	}

	public IncompatibilityList getIncompatiblePromotions() {
		return incompatiblePromotions;
	}

	public void setIncompatiblePromotions(IncompatibilityList incompatiblePromotions) {
		this.incompatiblePromotions = incompatiblePromotions;
	}

	public Set<String> getApplicableCiSet() {
		return new HashSet<String>(Stream.of(applicableCiCsv.split(","))
			     .map(String::trim)
			     .collect(Collectors.toList()));
	}

	public Map<String, Long> getApplicableCiOrderMap() {
		Map<String, Long> retMap = new HashMap<String, Long>();
		String[] applCiArray = applicableCiCsv.split(",");
		for(int i=0;i<applCiArray.length;i++) {
			retMap.put(applCiArray[i].trim(), (long)i);
		}
		return retMap;
	}

	public List<MtxPricingMetadataInfo> getTaxTemplates() {
		return taxTemplates;
	}

	public void addTaxTemplates(List<MtxPricingMetadataInfo> taxTemplates) {
		taxTemplates.forEach(pmi->{
			if(pmi.getName().toUpperCase().trim().endsWith(CI_METADATA.TAX_INPUT.toUpperCase())) {
				this.taxTemplates.add(pmi);	
			}
		});		
	}

	public void addTaxTemplate(MtxPricingMetadataInfo taxTemplate) {
			this.taxTemplates.add(taxTemplate);	
	}
	
	public void clearTaxTemplates() {
		taxTemplates = new ArrayList<MtxPricingMetadataInfo>();
	}
	

	public Set<String> getCreditIncludeAttributeValues() {
		return creditIncludeAttributeValues;
	}

	public void setCreditIncludeAttributeValues(List<String> creditIncludeAttributeValues) {
		if(creditIncludeAttributeValues!=null) {
			this.creditIncludeAttributeValues.clear();
			for (String attr: creditIncludeAttributeValues) {
				if(StringUtils.isNotBlank(attr)) {
					this.creditIncludeAttributeValues.add(attr.trim());	
				}			
			}			
		}
	}

	public void clearCreditIncludeAttributeValues() {
		this.creditIncludeAttributeValues = new HashSet<String>();		
	}

	public VisibleTemplate getVisibleTemplate() {
		return visibleTemplate;
	}

	public void setVisibleTemplate(VisibleTemplate visibleTemplate) {
		this.visibleTemplate = visibleTemplate;
	}

	public BigDecimal getCreditCapOrig() {
		return creditCapOrig;
	}

	public void setCreditCapOrig(BigDecimal creditCapOrig) {
		this.creditCapOrig = creditCapOrig;
	}
	
    public String toJson() {
    	ObjectMapper mapper = new ObjectMapper();
    	try {
			return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(this);
		} catch (JsonProcessingException e) {
			return null;
		}
    }

    public BigDecimal getGlobalRedeemables() {
		BigDecimal globalRedeemables = BigDecimal.ZERO;
		for(CreditStage cs:this.creditMap.values()) {
			globalRedeemables = globalRedeemables.add(cs.getRedeemableCredits());
		}
		return globalRedeemables;
	}
    
    public BigDecimal getGlobalGrantsReserved() {
		BigDecimal globalReserved = BigDecimal.ZERO;
		for(CreditStage cs:this.creditMap.values()) {
			globalReserved = globalReserved.add(cs.getEstimatedTransferableCredits());
		}
		return globalReserved;
	}

    public BigDecimal getGlobalConsumablesReserved() {
		BigDecimal globalReserved = BigDecimal.ZERO;
		for(CreditStage cs:this.creditMap.values()) {
			globalReserved = globalReserved.add(cs.getRedeemableConsumables());
		}
		return globalReserved;
	}

    public BigDecimal getConsumablesUnavailableToChangeService() {
		return consumablesUnavailableToChangeService;
	}

	public void setConsumablesUnavailableToChangeService(BigDecimal consumablesUnavailableToChangeService) {
		this.consumablesUnavailableToChangeService = consumablesUnavailableToChangeService;
	}
	
    public void removeCreditStageFor(String applicableCi) {
    	if (creditMap.get(applicableCi)!=null) {
    		CreditStage cs = creditMap.get(applicableCi);
    		cs.setAocGrantToZero();
    		cs.setPercentageGrantToZero();
    		cs.setFutureGrantToZero();
    		cs.setEstimatedTransferableCreditsToZero();
    		cs.setRedeemableConsumablesToZero();
    		cs.setRedeemableCreditsToZero();
    		creditMap.remove(applicableCi);
    	}
    	
    }

    public GlobalCreditStage shallowClone() {
    	
    	GlobalCreditStage clone = new GlobalCreditStage(this.grantOfferCi, this.visibleTemplate);
   
    	clone.applicableCiCsv = this.applicableCiCsv;
        if(this.applicableGrantPercentage!=null) {
        	clone.applicableGrantPercentage = this.applicableGrantPercentage.add(BigDecimal.ZERO);	
        }
        
    	clone.availableCredits = this.availableCredits.add(BigDecimal.ZERO);
        clone.availableCreditsConsumable = this.availableCreditsConsumable.add(BigDecimal.ZERO);
        clone.availableCreditsGrant = this.availableCreditsGrant.add(BigDecimal.ZERO);
        clone.futureCreditsGrant = this.futureCreditsGrant.add(BigDecimal.ZERO);
    	clone.classCode = this.classCode;
        clone.consumableBalanceName = this.consumableBalanceName;
        clone.creditPriority = this.creditPriority ;
        
        clone.creditIncludeFlagValues = new HashSet<String>();
        for (String entry:this.creditIncludeFlagValues) {
        	clone.creditIncludeFlagValues.add(entry);
        }

        if(this.creditCap!=null) {
        	clone.creditCap = this.creditCap.add(BigDecimal.ZERO);	
        }
        
        if(this.creditCapOrig!=null) {
        	clone.creditCapOrig = this.creditCapOrig.add(BigDecimal.ZERO);	
        }
        
        if(StringUtils.isNotBlank(this.creditIncludeFlagName)) {
        	clone.creditIncludeFlagName = this.creditIncludeFlagName;	
        }
        
        if(StringUtils.isNotBlank(this.creditTaxBaseOfferRequestTemplate)) {
        	clone.creditTaxBaseOfferRequestTemplate = this.creditTaxBaseOfferRequestTemplate;	
        }
        
        if(StringUtils.isNotBlank(this.creditGrantType)) {
        	clone.creditGrantType = this.creditGrantType;	
        }
            
        clone.discountCalculationMethod = this.discountCalculationMethod;
        if(StringUtils.isNotBlank(this.grantBalanceName)) {
        	clone.grantBalanceName = this.grantBalanceName;	
        }
        
        if(StringUtils.isNotBlank(this.grantOfferType)) {
        	clone.grantOfferType = this.grantOfferType;	
        }

        if(this.ignoreTax_ForPayableAmount!=null) {
        	clone.ignoreTax_ForPayableAmount = this.ignoreTax_ForPayableAmount.booleanValue();	
        }

        if(this.incompatiblePromotions!=null) {
        	clone.incompatiblePromotions = this.incompatiblePromotions;	
        }

        if(this.creditIncludeAttributeValues!=null) {
        	clone.creditIncludeAttributeValues = new HashSet<String>();	
        	for(String ciav:this.creditIncludeAttributeValues) {
        		clone.creditIncludeAttributeValues.add(ciav);
        	}
        }
        
        if(this.minimumCharge!=null) {
        	clone.minimumCharge = this.minimumCharge.add(BigDecimal.ZERO);	
        }

        clone.noCap = this.noCap;
        clone.noCapOrig = this.noCapOrig;
        clone.postChangeServicePromo = this.postChangeServicePromo;
        clone.promotionIsTaxable = this.promotionIsTaxable;
        clone.promotionName = this.promotionName;
        
        if(StringUtils.isNotBlank(this.redeemGoodType)) {
        	clone.redeemGoodType = this.redeemGoodType;	
        }
        
        clone.redeemOfferCi = this.redeemOfferCi;
        clone.redeemOrder = this.redeemOrder;
        
        if(this.taxCalculationMethod!=null) {
        	clone.taxCalculationMethod = this.taxCalculationMethod;	
        }        
                
        clone.taxTemplates = this.taxTemplates;
        clone.visibleTemplate = this.visibleTemplate;
    	return clone;
    }

}