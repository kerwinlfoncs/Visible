package com.matrixx.vag.config;

import static com.matrixx.platform.LogUtils.INFO;
import java.io.File;
import java.util.Map;
import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.configuration2.builder.fluent.Configurations;
import org.apache.commons.configuration2.ex.ConfigurationException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.Constants.AUTOPAY_CONSTANTS;
import com.matrixx.vag.common.Constants.SYSTEM_PROPERTIES;
import com.matrixx.vag.common.coverage.Generated;

/**
 * Singleton class for accessing application configuration properties.
 *
 * @author unico
 */
public class AppPropertyProvider {

    private static PropertiesConfiguration instance;
    private static final Logger m_logger = LoggerFactory.getLogger(AppPropertyProvider.class);

    /**
     * Private constructor to prevent clients from instantiation.
     */
    @Generated
    private AppPropertyProvider(AppPropertyProvider other) {
        // Empty
    }

    /**
     * Returns a reference to the singleton instance, while creating the instance for the first time
     * if necessary.
     *
     * @return
     */
    public static PropertiesConfiguration getInstance() {
        if (instance == null) {
            synchronized (AppPropertyProvider.class) {
                try {
                    INFO(m_logger, "Attempting to load application configuration properties");
                    instance = getApplicationProperties();
                    INFO(m_logger, "Application configuration properties loaded successfully");
                } catch (ConfigurationException e) {
                    throw new RuntimeException(
                            "Failed to load application configuration properties", e);
                }
            }
        }
        return instance;
    }

    /**
     * Reloads the application properties from file.
     *
     * @throws ConfigurationException
     */
    public static void reloadApplicationProperties() throws ConfigurationException {
        INFO(m_logger, "Attempting to reload application configuration properties");
        PropertiesConfiguration newInstance = getApplicationProperties();
        instance = newInstance;
        INFO(m_logger, "Application configuration properties reloaded successfully");
    }

    /**
     * Reloads the application properties from file.
     *
     * @throws ConfigurationException
     */
    public static void reloadApplicationProperties(Map<String, String> props)
            throws ConfigurationException {
        INFO(m_logger, "Attempting to reload application configuration properties");
        PropertiesConfiguration newInstance = getApplicationProperties();
        for (Map.Entry<String, String> entry : props.entrySet()) {
            newInstance.addProperty(entry.getKey(), entry.getValue());
        }
        instance = newInstance;
        INFO(m_logger, "Application configuration properties reloaded successfully");
    }

    /**
     * Reads the application properties from file.
     *
     * @throws ConfigurationException
     */
    private static PropertiesConfiguration getApplicationProperties()
            throws ConfigurationException {

        String propertiesFilename = System.getProperty(
                SYSTEM_PROPERTIES.SYSPROP_NAME_APP_CONFIG_FILE,
                SYSTEM_PROPERTIES.SYSPROP_VALUE_APP_CONFIG_FILE);

        INFO(
                m_logger,
                "Reading application configuration properties from file: " + propertiesFilename);

        // Load the properties
        Configurations configs = new Configurations();
        File propertiesFile = new File(propertiesFilename);
        PropertiesConfiguration propConfigs = configs.properties(propertiesFile);

        // Default values
        if (StringUtils.isBlank(propConfigs.getString(AUTOPAY_CONSTANTS.PROP_DELTA_HOURS))) {
            propConfigs.addProperty(
                    AUTOPAY_CONSTANTS.PROP_DELTA_HOURS, AUTOPAY_CONSTANTS.DELTA_HOURS_DEFAULT);
        }
        if (StringUtils.isBlank(propConfigs.getString(AUTOPAY_CONSTANTS.PROP_RETRY_WAIT_HOURS))) {
            propConfigs.addProperty(
                    AUTOPAY_CONSTANTS.PROP_DELTA_HOURS, AUTOPAY_CONSTANTS.RETRY_WAIT_HOURS_DEFAULT);
        }

        // Validate the properties
        AppPropertyParser.validateProperties(propConfigs);

        return propConfigs;
    }

    /**
     * Get the value of given property
     *
     * @param prefix
     * @return
     */
    public static Object getProperty(String prefix) {
        return getProperty(prefix, null);
    }

    /**
     * Get the property from poperties file. Check if suffix is provided, in which case, append the
     * standard '.' character and get the property.
     *
     * @param prefix
     * @param suffix
     * @return
     */
    public static Object getProperty(String prefix, String suffix) {
        return getInstance().getProperty(CommonUtils.getPropertyName(prefix, suffix));
    }

}
