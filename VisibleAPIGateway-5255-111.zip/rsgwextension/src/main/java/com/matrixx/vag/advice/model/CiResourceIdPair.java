package com.matrixx.vag.advice.model;

public class CiResourceIdPair {
    private String catalogItemExternalId;
    private Long resourceId;
    private static final String KEY_FLD_SEPARATOR = "#";

    public CiResourceIdPair(String catalogItemExternalId) {
    	this.catalogItemExternalId = catalogItemExternalId;
    }

    public CiResourceIdPair(String catalogItemExternalId, Long resourceId) {
    	this(catalogItemExternalId);
    	if(resourceId!=null) {
    		this.resourceId = resourceId;	
    	}    	
    }

    public String getCatalogItemExternalId() {
        return catalogItemExternalId;
    }

    public Long getResourceId() {
        return resourceId;
    }

    @Override
    public String toString() {
        return catalogItemExternalId + KEY_FLD_SEPARATOR + resourceId;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((catalogItemExternalId == null) ? 0 : catalogItemExternalId.hashCode());
        result = prime * result + ((resourceId == null) ? 0 : resourceId.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        CiResourceIdPair other = (CiResourceIdPair) obj;
        if (catalogItemExternalId == null) {
            if (other.catalogItemExternalId != null) {
                return false;
            }
        } else if (!catalogItemExternalId.equals(other.catalogItemExternalId)) {
            return false;
        }
        if (resourceId == null) {
            if (other.resourceId != null) {
                return false;
            }
        } else if (!resourceId.equals(other.resourceId)) {
            return false;
        }
        return true;
    }
}
