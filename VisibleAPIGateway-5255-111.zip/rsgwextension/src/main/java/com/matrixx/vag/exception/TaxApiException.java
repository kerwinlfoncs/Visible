package com.matrixx.vag.exception;

/**
 * Exception thrown upon encountering an error with processing subscriber offers.
 *
 * @author unico
 */
public class TaxApiException extends VisibleServiceException {

    private static final long serialVersionUID = -3411643550107423892L;

    public TaxApiException(Long resultCode, String message) {
        super(resultCode, message);
    }
}
