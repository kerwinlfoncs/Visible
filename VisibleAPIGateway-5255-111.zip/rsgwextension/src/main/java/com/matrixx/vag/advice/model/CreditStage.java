package com.matrixx.vag.advice.model;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CreditStage {

    private final String applicableCiExternalId;
    private final long applicableCiRedeemOrder;

	@JsonIgnore
    private final GlobalCreditStage globalCreditStage;
            
    private String creditTaxDetails;
    private String creditTaxApiErrorMessage;
    private String freezeGrantReason;    
	private BigDecimal percentageGrant = BigDecimal.ZERO;
	private BigDecimal aocGrant=BigDecimal.ZERO;
	private BigDecimal futureGrant=BigDecimal.ZERO;
	private BigDecimal redeemableCredits;
    private BigDecimal estimatedTransferableCredits;
    private BigDecimal redeemableConsumables;
    
    private boolean keepTransferableZero;
    
    @JsonIgnore
    private ServiceStage applicableServiceStage;
    
    public CreditStage(GlobalCreditStage globalCreditStage, String applicableCiExternalId) {
    	this.globalCreditStage = globalCreditStage; 
    	this.applicableCiExternalId = applicableCiExternalId.trim();        
        setEstimatedTransferableCreditsToZero();
        setRedeemableCreditsToZero();        
        setKeepTransferableZero(false);
    	setRedeemableConsumablesToZero();
        setApplicableServiceStage(null);
        applicableCiRedeemOrder = globalCreditStage.getApplicableCiOrderMap().get(applicableCiExternalId.trim());
    }
    
    public BigDecimal getEstimatedTransferableCredits() {
    	return estimatedTransferableCredits;
    }

    public void setEstimatedTransferableCredits(BigDecimal estimatedTransferableCredits) {
        this.estimatedTransferableCredits = estimatedTransferableCredits;
    }

    public void setEstimatedTransferableCreditsToZero() {
        this.estimatedTransferableCredits = BigDecimal.ZERO;
    }

    public BigDecimal getRedeemableCredits() {
        return redeemableCredits;
    }

	public void setRedeemableCredits(BigDecimal redeemableCredits) {
		this.redeemableCredits = redeemableCredits;
	}

	public void setRedeemableCreditsToZero() {
        this.redeemableCredits = BigDecimal.ZERO;
    }

    @JsonIgnore
    public String getCreditTaxDetails() {
        return creditTaxDetails;
    }

    public void setCreditTaxDetails(String creditTaxDetails) {
        this.creditTaxDetails = creditTaxDetails;
    }

    public String getCreditTaxApiErrorMessage() {
        return creditTaxApiErrorMessage;
    }

    public void setCreditTaxApiErrorMessage(String creditTaxApiErrorMessage) {
        this.creditTaxApiErrorMessage = creditTaxApiErrorMessage;
    }

    @JsonIgnore
	public String getTaxResponseAsPromo() {
		if(this.applicableServiceStage!=null && StringUtils.isNotBlank(this.applicableServiceStage.getTaxResponse())) {
			return this.applicableServiceStage.getTaxResponse();
		}else {
			return "";	
		}		
	}

	public ServiceStage getApplicableServiceStage() {
		return applicableServiceStage;
	}

	public void setApplicableServiceStage(ServiceStage applicablePaynowStage) {
		this.applicableServiceStage = applicablePaynowStage;
	}

	public GlobalCreditStage getGlobalCreditStage() {
		return globalCreditStage;
	}

	public BigDecimal getPercentageGrant() {
		return percentageGrant;
	}

	public void setPercentageGrant(BigDecimal percentageGrant) {
		this.percentageGrant = percentageGrant;
		this.globalCreditStage.addPercentageGrantToAvailableCreditsGrant(percentageGrant);
	}
	
	public void setPercentageGrantToZero() {
		this.globalCreditStage.subtractPercentageGrantFromAvailableCreditsGrant(this.percentageGrant);
		this.percentageGrant = BigDecimal.ZERO;
	}

	public BigDecimal getAocGrant() {
		return aocGrant;
	}

	public void setAocGrant(BigDecimal aocGrant) {
		this.aocGrant = aocGrant;
		this.globalCreditStage.addAocGrantToAvailableCreditsGrant(aocGrant);
	}
	
	public void setAocGrantToZero() {
		this.globalCreditStage.subtractPercentageGrantFromAvailableCreditsGrant(this.aocGrant);
		this.aocGrant = BigDecimal.ZERO;
	}
	
	public BigDecimal getRedeemableConsumables() {
		return redeemableConsumables;
	}

	public void setRedeemableConsumables(BigDecimal redeemableConsumables) {
		this.redeemableConsumables = redeemableConsumables;
	}

	public void setRedeemableConsumablesToZero() {
		this.redeemableConsumables = BigDecimal.ZERO;
	}

	public BigDecimal getFutureGrant() {
		return futureGrant;
	}

	public void addToFutureGrant(BigDecimal futureGrant) {
		this.futureGrant = futureGrant;
		this.globalCreditStage.addFutureGrantToGlobalGrant(this.futureGrant);
	}

	public void setFutureGrantToZero() {
		this.globalCreditStage.subtractFutureGrantFromGlobalGrant(this.futureGrant);
		this.futureGrant = BigDecimal.ZERO;
	}

	public String getApplicableCiExternalId() {
		return applicableCiExternalId;
	}

	public boolean isKeepTransferableZero() {
		return keepTransferableZero;
	}

	public void setKeepTransferableZero(boolean keepTransferableZero) {
		this.keepTransferableZero = keepTransferableZero;
	}

	public String getFreezeGrantReason() {
		return freezeGrantReason;
	}	
	
    public BigDecimal getAvailableCredits() {
        return globalCreditStage.getAvailableCredits();
    }

    public BigDecimal getAvailableCreditsGrant() {
        return globalCreditStage.getAvailableCreditsGrant();
    }
    
    public BigDecimal getAvailableCreditsConsumable() {
        return globalCreditStage.getAvailableCreditsConsumable();
    }

    public BigDecimal getCreditCap() {
        return globalCreditStage.getCreditCap();
    }

    @JsonIgnore
    public Boolean getIgnoreTax_ForPayableAmount() { 
    	return globalCreditStage.getIgnoreTax_ForPayableAmount(); 
    }

    @JsonIgnore
    public long getCreditRedeemOrder() {
        return globalCreditStage.getRedeemOrder();
    }
    
    public boolean isNoCap() {
        return globalCreditStage.isNoCap();
    }
	
	@JsonIgnore
	public long getCreditPriority() {
		return globalCreditStage.getCreditPriority();
	}
	
	@JsonIgnore
	public String getRedeemOfferCi() {
		return globalCreditStage.getRedeemOfferCi();
	}
	
	@JsonIgnore
	public String getDiscountCalculationMethod() {
		return globalCreditStage.getDiscountCalculationMethod();
	}
	
	@JsonIgnore
	public String getGrantOfferType() {
		return globalCreditStage.getGrantOfferType();
	}
	
	@JsonIgnore
	public String getGrantBalanceName() {
		return globalCreditStage.getGrantBalanceName();
	}

	@JsonIgnore
	public String getConsumableBalanceName() {
		return globalCreditStage.getConsumableBalanceName();
	}

	public String getClassCode() {
		return globalCreditStage.getClassCode();
	}
	
	@JsonIgnore
	public String getCreditGrantType() {
		return globalCreditStage.getCreditGrantType();
	}
	
	@JsonIgnore
	public String getPromotionName() {
		return globalCreditStage.getPromotionName();
	}

	@JsonIgnore
	public String getCreditTaxBaseOfferRequestTemplate() {
		return globalCreditStage.getCreditTaxBaseOfferRequestTemplate();
	}

	@JsonIgnore
	public boolean isPromotionTaxable() {
		return globalCreditStage.isPromotionIsTaxable();
	}
	
	@JsonIgnore
	public BigDecimal getMinimumCharge() {
		return globalCreditStage.getMinimumCharge();
	}

	@JsonIgnore
	public String getRedeemGoodType() {
		return globalCreditStage.getRedeemGoodType();
	}

	@JsonIgnore
	public String getCreditIncludeFlagName() {
		return globalCreditStage.getCreditIncludeFlagName();
	}

	@JsonIgnore
	public Set<String> getCreditIncludeFlagValues() {
		return globalCreditStage.getCreditIncludeFlagValues();
	}

	@JsonIgnore
    public String getGrantOfferCi() {
		return getGlobalCreditStage().getGrantOfferCi();
	}
   
    @JsonIgnore
	public BigDecimal getApplicableGrantPercentage() {
		return globalCreditStage.getApplicableGrantPercentage();
	}

	@JsonIgnore
	public IncompatibilityList getIncompatiblePromotions() {
		return globalCreditStage.getIncompatiblePromotions();
	}
	
	@JsonIgnore
    public BigDecimal getGlobalRedeemables() {
		return globalCreditStage.getGlobalRedeemables();
	}
	
    @JsonIgnore
    public long getApplicableCiRedeemOrder() {
		return applicableCiRedeemOrder;
	}
        
    @JsonIgnore
	public BigDecimal getGrantsReservedForOtherCi() {
		return globalCreditStage.getGlobalGrantsReserved().subtract(estimatedTransferableCredits);
	}
    
    @JsonIgnore
    public long getCiPromoRedeemOrder() {
        return globalCreditStage.getRedeemOrder()*100+this.applicableCiRedeemOrder;
    }

	public void updateGrantsAsNonTransferable() {
		this.setKeepTransferableZero(true);
		this.setEstimatedTransferableCreditsToZero();
	}
	
	public void updateGrantsAsNonTransferable(String freezeGrantReason) {
		updateGrantsAsNonTransferable();
		this.freezeGrantReason = freezeGrantReason;
	}
	
	@JsonIgnore
	public PromoOfferPair getPromoOfferPair () {
		return new PromoOfferPair(this.getApplicableCiExternalId(), this.getGrantOfferCi());
	}
    
    public String toShortJson() {
    	ObjectMapper mapper = new ObjectMapper();
    	try {
    		Map<String, Object> shortMap = new HashMap<String, Object>(); 
    		shortMap.put("availableCredits", getAvailableCredits());
    		shortMap.put("availableCreditsGrant", getAvailableCreditsGrant());
    		shortMap.put("availableCreditsConsumable", getAvailableCreditsConsumable());
    		shortMap.put("estimatedTransferableCredits", estimatedTransferableCredits);
    		shortMap.put("redeemableCredits", redeemableCredits);
    		shortMap.put("promotionLimit", getCreditCap());
    		shortMap.put("classCode", getClassCode());
    		shortMap.put("grantToBeAdded", getFutureGrant());
			return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(shortMap);
		} catch (JsonProcessingException e) {
			return null;
		}
    }
    
    public String toJson() {
    	ObjectMapper mapper = new ObjectMapper();
    	try {
			return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(this);
		} catch (JsonProcessingException e) {
			return null;
		}
    }

	public CreditStage shallowClone(GlobalCreditStage gcs) {

		CreditStage clone = new CreditStage(gcs, this.applicableCiExternalId);

		clone.creditTaxDetails = this.creditTaxDetails;
		clone.creditTaxApiErrorMessage = this.creditTaxApiErrorMessage;
		clone.percentageGrant = this.percentageGrant;
		clone.aocGrant = this.aocGrant;
		clone.redeemableCredits = this.redeemableCredits.add(BigDecimal.ZERO);
		clone.estimatedTransferableCredits = this.estimatedTransferableCredits.add(BigDecimal.ZERO);
		clone.redeemableConsumables = this.redeemableConsumables.add(BigDecimal.ZERO);
		clone.keepTransferableZero = this.keepTransferableZero;
		clone.freezeGrantReason = this.freezeGrantReason;
		clone.futureGrant = this.futureGrant;
		return clone;
	}  
}