package com.matrixx.vag.advice.model;

import java.util.HashMap;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.matrixx.datacontainer.mdc.MtxResponseGroup;
import com.matrixx.datacontainer.mdc.VisibleCAGroupExtension;
import com.matrixx.vag.common.Constants.GROUP_CONSTANTS;

public class SubscriberGroup {

    private String groupExternalId;
    private String groupName;
    private String groupTier;
    private Long subscriberMemberCount;
    private HashMap <String, String> payRelationMap = new HashMap <String, String>();

    public SubscriberGroup(MtxResponseGroup mtxGroup) {
        this.groupExternalId = mtxGroup.getExternalId();
        this.groupName = mtxGroup.getName();
        this.groupTier = mtxGroup.getTier();
        this.subscriberMemberCount = mtxGroup.getSubscriberMemberCount();
        if(mtxGroup.getAttr()!=null
                && mtxGroup.getAttr() instanceof VisibleCAGroupExtension) {
            VisibleCAGroupExtension vge =(VisibleCAGroupExtension)mtxGroup.getAttr();
            vge.getRelationshipArray().forEach(rel->{
                if(StringUtils.isNotBlank(rel)
                        && rel.toUpperCase().contains(GROUP_CONSTANTS.CA_RELATION_SEPARATOR)) {
                    String benId="";
                    String payId="";
                    for(String fld: rel.split(GROUP_CONSTANTS.CA_RELATION_SEPARATOR)) {
                        if(fld.startsWith(GROUP_CONSTANTS.CA_BENEFICIARY_FLD_NAME)
                                && fld.contains(GROUP_CONSTANTS.CA_FIELD_SEPARATOR)) {                            
                            benId = fld.split(":")[1].trim();
                        }else if(fld.startsWith(GROUP_CONSTANTS.CA_PAYER_FLD_NAME)
                                && fld.contains(GROUP_CONSTANTS.CA_FIELD_SEPARATOR)) {                            
                            payId = fld.split(":")[1].trim();
                        }

                    }

                    //String subs[]=rel.toUpperCase().split(GROUP_CONSTANTS.CA_RELATION_SEPARATOR);
                    payRelationMap.put(benId,payId);
                }
            });            
        }
    }

    public String getGroupExternalId() {
        return groupExternalId;
    }

    public void setGroupExternalId(String groupExternalId) {
        this.groupExternalId = groupExternalId;
    }

    public Long getSubscriberMemberCount() {
        return subscriberMemberCount;
    }

    public void setSubscriberMemberCount(Long subscriberMemberCount) {
        this.subscriberMemberCount = subscriberMemberCount;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getGroupTier() {
        return groupTier;
    }

    public void setGroupTier(String groupTier) {
        this.groupTier = groupTier;
    }

    public String getPayerForBeneficiary(String beneficiaryExtId) {
        return payRelationMap.get(beneficiaryExtId);
    }

    public String toJson() {
        ObjectMapper mapper = new ObjectMapper();
        try {
            return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(this);
        } catch (JsonProcessingException e) {
            return null;
        }
    }

}
