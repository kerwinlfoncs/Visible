package com.matrixx.vag.advice.service;

import static com.matrixx.platform.LogUtils.DEBUG;
import static com.matrixx.platform.LogUtils.INFO;
import static com.matrixx.platform.LogUtils.WARN;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.matrixx.datacontainer.MtxTimestamp;
import com.matrixx.datacontainer.mdc.MtxBalanceImpactInfo;
import com.matrixx.datacontainer.mdc.MtxBalanceImpactInfoGroup;
import com.matrixx.datacontainer.mdc.MtxPurchasedOfferInfo;
import com.matrixx.datacontainer.mdc.MtxResponsePricingCatalogItem;
import com.matrixx.datacontainer.mdc.MtxResponseRecurringChargeInfo;
import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import com.matrixx.datacontainer.mdc.PurchasedOfferInfo;
import com.matrixx.datacontainer.mdc.SubscriptionResponse;
import com.matrixx.datacontainer.mdc.VisibleCatalogItem;
import com.matrixx.datacontainer.mdc.VisibleChangeServiceAddItem;
import com.matrixx.datacontainer.mdc.VisibleChangeServiceCancelItem;
import com.matrixx.datacontainer.mdc.VisibleDeltaPromo;
import com.matrixx.datacontainer.mdc.VisibleFuturePromo;
import com.matrixx.datacontainer.mdc.VisibleRequestChangeServiceAdvice;
import com.matrixx.datacontainer.mdc.VisibleRequestPaymentAdviceService;
import com.matrixx.datacontainer.mdc.VisibleRequestQuoteAdviceService;
import com.matrixx.datacontainer.mdc.VisibleTemplate;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.Constants.BALANCE_CONSTANTS;
import com.matrixx.vag.common.Constants.CHANGE_SERVICE_CONSTANTS;
import com.matrixx.vag.common.Constants.CREDIT_CONSTANTS;
import com.matrixx.vag.common.Constants.EXCEPTION_MESSAGES;
import com.matrixx.vag.common.Constants.GENERIC_CONSTANTS;
import com.matrixx.vag.common.Constants.LOG_MESSAGES;
import com.matrixx.vag.common.Constants.OFFER_CONSTANTS;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.common.Constants.SUBSCRIPTION_CONSTANTS;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.exception.InvalidRequestException;

public class RequestValidator {

    private static final String REQUEST_TYPE_DETAIL = "detail";
    private static final String REQUEST_TYPE_SUMMARY = "summary";
    private static final Logger m_logger = LoggerFactory.getLogger(RequestValidator.class);

    void validateRequest(String loggingKey, VisibleRequestPaymentAdviceService request)
            throws InvalidRequestException {
        DEBUG(m_logger, loggingKey + "Validating payment advice service request");
        String missingMandatoryParamName = null;
        if (StringUtils.isEmpty(request.getSubscriberExternalId())) {
            missingMandatoryParamName = "SubscriberExternalId";
        }
        if (missingMandatoryParamName != null) {
            throw new InvalidRequestException(
                    "Missing mandatory parameter: " + missingMandatoryParamName);
        }
        if (StringUtils.isNotEmpty(request.getRequestType())) {
            if (!(request.getRequestType().equalsIgnoreCase(REQUEST_TYPE_DETAIL)
                    | request.getRequestType().equalsIgnoreCase(REQUEST_TYPE_SUMMARY))) {
                throw new InvalidRequestException(
                        "Permitted values for RequestType parameter are: " + REQUEST_TYPE_DETAIL
                                + " ," + REQUEST_TYPE_SUMMARY);
            }
            missingMandatoryParamName = "SubscriberExternalId";
        }
    }

    void validateRequest(String loggingKey,
                         VisibleRequestPaymentAdviceService request,
                         SubscriptionResponse subscriptionResponse)
            throws InvalidRequestException {
        if (SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_TERMINATED.equalsIgnoreCase(
                subscriptionResponse.getStatusDescription())) {
            INFO(
                    m_logger,
                    loggingKey + StringUtils.SPACE + LOG_MESSAGES.SUBSCRIPTION_IS_TERMINATED);
            throw new InvalidRequestException(
                    RESULT_CODES.HTTP_INTERNAL_ERROR,
                    LOG_MESSAGES.SUBSCRIPTION_IS_TERMINATED);
        } else if (SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_LAPSE.equalsIgnoreCase(
                subscriptionResponse.getStatusDescription())) {
            INFO(m_logger, loggingKey + StringUtils.SPACE + LOG_MESSAGES.SUBSCRIPTION_IS_LAPSED);
            throw new InvalidRequestException(
                    RESULT_CODES.HTTP_INTERNAL_ERROR,
                    LOG_MESSAGES.SUBSCRIPTION_IS_LAPSED);
        } else if (subscriptionResponse.getPurchasedOfferArray() == null
                || subscriptionResponse.getPurchasedOfferArray().isEmpty()) {
            INFO(
                    m_logger,
                    loggingKey + StringUtils.SPACE + LOG_MESSAGES.SUBSCRIPTION_HAS_NO_SERVICES);
            throw new InvalidRequestException(
                    RESULT_CODES.HTTP_INTERNAL_ERROR,
                    LOG_MESSAGES.SUBSCRIPTION_HAS_NO_SERVICES);
        }
    }

    void validateRequest(String loggingKey,
                         VisibleRequestPaymentAdviceService request,
                         SubscriptionResponse subscriptionResponse,
                         MtxResponseRecurringChargeInfo estimate,
                         boolean hasServiceStages)
            throws InvalidRequestException {
        boolean foundService = false;
        boolean foundWithNoImpact = false;
        List<String> svctypes = Stream.of(
                OFFER_CONSTANTS.OFFER_TYPE_BASE, OFFER_CONSTANTS.OFFER_TYPE_ADDON,
                OFFER_CONSTANTS.OFFER_TYPE_INSURANCE).collect(Collectors.toList());
        if (estimate.getBalanceImpactGroupList() == null
                || estimate.getBalanceImpactGroupList().isEmpty()) {
            WARN(m_logger, loggingKey + " : " + LOG_MESSAGES.SUBSCRIPTION_HAS_NO_ACTIVE_SERVICES);
            for (MtxPurchasedOfferInfo mpo : subscriptionResponse.getPurchasedOfferArray()) {
                PurchasedOfferInfo po = (PurchasedOfferInfo) mpo;
                if (po.getCatalogItemDetails() != null
                        && po.getCatalogItemDetails().getTemplateAttr() != null
                        && po.getCatalogItemDetails().getTemplateAttr() instanceof VisibleTemplate) {
                    VisibleTemplate vt = (VisibleTemplate) po.getCatalogItemDetails().getTemplateAttr();
                    if (svctypes.contains(vt.getOfferType().trim())) {
                        if (subscriptionResponse.getBillingCycle() != null
                                && subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime() != null
                                && CommonUtils.isOfferPreActive(
                                        loggingKey, m_logger, mpo,
                                        subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime())) {
                            foundService = true;
                            break;
                        }
                    }
                }
            }
        } else {
            for (MtxBalanceImpactInfoGroup big : estimate.getBalanceImpactGroupList()) {
                for (MtxBalanceImpactInfo bii : big.getBalanceImpactList()) {
                    if (BALANCE_CONSTANTS.BALANCE_CLASS_ID_USD == bii.getBalanceClassId()) {
                        if (bii.getImpactAmount().signum() > 0) {
                            foundService = true;
                            foundWithNoImpact = false;
                            break;
                        } else {
                            foundWithNoImpact = true;
                        }
                    }
                }
            }
        }

        if (foundWithNoImpact && !hasServiceStages) {
            INFO(
                    m_logger, loggingKey + StringUtils.SPACE
                            + LOG_MESSAGES.SUBSCRIPTION_HAS_NO_PAYABLE_SERVICES);
            throw new InvalidRequestException(
                    RESULT_CODES.HTTP_INTERNAL_ERROR,
                    LOG_MESSAGES.SUBSCRIPTION_HAS_NO_PAYABLE_SERVICES);
        } else if (!foundService && !hasServiceStages) {
            INFO(
                    m_logger,
                    loggingKey + StringUtils.SPACE + LOG_MESSAGES.SUBSCRIPTION_HAS_NO_SERVICES);
            throw new InvalidRequestException(
                    RESULT_CODES.HTTP_INTERNAL_ERROR,
                    LOG_MESSAGES.SUBSCRIPTION_HAS_NO_SERVICES);
        }
    }

    void validateRequest(String loggingKey, VisibleRequestQuoteAdviceService request)
            throws InvalidRequestException {
        DEBUG(m_logger, loggingKey + "Validating Quote Advice service request");
        Set<String> missingParameters = new HashSet<String>();

        if (StringUtils.isEmpty(request.getSubscriberExternalId())) {
            missingParameters.add("SubscriberExternalId");
        }
        if (request.getBillingCycleId() == null) {
            missingParameters.add("BillingCycleId");
        }
        if (request.getCatalogItemList() != null) {
            if (request.getCatalogItemList().isEmpty()) {
                missingParameters.add("CatalogItemList");
            } else {
                new HashSet<String>();
                for (VisibleCatalogItem ci : request.getCatalogItemList()) {
                    if (ci.getDiscountPrice() == null) {
                        missingParameters.add("CatalogItemList.DiscountPrice");
                        break;
                    }
                }

                Set<String> ciSet = request.getCatalogItemList().stream().map(
                        vci -> vci.getCatalogItemExternalId()).collect(Collectors.toSet());
                if (request.getCatalogItemList().size() > ciSet.size()) {
                    throw new InvalidRequestException(
                            RESULT_CODES.HTTP_BAD_REQUEST, "Duplicate catalog items in request ");
                }
            }
        } else {
            missingParameters.add("CatalogItemList");
        }

        if (missingParameters.size() > 0) {
            DEBUG(
                    m_logger, loggingKey + "Missing mandatory parameter: "
                            + Arrays.toString(missingParameters.toArray()));
            throw new InvalidRequestException(
                    "Missing mandatory parameter: " + Arrays.toString(missingParameters.toArray()));
        }

        if (request.getAdditionalPromoList() != null
                && !request.getAdditionalPromoList().isEmpty()) {
            for (VisibleFuturePromo fp : request.getAdditionalPromoList()) {
                if (StringUtils.isBlank(fp.getGrantOfferCI())) {
                    throw new InvalidRequestException(
                            LOG_MESSAGES.FUTURE_GRANT_NO_CI_1003);
                }
            }
        }

        if (StringUtils.isNotEmpty(request.getIncludeTaxDetails())) {
            if (StringUtils.isEmpty(request.getTaxGeoCode())) {
                DEBUG(
                        m_logger, loggingKey
                                + "TaxGeoCode not present in input. Subscriber's current GLCenter will be used.");
            }
        }
    }

    void validateRequestQuotePromoOfferTemplateAttributes(String loggingKey,
                                                          VisibleRequestQuoteAdviceService request,
                                                          MtxResponsePricingCatalogItem pricingCI)
            throws InvalidRequestException {
        if (pricingCI == null) {
            String resultText = "Invalid Catalog Item.";
            DEBUG(m_logger, loggingKey + resultText);
            throw new InvalidRequestException(resultText);
        } else if (RESULT_CODES.MTX_SUCCESS != pricingCI.getResult()) {
            String resultText = "Invalid Catalog Item." + StringUtils.SPACE
                    + pricingCI.getResultText();
            DEBUG(m_logger, loggingKey + resultText);
            throw new InvalidRequestException(resultText);
        } else if (pricingCI.getCatalogItemInfo() == null) {
            String resultText = "Invalid Catalog Item.";
            DEBUG(m_logger, loggingKey + resultText);
            throw new InvalidRequestException(resultText);
        } else if (pricingCI.getCatalogItemInfo().getTemplateAttr() == null
                || !(pricingCI.getCatalogItemInfo().getTemplateAttr() instanceof VisibleTemplate)) {
            String resultText = "Invalid Catalog Item. Catalog Item does not have visible template attributes.";
            DEBUG(m_logger, loggingKey + resultText);
            throw new InvalidRequestException(resultText);
        }

        VisibleTemplate attr = (VisibleTemplate) pricingCI.getCatalogItemInfo().getTemplateAttr();
        String newCiType = attr.getOfferType();
        if (!OFFER_CONSTANTS.OFFER_TYPE_PROMO.equalsIgnoreCase(newCiType)) {
            String resultText = LOG_MESSAGES.GRANT_CI_NOT_PROMO_1004
                    + pricingCI.getCatalogItemInfo().getExternalId();
            DEBUG(m_logger, loggingKey + resultText);
            throw new InvalidRequestException(resultText);
        }
        if (CREDIT_CONSTANTS.CALCULATION_METHOD_AOC.equalsIgnoreCase(
                attr.getDiscountCalculationMethod())) {
            String resultText = LOG_MESSAGES.FUTURE_PROMO_NO_AOC_1005
                    + pricingCI.getCatalogItemInfo().getExternalId();
            DEBUG(m_logger, loggingKey + resultText);
            throw new InvalidRequestException(resultText);
        }
        if (!CREDIT_CONSTANTS.GRANT_TYPE_DOLLAR.equalsIgnoreCase(attr.getCreditGrantType())) {
            String resultText = LOG_MESSAGES.FUTURE_GRANT_TYPE_DOLLAR_1006
                    + pricingCI.getCatalogItemInfo().getExternalId();
            DEBUG(m_logger, loggingKey + resultText);
            throw new InvalidRequestException(resultText);
        }

    }

    void validateRequest(String loggingKey, VisibleRequestChangeServiceAdvice request)
            throws InvalidRequestException {
        DEBUG(
                m_logger, loggingKey + "Validating "
                        + VisibleRequestChangeServiceAdvice.class.getSimpleName());
        Set<String> missingParameters = new HashSet<String>();
        if (StringUtils.isBlank(request.getSubscriptionExternalId())) {
            missingParameters.add("SubscriptionExternalId");
        }

        if (request.getDiscountPrice() == null) {
            missingParameters.add("DiscountPrice");
        }

        if (StringUtils.isBlank(request.getNewCatalogItemExternalId())) {
            missingParameters.add("NewCatalogItemExternalId");
        }

        if (missingParameters.size() > 0) {
            throw new InvalidRequestException(
                    "Missing mandatory parameter: " + Arrays.toString(missingParameters.toArray()));
        }

        if (request.getDiscountPrice().signum() < 0) {
            throw new InvalidRequestException("DiscountPrice should be positive value.");
        }

        if (request.getGrossPrice() != null
                && request.getDiscountPrice().compareTo(request.getGrossPrice()) > 0) {
            throw new InvalidRequestException("DiscountPrice should be less than Gross Price.");
        }

        String disallowedTargetOffers = AppPropertyProvider.getInstance().getString(
                CHANGE_SERVICE_CONSTANTS.CI_DISALLOWED_AS_TARGET_LIST);

        if (request.getNewCatalogItemExternalId() != null
                && disallowedTargetOffers.toUpperCase().contains(
                        request.getNewCatalogItemExternalId().toUpperCase())) {
            // Once new CreateConfig and Pricing are available change this condition.
            throw new InvalidRequestException(
                    EXCEPTION_MESSAGES.CAN_NOT_ENROLL_WITH_CHANGE_SERVICE);
        }

        if (request.getDeltaPromotionList() != null && !request.getDeltaPromotionList().isEmpty()) {
            for (VisibleDeltaPromo dp : request.getDeltaPromotionList()) {
                if (StringUtils.isBlank(dp.getClassCode())) {
                    throw new InvalidRequestException(EXCEPTION_MESSAGES.DELTA_PROMO_NO_CLASS_CODE);
                }

                if (dp.getDeltaPromotionLimit() == null) {
                    throw new InvalidRequestException(EXCEPTION_MESSAGES.DELTA_PROMO_NO_LIMIT);
                }
            }
        }

        if (request.getAddItems() != null && !request.getAddItems().isEmpty()
                && !GENERIC_CONSTANTS.YES.equalsIgnoreCase(request.getIncludePaymentAdvice())) {
            throw new InvalidRequestException(EXCEPTION_MESSAGES.ADDON_WITH_AOP_ONLY);
        }

        if (request.getAddItems() != null && !request.getAddItems().isEmpty()) {
            for (VisibleChangeServiceAddItem aItem : request.getAddItems()) {
                if (StringUtils.isBlank(aItem.getCatalogItemExternalId())) {
                    throw new InvalidRequestException(
                            EXCEPTION_MESSAGES.MANDATORY_ADDON_EXTERNAL_ID);
                }
                if (aItem.getDiscountPrice() == null) {
                    throw new InvalidRequestException(
                            EXCEPTION_MESSAGES.MANDATORY_ADDON_DISCOUNT_PRICE);
                }
            }
        }

        if (request.getCancelItems() != null && !request.getCancelItems().isEmpty()
                && !GENERIC_CONSTANTS.YES.equalsIgnoreCase(request.getIncludePaymentAdvice())) {
            throw new InvalidRequestException(EXCEPTION_MESSAGES.ADDON_CANCEL_WITH_AOP_ONLY);
        }

        if (request.getCancelItems() != null && !request.getCancelItems().isEmpty()) {
            for (VisibleChangeServiceCancelItem cItem : request.getCancelItems()) {
                if (StringUtils.isBlank(cItem.getCatalogItemExternalId())) {
                    throw new InvalidRequestException(
                            EXCEPTION_MESSAGES.MANDATORY_ADDON_EXTERNAL_ID);
                }
            }
        }
    }

    void validateRequestBaseOfferTemplateAttributes(String loggingKey,
                                                    VisibleRequestChangeServiceAdvice request,
                                                    MtxResponsePricingCatalogItem pricingNewCI)
            throws InvalidRequestException {
        if (pricingNewCI == null) {
            String resultText = "Invalid Catalog Item.";
            DEBUG(m_logger, loggingKey + resultText);
            throw new InvalidRequestException(resultText);
        } else if (RESULT_CODES.MTX_SUCCESS != pricingNewCI.getResult()) {
            String resultText = "Invalid Catalog Item." + StringUtils.SPACE
                    + pricingNewCI.getResultText();
            DEBUG(m_logger, loggingKey + resultText);
            throw new InvalidRequestException(resultText);
        } else if (pricingNewCI.getCatalogItemInfo() == null) {
            String resultText = "Invalid Catalog Item.";
            DEBUG(m_logger, loggingKey + resultText);
            throw new InvalidRequestException(resultText);
        } else if (pricingNewCI.getCatalogItemInfo().getTemplateAttr() == null
                || !(pricingNewCI.getCatalogItemInfo().getTemplateAttr() instanceof VisibleTemplate)) {
            String resultText = "Invalid Catalog Item. Catalog Item does not have visible template attributes.";
            DEBUG(m_logger, loggingKey + resultText);
            throw new InvalidRequestException(resultText);
        }

        VisibleTemplate attr = (VisibleTemplate) pricingNewCI.getCatalogItemInfo().getTemplateAttr();
        String newCiType = attr.getOfferType();
        if (!OFFER_CONSTANTS.OFFER_TYPE_BASE.equalsIgnoreCase(newCiType)) {
            String resultText = EXCEPTION_MESSAGES.INCORRECT_BASE_OFFER_TYPE;
            DEBUG(m_logger, loggingKey + resultText);
            throw new InvalidRequestException(resultText);
        }
    }

    void validateRequestAddonOfferTemplateAttributes(String loggingKey,
                                                     VisibleRequestChangeServiceAdvice request,
                                                     MtxResponsePricingCatalogItem pricingAddon)
            throws InvalidRequestException {
        if (pricingAddon == null) {
            String resultText = "Invalid Catalog Item.";
            DEBUG(m_logger, loggingKey + resultText);
            throw new InvalidRequestException(resultText);
        } else if (RESULT_CODES.MTX_SUCCESS != pricingAddon.getResult()) {
            String resultText = "Invalid Catalog Item." + StringUtils.SPACE
                    + pricingAddon.getResultText();
            DEBUG(m_logger, loggingKey + resultText);
            throw new InvalidRequestException(resultText);
        } else if (pricingAddon.getCatalogItemInfo() == null) {
            String resultText = "Invalid Catalog Item.";
            DEBUG(m_logger, loggingKey + resultText);
            throw new InvalidRequestException(resultText);
        } else if (pricingAddon.getCatalogItemInfo().getTemplateAttr() == null
                || !(pricingAddon.getCatalogItemInfo().getTemplateAttr() instanceof VisibleTemplate)) {
            String resultText = "Invalid Catalog Item. Catalog Item does not have visible template attributes.";
            DEBUG(m_logger, loggingKey + resultText);
            throw new InvalidRequestException(resultText);
        }

        VisibleTemplate attr = (VisibleTemplate) pricingAddon.getCatalogItemInfo().getTemplateAttr();
        String newCiType = attr.getOfferType();
        if (!OFFER_CONSTANTS.OFFER_TYPE_ADDON.equalsIgnoreCase(newCiType)) {
            String resultText = EXCEPTION_MESSAGES.INCORRECT_ADDON_OFFER_TYPE;
            DEBUG(m_logger, loggingKey + resultText);
            throw new InvalidRequestException(resultText);
        }
    }

    void validateRequestCompareSubscription(String loggingKey,
                                            VisibleRequestChangeServiceAdvice request,
                                            SubscriptionResponse subscription)
            throws InvalidRequestException {
        if (subscription == null) {
            String resultText = "This subscription does not exist : "
                    + request.getSubscriptionExternalId();
            DEBUG(m_logger, loggingKey + resultText);
            throw new InvalidRequestException(resultText);
        } else if (subscription.getPurchasedOfferArray() == null
                || subscription.getPurchasedOfferArray().isEmpty()) {
            String resultText = "This subscription has no purchased offer details : "
                    + request.getSubscriptionExternalId();
            DEBUG(m_logger, loggingKey + resultText);
            throw new InvalidRequestException(resultText);
        } else if (subscription.getAttr() == null) {
            String resultText = "This subscription has no attribute extensions : "
                    + request.getSubscriptionExternalId();
            DEBUG(m_logger, loggingKey + resultText);
            throw new InvalidRequestException(resultText);
        }
        for (VisibleChangeServiceCancelItem cItem : CommonUtils.emptyIfNull(
                request.getCancelItems())) {
            if (StringUtils.isBlank(cItem.getCatalogItemExternalId())) {
                continue;
            }
            boolean foundAddon = false;
            for (MtxPurchasedOfferInfo offer : subscription.getPurchasedOfferArray()) {
                if (offer.getCatalogItemExternalId() == null) {
                    continue;
                }
                if (offer.getCatalogItemExternalId().equalsIgnoreCase(
                        cItem.getCatalogItemExternalId())
                        && (OFFER_CONSTANTS.OFFER_STATUS_ACTIVE.equalsIgnoreCase(
                                offer.getOfferStatusDescription())
                                || OFFER_CONSTANTS.OFFER_STATUS_PRE_ACTIVE.equalsIgnoreCase(
                                        offer.getOfferStatusDescription()))) {
                    foundAddon = true;
                    break;
                }
            }
            if (!foundAddon) {
                throw new InvalidRequestException(
                        EXCEPTION_MESSAGES.NO_OFFER_IN_SUBSCRIPTION
                                + cItem.getCatalogItemExternalId());
            }
        }

        for (MtxPurchasedOfferInfo offer : subscription.getPurchasedOfferArray()) {
            if (offer.getCatalogItemExternalId() == null) {
                continue;
            }

            if (offer.getCatalogItemExternalId().equalsIgnoreCase(
                    request.getNewCatalogItemExternalId())
                    && OFFER_CONSTANTS.OFFER_STATUS_ACTIVE.equalsIgnoreCase(
                            offer.getOfferStatusDescription())) {
                String resultText = offer.getCatalogItemExternalId()
                        + " is already an active offer. ";
                DEBUG(m_logger, loggingKey + resultText);
                throw new InvalidRequestException(resultText);
            } else if (offer.getCatalogItemExternalId().equalsIgnoreCase(
                    request.getNewCatalogItemExternalId())
                    && CommonUtils.isOfferPreActive(
                            loggingKey, m_logger, offer,
                            subscription.getBillingCycle().getCurrentPeriodEndTime())) {
                String resultText = offer.getCatalogItemExternalId()
                        + " is already a preactive offer that gets activated on or before next bill cycle. ";
                DEBUG(m_logger, loggingKey + resultText);
                throw new InvalidRequestException(resultText);
            }
        }
    }

    void validateRequestCompareEnrolledCi(String loggingKey,
                                          VisibleRequestChangeServiceAdvice request,
                                          MtxPurchasedOfferInfo enrolledPoi)
            throws InvalidRequestException {
        if (enrolledPoi == null || StringUtils.isBlank(enrolledPoi.getCatalogItemExternalId())) {
            String resultText = "Subscription does not have active enrolled offer that is of the same type as "
                    + request.getNewCatalogItemExternalId();
            DEBUG(m_logger, loggingKey + resultText);
            throw new InvalidRequestException(resultText);
        } else if (enrolledPoi.getCatalogItemExternalId().equalsIgnoreCase(
                request.getNewCatalogItemExternalId())) {
            String resultText = "Subscription already has " + request.getNewCatalogItemExternalId();
            DEBUG(m_logger, loggingKey + resultText);
            throw new InvalidRequestException(resultText);
        }
    }

    void validateRequestCompareAopResponse(String loggingKey,
                                           VisibleRequestChangeServiceAdvice request,
                                           AdviceDataStage aopStage)
            throws InvalidRequestException {
        if (aopStage == null || aopStage.getVisibleOfferDetailsMap() == null
                || aopStage.getVisibleOfferDetailsMap().values() == null
                || aopStage.getVisibleOfferDetailsMap().values().isEmpty()) {
            String resultText = "Payment advice does not have current service";
            DEBUG(m_logger, loggingKey + resultText);
            throw new InvalidRequestException(resultText);
        } else if (aopStage.getServiceStage(request.getNewCatalogItemExternalId()) != null) {
            String resultText = "Payment advice has same service as new catalog item id. No change needed. Enrolled service: "
                    + request.getNewCatalogItemExternalId();
            DEBUG(m_logger, loggingKey + resultText);
            throw new InvalidRequestException(resultText);
        }

    }

    void validateChangeRequestCycleDates(String loggingKey,
                                         MtxPurchasedOfferInfo enrolledPoi,
                                         String changeType,
                                         String timezone)
            throws InvalidRequestException {
        String immediateChangeTypes = AppPropertyProvider.getInstance().getString(
                CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_IMMEDIATE_START_CSV_LIST);
        String realignChangeTypes = AppPropertyProvider.getInstance().getString(
                CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_REALIGN_CYCLE_LIST);
        if (enrolledPoi == null || StringUtils.isBlank(enrolledPoi.getCatalogItemExternalId())) {
            String resultText = "Subscription does not have active enrolled offer of the type base ";
            DEBUG(m_logger, loggingKey + resultText);
            throw new InvalidRequestException(resultText);
        }
        if (!immediateChangeTypes.contains(changeType)
                && !realignChangeTypes.contains(changeType)) {
            if (enrolledPoi.getCycleInfo() != null
                    && enrolledPoi.getCycleInfo().getCycleEndTime() != null) {
                MtxTimestamp permittedChangeDate = CommonUtils.subtractOneMonth(
                        enrolledPoi.getCycleInfo().getCycleEndTime(), timezone);
                if (permittedChangeDate.longValue() > CommonUtils.getCurrentTimeMillis()) {
                    // i.e permitted change date is after today.
                    String resultText = changeType + " " + LOG_MESSAGES.NO_CHANGE_NOW
                            + LOG_MESSAGES.SERVICE_ENDS_ON
                            + enrolledPoi.getCycleInfo().getCycleEndTime() + ". "
                            + LOG_MESSAGES.TRY_AFTER + permittedChangeDate;
                    DEBUG(m_logger, loggingKey + resultText);
                    throw new InvalidRequestException(resultText);
                }
            }
        }
    }

}
