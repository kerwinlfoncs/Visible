package com.matrixx.vag.advice.service;

import static com.matrixx.platform.LogUtils.INFO;
import static com.matrixx.platform.LogUtils.WARN;

import java.math.BigDecimal;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.matrixx.vag.advice.model.ServiceStage;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.Constants.CI_METADATA;
import com.matrixx.vag.common.Constants.GENERIC_CONSTANTS;
import com.matrixx.vag.common.Constants.LOG_MESSAGES;
import com.matrixx.vag.common.Constants.OFFER_CONSTANTS;
import com.matrixx.vag.common.Constants.TAX_CONSTANTS;
import com.matrixx.vag.common.request.builder.ServiceTaxRequestBuilder;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.tax.model.DpcGroup;
import com.matrixx.vag.tax.model.DpcGroupTax;
import com.matrixx.vag.tax.model.DpcItem;
import com.matrixx.vag.tax.model.DpcItemTax;
import com.matrixx.vag.tax.model.ServiceTaxRequest;
import com.matrixx.vag.tax.model.ServiceTaxResponse;
import com.matrixx.vag.tax.model.TransactionElement;

public class PaymentAdviceUtils {

    private static final Logger m_logger = LoggerFactory.getLogger(QuoteAdviceUtils.class);

    public static void updateTaxesInServiceStage(String loggingKey,
                                                 String route,
                                                 AdviceDataStage stage) {
        final String methodKey = loggingKey + " updateTaxesInServiceStage: ";

        if (!stage.isAdviceWithTaxes()) {
            INFO(m_logger, methodKey + "Advice is without taxes. Taxapi will not be called.");
            return;
        }

        for (ServiceStage svcStage : stage.getPayNowMap().values()) {
            if (svcStage.isSkipRenewal()) {
                INFO(m_logger, methodKey + "No renewal next month. Taxapi will not be called.");
                continue;
            }
            
            if (svcStage.getDiscountPrice().signum() <= 0) {
                // As per VER-549 comments. If a zero dollar offer then send response from metadata.
                INFO(m_logger, methodKey + "Discount price is zero.");
                if (StringUtils.isNotBlank(svcStage.getZeroTaxResponse())) {
                    INFO(
                            m_logger, methodKey
                                    + "Zero Dollar Tax Response from pricing metadata will be used.");
                    ServiceTaxResponse tResponse;
                    try {
                        tResponse = CommonUtils.getServiceTaxResponseFromJsonString(
                                svcStage.getZeroTaxResponse());
                    } catch (Exception ex) {
                        WARN(
                                m_logger, methodKey
                                        + "Zero Dollar Tax Response from pricing metadata is not parseable. Tax response will not be set.");
                        WARN(m_logger, methodKey + ex.getMessage());
                        continue;
                    }
                    tResponse.setGlDate(
                            CommonUtils.getDateYYYYMMDDasHiphenString(
                                    stage.getSubscriptionTimezone()));
                    if (StringUtils.isNotBlank(stage.getRequestGeoCode())) {
                        tResponse.setGeocode(stage.getRequestGeoCode());
                    } else if (StringUtils.isNotBlank(stage.getPayerGeoCode())) {
                        tResponse.setGeocode(stage.getPayerGeoCode());
                    } else {
                        tResponse.setGeocode(stage.getSubscriberGeoCode());
                    }
                    svcStage.setTaxResponse(tResponse.toJson());

                } else {
                    INFO(
                            m_logger, methodKey
                                    + "Zero Dollar Tax Response is not configured in pricing metadata. Tax response will not be set.");
                }
                continue;
            }

            String taxTemplateName = "";
            if ((svcStage.getOfferType().equalsIgnoreCase(OFFER_CONSTANTS.OFFER_TYPE_ADDON)
                    && stage.isBaseOfferInAdvice())) {
                long currentPeriodEndTime = stage.getCycleStartTime().getTimestamp().getTime();
                if (svcStage.getEffectivePaidCycleStartDate() != null) {
                    if (StringUtils.isNotEmpty(
                            svcStage.getEffectivePaidCycleStartDate().toString())) {
                        long paidCycleStartDate = svcStage.getEffectivePaidCycleStartDate().getTimestamp().getTime();
                        if (paidCycleStartDate > currentPeriodEndTime) {
                            taxTemplateName = CI_METADATA.STANDALONE_TAX_INPUT;
                        } else {
                            taxTemplateName = CI_METADATA.TAX_INPUT;
                        }
                    }
                } else {
                    taxTemplateName = CI_METADATA.TAX_INPUT;
                }
            } else if (svcStage.getOfferType().equalsIgnoreCase(OFFER_CONSTANTS.OFFER_TYPE_ADDON)) {
                taxTemplateName = CI_METADATA.STANDALONE_TAX_INPUT;
            } else {
                taxTemplateName = CI_METADATA.TAX_INPUT;
            }

            String taxTemplate = taxTemplateName.equalsIgnoreCase(CI_METADATA.STANDALONE_TAX_INPUT)
                    ? svcStage.getStandaloneTaxInput() : svcStage.getTaxInput();

            try {
                BigDecimal vendorPayableNonProrated = BigDecimal.ZERO;
                if (svcStage.getPrevTaxResponse() != null) {
                    if (svcStage.getPrevTaxResponse().getVendorPayableNonProrated() != null) {
                        vendorPayableNonProrated = svcStage.getPrevTaxResponse().getVendorPayableNonProrated();
                    }
                }

                INFO(
                        m_logger,
                        methodKey + "Call TaxApi to calculate service taxes for payment advice");

                String geoCode;                
                if (StringUtils.isNotBlank(stage.getRequestGeoCode())) {
                    geoCode = stage.getRequestGeoCode();
                } else if (StringUtils.isNotBlank(stage.getPayerGeoCode())) {
                    geoCode = stage.getPayerGeoCode();                    
                } else {
                    if (StringUtils.isNotBlank(stage.getSubscriberGeoCode())) {
                        geoCode = stage.getSubscriberGeoCode();
                    } else if (StringUtils.isNotBlank(svcStage.getPreviousGeocode())) {
                        geoCode = svcStage.getPreviousGeocode();
                    } else {
                        String noGeocodeMsg = "No valid geocode passed for tax calculation"
                                + StringUtils.SPACE + "requestGeoCode: " + stage.getRequestGeoCode()
                                + StringUtils.SPACE + "subscriberGeoCode: "
                                + stage.getSubscriberGeoCode() + StringUtils.SPACE
                                + "refTaxGeoCode: " + svcStage.getPreviousGeocode();

                        WARN(
                                m_logger,
                                methodKey + LOG_MESSAGES.LOG_FAILED_SERVICE_TAX + StringUtils.SPACE
                                        + GENERIC_CONSTANTS.ERROR_PREFIX + noGeocodeMsg);
                        svcStage.setTaxResponse(GENERIC_CONSTANTS.ERROR_PREFIX + noGeocodeMsg);
                        stage.setServiceTaxApiErrorMessage(
                                LOG_MESSAGES.LOG_FAILED_SERVICE_TAX + StringUtils.SPACE
                                        + GENERIC_CONSTANTS.ERROR_PREFIX + noGeocodeMsg);
                        return;
                    }
                }
                // @formatter:off
                ServiceTaxRequestBuilder builder = (new ServiceTaxRequestBuilder())
                        .withRequestTemplate(taxTemplate)
                        .withGrossPrice(svcStage.getGrossPrice())
                        .withDiscountPrice(svcStage.getProratedDiscountPrice())
                        .withVendorPayableNonProrated(vendorPayableNonProrated)
                        .withVendorPayable(vendorPayableNonProrated)
                        .withPlanID(svcStage.getPreviousPlanId())
                        .withBrand(stage.getBrand())
                        .withGeoCode(geoCode);
                // @formatter:on

                ServiceTaxRequest request = builder.build();
                if (StringUtils.isNotBlank(stage.getPayerExternalId())) {
                    request.setMsgID(String.format(TAX_CONSTANTS.MSG_FORMAT_ADVICE, request.getMsgID(), stage.getPayerExternalId()));
                }
                final String classCodes = AppPropertyProvider.getInstance().getString(
                        TAX_CONSTANTS.USE_CPS_FROM_LAST_TAX);
                if (svcStage.getPrevTaxResponse() != null && classCodes.toUpperCase().contains(
                        svcStage.getPrevTaxResponse().getClassCode().toUpperCase())) {
                    for (TransactionElement pte : CommonUtils.emptyIfNull(
                            svcStage.getPrevTaxResponse().getTransactionElement())) {
                        for (DpcGroupTax pdgt : CommonUtils.emptyIfNull(pte.getDpcGroupList())) {
                            for (DpcGroup rdg : CommonUtils.emptyIfNull(
                                    request.getDpcGroupList())) {
                                if (!pdgt.getDpcGroup().equalsIgnoreCase(rdg.getDpcGroup())) {
                                    // This is coded only for insurance. This has to be revisited
                                    // for something like PLUS3VIS23WB. DpcGroups with planID and
                                    // class code.
                                    continue;
                                }

                                for (DpcItemTax pdit : CommonUtils.emptyIfNull(
                                        pdgt.getDpcItemList())) {
                                    for (DpcItem rdi : CommonUtils.emptyIfNull(
                                            rdg.getDpcItemList())) {
                                        if (!pdit.getDpcItem().equalsIgnoreCase(rdi.getDpcItem())) {
                                            continue;
                                        } else {
                                            rdi.setcP(pdit.getcP());
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                String taxResp = AdviceUtils.getTaxDetailsWithoutRefTax(loggingKey, route, request);

                if (StringUtils.isNotBlank(taxResp)
                        && !taxResp.toUpperCase().startsWith(GENERIC_CONSTANTS.ERROR_PREFIX)) {
                    svcStage.setTaxResponse(taxResp);
                    ServiceTaxResponse taxDetails = CommonUtils.getServiceTaxResponseFromJsonString(
                            taxResp);
                    svcStage.setTaxFeeAmount(
                            taxDetails.getTransactionElement().get(0).getTotalFeeAmount());
                } else {
                    WARN(
                            m_logger, methodKey + LOG_MESSAGES.LOG_FAILED_SERVICE_TAX
                                    + StringUtils.SPACE + taxResp);
                    svcStage.setTaxResponse(taxResp);
                    stage.setServiceTaxApiErrorMessage(
                            LOG_MESSAGES.LOG_FAILED_SERVICE_TAX + StringUtils.SPACE + taxResp);
                }
            } catch (Exception ex) {
                WARN(
                        m_logger, methodKey + LOG_MESSAGES.LOG_FAILED_SERVICE_TAX
                                + StringUtils.SPACE + ExceptionUtils.getStackTrace(ex));
                svcStage.setTaxResponse(GENERIC_CONSTANTS.ERROR_PREFIX + ex.getMessage());
                stage.setServiceTaxApiErrorMessage(
                        LOG_MESSAGES.LOG_FAILED_SERVICE_TAX + StringUtils.SPACE + ex.getMessage());
            }
        }
    }

}
