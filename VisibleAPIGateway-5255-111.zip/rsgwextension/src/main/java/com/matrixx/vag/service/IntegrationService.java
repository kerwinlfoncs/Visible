package com.matrixx.vag.service;

import static com.matrixx.platform.LogUtils.DEBUG;
import static com.matrixx.platform.LogUtils.WARN;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.matrixx.datacontainer.MtxObjectId;
import com.matrixx.datacontainer.MtxPhone;
import com.matrixx.datacontainer.MtxTimestamp;
import com.matrixx.datacontainer.SubscriberManagementApi;
import com.matrixx.datacontainer.mdc.BalanceInfo;
import com.matrixx.datacontainer.mdc.EventQueryRequestEventId;
import com.matrixx.datacontainer.mdc.EventQueryRequestSubscriber;
import com.matrixx.datacontainer.mdc.EventQueryResponseEvents;
import com.matrixx.datacontainer.mdc.MtxBalanceImpactInfo;
import com.matrixx.datacontainer.mdc.MtxBalanceImpactInfoGroup;
import com.matrixx.datacontainer.mdc.MtxBalanceInfo;
import com.matrixx.datacontainer.mdc.MtxBalanceInfoSimple;
import com.matrixx.datacontainer.mdc.MtxBundleOfferInfo;
import com.matrixx.datacontainer.mdc.MtxCancelInfo;
import com.matrixx.datacontainer.mdc.MtxCancelOfferData;
import com.matrixx.datacontainer.mdc.MtxChargeMethodData;
import com.matrixx.datacontainer.mdc.MtxDeviceSearchData;
import com.matrixx.datacontainer.mdc.MtxGroupSearchData;
import com.matrixx.datacontainer.mdc.MtxPricingAttrInfo;
import com.matrixx.datacontainer.mdc.MtxPricingBalanceClassDetailInfo;
import com.matrixx.datacontainer.mdc.MtxPricingBillingCycleSearchData;
import com.matrixx.datacontainer.mdc.MtxPricingBundleDetailInfo;
import com.matrixx.datacontainer.mdc.MtxPricingCatalogItemSearchData;
import com.matrixx.datacontainer.mdc.MtxPricingOfferDetailInfo;
import com.matrixx.datacontainer.mdc.MtxPricingOfferSearchData;
import com.matrixx.datacontainer.mdc.MtxPurchaseInfo;
import com.matrixx.datacontainer.mdc.MtxPurchasedOfferData;
import com.matrixx.datacontainer.mdc.MtxRequestDeviceCreate;
import com.matrixx.datacontainer.mdc.MtxRequestDeviceDelete;
import com.matrixx.datacontainer.mdc.MtxRequestDeviceDeleteSession;
import com.matrixx.datacontainer.mdc.MtxRequestDeviceModify;
import com.matrixx.datacontainer.mdc.MtxRequestDeviceQuery;
import com.matrixx.datacontainer.mdc.MtxRequestGroupModify;
import com.matrixx.datacontainer.mdc.MtxRequestGroupQuery;
import com.matrixx.datacontainer.mdc.MtxRequestMulti;
import com.matrixx.datacontainer.mdc.MtxRequestPricingQueryBillingCycle;
import com.matrixx.datacontainer.mdc.MtxRequestPricingQueryCatalogItem;
import com.matrixx.datacontainer.mdc.MtxRequestPricingQueryOffer;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberAddDevice;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberAddPaymentMethod;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberAdjustBalance;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberCancelOffer;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberEstimateRecurringCharge;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberModify;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberModifyPaymentMethod;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberPurchaseOffer;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberQueryOneTimeOffer;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberQueryPaymentHistory;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberQueryPaymentMethod;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberQueryWallet;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberRecharge;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberRefundPayment;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberRemoveDevice;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberRemovePaymentMethod;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriptionModify;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriptionQuery;
import com.matrixx.datacontainer.mdc.MtxRequestSysCreateClientToken;
import com.matrixx.datacontainer.mdc.MtxRequestUserQuery;
import com.matrixx.datacontainer.mdc.MtxResponse;
import com.matrixx.datacontainer.mdc.MtxResponseAdd;
import com.matrixx.datacontainer.mdc.MtxResponseCancel;
import com.matrixx.datacontainer.mdc.MtxResponseClientToken;
import com.matrixx.datacontainer.mdc.MtxResponseDevice;
import com.matrixx.datacontainer.mdc.MtxResponseGroup;
import com.matrixx.datacontainer.mdc.MtxResponseMulti;
import com.matrixx.datacontainer.mdc.MtxResponseOneTimeOffer;
import com.matrixx.datacontainer.mdc.MtxResponsePaymentHistory;
import com.matrixx.datacontainer.mdc.MtxResponsePaymentMethodInfo;
import com.matrixx.datacontainer.mdc.MtxResponsePricingBillingCycle;
import com.matrixx.datacontainer.mdc.MtxResponsePricingCatalogItem;
import com.matrixx.datacontainer.mdc.MtxResponsePricingOffer;
import com.matrixx.datacontainer.mdc.MtxResponsePurchase;
import com.matrixx.datacontainer.mdc.MtxResponseRecurringChargeInfo;
import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import com.matrixx.datacontainer.mdc.MtxResponseUser;
import com.matrixx.datacontainer.mdc.MtxResponseWallet;
import com.matrixx.datacontainer.mdc.MtxSubscriberSearchData;
import com.matrixx.datacontainer.mdc.MtxSubscriptionSearchData;
import com.matrixx.datacontainer.mdc.MtxUserSearchData;
import com.matrixx.datacontainer.mdc.PricingBalanceDetailInfo;
import com.matrixx.datacontainer.mdc.PurchasedOfferInfo;
import com.matrixx.datacontainer.mdc.SubscriberQuery;
import com.matrixx.datacontainer.mdc.SubscriptionResponse;
import com.matrixx.datacontainer.mdc.VisibleCAGroupExtension;
import com.matrixx.datacontainer.mdc.VisibleDeviceExtension;
import com.matrixx.datacontainer.mdc.VisibleRechargeExtension;
import com.matrixx.datacontainer.mdc.VisibleRiskData;
import com.matrixx.datacontainer.rest.JsonStubs;
import com.matrixx.datacontainer.rest.RestQueryTerm;
import com.matrixx.platform.JsonObject;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.Constants.BALANCE_CONSTANTS;
import com.matrixx.vag.common.Constants.CHANGE_SERVICE_CONSTANTS;
import com.matrixx.vag.common.Constants.CI_METADATA;
import com.matrixx.vag.common.Constants.EVENT_TYPES;
import com.matrixx.vag.common.Constants.LOG_MESSAGES;
import com.matrixx.vag.common.Constants.MATRIXX_CONSTANTS;
import com.matrixx.vag.common.Constants.OFFER_CONSTANTS;
import com.matrixx.vag.common.Constants.REQUEST_QUERY_TERM_PREFIX;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.common.coverage.Generated;
import com.matrixx.vag.common.request.builder.MtxPurchasedOfferDataBuilder;
import com.matrixx.vag.exception.DeviceServiceException;
import com.matrixx.vag.exception.IntegrationServiceException;
import com.matrixx.vag.exception.PaymentAdviceException;
import com.matrixx.vag.exception.SubscriberServiceException;
import com.matrixx.vag.exception.TaxApiException;
import com.matrixx.vag.tax.client.TaxApiClient;

/**
 * Base class for MATRIXX integration services (using Business API Gateway)
 *
 * @author CGI
 */
public abstract class IntegrationService extends JsonStubs {

    protected final static String ATTR_NAME_GOOD_TYPE = "good_type";
    protected final static String ATTR_NAME_RECHARGE_REASON_NRF_BAD_DEBT = "recharge_bad_debt";
    protected final static String ATTR_NAME_REFUND_REASON = "refund_reason";
    protected final static String ATTR_NAME_RECHARGE_BAD_DEBT = "recharge_bad_debt";

    public static final String SERVICE_TYPE_SERVICE = "SERVICE";
    public static final String SERVICE_TYPE_INSURANCE = "INSURANCE";

    private final Map<String, MtxResponsePricingCatalogItem> ciMap = new HashMap<String, MtxResponsePricingCatalogItem>();

    private static final Logger m_logger = LoggerFactory.getLogger(IntegrationService.class);

    public MtxResponseUser queryUserByObjectId(String loggingKey, MtxObjectId objectId) {
        MtxUserSearchData msud = new MtxUserSearchData();
        msud.setObjectId(objectId);
        return queryUserBySearchData(loggingKey, msud);
    }

    public MtxResponseUser queryUserBySubscriptionExternalId(String loggingKey,
                                                             String subscriptionExternalId) {
        MtxUserSearchData msud = new MtxUserSearchData();
        MtxSubscriptionSearchData mssd = new MtxSubscriptionSearchData();
        mssd.setExternalId(subscriptionExternalId);
        msud.setSubscriptionSearchData(mssd);
        return queryUserBySearchData(loggingKey, msud);
    }

    public MtxResponseUser queryUserBySubscriptionObjectId(String loggingKey,
                                                           MtxObjectId subscriptionObjectId) {
        MtxUserSearchData msud = new MtxUserSearchData();
        MtxSubscriptionSearchData mssd = new MtxSubscriptionSearchData();
        mssd.setObjectId(subscriptionObjectId);
        msud.setSubscriptionSearchData(mssd);
        return queryUserBySearchData(loggingKey, msud);
    }

    public MtxResponseUser queryUserBySearchData(String loggingKey, MtxUserSearchData msud) {
        final String methodName = "queryUser: ";
        MtxRequestUserQuery reqMsg = new MtxRequestUserQuery();
        reqMsg.setUserSearchData(msud);
        DEBUG(
                m_logger,
                loggingKey + methodName + StringUtils.SPACE + "Request: " + reqMsg.toJson());
        MtxResponseUser rspMsg = new MtxResponseUser();
        try {
            rspMsg = m_api.userQuery(reqMsg);
            DEBUG(
                    m_logger,
                    loggingKey + methodName + StringUtils.SPACE + "Response: " + rspMsg.toJson());
        } catch (Exception e) {
            DEBUG(m_logger, "Failed to get user: " + ExceptionUtils.getStackTrace(e));
            rspMsg.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            rspMsg.setResultText(e.getMessage());
        }
        return rspMsg;
    }

    public SubscriptionResponse querySubscriptionByObjectId(String loggingKey,
                                                            String route,
                                                            String objectIdString) {
        RestQueryTerm rqt = new RestQueryTerm(objectIdString);
        return querySubscriptionByRQT(loggingKey, route, rqt);
    }

    public SubscriptionResponse querySubscriptionByExternalId(String loggingKey,
                                                              String route,
                                                              String subscriptionExternalId) {
        RestQueryTerm rqt = new RestQueryTerm(
                REQUEST_QUERY_TERM_PREFIX.EXTERNAL_ID + subscriptionExternalId);
        return querySubscriptionByRQT(loggingKey, route, rqt);
    }

    @SuppressWarnings("unchecked")
    public SubscriptionResponse querySubscriptionByRQT(String loggingKey,
                                                       String route,
                                                       RestQueryTerm rqt) {
        final String methodName = "querySubscriptionByRQT: ";
        JsonObject ret = new JsonObject();
        SubscriberQuery reqMsg = new SubscriberQuery();
        SubscriptionResponse rspMsg = new SubscriptionResponse();
        try {

            DEBUG(
                    m_logger,
                    loggingKey + methodName + StringUtils.SPACE + "Request: " + reqMsg.toJson());
            DEBUG(
                    m_logger, loggingKey + methodName + StringUtils.SPACE + "RequestQueryTerm: "
                            + rqt.toString());
            service_subscription_query(route, ret, rqt, reqMsg, rspMsg);

            rspMsg = callSubscriptionResponseTransform(rspMsg);
            // 20240423-Reduce some info to reduce log size
            if (rspMsg.getPurchasedOfferArray() != null) {
                rspMsg.getPurchasedOfferArray().forEach(mpoi -> {
                    PurchasedOfferInfo poi = (PurchasedOfferInfo) mpoi;
                    if (poi.getMetadataList() != null && !poi.getMetadataList().isEmpty()) {
                        poi.getMetadataListAppender().clear();
                    }
                    poi.setBundleDetails((MtxPricingBundleDetailInfo) null);
                    poi.setOfferDetails((MtxPricingOfferDetailInfo) null);
                    if (poi.getRequiredBalanceArray() != null
                            && !poi.getRequiredBalanceArray().isEmpty()) {
                        poi.getRequiredBalanceArrayAppender().clear();
                    }
                });
            }

            List<BalanceInfo> temp = new ArrayList<BalanceInfo>();
            for (BalanceInfo bi : CommonUtils.emptyIfNull(rspMsg.getWalletBalances())) {
                if (StringUtils.isNotBlank(bi.getClassName())
                        && !BALANCE_CONSTANTS.BAPI_UNUSED_BALANCE_CLASSES_UPPER.contains(
                                bi.getClassName().toUpperCase())) {
                    bi.setBalanceTemplateDetails((PricingBalanceDetailInfo) null);
                    bi.setBalanceDetails((MtxBalanceInfoSimple) null);
                    bi.setBalanceClassDetails((MtxPricingBalanceClassDetailInfo) null);
                    bi.getAttrListAppender().clear();
                    bi.getThresholdArrayAppender().clear();
                    bi.getBalancePeriodArrayAppender().clear();
                    temp.add(bi);
                }
            }
            rspMsg.getWalletBalancesAppender().clear();
            rspMsg.getWalletBalancesAppender().addAll(temp);

            DEBUG(
                    m_logger,
                    loggingKey + methodName + StringUtils.SPACE + "Response: " + rspMsg.toJson());

        } catch (Exception e) {
            DEBUG(m_logger, "Failed to get subscription: " + ExceptionUtils.getStackTrace(e));
            rspMsg.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            rspMsg.setResultText(e.getMessage());
        }
        return rspMsg;
    }

    @Generated
    public SubscriptionResponse callSubscriptionResponseTransform(SubscriptionResponse subResp) {
        // Convenience method for jUnit test
        return (SubscriptionResponse) postCallTransform("service_subscription_query", subResp);
    }

    /**
     * Query subscriber data in MATRIXX.
     * 
     * @param loggingKey
     * @param objectId
     * @return
     */
    public MtxResponseSubscription querySubscriptionDataByObjectId(String loggingKey,
                                                                   String objectIdString) {

        final String methodName = "querySubscriptionDataByObjectId: ";

        // Create a request to query subscriber
        DEBUG(
                m_logger, loggingKey + methodName + StringUtils.SPACE
                        + "Creating subscription query request with object Id");
        MtxRequestSubscriptionQuery reqMsg = new MtxRequestSubscriptionQuery();
        MtxObjectId objId = new MtxObjectId(objectIdString);

        MtxSubscriptionSearchData searchData = new MtxSubscriptionSearchData();
        searchData.setObjectId(objId);

        // Set the subscriber search key
        reqMsg.setSubscriptionSearchData(searchData);

        // Send the request to MATRIXX and receive the response
        DEBUG(
                m_logger, loggingKey + methodName + StringUtils.SPACE + "Sending to MATRIXX\n"
                        + reqMsg.toJson());
        MtxResponseSubscription rspMsg = m_api.subscriptionQuery(reqMsg);
        if (rspMsg == null) {
            DEBUG(
                    m_logger, loggingKey + methodName + StringUtils.SPACE
                            + "No Subscription Data Received from MATRIXX\n");
            return null;
        }
        DEBUG(
                m_logger, loggingKey + methodName + StringUtils.SPACE + "Received from MATRIXX\n"
                        + rspMsg.toJson());

        return rspMsg;
    }

    /**
     * Query subscriber data in MATRIXX.
     * 
     * @param loggingKey
     * @param searchData
     * @return
     */
    public MtxResponseSubscription querySubscriptionData(String loggingKey,
                                                         String subscriptionExternalId) {
        final String methodName = "querySubscriptionData: ";

        // Create a request to query subscriber
        DEBUG(
                m_logger, loggingKey + methodName + StringUtils.SPACE
                        + "Creating subscription query request");
        MtxRequestSubscriptionQuery reqMsg = new MtxRequestSubscriptionQuery();

        MtxSubscriptionSearchData searchData = new MtxSubscriptionSearchData();
        searchData.setExternalId(subscriptionExternalId);

        // Set the subscriber search key
        reqMsg.setSubscriptionSearchData(searchData);

        // Send the request to MATRIXX and receive the response
        DEBUG(
                m_logger, loggingKey + methodName + StringUtils.SPACE + "Sending to MATRIXX\n"
                        + reqMsg.toJson());
        MtxResponseSubscription rspMsg = m_api.subscriptionQuery(reqMsg);
        if (rspMsg == null) {
            DEBUG(
                    m_logger, loggingKey + methodName + StringUtils.SPACE
                            + "No Subscription Data Received from MATRIXX\n");
            return null;
        }
        DEBUG(
                m_logger, loggingKey + methodName + StringUtils.SPACE + "Received from MATRIXX\n"
                        + rspMsg.toJson());

        return rspMsg;
    }

    @SuppressWarnings("unchecked")
    public MtxResponseMulti querySubscriptionGroups(String loggingKey,
                                                    String route,
                                                    MtxResponseSubscription subscription) {
        MtxResponseMulti multiRespMsg = null;
        // Get Subscription groups
        if (subscription.getParentGroupIdArray() != null
                && subscription.getParentGroupIdArray().size() > 0) {
            MtxRequestMulti multiReqMsg = new MtxRequestMulti();
            subscription.getParentGroupIdArray().forEach(oid -> {
                // Create a request to purchase offer
                DEBUG(m_logger, loggingKey + "Creating group query request");
                MtxRequestGroupQuery reqMsg = new MtxRequestGroupQuery();
                MtxGroupSearchData search = new MtxGroupSearchData();
                search.setObjectId(oid);
                // Always try to fetch only max of one associated item. We are interested only in
                // subscription count
                reqMsg.setQuerySize(1L);
                reqMsg.setGroupSearchData(search);
                multiReqMsg.getRequestListAppender().add(reqMsg);
            });
            multiRespMsg = multiRequest(loggingKey, route, multiReqMsg);
        }
        return multiRespMsg;
    }

    public MtxResponseGroup querySubscriptionGroup(String loggingKey, MtxObjectId oid) {
        DEBUG(m_logger, loggingKey + "Creating group query request");
        MtxRequestGroupQuery reqMsg = new MtxRequestGroupQuery();
        MtxGroupSearchData search = new MtxGroupSearchData();
        search.setObjectId(oid);
        reqMsg.setQuerySize(1L);
        reqMsg.setGroupSearchData(search);
        DEBUG(m_logger, loggingKey + "Sending to MATRIXX\n" + reqMsg.toJson());
        MtxResponseGroup rspMsg = m_api.groupQuery(reqMsg);
        DEBUG(m_logger, loggingKey + "Received from MATRIXX\n" + rspMsg.toJson());
        return rspMsg;
    }

    public MtxResponse updateSubscriptionGroupAttr(String loggingKey,
                                                   MtxObjectId oid,
                                                   VisibleCAGroupExtension attr) {
        DEBUG(m_logger, loggingKey + "Creating group modify request");
        MtxGroupSearchData search = new MtxGroupSearchData();
        search.setObjectId(oid);
        MtxRequestGroupModify reqMsg = new MtxRequestGroupModify();
        reqMsg.setGroupSearchData(search);
        reqMsg.setAttr(attr);
        DEBUG(m_logger, loggingKey + "Sending to MATRIXX\n" + reqMsg.toJson());
        MtxResponse rspMsg = m_api.groupModify(reqMsg);
        DEBUG(m_logger, loggingKey + "Received from MATRIXX\n" + rspMsg.toJson());
        return rspMsg;
    }

    @SuppressWarnings("unchecked")
    public MtxResponseWallet querySubscriptionWalletMinimal(String loggingKey,
                                                            String route,
                                                            String subscriptionExternalId) {
        // Create a request to purchase offer
        DEBUG(m_logger, loggingKey + "Creating subscriber wallet query request");
        MtxRequestSubscriberQueryWallet reqMsg = new MtxRequestSubscriberQueryWallet();

        // MtxSubscriptionSearchData is not working
        MtxSubscriberSearchData subscriberSearchData = new MtxSubscriberSearchData();
        subscriberSearchData.setExternalId(subscriptionExternalId);

        // Set the subscriber search key
        reqMsg.setSubscriberSearchData(subscriberSearchData);

        // Send the request to MATRIXX and receive the response
        DEBUG(m_logger, loggingKey + "Sending to MATRIXX\n" + reqMsg.toJson());
        MtxResponseWallet rspMsg = m_api.subscriberQueryWallet(reqMsg);
        List<MtxBalanceInfo> temp = new ArrayList<MtxBalanceInfo>();
        for (MtxBalanceInfo bi : CommonUtils.emptyIfNull(rspMsg.getBalanceArray())) {
            if (StringUtils.isNotBlank(bi.getClassName())
                    && !BALANCE_CONSTANTS.BAPI_UNUSED_BALANCE_CLASSES_UPPER.contains(
                            bi.getClassName().toUpperCase())) {
                temp.add(bi);
            }
        }
        rspMsg.getBalanceArrayAppender().clear();
        rspMsg.getBalanceArrayAppender().addAll(temp);
        DEBUG(m_logger, loggingKey + "Wallet filtered Response\n" + rspMsg.toJson());

        return rspMsg;
    }

    public MtxResponseWallet querySubscriptionWallet(String loggingKey,
                                                     String route,
                                                     String subscriptionExternalId) {
        // Create a request to purchase offer
        DEBUG(m_logger, loggingKey + "Creating subscriber wallet query request");
        MtxRequestSubscriberQueryWallet reqMsg = new MtxRequestSubscriberQueryWallet();

        // MtxSubscriptionSearchData is not working
        MtxSubscriberSearchData subscriberSearchData = new MtxSubscriberSearchData();
        subscriberSearchData.setExternalId(subscriptionExternalId);

        // Set the subscriber search key
        reqMsg.setSubscriberSearchData(subscriberSearchData);

        // Send the request to MATRIXX and receive the response
        DEBUG(m_logger, loggingKey + "Sending to MATRIXX\n" + reqMsg.toJson());
        MtxResponseWallet rspMsg = m_api.subscriberQueryWallet(route, reqMsg);
        DEBUG(m_logger, loggingKey + "Received from MATRIXX\n" + rspMsg.toJson());

        return rspMsg;
    }

    public EventQueryResponseEvents querySubscriptionEventList(String route,
                                                               String subscriptionExternalId,
                                                               String[] searchEventTypes) {
        return querySubscriberEventList(
                route, "ExternalId+" + subscriptionExternalId, searchEventTypes, null, null);
    }

    /**
     * @param route
     *            the routing data
     * @param searchTerm
     *            the query search term
     * @param searchEventTypes
     *            the event types to search for
     * @return the events found that match the query parameters
     */
    @Generated
    public EventQueryResponseEvents querySubscriberEventList(String route,
                                                             String searchTerm,
                                                             String[] searchEventTypes) {
        return querySubscriberEventList(route, searchTerm, searchEventTypes, null, null);
    }

    /**
     * Query the subscriber event list in MATRIXX.
     *
     * @param route
     *            the routing data
     * @param searchTerm
     *            the query search term
     * @param searchEventTypes
     *            the event types to search for
     * @param timeLowerBound
     *            the lower bound time boundary (start time)
     * @return the events found that match the query parameters
     */
    @Generated
    public EventQueryResponseEvents querySubscriberEventList(String route,
                                                             String searchTerm,
                                                             String[] searchEventTypes,
                                                             MtxTimestamp timeLowerBound) {
        return querySubscriberEventList(route, searchTerm, searchEventTypes, timeLowerBound, null);
    }

    @Generated
    public EventQueryResponseEvents queryRecurringEvents(String subscriptionExternalId,
                                                         MtxTimestamp timeLowerBound) {
        String[] searchEventTypes = {
            EVENT_TYPES.RECURRING
        };
        return querySubscriberEventList(
                "", "ExternalId+" + subscriptionExternalId, searchEventTypes, timeLowerBound, null);
    }

    @Generated
    public EventQueryResponseEvents queryRechargeEvents(String subscriptionExternalId) {
        String[] searchEventTypes = {
            EVENT_TYPES.RECHARGE
        };
        return querySubscriberEventList(
                "", "ExternalId+" + subscriptionExternalId, searchEventTypes, null, null);
    }

    /**
     * Query the subscriber event list in MATRIXX.
     *
     * @param route
     *            the routing data
     * @param searchTerm
     *            the query search term
     * @param searchEventTypes
     *            the event types to search for
     * @param timeLowerBound
     *            the lower bound time boundary (start time)
     * @param timeUpperBound
     *            the upper bound time boundary (end time)
     * @return the events found that match the query parameters
     */
    public EventQueryResponseEvents querySubscriberEventList(String route,
                                                             String searchTerm,
                                                             String[] searchEventTypes,
                                                             MtxTimestamp timeLowerBound,
                                                             MtxTimestamp timeUpperBound) {

        JsonObject ret = new JsonObject();
        RestQueryTerm rqt = new RestQueryTerm(searchTerm);
        EventQueryResponseEvents rspMsg = new EventQueryResponseEvents();
        try {
            EventQueryRequestSubscriber reqMsg = new EventQueryRequestSubscriber();
            for (String eType : searchEventTypes) {
                reqMsg.appendEventTypeArray(eType);
            }
            if (timeLowerBound != null) {

                Calendar calLower = Calendar.getInstance();
                calLower.setTimeInMillis(timeLowerBound.getTimestamp().getTime());
                calLower.set(Calendar.HOUR_OF_DAY, 0);
                calLower.set(Calendar.MINUTE, 0);
                calLower.set(Calendar.SECOND, 0);
                calLower.set(Calendar.MILLISECOND, 0);

                reqMsg.setEventTimeLowerBound(new MtxTimestamp(calLower.getTimeInMillis()));
            }
            if (timeUpperBound != null) {
                Calendar calUpper = Calendar.getInstance();
                calUpper.setTimeInMillis(timeUpperBound.getTimestamp().getTime());
                calUpper.set(Calendar.HOUR_OF_DAY, 23);
                calUpper.set(Calendar.MINUTE, 59);
                calUpper.set(Calendar.SECOND, 59);
                calUpper.set(Calendar.MILLISECOND, 999);

                reqMsg.setEventTimeUpperBound(new MtxTimestamp(calUpper.getTimeInMillis()));
            }

            buildFilter("eventstore_subscriber_event");
            reqMsg = (EventQueryRequestSubscriber) preCallTransform(
                    "eventstore_subscriber_event", reqMsg);
            DEBUG(m_logger, "QuerySubscriberEventList Request: " + reqMsg.toJson());
            eventstore_subscriber_event(route, ret, rqt, reqMsg, rspMsg);
            DEBUG(m_logger, "QuerySubscriberEventList Response: " + rspMsg.toJson());
            rspMsg = (EventQueryResponseEvents) postCallTransform(
                    "eventstore_subscriber_event", rspMsg);
        } catch (Exception e) {
            String resultText = LOG_MESSAGES.FAILED_TO_QUERY_SUB_EVENTS;
            if (StringUtils.isNotBlank(e.getMessage())) {
                resultText = resultText + e.getMessage();
            }
            DEBUG(m_logger, resultText);
            rspMsg.setResult(RESULT_CODES.HTTP_INTERNAL_ERROR);
            rspMsg.setResultText(resultText);
        }
        return rspMsg;
    }

    public EventQueryResponseEvents queryEventListByEventIds(String loggingKey,
                                                             String route,
                                                             String eventIdCsv) {
        String methodKey = loggingKey + " queryEventListByEventIds: ";
        JsonObject ret = new JsonObject();
        EventQueryRequestEventId reqMsg = new EventQueryRequestEventId();
        EventQueryResponseEvents rspMsg = new EventQueryResponseEvents();
        try {

            buildFilter("eventstore_query_event_id");
            reqMsg = (EventQueryRequestEventId) preCallTransform(
                    "eventstore_query_event_id", reqMsg);
            DEBUG(m_logger, methodKey + "QuerySubscriberEventList Request: " + reqMsg.toJson());
            DEBUG(m_logger, methodKey + "eventIdCsv: " + reqMsg.toJson());
            eventstore_query_event_id(route, ret, eventIdCsv, reqMsg, rspMsg);
            rspMsg = (EventQueryResponseEvents) postCallTransform(
                    "eventstore_query_event_id", rspMsg);
            DEBUG(m_logger, methodKey + "QuerySubscriberEventList Response: " + rspMsg.toJson());
            rspMsg = (EventQueryResponseEvents) postCallTransform(
                    "eventstore_query_event_id", rspMsg);
        } catch (Exception e) {
            DEBUG(m_logger, "Failed to find events: " + e.getMessage());
            rspMsg.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            rspMsg.setResultText(e.getMessage());
        }
        return rspMsg;
    }

    public MtxResponsePaymentHistory querySubscriberPaymentHistoryByExternalId(String loggingKey,
                                                                               String route,
                                                                               String subscriptionExternalId) {
        MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
        searchData.setExternalId(subscriptionExternalId);
        return querySubscriberPaymentHistory(loggingKey, route, searchData);
    }

    /**
     * Query subscriber payment history in MATRIXX.
     *
     * @param loggingKey
     *            loggingKey
     * @param route
     *            route
     * @param searchData
     *            searchData
     * @return MtxResponseEventInfo
     */
    public MtxResponsePaymentHistory querySubscriberPaymentHistory(String loggingKey,
                                                                   String route,
                                                                   MtxSubscriberSearchData searchData) {

        String methodKey = loggingKey + " querySubscriberPaymentHistory: ";
        // Create a request to purchase offer
        DEBUG(m_logger, methodKey + "Creating subscriber payment history request");
        MtxRequestSubscriberQueryPaymentHistory reqMsg = new MtxRequestSubscriberQueryPaymentHistory();

        // Set the subscriber search key
        reqMsg.setSubscriberSearchData(searchData);

        // Send the request to MATRIXX and receive the response
        DEBUG(m_logger, methodKey + "Sending to MATRIXX\n" + reqMsg.toJson());
        MtxResponsePaymentHistory rspMsg = m_api.subscriberQueryPaymentHistory(route, reqMsg);
        DEBUG(m_logger, methodKey + "Received from MATRIXX\n" + rspMsg.toJson());

        return rspMsg;
    }

    /**
     * Query device data in MATRIXX.
     *
     * @param loggingKey
     *            loggingKey
     * @param route
     *            route
     * @param objectId
     *            objectId
     * @return MtxResponseDevice
     */
    public MtxResponseDevice queryDeviceData(String loggingKey,
                                             String route,
                                             MtxObjectId objectId) {
        // Create a request to purchase offer
        DEBUG(m_logger, loggingKey + "Creating device query request");
        MtxRequestDeviceQuery reqMsg = new MtxRequestDeviceQuery();

        // Set the device search key
        buildDeviceSearchByObjectId(reqMsg, objectId);

        // Send the request to MATRIXX and receive the response
        DEBUG(m_logger, loggingKey + "Sending to MATRIXX\n" + reqMsg.toJson());
        MtxResponseDevice rspMsg = m_api.deviceQuery(route, reqMsg);
        DEBUG(m_logger, loggingKey + "Received from MATRIXX\n" + rspMsg.toJson());

        return rspMsg;
    }

    /**
     * Query pricing offer in MATRIXX.
     *
     * @param loggingKey
     *            loggingKey
     * @param route
     *            route offerExternalId
     * @return MtxResponsePricingOffer
     */
    public MtxResponsePricingOffer queryPricingOffer(String loggingKey,
                                                     String route,
                                                     String ciExternalId) {
        MtxResponsePricingCatalogItem rspCatalog = queryPricingCatalogItem(
                loggingKey, route, ciExternalId);

        if (rspCatalog == null || rspCatalog.getCatalogItemInfo() == null) {
            return null;
        }

        // Create a request to query pricing offer
        DEBUG(m_logger, loggingKey + "Creating pricing offer query request");
        MtxRequestPricingQueryOffer reqMsg = new MtxRequestPricingQueryOffer();

        // Set the offer search data
        MtxPricingOfferSearchData searchData = new MtxPricingOfferSearchData();
        searchData.setExternalId(rspCatalog.getCatalogItemInfo().getTemplateExternalId());
        reqMsg.setOfferSearchData(searchData);

        // Send the request to MATRIXX and receive the response
        DEBUG(m_logger, loggingKey + "Sending to MATRIXX\n" + reqMsg.toJson());
        MtxResponsePricingOffer rspMsg = m_api.pricingQueryOffer(route, reqMsg);

        DEBUG(m_logger, loggingKey + "Received from MATRIXX\n" + rspMsg.toJson());

        return rspMsg;
    }

    public MtxResponsePricingOffer queryPricingProductOffer(String loggingKey,
                                                            String route,
                                                            BigInteger productOfferId) {
        // Create a request to query pricing offer
        DEBUG(m_logger, loggingKey + "Creating pricing offer query request");
        MtxRequestPricingQueryOffer reqMsg = new MtxRequestPricingQueryOffer();

        // Set the offer search data
        MtxPricingOfferSearchData searchData = new MtxPricingOfferSearchData();
        searchData.setOfferId(productOfferId);
        reqMsg.setOfferSearchData(searchData);

        // Send the request to MATRIXX and receive the response
        DEBUG(m_logger, loggingKey + "Sending to MATRIXX\n" + reqMsg.toJson());
        MtxResponsePricingOffer rspMsg = m_api.pricingQueryOffer(route, reqMsg);

        DEBUG(m_logger, loggingKey + "Received from MATRIXX\n" + rspMsg.toJson());

        return rspMsg;
    }

    /**
     * Query pricing catalog item in MATRIXX.
     *
     * @param loggingKey
     *            loggingKey
     * @param route
     *            route
     * @return MtxResponsePricingCatalogItem
     */
    public MtxResponsePricingCatalogItem queryPricingCatalogItem(String loggingKey,
                                                                 String route,
                                                                 String catalogItemExternalID) {
        MtxResponsePricingCatalogItem pricingCI = ciMap.get(catalogItemExternalID);
        if (pricingCI != null && pricingCI.getCatalogItemInfo() != null
                && catalogItemExternalID.equalsIgnoreCase(
                        pricingCI.getCatalogItemInfo().getExternalId())) {
            DEBUG(
                    m_logger,
                    loggingKey + "Returned from prior query to MATRIXX\n" + pricingCI.toJson());
            return pricingCI;
        }

        // Create a request to query pricing offer
        DEBUG(m_logger, loggingKey + "Creating pricing catalog item query request");
        MtxRequestPricingQueryCatalogItem reqMsg = new MtxRequestPricingQueryCatalogItem();

        // Set the offer search data
        MtxPricingCatalogItemSearchData searchData = new MtxPricingCatalogItemSearchData();
        searchData.setExternalId(catalogItemExternalID);
        reqMsg.setCatalogItemSearchData(searchData);

        // Send the request to MATRIXX and receive the response
        DEBUG(m_logger, loggingKey + StringUtils.SPACE + "Sending to MATRIXX\n" + reqMsg.toJson());
        MtxResponsePricingCatalogItem rspMsg = m_api.pricingQueryCatalogItem(route, reqMsg);
        if (rspMsg == null) {
            DEBUG(m_logger, loggingKey + "Received from MATRIXX\n" + rspMsg);
        } else {
            DEBUG(m_logger, loggingKey + "Received from MATRIXX\n" + rspMsg.toJson());
        }
        ciMap.put(catalogItemExternalID, rspMsg);
        return rspMsg;
    }

    /**
     * Send a multi-request to MATRIXX.
     *
     * @param loggingKey
     * @param route
     * @param reqMsg
     * @return
     */
    public MtxResponseMulti multiRequest(String loggingKey, String route, MtxRequestMulti reqMsg) {
        // Send the request to MATRIXX and receive the response
        DEBUG(m_logger, loggingKey + "Sending to MATRIXX\n" + reqMsg.toJson());
        MtxResponseMulti rspMsg = m_api.multi(route, reqMsg);
        DEBUG(m_logger, loggingKey + "Received from MATRIXX\n" + rspMsg.toJson());

        return rspMsg;
    }

    public MtxResponseMulti multiRequest(String loggingKey, MtxRequestMulti reqMsg) {
        // Send the request to MATRIXX and receive the response
        DEBUG(m_logger, loggingKey + "Sending to MATRIXX\n" + reqMsg.toJson());
        MtxResponseMulti rspMsg = m_api.multi(reqMsg);
        DEBUG(m_logger, loggingKey + "Received from MATRIXX\n" + rspMsg.toJson());

        return rspMsg;
    }

    /**
     * Obtain a subscriber recharge request. Can be moved to utility class.
     *
     * @param searchData
     * @param amount
     * @return
     */
    @Deprecated
    @Generated
    // Used By Device Swap Apis
    public MtxRequestSubscriberRecharge getSubscriberRechargeRequest(MtxSubscriberSearchData searchData,
                                                                     MtxChargeMethodData chargeMethodData,
                                                                     String reason,
                                                                     String info,
                                                                     BigDecimal amount,
                                                                     String orderId) {
        return CommonUtils.getSubscriberRechargeRequest(
                searchData, chargeMethodData, reason, info, amount, orderId);
    }

    /**
     * Obtain a subscriber recharge request. Can be moved to utility class.
     *
     * @param searchData
     * @param chargeMethodData
     * @param reason
     * @param info
     * @param amount
     * @param payNow
     * @param orderId
     * @return
     */
    // Used By Device Swap Apis
    public MtxRequestSubscriberRecharge getSubscriberRechargeRequest(MtxSubscriberSearchData searchData,
                                                                     MtxChargeMethodData chargeMethodData,
                                                                     String reason,
                                                                     String info,
                                                                     BigDecimal amount,
                                                                     Boolean payNow,
                                                                     String orderId) {
        MtxRequestSubscriberRecharge subRecharge = new MtxRequestSubscriberRecharge();
        subRecharge.setSubscriberSearchData(searchData);
        if (StringUtils.isNotBlank(orderId)) {
            VisibleRechargeExtension visRechargeExtn = new VisibleRechargeExtension();
            visRechargeExtn.setOrderId(orderId);
            subRecharge.setRechargeAttr(visRechargeExtn);
        }
        subRecharge.setAmount(amount);
        subRecharge.setReason(reason);
        subRecharge.setInfo(info);
        subRecharge.setChargeMethodData(chargeMethodData);
        subRecharge.setPayNow(payNow);

        return subRecharge;
    }

    /**
     * Obtain a subscriber refund request. Can be moved to utility class.
     *
     * @param searchData
     * @param amount
     * @param reason
     * @param info
     * @return
     */
    // Used By Device Swap Apis
    public MtxRequestSubscriberRefundPayment getSubscriberRefundRequest(MtxSubscriberSearchData searchData,
                                                                        Long paymentMethodResourceId,
                                                                        BigDecimal amount,
                                                                        String reason,
                                                                        String info) {
        MtxRequestSubscriberRefundPayment subRefund = new MtxRequestSubscriberRefundPayment();
        subRefund.setSubscriberSearchData(searchData);
        subRefund.setResourceId(paymentMethodResourceId);
        subRefund.setAmount(amount);
        subRefund.setReason(reason);
        if (info != null) {
            subRefund.setInfo(info);
        }
        return subRefund;
    }

    /**
     * Obtain a subscriber modify request. Can be moved to utility class.
     *
     * @param searchData
     * @param glCentre
     * @return
     */
    // Used by Device and Device Swap Apis
    public MtxRequestSubscriberModify getSubscriberModifyRequest(MtxSubscriberSearchData searchData,
                                                                 String glCentre) {

        MtxRequestSubscriberModify subModify = new MtxRequestSubscriberModify();
        subModify.setSubscriberSearchData(searchData);
        subModify.setGlCenter(glCentre);
        return subModify;
    }

    /**
     * Obtain a device create request. Can be moved to utility class.
     *
     * @param accessNumber
     * @param imsi
     * @return
     */
    // Used by Device Apis
    public MtxRequestDeviceCreate getDeviceCreateRequest(String accessNumber, String imsi) {
        MtxRequestDeviceCreate createDevice = new MtxRequestDeviceCreate();
        VisibleDeviceExtension deviceExtn = new VisibleDeviceExtension();
        deviceExtn.appendAccessNumberArray(new MtxPhone(accessNumber));
        deviceExtn.setImsi(new MtxPhone(imsi));
        createDevice.setAttr(deviceExtn);
        return createDevice;
    }

    /**
     * Obtain a device modify request. Can be moved to utility class.
     *
     * @param mtxObjectId
     * @return
     */
    // Used by Device Apis
    public MtxRequestDeviceModify getDeviceModifyRequest(MtxObjectId mtxObjectId, Integer status) {
        MtxRequestDeviceModify modifyDevice = new MtxRequestDeviceModify();
        MtxDeviceSearchData searchData = new MtxDeviceSearchData();
        searchData.setObjectId(mtxObjectId);
        modifyDevice.setDeviceSearchData(searchData);
        modifyDevice.setStatus(status);
        return modifyDevice;
    }

    /**
     * Obtain a device delete request. Can be moved to utility class.
     *
     * @param mtxObjectId
     * @return
     */
    // Used by Device Apis
    public MtxRequestDeviceDelete getDeviceDeleteRequest(MtxObjectId mtxObjectId) {
        MtxRequestDeviceDelete deleteDevice = new MtxRequestDeviceDelete();
        MtxDeviceSearchData searchData = new MtxDeviceSearchData();
        searchData.setObjectId(mtxObjectId);
        deleteDevice.setDeviceSearchData(searchData);
        deleteDevice.setDeleteSession(true);
        return deleteDevice;
    }

    /**
     * Obtain a device delete session request. Can be moved to utility class.
     *
     * @param mtxObjectId
     * @return
     */
    // Used by Device Apis
    public MtxRequestDeviceDeleteSession getDeviceDeleteSessionRequest(MtxObjectId mtxObjectId) {
        MtxRequestDeviceDeleteSession deleteDeviceSession = new MtxRequestDeviceDeleteSession();
        MtxDeviceSearchData searchData = new MtxDeviceSearchData();
        searchData.setObjectId(mtxObjectId);
        deleteDeviceSession.setDeviceSearchData(searchData);
        return deleteDeviceSession;
    }

    /**
     * Obtain a subscriber add device request. Can be moved to utility class.
     *
     * @param searchData
     * @param multiRequestIndexDeviceCreate
     * @return
     */
    // Used by Device Apis
    public MtxRequestSubscriberAddDevice getSubscriberAddDeviceRequest(MtxSubscriberSearchData searchData,
                                                                       int multiRequestIndexDeviceCreate) {
        MtxRequestSubscriberAddDevice subAddDevice = new MtxRequestSubscriberAddDevice();
        subAddDevice.setSubscriberSearchData(searchData);
        MtxDeviceSearchData deviceSearchData = new MtxDeviceSearchData();
        deviceSearchData.setMultiRequestIndex(multiRequestIndexDeviceCreate);
        subAddDevice.setDeviceSearchData(deviceSearchData);
        return subAddDevice;
    }

    /**
     * Obtain a subscriber remove device request. Can be moved to utility class.
     *
     * @param searchData
     * @param mtxObjectId
     * @return
     */
    // Used by Device Apis
    public MtxRequestSubscriberRemoveDevice getSubscriberRemoveDeviceRequest(MtxSubscriberSearchData searchData,
                                                                             MtxObjectId mtxObjectId) {
        MtxRequestSubscriberRemoveDevice subRemoveDevice = new MtxRequestSubscriberRemoveDevice();
        subRemoveDevice.setSubscriberSearchData(searchData);
        MtxDeviceSearchData deviceSearchData = new MtxDeviceSearchData();
        deviceSearchData.setObjectId(mtxObjectId);
        subRemoveDevice.setDeviceSearchData(deviceSearchData);
        return subRemoveDevice;
    }

    /**
     * Obtain a subscriber purchase offer request. Can be moved to utility class.
     *
     * @param offerExternalId
     * @param orderId
     * @param deviceSku
     * @param amount
     * @param taxDetails
     * @param deviceDetails
     * @param chargeId
     * @return
     */
    @Deprecated
    // Used by Device and swap Apis
    public MtxPurchasedOfferData getPurchasedOfferData(String offerExternalId,
                                                       String orderId,
                                                       String deviceSku,
                                                       BigDecimal amount,
                                                       String taxDetails,
                                                       String deviceDetails,
                                                       String chargeId) {
        return (new MtxPurchasedOfferDataBuilder()).withOfferExternalId(
                offerExternalId).withOrderId(orderId).withDeviceSku(deviceSku).withAmount(
                        amount).withTaxDetails(taxDetails).withDeviceDetails(
                                deviceDetails).withChargeId(chargeId).build();
    }

    /**
     * Obtain a subscriber purchase offer request. Can be moved to utility class.
     *
     * @param offerExternalId
     * @param orderId
     * @param deviceSku
     * @param amount
     * @param taxDetails
     * @param deviceDetails
     * @param chargeId
     * @param goodType
     * @param info
     * @return
     */
    // Used by Device and swap and manual pay Apis
    public MtxPurchasedOfferData getPurchasedOfferData(String offerExternalId,
                                                       String orderId,
                                                       String deviceSku,
                                                       BigDecimal amount,
                                                       String taxDetails,
                                                       String deviceDetails,
                                                       String chargeId,
                                                       String goodType,
                                                       String info) {
        return (new MtxPurchasedOfferDataBuilder()).withOfferExternalId(
                offerExternalId).withOrderId(orderId).withDeviceSku(deviceSku).withAmount(
                        amount).withTaxDetails(taxDetails).withDeviceDetails(
                                deviceDetails).withChargeId(chargeId).withGoodType(
                                        goodType).withInfo(info).build();
    }

    /**
     * Obtain a subscriber purchase offer request. Can be moved to utility class.
     *
     * @param searchData
     * @param offerDataList
     * @return
     */
    // Used by Device, swap, purchaseService and manual pay Apis
    public MtxRequestSubscriberPurchaseOffer getSubscriberPurchaseOfferRequest(MtxSubscriberSearchData searchData,
                                                                               MtxPurchasedOfferData... offerDataList) {
        return CommonUtils.getSubscriberPurchaseOfferRequest(searchData, offerDataList);
    }

    // Used by Device and swap Apis
    public MtxRequestSubscriberPurchaseOffer getSubscriberPurchaseOfferRequest(MtxSubscriberSearchData searchData,
                                                                               MtxChargeMethodData chargeMethodData,
                                                                               MtxPurchasedOfferData... offerDataList) {
        MtxRequestSubscriberPurchaseOffer subPurchaseOffer = new MtxRequestSubscriberPurchaseOffer();
        subPurchaseOffer.setSubscriberSearchData(searchData);
        subPurchaseOffer.setChargeMethodData(chargeMethodData);
        for (MtxPurchasedOfferData offerData : offerDataList) {
            subPurchaseOffer.appendOfferRequestArray(offerData);
        }
        return subPurchaseOffer;
    }

    /**
     * Obtain a subscriber adjust balance request. Can be moved to utility class.
     *
     * @param searchData
     * @param balanceResourceId
     * @param amount
     * @param reason
     * @return MtxRequestSubscriberAdjustBalance
     */
    // Used by Device and swap Apis
    @Deprecated(since = "108.4", forRemoval = true)
    public MtxRequestSubscriberAdjustBalance getSubscriberAdjustBalanceRequest(MtxSubscriberSearchData searchData,
                                                                               Long balanceResourceId,
                                                                               BigDecimal amount,
                                                                               String reason) {
        final int ADJUSTMENT_TYPE_CREDIT = 1;
        final int ADJUSTMENT_TYPE_DEBIT = 2;

        MtxRequestSubscriberAdjustBalance subAdjustBalance = new MtxRequestSubscriberAdjustBalance();
        subAdjustBalance.setSubscriberSearchData(searchData);
        subAdjustBalance.setBalanceResourceId(balanceResourceId);
        subAdjustBalance.setAmount(amount.abs());
        subAdjustBalance.setAdjustType(
                amount.signum() >= 0 ? ADJUSTMENT_TYPE_CREDIT : ADJUSTMENT_TYPE_DEBIT);
        subAdjustBalance.setReason(reason);
        return subAdjustBalance;
    }

    /**
     * Check whether an offer can be refunded.
     *
     * @return
     * @throws DeviceServiceException
     */
    public boolean isRefundableOffer(String loggingKey, String route, String externalId)
            throws DeviceServiceException {
        final String ATTR_NAME_REFUNDABLE = "Refundable";
        final String ATTR_VALUE_REFUNDABLE = "isRefundable";

        DEBUG(m_logger, loggingKey + "Querying MATRIXX pricing cache");
        MtxResponsePricingOffer pricingOffer = queryPricingOffer(loggingKey, route, externalId);
        if (pricingOffer == null
                || pricingOffer.getResult() != RESULT_CODES.MTX_SUCCESS) {
            Long resultCode = pricingOffer != null
                    ? pricingOffer.getResult() : RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR;
            String message = "Failed to query pricing offer for external ID " + externalId
                    + (pricingOffer != null ? " - " + pricingOffer.getResultText() : "");
            throw new DeviceServiceException(resultCode, message);
        }

        if (pricingOffer.getOfferInfo() != null) {
            MtxPricingOfferDetailInfo offerInfo = pricingOffer.getOfferInfo();
            if (offerInfo.getAttrList() != null
                    && !pricingOffer.getOfferInfo().getAttrList().isEmpty()) {
                for (MtxPricingAttrInfo attrInfo : pricingOffer.getOfferInfo().getAttrList()) {
                    if (attrInfo.getName().equalsIgnoreCase(ATTR_NAME_REFUNDABLE)) {
                        return attrInfo.getValue().equalsIgnoreCase(ATTR_VALUE_REFUNDABLE);
                    }
                }
            }
        }

        WARN(m_logger, loggingKey + "Failed to determine refundability of offer: " + externalId);

        return false;
    }

    /**
     * Retrieves the offer from the Matrixx.
     *
     * @param loggingKey
     * @param route
     * @param offerExternalId
     * @return the offer attributes if found.
     * @throws IntegrationServiceException
     *             if offer or dependent data were not found.
     */
    public Map<String, String> getOfferAttributes(String loggingKey,
                                                  String route,
                                                  String offerExternalId)
            throws IntegrationServiceException {
        Map<String, String> retMap = new HashMap<String, String>();
        DEBUG(m_logger, loggingKey + "Querying MATRIXX pricing cache for " + offerExternalId);
        MtxResponsePricingOffer pricingOffer = queryPricingOffer(
                loggingKey, route, offerExternalId);
        if (pricingOffer == null
                || pricingOffer.getResult() != RESULT_CODES.MTX_SUCCESS) {
            Long resultCode = pricingOffer != null
                    ? pricingOffer.getResult() : RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR;
            String message = "Failed to query pricing offer for " + offerExternalId
                    + (pricingOffer != null ? " - " + pricingOffer.getResultText() : "");
            throw new IntegrationServiceException(resultCode, message);
        }

        if (pricingOffer.getOfferInfo() != null) {
            for (MtxPricingAttrInfo attrInfo : CommonUtils.emptyIfNull(
                    pricingOffer.getOfferInfo().getAttrList())) {
                retMap.put(attrInfo.getName(), attrInfo.getValue());
            }
        } else if (pricingOffer.getBundleInfo() != null) {
            for (MtxBundleOfferInfo boi : CommonUtils.emptyIfNull(
                    pricingOffer.getBundleInfo().getOfferInfoList())) {

                DEBUG(
                        m_logger,
                        loggingKey + "Querying MATRIXX pricing cache for Product Offer Id: "
                                + boi.getProductOfferId());
                MtxResponsePricingOffer pricingProductOffer = queryPricingProductOffer(
                        loggingKey, route, boi.getProductOfferId());
                if (pricingProductOffer == null
                        || pricingProductOffer.getResult() != RESULT_CODES.MTX_SUCCESS) {
                    Long resultCode = pricingProductOffer != null
                            ? pricingProductOffer.getResult()
                            : RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR;
                    String message = "Failed to query pricing offer for product offer id "
                            + boi.getProductOfferId() + (pricingProductOffer != null
                                    ? " - " + pricingProductOffer.getResultText() : "");
                    throw new IntegrationServiceException(resultCode, message);
                }
                if (pricingProductOffer.getOfferInfo() != null) {
                    boolean isPrimaryOffer = false;
                    for (MtxPricingAttrInfo attrInfo : CommonUtils.emptyIfNull(
                            pricingProductOffer.getOfferInfo().getAttrList())) {
                        if (OFFER_CONSTANTS.OFFER_ATTR_PRIMARY_OFFER.equalsIgnoreCase(attrInfo.getName())
                                && OFFER_CONSTANTS.OFFER_ATTR_PRIMARY_OFFER_YES.equalsIgnoreCase( attrInfo.getValue())) {
                            isPrimaryOffer = true;
                            break;
                        }
                    }
                    if (isPrimaryOffer) {
                        for (MtxPricingAttrInfo attrInfo : CommonUtils.emptyIfNull(
                                pricingProductOffer.getOfferInfo().getAttrList())) {
                            retMap.put(attrInfo.getName(), attrInfo.getValue());
                        }
                    }
                }
            }
        } else {
            WARN(m_logger, loggingKey + "No offer info available for: " + offerExternalId);
        }

        return retMap;
    }

    // Can be moved to utility class.
    // Used by Device Apis
    public void addPaymentInfoToChargeMethodData(MtxChargeMethodData chargeMethodData,
                                                 String paymentMethod,
                                                 String paymentInfo,
                                                 String paymentGatewayId) {
        CommonUtils.addPaymentInfoToChargeMethodData(
                chargeMethodData, paymentMethod, paymentInfo, paymentGatewayId);
    }

    public Map<Long, BigDecimal> getRefundAmountFromCancelAOC(String loggingKey,
                                                              String route,
                                                              long offerResourceId,
                                                              long chargeCancelProrationType,
                                                              MtxSubscriberSearchData searchData)
            throws SubscriberServiceException {
        Map<Long, BigDecimal> refundMap = new HashMap<Long, BigDecimal>();
        DEBUG(m_logger, loggingKey + " Calling cancel offer AOC");
        MtxResponseCancel cancelofferRes = doSubscriberCancelOfferAOC(
                loggingKey, route, offerResourceId, chargeCancelProrationType, searchData);
        if (cancelofferRes == null
                || cancelofferRes.getResult() != RESULT_CODES.MTX_SUCCESS) {
            Long resultCode = cancelofferRes != null
                    ? cancelofferRes.getResult() : RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR;
            String message = LOG_MESSAGES.FAILED_TO_GET_CANCEL_AOC
                    + (cancelofferRes != null ? " - " + cancelofferRes.getResultText() : "");
            throw new SubscriberServiceException(resultCode, message);
        }

        for (MtxCancelInfo cancelInfoItem : CommonUtils.emptyIfNull(
                cancelofferRes.getCancelInfoArray())) {
            for (MtxBalanceImpactInfoGroup balanceImpGrpItem : CommonUtils.emptyIfNull(cancelInfoItem.getBalanceImpactGroupList())) {
                for (MtxBalanceImpactInfo balanceImpInfoItem : CommonUtils.emptyIfNull(balanceImpGrpItem.getBalanceImpactList())) {
                    if (balanceImpInfoItem.getImpactAmount() != null
                            && balanceImpInfoItem.getImpactAmount().signum() != 0) {
                        refundMap.put(
                                balanceImpInfoItem.getBalanceResourceId(),
                                balanceImpInfoItem.getImpactAmount());
                    }
                }
            }
        }

        return refundMap;
    }

    public MtxResponseCancel doSubscriberCancelOfferAOC(String loggingKey,
                                                        String route,
                                                        long offerResourceId,
                                                        long chargeCancelProrationType,
                                                        MtxSubscriberSearchData searchData) {
        // Create a request to cancel offer
        DEBUG(m_logger, loggingKey + "Creating AOC cancel offer request");
        MtxRequestSubscriberCancelOffer reqMsg = new MtxRequestSubscriberCancelOffer();

        MtxCancelOfferData cod = new MtxCancelOfferData();
        cod.setResourceId(offerResourceId);
        cod.setChargeCancelProrationType(chargeCancelProrationType);
        reqMsg.appendCancelDataArray(cod);

        reqMsg.setSubscriberSearchData(searchData);
        reqMsg.setExecuteMode(MATRIXX_CONSTANTS.ADVICE_MODE);
        // Send the request to MATRIXX and receive the response
        DEBUG(m_logger, loggingKey + "Sending to MATRIXX\n" + reqMsg.toJson());
        MtxResponseCancel rspMsg = m_api.subscriberCancelOffer(route, reqMsg);
        DEBUG(m_logger, loggingKey + "Received from MATRIXX\n" + rspMsg.toJson());

        return rspMsg;
    }

    /**
     * @param loggingKey
     * @param ciExternalId
     *            to keep method testable using junit. There is no other purpose
     * @param mpod
     * @param searchData
     * @return
     * @throws PaymentAdviceException
     */
    public BigDecimal getChargeableAmountForPurchaseOffer(String loggingKey,
                                                          String ciExternalId,
                                                          MtxPurchasedOfferData mpod,
                                                          MtxSubscriberSearchData searchData)
            throws PaymentAdviceException {
        final String methodName = "getChargeableAmountForPurchaseOffer: ";
        BigDecimal proratedChargeAmount = BigDecimal.ZERO;
        DEBUG(
                m_logger, loggingKey + StringUtils.SPACE + methodName + StringUtils.SPACE
                        + " Calling purchase offer AOC");

        MtxResponsePurchase purchaseOfferRes = doSubscriberPurchaseOfferAOC(
                loggingKey, ciExternalId, mpod, searchData);
        if (purchaseOfferRes == null || purchaseOfferRes.getResult() != RESULT_CODES.MTX_SUCCESS) {
            Long resultCode = purchaseOfferRes != null
                    ? purchaseOfferRes.getResult() : RESULT_CODES.HTTP_INTERNAL_ERROR;
            String message = LOG_MESSAGES.FAILED_TO_GET_PURCHASE_AOC
                    + (purchaseOfferRes != null ? " - " + purchaseOfferRes.getResultText() : "");
            throw new PaymentAdviceException(resultCode, message);
        }

        if (purchaseOfferRes.getPurchaseInfoArray() != null
                && !purchaseOfferRes.getPurchaseInfoArray().isEmpty()) {
            for (MtxPurchaseInfo purchaseInfoItem : purchaseOfferRes.getPurchaseInfoArray()) {
                proratedChargeAmount = proratedChargeAmount.add(
                        CommonUtils.getCurrencyAmount(
                                purchaseInfoItem.getBalanceImpactGroupList()));
            }
        }

        return proratedChargeAmount;
    }

    @SuppressWarnings("unchecked")
    public MtxResponsePurchase getAocCurrencyBalanceImpactInfo(String loggingKey,
                                                               String ciExternalId,
                                                               MtxPurchasedOfferData mpod,
                                                               String subscriptionExternalId)
            throws IntegrationServiceException {
        final String methodName = "getAocCurrencyBalanceImpactInfo: ";
        DEBUG(
                m_logger, loggingKey + StringUtils.SPACE + methodName + StringUtils.SPACE
                        + " Calling purchase offer Aoc");

        MtxRequestSubscriberPurchaseOffer reqMsg = new MtxRequestSubscriberPurchaseOffer();

        MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
        searchData.setExternalId(subscriptionExternalId);

        reqMsg.appendOfferRequestArray(mpod);
        reqMsg.setSubscriberSearchData(searchData);
        reqMsg.setExecuteMode(MATRIXX_CONSTANTS.ADVICE_MODE);
        // Send the request to MATRIXX and receive the response
        DEBUG(
                m_logger, loggingKey + StringUtils.SPACE + methodName + StringUtils.SPACE
                        + "Sending to MATRIXX\n" + reqMsg.toJson());

        MtxResponsePurchase purchaseOfferRes = m_api.subscriberPurchaseOffer(reqMsg);

        if (purchaseOfferRes == null
                || purchaseOfferRes.getResult() != RESULT_CODES.MTX_SUCCESS) {
            Long resultCode = purchaseOfferRes != null
                    ? purchaseOfferRes.getResult() : RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR;
            String message = LOG_MESSAGES.FAILED_TO_GET_PURCHASE_AOC
                    + (purchaseOfferRes != null ? " - " + purchaseOfferRes.getResultText() : "");
            throw new IntegrationServiceException(resultCode, message);
        }

        if (purchaseOfferRes.getPurchaseInfoArray() != null
                && !purchaseOfferRes.getPurchaseInfoArray().isEmpty()) {
            for (MtxPurchaseInfo purchaseInfoItem : purchaseOfferRes.getPurchaseInfoArray()) {
                purchaseInfoItem.getRequiredBalanceArrayAppender().clear();
                ArrayList<MtxBalanceImpactInfoGroup> tmpBigList = new ArrayList<MtxBalanceImpactInfoGroup>();
                if (purchaseInfoItem.getBalanceImpactGroupList() != null
                        && !purchaseInfoItem.getBalanceImpactGroupList().isEmpty()) {
                    for (MtxBalanceImpactInfoGroup balanceImpGrpItem : purchaseInfoItem.getBalanceImpactGroupList()) {
                        if (balanceImpGrpItem.getBalanceImpactList() != null
                                && !balanceImpGrpItem.getBalanceImpactList().isEmpty()) {
                            ArrayList<MtxBalanceImpactInfo> tmpBiiList = new ArrayList<MtxBalanceImpactInfo>();
                            for (MtxBalanceImpactInfo balanceImpInfoItem : balanceImpGrpItem.getBalanceImpactList()) {
                                if (balanceImpInfoItem.getBalanceClassId() != null
                                        && balanceImpInfoItem.getBalanceClassId().longValue() == BALANCE_CONSTANTS.BALANCE_CLASS_ID_USD) {
                                    tmpBiiList.add(balanceImpInfoItem);
                                }
                            }
                            balanceImpGrpItem.getBalanceImpactListAppender().clear();
                            balanceImpGrpItem.getBalanceImpactListAppender().addAll(tmpBiiList);
                            if (!tmpBiiList.isEmpty()) {
                                tmpBigList.add(balanceImpGrpItem);
                            }
                        }
                    }
                }
                purchaseInfoItem.getBalanceImpactGroupListAppender().clear();
                purchaseInfoItem.getBalanceImpactGroupListAppender().addAll(tmpBigList);
            }
        }
        DEBUG(
                m_logger, loggingKey + StringUtils.SPACE + methodName + StringUtils.SPACE
                        + "AOC Balance Impact of currency balances: " + purchaseOfferRes.toJson());
        return purchaseOfferRes;
    }

    public MtxResponsePurchase getAocResponsePurchase(String loggingKey,
                                                      String ciExternalId,
                                                      MtxPurchasedOfferData mpod,
                                                      String subscriptionExternalId) {
        MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
        searchData.setExternalId(subscriptionExternalId);
        return (doSubscriberPurchaseOfferAOC(loggingKey, ciExternalId, mpod, searchData));
    }

    /**
     * @param loggingKey
     * @param ciExternalId
     *            to keep method testable using junit. There is no other purpose
     * @param mpod
     * @param searchData
     * @return
     */
    public MtxResponsePurchase doSubscriberPurchaseOfferAOC(String loggingKey,
                                                            String ciExternalId,
                                                            MtxPurchasedOfferData mpod,
                                                            MtxSubscriberSearchData searchData) {
        // Create a request for aoc
        final String methodName = "doSubscriberPurchaseOfferAOC: ";
        DEBUG(
                m_logger, loggingKey + StringUtils.SPACE + methodName + StringUtils.SPACE
                        + "Creating AOC purchase offer request");
        MtxRequestSubscriberPurchaseOffer reqMsg = new MtxRequestSubscriberPurchaseOffer();

        reqMsg.appendOfferRequestArray(mpod);
        reqMsg.setSubscriberSearchData(searchData);
        reqMsg.setExecuteMode(MATRIXX_CONSTANTS.ADVICE_MODE);
        // Send the request to MATRIXX and receive the response
        DEBUG(
                m_logger, loggingKey + StringUtils.SPACE + methodName + StringUtils.SPACE
                        + "Sending to MATRIXX\n" + reqMsg.toJson());
        MtxResponsePurchase rspMsg = m_api.subscriberPurchaseOffer(reqMsg);
        DEBUG(
                m_logger, loggingKey + StringUtils.SPACE + methodName + StringUtils.SPACE
                        + "Received from MATRIXX\n" + rspMsg.toJson());

        return rspMsg;
    }

    /**
     * Call tax api and get tax string for purchase api calls
     *
     * @param subscriber
     * @param discountPrice
     * @param grossPrice
     * @param ciExternalId
     * @param goodType
     * @param loggingKey
     * @param route
     * @return
     * @throws TaxApiException
     * @throws DeviceServiceException
     * @throws IOException
     * @throws JsonMappingException
     * @throws JsonParseException
     */
    @Deprecated
    // Used by swap api
    public String getServiceTaxDetails(MtxResponseSubscription subscriber,
                                       BigDecimal discountPrice,
                                       BigDecimal grossPrice,
                                       BigDecimal offer606RevAdjDailyRecog,
                                       String ciExternalId,
                                       String goodType,
                                       String serviceType,
                                       String loggingKey,
                                       String route)
            throws IntegrationServiceException, TaxApiException, IOException {
        MtxResponsePricingCatalogItem pricingNewCIService = queryPricingCatalogItem(
                loggingKey, route, CHANGE_SERVICE_CONSTANTS.NIB_SERVICE_CI);
        MtxResponsePricingCatalogItem pricingNewCIInsurance = queryPricingCatalogItem(
                loggingKey, route, CI_METADATA.VISIBLE_INSURANCE);
        return TaxApiClient.getServiceTaxDetails(
                subscriber, pricingNewCIService, pricingNewCIInsurance, discountPrice, grossPrice,
                offer606RevAdjDailyRecog, ciExternalId, goodType, serviceType, loggingKey, route);
    }

    /**
     * Delete Payment method
     *
     * @param loggingKey
     * @param route
     * @param reqMsg
     * @return
     */
    public MtxResponse doSubscriberRemovePaymentMethod(String loggingKey,
                                                       String route,
                                                       MtxRequestSubscriberRemovePaymentMethod reqMsg) {
        // Send the request to MATRIXX and receive the response
        DEBUG(m_logger, loggingKey + "Sending to MATRIXX\n" + reqMsg.toJson());
        MtxResponse rspMsg = m_api.subscriberRemovePaymentMethod(route, reqMsg);
        DEBUG(m_logger, loggingKey + "Received from MATRIXX\n" + rspMsg.toJson());

        return rspMsg;
    }

    /**
     * Add payment method
     *
     * @param loggingKey
     * @param route
     * @param reqMsg
     * @return
     */
    public MtxResponseAdd doSubscriberAddPaymentMethod(String loggingKey,
                                                       String route,
                                                       MtxRequestSubscriberAddPaymentMethod reqMsg) {
        // Send the request to MATRIXX and receive the response
        DEBUG(m_logger, loggingKey + "Sending to MATRIXX\n" + reqMsg.toJson());
        MtxResponseAdd rspMsg = m_api.subscriberAddPaymentMethod(route, reqMsg);
        DEBUG(m_logger, loggingKey + "Received from MATRIXX\n" + rspMsg.toJson());

        return rspMsg;
    }

    /**
     * get Payment method details
     *
     * @param objectId
     * @param loggingKey
     * @param route
     * @return
     */
    public MtxResponsePaymentMethodInfo getPaymentMethodInfo(MtxObjectId objectId,
                                                             String loggingKey,
                                                             String route) {
        MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
        searchData.setObjectId(objectId);
        return queryPaymentMethodInfo(loggingKey, route, searchData);
    }

    public MtxResponsePaymentMethodInfo queryPaymentMethodInfo(String loggingKey,
                                                               String route,
                                                               String subscriptionExternalId) {
        MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
        searchData.setExternalId(subscriptionExternalId);
        return queryPaymentMethodInfo(loggingKey, route, searchData);
    }

    /**
     * get Payment method details
     *
     * @param objectId
     * @param loggingKey
     * @param route
     * @return
     */
    public MtxResponsePaymentMethodInfo queryPaymentMethodInfo(String loggingKey,
                                                               String route,
                                                               MtxSubscriberSearchData searchData) {
        MtxRequestSubscriberQueryPaymentMethod reqMsg = new MtxRequestSubscriberQueryPaymentMethod();
        reqMsg.setSubscriberSearchData(searchData);
        // Send the request to MATRIXX and receive the response
        DEBUG(m_logger, loggingKey + "Sending to MATRIXX\n" + reqMsg.toJson());
        MtxResponsePaymentMethodInfo rspMsg = m_api.subscriberQueryPaymentMethod(route, reqMsg);
        DEBUG(m_logger, loggingKey + "Received from MATRIXX\n" + rspMsg.toJson());

        return rspMsg;
    }

    /**
     * Modify payment method
     *
     * @param loggingKey
     * @param route
     * @return
     */
    public MtxResponse doSubscriberModifyPaymentMethod(String loggingKey,
                                                       String route,
                                                       MtxRequestSubscriberModifyPaymentMethod reqMsg) {
        DEBUG(m_logger, loggingKey + "Sending to MATRIXX\n" + reqMsg.toJson());
        MtxResponse rspMsg = m_api.subscriberModifyPaymentMethod(route, reqMsg);
        DEBUG(m_logger, loggingKey + "Received from MATRIXX\n" + rspMsg.toJson());
        return rspMsg;
    }

    /**
     * Extracts the risk data from recharge response's Braintree response if available. Otherwise
     * returns the default risk data (1). Can be moved to utility class.
     *
     * @param responseList
     * @param rechargeIndex
     * @return the risk data from Braintree response if available. Otherwise, default risk data (1).
     */
    // Used by device and manual pay apis
    public VisibleRiskData getRiskData(ArrayList<MtxResponse> responseList, int rechargeIndex) {
        return CommonUtils.getRiskData(responseList, rechargeIndex);
    }

    public MtxResponseRecurringChargeInfo getRecurringChargeEstimateFromExternalId(String loggingKey,
                                                                                   String subscriptionExternalId) {
        MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
        searchData.setExternalId(subscriptionExternalId);
        MtxRequestSubscriberEstimateRecurringCharge estimateRequest = new MtxRequestSubscriberEstimateRecurringCharge();
        estimateRequest.setSubscriberSearchData(searchData);
        DEBUG(
                m_logger,
                loggingKey
                        + "getRecurringChargeEstimateFromExternalId: Querying MATRIXX for Estimate on reccurring charges: "
                        + estimateRequest.toJson());
        return m_api.subscriberEstimateRecurringCharge(estimateRequest);
    }

    public MtxResponseOneTimeOffer querySubscriptionOneTimeOffer(String loggingKey,
                                                                 String subscriptionExternalId) {
        MtxRequestSubscriberQueryOneTimeOffer request = new MtxRequestSubscriberQueryOneTimeOffer();
        MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
        searchData.setExternalId(subscriptionExternalId);
        request.setSubscriberSearchData(searchData);
        DEBUG(
                m_logger,
                loggingKey
                        + "querySubscriptionOneTimeOffer: Querying MATRIXX for Subscribers onetime cancellable offers: "
                        + request.toJson());
        MtxResponseOneTimeOffer response = m_api.subscriberQueryOneTimeOffer(request);
        DEBUG(m_logger, loggingKey + "Received from MATRIXX\n" + response.toJson());
        return response;
    }

    public MtxResponse modifySubscription(String loggingKey,
                                          MtxRequestSubscriptionModify modifyReq) {
        final String methodName = "modifySubscription: ";
        DEBUG(
                m_logger, loggingKey + methodName + StringUtils.SPACE + "Sending to MATRIXX\n"
                        + modifyReq.toJson());
        MtxResponse response = m_api.subscriptionModify(modifyReq);
        DEBUG(
                m_logger, loggingKey + methodName + StringUtils.SPACE + "Received from MATRIXX\n"
                        + response.toJson());
        return response;
    }

    public MtxResponsePricingBillingCycle getPricingBillingCycle(String loggingKey,
                                                                 BigInteger billingCycleId) {
        final String methodKey = loggingKey + " MtxResponsePricingBillingCycle: ";
        MtxRequestPricingQueryBillingCycle request = new MtxRequestPricingQueryBillingCycle();
        MtxPricingBillingCycleSearchData searchData = new MtxPricingBillingCycleSearchData();
        searchData.setBillingCycleId(billingCycleId);
        request.setBillingCycleSearchData(searchData);
        DEBUG(m_logger, methodKey + "Sending to MATRIXX\n" + request.toJson());
        MtxResponsePricingBillingCycle response = m_api.pricingQueryBillingCycle(request);
        DEBUG(m_logger, methodKey + "Received from MATRIXX\n" + response.toJson());
        return response;
    }

    /**
     * Creates new client token,no need to pass any specific input
     *
     * @param route
     * @return
     */
    @Generated
    public MtxResponseClientToken createClientToken(String route) {
        return m_api.sysCreateClientToken(route, new MtxRequestSysCreateClientToken());
    }

    /**
     * Build log message prefix. Can be moved to utility class.
     *
     * @param subscriberExternalId
     * @return
     */
    public String getLoggingKey(String subscriberExternalId) {
        return "[Subscriber=" + (subscriberExternalId == null ? "" : subscriberExternalId) + "]: ";
    }

    public String getSubscriptionLoggingKey(String subscriptionExternalId) {
        return "[Subscription=" + (subscriptionExternalId == null ? "" : subscriptionExternalId)
                + "]: ";
    }

    /**
     * For unit testing.
     * 
     * @return
     */
    @Generated
    public SubscriberManagementApi getApi() {
        return m_api;
    }

}
