package com.matrixx.vag.common.request.builder;


import com.matrixx.datacontainer.mdc.*;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;

public class MtxRechargeExtensionBuilder  {

    String orderId;
    
    String ratePlan;
    BigDecimal planAmount;
    String serviceMDN;
    
    String wearableRatePlan;
    BigDecimal wearablePlanAmount;
    String wearableMDN;
    
    String purchaseServiceType;
    VisibleRechargeExtension existingExtension;

    public VisibleRechargeExtension build() {
    	boolean newAttr = true;
        VisibleRechargeExtension rechargeExtension = new VisibleRechargeExtension();

        if(existingExtension != null) {
            rechargeExtension = existingExtension;
            newAttr = false;
        }

        if (StringUtils.isNotBlank(this.orderId)) {
            rechargeExtension.setOrderId(this.orderId);
        }

        if (StringUtils.isNotBlank(this.ratePlan)) {
            rechargeExtension.setRatePlan(this.ratePlan);
        }

        if (StringUtils.isNotBlank(this.wearableRatePlan)) {
            rechargeExtension.setWearableRatePlan(this.wearableRatePlan);
        }
        
        if (planAmount!=null) {
            rechargeExtension.setPlanAmount(this.planAmount.toPlainString());
        }
        
        if (wearablePlanAmount!=null) {
            rechargeExtension.setWearablePlanAmount(this.wearablePlanAmount.toPlainString());
        }

        if (StringUtils.isNotBlank(this.serviceMDN)) {
        	rechargeExtension.setServiceMDN(serviceMDN);
        }

        if (StringUtils.isNotBlank(this.wearableMDN)) {
            rechargeExtension.setWearableMDN(wearableMDN);
        }

        if (StringUtils.isNotBlank(this.purchaseServiceType)) {
        	VisibleServiceDetails vsd = new VisibleServiceDetails();
        	vsd.setChangeServiceReason(purchaseServiceType);
        	rechargeExtension.getVisibleServiceInfoArrayAppender().add(vsd);	
        }
        
        return rechargeExtension;
    }

    public MtxRechargeExtensionBuilder withOrderId(String orderId) {
    	if(StringUtils.isNotBlank(orderId)) {
    		this.orderId = orderId;	
    	}    	
        return this;
    }

    public MtxRechargeExtensionBuilder withRatePlan(String ratePlan) {
    	if(StringUtils.isNotBlank(ratePlan)) {
    		this.ratePlan = ratePlan;	
    	}    	
        return this;
    }

    public MtxRechargeExtensionBuilder withWearableRatePlan(String wearableRatePlan) {
    	if(StringUtils.isNotBlank(wearableRatePlan)) {
    		this.wearableRatePlan = wearableRatePlan;	
    	}    	
        return this;
    }

    public MtxRechargeExtensionBuilder withServiceMDN(String serviceMDN) {
    	if(StringUtils.isNotBlank(serviceMDN)) {
    		this.serviceMDN = serviceMDN;	
    	}    	
        return this;
    }
    
    public MtxRechargeExtensionBuilder withWearableMDN(String wearableMDN) {
    	if(StringUtils.isNotBlank(wearableMDN)) {
    		this.wearableMDN = wearableMDN;	
    	}    	
        return this;
    }
    
    public MtxRechargeExtensionBuilder withPurchaseServiceType(String purchaseServiceType) {
    	if(StringUtils.isNotBlank(purchaseServiceType)) {
    		this.purchaseServiceType = purchaseServiceType;	
    	}    	
        return this;
    }
    
    public MtxRechargeExtensionBuilder withPlanAmount(BigDecimal planAmount) {
    	if(planAmount!=null) {
    		this.planAmount = planAmount;
    	}        
        return this;
    }

    public MtxRechargeExtensionBuilder withWearablePlanAmount(BigDecimal wearablePlanAmount) {
    	if(wearablePlanAmount!=null) {
    		this.wearablePlanAmount = wearablePlanAmount;
    	}        
        return this;
    }
    
    public MtxRechargeExtensionBuilder withRechargeExtData(VisibleRechargeExtension rechargeExtensionData) {
    	if(rechargeExtensionData!=null) {
    		this.existingExtension = rechargeExtensionData;
    	}        
        return this;
    }

}
