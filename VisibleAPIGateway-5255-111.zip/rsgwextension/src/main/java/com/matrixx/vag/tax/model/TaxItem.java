package com.matrixx.vag.tax.model;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL) // Ignore unused fields to reduce payload size.
public class TaxItem {

    private String taxItemType;
    private String tai;
    private String tat;
    private String taxCategory;
    private String taxType;
    private String description;
    @JsonSerialize(using = TaxBigDecimalSerializer.class)
    private BigDecimal rate;
    @JsonSerialize(using = TaxBigDecimalSerializer.class)
    private BigDecimal taxAmount;

    public String getTaxItemType() {
        return taxItemType;
    }

    public void setTaxItemType(String taxItemType) {
        this.taxItemType = taxItemType;
    }

    public String getTai() {
        return tai;
    }

    public void setTai(String tai) {
        this.tai = tai;
    }

    public String getTat() {
        return tat;
    }

    public void setTat(String tat) {
        this.tat = tat;
    }

    public String getTaxCategory() {
        return taxCategory;
    }

    public void setTaxCategory(String taxCategory) {
        this.taxCategory = taxCategory;
    }

    public String getTaxType() {
        return taxType;
    }

    public void setTaxType(String taxType) {
        this.taxType = taxType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public BigDecimal getRate() {
        return rate;
    }

    public void setRate(BigDecimal rate) {
        this.rate = rate;
    }

    public BigDecimal getTaxAmount() {
        return taxAmount;
    }

    public void setTaxAmount(BigDecimal taxAmount) {
        this.taxAmount = taxAmount;
    }
    
    @JsonIgnore
    public String getTaxItemKey() {
        return this.taxItemType+"-"+this.tai+"-"+this.tat+"-"+this.taxCategory+"-"+this.taxType+"-"+this.description;
    }

}
