package com.matrixx.vag.subscriber.service.model;

import java.math.BigDecimal;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.matrixx.datacontainer.mdc.MtxPaymentAuthorizationEvent;
import com.matrixx.datacontainer.mdc.MtxPaymentInfo;
import com.matrixx.datacontainer.mdc.MtxPaymentRefundInfo;
import com.matrixx.vag.common.CommonUtils;

public class RefundPaymentInfo {

    private MtxPaymentInfo mtxPaymentInfo;
    private MtxPaymentAuthorizationEvent payAuthEvent;
    private RefundEventInfo rei;
    private BigDecimal fundsBlocked = BigDecimal.ZERO;
    public RefundPaymentInfo(MtxPaymentInfo mtxPaymentInfo) {
        this.mtxPaymentInfo = mtxPaymentInfo;
        for (MtxPaymentRefundInfo rInfo : CommonUtils.emptyIfNull(mtxPaymentInfo.getRefundInfoList())) {
            this.fundsBlocked = this.fundsBlocked.add(rInfo.getRefundAmount());
        }
    }

    public MtxPaymentInfo getMtxPaymentInfo() {
        return mtxPaymentInfo;
    }

    public void setMtxPaymentInfo(MtxPaymentInfo mtxPaymentInfo) {
        this.mtxPaymentInfo = mtxPaymentInfo;
    }

    public MtxPaymentAuthorizationEvent getPayAuthEvent() {
        return payAuthEvent;
    }

    public void setPayAuthEvent(MtxPaymentAuthorizationEvent payAuthEvent) {
        this.payAuthEvent = payAuthEvent;
    }

    public boolean areFundsAvailable() {        
        return this.mtxPaymentInfo.getAuthorizationAmount().subtract(this.fundsBlocked).signum()>0;
    }

    public boolean areFundsNotAvailable() {        
        return !areFundsAvailable();
    }
    
    public RefundEventInfo getRei() {
        return rei;
    }

    public void setRei(RefundEventInfo rei) {
        this.rei = rei;
    }

    public void addToBlockedFunds(BigDecimal blockAmount) {
        this.fundsBlocked = this.fundsBlocked.add(blockAmount);
    }
    
    public String toJson() {
        ObjectMapper mapper = new ObjectMapper();
        try {
            return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(this);
        } catch (JsonProcessingException e) {
            return null;
        }
    }
}
