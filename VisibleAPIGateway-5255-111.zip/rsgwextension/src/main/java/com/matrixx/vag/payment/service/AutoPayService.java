package com.matrixx.vag.payment.service;

import static com.matrixx.platform.LogUtils.ENTER;
import static com.matrixx.platform.LogUtils.ERROR;
import static com.matrixx.platform.LogUtils.INFO;

import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.stream.Stream;

import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.matrixx.datacontainer.MtxDate;
import com.matrixx.datacontainer.MtxObjectId;
import com.matrixx.datacontainer.MtxTimestamp;
import com.matrixx.datacontainer.mdc.MtxPaymentMethodInfo;
import com.matrixx.datacontainer.mdc.MtxPricingRoleInfo;
import com.matrixx.datacontainer.mdc.MtxPurchasedOfferInfo;
import com.matrixx.datacontainer.mdc.MtxRelatedUserObject;
import com.matrixx.datacontainer.mdc.MtxRequestMulti;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberModifyOffer;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberPurchaseOffer;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberRecharge;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriptionModify;
import com.matrixx.datacontainer.mdc.MtxResponse;
import com.matrixx.datacontainer.mdc.MtxResponseMulti;
import com.matrixx.datacontainer.mdc.MtxResponsePaymentMethodInfo;
import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import com.matrixx.datacontainer.mdc.MtxResponseUser;
import com.matrixx.datacontainer.mdc.PromoAutoPay;
import com.matrixx.datacontainer.mdc.PurchasedOfferInfo;
import com.matrixx.datacontainer.mdc.ServiceAutoPay;
import com.matrixx.datacontainer.mdc.SubscriptionResponse;
import com.matrixx.datacontainer.mdc.VisibleCredits;
import com.matrixx.datacontainer.mdc.VisibleOfferDetails;
import com.matrixx.datacontainer.mdc.VisiblePurchasedOfferExtension;
import com.matrixx.datacontainer.mdc.VisibleRequestAutoPay;
import com.matrixx.datacontainer.mdc.VisibleRequestPaymentAdviceService;
import com.matrixx.datacontainer.mdc.VisibleResponseAutoPay;
import com.matrixx.datacontainer.mdc.VisibleResponsePaymentAdviceService;
import com.matrixx.datacontainer.mdc.VisibleSubscriberDevice;
import com.matrixx.datacontainer.mdc.VisibleSubscriberExtension;
import com.matrixx.datacontainer.mdc.VisibleTemplate;
import com.matrixx.platform.MatrixxContext;
import com.matrixx.vag.advice.service.PaymentAdviceService;
import com.matrixx.vag.amq.client.ActiveMQClient;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.Constants.AUTOPAY_CONSTANTS;
import com.matrixx.vag.common.Constants.AUTOPAY_MESSAGES;
import com.matrixx.vag.common.Constants.BRAINTREE_CONSTANTS;
import com.matrixx.vag.common.Constants.DEVICE_CONSTANTS;
import com.matrixx.vag.common.Constants.GENERIC_CONSTANTS;
import com.matrixx.vag.common.Constants.MATRIXX_CONSTANTS;
import com.matrixx.vag.common.Constants.NOTIFICATION_CONSTANTS;
import com.matrixx.vag.common.Constants.OFFER_CONSTANTS;
import com.matrixx.vag.common.Constants.PAYMENT_CONSTANTS;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.common.Constants.SUBSCRIPTION_CONSTANTS;
import com.matrixx.vag.common.coverage.Generated;
import com.matrixx.vag.common.request.builder.AutoPayNotificationBuilder;
import com.matrixx.vag.common.request.builder.MtxPurchasedOfferDataBuilder;
import com.matrixx.vag.common.request.builder.MtxRechargeExtensionBuilder;
import com.matrixx.vag.common.request.builder.MtxRequestSubscriberModifyOfferBuilder;
import com.matrixx.vag.common.request.builder.MtxRequestSubscriberPurchaseOfferBuilder;
import com.matrixx.vag.common.request.builder.MtxRequestSubscriberRechargeBuilder;
import com.matrixx.vag.common.request.builder.MtxRequestSubscriptionModifyBuilder;
import com.matrixx.vag.common.request.builder.VisibleBraintreeChargeMethodExtensionBuilder;
import com.matrixx.vag.common.request.builder.VisibleSubscriberExtensionBuilder;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.exception.IntegrationServiceException;
import com.matrixx.vag.service.IntegrationService;

@Configuration
public class AutoPayService extends IntegrationService {

    private static final Logger m_logger = LoggerFactory.getLogger(AutoPayService.class);
    private static final PropertiesConfiguration props = AppPropertyProvider.getInstance();

    RequestValidator requestValidator;

    @Autowired
    private PaymentAdviceService paymentAdviceService;

    public AutoPayService() {
        this.requestValidator = new RequestValidator();
    }

    @Generated()
    @Bean(name = "AutoPayService")
    AutoPayService getService() {
        return new AutoPayService();
    }

    @SuppressWarnings("static-access")
    public void autoPay(VisibleRequestAutoPay request, VisibleResponseAutoPay response)
            throws IntegrationServiceException, NoSuchMethodException, SecurityException,
            InstantiationException, IllegalAccessException, IllegalArgumentException,
            InvocationTargetException {
        String loggingKey = StringUtils.isNotBlank(request.getSubscriptionExternalId())
                ? getSubscriptionLoggingKey(request.getSubscriptionExternalId())
                : getSubscriptionLoggingKey(request.getSubscriptionObjectId());
        String route = getRoute(MatrixxContext.getRequest());
        requestValidator.validateRequest(loggingKey, request);
        final String methodKey = loggingKey + " autoPay: ";
        response.setResult(RESULT_CODES.MTX_SUCCESS);
        SubscriptionResponse subscription = null;

        // 1) get subscriber details
        if (StringUtils.isNoneBlank(request.getSubscriptionExternalId())) {
            response.setSubscriptionExternalId(request.getSubscriptionExternalId().trim());
            subscription = querySubscriptionByExternalId(
                    loggingKey, route, request.getSubscriptionExternalId());
        }
        if (StringUtils.isNoneBlank(request.getSubscriptionObjectId())) {
            response.setSubscriptionObjectId(request.getSubscriptionObjectId().trim());
            subscription = querySubscriptionByObjectId(
                    loggingKey, route, request.getSubscriptionObjectId());
        }

        VisibleSubscriberExtension subExtn;
        if (subscription.getAttr() != null) {
            subExtn = (VisibleSubscriberExtension) subscription.getAttr();
        } else {
            ERROR(m_logger, methodKey + AUTOPAY_MESSAGES.NO_SUBSCRIPTION_ATTR_ERROR_267);
            response.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            response.setResultText(AUTOPAY_MESSAGES.NO_SUBSCRIPTION_ATTR_ERROR_267);
            return;
        }

        // 2) if payment reference is not autopay then skip
        if (StringUtils.isNotBlank(subExtn.getPaymentPreference())
                && PAYMENT_CONSTANTS.AUTOPAY.equalsIgnoreCase(subExtn.getPaymentPreference())) {
            INFO(m_logger, methodKey + AUTOPAY_MESSAGES.PAYMENT_PREFERENCE_AUTOPAY_200);
            response.setResultText(AUTOPAY_MESSAGES.PAYMENT_PREFERENCE_AUTOPAY_200);
        } else if (StringUtils.isNotBlank(subExtn.getPaymentPreference())
                && PAYMENT_CONSTANTS.MANUALPAY.equalsIgnoreCase(subExtn.getPaymentPreference())) {
            INFO(m_logger, methodKey + AUTOPAY_MESSAGES.MANUAL_PAY_SUBSCRIPTION_269);
            response.setResult(RESULT_CODES.AUTOPAY_SKIP_SUB);
            response.setResultText(AUTOPAY_MESSAGES.MANUAL_PAY_SUBSCRIPTION_269);
            return;
        } else {
            ERROR(m_logger, methodKey + AUTOPAY_MESSAGES.NO_PAYMENT_PREFERENCE_268);
            response.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            response.setResultText(AUTOPAY_MESSAGES.NO_PAYMENT_PREFERENCE_268);
            return;
        }

        ZonedDateTime dateTimeNow = CommonUtils.getZonedDateTimeNow(subscription.getTimeZone());

        // 3) if billing cycle notpresent then skip
        if (subscription.getBillingCycle() == null
                || subscription.getBillingCycle().getCurrentPeriodEndTime() == null) {
            INFO(m_logger, methodKey + AUTOPAY_MESSAGES.SUBSCRIPTION_DATA_ERROR_280);
            response.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            response.setResultText(
                    response.getResultText() + " | "
                            + AUTOPAY_MESSAGES.SUBSCRIPTION_DATA_ERROR_280);
            return;
        }

        // 4) check to see if recharge is needed
        String rechDir = getRechargeDirections(loggingKey, route, subscription, dateTimeNow);

        ZonedDateTime endTime = CommonUtils.getZonedDateTimeFromMtxTimestamp(
                subscription.getBillingCycle().getCurrentPeriodEndTime(),
                subscription.getTimeZone());

        if (!AUTOPAY_MESSAGES.SUBSCRIPTION_NEEDS_RECHARGE_300.equalsIgnoreCase(rechDir)) {

            if (AUTOPAY_MESSAGES.STATUS_PAUSE_END_DATE_ILLEGAL_278.equalsIgnoreCase(rechDir)) {
                response.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            } else {
                response.setResult(RESULT_CODES.AUTOPAY_SKIP_SUB);
            }

            response.setResultText(response.getResultText() + " | " + rechDir);
            return;
        }

        // 4) get new order id
        String orderId = CommonUtils.getCurrentOrderId(subscription, null);
        String yymmddOrderId = CommonUtils.getNewOrderId(orderId);
        response.setOrderId(yymmddOrderId);

        INFO(m_logger, methodKey + "OrderId is : " + yymmddOrderId);

        // 6 get payment advice
        VisibleResponsePaymentAdviceService advice = getPaymentAdvice(loggingKey, subscription);
        if (RESULT_CODES.MTX_SUCCESS != advice.getResult()) {
            response.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            response.setResultText(
                    response.getResultText() + " | " + AUTOPAY_MESSAGES.PAYMENT_ADVICE_ERROR_301
                            + " | " + advice.getResultText());
            return;
        }

        // 6 get payment method name
        String pmnSearchExternalId = null;
        if (StringUtils.isNotBlank(advice.getPayerExternalId())) {
            pmnSearchExternalId = advice.getPayerExternalId();
        } else {
            pmnSearchExternalId = subscription.getExternalId();
        }
        MtxResponsePaymentMethodInfo paymentMethodInfoRes = queryPaymentMethodInfo(
                loggingKey, route, pmnSearchExternalId);
        if (paymentMethodInfoRes.getResult() != RESULT_CODES.MTX_SUCCESS) {
            ERROR(m_logger, methodKey + AUTOPAY_MESSAGES.READ_PAYMENT_METHODS_ERROR_264);
            response.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            response.setResultText(AUTOPAY_MESSAGES.READ_PAYMENT_METHODS_ERROR_264);
            return;
        } else if (StringUtils.isNotBlank(advice.getPayerExternalId())
                && CommonUtils.emptyOrNull(paymentMethodInfoRes.getPaymentMethodInfoList())) {
            ERROR(m_logger, methodKey + AUTOPAY_MESSAGES.PAYER_HAS_NO_PAYMENT_METHODS_ERROR_286);
            response.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            response.setResultText(AUTOPAY_MESSAGES.PAYER_HAS_NO_PAYMENT_METHODS_ERROR_286);
            return;
        } else if (CommonUtils.emptyOrNull(paymentMethodInfoRes.getPaymentMethodInfoList())) {
            ERROR(m_logger, methodKey + AUTOPAY_MESSAGES.NO_PAYMENT_METHODS_ERROR_265);
            response.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            response.setResultText(AUTOPAY_MESSAGES.NO_PAYMENT_METHODS_ERROR_265);
            return;
        }

        MtxPaymentMethodInfo pmi = CommonUtils.getCurrentPaymentMethodFromApiResponse(
                paymentMethodInfoRes);
        if (pmi == null) {
            ERROR(m_logger, methodKey + AUTOPAY_MESSAGES.NO_DEFAULT_PAYMENT_METHOD_ERROR_266);
            response.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            response.setResultText(AUTOPAY_MESSAGES.NO_DEFAULT_PAYMENT_METHOD_ERROR_266);
            return;
        }

        String payerPmn = null;
        String beneficiaryPmn = null;

        if (StringUtils.isNotBlank(advice.getPayerExternalId())) {
            payerPmn = pmi.getName();
        } else {
            beneficiaryPmn = pmi.getName();
        }

        MtxRequestMulti multiReq = new MtxRequestMulti();
        // 7 update multi request with info from payment advice
        updateMultiRequestWithPaymentAdvice(
                loggingKey, multiReq, yymmddOrderId, advice, subscription, response);

        // 8) add payment date
        updatePaymentDate(
                loggingKey, subscription.getExternalId(),
                subscription.getBillingCycle().getCurrentPeriodEndTime(), multiReq);

        MtxResponseMulti multiResp;
        if (StringUtils.isNotBlank(request.getTestRun())
                && GENERIC_CONSTANTS.YES.equalsIgnoreCase(request.getTestRun())) {
            INFO(m_logger, methodKey + AUTOPAY_MESSAGES.RECHARGE_SKIPPED_TESTRUN_234);
            INFO(m_logger, methodKey + "Test Run. NOT Sending to MATRIXX: " + multiReq.toJson());

            // 9.1) skip calling multirequest with all requests
            multiResp = new MtxResponseMulti();
            multiResp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
            multiResp.setResultText(MATRIXX_CONSTANTS.RESULT_TEXT_MTX_SUCCESS);

            INFO(
                    m_logger,
                    methodKey + "Test Run. Dummy Response Message. NOT Received to MATRIXX: "
                            + multiResp.toJson());
        } else {
            // 9.2) call multirequest with all requests
            multiResp = multiRequest(loggingKey, route, multiReq);
        }

        boolean multiError = false;
        if (multiResp == null) {
            response.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            ERROR(
                    m_logger,
                    methodKey + AUTOPAY_MESSAGES.RECHARGE_FAILED_233 + " - response is null");
            response.setResultText(
                    response.getResultText() + " | " + AUTOPAY_MESSAGES.RECHARGE_FAILED_233);
            multiError = true;
        } else if (multiResp.getResult() == null
                || !multiResp.getResult().equals(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS)) {
            response.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            String message = AUTOPAY_MESSAGES.RECHARGE_FAILED_233 + " - "
                    + response.getResultText();
            response.setResultText(
                    response.getResultText() + " | " + AUTOPAY_MESSAGES.RECHARGE_FAILED_233);
            ERROR(m_logger, loggingKey + message);
            multiError = true;
        } else {
            INFO(m_logger, methodKey + AUTOPAY_MESSAGES.RECHARGE_SUCCESSFUL_232);
            multiError = false;
        }

        // 10 get user
        MtxResponseUser user = queryUserBySubscriptionExternalId(
                loggingKey, subscription.getExternalId());
        String contactEmailId = user.getContactEmail();

        // @formatter:off
        AutoPayNotificationBuilder notifBuilder = (new AutoPayNotificationBuilder())
                .withObjectType(AppPropertyProvider.getInstance().getInt(NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_OBJECT_TYPE_VALUE))
                .withObjectId(subscription.getObjectId())
                .withObjectExternalId(subscription.getExternalId())
                .withPaymentMethodName(beneficiaryPmn)
                .withAmount(advice.getEstimatedPayableAmount())
                .withStatus(AppPropertyProvider.getInstance().getString(NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_STATUS_VALUE))
                .withNotifTime(dateTimeNow)
                .withPaymentPreference(subExtn.getPaymentPreference())
                .withContactEmail(contactEmailId)                
                .withBeforeCycleEnd(Math.abs(ChronoUnit.SECONDS.between(dateTimeNow,endTime) / 60))
                .withExpirationNotificationOffset(Math.abs(ChronoUnit.DAYS.between(dateTimeNow,endTime)))
                .withExpirationNotificationOffsetType(AUTOPAY_CONSTANTS.NOTIF_EXP_OFFSET_TYPE)
                .withExpirationTime(endTime)
                .withPayerExternalId(advice.getPayerExternalId())
                .withPayerPaymentMethodName(payerPmn);                
        // @formatter:on

        if (advice.getVisibleOfferDetailsList() != null
                && !advice.getVisibleOfferDetailsList().isEmpty()) {
            advice.getVisibleOfferDetailsList().forEach(vod -> {
                if (vod.getPayableAmount().signum() > 0) {
                    notifBuilder.withOffer(vod.getCatalogItemExternalId());
                }
            });
        }

        // 9) update retry
        if (multiError) {
            notifBuilder.withNotificationType(
                    AUTOPAY_CONSTANTS.FAILURE_NOTIF_TYPE).withContainerName(
                            AUTOPAY_CONSTANTS.FAILURE_NOTIF_CONTAINER);
            try {
                MtxResponse resp = updateRetryDate(
                        loggingKey, subscription.getExternalId(), dateTimeNow,
                        subscription.getBillingCycle().getCurrentPeriodEndTime());
                if (RESULT_CODES.MTX_SUCCESS != resp.getResult()) {
                    response.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
                    response.setResultText(
                            response.getResultText() + " | "
                                    + AUTOPAY_MESSAGES.PAYMENT_RETRY_UPDATE_ERROR_281);
                    ERROR(
                            m_logger, methodKey + AUTOPAY_MESSAGES.PAYMENT_RETRY_UPDATE_ERROR_281
                                    + StringUtils.LF + resp.getResultText());
                }
            } catch (Exception e) {
                response.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
                response.setResultText(
                        response.getResultText() + " | "
                                + AUTOPAY_MESSAGES.PAYMENT_RETRY_UPDATE_ERROR_281);
                ERROR(
                        m_logger, methodKey + AUTOPAY_MESSAGES.PAYMENT_RETRY_UPDATE_ERROR_281
                                + StringUtils.LF + ExceptionUtils.getStackTrace(e));
            }
        } else {
            // @formatter:off
            notifBuilder.withNotificationType(AUTOPAY_CONSTANTS.SUCCESS_NOTIF_TYPE)
                .withContainerName(AUTOPAY_CONSTANTS.SUCCESS_NOTIF_CONTAINER)
                .withCycleLength(subExtn.getCycleLength());
            // @formatter:on
        }

        // 10) send notification
        String msgBody = notifBuilder.build();
        if (StringUtils.isNotBlank(request.getTestRun())
                && GENERIC_CONSTANTS.YES.equalsIgnoreCase(request.getTestRun())) {
            INFO(
                    m_logger,
                    methodKey + "Test Run. NOT Sending message to ActiveMQClient: " + msgBody);
        } else {
            INFO(m_logger, methodKey + "Sending message to ActiveMQClient: " + msgBody);
            try {
                MtxResponse qResp = ActiveMQClient.sendAuopayMessage(
                        loggingKey, msgBody, yymmddOrderId);
                if (RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS != qResp.getResult()) {
                    if (multiError) {
                        response.setResult(RESULT_CODES.AUTOPAY_FAIL_NOTIF_FAIL);
                        response.setResultText(
                                response.getResultText() + " | "
                                        + AUTOPAY_MESSAGES.RECHARGE_ERROR_NOTIFICATION_ERROR_283);
                        ERROR(
                                m_logger,
                                methodKey + AUTOPAY_MESSAGES.RECHARGE_ERROR_NOTIFICATION_ERROR_283
                                        + StringUtils.LF + qResp.getResultText());
                    } else {
                        response.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
                        response.setResultText(
                                response.getResultText() + " | "
                                        + AUTOPAY_MESSAGES.RECHARGE_SUCESS_NOTIFICATION_ERROR_282);
                        ERROR(
                                m_logger,
                                methodKey + AUTOPAY_MESSAGES.RECHARGE_SUCESS_NOTIFICATION_ERROR_282
                                        + StringUtils.LF + qResp.getResultText());
                    }
                }
            } catch (Exception e) {
                if (multiError) {
                    response.setResult(RESULT_CODES.AUTOPAY_FAIL_NOTIF_FAIL);
                    response.setResultText(
                            response.getResultText() + " | "
                                    + AUTOPAY_MESSAGES.RECHARGE_ERROR_NOTIFICATION_ERROR_283);
                    ERROR(
                            m_logger,
                            methodKey + AUTOPAY_MESSAGES.RECHARGE_ERROR_NOTIFICATION_ERROR_283
                                    + StringUtils.LF + ExceptionUtils.getStackTrace(e));
                } else {
                    response.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
                    response.setResultText(
                            response.getResultText() + " | "
                                    + AUTOPAY_MESSAGES.RECHARGE_SUCESS_NOTIFICATION_ERROR_282);
                    ERROR(
                            m_logger,
                            methodKey + AUTOPAY_MESSAGES.RECHARGE_SUCESS_NOTIFICATION_ERROR_282
                                    + StringUtils.LF + ExceptionUtils.getStackTrace(e));
                }
            }
        }

        if (StringUtils.isBlank(response.getResultText())) {
            response.setResultText(
                    "OK - Subscription External Id: " + subscription.getExternalId());
        }
    }

    private MtxResponse updateRetryDate(String loggingKey,
                                        String subscriptionExternalId,
                                        ZonedDateTime dateTimeNow,
                                        MtxTimestamp tsWithOffset) {
        // dateTimeNow.
        MtxTimestamp mts = new MtxTimestamp(
                dateTimeNow.toInstant().toEpochMilli(), BigDecimal.ZERO, tsWithOffset.getOffset(),
                tsWithOffset.getOffsetSign());
        final String methodName = "updateRetryDate:";
        VisibleSubscriberExtensionBuilder attrBuilder = (new VisibleSubscriberExtensionBuilder()).withPaymentRetryDate(
                mts);
        MtxRequestSubscriptionModifyBuilder modifyBuilder = (new MtxRequestSubscriptionModifyBuilder()).withSubscriberExternalId(
                subscriptionExternalId).withAttr(attrBuilder.build());
        MtxRequestSubscriptionModify modifyReq = modifyBuilder.build();
        INFO(
                m_logger, loggingKey + methodName + "Create request to update payment retry: "
                        + modifyReq.toJson());
        return modifySubscription(loggingKey, modifyReq);
    }

    private void updatePaymentDate(String loggingKey,
                                   String subscriptionExternalId,
                                   MtxTimestamp paymentDate,
                                   MtxRequestMulti multiReq) {
        final String methodName = "updatePaymentDate:";
        VisibleSubscriberExtensionBuilder attrBuilder = (new VisibleSubscriberExtensionBuilder()).withPaymentDate(
                paymentDate);
        MtxRequestSubscriptionModifyBuilder modifyBuilder = (new MtxRequestSubscriptionModifyBuilder()).withSubscriberExternalId(
                subscriptionExternalId).withAttr(attrBuilder.build());
        MtxRequestSubscriptionModify modifyReq = modifyBuilder.build();
        INFO(
                m_logger,
                loggingKey + methodName + "Adding payment date update request to Multirequest: "
                        + modifyReq.toJson());
        CommonUtils.addRequestToMulti(multiReq, modifyReq);
    }

    private String getRechargeDirections(String loggingKey,
                                         String route,
                                         SubscriptionResponse subscription,
                                         ZonedDateTime dateTimeNow) {
        final String methodKey = loggingKey + " getRechargeDirections: ";

        ZonedDateTime endTime = CommonUtils.getZonedDateTimeFromMtxTimestamp(
                subscription.getBillingCycle().getCurrentPeriodEndTime(),
                subscription.getTimeZone());

        MtxTimestamp offrLevelEndTime = null;
        boolean useWalletBillCycle = false;
        int numOfRechargableOffer = 0;
        for (MtxPurchasedOfferInfo mpoi : CommonUtils.emptyIfNull(
                subscription.getPurchasedOfferArray())) {
            PurchasedOfferInfo poi = (PurchasedOfferInfo) mpoi;
            if (poi.getCatalogItemExternalId() == null || poi.getCatalogItemDetails() == null
                    || poi.getCatalogItemDetails().getTemplateAttr() == null
                    || !(poi.getCatalogItemDetails().getTemplateAttr() instanceof VisibleTemplate)) {
                continue;
            }

            VisibleTemplate vt = (VisibleTemplate) poi.getCatalogItemDetails().getTemplateAttr();

            if (StringUtils.isNotBlank(vt.getOfferType()) && Stream.of(
                    OFFER_CONSTANTS.OFFER_TYPE_BASE, OFFER_CONSTANTS.OFFER_TYPE_ADDON,
                    OFFER_CONSTANTS.OFFER_TYPE_INSURANCE).anyMatch(
                            otype -> (otype.equalsIgnoreCase(vt.getOfferType())))) {
                // Chargeable offers only. Skip setupservice, promo, gift etc
                numOfRechargableOffer++;
                if (poi.getCycleInfo() != null) {
                    // Annual plan that has cycle info. Not a preactive offer. Preactive
                    // offers need to be activated next month. Hence they can be treated
                    // like monthly plans here.
                    if (offrLevelEndTime == null
                            || offrLevelEndTime.longValue() > poi.getCycleInfo().getCycleEndTime().longValue()) {
                        offrLevelEndTime = poi.getCycleInfo().getCycleEndTime();
                        INFO(
                                m_logger, methodKey + "OffrLevelEndTime for "
                                        + poi.getCatalogItemExternalId() + ":" + offrLevelEndTime);
                    }
                } else {
                    // Either a monthly offer or a preactive annual offer. Use wallet bill
                    // cycle.
                    useWalletBillCycle = true;
                    break;
                }
            }
        }

        if (numOfRechargableOffer == 0) {
            INFO(m_logger, methodKey + AUTOPAY_MESSAGES.NO_OFFERS_TO_RECHARGE_285);
            return AUTOPAY_MESSAGES.NO_OFFERS_TO_RECHARGE_285;
        }
        if (!useWalletBillCycle && offrLevelEndTime != null) {
            // Ideally this scenario happens when user has only one plan and that is annual
            endTime = CommonUtils.getZonedDateTimeFromMtxTimestamp(
                    offrLevelEndTime, subscription.getTimeZone());
            INFO(
                    m_logger,
                    methodKey
                            + "Subscriber has only one chargeable service. PurchaseCycleEndTime is available and it will be used."
                            + endTime);
        }

        if (!SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE.equalsIgnoreCase(
                subscription.getStatusDescription())
                && !SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_PAUSE.equalsIgnoreCase(
                        subscription.getStatusDescription())) {
            INFO(m_logger, methodKey + AUTOPAY_MESSAGES.STATUS_NOT_ACTIVE_PAUSE_271);
            return AUTOPAY_MESSAGES.STATUS_NOT_ACTIVE_PAUSE_271;
        }

        if (endTime.isAfter(
                dateTimeNow.plusHours(props.getInt(AUTOPAY_CONSTANTS.PROP_DELTA_HOURS)))) {
            INFO(m_logger, methodKey + AUTOPAY_MESSAGES.RECHARGE_WINDOW_NOT_REACHED_273);
            INFO(
                    m_logger,
                    methodKey + "AUDIT RECORD: Subscriber is not due. " + endTime + "(nextcycle)"
                            + "-" + dateTimeNow + "(now) = "
                            + ChronoUnit.HOURS.between(dateTimeNow, endTime));
            INFO(
                    m_logger, methodKey + AUTOPAY_CONSTANTS.PROP_DELTA_HOURS + " = "
                            + props.getInt(AUTOPAY_CONSTANTS.PROP_DELTA_HOURS));
            INFO(
                    m_logger,
                    methodKey + "Billing Cycle End Time should be on or before: "
                            + dateTimeNow.plusHours(
                                    props.getInt(AUTOPAY_CONSTANTS.PROP_DELTA_HOURS)));
            return AUTOPAY_MESSAGES.RECHARGE_WINDOW_NOT_REACHED_273;
        }

        String terminationStatus = getSubscriptionTerminateStatus(
                loggingKey, subscription, endTime);
        if (!AUTOPAY_MESSAGES.STATUS_NOT_TERMINATED.equalsIgnoreCase(terminationStatus)) {
            INFO(m_logger, methodKey + terminationStatus);
            return terminationStatus;
        }

        VisibleSubscriberExtension subExtn = (VisibleSubscriberExtension) subscription.getAttr();

        if (subExtn.getPaymentDate() != null) {
            ZonedDateTime paymentDate = CommonUtils.getZonedDateTimeFromMtxTimestamp(
                    subExtn.getPaymentDate(), subscription.getTimeZone());
            if (endTime.truncatedTo(ChronoUnit.DAYS).equals(
                    paymentDate.truncatedTo(ChronoUnit.DAYS))) {
                if (!hasActivationInWindow(loggingKey, subscription, endTime)) {
                    INFO(m_logger, methodKey + AUTOPAY_MESSAGES.RECHARGE_ALREADY_DONE_274);
                    return AUTOPAY_MESSAGES.RECHARGE_ALREADY_DONE_274;
                } else {
                    INFO(
                            m_logger, methodKey
                                    + "'AUDIT RECORD: Subscription is not due but ActivationTime within recharge window'");
                }
            }
        }

        String prStatus = getSubscriptionPaymentRetryStatus(loggingKey, subscription, dateTimeNow);

        if (AUTOPAY_MESSAGES.IN_RETRY_PERIOD_275.equalsIgnoreCase(prStatus)) {
            return prStatus;
        }

        INFO(m_logger, methodKey + AUTOPAY_MESSAGES.SUBSCRIPTION_NEEDS_RECHARGE_300);
        return AUTOPAY_MESSAGES.SUBSCRIPTION_NEEDS_RECHARGE_300;
    }

    /**
     * @param loggingKey
     * @param multiReq
     * @param advice
     * @param subscription
     * @param response
     */
    @SuppressWarnings("unchecked")
    private void updateMultiRequestWithPaymentAdvice(String loggingKey,
                                                     MtxRequestMulti multiReq,
                                                     String orderId,
                                                     VisibleResponsePaymentAdviceService advice,
                                                     SubscriptionResponse subscription,
                                                     VisibleResponseAutoPay response) {
        final String methodKey = loggingKey + " updateMultiRequestWithPaymentAdvice: ";
        ENTER(m_logger, methodKey);

        addRechargeRequest(loggingKey, multiReq, orderId, advice, response);
        if (advice.getVisibleOfferDetailsList() == null
                || advice.getVisibleOfferDetailsList().isEmpty()) {
            return;
        }

        for (VisibleOfferDetails vod : advice.getVisibleOfferDetailsList()) {
            if (vod.getPayableAmount().signum() <= 0
                    && CommonUtils.emptyIfNull(advice.getCredits()).isEmpty()) {
                continue;
            }

            ServiceAutoPay service = new ServiceAutoPay();
            service.setCatalogItemExternalId(vod.getCatalogItemExternalId());
            // PaidCycleStartDate should not be updated if there no pending renewal. i.e. if no
            // payment is being done next month.
            // Otherwise this will cause issues in ChangeServiceAdvice. CSA will calculate
            // nextcycle when PaidCycleStartDate is
            // in future.
            //@formatter:off
            MtxRequestSubscriberModifyOfferBuilder modifyReqBuilder = (new MtxRequestSubscriberModifyOfferBuilder())
                    .withSubscriberExternalId(advice.getSubscriberExternalId())
                    .withResourceId(Long.parseLong(vod.getResourceId()))
                    .withPaidCycleStartDate(new MtxDate(subscription.getBillingCycle().getCurrentPeriodEndTime().longValue()))
                    .withTaxDetails(vod.getTaxDetails())
                    .withPurchaseServiceType(vod.getPurchaseServiceType())
                    .withOrderId(orderId);
            //@formatter:on
            for (VisibleCredits promo : CommonUtils.emptyIfNull(advice.getCredits())) {
                if (promo.getApplicableCI().trim().equalsIgnoreCase(
                        vod.getCatalogItemExternalId().trim())) {
                    PromoAutoPay promoResp = new PromoAutoPay();
                    promoResp.setPromotionName(promo.getPromotionName());
                    promoResp.setTransferedCredits(promo.getEstimatedTransferableCredits());
                    service.getPromoAutoPayListAppender().add(promoResp);

                    modifyReqBuilder.withCreditTaxDetails(promo.getTaxDetails());
                    if (promo.getEstimatedTransferableCredits() != null
                            && promo.getEstimatedTransferableCredits().signum() > 0) {
                        //@formatter:off
                        MtxPurchasedOfferDataBuilder promoBuilder = (new MtxPurchasedOfferDataBuilder())
                                .withOfferExternalId(promo.getCreditRedeemableOfferCI())
                                .withAmount(promo.getEstimatedTransferableCredits())
                                .withCoreBasePlanCI(promo.getApplicableCI())
                                .withGoodType(promo.getPromotionName());
                        MtxRequestSubscriberPurchaseOfferBuilder redeemBuilder = (new MtxRequestSubscriberPurchaseOfferBuilder())
                                .withSubscriberExternalId(advice.getSubscriberExternalId())
                                .withOfferData(promoBuilder.build());
                        //@formatter:on
                        MtxRequestSubscriberPurchaseOffer promoRedeem = redeemBuilder.build();
                        INFO(
                                m_logger,
                                methodKey + "Adding to multirequest, promotion purchase request: "
                                        + promoRedeem.toJson());
                        CommonUtils.addRequestToMulti(multiReq, promoRedeem);
                    }
                }
            }

            if (StringUtils.isNotBlank(vod.getOfferType())
                    && OFFER_CONSTANTS.OFFER_TYPE_BASE.equalsIgnoreCase(vod.getOfferType())) {
                if (advice.getSubscriberGroups() != null
                        && !advice.getSubscriberGroups().isEmpty()) {
                    modifyReqBuilder.withGroupName(advice.getAtSubscriberGroups(0).getGroupName());
                    modifyReqBuilder.withGroupTier(advice.getAtSubscriberGroups(0).getGroupTier());
                    modifyReqBuilder.withGroupMemberCount(
                            advice.getAtSubscriberGroups(0).getSubscriberMemberCount());
                }
            }
            response.getServiceAutoPayListAppender().add(service);

            MtxRequestSubscriberModifyOffer modifyReq = modifyReqBuilder.build();
            INFO(
                    m_logger,
                    methodKey + "Adding modify request to Multirequest: " + modifyReq.toJson());
            CommonUtils.addRequestToMulti(multiReq, modifyReq);

            if (StringUtils.isNotBlank(vod.getOfferType())
                    && OFFER_CONSTANTS.OFFER_TYPE_BASE.equalsIgnoreCase(vod.getOfferType())
                    && vod.getPayableAmount().signum() > 0) {
                MtxPurchasedOfferDataBuilder podBuilder = (new MtxPurchasedOfferDataBuilder()).withOfferExternalId(
                        AppPropertyProvider.getInstance().getString(
                                OFFER_CONSTANTS.OFFER_EXTERNAL_ID_VISIBLE_SERVICE_CHARGES)).withInfo(
                                        CommonUtils.getTimestampAsString(0)).withAmount(
                                                vod.getPayableAmount());
                MtxRequestSubscriberPurchaseOfferBuilder purchaseBuilder = (new MtxRequestSubscriberPurchaseOfferBuilder()).withSubscriberExternalId(
                        advice.getSubscriberExternalId()).withOfferData(podBuilder.build());
                MtxRequestSubscriberPurchaseOffer lifetimeTracker = purchaseBuilder.build();
                INFO(
                        m_logger,
                        methodKey + "Adding to multirequest, lifetime recharges to base offers: "
                                + lifetimeTracker.toJson());
                CommonUtils.addRequestToMulti(multiReq, lifetimeTracker);
            }
        }
    }

    private void addRechargeRequest(String loggingKey,
                                    MtxRequestMulti multiReq,
                                    String orderId,
                                    VisibleResponsePaymentAdviceService advice,
                                    VisibleResponseAutoPay response) {
        final String methodKey = loggingKey + " addRechargeRequest: ";
        ENTER(m_logger, methodKey);

        // if (advice.getEstimatedPayableAmount() == null) {
        // return;
        // }

        if (CommonUtils.zeroIfNull(advice.getEstimatedPayableAmount()).signum() <= 0
                && CommonUtils.zeroIfNull(advice.getConsumableMainBalanceAmount()).signum() > 0) {
            response.setRechargeAmount(BigDecimal.ZERO);
            INFO(m_logger, methodKey + AUTOPAY_MESSAGES.HAS_ENOUGH_BALANCE_FOR_RENEWAL_276);
            INFO(
                    m_logger,
                    "AUDIT RECORD: Subscription is due but has sufficient balance for renewal");
            return;
        }
        if (CommonUtils.zeroIfNull(advice.getEstimatedPayableAmount()).signum() <= 0
                && CommonUtils.zeroIfNull(advice.getConsumableMainBalanceAmount()).signum() <= 0) {
            response.setRechargeAmount(BigDecimal.ZERO);
            INFO(m_logger, methodKey + AUTOPAY_MESSAGES.NO_RECHARGE_REQUIRED_THIS_MONTH_284);
            INFO(
                    m_logger,
                    "AUDIT RECORD: Recharge not due. No service needs recharge for next cycle.");
            return;
        }

        // Create recharge request
        response.setRechargeAmount(advice.getEstimatedPayableAmount());

        String baseRatePlan = null;
        BigDecimal basePlanAmount = null;
        BigDecimal basePayableAmount = BigDecimal.ZERO;
        String baseMDN = null;
        String wearableMDN = null;
        String wearableRatePlan = null;
        String purchaseServiceType = null;
        BigDecimal wearablePlanAmount = null;
        BigDecimal wearablePayableAmount = BigDecimal.ZERO;

        for (VisibleOfferDetails vod : CommonUtils.emptyIfNull(
                advice.getVisibleOfferDetailsList())) {

            if (OFFER_CONSTANTS.OFFER_TYPE_BASE.equalsIgnoreCase(vod.getOfferType())) {
                baseRatePlan = vod.getCatalogItemExternalId();
                basePlanAmount = vod.getChargeAmount();
                basePayableAmount = vod.getPayableAmount();
                purchaseServiceType = vod.getPurchaseServiceType();
            } else if (OFFER_CONSTANTS.OFFER_TYPE_ADDON.equalsIgnoreCase(vod.getOfferType())) {
                wearableRatePlan = vod.getCatalogItemExternalId();
                wearablePlanAmount = vod.getChargeAmount();
                wearablePayableAmount = vod.getPayableAmount();
            }
        }

        for (VisibleSubscriberDevice device : CommonUtils.emptyIfNull(
                advice.getSubscriberDevices())) {
            if (DEVICE_CONSTANTS.DEVICE_TYPE_WEARABLE.equalsIgnoreCase(device.getDeviceType())
                    && StringUtils.isNotBlank(device.getAccessNumber())) {
                wearableMDN = device.getAccessNumber();
            } else {
                baseMDN = device.getAccessNumber();
            }
        }

        boolean hasBaseDevice = StringUtils.isNotBlank(baseMDN);
        boolean hasBaseOffer = StringUtils.isNotBlank(baseRatePlan);
        boolean needBaseRecharge = basePayableAmount.signum() > 0;
        boolean isBaseRechargeCycle = hasBaseDevice && hasBaseOffer && needBaseRecharge;

        boolean hasWearableDevice = StringUtils.isNotBlank(wearableMDN);
        boolean hasWearableOffer = StringUtils.isNotBlank(wearableRatePlan);
        boolean isStandaloneWearable = hasWearableDevice && hasWearableOffer
                && wearablePayableAmount.signum() > 0;
        boolean notStandaloneWearable = hasWearableDevice && hasWearableOffer
                && wearablePayableAmount.signum() <= 0;
        boolean isFreeWearable = notStandaloneWearable && needBaseRecharge;
        //@formatter:off                
        MtxRechargeExtensionBuilder rechAttrBuilder = (new MtxRechargeExtensionBuilder())
                .withOrderId(orderId);
        if (isBaseRechargeCycle){
            rechAttrBuilder.withRatePlan(baseRatePlan)                
                .withPurchaseServiceType(purchaseServiceType)
                .withServiceMDN(baseMDN);
            if (CommonUtils.zeroIfNull(basePlanAmount).signum()>0){
                rechAttrBuilder.withPlanAmount(basePlanAmount);
            }
        }

        if (isStandaloneWearable || isFreeWearable){
            rechAttrBuilder.withWearableRatePlan(wearableRatePlan)                
                .withWearableMDN(wearableMDN);
            if (CommonUtils.zeroIfNull(wearablePlanAmount).signum()>0){
                rechAttrBuilder.withWearablePlanAmount(wearablePlanAmount);
            }
        }
        VisibleBraintreeChargeMethodExtensionBuilder btBuilder = (new VisibleBraintreeChargeMethodExtensionBuilder())
                    .withOrderId(orderId)
                    .withTransactionType(AUTOPAY_CONSTANTS.TRANSACTION_TYPE)
                    .withRecurringOverride(BRAINTREE_CONSTANTS.BT_VISIBLE_RECURRING_OVERRIDE_FLAG);

        MtxRequestSubscriberRechargeBuilder rechBuilder = (new MtxRequestSubscriberRechargeBuilder())
                    .withSubscriberExternalId(advice.getSubscriberExternalId())
                    .withAmount(advice.getEstimatedPayableAmount())
                    .withPayNow(true)
                    .withReason(AUTOPAY_CONSTANTS.RECHARGE_REASON)
                    .withBTExtension(btBuilder.build())
                    .withAttr(rechAttrBuilder.build());
        // @formatter:on
        MtxRequestSubscriberRecharge rechReq = rechBuilder.build();
        INFO(m_logger, methodKey + "Adding recharge request to Multirequest: " + rechReq.toJson());
        CommonUtils.addRequestToMulti(multiReq, rechReq);

    }

    private VisibleResponsePaymentAdviceService getPaymentAdvice(String loggingKey,
                                                                 SubscriptionResponse subscriptionResponse) {
        final String methodName = "getPaymentAdvice:";
        VisibleRequestPaymentAdviceService req = new VisibleRequestPaymentAdviceService();
        VisibleResponsePaymentAdviceService resp = new VisibleResponsePaymentAdviceService();
        req.setIncludeTaxDetails(GENERIC_CONSTANTS.YES);
        req.setSubscriberExternalId(subscriptionResponse.getExternalId());
        try {
            paymentAdviceService.getAOPForAutopay(req, resp, subscriptionResponse);
            INFO(
                    m_logger, loggingKey + methodName + StringUtils.SPACE + "PaymentAdviceResponse:"
                            + StringUtils.SPACE + resp.toJson());
            if (RESULT_CODES.MTX_SUCCESS != resp.getResult()) {
                resp.setResultText(AUTOPAY_MESSAGES.PAYMENT_ADVICE_FAILED_279);
                ERROR(
                        m_logger,
                        loggingKey + methodName + StringUtils.SPACE
                                + "AUDIT RECORD ERROR: Payment advice service failed. Result Text:"
                                + StringUtils.SPACE + resp.getResultText());
            }
        } catch (Exception e) {
            resp.setResultText(AUTOPAY_MESSAGES.PAYMENT_ADVICE_FAILED_279);
            resp.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR);
            ERROR(
                    m_logger,
                    loggingKey + methodName + StringUtils.SPACE
                            + "AUDIT RECORD ERROR: PaymentAdvice Error:" + StringUtils.SPACE
                            + ExceptionUtils.getStackTrace(e));
        }
        return resp;
    }

    private boolean hasActivationInWindow(String loggingKey,
                                          MtxResponseSubscription subscription,
                                          ZonedDateTime endTime) {
        if (subscription.getPurchasedOfferArray() != null) {
            for (MtxPurchasedOfferInfo po : subscription.getPurchasedOfferArray()) {
                if (po.getActivationTime() != null) {
                    ZonedDateTime activationDate = CommonUtils.getZonedDateTimeFromMtxTimestamp(
                            po.getActivationTime(), subscription.getTimeZone());
                    if (endTime.isAfter(
                            activationDate.plusHours(
                                    props.getInt(AUTOPAY_CONSTANTS.PROP_DELTA_HOURS)))) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private String getSubscriptionPaymentRetryStatus(String loggingKey,
                                                     MtxResponseSubscription subscription,
                                                     ZonedDateTime dateTimeNow) {
        final String methodName = "getSubscriptionPaymentRetryStatus:";
        VisibleSubscriberExtension subExtn = (VisibleSubscriberExtension) subscription.getAttr();
        if (StringUtils.isNotBlank(subExtn.getPaymentRetry())) {
            ZonedDateTime retryDate;
            try {
                retryDate = CommonUtils.getZonedDateTimeFromString(
                        subExtn.getPaymentRetry(), subscription.getTimeZone() + "");
            } catch (Exception e) {
                ERROR(
                        m_logger,
                        loggingKey + methodName + StringUtils.SPACE + subExtn.getPaymentRetry()
                                + StringUtils.SPACE
                                + "is invalid payment retry date. Assuming subscription to be not in retry period.");
                ERROR(m_logger, ExceptionUtils.getStackTrace(e));
                return AUTOPAY_MESSAGES.STATUS_NOT_IN_RETRY;
            }

            if (dateTimeNow.isBefore(
                    retryDate.plusHours(props.getInt(AUTOPAY_CONSTANTS.PROP_RETRY_WAIT_HOURS)))) {
                INFO(
                        m_logger, loggingKey + methodName + StringUtils.SPACE
                                + AUTOPAY_MESSAGES.IN_RETRY_PERIOD_275);
                return AUTOPAY_MESSAGES.IN_RETRY_PERIOD_275;
            }
        }

        return AUTOPAY_MESSAGES.STATUS_NOT_IN_RETRY;
    }

    private String getSubscriptionTerminateStatus(String loggingKey,
                                                  MtxResponseSubscription subscription,
                                                  ZonedDateTime endTime) {
        final String methodName = "getSubscriptionTerminateStatus:";
        VisibleSubscriberExtension subExtn = (VisibleSubscriberExtension) subscription.getAttr();
        if (StringUtils.isNotBlank(subExtn.getTerminateDate())) {
            ZonedDateTime terminateDate;
            try {
                terminateDate = CommonUtils.getZonedDateTimeFromString(
                        subExtn.getTerminateDate(), subscription.getTimeZone() + "");
            } catch (Exception e) {
                ERROR(
                        m_logger,
                        loggingKey + methodName + StringUtils.SPACE + subExtn.getTerminateDate()
                                + StringUtils.SPACE
                                + "is invalid terminate date. Assuming subscription to be not terminated.");
                ERROR(m_logger, ExceptionUtils.getStackTrace(e));
                return AUTOPAY_MESSAGES.STATUS_NOT_TERMINATED;
            }

            if (endTime.isAfter(terminateDate)) {
                INFO(
                        m_logger, loggingKey + methodName + StringUtils.SPACE
                                + AUTOPAY_MESSAGES.TERMINATION_DATE_277);
                INFO(
                        m_logger,
                        loggingKey + methodName + StringUtils.SPACE
                                + "AUDIT RECORD: Subscriber is due. But " + terminateDate
                                + "(termination date)" + "<=" + endTime + "(nextcycle)");
                return AUTOPAY_MESSAGES.TERMINATION_DATE_277;
            }
        }
        return AUTOPAY_MESSAGES.STATUS_NOT_TERMINATED;
    }

}
