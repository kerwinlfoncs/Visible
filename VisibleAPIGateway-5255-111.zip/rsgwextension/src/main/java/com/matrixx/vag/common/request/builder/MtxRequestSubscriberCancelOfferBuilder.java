package com.matrixx.vag.common.request.builder;

import com.matrixx.datacontainer.mdc.MtxCancelOfferData;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberCancelOffer;
import com.matrixx.datacontainer.mdc.MtxSubscriberSearchData;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

/**
 * Defines property names and constants used by the API gateway.
 *
 * @author unico
 */
public class MtxRequestSubscriberCancelOfferBuilder {

    String subscriberExternalId;
    List<Long> resourceIdList = new ArrayList<Long>();
    Long chargeCancelProrationType;
    Long prorationCatalogItemResourceId;
    MtxSubscriberSearchData searchData;
    MtxCancelOfferData cancelOfferData;

    boolean needCancelOfferData = false;
    
    public MtxRequestSubscriberCancelOffer build() {

        if (searchData == null) {
            this.searchData = new MtxSubscriberSearchData();
        }

        if (StringUtils.isNotBlank(subscriberExternalId)
                && StringUtils.isBlank(searchData.getExternalId())) {
            this.searchData.setExternalId(subscriberExternalId);
        }

        MtxRequestSubscriberCancelOffer cancelOffer = new MtxRequestSubscriberCancelOffer();

        cancelOffer.setSubscriberSearchData(searchData);

        if (needCancelOfferData) {
            cancelOfferData = new MtxCancelOfferData();
            if (chargeCancelProrationType != null) {
                cancelOfferData.setChargeCancelProrationType(chargeCancelProrationType);
            }
            if (prorationCatalogItemResourceId != null) {
                cancelOfferData.setResourceId(prorationCatalogItemResourceId);
            }
            cancelOffer.appendCancelDataArray(cancelOfferData);
        }

        resourceIdList.forEach(id -> {
            cancelOffer.appendResourceIdArray(id);
        });
        
        return cancelOffer;
    }

    public MtxRequestSubscriberCancelOfferBuilder withSubscriberExternalId(String subscriberExternalId) {
        if (StringUtils.isNotBlank(subscriberExternalId)) {
            this.subscriberExternalId = subscriberExternalId;
        }
        return this;
    }

    public MtxRequestSubscriberCancelOfferBuilder withSearchData(MtxSubscriberSearchData searchData) {
        if (searchData != null) {
            this.searchData = searchData;
        }
        return this;
    }

    public MtxRequestSubscriberCancelOfferBuilder withCancelOfferData(MtxCancelOfferData cancelOfferData) {
        if (cancelOfferData != null) {
            this.cancelOfferData = cancelOfferData;
        }
        return this;
    }

    public MtxRequestSubscriberCancelOfferBuilder withResourceId(Long resourceId) {
        if (resourceId != null) {
            this.resourceIdList.add(resourceId);
        }
        return this;
    }

    public MtxRequestSubscriberCancelOfferBuilder withChargeCancelProrationType(Long chargeCancelProrationType) {
        if (chargeCancelProrationType != null) {
            this.chargeCancelProrationType = chargeCancelProrationType;
            needCancelOfferData = true;
        }
        return this;
    }
    
    public MtxRequestSubscriberCancelOfferBuilder withProrationCatalogItemResourceId(Long prorationCatalogItemResourceId) {
        if (prorationCatalogItemResourceId != null) {
            this.prorationCatalogItemResourceId = prorationCatalogItemResourceId;
            needCancelOfferData = true;
        }
        return this;
    }
}
