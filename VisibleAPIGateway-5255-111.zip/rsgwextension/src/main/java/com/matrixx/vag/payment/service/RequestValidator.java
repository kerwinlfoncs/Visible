package com.matrixx.vag.payment.service;

import static com.matrixx.platform.LogUtils.DEBUG;
import static com.matrixx.platform.LogUtils.ERROR;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.matrixx.datacontainer.mdc.ManualPayRequest;
import com.matrixx.datacontainer.mdc.MtxSubscriberSearchData;
import com.matrixx.datacontainer.mdc.VisibleApiEventData;
import com.matrixx.datacontainer.mdc.VisibleCreditsManualPay;
import com.matrixx.datacontainer.mdc.VisibleOfferDetails;
import com.matrixx.datacontainer.mdc.VisibleRechargeExtension;
import com.matrixx.datacontainer.mdc.VisibleRequestAutoPay;
import com.matrixx.datacontainer.mdc.VisibleRequestRecharge;
import com.matrixx.datacontainer.mdc.VisibleResponsePaymentAdviceService;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.exception.InvalidRequestException;
import com.matrixx.vag.exception.InvalidRequestParameterException;
import com.matrixx.vag.exception.ManualPayException;
import com.matrixx.vag.exception.MissingRequestParametersException;

public class RequestValidator {

    private static final Logger m_logger = LoggerFactory.getLogger(RequestValidator.class);

    public static void validateRequest(String loggingKey, ManualPayRequest request)
            throws InvalidRequestException {
        DEBUG(m_logger, loggingKey + "Validating manual pay  service request");
        StringBuilder missingMandatoryParamNames = new StringBuilder();

        if (StringUtils.isEmpty(request.getSubscriberSearchDataExternalId())) {
            missingMandatoryParamNames.append("SubscriberSearchDataExternalId, ");
        }

        if (request.getVisibleOfferDetailsList() != null
                && !request.getVisibleOfferDetailsList().isEmpty()) {
            for (int i = 0; i < request.getVisibleOfferDetailsList().size(); i++) {
                VisibleOfferDetails offer = request.getVisibleOfferDetailsList().get(i);
                String catalogItemExternalId = offer.getCatalogItemExternalId();
                if (StringUtils.isEmpty(catalogItemExternalId)) {
                    missingMandatoryParamNames.append("VisibleOfferDetailsList[").append(i).append(
                            "].CatalogItemExternalId, ");
                } else if (offer.getPayableAmount().signum() > 0
                        && StringUtils.isEmpty(offer.getTaxDetails())) {
                    missingMandatoryParamNames.append(
                            "VisibleOfferDetailsList[CatalogItemExternalId='").append(
                                    catalogItemExternalId).append("'].TaxDetails, ");
                } else {
                    if (StringUtils.isEmpty(offer.getResourceId())) {
                        missingMandatoryParamNames.append(
                                "VisibleOfferDetailsList[CatalogItemExternalId='").append(
                                        catalogItemExternalId).append("'].ResourceId, ");
                    } else {
                        try {
                            Long.valueOf(offer.getResourceId());
                        } catch (Exception ex) {
                            throw new InvalidRequestParameterException(
                                    "VisibleOfferDetailsList[CatalogItemExternalId='"
                                            + catalogItemExternalId
                                            + "'].ResourceId is not a number",
                                    ex);
                        }
                    }
                }
            }
        }

        boolean chargeAmountZeroOrMissing = (request.getPayNow() == null
                || !CommonUtils.checkIfNonZero(request.getPayNow().getChargeAmount()));

        if (!chargeAmountZeroOrMissing) {
            if (StringUtils.isEmpty(request.getPayNow().getPaymentMethod())) {
                missingMandatoryParamNames.append("PaymentMethod, ");
            }
            if (StringUtils.isEmpty(request.getPayNow().getPaymentInfo())) {
                missingMandatoryParamNames.append("PaymentInfo, ");
            }
        }
        if (request.getCredits() != null) {
            for (VisibleCreditsManualPay credit : request.getCredits()) {
                String error = null;
                if (StringUtils.isBlank(credit.getPromotionName())) {
                    error = "No PromotionName provided";
                }
                if (StringUtils.isBlank(credit.getApplicableCI())) {
                    error = "No ApplicableCI provided";
                }
                if (StringUtils.isBlank(credit.getCreditRedeemableOfferCI())) {
                    error = "No CreditRedeemableOfferCI provided";
                }

                if (error != null) {
                    throw new InvalidRequestParameterException("Invalid Request: " + error);
                }
            }
        }

        if (missingMandatoryParamNames.length() != 0) {
            String errMsg = missingMandatoryParamNames.toString();
            errMsg = errMsg.substring(0, errMsg.length() - 2);
            throw new MissingRequestParametersException("Missing mandatory parameters: " + errMsg);
        }

    }

    /**
     * Validate that the manual pay inputs are upto date as expected out of corresponding AOP
     * output. 1) Payable amount: AOP Estimated Payable Amount = ManualPay PayNow Charge amount 2)
     * Credits: a. Number and the type of credits in ManualPay input should match with that of
     * credits in AOP Estimate. b. For each type of credit, ManualPay approved transferable credits
     * == AOP estimated transferable credits 3) Offers: a. Number and the type (externalId
     * eg:visible_unlimited) of offer in ManualPay input should match with that of credits in AOP
     * Estimate. b. For each type of offer, Payable amounts should tally.
     * 
     * @param request
     * @param aopRecalcOutput
     * @param loggingKey
     * @throws ManualPayException
     */
    public static void validateForStaleAdviceCalculations(ManualPayRequest request,
                                                          VisibleResponsePaymentAdviceService aopRecalcOutput,
                                                          String loggingKey)
            throws ManualPayException {

        // 1. Verify AOP Main Estimate Amounts
        validateWithAOPEstimatedPayableAmountWithPayNow(request, aopRecalcOutput, loggingKey);
    }

    /**
     * Validate Manual Pay input PayNow amount with AOP Main Estimated amount Check for below
     * condition: If AOP calculated payable amount present, but no ManualPay PayNow amount? // OR If
     * ManualPay PayNow amount, but no AOP payable amount // OR If both are present, but amounts do
     * not match
     *
     * @param request
     * @param aopRecalcOutput
     * @param loggingKey
     * @throws ManualPayException
     */
    private static void validateWithAOPEstimatedPayableAmountWithPayNow(ManualPayRequest request,
                                                                        VisibleResponsePaymentAdviceService aopRecalcOutput,
                                                                        String loggingKey)
            throws ManualPayException {
        StringBuilder error = new StringBuilder();

        boolean bManPayNowAmountPresent = (request.getPayNow() != null
                && request.getPayNow().getChargeAmount() != null
                && request.getPayNow().getChargeAmount().doubleValue() != 0);

        // If AOP calculated payable amount present, but no ManualPay PayNow amount?
        // OR
        // If ManualPay PayNow amount, but no AOP payable amount
        // OR
        // If both are present, but amounts do not tally
        if (aopRecalcOutput.getEstimatedPayableAmount() == null && bManPayNowAmountPresent
                || (aopRecalcOutput.getEstimatedPayableAmount() != null
                        && aopRecalcOutput.getEstimatedPayableAmount().doubleValue() != 0)
                        && !bManPayNowAmountPresent
                || bManPayNowAmountPresent && aopRecalcOutput.getEstimatedPayableAmount() != null
                        && request.getPayNow().getChargeAmount().compareTo(
                                aopRecalcOutput.getEstimatedPayableAmount()) != 0) {
            error.append(
                    "ManualPay input estimates are stale. (AOP Estimated Payment Amount: ").append(
                            aopRecalcOutput.getEstimatedPayableAmount()).append(
                                    ", (ManualPay Input PayNow charge amount): ").append(
                                            bManPayNowAmountPresent
                                                    ? request.getPayNow().getChargeAmount()
                                                    : null).append(
                                                            "). Please restart the operation.");

            String errStr = error.toString();
            ERROR(m_logger, loggingKey + errStr);
            throw new ManualPayException(RESULT_CODES.MPAY_STALE_INPUT, errStr);
        }
    }

    public static void validateRequest(String loggingKey, VisibleRequestAutoPay request)
            throws InvalidRequestException {
        DEBUG(m_logger, loggingKey + "Validating autopay service request");

        if (StringUtils.isBlank(request.getSubscriptionExternalId())
                && StringUtils.isBlank(request.getSubscriptionObjectId())) {
            throw new MissingRequestParametersException(
                    "Missing mandatory parameters either SubscriptionExternalId or SubscriptionObjectId should be supplied.");
        }
    }
    
    public static void validateRequest(String loggingKey, VisibleRequestRecharge request)
            throws InvalidRequestException {
        DEBUG(m_logger, loggingKey + "Validating VisibleRequestRecharge");  

        MtxSubscriberSearchData searchData = request.getSubscriberSearchData();
        
        if (StringUtils.isBlank(searchData.getExternalId())&&searchData.getObjectId()==null) {
            throw new MissingRequestParametersException(
                    "Missing mandatory parameter SubscriptionExternalId (Beneficiary External Id).");
        }   

        if (request.getAmount()==null) {
            throw new MissingRequestParametersException(
                    "Missing mandatory parameter RechargeAmount.");
        }else if (request.getAmount().signum()<=0) {
            throw new MissingRequestParametersException(
                    "Invalid value for parameter RechargeAmount.");
        }

        String aedOrderId = null;
        if(request.getApiEventData() != null&&(request.getApiEventData() instanceof VisibleApiEventData)) {
            VisibleApiEventData aed = (VisibleApiEventData)request.getApiEventData();
            aedOrderId = aed.getOrderId();
        }        

        if(request.getRechargeAttr() == null) {
            throw new InvalidRequestParameterException(
                    "RechargeAttr should not be null.");
        }        
        if(!(request.getRechargeAttr() instanceof VisibleRechargeExtension)) {
            throw new InvalidRequestParameterException(
                    "RechargeAttr should be of type VisibleRechargeExtension.");        
        }
        VisibleRechargeExtension attr = (VisibleRechargeExtension)request.getRechargeAttr();        
        
        if (StringUtils.isBlank(aedOrderId) && StringUtils.isBlank(attr.getOrderId())) {
            throw new MissingRequestParametersException(
                    "Missing mandatory parameter OrderId.");
        }
        
        if(StringUtils.isBlank(attr.getServiceMDN())) {
            throw new MissingRequestParametersException(
                    "Missing mandatory parameter ServiceMDN (BeneficiaryMDN).");
        }
    }
}
