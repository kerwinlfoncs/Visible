package com.matrixx.vag.subscriber.service.model;

import java.math.BigDecimal;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class RefundEventInfo {

    private String recurringEventId;
    private String paymentAuthorizationEventId;
    private String payerExternalId;
    private Long beneficiaryMainbalanceResourceId;
    private Long payerMainbalanceResourceId;
    private BigDecimal mainBalanceChargeAmount;
    private BigDecimal payerAdjustmentAmount;
    
    public Long getBeneficiaryMainbalanceResourceId() {
        return beneficiaryMainbalanceResourceId;
    }

    public void setBeneficiaryMainbalanceResourceId(Long beneficiaryMainbalanceResourceId) {
        this.beneficiaryMainbalanceResourceId = beneficiaryMainbalanceResourceId;
    }

    public String getRecurringEventId() {
        return recurringEventId;
    }

    public void setRecurringEventId(String recurringEventId) {
        this.recurringEventId = recurringEventId;
    }

    public String getPaymentAuthorizationEventId() {
        return paymentAuthorizationEventId;
    }

    public void setPaymentAuthorizationEventId(String paymentAuthorizationEventId) {
        this.paymentAuthorizationEventId = paymentAuthorizationEventId;
    }

    public Long getPayerMainbalanceResourceId() {
        return payerMainbalanceResourceId;
    }

    public void setPayerMainbalanceResourceId(Long payerMainbalanceResourceId) {
        this.payerMainbalanceResourceId = payerMainbalanceResourceId;
    }

    public BigDecimal getMainBalanceChargeAmount() {
        return mainBalanceChargeAmount;
    }

    public void setMainBalanceChargeAmount(BigDecimal mainBalanceChargeAmount) {
        this.mainBalanceChargeAmount = mainBalanceChargeAmount;
    }

    public String getPayerExternalId() {
        return payerExternalId;
    }

    public void setPayerExternalId(String payerExternalId) {
        this.payerExternalId = payerExternalId;
    }    

    public BigDecimal getPayerAdjustmentAmount() {
        return payerAdjustmentAmount;
    }

    public void setPayerAdjustmentAmount(BigDecimal payerAdjustmentAmount) {
        this.payerAdjustmentAmount = payerAdjustmentAmount;
    }

    public String toJson() {
        ObjectMapper mapper = new ObjectMapper();
        try {
            return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(this);
        } catch (JsonProcessingException e) {
            return null;
        }
    }

}
