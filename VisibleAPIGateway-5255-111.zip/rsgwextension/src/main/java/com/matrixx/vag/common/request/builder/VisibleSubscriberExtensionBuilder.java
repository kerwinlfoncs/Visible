package com.matrixx.vag.common.request.builder;

import org.apache.commons.lang3.StringUtils;

import com.matrixx.datacontainer.MtxTimestamp;
import com.matrixx.datacontainer.mdc.VisibleSubscriberExtension;

public class VisibleSubscriberExtensionBuilder {

    MtxTimestamp paymentDate;
    MtxTimestamp paymentRetryDate;
    String payerExternalId;
    Boolean removePayerExternalId = false;
    VisibleSubscriberExtension existingExtension;

    public VisibleSubscriberExtension build() {
        boolean newAttr = true;
        VisibleSubscriberExtension subExtension = new VisibleSubscriberExtension();

        if (existingExtension != null) {
            subExtension = existingExtension;
            newAttr = false;
        }

        if (this.paymentDate != null && (newAttr || subExtension.getPaymentDate() == null)) {
            subExtension.setPaymentDate(paymentDate);
        }

        if (paymentRetryDate != null) {
            subExtension.setPaymentRetry(paymentRetryDate.toString());
        }

        if (StringUtils.isNotBlank(payerExternalId)) {
            subExtension.setPayerExternalId(payerExternalId);
        } else if (removePayerExternalId) {
            subExtension.setPayerExternalId("");
        }

        return subExtension;
    }

    public VisibleSubscriberExtensionBuilder withPaymentDate(MtxTimestamp paymentDate) {
        if (paymentDate != null) {
            this.paymentDate = paymentDate;
        }
        return this;
    }

    public VisibleSubscriberExtensionBuilder withPayerExternalId(String payerExternalId) {
        if (StringUtils.isNotBlank(payerExternalId)) {
            this.payerExternalId = payerExternalId;
        }
        return this;
    }

    public VisibleSubscriberExtensionBuilder dropPayerExternalId() {
        this.removePayerExternalId = true;
        return this;
    }

    public VisibleSubscriberExtensionBuilder withPaymentRetryDate(MtxTimestamp paymentRetryDate) {
        if (paymentRetryDate != null) {
            this.paymentRetryDate = paymentRetryDate;
        }
        return this;
    }

}
