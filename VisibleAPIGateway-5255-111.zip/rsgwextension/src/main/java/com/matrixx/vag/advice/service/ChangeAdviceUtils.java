package com.matrixx.vag.advice.service;

import static com.matrixx.platform.LogUtils.DEBUG;
import static com.matrixx.platform.LogUtils.INFO;
import static com.matrixx.platform.LogUtils.WARN;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.TimeZone;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.matrixx.datacontainer.mdc.BalanceInfo;
import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import com.matrixx.datacontainer.mdc.MtxSubscriberSearchData;
import com.matrixx.datacontainer.mdc.SubscriptionResponse;
import com.matrixx.datacontainer.mdc.VisiblNextCycle;
import com.matrixx.datacontainer.mdc.VisibleAttribute;
import com.matrixx.datacontainer.mdc.VisibleCatalogItem;
import com.matrixx.datacontainer.mdc.VisibleChangeCycle;
import com.matrixx.datacontainer.mdc.VisibleChangeServiceCredit;
import com.matrixx.datacontainer.mdc.VisibleCredits;
import com.matrixx.datacontainer.mdc.VisibleGroup;
import com.matrixx.datacontainer.mdc.VisibleNextCyclePaymentAdvice;
import com.matrixx.datacontainer.mdc.VisibleNonRedeemableCredit;
import com.matrixx.datacontainer.mdc.VisibleOfferDetails;
import com.matrixx.datacontainer.mdc.VisibleRequestChangeServiceAdvice;
import com.matrixx.datacontainer.mdc.VisibleResponseChangeServiceAdvice;
import com.matrixx.vag.advice.model.ChangeServiceDataStage.BillCycle;
import com.matrixx.vag.advice.model.ChangeServiceDataStage.NextCycleDetails;
import com.matrixx.vag.advice.model.CiResourceIdPair;
import com.matrixx.vag.advice.model.CreditStage;
import com.matrixx.vag.advice.model.ServiceStage;
import com.matrixx.vag.advice.model.SubscriberGroup;
import com.matrixx.vag.advice.model.VisibleReverseCreditInternal;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.Constants.BRAINTREE_CONSTANTS;
import com.matrixx.vag.common.Constants.CHANGE_SERVICE_CONSTANTS;
import com.matrixx.vag.common.Constants.CI_METADATA;
import com.matrixx.vag.common.Constants.GENERIC_CONSTANTS;
import com.matrixx.vag.common.Constants.LOG_MESSAGES;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.common.Constants.TAX_CONSTANTS;
import com.matrixx.vag.common.request.builder.ServiceTaxRequestBuilder;
import com.matrixx.vag.config.AppPropertyParser;
import com.matrixx.vag.tax.model.ServiceTaxRequest;
import com.matrixx.vag.tax.model.ServiceTaxResponse;

public class ChangeAdviceUtils {

    private static final Logger m_logger = LoggerFactory.getLogger(ChangeAdviceUtils.class);

    public static void updateTaxesInServiceStage(String loggingKey,
                                                 String route,
                                                 AdviceDataStage stage) {
        final String methodKey = loggingKey + " updateTaxesInServiceStage: ";

        if (!stage.isAdviceWithTaxes()) {
            INFO(m_logger, methodKey + "Advice is without taxes. Taxapi will not be called.");
            return;
        }

        for (ServiceStage paynow : CommonUtils.emptyIfNull(stage.getPayNowMap().values())) {
            if (paynow.getProratedDiscountPrice().signum() <= 0) {
                continue;
            }
            String taxTemplateName = "";
            if (stage.getChangeServiceDataStage().getBillCycle() == BillCycle.CURRENT) {
                taxTemplateName = CI_METADATA.CHANGE_CYCLE_DELTA_TAX_INPUT;
            } else {
                taxTemplateName = CI_METADATA.TAX_INPUT;
            }
            String taxTemplate = taxTemplateName.equalsIgnoreCase(
                    CI_METADATA.CHANGE_CYCLE_DELTA_TAX_INPUT)
                            ? stage.getChangeServiceDataStage().getDeltaTaxInput()
                            : paynow.getTaxInput();
            try {
                INFO(
                        m_logger, methodKey
                                + "Call TaxApi to calculate service taxes for quote or change service advice");
                String geoCode;
                if (StringUtils.isNotBlank(stage.getRequestGeoCode())) {
                    geoCode = stage.getRequestGeoCode();
                } else if (StringUtils.isNotBlank(stage.getPayerGeoCode())) {
                    geoCode = stage.getPayerGeoCode();
                } else {
                    if (StringUtils.isNotBlank(stage.getSubscriberGeoCode())) {
                        geoCode = stage.getSubscriberGeoCode();
                    } else {
                        String noGeocodeMsg = "No valid geocode passed for tax calculation"
                                + StringUtils.SPACE + "requestGeoCode: " + stage.getRequestGeoCode()
                                + StringUtils.SPACE + "subscriberGeoCode: "
                                + stage.getSubscriberGeoCode();
                        WARN(
                                m_logger,
                                methodKey + LOG_MESSAGES.LOG_FAILED_SERVICE_TAX + StringUtils.SPACE
                                        + GENERIC_CONSTANTS.ERROR_PREFIX + noGeocodeMsg);
                        paynow.setTaxResponse(GENERIC_CONSTANTS.ERROR_PREFIX + noGeocodeMsg);
                        stage.setServiceTaxApiErrorMessage(
                                LOG_MESSAGES.LOG_FAILED_SERVICE_TAX + StringUtils.SPACE
                                        + GENERIC_CONSTANTS.ERROR_PREFIX + noGeocodeMsg);
                        return;
                    }
                }
                // @formatter:off
                ServiceTaxRequestBuilder taxReqBuilder = (new ServiceTaxRequestBuilder())
                        .withRequestTemplate(taxTemplate)
                        .withGrossPrice(paynow.getGrossPrice())
                        .withDiscountPrice(paynow.getProratedDiscountPrice())
                        .withBrand(stage.getBrand())
                        .withGeoCode(geoCode);
                // @formatter:on
                ServiceTaxRequest taxRequest = taxReqBuilder.build();
                if (StringUtils.isNotBlank(stage.getPayerExternalId())) {
                    taxRequest.setMsgID(
                            String.format(
                                    TAX_CONSTANTS.MSG_FORMAT_ADVICE, taxRequest.getMsgID(),
                                    stage.getPayerExternalId()));
                }
                String taxResp = AdviceUtils.getTaxDetailsWithoutRefTax(
                        loggingKey, route, taxRequest);

                if (StringUtils.isNotBlank(taxResp)
                        && !taxResp.toUpperCase().startsWith(GENERIC_CONSTANTS.ERROR_PREFIX)) {
                    paynow.setTaxResponse(taxResp);
                    ServiceTaxResponse taxDetails = CommonUtils.getServiceTaxResponseFromJsonString(
                            taxResp);
                    paynow.setTaxFeeAmount(
                            taxDetails.getTransactionElement().get(0).getTotalFeeAmount());
                    INFO(
                            m_logger,
                            methodKey + "Fee amount : " + taxDetails.getTransactionElement().get(
                                    0).getTotalFeeAmount());
                } else {
                    WARN(
                            m_logger, methodKey + LOG_MESSAGES.LOG_FAILED_SERVICE_TAX
                                    + StringUtils.SPACE + taxResp);
                    paynow.setTaxResponse(taxResp);
                    stage.setServiceTaxApiErrorMessage(
                            LOG_MESSAGES.LOG_FAILED_SERVICE_TAX + StringUtils.SPACE + taxResp);
                }
            } catch (Exception ex) {
                WARN(
                        m_logger, methodKey + LOG_MESSAGES.LOG_FAILED_SERVICE_TAX
                                + StringUtils.SPACE + ExceptionUtils.getStackTrace(ex));
                paynow.setTaxResponse(GENERIC_CONSTANTS.ERROR_PREFIX + ex.getMessage());
                stage.setServiceTaxApiErrorMessage(
                        LOG_MESSAGES.LOG_FAILED_SERVICE_TAX + StringUtils.SPACE + ex.getMessage());
            }

        }
        // stage.getPayNowMap().values().forEach(paynow -> {
        // if (paynow.getProratedDiscountPrice().signum() > 0) {
        // }
        // });
    }

    @SuppressWarnings("unchecked")
    public static void updateChangeAdviceOutputCurrentCycle(String loggingKey,
                                                            MtxResponseSubscription subscription,
                                                            AdviceDataStage stageChangeCycle,
                                                            VisibleResponseChangeServiceAdvice output) {
        final String methodKey = loggingKey + " updateChangeAdviceOutputCurrentCycle: ";
        output.setResult(stageChangeCycle.getResultCode());
        output.setResultText(stageChangeCycle.getResultText());
        output.setBrand(stageChangeCycle.getBrand());
        output.setAvailableMainBalance(stageChangeCycle.getAvailableMainBalanceAmount());
        output.setChangeType(stageChangeCycle.getChangeServiceDataStage().getChangeType());
        output.setPayerExternalId(stageChangeCycle.getPayerExternalId());

        if (!stageChangeCycle.isPaidCycleStartDateDefaulted()) {
            output.setPaidCycleStartDate(stageChangeCycle.getPaidCycleStartDate());
        }

        if (stageChangeCycle.getPayNowMap() == null
                || stageChangeCycle.getPayNowMap().values() == null
                || stageChangeCycle.getPayNowMap().values().isEmpty()) {
            INFO(m_logger, methodKey + "Enrolled service not found.");
            output.setResult(RESULT_CODES.HTTP_INTERNAL_ERROR);
            output.setResultText("Enrolled service not found.");
            return;
        }

        ServiceStage ps = null;
        for (ServiceStage psTemp : stageChangeCycle.getPayNowMap().values()) {
            ps = psTemp;
            break;
        }

        VisibleChangeCycle cc = new VisibleChangeCycle();
        output.setChangeCycle(cc);

        if (stageChangeCycle.getChangeServiceDataStage().getReverseCreditMap().values() != null
                && !stageChangeCycle.getChangeServiceDataStage().getReverseCreditMap().values().isEmpty()) {
            // 20240315 - For time being let us add all reverse credits to NextCycle.
            // We get promos in consumption balance because of next cycle payments.
            // This also leaves current rsgateway MDC structures relatively unchanged.
            stageChangeCycle.getChangeServiceDataStage().getReverseCreditMap().values().forEach(
                    rs -> {
                        VisibleReverseCreditInternal rsi = (VisibleReverseCreditInternal) rs;
                        if (rsi.getNoReverseReason() == null) {
                            stageChangeCycle.getChangeServiceDataStage().setNextCycleDetails(
                                    NextCycleDetails.REVERSE_PROMO_ONLY);
                        } else {
                            INFO(
                                    m_logger,
                                    methodKey + "Reverse Promo skipped for "
                                            + rsi.getRedeemableOfferCI() + ". Due to "
                                            + rsi.getNoReverseReason());
                        }
                    });
        }

        List<String> deltaOnlyTargets = AppPropertyParser.getStringList(
                CHANGE_SERVICE_CONSTANTS.DELTA_ONLY_TARGET_LIST);
        List<String> annualUpgradeList = AppPropertyParser.getStringList(
                CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_REALIGN_CYCLE_LIST);

        if (CommonUtils.compareDateAndTimestamp(
                stageChangeCycle.getPaidCycleStartDate(),
                stageChangeCycle.getCycleEndTime()) >= 0) {
            if (!deltaOnlyTargets.contains(ps.getCatalogItemExternalId())) {
                // Monthly offers (mostly)
                stageChangeCycle.getChangeServiceDataStage().setNextCycleDetails(
                        NextCycleDetails.NEXT_CYCLE_PAYMENT);
            } else if (annualUpgradeList.contains(
                    stageChangeCycle.getChangeServiceDataStage().getChangeType())) {
                // Annual upgrades (mostly)
                stageChangeCycle.getChangeServiceDataStage().setNextCycleDetails(
                        NextCycleDetails.NEXT_CYCLE_PAYMENT);
            }
        }

        if (stageChangeCycle.getChangeServiceDataStage().getNextCycleDetails() == NextCycleDetails.REVERSE_PROMO_ONLY
                || stageChangeCycle.getChangeServiceDataStage().getNextCycleDetails() == NextCycleDetails.NEXT_CYCLE_PAYMENT) {
            VisiblNextCycle nc = new VisiblNextCycle();
            output.setNextCycle(nc);

            if (stageChangeCycle.getChangeServiceDataStage().getNextCycleDetails() != null) {
                INFO(
                        m_logger, methodKey + "Next Cycle created for "
                                + stageChangeCycle.getChangeServiceDataStage().getNextCycleDetails());
            }

            if (ps != null) {
                if (!(stageChangeCycle.getChangeServiceDataStage().getReverseCreditMap().values() == null
                        || stageChangeCycle.getChangeServiceDataStage().getReverseCreditMap().values().isEmpty())) {
                    stageChangeCycle.getChangeServiceDataStage().getReverseCreditMap().values().forEach(
                            rs -> {
                                VisibleReverseCreditInternal rsi = (VisibleReverseCreditInternal) rs;
                                nc.appendReverseCredits(rsi);
                            });
                }
            }
        }

        if (stageChangeCycle.getChangeServiceDataStage().getReservedMainBalanceNextCycle() != null
                && stageChangeCycle.getChangeServiceDataStage().getReservedMainBalanceNextCycle().signum() > 0) {
            if (output.getNextCycle() == null) {
                VisiblNextCycle nc = new VisiblNextCycle();
                output.setNextCycle(nc);
                INFO(m_logger, methodKey + "Next Cycle created for reserved mainbalance");
            }
            if (stageChangeCycle.getChangeServiceDataStage().getNextCycleDetails() != null) {
                output.getNextCycle().setReservedMainBalanceAmount(
                        stageChangeCycle.getChangeServiceDataStage().getReservedMainBalanceNextCycle());
            }
        }

        if (stageChangeCycle.getChangeServiceDataStage().getNextCycleDetails() == NextCycleDetails.NEXT_CYCLE_PAYMENT) {
            output.getNextCycle().setReservedMainBalanceAmount(
                    stageChangeCycle.getChangeServiceDataStage().getReservedMainBalanceNextCycle());
            if (ps != null) {
                output.getNextCycle().setTotalAmount(ps.getDiscountPrice());
            }
        }

        for (CreditStage cs : stageChangeCycle.getCreditMap().values()) {
            if (cs.getAvailableCredits().signum() > 0) {
                VisibleCredits vc = new VisibleCredits();
                vc.setPromotionName(cs.getPromotionName());
                vc.setApplicableCI(cs.getApplicableCiExternalId());
                vc.setAvailableCredits(cs.getAvailableCredits());

                vc.setAvailableCreditsGrant(cs.getAvailableCreditsGrant());
                vc.setAvailableCreditsConsumable(cs.getAvailableCreditsConsumable());
                vc.setEstimatedTransferableCredits(cs.getEstimatedTransferableCredits());
                vc.setCreditRedeemableOfferCI(cs.getRedeemOfferCi());
                vc.setDiscountCalculationMethod(cs.getDiscountCalculationMethod());
                vc.setRedeemableGoodType(cs.getRedeemGoodType());
                vc.setApplicableCreditsPercentage(cs.getApplicableGrantPercentage());
                if (StringUtils.isNotBlank(cs.getCreditTaxDetails())) {
                    vc.setTaxDetails(cs.getCreditTaxDetails());
                } else if (cs.isPromotionTaxable()
                        && StringUtils.isNotBlank(AdviceUtils.getErrorResultText(stageChangeCycle))
                        && !(AdviceUtils.getErrorResultText(stageChangeCycle).equalsIgnoreCase(
                                "OK"))) {
                    vc.setTaxDetails(AdviceUtils.getErrorResultText(stageChangeCycle));
                }

                if (!cs.isNoCap()) {
                    vc.setCreditCap(cs.getCreditCap());
                }

                if (cs.getFutureGrant() != null && cs.getFutureGrant().signum() > 0) {
                    vc.setFutureCreditGrant(cs.getFutureGrant());
                    vc.setFutureGrantOfferCI(cs.getGrantOfferCi());
                    // This is a quick and dirty workaround.
                    // We need future grant to be available as normal grant for all calculations.
                    // But finally it should be reported separate from available grants.
                    vc.setAvailableCreditsGrant(
                            cs.getAvailableCreditsGrant().subtract(cs.getFutureGrant()).max(
                                    BigDecimal.ZERO));
                }

                if (cs.getGlobalCreditStage().getConsumablesUnavailableToChangeService().signum() > 0) {
                    vc.setConsumablesUnavailableToChangeService(
                            cs.getGlobalCreditStage().getConsumablesUnavailableToChangeService());
                }
                vc.setRedeemableCredits(cs.getRedeemableCredits());
                cc.getCreditsAppender().add(vc);
            }
        }
        VisibleCatalogItem tobe = new VisibleCatalogItem();
        tobe.setCatalogItemExternalId(ps.getCatalogItemExternalId());
        tobe.setDiscountPrice(ps.getDiscountPrice());
        tobe.setGrossPrice(ps.getGrossPrice());
        if (stageChangeCycle.getChangeServiceDataStage().getAsisCatalogItem().getEndDate() != null) {
            tobe.setStartDate(
                    stageChangeCycle.getChangeServiceDataStage().getAsisCatalogItem().getEndDate());
        }
        tobe.setGoodType(ps.getGoodType());

        if (ps.getGlobalPasses() != null && ps.getGlobalPasses().signum() > 0) {
            VisibleAttribute va = new VisibleAttribute();
            va.setName(CHANGE_SERVICE_CONSTANTS.ATTRIBUTE_NAME_FREE_GLOBAL_PASS);
            va.setValue(ps.getGlobalPasses().setScale(0, RoundingMode.FLOOR).toPlainString());
            tobe.getAttributesAppender().add(va);
        }
        output.setNewCatalogItem(tobe);

        VisibleOfferDetails vod = stageChangeCycle.getVisibleOfferDetails(
                ps.getCatalogItemExternalId());

        cc.setAocAmount(ps.getAocDiscountPrice());
        cc.setConsumableMainBalance(ps.getConsumableMainBalance());
        cc.setTaxDetails(ps.getTaxResponse());
        cc.setPayableAmount(vod.getPayableAmount().max(ps.getTaxFeeAmount()));
        cc.setTotalAmount(ps.getProratedDiscountPrice().max(ps.getTaxFeeAmount()));

        if (ps.getCycleStartTime() != null) {
            cc.setCycleStartTime(ps.getCycleStartTime());
        } else if (stageChangeCycle.getCycleStartTime() != null) {
            cc.setCycleStartTime(stageChangeCycle.getCycleStartTime());
        }
        if (ps.getCycleEndTime() != null) {
            cc.setCycleEndTime(ps.getCycleEndTime());
        } else if (stageChangeCycle.getCycleEndTime() != null) {
            cc.setCycleEndTime(stageChangeCycle.getCycleEndTime());
        }

        output.setCurrentCatalogItem(
                stageChangeCycle.getChangeServiceDataStage().getAsisCatalogItem());
        output.setConsumableMainBalance(ps.getConsumableMainBalance());
        output.setTotalAmount(cc.getTotalAmount());
        output.setRechargeAmount(
                cc.getPayableAmount().subtract(cc.getConsumableMainBalance()).max(BigDecimal.ZERO));

        cc.setDelta(BigDecimal.ZERO.max(stageChangeCycle.getChangeServiceDataStage().getDelta()));

        // if (stageChangeCycle.getSubscriberGroupList() != null) {
        for (SubscriberGroup sg : CommonUtils.emptyIfNull(
                stageChangeCycle.getSubscriberGroupList())) {
            VisibleGroup vg = new VisibleGroup();
            vg.setGroupExternalId(sg.getGroupExternalId());
            vg.setGroupName(sg.getGroupName());
            vg.setGroupTier(sg.getGroupTier());
            vg.setSubscriberMemberCount(sg.getSubscriberMemberCount());
            output.appendSubscriberGroups(vg);
        }
        // }

        // if (stageChangeCycle.getChangeServiceDataStage().getNonRedeemableCreditMap() != null
        // && !stageChangeCycle.getChangeServiceDataStage().getNonRedeemableCreditMap().isEmpty()) {
        for (VisibleNonRedeemableCredit nrc : CommonUtils.emptyValuesIfNull(
                stageChangeCycle.getChangeServiceDataStage().getNonRedeemableCreditMap())) {
            output.appendNonRedeemableCredits(nrc);
        }
        // }
        // if (stageChangeCycle.getChangeServiceDataStage().getChangeServiceCredits() != null
        // && !stageChangeCycle.getChangeServiceDataStage().getChangeServiceCredits().isEmpty()) {
        for (VisibleChangeServiceCredit csc : CommonUtils.emptyIfNull(
                stageChangeCycle.getChangeServiceDataStage().getChangeServiceCredits())) {
            output.appendNewRedeemableCredits(csc);
        }
        // }

        for (CiResourceIdPair pci : CommonUtils.emptyIfNull(
                stageChangeCycle.getChangeServiceDataStage().getPreactiveOffers())) {
            VisibleCatalogItem preactiveCi = new VisibleCatalogItem();
            preactiveCi.setCatalogItemExternalId(pci.getCatalogItemExternalId());
            preactiveCi.setResourceId(pci.getResourceId());
            output.setPreactiveCatalogItem(preactiveCi);
            break;
        }

        if (StringUtils.isNotBlank(
                stageChangeCycle.getChangeServiceDataStage().getIgnoreFuturePromoReason())) {
            output.setResultText(
                    output.getResultText() + " | "
                            + stageChangeCycle.getChangeServiceDataStage().getIgnoreFuturePromoReason());
        }
        if (StringUtils.isNotBlank(
                stageChangeCycle.getChangeServiceDataStage().getPromoNaDeltaReason())) {
            output.setResultText(
                    output.getResultText() + " | "
                            + stageChangeCycle.getChangeServiceDataStage().getPromoNaDeltaReason());
        }

        INFO(m_logger, methodKey + " Updated ChangeServiceAdvice output: " + output.toJson());
    }

    @SuppressWarnings("unchecked")
    public static void updateChangeAdviceOutputNextCycle(String loggingKey,
                                                         AdviceDataStage stageNextCycle,
                                                         VisibleResponseChangeServiceAdvice output) {
        final String methodKey = loggingKey + " updateChangeAdviceOutputNextCycle: ";
        VisiblNextCycle nc = output.getNextCycle();
        ServiceStage ps = null;
        for (ServiceStage psTemp : stageNextCycle.getPayNowMap().values()) {
            ps = psTemp;
            break;
        }

        if (ps != null) {
            VisibleOfferDetails vod = stageNextCycle.getVisibleOfferDetails(
                    ps.getCatalogItemExternalId());

            nc.setConsumableMainBalance(ps.getConsumableMainBalance());
            output.setConsumableMainBalance(
                    output.getConsumableMainBalance().add(ps.getConsumableMainBalance()));
            nc.setPayableAmount(vod.getPayableAmount());
            nc.setTotalAmount(ps.getDiscountPrice());
            output.setTotalAmount(output.getTotalAmount().add(ps.getDiscountPrice()));
            output.setRechargeAmount(
                    output.getRechargeAmount().add(nc.getPayableAmount()).subtract(
                            nc.getConsumableMainBalance()).max(BigDecimal.ZERO));
            nc.setTaxDetails(ps.getTaxResponse());
        }

        for (CreditStage cs : stageNextCycle.getCreditMap().values()) {
            if (cs.getAvailableCredits().signum() > 0) {
                VisibleCredits vc = new VisibleCredits();
                vc.setPromotionName(cs.getPromotionName());
                vc.setApplicableCI(cs.getApplicableCiExternalId());
                vc.setAvailableCredits(cs.getAvailableCredits());

                vc.setAvailableCreditsGrant(cs.getAvailableCreditsGrant());
                vc.setAvailableCreditsConsumable(cs.getAvailableCreditsConsumable());
                vc.setEstimatedTransferableCredits(cs.getEstimatedTransferableCredits());
                vc.setCreditRedeemableOfferCI(cs.getRedeemOfferCi());
                vc.setDiscountCalculationMethod(cs.getDiscountCalculationMethod());
                vc.setRedeemableGoodType(cs.getRedeemGoodType());
                vc.setApplicableCreditsPercentage(cs.getApplicableGrantPercentage());
                if (StringUtils.isNotBlank(cs.getCreditTaxDetails())) {
                    vc.setTaxDetails(cs.getCreditTaxDetails());
                } else if (cs.isPromotionTaxable()
                        && StringUtils.isNotBlank(AdviceUtils.getErrorResultText(stageNextCycle))
                        && !(AdviceUtils.getErrorResultText(stageNextCycle).equalsIgnoreCase(
                                "OK"))) {
                    vc.setTaxDetails(AdviceUtils.getErrorResultText(stageNextCycle));
                }

                if (!cs.isNoCap()) {
                    vc.setCreditCap(cs.getCreditCap());
                }

                if (cs.getFutureGrant() != null && cs.getFutureGrant().signum() > 0) {
                    vc.setFutureCreditGrant(cs.getFutureGrant());
                    vc.setFutureGrantOfferCI(cs.getGrantOfferCi());
                    // This is a quick and dirty workaround.
                    // We need future grant to be available as normal grant for all calculations.
                    // But finally it should be reported separate from available grants.
                    vc.setAvailableCreditsGrant(
                            cs.getAvailableCreditsGrant().subtract(cs.getFutureGrant()).max(
                                    BigDecimal.ZERO));
                }

                vc.setRedeemableCredits(cs.getRedeemableCredits());
                nc.getCreditsAppender().add(vc);
            }
        }

        BigDecimal gap = output.getNewCatalogItem().getDiscountPrice().subtract(
                output.getCurrentCatalogItem().getDiscountPrice());

        gap = gap.add(stageNextCycle.getChangeServiceDataStage().getGapImpactPromos());
        BigDecimal newPromosRedeemable = BigDecimal.ZERO;
        if (nc.getCredits() != null) {
            for (VisibleCredits cs : nc.getCredits()) {
                newPromosRedeemable = newPromosRedeemable.add(cs.getRedeemableCredits());
            }
        }
        gap = gap.subtract(newPromosRedeemable);

        nc.setGap(gap.max(BigDecimal.ZERO));

        INFO(
                m_logger,
                methodKey
                        + "Gap for Next Cycle = (New Offer Price - Promos for New Offer)- (Old Offer Price - Promos for Old Offer) = "
                        + "(" + output.getNewCatalogItem().getDiscountPrice() + " - "
                        + newPromosRedeemable + ") - ("
                        + output.getCurrentCatalogItem().getDiscountPrice() + " - "
                        + stageNextCycle.getChangeServiceDataStage().getGapImpactPromos() + ") ="
                        + nc.getGap());

        INFO(m_logger, methodKey + " Updated ChangeServiceAdvice output: " + output.toJson());
    }

    public static void updateChangeAdviceOutputNextCycleAop(String loggingKey,
                                                            AdviceDataStage stageAop,
                                                            VisibleResponseChangeServiceAdvice output) {
        final String methodKey = loggingKey + " updateChangeAdviceOutputNextCycleAop: ";
        VisibleNextCyclePaymentAdvice ncpa = AdviceUtils.getNextCycleAop(loggingKey, stageAop);
        output.setNextCyclePaymentAdvice(ncpa);
        INFO(m_logger, methodKey + " Updated ChangeServiceAdvice output: " + output.toJson());
    }

    public static void rechargeCorrectionForChangeService(String loggingKey,
                                                          AdviceDataStage stage) {
        ServiceStage ps = stage.getPayNowMap().values().iterator().next();
        BigDecimal remainingMainBalance = stage.getAvailableMainBalanceAmount().subtract(
                stage.getChangeServiceDataStage().getReservedMainBalanceNextCycle()).subtract(
                        ps.getConsumableMainBalance());
        BigDecimal rechargePayable = ps.getFinalPayableAmount().subtract(
                ps.getConsumableMainBalance());

        if (rechargePayable.signum() > 0 && remainingMainBalance.signum() > 0) {
            if (remainingMainBalance.compareTo(rechargePayable) >= 0) {
                ps.setConsumableMainBalance(ps.getFinalPayableAmount());
            } else {
                ps.setConsumableMainBalance(
                        ps.getConsumableMainBalance().add(remainingMainBalance));
            }
        }
    }

    public static void updatePayNowFromChangeServiceAdviceRequest(String loggingKey,
                                                                  String route,
                                                                  VisibleRequestChangeServiceAdvice changeRequest,
                                                                  AdviceDataStage stage) {
        final String methodName = "updatePayNowFromChangeServiceAdviceRequest:";
        // MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
        // searchData.setExternalId(builder.getSubscriptionExternalId());

        stage.getPayNowMap().values().forEach(ps -> {
            if (ps.getCatalogItemExternalId().equals(changeRequest.getNewCatalogItemExternalId())) {
                ps.setGrossPrice(changeRequest.getGrossPrice());
                ps.setDiscountPrice(changeRequest.getDiscountPrice());
                INFO(
                        m_logger,
                        loggingKey + methodName + StringUtils.SPACE
                                + "Updated Paynow Stage from Change Service Advice Request: "
                                + ps.toJson());
            }
        });
    }

    public static void updatePayableAmountsForChangeCycle(String loggingKey,
                                                          String route,
                                                          AdviceDataStage stage) {

        final String methodKey = loggingKey + " updatePayableAmountsForChangeCycle: ";
        BigDecimal mainBalanceAccount = stage.getAvailableMainBalanceAmount().subtract(
                stage.getChangeServiceDataStage().getReservedMainBalanceNextCycle());

        for (ServiceStage ps : stage.getPayNowMap().values()) {
            if (ps.getNonCreditAmount().compareTo(mainBalanceAccount) <= 0) {
                ps.setConsumableMainBalance(ps.getNonCreditAmount());
            } else {
                ps.setConsumableMainBalance(mainBalanceAccount);
            }
            ps.setConsumableMainBalance(
                    ps.getConsumableMainBalance().setScale(
                            BRAINTREE_CONSTANTS.BT_AMOUNT_PRECISION, RoundingMode.FLOOR));
            DEBUG(
                    m_logger, methodKey + " Updated Consumable Main Balance: "
                            + ps.getConsumableMainBalance());
        }
    }

    public static void updateMainBalaceCycleDates(String loggingKey,
                                                  SubscriptionResponse subscriptionResponse,
                                                  AdviceDataStage stage) {
        final String methodKey = loggingKey + " updateMainBalaceCycleDates: ";
        stage.setAvailableMainBalanceAmount(BigDecimal.ZERO);

        for (BalanceInfo bi : CommonUtils.emptyIfNull(subscriptionResponse.getWalletBalances())) {
            if (bi.getIsMainBalance()) {
                stage.setAvailableMainBalanceAmount(bi.getAmount().negate());
            }
        }

        INFO(
                m_logger, loggingKey + methodKey + "Updated mainbalance amount from balance: "
                        + stage.getAvailableMainBalanceAmount());

        if (subscriptionResponse.getBillingCycle() != null) {
            stage.setCycleStartTime(
                    subscriptionResponse.getBillingCycle().getCurrentPeriodStartTime());
            stage.setCycleEndTime(subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime());
            INFO(
                    m_logger, loggingKey + methodKey
                            + "Updated cycle start date and cycle end date from bill cycle.");
        }
    }

    public static void updateGlobalPasses(String loggingKey,
                                          AdviceDataStage stage,
                                          ServiceStage ps,
                                          boolean isMonthly,
                                          boolean reAlignCycle,
                                          boolean changeImmediate,
                                          BigDecimal aocGP,
                                          BigDecimal cycleMonths) {
        final String methodKey = loggingKey + " updateGlobalPasses: ";
        INFO(m_logger, methodKey);
        if (!changeImmediate) {
            ps.setGlobalPasses(aocGP);
            INFO(
                    m_logger,
                    methodKey
                            + "Change will take effect next month. Global passes will not be subject to adjustment by Change Service :"
                            + aocGP);
            return;
        }

        BigDecimal existingPasses = BigDecimal.ZERO;
        for (VisibleAttribute va : CommonUtils.emptyIfNull(
                stage.getChangeServiceDataStage().getAsisCatalogItem().getAttributes())) {
            if (CHANGE_SERVICE_CONSTANTS.ATTRIBUTE_NAME_FREE_GLOBAL_PASS.equalsIgnoreCase(
                    va.getName().trim())) {
                existingPasses = new BigDecimal(va.getValue());
                break;
            }
        }

        BigDecimal newPasses = null;
        BigDecimal remainingMonths = BigDecimal.ZERO;
        if (CommonUtils.zeroIfNull(ps.getGpPerMonth()).signum() > 0) {
            if (reAlignCycle) {
                ZonedDateTime startTime = CommonUtils.getZonedDateTimeNow(
                        stage.getSubscriptionTimezone());
                YearMonth ymStartTime = YearMonth.from(startTime);
                ZonedDateTime endTime = CommonUtils.getZonedDateTimeFromMtxTimestamp(
                        ps.getCycleEndTime(), stage.getSubscriptionTimezone());
                YearMonth ymEndTime = YearMonth.from(endTime);
                remainingMonths = BigDecimal.valueOf(
                        ChronoUnit.MONTHS.between(ymStartTime, ymEndTime));
                if (endTime.getDayOfMonth() - startTime.getDayOfMonth() > 0) {
                    remainingMonths = remainingMonths.add(BigDecimal.ONE);
                }
                INFO(
                        m_logger,
                        methodKey
                                + "Remaining months for global passes by retaining annual cycle dates :"
                                + remainingMonths);
            } else if (!isMonthly) {
                remainingMonths = cycleMonths;
                INFO(
                        m_logger, methodKey + "Global pass months for target annual service :"
                                + remainingMonths);
            } else {
                remainingMonths = BigDecimal.ONE;
                INFO(
                        m_logger, methodKey + "Global pass months for target monthly service :"
                                + remainingMonths);
            }

            if (stage.getChangeServiceDataStage().getAsIsHasGlobalPass()) {
                newPasses = remainingMonths;
            } else {
                newPasses = remainingMonths.multiply(ps.getGpPerMonth());
            }
        }

        if (newPasses != null && newPasses.signum() >= 0) {
            BigDecimal maxPasses = ps.getGpCap();

            BigDecimal afterChangePasses = newPasses.add(existingPasses);
            if (maxPasses != null) {
                afterChangePasses = maxPasses.min(afterChangePasses);
            }
            ps.setGlobalPasses(afterChangePasses);
            INFO(m_logger, methodKey + "Global passes after change :" + afterChangePasses);
        } else {
            INFO(
                    m_logger, methodKey
                            + "Impact on Global pass banking balance is negative. It will be assumed that all global passes will be forfeited.");
            ps.setGlobalPasses(BigDecimal.ZERO);
        }
    }

}
