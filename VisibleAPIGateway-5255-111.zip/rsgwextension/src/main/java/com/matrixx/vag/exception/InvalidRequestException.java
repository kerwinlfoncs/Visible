package com.matrixx.vag.exception;

import com.matrixx.vag.common.Constants.RESULT_CODES;

/**
 * Exception thrown upon encountering an error with incoming request.
 *
 * @author unico
 */
public class InvalidRequestException extends IntegrationServiceException {

    private static final long serialVersionUID = -1296664825668966679L;

    public InvalidRequestException(String message) {
        super(RESULT_CODES.HTTP_BAD_REQUEST, message);
    }

    public InvalidRequestException(Long resultCode, String message) {
        super(resultCode, message);
    }

    public InvalidRequestException(Long resultCode, String message, Throwable cause) {
        super(resultCode, message, cause);
    }

}
