/**
 * 
 */
package com.matrixx.vag.exception;

import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.common.coverage.Generated;

/**
 * @author mnguyen
 */
@Generated
public class AutoPayException extends IntegrationServiceException {

    /**
     * 
     */
    private static final long serialVersionUID = 2492033412624981760L;

    /**
     * @param resultCode
     * @param message
     */
    public AutoPayException(Long resultCode, String message) {
        super(resultCode, message);
    }

    public AutoPayException(String message) {
        super(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, message);
    }

    /**
     * @param resultCode
     * @param message
     * @param cause
     */
    public AutoPayException(Long resultCode, String message, Throwable cause) {
        super(resultCode, message, cause);
    }

}
