
package com.matrixx.vag.common;

import com.matrixx.datacontainer.mdc.VisiblePurchasedOfferExtension;
import com.matrixx.datacontainer.mdc.VisibleSubscriberExtension;
import com.matrixx.vag.common.coverage.Generated;

import java.math.BigDecimal;
import java.util.Set;

/**
 * Defines property names and constants used by the API gateway.
 *
 * @author unico
 */
@Generated
public final class Constants {

    /**
     * System properties used by the API gateway.
     */
    @Generated
    public static final class SYSTEM_PROPERTIES {

        public static final String SYSPROP_NAME_APP_CONFIG_FILE = "custom.config";
        public static final String SYSPROP_VALUE_APP_CONFIG_FILE = "/opt/mtx/conf/rsgateway.properties";
    }

    @Generated
    public static final class ACTIVE_MQ_CONSTANTS {

        public static final String AMQ_CONNECTION_PROTOCOL = "tcp://";
        public static final String PROP_AMQ_MSG_HOST = "sac.notification.environment.messaging.host";
        public static final String PROP_AMQ_MSG_PORT = "sac.notification.environment.messaging.port";
    }

    @Generated
    public static final class AOP_CONSTANTS {

        public static final String REQUEST_TYPE_DETAIL = "detail";
        public static final String REQUEST_TYPE_SUMMARY = "summary";
    }

    @Generated
    public static final class AUTOPAY_CONSTANTS {

        public static final int DELTA_HOURS_DEFAULT = 24;
        public static final String PROP_DELTA_HOURS = "autopay.deltahours";
        public static final int RETRY_WAIT_HOURS_DEFAULT = 24;
        public static final String PROP_RETRY_WAIT_HOURS = "autopay.retry.waithours";
        public static final String PROP_MSG_QUEUE = "autopay.notification.queue";
        public static final String RECHARGE_REASON = "purchase_service";
        public static final String TRANSACTION_TYPE = "Customer Initiated";
        public static final String FAILURE_NOTIF_CONTAINER = "MtxPaymentFailureNotification";
        public static final String SUCCESS_NOTIF_CONTAINER = "MtxPaymentSuccessNotification";
        public static final String NOTIF_EXP_OFFSET_TYPE = "days";
        public static final long FAILURE_NOTIF_TYPE = 68;
        public static final long SUCCESS_NOTIF_TYPE = 69;
    }

    @Generated
    public static final class AUTOPAY_MESSAGES {

        public static final String PAYMENT_PREFERENCE_AUTOPAY_200 = "200 -   Payment preference AutoPay";
        public static final String RECHARGE_ATTEMPTED_230 = "230 -     Recharge attempted";
        public static final String RECHARGE_SUCCESSFUL_232 = "232 -       Recharge successful";
        public static final String RECHARGE_FAILED_233 = "233 -       Recharge failed";
        public static final String RECHARGE_SKIPPED_TESTRUN_234 = "234 -       Recharge skipped. Test run.";

        public static final String READ_PAYMENT_METHODS_ERROR_264 = "264 -       Error in reading payment methods.";
        public static final String NO_PAYMENT_METHODS_ERROR_265 = "265 -       Subscription has no payment methods.";
        public static final String NO_DEFAULT_PAYMENT_METHOD_ERROR_266 = "266 -       Subscription has no default payment method.";
        public static final String NO_SUBSCRIPTION_ATTR_ERROR_267 = "267 -       Subscription has no attributes.";
        public static final String NO_PAYMENT_PREFERENCE_268 = "268 -       Subscription has no payment preference.";
        public static final String MANUAL_PAY_SUBSCRIPTION_269 = "269 -       Skipping manual pay subscription.";

        public static final String RECHARGE_NOT_DUE_270 = "270 -     Recharge not due";
        public static final String STATUS_NOT_ACTIVE_PAUSE_271 = "271 -       Status not Active or Pause";
        public static final String STATUS_PAUSED_272 = "272 -       Paused";
        public static final String RECHARGE_WINDOW_NOT_REACHED_273 = "273 -       Recharge not due - window not reached";
        public static final String RECHARGE_ALREADY_DONE_274 = "274 -       Recharge not due - already done";
        public static final String IN_RETRY_PERIOD_275 = "275 -       Recharge due but in retry period";
        public static final String HAS_ENOUGH_BALANCE_FOR_RENEWAL_276 = "276 -       Recharge due but has sufficient balance";
        public static final String TERMINATION_DATE_277 = "277 -       Termination date <= next cycle";
        public static final String STATUS_PAUSE_END_DATE_ILLEGAL_278 = "278 -       PauseEndDate has an illegal value";
        public static final String PAYMENT_ADVICE_FAILED_279 = "279 -       Payment Advice Service failed";
        public static final String SUBSCRIPTION_DATA_ERROR_280 = "280 -       Subscription data error";

        public static final String PAYMENT_RETRY_UPDATE_ERROR_281 = "281 -       Recharge failed. Payment Retry Date update also failed.";
        public static final String RECHARGE_SUCESS_NOTIFICATION_ERROR_282 = "282 -       Recharge successful. But notification sending error.";
        public static final String RECHARGE_ERROR_NOTIFICATION_ERROR_283 = "283 -       Recharge failed. Notiification sending also failed.";
        public static final String NO_RECHARGE_REQUIRED_THIS_MONTH_284 = "284 -       Recharge not due. No service needs recharge for next cycle. ";
        public static final String NO_OFFERS_TO_RECHARGE_285 = "285 -       Subscriber has no offers to be recharged. ";
        public static final String PAYER_HAS_NO_PAYMENT_METHODS_ERROR_286 = "286 -       Payer has no payment methods.";
        public static final String SUBSCRIPTION_NEEDS_RECHARGE_300 = "300 -       Subscription needs recharge";
        public static final String PAYMENT_ADVICE_ERROR_301 = "301 -       Payment Advice Error";
        public static final String STATUS_NOT_PAUSE = "Not Paused";
        public static final String STATUS_NOT_TERMINATED = "Not Terminated";
        public static final String STATUS_NOT_IN_RETRY = "Not In Retry Period";
    }

    @Generated
    public static final class BALANCE_CONSTANTS {

        public static final String BALANCE_NAME_VISIBLE_DEV_SWAP = "balance.name.visible.dev.swp";
        public static final String BALANCE_NAME_GLOBAL_PASS = "balance.name.global.pass";
        public static final String MAINBALANCE_USAGE_PRIORITY_LIST = "balance.usage.priority.list.mainbalance";
        public static final String BALANCE_CLASS_CREDITS = "Credits";
        public static final String BALANCE_ATTR_GRANT_CI = "PromotionMetadataCI";
        public static final String BALANCE_LIFETIME_GOODWILL_METER = "Lifetime_Goodwill_Credits_Meter";
        public static final long BALANCE_CLASS_ID_USD = 840;
        public static final Set<String> BAPI_UNUSED_BALANCE_CLASSES_UPPER = Set.of(
                "METER", "VOICE", "DATA", "TEXT", "MMS", "EURO");
    }

    @Generated
    public static final class BRAINTREE_CONSTANTS {

        public static final String BRAINTREE_ERROR_CODES_LIST = "braintree.error.codes";
        public final static int BT_AMOUNT_PRECISION = 2;
        public final static boolean BT_VISIBLE_RECURRING_OVERRIDE_FLAG = false;
    }

    @Generated
    public static final class CHANGE_SERVICE_CONSTANTS {

        public static final String NIB_SERVICE_CI = "Visible_Unlimited";
        public final static String AOC_PROMO_INFO_FOR_DELTA = "PurchaseService";

        public final static String CHANGE_TYPE_IMMEDIATE_START_CSV_LIST = "change.service.type.list.start.immediate";
        public final static String CI_DISALLOWED_AS_TARGET_LIST = "change.service.ci.list.disallowed.as.target";
        public final static String CHANGE_TYPE_REALIGN_CYCLE_LIST = "change.service.type.list.purchase.cycle.realign";
        public final static String DELTA_ONLY_TARGET_LIST = "change.service.delta.only.list.tobe.service";
        public final static String DELTA_FREE_CLASS_CODE_UPPER_CASE_LIST = "change.service.class.code.upper.case.list.no.delta.impact";

        public final static String CHANGE_TYPE_NAME_PROP_PREFIX = "change.service.type.name.";
        public final static String CHANGE_TYPE_NAME_PROP_OFFER_SEPARATOR_TO = ".to.";

        public final static String ATTRIBUTE_NAME_FREE_GLOBAL_PASS = "FreeGlobalPasses";
        public final static String GOOD_TYPE_ADJ_GPGL = "adjust_gp_gl";
        public final static String PLAN_ID_ADJ_GPGL = "GP00002";
    }

    @Generated
    public static final class CI_METADATA {

        public static final String TAX_INPUT = "TaxInput";
        public static final String STANDALONE_TAX_INPUT = "StandAloneTaxInput";
        public static final String BASE_OFFER_TAX_INPUT = "BaseOfferTaxInput";
        public static final String CHANGE_CYCLE_DELTA_TAX_INPUT = "ChangeCycleDeltaTaxInput";
        public static final String ZERO_TAX_RESPONSE = "ZeroTaxResponse";
        public static final String VISIBLE_INSURANCE = "Visible_Insurance";
        public static final String GP_CAP = "gpCap";
        public static final String GP_PER_MONTH = "gpMultiple";
    }

    @Generated
    public static final class CI_EXTERNAL_IDS {

        public static final String SETUP_SERVICES = "Setup_Services";
        public static final String SETUP_MAINBALANCE = "Setup_Mainbalance";
    }

    @Generated
    public static final class CREDIT_CONSTANTS {

        public static final BigDecimal HIGH_CREDIT_CAP = new BigDecimal(Double.MAX_VALUE);
        public static final String CALCULATION_METHOD_AOC = "AOC";
        public static final String CALCULATION_METHOD_READ_METADATA = "ReadMetadata";
        public static final String CALCULATION_METHOD_READ_OFFER_INSTANCE = "ReadOfferInstance";
        public static final String GRANT_TYPE_DOLLAR = "Dollar";
        public static final String GRANT_TYPE_PERCENTAGE = "Percentage";
        public static final String GRANT_TYPE_AOC = "AOC";
        public static final String AOC_GRANT_OFFERS = "credit.grant.calculation.method.aoc.catalog.items";
    }

    @Generated
    public static final class CYCLE_INTERVALS {

        public static final int YEARLY = 12;
    }

    @Generated
    public static final class CYCLE_LENGTHS {

        public static final String YEAR = "Year";
        public static final String MULTI_MONTH = "MultiMonth";
        public static final String MONTH = "Month";
    }

    @Generated
    public static final class CYCLE_PERIODS {

        public static final int HOURLY = 1;
        public static final int DAILY = 2;
        public static final int WEEKLY = 3;
        public static final int MONTHLY = 4;
        public static final int YEARLY = 5;
        public static final int MINUTES = 6;
    }

    @Generated
    public static final class DATE_POLICY {

        public static final long START_OF_PERIOD = 1;
        public static final long OFFSET_FROM_START = 3;;
    }

    /**
     * Constants used by device service.
     */
    @Generated
    public static final class DEVICE_CONSTANTS {

        public static final String DEVICE_PAYMENT_USING_RECHARGE = "device.payment.using.recharge";
        public static final Boolean DEVICE_PAYMENT_USING_RECHARGE_DEFAULT_VALUE = true;
        public static final Boolean DEVICE_RETURN_EVENT_SEARCH_IN_MEMORY_ONLY_DEFAULT_VALUE = false;

        public static final String DEVICE_DIRECT_PURCHASE_GOOD_TYPE_PURCHASE_DEVICE = "device.direct.purchase.good.type.purchase.device";
        public static final String DEVICE_DIRECT_PURCHASE_GOOD_TYPE_PURCHASE_SHIPPING = "device.direct.purchase.good.type.purchase.shipping";
        public static final String DEVICE_DIRECT_PURCHASE_PAY_AUTH_EXPIRY = "device.direct.purchase.payment.authorization.expiry.days";
        public static final String DEVICE_DIRECT_PURCHASE_PAY_AUTH_EXPIRY_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ssZ";

        public static final String DEVICE_FINANCE_PURCHASE_REASON_FINANCE_DEVICE = "device.finance.purchase.reason.finance.device";
        public static final String DEVICE_FINANCE_PURCHASE_REASON_FINANCE_SHIPPING = "device.finance.purchase.reason.finance.shipping";
        public static final String DEVICE_FINANCE_PURCHASE_GOOD_TYPE_AFFIRM_FEE = "device.finance.purchase.good.type.affirm.fee";
        public static final String DEVICE_FINANCE_PURCHASE_GOOD_TYPE_FINANCE_DEVICE = "device.finance.purchase.good.type_finance_device";
        public static final String DEVICE_FINANCE_PURCHASE_GOOD_TYPE_FINANCE_SHIPPING = "device.finance.purchase.good.type_finance.shipping";
        public static final String DEVICE_FINANCE_PURCHASE_SHIPPING_GEOCODE_KEY = "device.finance.purchase.shipping.geocode.key";

        public static final String DEVICE_TYPE_WEARABLE = "Wearable";
        public static final String DEVICE_TYPE_SERVICE = "Service";
    }

    @Generated
    public static final class EVENT_TYPES {

        public static final String BALANCE_TRANSFER = "19";
        public static final String PAYMENT_AUTHORIZATION = "24";
        public static final String PURCHASE = "4";
        public static final String RECHARGE = "30";
        public static final String RECURRING = "2";
    }

    @Generated
    public static final class EXCEPTION_MESSAGES {

        public static final String FAILED_TO_QUERY_SUBSCRIPTION = "Failed to query subscription";
        public static final String FAILED_TO_QUERY_SUBSCRIBER_WALLET = "Failed to query subscriber Wallet";
        public static final String CAN_NOT_ENROLL_WITH_CHANGE_SERVICE = "Requested Catalog Item can not be enrolled through change service.";
        public static final String DELTA_PROMO_NO_CLASS_CODE = "Delta credit should be provided with ClassCode.";
        public static final String DELTA_PROMO_NO_LIMIT = "Delta credit should be provided with promotion limit.";
        public static final String ADDON_WITH_AOP_ONLY = "New addon details are provided with NextCyclePaymentAdvice only.";
        public static final String ADDON_CANCEL_WITH_AOP_ONLY = "Advice after addon cancellation is provided with NextCyclePaymentAdvice only.";
        public static final String MANDATORY_ADDON_EXTERNAL_ID = "Addon CatalogItemExternalId is mandatory parameter.";
        public static final String MANDATORY_ADDON_DISCOUNT_PRICE = "Addon discount price is mandatory parameter.";
        public static final String INCORRECT_BASE_OFFER_TYPE = "ChangeServiceAdvice api additional input Catalog Item should be of type Base";
        public static final String INCORRECT_ADDON_OFFER_TYPE = "ChangeServiceAdvice api new input Catalog Item should be of type Addon";
        public static final String NO_OFFER_IN_SUBSCRIPTION = "Subscription does not have active or pre-active CatalogItemExternalId: ";
        public static final String SERVICE_MDN_ERROR = "Device does not have Service MDN";
        public static final String WEARABLE_MDN_ERROR = "Device does not have Wearable MDN";
    }

    @Generated
    public static final class FILTER_CONSTANTS {

        public static final String RESPONSE_OFFER_FIELD_TYPE_INCLUDE = "Include";
        public static final String RESPONSE_OFFER_FIELD_TYPE_EXCLUDE = "Exclude";
    }

    @Generated
    public static final class FREEZE_GRANT_REASONS {

        public static final String ZERO_VALUE_GRANT = "Zero Value Grant";
        public static final String ENOUGH_CONSUMABLES = "Consumables Greater Than or Equal to Promotion Limit";
        public static final String INCOMPATIBLITY = "Incompatible with other promotions";
        public static final String NO_APPLICABLE_OFFERS = "No applicable offers";
        public static final String APPLICABLE_OFFERS_CHANGE_SERVICE = "No applicable offers after change service.";
        public static final String OFFER_ATTRIBUTE_AS_IS = "As-Is attribute values do not match with CreditIncludeAttributeValues. ";
        public static final String OFFER_ATTRIBUTE_TO_BE = "To-Be attribute values do not match with CreditIncludeAttributeValues. ";
        public static final String OFFER_ATTRIBUTE = "Attribute values do not match with CreditIncludeAttributeValues. ";
        public static final String NONE = "None";
    }

    @Generated
    public static final class GENERIC_CONSTANTS {

        public static final String YES = "Y";
        public static final String NO = "N";
        public static final String DOT_REGEX = "\\.";
        public static final String DOT = ".";
        public static final String EQUALS = "=";
        public static final String ERROR_PREFIX = "ERROR: ";
        public static final long MILLISECONDS_IN_A_DAY = 86400000;
        public static final long LARGE_NUMBER = 999999999;
    }

    @Generated
    public static final class GROUP_CONSTANTS {

        public static final String GROUP_TIER_CONNECCTED = "ConnectedAccount";
        public static final String CA_RELATION_SEPARATOR = "#";
        public static final String CA_FIELD_SEPARATOR = ":";
        public static final String CA_BENEFICIARY_FLD_NAME = "Ben";
        public static final String CA_PAYER_FLD_NAME = "Pay";
        public static final String CA_LINK_FORMAT = CA_BENEFICIARY_FLD_NAME + ":%s#"
                + CA_PAYER_FLD_NAME + ":%s";
    }

    /**
     * Constants used for HTTP requests.
     */
    @Generated
    public static final class HTTP_CONSTANTS {

        public static final String REQUEST_PARAM_SUMMARY = "Summary";
        public static final String REQUEST_PARAM_VALUE_SET = "1";
    }

    @Generated
    public static final class LOG_MESSAGES {

        public static final String NOT_ENOUGH_BALANCE_TO_CHANGE_SERVICE = "Mainbalance and Credits are not enough to complete purchase. Please recharge and proceed with purchase. Suggested Solution: Run Quote Advice and make sure enough amount is available in mainbalance and credits";
        public static final String NOT_ENOUGH_BALANCE_TO_PURCHASE = "Mainbalance and Credits are not enough to complete purchase. Please recharge and proceed with purchase. Suggested Solution: Run Quote Advice and make sure enough amount is available in mainbalance and credits";

        public static final String FAILED_TO_CHANGE_SERVICE = "Failed to change service";
        public static final String FAILED_RECURRING_CHARGE_ESTIMATE = "Error in getting recurring charge estimate";
        public static final String FAILED_TO_QUERY_FUTURE_PAYMENT = "Failed to query future payment for subscriber";
        public static final String FAILED_TO_QUERY_SERVICE_SUBSCRIPTION = "Failed to query service subscription.";
        public static final String FAILED_TO_QUERY_SUBSCRIBER_WALLET = "Failed to query subscriber Wallet";
        public static final String FAILED_TO_QUERY_PAYER_WALLET = "Failed to query payer Wallet";
        public static final String FAILED_TO_GET_MATCHING_PAYMENT_HISTORY_FOR_PAY_AUTH_EVENT_IDS = "Failed to get matching payment history for payment authorisation event ids";
        public static final String FAILED_TO_QUERY_SUBSCRIBER = "Failed to query subscriber ";
        public static final String FAILED_TO_PURCHASE_REVERSE_CUMULATIVE_OFFER = "Failed to purchase reverse cumulative offer ";
        public static final String FAILED_TO_QUERY_EVENTS = "Failed to query events";
        public static final String FAILED_TO_QUERY_SUB_EVENTS = "Failed to query subscriber events.";
        public static final String FAILED_TO_REFUND_SERVICE = "Failed to Refund Service ";
        public static final String FAILED_TO_REFUND_GIFT_SERVICE = "Failed to refund gift service ";
        public static final String FAILED_TO_QUERY_PAYMENT_HISTORY = "Failed to query payment history for subscriber";
        public static final String FAILED_TO_QUERY_PAYMENT_HISTORY_GIFTER = "Failed to query payment history for gifter";
        public static final String FAILED_TO_GET_MATCHING_PAYMENT_HISTORY = "Failed to get matching payment history for subscriber";
        public static final String FAILED_TO_GET_CANCEL_AOC = "Failed to get AOC on cancel subscriber offer";
        public static final String FAILED_TO_GET_PURCHASE_AOC = "Failed to get AOC on purchase subscriber offer";
        public static final String FAILED_TO_ADD_CA_LINK = "Failed to add connected account link.";
        public static final String FAILED_TO_REMOVE_CA_LINK = "Failed to remove connected account link.";

        public static final String BALANCE_RESOURCE_NOT_FOUND = "Failed to determine refund balance resource ID for subscriber";
        public static final String CATALOG_ITEM_RESOURCE_NOT_FOUND = "Failed to find catalog item resource Id";
        public static final String INSUFFICIENT_AUTHORIZATION_AMOUNT = "Insufficient authorized amount to refund";

        public static final String LOG_TAX_NOT_AVAILABLE_GEOCODE_CANNOT_BE_READ = " credit taxes can not be calculated. ServiceTaxDetails are not available to map GeoCode ";
        public static final String LOG_ERROR_CALCULATING = "Error while calculating";
        public static final String LOG_CREDIT_TAX = "credit tax";

        public static final String LOG_FAILED_TO_ADD_PAYMENT = "Failed to add payment";
        public static final String LOG_FAILED_TO_CURRENT_PAYMENT = "Failed to make the payment method default";
        public static final String LOG_FAILED_TO_DELETE_PAYMENT = "Failed to delete payment";
        public static final String LOG_FAILED_TO_GET_CURRENT_PAYMENT_METHOD = "Failed to get current payment method";
        public static final String LOG_FAILED_TO_GET_PAYMENT_RESOURCE_ID = "Failed to get paymnet resource id";
        public static final String LOG_FAILED_TO_GENERATE_CLIENT_TOKEN = "Failed to generate client token";
        public static final String LOG_FAILED_TO_MODIFY_PAYMENT = "Failed to modify payment";
        public static final String LOG_FAILED_TO_QUERY_PAYMENT_METHOD_INFO = "Failed to query payment method info";
        public static final String LOG_FAILED_TO_QUERY_SUBSCRIBER = "Failed to query subscriber";
        public static final String LOG_FAILED_TO_QUERY_SUBSCRIBER_GROUPS = "Failed to query subscriber groups";
        public static final String LOG_FAILED_SERVICE_TAX = "Error while calculating service tax";

        public static final String NO_GIFTER_API_EVENT_DATA = "No api event data found with gifter subscription external id.";
        public static final String NO_CHANGE_NOW = "can not be done now. ";
        public static final String SUPPLIED_RECURRING_EVENTS_NOT_FOUND = "Supplied recurring events could not be found for subscription.";
        public static final String SUPPLIED_PAYAUTH_EVENTS_NOT_FOUND = "Supplied payment authorization events could not be found for subscription.";
        public static final String NO_GIFTER_EVENTS = "Balance transfer events not found for gifter: ";
        public static final String NO_MATCH_GIFTER_PAYAUTH_EVENT = "No matching payment authorization found for gifter.";
        public static final String NO_TRANSFER_BALANCE_EVENT = "No transfer balance event found for gifter.";
        public static final String NO_SECONDARY_EVENT_GIFT = "No secondary events found for gifting.";
        public static final String GIFT_SINGLE_PAYMENT = "Gift should be from one payment only.";
        public static final String GIFT_AMOUNT_TO_REFUND = "Gift amount to be refunded to gifter: ";
        public static final String GIFT_AMOUNT_MISMATCH = "Gift payment authorization amount does not match with transfer balance amount.";
        public static final String GIFTER_INFO_NOT_FOUND = "Gift external id not found in recurring event of giftee.";
        public static final String GIFT_REFUND_SINGLE_RECUR_EVENT = "Gift Service Refund should have only one recurring event in input.";
        public static final String PRORATED_INSURANCE_REFUND_SINGLE_RECUR_EVENT = "Prorated Insurance Refund should have only one recurring event in input.";
        public static final String BASE_REFUND_SINGLE_RECUR_EVENT = "Base / Addon Service Refund should have only one recurring event in input.";
        public static final String GIFT_REFUND_SINGLE_PAYAUTH_EVENT = "Gift Service Refund should have only one payment authorization event in input.";

        public static final String SERVICE_ENDS_ON = "Current service ends on : ";
        public static final String SUBSCRIPTION_HAS_NO_PAYABLE_SERVICES = "Subscriber has no active purchased services that need payment for next cycle.";
        public static final String SUBSCRIPTION_HAS_NO_ACTIVE_SERVICES = "Subscriber has no active purchased services.";
        public static final String SUBSCRIPTION_HAS_NO_SERVICES = "Subscriber has no active or pre-active purchased services.";
        public static final String SUBSCRIPTION_IS_TERMINATED = "Subscriber is Terminated.";
        public static final String SUBSCRIPTION_IS_LAPSED = "Subscriber is Lapsed.";
        public static final String TRY_AFTER = "Try after: ";
        public static final String VALID_CHARGES_WITH_BALANCE_UPDATES_NOT_FOUND = "Failed to find valid charges with balance updates";

        public static final String FUTURE_GRANT_AMOUNT_IGNORED_1001 = "1001 - Warning : Grant balance exists. Non-Zero credits available. Future grant amount will be ignored for Delta calculation. Promotion class code: ";
        public static final String FUTURE_GRANT_NOT_APPLICABLE_1002 = "1002 - Warning : As per template attributes, promotion is not applicable to new service. Promotion will be ignored. Promotion class code: ";
        public static final String FUTURE_GRANT_NO_CI_1003 = "1003 - Error : Future promo should be provided with CatalogItemExternalId of grant offer. ";
        public static final String GRANT_CI_NOT_PROMO_1004 = "1004 - Error : Grant CI is not of the type Promo. : ";
        public static final String FUTURE_PROMO_NO_AOC_1005 = "1005 - Error : Future promotion should not of the type AOC. : ";
        public static final String FUTURE_GRANT_TYPE_DOLLAR_1006 = "1006 - Error : Future promotion grant should be of type Dollar. : ";

        public static final String CA_SUBS_NOT_BE_LINKED = "Payer-Beneficiary link can not be created.";        
        public static final String PAYER_BENEFICIARY_NO_CA_GROUP = "Common ConnectedAccounts group for payer and beneficiary could not be found.";
        public static final String BENEFICIARY_NO_CA_GROUP_SEARCH_PAYER_GROUP = "Beneficiary has no ConnectedAccounts group. But Payer Id exists. Search payer groups.";
        public static final String BENEFICIARY_NO_CA_GROUP_CLEAR_ATTR = "Beneficiary has no ConnectedAccounts group. But Payer Id exists. Clear attribute field for Payer.";
        public static final String NO_CA_LINKS_FOR_BENEFICIARY_CLEAR_ATTR = "No ConnectedAccounts link found for beneficiary. Clear attribute field for Payer.";        
        public static final String BENEFICIARY_NO_CA_GROUP_SEARCH_PAYER_AS_PER_REQUEST = "Beneficiary has no ConnectedAccounts group. But Payer Id supplied in request. Search payer groups.";
        public static final String NO_LINKS_IN_CA_GROUP = "ConnectedAccounts group has no links.";

        public static final String NO_CA_LINKS_FOR_BENEFICIARY = "No ConnectedAccounts link found for beneficiary.";
        public static final String BENEFICIARY_NOT_ACTIVE = "Beneficiary is not Active.";
        public static final String BENEFICIARY_HAS_CA_LINK = "Beneficiary is already linked with a payer. Unlink before creating new link.";
        public static final String BENEFICIARY_HAS_NO_MAINBALANCE = "Beneficiary has no mainbalance.";
        public static final String PAYER_HAS_NO_MAINBALANCE = "Payer has no mainbalance.";
        public static final String PAYER_NOT_ON_AUTOPAY = "Payer is not on Autopay.";
        public static final String PAYER_NOT_ACTIVE = "Payer is not Active.";
    }

    @Generated
    public static final class MANUAL_PAY {

        public static final String ALLOWABLE_SUBSCR_STATS = "manual.pay.allowable.subscriber.statuses";
        public static final String ALLOWABLE_SUBSCR_STATS_ERR_MSG = "manual.pay.allowable.subscriber.errormsg";
    }

    @Generated
    public static final class MATRIXX_CONSTANTS {

        public static final int CHRG_METHOD_PAY_ON_ACC = 1;
        public static final int CHRG_METHOD_PAY_NOW = 2;
        public static final int CHRG_METHOD_SPLIT = 3;
        public static final Long CHRG_PURCHASE_FULL_AMOUNT = 1L;
        public static final String MTX_DATE_TIME_FORMAT = "uuuu-MM-dd'T'HH:mm:ss.SSSSSSxxx";
        public static final String PAYMENT_METHOD_REGISTERED = "1";
        public static final String PAYMENT_METHOD_TOKEN = "2";
        public static final String ROLE_INFO_EXTERNAL_ID_OWNER = "Owner";
        public static final String RESULT_TEXT_MTX_SUCCESS = "OK";
        public static final int DECIMAL_PRECISION = 8;
        public static final long CANCEL_TYPE_SCALED = 3;
        public static final int ADVICE_MODE = 2;
        public static final int BALANCE_ADJUSTMENT_TYPE_CREDIT = 1;
        public static final int BALANCE_ADJUSTMENT_TYPE_DEBIT = 2;
        public final static String CONTAINER_FIELD_NAME = "$";
    }

    @Generated
    public static final class MDC_NAMES {

        public static final String SUBSCRIBER_EXTENSION = VisibleSubscriberExtension.class.getSimpleName();
        public static final String PURCHASED_OFFER_EXTENSION = VisiblePurchasedOfferExtension.class.getSimpleName();
    }

    @Generated
    public static final class NOTIFICATION_CONSTANTS {

        public static final String NOTIFICATION_PROPERTY_NOTIFICATION_NOTIFICATION_NAME_KEY = "sac.notification.property.notification.notification_name.key";
        public static final String NOTIFICATION_PROPERTY_NOTIFICATION_OBJECT_TYPE_KEY = "sac.notification.property.notification.object_type.key";
        public static final String NOTIFICATION_PROPERTY_NOTIFICATION_OBJECT_TYPE_VALUE = "sac.notification.property.notification.object_type.value";
        public static final String NOTIFICATION_PROPERTY_NOTIFICATION_OBJECT_EXTERNAL_ID_KEY = "sac.notification.property.notification.object_external_id.key";
        public static final String NOTIFICATION_PROPERTY_NOTIFICATION_NOTIFICATION_TYPE_KEY = "sac.notification.property.notification.notification_type.key";
        public static final String NOTIFICATION_PROPERTY_NOTIFICATION_NOTIFICATION_ID_KEY = "sac.notification.property.notification.notification_id.key";
        public static final String NOTIFICATION_PROPERTY_NOTIFICATION_PAYMENT_METHOD_NAME_KEY = "sac.notification.property.notification.payment_method_name.key";
        public static final String NOTIFICATION_PROPERTY_NOTIFICATION_PAYMENT_PREFERENCE_KEY = "sac.notification.property.notification.payment_reference.key";
        public static final String NOTIFICATION_PROPERTY_STATUS_KEY = "sac.notification.property.status.key";
        public static final String NOTIFICATION_PROPERTY_STATUS_VALUE = "sac.notification.property.status.value";
        public static final String NOTIFICATION_PROPERTY_NOTIFICATION_STATUS_DESCRIPTION_KEY = "sac.notification.property.notification.status_description";
        public static final String OBJECT_ID_KEY = "ObjectId";
        public static final String AMOUNT_KEY = "Amount";
        public static final String CONTACT_EMAIL_KEY = "ContactEmail";
        public static final String CYCLE_LENGTH = "CycleLength";
        public static final String BEFORE_CYCLE_END = "BeforeCycleEnd";
        public static final String NOTIFICATION_EXPIRATION_OFFSET_KEY = "ExpirationNotificationOffset";
        public static final String NOTIFICATION_EXPIRATION_OFFSET_TYPE_KEY = "ExpirationNotificationOffsetType";
        public static final String EXPIRATION_TIME_KEY = "ExpirationTime";
        public static final String OFFER_LIST_KEY = "OfferArray";
        public static final String PAYER_CONTAINER_NAME = "MtxPayerDetails";
        public static final String PAYER_KEY = "Payer";
        public static final String PAYER_EXTERNAL_ID_KEY = "ExternalId";
    }

    @Generated
    public static final class OFFER_CONSTANTS {

        public static final String OFFER_EXTERNAL_ID_DEVICE_FINANCE_FEE = "offer.external.id.device.finance.fee";
        public static final String OFFER_PURCHASE_SETUP_MAINBALANCE_OFFER = "offer.external.id.setup.mainbalance";
        public static final String OFFER_EXTERNAL_ID_VISIBLE_SERVICE_CHARGES = "offer.external.id.visible.service.charges";
        public static final String OFFER_EXTERNAL_ID_VISIBLE_REVERSE_SERVICE_PAYMENTS = "offer.external.id.visible.reverse.service.payments";
        public static final String OFFER_EXTERNAL_ID_VISIBLE_DEVICE = "offer.external.id.device.visible";
        public static final String CI_EXTERNAL_ID_PBLINK = "ci.external.id.payer.beneficiary.link";
        public static final String OFFER_TYPE_ADDON = "Addon";
        public static final String OFFER_TYPE_BASE = "Base";
        public static final String OFFER_TYPE_INSURANCE = "Insurance";
        public static final String OFFER_TYPE_PROMO = "Promo";
        public static final String OFFER_TYPE_GIFT = "Gift";
        public static final String OFFER_STATUS_ACTIVE = "active";
        public static final String OFFER_STATUS_PRE_ACTIVE = "Pre_active";
        public static final String OFFER_ATTR_PRIMARY_OFFER = "primary_offer_in_bundle";
        public static final String OFFER_ATTR_PRIMARY_OFFER_YES = "yes";
        public static final String RETAIL_CHANNEL_CHIME = "Chime";
        public static final String AMAZON_BRAND_NAME = "Amazon";
        public static final String CHIME_OFFER_NAME = "Visible_CHIME_AOC_CI";
        public static final String VBPP_GROUP_NAME = "Visible_VBPP5_AOC_Grant";
        public static final String VBPP_25_GROUP_NAME = "Visible_VBPP25_AOC_Grant";
        public static final String AMAZON_PREPAY_OFFER_NAME = "Visible_Redeem_Amazon_PrePay_Discount";
        public static final String AMAZON_PAID_ON_OFFER_NAME = "Visible_Redeem_Amazon_PaidOn_Discount";
        public static final String PARTYPAY_OFFER_NAME = "Visible_Group_Grant";
        public static final String GROUP_TIER_VBPP = "VBPP";

        public static final String GPGL_CURLY_ADJUST_OFFER_NAME = "AdjustGPGLCurlyUpgradeCI25";
    }

    @Generated
    public static final class PAYMENT_CONSTANTS {

        public static final String AUTOPAY = "AutoPay";
        public static final String MANUALPAY = "ManualPay";
        public static final String TXN_TYP_CUST_INIT = "Customer Initiated";
        public static final String DEFAULT_RISK_DATA = "1";
        public final static String PURCHASE_SERVICE_TYPE_RENEWAL = "Renewal";
        public final static String PAYER_EXTERNAL_ID_FIELD_NAME = "PayerExternalId";
        public final static String PURCHASE_SERVICE_TYPE_FIELD_NAME = "PurchaseServiceType";
        public final static String API_EVENT_DATA_FIELD_NAME = "ApiEventData";
        public final static String PURCHASE_SERVICE_TYPE_FOR_PBLINK_CSV_LIST = "purchase.service.type.list.for.payer.beneficiary.link.ci";
    }

    @Generated
    public static final class REQUEST_QUERY_TERM_PREFIX {

        public static final String EXTERNAL_ID = "ExternalId+";
    }

    @Generated
    public static final class RESULT_CODES {

        public final static long MTX_SUCCESS = 0;
        public final static long MTX_NOT_FOUND = 11;
        public final static long RESULT_CODE_CUSTOM_SUCCESS = MTX_SUCCESS;

        // Default Success
        public final static long HTTP_SUCCESS = 200;
        // Bad request. Say Input parameter validation errors.
        public final static long HTTP_BAD_REQUEST = 400;
        // Resource not found. Say requested subscriber or group or purchased offer does not exist.
        public final static long HTTP_NOT_FOUND = 404;
        // Conflict with the current state of the resource. Say Sub is but some other field stops operation.        
        public final static long HTTP_CONFLICT = 409;
        // unable to process the request for some reason. Say sub is found but some business rule stops operation.
        public final static long HTTP_UNPROCESSABLE_ENTITY = 422;
        // unexpected condition that prevented it from fulfilling the request
        public final static long HTTP_INTERNAL_ERROR = 500;

        public final static long RESULT_CODE_CUSTOM_MISSING_REQUEST_PARAMETERS = -1;
        public final static long RESULT_CODE_CUSTOM_INVALID_REQUEST_PARAMETERS = -2;

        public final static long AUTOPAY_SKIP_SUB = -50;
        public final static long AUTOPAY_FAIL_NOTIF_FAIL = -52;

        public final static long MPAY_STALE_INPUT = 1001;

        public final static long RESULT_CODE_CUSTOM_INTERNAL_ERROR = -100;
    }

    @Generated
    public static final class SAC_CONSTANTS {

    }

    @Generated
    public static final class SAC_NOTIFICATION_CONSTANTS {

        public static final String SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_DELETE_PAYMENT_NOTIFICATION_NAME = "sac.notification.environment.property.delete.payment.notification.name";
        public static final String SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_DELETE_PAYMENT_NOTIFICATION_TYPE = "sac.notification.environment.property.delete.payment.notification.type";
        public static final String SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_DELETE_PAYMENT_STATUS_DESCRIPTION = "sac.notification.environment.property.delete.payment.status_description";
        public static final String SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_ADD_PAYMENT_NOTIFICATION_NAME = "sac.notification.environment.property.add.payment.notification.name";
        public static final String SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_ADD_PAYMENT_NOTIFICATION_TYPE = "sac.notification.environment.property.add.payment.notification.type";
        public static final String SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_ADD_PAYMENT_STATUS_DESCRIPTION = "sac.notification.environment.property.add.payment.status_description";
        public static final String SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_CURRENT_PAYMENT_NOTIFICATION_NAME = "sac.notification.environment.property.current.payment.notification.name";
        public static final String SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_CURRENT_PAYMENT_NOTIFICATION_TYPE = "sac.notification.environment.property.current.payment.notification.type";
        public static final String SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_CURRENT_PAYMENT_STATUS_DESCRIPTION = "sac.notification.environment.property.current.payment.status_description";
        public static final String SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_MODIFY_PAYMENT_PREFERENCE_NAME = "sac.notification.environment.property.modify.payment.preference.name";
        public static final String SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_MODIFY_PAYMENT_PREFERENCE_TYPE = "sac.notification.environment.property.modify.payment.preference.type";
        public static final String SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_MODIFY_PAYMENT_PREFERENCE_DESC = "sac.notification.environment.property.modify.payment.preference.description";
        public static final String SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_MSG_QUEUE = "sac.notification.environment.messaging.queue";
    }

    /**
     * Constants used by subscriber service.
     */
    @Generated
    public static final class SUBSCRIBER_SERVICE_CONSTANTS {

        public static final String SERVICE_PAYMENT_USING_RECHARGE = "service.payment.using.recharge";
        public static final Boolean SERVICE_PAYMENT_USING_RECHARGE_DEFAULT_VALUE = true;
        public static final String SERVICE_PURCHASE_REASON_MANUAL_PAY = "service.purchase.reason.manual.pay";
        public static final String SERVICE_REFUND_PAYAUTH_CAP = "service.refund.avoid.payment.authorizations.greater.than";

        public static final String BILL_CYCLE_FLAT = "0";
        public static final String BILL_CYCLE_PRORATE = "1";
        public static final String REMORSE_FLAT = "2";
        public static final String GIFT_SERVICE_REFUND = "3";
        public static final String GIFT_REFUND_REASON = "refund_gift";
        
        public static final String REFUND_CANCEL_YES = "1";
        public static final String REFUND_CANCEL_NO = "0";
    }

    @Generated
    public static final class SUBSCRIPTION_CONSTANTS {

        public static final String SUBSCRIPTION_STATUS_ACTIVE = "Active";
        public static final String SUBSCRIPTION_STATUS_PAUSE = "Pause";
        public static final String SUBSCRIPTION_STATUS_SUSPEND = "Suspend";
        public static final String SUBSCRIPTION_STATUS_LAPSE = "Lapse";
        public static final String SUBSCRIPTION_STATUS_TERMINATED = "Terminated";
        public static final String SUBSCRIPTION_STATUS_DISABLED = "Disabled";
        public static final String SUBSCRIPTION_STATUS_PREACTIVE = "Pre-Active";
        public static final String SUBSCRIPTION_STATUS_REGISTERED = "Registered";
        public static final String SUBSCRIPTION_ANNUAL_ACTIVE = "Annual_Active";
        public static final String SUBSCRIPTION_ANNUAL_SUSPEND = "Annual_Suspend";
        public static final String SUBSCRIPTION_ANNUAL_ACTIVE_SUSPEND = "Annual_Active_Suspend";
    }

    @Generated
    public static final class TAX_CONSTANTS {

        public static final String GL_DATE_FORMAT = "yyyy-MM-dd";
        public static final String MSG_PREFIX_GIFT_TAX = "Gift";
        public static final String MSG_FIELD_PAYER_TAX = "Payer:";
        public static final String MSG_FIELD_ORDER_ID = "OrderId:";
        public static final String MSG_FIELD_DELIMITER = "|";
        public static final String MSG_FORMAT_ADVICE = "%s" + MSG_FIELD_DELIMITER
                + MSG_FIELD_PAYER_TAX + "%s";
        public static final String TAX_ITEMTYPE_911 = "tax.itemType.911";
        public static final String TAX_ON_SERVICES_API_ENDPOINT = "tax.on.services.api.endpoint";
        public static final String USE_CPS_FROM_LAST_TAX = "tax.use.last.cp.for.class.codes";
        public static final int TAX_API_PRECISION = 8;
        public static final int TAX_API_DISPLAY_PRECISION = 2;
    }

    @Generated
    public static final class VISIBLE_EXTN_CONSTANTS {

        public static final String VISIBLE_MULTI_REQUESTS_NUMBER_MAX = "visible.multirequest.requests.number.max";
    }

}
