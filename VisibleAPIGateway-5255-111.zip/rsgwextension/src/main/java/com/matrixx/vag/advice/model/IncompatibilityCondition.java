package com.matrixx.vag.advice.model;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL) // Ignore unused fields to reduce payload size.
public class IncompatibilityCondition {

	public static final String OPERATOR_GT ="GT";
	public static final String OPERATOR_GE ="GE";
	public static final String OPERATOR_LT ="LT";
	public static final String OPERATOR_LE ="LE";
	public static final String OPERATOR_EQ ="EQ";

	public static final String ON_CURRENT_PROMO_AMOUNT = "CurrentPromoAmount";
	public static final String ON_INCOMPATIBLE_PROMO_AMOUNT = "IncompatiblePromoAmount";
	
	@JsonProperty("On")
    private String on;
	@JsonProperty("Operator")
    private String operator;
	@JsonProperty("Amount")
    private BigDecimal amount;

    IncompatibilityCondition() { }
    
	public void setOn(String on) {
		this.on = on;
	}

	public String getOn() {
		return on;
	}
	
	public String getOperator() {
		return operator;
	}
	
	public void setOperator(String operator) {
		this.operator = operator;
	}

	public BigDecimal getAmount() {
		return amount;
	}
	
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	
    @Override
    public String toString() {
    	//@formatter:off
        return "condition ["
                + "on=" + on 
                + "," + "\n" + " operator=" + operator 
                + "," + "\n" + " amount=" + amount
                + "]";
      //@formatter:on
    }
}