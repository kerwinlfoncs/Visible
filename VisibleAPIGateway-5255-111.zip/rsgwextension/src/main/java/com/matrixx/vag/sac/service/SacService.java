package com.matrixx.vag.sac.service;

import static com.matrixx.platform.LogUtils.DEBUG;
import static com.matrixx.platform.LogUtils.ENTER;
import static com.matrixx.platform.LogUtils.ERROR;
import static com.matrixx.platform.LogUtils.INFO;
import static com.matrixx.platform.LogUtils.WARN;

import java.lang.reflect.InvocationTargetException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonObject;
import com.matrixx.datacontainer.MtxObjectId;
import com.matrixx.datacontainer.mdc.MtxAttr;
import com.matrixx.datacontainer.mdc.MtxPaymentMethodInfo;
import com.matrixx.datacontainer.mdc.MtxRequestMulti;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberAddPaymentMethod;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberModify;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberModifyPaymentMethod;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberRemovePaymentMethod;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriptionModify;
import com.matrixx.datacontainer.mdc.MtxResponse;
import com.matrixx.datacontainer.mdc.MtxResponseAdd;
import com.matrixx.datacontainer.mdc.MtxResponseClientToken;
import com.matrixx.datacontainer.mdc.MtxResponseGroup;
import com.matrixx.datacontainer.mdc.MtxResponseMulti;
import com.matrixx.datacontainer.mdc.MtxResponsePaymentMethodInfo;
import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import com.matrixx.datacontainer.mdc.MtxSubscriberExtension;
import com.matrixx.datacontainer.mdc.MtxSubscriberSearchData;
import com.matrixx.datacontainer.mdc.SacModifyRequest;
import com.matrixx.datacontainer.mdc.SacModifyResponse;
import com.matrixx.datacontainer.mdc.SacResponse;
import com.matrixx.datacontainer.mdc.VisibleCAGroupExtension;
import com.matrixx.datacontainer.mdc.VisibleRequestCaLink;
import com.matrixx.datacontainer.mdc.VisibleRequestCaUnlink;
import com.matrixx.datacontainer.mdc.VisibleRequestSacSetUpPayment;
import com.matrixx.datacontainer.mdc.VisibleResponseCaLink;
import com.matrixx.datacontainer.mdc.VisibleResponseCaUnlink;
import com.matrixx.datacontainer.mdc.VisibleResponseSacSetUpPayment;
import com.matrixx.datacontainer.mdc.VisibleSubscriberExtension;
import com.matrixx.datacontainer.mdc.result;
import com.matrixx.platform.MatrixxContext;
import com.matrixx.vag.amq.client.ActiveMQClient;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.Constants.EXCEPTION_MESSAGES;
import com.matrixx.vag.common.Constants.GROUP_CONSTANTS;
import com.matrixx.vag.common.Constants.LOG_MESSAGES;
import com.matrixx.vag.common.Constants.MATRIXX_CONSTANTS;
import com.matrixx.vag.common.Constants.NOTIFICATION_CONSTANTS;
import com.matrixx.vag.common.Constants.PAYMENT_CONSTANTS;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.common.Constants.SAC_NOTIFICATION_CONSTANTS;
import com.matrixx.vag.common.Constants.SUBSCRIPTION_CONSTANTS;
import com.matrixx.vag.common.request.builder.MtxRequestGroupModifyBuilder;
import com.matrixx.vag.common.request.builder.MtxRequestSubscriptionModifyBuilder;
import com.matrixx.vag.common.request.builder.VisibleSubscriberExtensionBuilder;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.exception.IntegrationServiceException;
import com.matrixx.vag.exception.InvalidRequestException;
import com.matrixx.vag.exception.PaymentAdviceException;
import com.matrixx.vag.exception.SacServiceException;
import com.matrixx.vag.service.IntegrationService;

/**
 * @author Fieni Stefan
 */
@Configuration
public class SacService extends IntegrationService {

    private final RequestValidator requestValidator;
    private static final String date_format = "yyyy-MM-dd HH:mm:ss.SSS";

    private final static Logger m_logger = LoggerFactory.getLogger(SacService.class);

    private final boolean testmode; // added for junit tests
    private String notificationMsg = ""; // added for convenience. Junits can validate using
                                         // reflection. Serves no other purpose.

    @Bean(name = "SacService")
    SacService getService() {
        return new SacService();
    }

    /**
     * Constructor.
     */
    public SacService() {
        this.requestValidator = new RequestValidator();
        this.testmode = false;
    }

    /**
     * Constructor.
     */
    public SacService(boolean testmode) {
        // added for junit tests
        this.requestValidator = new RequestValidator();
        this.testmode = testmode;
    }

    private MtxResponseSubscription searchSubscriber(String loggingKey,
                                                     String route,
                                                     String objectId) {
        INFO(m_logger, "SAC - searchSubscriber - Starting - objectId :::::: " + objectId);

        return querySubscriptionDataByObjectId(loggingKey, objectId);
    }

    private MtxResponseSubscription searchSubscriberExternal(String loggingKey,
                                                             String route,
                                                             String externalId) {
        INFO(m_logger, "SAC - searchSubscriber - Starting - objectId :::::: " + externalId);
        MtxSubscriberSearchData sSData = new MtxSubscriberSearchData();
        sSData.setExternalId(externalId);
        return querySubscriptionData(loggingKey, externalId);
    }

    private MtxResponsePaymentMethodInfo searchPaymentMethodName(String loggingKey,
                                                                 String route,
                                                                 String externalId) {
        INFO(
                m_logger,
                "SAC - searchPaymentMethodName - Starting - externalId :::::: " + externalId);
        MtxSubscriberSearchData sSData = new MtxSubscriberSearchData();
        sSData.setExternalId(externalId);
        return queryPaymentMethodInfo(loggingKey, route, sSData);
    }

    /**
     * @param request
     * @param response
     * @return
     */
    public int sacModifyPayment(SacModifyRequest request, SacModifyResponse response)
            throws SacServiceException {

        long startTime = System.nanoTime();

        ENTER(m_logger, "sacmodify");

        MtxRequestMulti rMulti = new MtxRequestMulti();

        MtxRequestSubscriberModify requestSubscriberModify = new MtxRequestSubscriberModify();

        MtxSubscriberSearchData subscriberSearchData = new MtxSubscriberSearchData();
        subscriberSearchData.setExternalId(request.getExternalId());
        requestSubscriberModify.setSubscriberSearchData(subscriberSearchData);

        VisibleSubscriberExtension visibleSubscriberExtension = new VisibleSubscriberExtension();
        visibleSubscriberExtension.setPaymentPreference(request.getPaymentPreference());
        requestSubscriberModify.setAttr(new MtxAttr(visibleSubscriberExtension).mdc());

        rMulti.appendRequestList(requestSubscriberModify);

        INFO(m_logger, "SAC - modifyPurchase - REQUEST JSON -  : " + rMulti.toJson());

        MtxResponseMulti responseMulti = m_api.multi(rMulti);

        String resultText = responseMulti.getResultText();

        INFO(m_logger, "SAC - responseMulti again - RESPONSE : " + resultText);

        Long result = responseMulti.getResult();
        INFO(m_logger, "SAC - responseMulti again - RESULT CODE : " + result);

        // Step 3 - 4
        if (resultText.equalsIgnoreCase("OK") && result.intValue() == 0) {

            INFO(m_logger, "SAC - MODIFY " + "SacService" + " setting paymentSACNotification : ");

            String loggingKey = getLoggingKey(request.getExternalId());
            String route = getRoute(MatrixxContext.getRequest());
            MtxResponseSubscription responseSubscriber = searchSubscriberExternal(
                    loggingKey, route, request.getExternalId());

            String objectId = responseSubscriber.getObjectId().toString();
            MtxResponsePaymentMethodInfo rspPmtInfo = searchPaymentMethodName(
                    loggingKey, route, responseSubscriber.getExternalId());

            // Validate that we get a proper response.

            validateResponse(loggingKey, LOG_MESSAGES.LOG_FAILED_TO_MODIFY_PAYMENT, rspPmtInfo);

            String paymentMethodName = determinePaymentMethodName(rspPmtInfo);

            String sacNotificationName = AppPropertyProvider.getInstance().getString(
                    SAC_NOTIFICATION_CONSTANTS.SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_MODIFY_PAYMENT_PREFERENCE_NAME);

            String sacNotificationType = AppPropertyProvider.getInstance().getString(
                    SAC_NOTIFICATION_CONSTANTS.SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_MODIFY_PAYMENT_PREFERENCE_TYPE);

            String sacStatusDescription = AppPropertyProvider.getInstance().getString(
                    SAC_NOTIFICATION_CONSTANTS.SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_MODIFY_PAYMENT_PREFERENCE_DESC);

            INFO(m_logger, "SAC - Modify " + "SacService" + " Send Notification");
            doSendNotification(
                    loggingKey, responseSubscriber, objectId, null, paymentMethodName,
                    sacNotificationName, sacNotificationType, sacStatusDescription);

            response.setResult(responseMulti.getResult());
            response.setResultText(responseMulti.getResultText());
            INFO(m_logger, "SAC - MODIFY " + "SacService" + " Response OK set ");

        } else {
            response.setResult(Long.valueOf(result));
            response.setResultText(resultText);
            INFO(m_logger, "SAC - MODIFY " + "SacService" + " Response Failure !!!!! set ");
        }
        long endTime = System.nanoTime();

        long duration = (endTime - startTime);
        INFO(m_logger, "SAC - " + getClass().getSimpleName() + " Execution Time -  : " + duration);

        return result.intValue();
    }

    /**
     * Determine paymentMethodName from the MtxResponsePaymentMethodInfo -- Look for the default
     * one.
     *
     * @param rspPmtInfo
     * @return
     */
    private String determinePaymentMethodName(MtxResponsePaymentMethodInfo rspPmtInfo) {
        String paymentMethodName = null;
        String paymentMethodNameBkUp = null;

        // Search for default Payment type and get its name.
        List<MtxPaymentMethodInfo> pmtMethodInfoList = rspPmtInfo.getPaymentMethodInfoList();
        if (pmtMethodInfoList != null && !pmtMethodInfoList.isEmpty()) {
            INFO(
                    m_logger, "SAC - MODIFY " + "SacService - payment method info list size :"
                            + pmtMethodInfoList.size());
            for (MtxPaymentMethodInfo mtxPaymentMethodInfo : pmtMethodInfoList) {
                if (mtxPaymentMethodInfo.getIsDefault()) {
                    paymentMethodName = mtxPaymentMethodInfo.getName();
                    break;
                } else if (mtxPaymentMethodInfo.getIsSysDefault()) {
                    paymentMethodNameBkUp = mtxPaymentMethodInfo.getName();
                }
            }
        } else {
            paymentMethodName = "No Payment Methods Registered currently";
            INFO(m_logger, "SAC - MODIFY " + "SacService - NON EXISTING paymentMethodName");
        }
        // Check if this is right to do to use 'default payment method for system
        // initiated charges' in case the default one is missing.
        // And also what to select if Default / System-Default are both not present.
        // Can we choose one randomly (may be first one) or show message "No Payment Methods
        // Registered currently"
        if (paymentMethodName == null && paymentMethodNameBkUp == null) {
            paymentMethodName = "No default Payment Methods selected currently";
            INFO(m_logger, "SAC - MODIFY " + "SacService - NO DEFAULT paymentMethodName defined");
        } else if (paymentMethodName == null) {
            paymentMethodName = paymentMethodNameBkUp;
            INFO(
                    m_logger,
                    "SAC - MODIFY "
                            + "SacService - NO DEFAULT paymentMethodName, choosing system default: "
                            + paymentMethodName);
        } else {
            INFO(m_logger, "SAC - MODIFY " + "SacService - mtxPaymentTokenInfo :");
            INFO(
                    m_logger, "SAC - MODIFY " + "SacService - EXISTING paymentMethodName: "
                            + paymentMethodName);
        }
        return paymentMethodName;
    }

    /**
     * Sac delete payment on resource Id
     *
     * @param response
     * @param subscriberObjectId
     * @param paymentMethodResourceId
     * @return
     * @throws SacServiceException
     */
    public void sacDeletePaymentOnResourceId(SacResponse response,
                                             String subscriberObjectId,
                                             long paymentMethodResourceId)
            throws SacServiceException {

        // m_logger.setLevel(Level.ALL);
        long startTime = System.nanoTime();

        ENTER(m_logger, "sacDeletePaymentOnResourceId");

        INFO(m_logger, "SAC - DELETE " + "SacService" + " step 1 start -  : " + startTime);
        String loggingKey = getLoggingKey(subscriberObjectId);
        String route = getRoute(MatrixxContext.getRequest());
        MtxResponseSubscription subscriber = searchSubscriber(
                loggingKey, route, subscriberObjectId);
        validateResponse(loggingKey, LOG_MESSAGES.LOG_FAILED_TO_QUERY_SUBSCRIBER, subscriber);

        MtxResponsePaymentMethodInfo rspPmtInfo = searchPaymentMethodName(
                loggingKey, route, subscriber.getExternalId());
        INFO(m_logger, "SAC - DELETE " + "SacService - Result paymentInfo:" + rspPmtInfo.toJson());

        String paymentMethodName = null;
        List<MtxPaymentMethodInfo> pmtTokenInfoList = rspPmtInfo.getPaymentMethodInfoList();
        if (pmtTokenInfoList != null && !pmtTokenInfoList.isEmpty()) {
            INFO(
                    m_logger,
                    "SAC - DELETE " + "SacService - tokenlist size :" + pmtTokenInfoList.size());
            for (MtxPaymentMethodInfo pmi : pmtTokenInfoList) {
                if (pmi.getResourceId().longValue() == paymentMethodResourceId) {
                    paymentMethodName = pmi.getName();
                }
            }
        }

        if (StringUtils.isBlank(paymentMethodName)) {
            paymentMethodName = "No paymentMethodName";
            INFO(
                    m_logger,
                    "SAC - DELETE " + "SacService - EXISTING token with No paymentMethodName");
        } else {
            INFO(m_logger, "SAC - DELETE " + "SacService - mtxPaymentTokenInfo :");
            INFO(
                    m_logger, "SAC - DELETE " + "SacService - EXISTING token paymentMethodName: "
                            + paymentMethodName);
        }

        // Call DeletePayment API to delete payment for the given resource id
        MtxResponse deletePaymentRes = deletePaymentOnResourceId(
                subscriberObjectId, paymentMethodResourceId);
        validateResponse(loggingKey, LOG_MESSAGES.LOG_FAILED_TO_DELETE_PAYMENT, deletePaymentRes);
        INFO(
                m_logger, "SAC - DELETE " + "SacService" + " Delete Payment response -  : "
                        + deletePaymentRes.toJson());

        ObjectMapper objMapper = new ObjectMapper();
        objMapper.setSerializationInclusion(Include.NON_NULL);
        // prepare send notification message and if deletepayment is success
        String sacNotificationName = AppPropertyProvider.getInstance().getString(
                SAC_NOTIFICATION_CONSTANTS.SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_DELETE_PAYMENT_NOTIFICATION_NAME);
        String sacNotificationType = AppPropertyProvider.getInstance().getString(
                SAC_NOTIFICATION_CONSTANTS.SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_DELETE_PAYMENT_NOTIFICATION_TYPE);

        String sacStatusDescription = AppPropertyProvider.getInstance().getString(
                SAC_NOTIFICATION_CONSTANTS.SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_DELETE_PAYMENT_STATUS_DESCRIPTION);

        doSendNotification(
                loggingKey, subscriber, subscriberObjectId, null, paymentMethodName,
                sacNotificationName, sacNotificationType, sacStatusDescription);

        response.setResult(deletePaymentRes.getResult());
        response.setResultText(deletePaymentRes.getResultText());
        // Set HTTP status code as 200.
        response.setstatusCode((int) RESULT_CODES.HTTP_SUCCESS);
        response.setstatus(MATRIXX_CONSTANTS.RESULT_TEXT_MTX_SUCCESS);

        long endTime = System.nanoTime();
        long duration = (endTime - startTime);
        INFO(m_logger, "SAC -  DELETE " + "SacService" + " Execution Time : " + duration);
    }

    /**
     * Send Notification after add/modify/delete payment
     *
     * @param subscriber
     * @param objectId
     * @param customerId
     * @param paymentMethodName
     * @param sacNotificationName
     * @param sacNotificationType
     * @param sacStatusDescription
     */
    private void doSendNotification(String loggingKey,
                                    MtxResponseSubscription subscriber,
                                    String objectId,
                                    String customerId,
                                    String paymentMethodName,
                                    String sacNotificationName,
                                    String sacNotificationType,
                                    String sacStatusDescription) {
        INFO(m_logger, "SacService" + " Preparing notification message ");

        this.notificationMsg = prepareNotificationMsg(
                subscriber, objectId, customerId, paymentMethodName, sacNotificationName,
                sacNotificationType, sacStatusDescription);

        INFO(m_logger, "SacService" + " JSON Notification Message : " + notificationMsg);

        INFO(m_logger, "SacService" + " Sending message");
        // MtxMsg respMsg = putOnQueue(this.notificationMsg);
        MtxResponse respMsg = ActiveMQClient.sendSacMessage(
                loggingKey, this.notificationMsg);

        INFO(m_logger, "SacService" + " Result text : " + respMsg.toJson());

    }

    /**
     * Prepare notification message to send nodtification
     *
     * @param objectId
     * @param customerId
     * @param paymentMethodName
     * @param sacNotificationName
     * @param sacNotificationType
     * @param sacStatusDescription
     * @return
     */
    private String prepareNotificationMsg(MtxResponseSubscription responseSubscriber,
                                          String objectId,
                                          String customerId,
                                          String paymentMethodName,
                                          String sacNotificationName,
                                          String sacNotificationType,
                                          String sacStatusDescription) {

        JsonObject jobj = new JsonObject();
        // Adding Status to Jobj
        jobj.addProperty(
                AppPropertyProvider.getInstance().getString(
                        NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_STATUS_KEY),
                AppPropertyProvider.getInstance().getString(
                        NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_STATUS_VALUE));
        // Adding Notification Name to Jobj
        INFO(m_logger, "SacService" + " - name: " + sacNotificationName);
        jobj.addProperty(
                AppPropertyProvider.getInstance().getString(
                        NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_NOTIFICATION_NAME_KEY),
                sacNotificationName);

        // Adding Notification Type to Jobj
        INFO(m_logger, "SacService" + " - notificationType: " + sacNotificationType);
        jobj.addProperty(
                AppPropertyProvider.getInstance().getString(
                        NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_NOTIFICATION_TYPE_KEY),
                sacNotificationType);

        // Adding Notification ID to Jobj
        SimpleDateFormat sdf = new SimpleDateFormat(SacService.date_format);
        String sNowD = sdf.format(new Date());
        INFO(m_logger, "SacService" + " - notificationId Timestamp: " + sNowD);
        String notificationId = objectId + "|" + sNowD;
        INFO(m_logger, "SacService" + " - notificationId: " + notificationId);
        jobj.addProperty(
                AppPropertyProvider.getInstance().getString(
                        NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_NOTIFICATION_ID_KEY),
                notificationId);

        // Adding PaymentMethodName to Jobj
        INFO(m_logger, "SacService" + " - PaymentMethodName: " + paymentMethodName);
        jobj.addProperty(
                AppPropertyProvider.getInstance().getString(
                        NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_PAYMENT_METHOD_NAME_KEY),
                paymentMethodName);

        // Adding paymentPreference to Jobj
        String paymentPreference = "";
        if (responseSubscriber.getAttr() != null) {
            MtxSubscriberExtension subEx = responseSubscriber.getAttr();
            if (("VisibleSubscriberExtension").equalsIgnoreCase(subEx.getContainer().getName())) {
                VisibleSubscriberExtension visibleSubscriberExtension = new VisibleSubscriberExtension(
                        subEx);
                paymentPreference = visibleSubscriberExtension.getPaymentPreference();
            }
        }
        INFO(m_logger, "SacService" + " - paymentPreference: " + paymentPreference);
        jobj.addProperty(
                AppPropertyProvider.getInstance().getString(
                        NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_PAYMENT_PREFERENCE_KEY),
                paymentPreference);

        // Adding CustomerId/ExternalID to Jobj
        String objectExternalId = null;
        if (customerId != null) {
            // customerId from Add payment
            objectExternalId = customerId;
        } else {
            objectExternalId = responseSubscriber.getExternalId();
            INFO(m_logger, "SacService" + " - externalId found : " + objectExternalId);
        }

        jobj.addProperty(
                AppPropertyProvider.getInstance().getString(
                        NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_OBJECT_EXTERNAL_ID_KEY),
                objectExternalId);

        // Adding objectType to Jobj
        INFO(
                m_logger,
                "SacService" + " - ObjectType: " + AppPropertyProvider.getInstance().getInt(
                        NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_OBJECT_TYPE_VALUE));
        jobj.addProperty(
                AppPropertyProvider.getInstance().getString(
                        NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_OBJECT_TYPE_KEY),
                AppPropertyProvider.getInstance().getInt(
                        NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_OBJECT_TYPE_VALUE));

        // Adding statusDescription to Jobj
        String statusDescription = paymentPreference + "|" + sacStatusDescription;
        INFO(m_logger, "SacService" + " statusDescription: " + statusDescription);

        jobj.addProperty(
                AppPropertyProvider.getInstance().getString(
                        NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_STATUS_DESCRIPTION_KEY),
                statusDescription);
        INFO(m_logger, "SacService" + " Notification Object: " + jobj);
        return jobj.toString();
    }

    /**
     * Call Delete Payment API for resourceId
     *
     * @param objectId
     * @param resourceId
     * @return
     * @throws SacServiceException
     */
    private MtxResponse deletePaymentOnResourceId(String objectId, long resourceId)
            throws SacServiceException {
        INFO(m_logger, "SAC - DELETE " + "SacService" + " deletePaymentOnResourceId: ");
        MtxResponse removePayResponse = new MtxResponse();

        // Prepare MtxRequestSubscriberRemovePaymentMethod request and add it to MultiRequest
        MtxRequestSubscriberRemovePaymentMethod removePayRequest = new MtxRequestSubscriberRemovePaymentMethod();
        // Prepare subscriber search data and add it to MtxRequestSubscriberRemovePaymentMethod
        // request
        MtxObjectId objId = new MtxObjectId(objectId);
        MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
        searchData.setObjectId(objId);
        removePayRequest.setSubscriberSearchData(searchData);
        removePayRequest.setResourceId(resourceId);

        // Determine routing data
        String route = getRoute(MatrixxContext.getRequest());
        String loggingKey = getLoggingKey(objectId);
        // calling multi request(MtxRequestSubscriberRemovePaymentMethod)
        INFO(
                m_logger, "SAC - DELETE " + "SacService"
                        + " deletePaymentOnResourceId: Calling MtxRequestSubscriberRemovePaymentMethod");
        removePayResponse = doSubscriberRemovePaymentMethod(loggingKey, route, removePayRequest);

        if (removePayResponse == null
                || removePayResponse.getResult() != RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS) {
            Long resultCode = removePayResponse != null
                    ? removePayResponse.getResult()
                    : RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR;
            String message = "Failed to delete payment "
                    + (removePayResponse != null ? " - " + removePayResponse.getResultText() : "");
            WARN(m_logger, removePayResponse + message);
            throw new SacServiceException(resultCode, message);
        }
        return removePayResponse;

    }

    /**
     * Sac Add payment to subscriber
     *
     * @param output
     * @param objectId
     * @param customerId
     * @param nonce
     * @throws SacServiceException
     */
    public void sacAddPayment(SacResponse output, String objectId, String customerId, String nonce)
            throws SacServiceException {
        ENTER(m_logger, "sacAddPayment");

        long startTime = System.nanoTime();
        INFO(m_logger, "SAC - Add " + "SacService" + " Start Time -  : " + startTime);

        INFO(m_logger, "SAC - Add " + "SacService" + " Call add payment method : ");
        // Determine routing data
        String route = getRoute(MatrixxContext.getRequest());
        String loggingKey = getLoggingKey(objectId);

        MtxResponseSubscription subscriber = searchSubscriber(loggingKey, route, objectId);

        validateResponse(loggingKey, LOG_MESSAGES.LOG_FAILED_TO_QUERY_SUBSCRIBER, subscriber);
        // call add payment method
        MtxResponseAdd addPaymentRes = addPayment(objectId, customerId, nonce, loggingKey, route);

        validateResponse(loggingKey, LOG_MESSAGES.LOG_FAILED_TO_ADD_PAYMENT, addPaymentRes);

        INFO(
                m_logger, "SAC - Add " + "SacService" + " Add Payment response -  : "
                        + addPaymentRes.toXml());
        ObjectMapper objMapper = new ObjectMapper();
        objMapper.setSerializationInclusion(Include.NON_NULL);
        // prepare send notification message and if addpayment is success
        long resourceId = 0;
        String paymentMethodName = null;
        if (addPaymentRes.getResourceIdArray() != null
                && !addPaymentRes.getResourceIdArray().isEmpty()) {
            resourceId = addPaymentRes.getResourceIdArray().get(0);
            paymentMethodName = getPaymentMethodName(objectId, resourceId, loggingKey, route);
        }
        String sacNotificationName = AppPropertyProvider.getInstance().getString(
                SAC_NOTIFICATION_CONSTANTS.SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_ADD_PAYMENT_NOTIFICATION_NAME);
        String sacNotificationType = AppPropertyProvider.getInstance().getString(
                SAC_NOTIFICATION_CONSTANTS.SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_ADD_PAYMENT_NOTIFICATION_TYPE);
        String sacStatusDescription = AppPropertyProvider.getInstance().getString(
                SAC_NOTIFICATION_CONSTANTS.SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_ADD_PAYMENT_STATUS_DESCRIPTION);
        INFO(m_logger, "SAC - Add " + "SacService" + " Send Notification");
        doSendNotification(
                loggingKey, subscriber, objectId, customerId, paymentMethodName,
                sacNotificationName, sacNotificationType, sacStatusDescription);

        output.setResult(addPaymentRes.getResult());
        output.setResultText(addPaymentRes.getResultText());
        result rst = new result();
        rst.setresourceId((int) resourceId);
        if (paymentMethodName != null) {
            rst.setname(paymentMethodName);

        }
        output.setresult(rst);
        // Set HTTP status code as 200.
        output.setstatusCode((int) RESULT_CODES.HTTP_SUCCESS);
        output.setstatus(MATRIXX_CONSTANTS.RESULT_TEXT_MTX_SUCCESS);

        long endTime = System.nanoTime();
        long duration = (endTime - startTime);
        INFO(m_logger, "SAC -  Add " + "SacService" + " Execution Time : " + duration);
    }

    /**
     * Get payment method name for the resourceid
     *
     * @param objectId
     * @param resourceId
     * @param loggingKey
     * @param route
     * @return
     * @throws SacServiceException
     */
    private String getPaymentMethodName(String objectId,
                                        Long resourceId,
                                        String loggingKey,
                                        String route)
            throws SacServiceException {

        MtxResponsePaymentMethodInfo paymentMethodInfoRes = null;

        INFO(m_logger, "SAC -  Add " + "SacService" + "Calling Subscriber query payment method");

        paymentMethodInfoRes = getPaymentMethodInfo(new MtxObjectId(objectId), loggingKey, route);
        try {
            validateResponse(
                    loggingKey, LOG_MESSAGES.LOG_FAILED_TO_QUERY_PAYMENT_METHOD_INFO,
                    paymentMethodInfoRes);
        } catch (SacServiceException e) {
            WARN(m_logger, "SAC -  Add " + "SacService" + "Failed to query payment method");
        }

        String paymentMethodName = null;
        if (paymentMethodInfoRes != null
                && paymentMethodInfoRes.getPaymentMethodInfoList() != null) {
            ArrayList<MtxPaymentMethodInfo> paymentMethodList = paymentMethodInfoRes.getPaymentMethodInfoList();
            for (MtxPaymentMethodInfo paymentMethodInfo : paymentMethodList) {
                if (paymentMethodInfo.getResourceId() != null
                        && paymentMethodInfo.getResourceId().equals(resourceId)
                        && paymentMethodInfo.getName() != null) {
                    paymentMethodName = paymentMethodInfo.getName();
                    INFO(
                            m_logger, "SAC - Add" + "SacService" + " paymentMethodName found -"
                                    + paymentMethodName);
                }
            }
        }
        if (paymentMethodName == null) {
            WARN(m_logger, "SAC - Add" + "SacService" + " paymentMethodName not found");
        }
        return paymentMethodName;
    }

    /**
     * Prepare subscriberAddPaymentMethod request and call subscriberAddPaymentMethod
     *
     * @param objectId
     * @param customerId
     * @param nonce
     * @param route
     * @param loggingKey
     * @return
     * @throws SacServiceException
     */
    private MtxResponseAdd addPayment(String objectId,
                                      String customerId,
                                      String nonce,
                                      String loggingKey,
                                      String route)
            throws SacServiceException {
        INFO(m_logger, "SAC - Add " + "SacService" + " addPayment: ");

        MtxResponseAdd addPaymentResponse = new MtxResponseAdd();

        // Prepare MtxRequestSubscriberAddPaymentMethod request and add it to MultiRequest
        MtxRequestSubscriberAddPaymentMethod addPaymentRequest = new MtxRequestSubscriberAddPaymentMethod();
        // Prepare subscriber search data and add it to MtxRequestSubscriberAddPaymentMethod
        // request
        MtxObjectId objId = new MtxObjectId(objectId);
        MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
        searchData.setObjectId(objId);
        addPaymentRequest.setSubscriberSearchData(searchData);
        addPaymentRequest.setPaymentGatewayOneTimeToken(nonce);
        addPaymentRequest.setPaymentGatewayUserId(customerId);

        // calling (MtxRequestSubscriberAddPaymentMethod)

        INFO(
                m_logger, "SAC - Add " + "SacService"
                        + " sacAddPayment: Calling MtxRequestSubscriberAddPaymentMethod");
        addPaymentResponse = doSubscriberAddPaymentMethod(loggingKey, route, addPaymentRequest);
        return addPaymentResponse;
    }

    /**
     * Validates the response from Matrixx.
     *
     * @param originatingClass
     * @param loggingKey
     * @param errorContext
     * @param response
     * @throws SacServiceException
     *             if response is null or result code is not success.
     */
    protected void validateResponse(String loggingKey, String errorContext, MtxResponse response)
            throws SacServiceException

    {
        if (response == null) {
            ERROR(m_logger, loggingKey + errorContext + " - response is null");
            throw new SacServiceException(
                    RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, errorContext);
        }
        if (!response.getResult().equals(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS)
                && !response.getResultText().equalsIgnoreCase(
                        MATRIXX_CONSTANTS.RESULT_TEXT_MTX_SUCCESS)) {
            String message = errorContext + " - " + response.getResultText();
            ERROR(m_logger, loggingKey + message);
            throw new SacServiceException(response.getResult(), message);
        }
    }

    /**
     * SacCurrentPaymnet to default paymentMethod
     *
     * @param output
     * @param objectId
     * @param resourceId
     * @throws SacServiceException
     */
    public void sacCurrentPayment(SacResponse output, String objectId, long resourceId)
            throws SacServiceException {
        ENTER(m_logger, "sacCurrentPayment");

        long startTime = System.nanoTime();
        INFO(m_logger, "SAC - Current " + "SacService" + " Start Time -  : " + startTime);

        // Determine routing data
        String route = getRoute(MatrixxContext.getRequest());
        String loggingKey = getLoggingKey(objectId);

        MtxResponseSubscription subscriber = searchSubscriber(loggingKey, route, objectId);

        validateResponse(loggingKey, LOG_MESSAGES.LOG_FAILED_TO_QUERY_SUBSCRIBER, subscriber);

        MtxResponse sacCurrentResp = currentPaymentMethod(loggingKey, route, objectId, resourceId);
        validateResponse(loggingKey, LOG_MESSAGES.LOG_FAILED_TO_CURRENT_PAYMENT, sacCurrentResp);
        // prepare send notification message and if currentPayment is success

        ObjectMapper objMapper = new ObjectMapper();
        objMapper.setSerializationInclusion(Include.NON_NULL);

        MtxPaymentMethodInfo currentPaymentMethodInfo = new MtxPaymentMethodInfo();

        String paymentMethodName = null;

        currentPaymentMethodInfo = getCurrentPaymentMethodInfo(objectId, loggingKey, route);

        if (currentPaymentMethodInfo.getName() != null) {
            paymentMethodName = currentPaymentMethodInfo.getName();
        }

        String sacNotificationName = AppPropertyProvider.getInstance().getString(
                SAC_NOTIFICATION_CONSTANTS.SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_CURRENT_PAYMENT_NOTIFICATION_NAME);
        String sacNotificationType = AppPropertyProvider.getInstance().getString(
                SAC_NOTIFICATION_CONSTANTS.SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_CURRENT_PAYMENT_NOTIFICATION_TYPE);

        String sacStatusDescription = AppPropertyProvider.getInstance().getString(
                SAC_NOTIFICATION_CONSTANTS.SAC_NOTIFICATION_ENVIRONMENT_PROPERTY_CURRENT_PAYMENT_STATUS_DESCRIPTION);
        INFO(m_logger, "SAC - Current " + "SacService" + " Send Notification");

        doSendNotification(
                loggingKey, subscriber, objectId, null, paymentMethodName, sacNotificationName,
                sacNotificationType, sacStatusDescription);

        output.setResult(sacCurrentResp.getResult());
        output.setResultText(sacCurrentResp.getResultText());
        result rst = new result();
        rst.setresourceId((int) resourceId);
        if (paymentMethodName != null) {
            rst.setname(paymentMethodName);

        }
        if (currentPaymentMethodInfo.getResourceId() != null) {
            rst.setresourceId(currentPaymentMethodInfo.getResourceId().intValue());
        }
        output.setresult(rst);
        output.setstatusCode((int) RESULT_CODES.HTTP_SUCCESS);
        output.setstatus(MATRIXX_CONSTANTS.RESULT_TEXT_MTX_SUCCESS);

        long endTime = System.nanoTime();
        long duration = (endTime - startTime);
        INFO(m_logger, "SAC -  Current " + "SacService" + " Execution Time : " + duration);
    }

    private MtxPaymentMethodInfo getCurrentPaymentMethodInfo(String objectId,
                                                             String loggingKey,
                                                             String route)
            throws SacServiceException {
        MtxResponsePaymentMethodInfo paymentMethodInfoRes = null;

        INFO(m_logger, "SacService" + "Calling Subscriber query payment method");

        paymentMethodInfoRes = getPaymentMethodInfo(new MtxObjectId(objectId), loggingKey, route);

        validateResponse(
                loggingKey, LOG_MESSAGES.LOG_FAILED_TO_QUERY_PAYMENT_METHOD_INFO,
                paymentMethodInfoRes);

        MtxPaymentMethodInfo currentPaymentMethodInfo = null;
        if (paymentMethodInfoRes != null
                && paymentMethodInfoRes.getPaymentMethodInfoList() != null) {
            ArrayList<MtxPaymentMethodInfo> paymentMethodList = paymentMethodInfoRes.getPaymentMethodInfoList();
            for (MtxPaymentMethodInfo paymentMethodInfo : paymentMethodList) {
                if (paymentMethodInfo.getIsDefault() != null && paymentMethodInfo.getIsDefault()) {
                    currentPaymentMethodInfo = paymentMethodInfo;
                }
            }
        }
        if (currentPaymentMethodInfo == null) {
            throw new SacServiceException(
                    RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,
                    LOG_MESSAGES.LOG_FAILED_TO_GET_CURRENT_PAYMENT_METHOD);
        }
        return currentPaymentMethodInfo;
    }

    /**
     * Prepare subscriberModifyPaymentMethod request and call subscriberModifyPaymentMethod to
     * default payment method
     *
     * @param loggingKey
     * @param route
     * @param objectId
     * @param resourceId
     * @return
     * @throws SacServiceException
     */
    private MtxResponse currentPaymentMethod(String loggingKey,
                                             String route,
                                             String objectId,
                                             long resourceId)
            throws SacServiceException {

        INFO(m_logger, "SAC - Current " + "SacService" + " currentPaymentMethod: ");

        MtxResponse modifySubscriberCurrentPaymentResponse = new MtxResponse();

        // Prepare MtxRequestSubscriberAddPaymentMethod request and add it to MultiRequest
        MtxRequestSubscriberModifyPaymentMethod modifySubscriberCurrentPaymentReq = new MtxRequestSubscriberModifyPaymentMethod();
        // Prepare subscriber search data and add it to MtxRequestSubscriberAddPaymentMethod
        // request
        MtxObjectId objId = new MtxObjectId(objectId);
        MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
        searchData.setObjectId(objId);
        modifySubscriberCurrentPaymentReq.setSubscriberSearchData(searchData);
        modifySubscriberCurrentPaymentReq.setResourceId(resourceId);
        modifySubscriberCurrentPaymentReq.setIsDefault(true);

        // calling (MtxRequestSubscriberModifyPaymentMethod)
        INFO(
                m_logger, "SAC - Add " + "SacService"
                        + " sacCurrent: Calling MtxRequestSubscriberModifyPaymentMethod to make the payment method default");
        modifySubscriberCurrentPaymentResponse = doSubscriberModifyPaymentMethod(
                loggingKey, route, modifySubscriberCurrentPaymentReq);

        return modifySubscriberCurrentPaymentResponse;
    }

    /**
     * SAC Composite API to add ,default payment and generate client token
     *
     * @param input
     * @param output
     * @throws SacServiceException
     * @throws InvalidRequestException
     */
    public void sacSetUpPayment(VisibleRequestSacSetUpPayment input,
                                VisibleResponseSacSetUpPayment output)
            throws SacServiceException, InvalidRequestException {
        INFO(m_logger, "SacService :" + " sacSetUpPayment");
        String externalId = null;
        String customerId = null;
        String nonce = null;
        SacResponse addRes = new SacResponse();
        SacResponse currentRes = new SacResponse();
        // Determine routing data
        String route = getRoute(MatrixxContext.getRequest());
        String loggingKey = getLoggingKey(externalId);
        int paymentResourceId = 0;
        if (input.getSubscriberExternalId() != null) {
            externalId = input.getSubscriberExternalId();
        }
        requestValidator.validateRequest(loggingKey, input);

        MtxResponseSubscription subscriber = searchSubscriberExternal(
                loggingKey, route, externalId);
        validateResponse(loggingKey, LOG_MESSAGES.LOG_FAILED_TO_QUERY_SUBSCRIBER, subscriber);
        String objectId = subscriber.getObjectId().toString();

        if (input.getCustomerId() != null) {
            customerId = input.getCustomerId();
        } else {
            INFO(
                    m_logger, "SacService :" + " sacSetUpPayment : "
                            + "CustomerId is not available in the request. So, using externalId as customerId");

            customerId = externalId;
        }
        nonce = input.getNonce();
        INFO(m_logger, "SacService :" + " sacSetUpPayment : " + "Calling SacAddPayment");

        sacAddPayment(addRes, objectId, customerId, nonce);

        if (input.getDefaultPaymentFlag() != null
                && input.getDefaultPaymentFlag().equalsIgnoreCase("Y")) {
            if (addRes.getresult() != null && addRes.getresult().getresourceId() != null) {
                paymentResourceId = addRes.getresult().getresourceId();

            } else {
                throw new SacServiceException(
                        RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,
                        LOG_MESSAGES.LOG_FAILED_TO_GET_PAYMENT_RESOURCE_ID);
            }
            INFO(m_logger, "SacService :" + " sacSetUpPayment : " + "Calling SacCurrentPayment");

            sacCurrentPayment(currentRes, objectId, paymentResourceId);
        }

        MtxResponsePaymentMethodInfo paymentMethodInfo = getPaymentMethodInfo(
                subscriber.getObjectId(), loggingKey, route);

        validateResponse(
                loggingKey, LOG_MESSAGES.LOG_FAILED_TO_QUERY_PAYMENT_METHOD_INFO,
                paymentMethodInfo);

        INFO(m_logger, "SacService :" + " sacSetUpPayment : " + "Calling getClientToken");

        String clientToken = getClientToken(route, loggingKey);

        output.setClientToken(clientToken);
        output.setPaymentMethodInfo(paymentMethodInfo);
        output.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
        output.setResultText(MATRIXX_CONSTANTS.RESULT_TEXT_MTX_SUCCESS);
    }

    /**
     * Create system client token
     *
     * @param route
     * @param loggingKey
     * @return
     * @throws SacServiceException
     */
    private String getClientToken(String route, String loggingKey) throws SacServiceException {
        INFO(m_logger, "SacService :" + " getClientToken");
        MtxResponseClientToken tokenResponse = new MtxResponseClientToken();
        tokenResponse = createClientToken(route);

        String clientToken = null;
        validateResponse(
                loggingKey, LOG_MESSAGES.LOG_FAILED_TO_GENERATE_CLIENT_TOKEN, tokenResponse);

        DEBUG(m_logger, loggingKey + "Received from MATRIXX\n" + tokenResponse.toJson());
        if (tokenResponse.getPaymentToken() != null) {
            clientToken = tokenResponse.getPaymentToken();
        } else {
            WARN(
                    m_logger, "SacService :" + " getClientToken"
                            + "Payment token is not available in MtxResponseClientToken");
        }

        return clientToken;
    }

    @SuppressWarnings("unchecked")
    public void sacLinkCa(VisibleRequestCaLink request, VisibleResponseCaLink response)
            throws IntegrationServiceException, NoSuchMethodException, SecurityException,
            InstantiationException, IllegalAccessException, IllegalArgumentException,
            InvocationTargetException {
        String loggingKey = getLoggingKey(request.getBeneficiaryExternalId());
        final String methodKey = loggingKey + "sacLinkCa: ";
        INFO(m_logger, methodKey);
        try {
            requestValidator.validateRequest(loggingKey, request);
        } catch (InvalidRequestException e) {
            response.setResult(e.getResultCode());
            response.setResultText(e.getMessage());
            throw e;
        }
        response.setPayerExternalId(request.getPayerExternalId());
        response.setBeneficiaryExternalId(request.getBeneficiaryExternalId());

        MtxResponseSubscription benSubscription = getSubscriptionDetails(
                loggingKey, request.getBeneficiaryExternalId());
        MtxResponseSubscription paySubscription = getSubscriptionDetails(
                loggingKey, request.getPayerExternalId());

        VisibleSubscriberExtension payAttr = (VisibleSubscriberExtension) paySubscription.getAttr();
        if (payAttr == null
                || !PAYMENT_CONSTANTS.AUTOPAY.equalsIgnoreCase(payAttr.getPaymentPreference())) {
            INFO(m_logger, methodKey + LOG_MESSAGES.PAYER_NOT_ON_AUTOPAY);
            response.setResult(RESULT_CODES.HTTP_CONFLICT);
            response.setResultText(LOG_MESSAGES.PAYER_NOT_ON_AUTOPAY);
            throw new SacServiceException(
                    RESULT_CODES.HTTP_CONFLICT, LOG_MESSAGES.PAYER_NOT_ON_AUTOPAY);
        }
        if (!List.of(
                SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE,
                SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_ANNUAL_ACTIVE).contains(
                        paySubscription.getStatusDescription())) {
            INFO(m_logger, methodKey + LOG_MESSAGES.PAYER_NOT_ACTIVE);
            response.setResult(RESULT_CODES.HTTP_CONFLICT);
            response.setResultText(LOG_MESSAGES.PAYER_NOT_ACTIVE);
            throw new SacServiceException(
                    RESULT_CODES.HTTP_CONFLICT, LOG_MESSAGES.PAYER_NOT_ACTIVE);
        }
        if (!List.of(
                SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE,
                SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_ANNUAL_ACTIVE).contains(
                        benSubscription.getStatusDescription())) {
            INFO(m_logger, methodKey + LOG_MESSAGES.BENEFICIARY_NOT_ACTIVE);
            response.setResult(RESULT_CODES.HTTP_CONFLICT);
            response.setResultText(LOG_MESSAGES.BENEFICIARY_NOT_ACTIVE);
            throw new SacServiceException(
                    RESULT_CODES.HTTP_CONFLICT, LOG_MESSAGES.BENEFICIARY_NOT_ACTIVE);
        }
        MtxResponseGroup caGrp = null;

        for (MtxObjectId benGrpId : CommonUtils.emptyIfNull(
                benSubscription.getParentGroupIdArray())) {
            for (MtxObjectId payGrpId : CommonUtils.emptyIfNull(
                    paySubscription.getParentGroupIdArray())) {
                if (benGrpId.getId().equalsIgnoreCase(payGrpId.getId())) {
                    INFO(m_logger, methodKey + "common group found: " + benGrpId.getId());
                    MtxResponseGroup commonGrp = getGroupDetails(loggingKey, benGrpId);
                    INFO(m_logger, methodKey + "common group is of type: " + commonGrp.getTier());
                    if (GROUP_CONSTANTS.GROUP_TIER_CONNECCTED.equalsIgnoreCase(
                            commonGrp.getTier())) {
                        caGrp = commonGrp;
                        INFO(
                                m_logger, methodKey + "ConnectedAccount group found: "
                                        + commonGrp.getObjectId());
                        break;
                    }
                }
            }
            if (caGrp != null) {
                break;
            }
        }

        if (caGrp == null) {
            INFO(m_logger, methodKey + LOG_MESSAGES.PAYER_BENEFICIARY_NO_CA_GROUP);
            response.setResult(RESULT_CODES.HTTP_UNPROCESSABLE_ENTITY);
            response.setResultText(LOG_MESSAGES.PAYER_BENEFICIARY_NO_CA_GROUP);
            throw new SacServiceException(
                    RESULT_CODES.HTTP_UNPROCESSABLE_ENTITY,
                    LOG_MESSAGES.PAYER_BENEFICIARY_NO_CA_GROUP);
        }
        String newLink = String.format(
                GROUP_CONSTANTS.CA_LINK_FORMAT, request.getBeneficiaryExternalId(),
                request.getPayerExternalId());
        VisibleCAGroupExtension caAttr;
        if (caGrp.getAttr() != null) {
            caAttr = (VisibleCAGroupExtension) caGrp.getAttr();
            for (String link : CommonUtils.emptyIfNull(caAttr.getRelationshipArray())) {
                if (!link.contains(request.getBeneficiaryExternalId())) {
                    continue;
                }

                for (String fld : link.split(GROUP_CONSTANTS.CA_RELATION_SEPARATOR)) {
                    if (fld.startsWith(GROUP_CONSTANTS.CA_BENEFICIARY_FLD_NAME)) {
                        String[] fldBits = fld.split(GROUP_CONSTANTS.CA_FIELD_SEPARATOR);
                        String fldValue = "";
                        if (fldBits.length >= 2) {
                            fldValue = fldBits[1];
                        }
                        if (fldValue.trim().equalsIgnoreCase(
                                request.getBeneficiaryExternalId().trim())) {
                            String msg = LOG_MESSAGES.BENEFICIARY_HAS_CA_LINK + " Current Link: "
                                    + link;
                            INFO(m_logger, methodKey + msg);
                            response.setResult(RESULT_CODES.HTTP_CONFLICT);
                            response.setResultText(msg);
                            throw new SacServiceException(RESULT_CODES.HTTP_CONFLICT, msg);
                        }
                    }
                }
            }
        } else {
            caAttr = new VisibleCAGroupExtension();
        }

        MtxRequestMulti multiRequest = new MtxRequestMulti();
        // @formatter:off
        MtxRequestGroupModifyBuilder grpModBuild = (new MtxRequestGroupModifyBuilder())
                .withGroupOid(caGrp.getObjectId())
                .withAttr(caAttr)
                .withRelationship(newLink);
        multiRequest.getRequestListAppender().add(grpModBuild.build());
        VisibleSubscriberExtensionBuilder benAttrBuilder = (new VisibleSubscriberExtensionBuilder())
                .withPayerExternalId(request.getPayerExternalId());
        MtxRequestSubscriptionModifyBuilder benModBuilder = (new MtxRequestSubscriptionModifyBuilder())
                .withSubscriberExternalId(request.getBeneficiaryExternalId().trim())
                .withAttr(benAttrBuilder.build());
        multiRequest.getRequestListAppender().add(benModBuilder.build());
        // @formatter:on

        MtxResponseMulti multiResponse = multiRequest(loggingKey, multiRequest);

        CommonUtils.validateResponse(
                loggingKey, LOG_MESSAGES.FAILED_TO_ADD_CA_LINK, m_logger, SacServiceException.class,
                multiResponse);

        response.setResult(RESULT_CODES.MTX_SUCCESS);
        String msg = "|Link created " + newLink + "|PayerExternalId " + request.getPayerExternalId()
                + " added to attributes of beneficiary " + request.getBeneficiaryExternalId();
        response.setResultText(multiResponse.getResultText() + msg);
        INFO(m_logger, methodKey + msg);
    }

    @SuppressWarnings("unchecked")
    public void sacUnlinkCa(VisibleRequestCaUnlink request, VisibleResponseCaUnlink response)
            throws IntegrationServiceException, NoSuchMethodException, SecurityException,
            InstantiationException, IllegalAccessException, IllegalArgumentException,
            InvocationTargetException {
        String loggingKey = getLoggingKey(request.getBeneficiaryExternalId());
        final String methodKey = loggingKey + "sacUnlinkCa: ";
        INFO(m_logger, methodKey);
        try {
            requestValidator.validateRequest(loggingKey, request);
        } catch (InvalidRequestException e) {
            response.setResult(e.getResultCode());
            response.setResultText(e.getMessage());
            throw e;
        }
        response.setBeneficiaryExternalId(request.getBeneficiaryExternalId());

        MtxResponseSubscription benSubscription = getSubscriptionDetails(
                loggingKey, request.getBeneficiaryExternalId());
        VisibleSubscriberExtension benAttr = (VisibleSubscriberExtension) benSubscription.getAttr();

        MtxResponseGroup caGrp = getCaGroup(loggingKey, benSubscription);
        MtxResponseSubscription payerSubscription = null;

        if (caGrp == null && StringUtils.isNotBlank(request.getPayerExternalId())) {
            INFO(
                    m_logger,
                    methodKey + LOG_MESSAGES.BENEFICIARY_NO_CA_GROUP_SEARCH_PAYER_AS_PER_REQUEST);
            payerSubscription = getSubscriptionDetails(loggingKey, request.getPayerExternalId());
        }
        
        if (caGrp == null && payerSubscription == null && StringUtils.isNotBlank(benAttr.getPayerExternalId())) {
            INFO(m_logger, methodKey + LOG_MESSAGES.BENEFICIARY_NO_CA_GROUP_SEARCH_PAYER_GROUP);
            payerSubscription = getSubscriptionDetails(loggingKey, benAttr.getPayerExternalId());
        }            

        if (caGrp == null && payerSubscription != null
                && payerSubscription.getParentGroupCount() > 0) {
            caGrp = getCaGroup(loggingKey, payerSubscription);
        }

        if (caGrp == null && StringUtils.isNotBlank(benAttr.getPayerExternalId())) {
            INFO(m_logger, methodKey + LOG_MESSAGES.BENEFICIARY_NO_CA_GROUP_CLEAR_ATTR);
        }else if (caGrp == null) {
            INFO(m_logger, methodKey + LOG_MESSAGES.PAYER_BENEFICIARY_NO_CA_GROUP);
            response.setResult(RESULT_CODES.HTTP_UNPROCESSABLE_ENTITY);
            response.setResultText(LOG_MESSAGES.PAYER_BENEFICIARY_NO_CA_GROUP);
            throw new SacServiceException(
                    RESULT_CODES.HTTP_UNPROCESSABLE_ENTITY,
                    LOG_MESSAGES.PAYER_BENEFICIARY_NO_CA_GROUP);
        }else if (caGrp.getAttr() == null) {
            INFO(m_logger, methodKey + LOG_MESSAGES.NO_LINKS_IN_CA_GROUP);
            response.setResult(RESULT_CODES.HTTP_UNPROCESSABLE_ENTITY);
            response.setResultText(LOG_MESSAGES.NO_LINKS_IN_CA_GROUP);
            throw new SacServiceException(
                    RESULT_CODES.HTTP_UNPROCESSABLE_ENTITY, LOG_MESSAGES.NO_LINKS_IN_CA_GROUP);
        }
        
        VisibleCAGroupExtension caAttr = (VisibleCAGroupExtension) caGrp.getAttr();
        ArrayList<String> newLinkList = new ArrayList<String>();
        String linkToDrop = "";
        for (String link : CommonUtils.emptyIfNull(caAttr.getRelationshipArray())) {
            if (!link.contains(request.getBeneficiaryExternalId())) {
                newLinkList.add(link);
                continue;
            }
            for (String fld : link.split(GROUP_CONSTANTS.CA_RELATION_SEPARATOR)) {
                if (fld.startsWith(GROUP_CONSTANTS.CA_BENEFICIARY_FLD_NAME)) {
                    String[] fldBits = fld.split(GROUP_CONSTANTS.CA_FIELD_SEPARATOR);
                    String fldValue = "";
                    if (fldBits.length >= 2) {
                        fldValue = fldBits[1];
                    }
                    if (fldValue.trim().equalsIgnoreCase(
                            request.getBeneficiaryExternalId().trim())) {
                        linkToDrop = link;
                        INFO(m_logger, methodKey + "Link to be removed: " + linkToDrop);
                        break;
                    } else {
                        newLinkList.add(link);
                    }
                }
            }
        }
        
        if (StringUtils.isBlank(linkToDrop) && StringUtils.isNotBlank(benAttr.getPayerExternalId())) {
            INFO(m_logger, methodKey + LOG_MESSAGES.NO_CA_LINKS_FOR_BENEFICIARY_CLEAR_ATTR);
        }else if (StringUtils.isBlank(linkToDrop)) {
            response.setResult(RESULT_CODES.MTX_SUCCESS);
            String msg = LOG_MESSAGES.NO_CA_LINKS_FOR_BENEFICIARY;
            INFO(m_logger, methodKey + msg);
            response.setResultText(msg);
            return;
        }

        if (newLinkList.isEmpty() && StringUtils.isNotBlank(linkToDrop)) {
            INFO(m_logger, methodKey + "Cleared only relationship from the group: " + linkToDrop);
            caAttr.getRelationshipArrayAppender().clear();
        } else {
            caAttr.getRelationshipArrayAppender().addAll(newLinkList);
            INFO(m_logger, methodKey + "Dropped relationship from the group: " + linkToDrop);
            INFO(
                    m_logger,
                    methodKey + "Relationships that will remain in the group: " + linkToDrop);
        }
        MtxRequestMulti multiRequest = new MtxRequestMulti();
        // @formatter:off
        MtxRequestGroupModifyBuilder grpModBuild = (new MtxRequestGroupModifyBuilder())
                .withGroupOid(caGrp.getObjectId())
                .withAttr(caAttr);
        multiRequest.getRequestListAppender().add(grpModBuild.build());
        
        if(StringUtils.isNotBlank(benAttr.getPayerExternalId())) {
            VisibleSubscriberExtensionBuilder benAttrBuilder = (new VisibleSubscriberExtensionBuilder())
                    .dropPayerExternalId();
            
            MtxRequestSubscriptionModifyBuilder benModBuilder = (new MtxRequestSubscriptionModifyBuilder())
                    .withSubscriberExternalId(request.getBeneficiaryExternalId().trim())
                    .withAttr(benAttrBuilder.build());
            multiRequest.getRequestListAppender().add(benModBuilder.build());            
        }
        
        MtxResponseMulti multiResponse = multiRequest(loggingKey, multiRequest);
        
        CommonUtils.validateResponse(
                loggingKey, LOG_MESSAGES.FAILED_TO_REMOVE_CA_LINK, m_logger, SacServiceException.class,
                multiResponse);
        
        response.setResult(RESULT_CODES.MTX_SUCCESS);
        String msg = "|Link removed " + linkToDrop+"|PayerExternalId removed from beneficiary "+request.getBeneficiaryExternalId();
        response.setResultText(multiResponse.getResultText() + msg);

        INFO(m_logger, methodKey + msg);
    }

    private MtxResponseGroup getCaGroup(String loggingKey,
                                        MtxResponseSubscription subscription) 
        throws IntegrationServiceException, NoSuchMethodException, SecurityException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        final String methodKey = loggingKey + "getCaGroup: ";
        MtxResponseGroup caGrp = null;
        for (MtxObjectId benGrpId : CommonUtils.emptyIfNull(
                subscription.getParentGroupIdArray())) {
            MtxResponseGroup commonGrp = getGroupDetails(loggingKey, benGrpId);
            INFO(m_logger, methodKey + "Group is of type: " + commonGrp.getTier());
            if (GROUP_CONSTANTS.GROUP_TIER_CONNECCTED.equalsIgnoreCase(commonGrp.getTier())) {
                caGrp = commonGrp;
                INFO(
                        m_logger,
                        methodKey + "ConnectedAccount group found: " + commonGrp.getObjectId());
                break;
            }

            if (caGrp != null) {
                break;
            }
        }
        return caGrp;        
    }
    
    private MtxResponseSubscription getSubscriptionDetails(String loggingKey,
                                                           String subscriptionExternalId)
            throws IntegrationServiceException, NoSuchMethodException, SecurityException,
            InstantiationException, IllegalAccessException, IllegalArgumentException,
            InvocationTargetException {

        MtxResponseSubscription subscription = querySubscriptionData(
                loggingKey, subscriptionExternalId);
        CommonUtils.validateResponse(
                loggingKey, EXCEPTION_MESSAGES.FAILED_TO_QUERY_SUBSCRIPTION, m_logger,
                SacServiceException.class, subscription);

        return subscription;
    }

    private MtxResponseGroup getGroupDetails(String loggingKey, MtxObjectId oid)
            throws IntegrationServiceException, NoSuchMethodException, SecurityException,
            InstantiationException, IllegalAccessException, IllegalArgumentException,
            InvocationTargetException {
        MtxResponseGroup respMsg = querySubscriptionGroup(loggingKey, oid);

        CommonUtils.validateResponse(
                loggingKey, LOG_MESSAGES.LOG_FAILED_TO_QUERY_SUBSCRIBER_GROUPS, m_logger,
                PaymentAdviceException.class, respMsg);
        return respMsg;
    }

}
