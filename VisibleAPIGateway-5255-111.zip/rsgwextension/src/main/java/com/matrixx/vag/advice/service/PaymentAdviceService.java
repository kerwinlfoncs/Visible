package com.matrixx.vag.advice.service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.matrixx.datacontainer.MtxDate;
import com.matrixx.datacontainer.MtxObjectId;
import com.matrixx.datacontainer.MtxPhone;
import com.matrixx.datacontainer.MtxTimestamp;
import com.matrixx.datacontainer.mdc.*;
import com.matrixx.platform.MatrixxContext;
import com.matrixx.vag.advice.model.*;
import com.matrixx.vag.advice.model.ChangeServiceDataStage.BillCycle;
import com.matrixx.vag.advice.model.ChangeServiceDataStage.NextCycleDetails;
import com.matrixx.vag.advice.model.VisibleReverseCreditInternal.DontReverseCode;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.Constants.*;
import com.matrixx.vag.common.request.builder.MtxPurchasedOfferDataBuilder;
import com.matrixx.vag.config.AppPropertyParser;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.exception.CommonUtilsException;
import com.matrixx.vag.exception.IntegrationServiceException;
import com.matrixx.vag.exception.InvalidRequestException;
import com.matrixx.vag.exception.PaymentAdviceException;
import com.matrixx.vag.service.IntegrationService;
import com.matrixx.vag.tax.client.TaxApiClient;
import com.matrixx.vag.tax.model.ServiceTaxRequest;
import com.matrixx.vag.tax.model.ServiceTaxResponse;
import org.apache.commons.configuration2.ex.ConfigurationException;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.beans.IntrospectionException;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.AbstractMap.SimpleEntry;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.matrixx.platform.LogUtils.*;

@SuppressWarnings("unused")
@Configuration
public class PaymentAdviceService extends IntegrationService {

    private static final String DELTA_IMPACT_ASIS_PROMOS = "deltaImpactOldPromos";
    private static final String DELTA_IMPACT_TOBE_PROMOS = "deltaImpactNewPromos";
    private static final String ASIS_PROMO_CLASS_CODES = "oldPromoClassCodes";
    private static final String TOBE_PROMO_CLASS_CODES = "newPromoClassCodes";
    private static final String TOBE_PROMO_IGNORE_ERROR = "newPromoIgnoreError";

    private static final Logger m_logger = LoggerFactory.getLogger(PaymentAdviceService.class);

    RequestValidator requestValidator;

    @Bean(name = "PaymentAdviceService")
    PaymentAdviceService getService() {
        return new PaymentAdviceService();
    }

    /**
     * Constructor.
     */
    public PaymentAdviceService() {
        this.requestValidator = new RequestValidator();
    }

    /**
     * AOP Response does not provide Offer/CI level breakup for paNow amount. PayNow amounts need
     * offer level breakup to structure recharge calls with correct reason codes for GL. This method
     * can not be implemented without changes to AOP Output
     *
     * @param loggingKey
     * @param route
     * @param purchaseRequest
     * @param subscriber
     * @return
     * @throws Exception
     */

    public VisibleResponsePurchaseAdvice getPurchaseAdvice(String loggingKey,
                                                           String route,
                                                           VisibleMultiRequestPurchaseService purchaseRequest,
                                                           MtxResponseSubscription subscriber)
            throws Exception {
        AdviceDataStage stage = new AdviceDataStage(
                subscriber, AdviceDataStage.Advice.PURCHASE, null, true);
        stage.setPurchaseRequest(purchaseRequest);
        for (VisiblePurchaseInfo vpi : purchaseRequest.getPurchaseInfo()) {
            stage.addCiListInPurchaseService(
                    vpi.getPurchaseServiceInfo().getServiceOfferExternalId());
        }

        // 2. Get Initial Paynow amounts
        updateDefaultPaynowAmountsPurchaseServiceMulti(loggingKey, route, stage, purchaseRequest);

        // 4.5 payment stage taxes
        // updateTaxesInPaynowStage(loggingKey, route, builder);
        PurchaseAdviceUtils.updateTaxesInServiceStage(loggingKey, route, stage);

        // 4.calculate Aop Amounts
        MtxResponseSubscription subscription = getSubscriptionDetails(
                loggingKey, purchaseRequest.getSubscriberExternalId());
        stage = updateCreditsForPaymentAndPurchaseAdvice(loggingKey, route, subscription, stage);

        // 5.update taxes
        stage = AdviceUtils.updateOfferDetails(loggingKey, route, stage);

        // 6.update payable amounts
        AdviceUtils.updatePayableAmountsForProration(loggingKey, route, stage);

        // 7.update credit taxes
        AdviceUtils.updateCreditTaxDetails(loggingKey, route, stage, subscription);

        // 8. update group details
        updateSubscriptionGroups(loggingKey, route, subscriber, stage);

        VisibleResponsePurchaseAdvice output = new VisibleResponsePurchaseAdvice();
        stage.setResultCode(RESULT_CODES.MTX_SUCCESS);
        stage.setResultText(MATRIXX_CONSTANTS.RESULT_TEXT_MTX_SUCCESS);
        PurchaseAdviceUtils.updatePurchaseAdviceOutput(loggingKey, route, stage, output);

        return output;
    }

    /**
     * Get AOP when called as REST endpoint
     *
     * @param input
     * @param output
     * @throws Exception
     */
    public void getAOP(VisibleRequestPaymentAdviceService input,
                       VisibleResponsePaymentAdviceService output)
            throws Exception {
        final String methodName = "getAOP:";
        String loggingKey = getLoggingKey(input.getSubscriberExternalId());
        String route = getRoute(MatrixxContext.getRequest());

        AdviceDataStage stage = getAOPStage(loggingKey, route, input, null, null);

        output = updateAOPOutput(loggingKey, route, stage, output);
    }

    public void getAOPForAutopay(VisibleRequestPaymentAdviceService input,
                                 VisibleResponsePaymentAdviceService output,
                                 SubscriptionResponse subscriptionResponse)
            throws Exception {
        final String methodName = "getAOPForAutopay:";
        String loggingKey = getLoggingKey(input.getSubscriberExternalId());
        String route = getRoute(MatrixxContext.getRequest());

        AdviceDataStage stage = getAOPStage(loggingKey, route, input, subscriptionResponse, null);

        output = updateAOPOutput(loggingKey, route, stage, output);
    }

    public AdviceDataStage getAOPStage(String loggingKey,
                                       String route,
                                       VisibleRequestPaymentAdviceService input,
                                       SubscriptionResponse subscriptionResponse,
                                       MtxResponseSubscription subscription)
            throws Exception {
        final String methodKey = loggingKey + "getAOPStage: ";

        requestValidator.validateRequest(loggingKey, input);

        if (subscription == null) {
            subscription = getSubscriptionDetails(loggingKey, input.getSubscriberExternalId());
        }

        if (subscriptionResponse == null) {
            subscriptionResponse = querySubscriptionByExternalId(
                    loggingKey, route, input.getSubscriberExternalId());
        }

        requestValidator.validateRequest(loggingKey, input, subscriptionResponse);

        CommonUtils.validateResponse(
                loggingKey, LOG_MESSAGES.FAILED_TO_QUERY_SERVICE_SUBSCRIPTION, m_logger,
                PaymentAdviceException.class, subscriptionResponse);

        AdviceDataStage stage = new AdviceDataStage(
                subscriptionResponse, AdviceDataStage.Advice.PAYMENT, input.getTaxGeoCode(),
                GENERIC_CONSTANTS.YES.equalsIgnoreCase("" + input.getIncludeTaxDetails()));
        stage.setTotalEstimatedAmount(BigDecimal.ZERO);

        AdviceUtils.updateServiceStageFromSubscription(
                loggingKey, route, stage, subscriptionResponse);

        // 2. Get recurring charge estimate
        MtxResponseRecurringChargeInfo estimate = getRecurringChargeEstimateFromExternalId(
                loggingKey, input.getSubscriberExternalId());
        INFO(m_logger, methodKey + " MATRIXX Estimate : " + estimate.toJson());
        CommonUtils.validateResponse(
                loggingKey, LOG_MESSAGES.FAILED_RECURRING_CHARGE_ESTIMATE, m_logger,
                PaymentAdviceException.class, estimate);

        boolean hasServiceStages = !stage.getPayNowMap().values().isEmpty();
        // requestValidator.validateRequest(
        // loggingKey, input, subscriptionResponse, estimate, hasServiceStages);
        stage.setRecurringChargeInfo(estimate);

        // 3. Get Initial Paynow amounts
        updateDefaultPaynowAmountsForAop(loggingKey, route, stage, estimate, subscriptionResponse);

        updatePayNowFromSubscriberForAOP(loggingKey, subscriptionResponse, stage);

        // 4. update group details
        updateSubscriptionGroups(loggingKey, route, subscriptionResponse, stage);
        updatePayerDetails(loggingKey, stage);

        // 5. calculate and update paynow taxes here
        PaymentAdviceUtils.updateTaxesInServiceStage(loggingKey, route, stage);

        // 6.calculate Aop Amounts
        stage = updateCreditsForPaymentAndPurchaseAdvice(loggingKey, route, subscription, stage);

        // 7.update offer Detrails
        stage = AdviceUtils.updateOfferDetails(loggingKey, route, stage);

        // 8. update payable amounts
        AdviceUtils.updatePayableAmountsForProration(loggingKey, route, stage);

        // 9.update promotion taxes
        AdviceUtils.updateCreditTaxDetails(loggingKey, route, stage, subscription);

        // 10. update device details
        updateDeviceDetails(loggingKey, route, subscriptionResponse, stage);

        stage.setResultCode(estimate.getResult());
        stage.setResultText(estimate.getResultText());

        return stage;
    }

    private AdviceDataStage getNextCyclePaymentAdvice(String loggingKey,
                                                      String route,
                                                      VisibleRequestChangeServiceAdvice request,
                                                      AdviceDataStage changeAdvicestage,
                                                      SubscriptionResponse subscriptionResponse,
                                                      MtxResponseSubscription subscription)
            throws Exception {
        final String methodKey = loggingKey + " getNextCyclePaymentAdvice: ";

        INFO(
                m_logger, methodKey
                        + "Build payment advice by replacing as-is base service with to-be base service");

        AdviceDataStage aopStage = new AdviceDataStage(
                subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, true);
        for (SubscriberGroup sg : changeAdvicestage.getSubscriberGroupList()) {
            aopStage.appendSubscriberGroupList(sg);
        }
        aopStage.setTotalEstimatedAmount(BigDecimal.ZERO);
        aopStage.setPayerExternalId(changeAdvicestage.getPayerExternalId());
        aopStage.setPayerGeoCode(changeAdvicestage.getPayerGeoCode());

        AdviceUtils.updateServiceStageFromSubscription(
                loggingKey, route, aopStage, subscriptionResponse);

        // 1. Get Initial Paynow amounts
        updateDefaultPaynowAmountsForAop(
                loggingKey, route, aopStage, changeAdvicestage.getRecurringChargeInfo(),
                subscriptionResponse);
        // 2.Remove stage for base servce and addon for future base service
        replaceBaseServiceStageWithFuturePaymentAdviceStage(
                loggingKey, route, aopStage, changeAdvicestage, request, subscriptionResponse);
        updatePayNowFromSubscriberForAOP(loggingKey, subscriptionResponse, aopStage);

        aopStage.setAvailableMainBalanceAmount(
                changeAdvicestage.getAvailableMainBalanceAmount().subtract(
                        changeAdvicestage.getConsumableMainBalanceAmount()));
        INFO(
                m_logger,
                methodKey + "New mainbalance by reducing mainbalance consumed by delta stage: "
                        + aopStage.getAvailableMainBalanceAmount());

        // 3. calculate and update paynow taxes here
        PaymentAdviceUtils.updateTaxesInServiceStage(loggingKey, route, aopStage);
        // 4.calculate Aop Amounts
        aopStage = calculatePaymentAdviceAmountsWithFuturePromo(
                loggingKey, route, subscription, request, aopStage, changeAdvicestage);

        // 5.update offer Detrails
        aopStage = AdviceUtils.updateOfferDetails(loggingKey, route, aopStage);

        // 6. update payable amounts
        AdviceUtils.updatePayableAmountsForProration(loggingKey, route, aopStage);

        // 7.update promotion taxes
        AdviceUtils.updateCreditTaxDetails(loggingKey, route, aopStage, subscriptionResponse);

        return aopStage;
    }

    private AdviceDataStage getNextCyclePaymentAdvice(String loggingKey,
                                                      String route,
                                                      VisibleRequestQuoteAdviceService request,
                                                      AdviceDataStage quoteAdvicestage,
                                                      MtxResponseSubscription subscription)
            throws Exception {
        final String methodKey = loggingKey + " getNextCyclePaymentAdvice: ";

        SubscriptionResponse subscriptionResponse = querySubscriptionByExternalId(
                loggingKey, route, request.getSubscriberExternalId());

        INFO(m_logger, methodKey + "Build payment advice with existing and future services.");

        AdviceDataStage aopStage = new AdviceDataStage(
                subscriptionResponse, AdviceDataStage.Advice.PAYMENT, null, true);

        if (subscriptionResponse.getBillingCycle() == null) {
            BillingCycleInfo billingCycle = new BillingCycleInfo();
            billingCycle.setBillingCycleId(BigInteger.valueOf(request.getBillingCycleId()));
            billingCycle.setDateOffset(Long.valueOf(request.getBillingCycleOffset()));
            billingCycle.setCurrentPeriodStartTime(quoteAdvicestage.getCycleStartTime());

            MtxResponsePricingBillingCycle pricingBillingCycle = getPricingBillingCycle(
                    loggingKey, BigInteger.valueOf(request.getBillingCycleId()));

            MtxPricingBillingCycleDetailInfo detailInfo = new MtxPricingBillingCycleDetailInfo();
            detailInfo.setDatePolicy(pricingBillingCycle.getBillingCycleInfo().getDatePolicy());
            detailInfo.setInterval(pricingBillingCycle.getBillingCycleInfo().getInterval());
            detailInfo.setPeriod(pricingBillingCycle.getBillingCycleInfo().getPeriod());
            detailInfo.setId(pricingBillingCycle.getBillingCycleInfo().getId());
            billingCycle.setDetails(detailInfo);
            billingCycle.setDatePolicy(pricingBillingCycle.getBillingCycleInfo().getDatePolicy());

            subscriptionResponse.setBillingCycle(billingCycle);

            MtxTimestamp billingCycleEndTime = CommonUtils.getCycleEndDate(
                    quoteAdvicestage.getCycleStartTime(), subscription.getTimeZone(),
                    pricingBillingCycle.getBillingCycleInfo().getPeriod(),
                    pricingBillingCycle.getBillingCycleInfo().getInterval(),
                    subscriptionResponse.getBillingCycle());
            billingCycle.setCurrentPeriodEndTime(billingCycleEndTime);
        }
        for (SubscriberGroup sg : quoteAdvicestage.getSubscriberGroupList()) {
            aopStage.appendSubscriberGroupList(sg);
        }
        aopStage.setPayerExternalId(quoteAdvicestage.getPayerExternalId());
        aopStage.setPayerGeoCode(quoteAdvicestage.getPayerGeoCode());
        aopStage.setTotalEstimatedAmount(BigDecimal.ZERO);
        AdviceUtils.updateServiceStageFromSubscription(
                loggingKey, route, aopStage, subscriptionResponse);
        // 3. Get Initial Paynow amounts
        if (quoteAdvicestage.getRecurringChargeInfo() != null) {
            updateDefaultPaynowAmountsForAop(
                    loggingKey, route, aopStage, quoteAdvicestage.getRecurringChargeInfo(),
                    subscriptionResponse);
        }
        addServiceStageFromQuoteAdvice(
                loggingKey, route, aopStage, quoteAdvicestage, subscriptionResponse);
        if (aopStage.getPayNowMap() == null || aopStage.getPayNowMap().isEmpty()) {
            return null;
        }
        updatePayNowFromSubscriberForAOP(loggingKey, subscriptionResponse, aopStage);
        aopStage.setAvailableMainBalanceAmount(
                quoteAdvicestage.getAvailableMainBalanceAmount().subtract(
                        quoteAdvicestage.getConsumableMainBalanceAmount()));

        // 4. calculate and update paynow taxes here
        // updateTaxesInPaynowStage(loggingKey, route, stage);
        PaymentAdviceUtils.updateTaxesInServiceStage(loggingKey, route, aopStage);
  
        // 6.calculate Aop Amounts
        aopStage = calculatePaymentAmountsSubtractQuoteAmounts(
                loggingKey, route, subscription, aopStage, quoteAdvicestage);

        // 7.update offer Detrails
        aopStage = AdviceUtils.updateOfferDetails(loggingKey, route, aopStage);

        // 8. update payable amounts
        AdviceUtils.updatePayableAmountsForProration(loggingKey, route, aopStage);

        // 9.update promotion taxes
        AdviceUtils.updateCreditTaxDetails(loggingKey, route, aopStage, subscriptionResponse);

        return aopStage;
    }

    private void updatePayNowFromSubscriberForAOP(String loggingKey,
                                                  SubscriptionResponse subscriptionResponse,
                                                  AdviceDataStage stage) {
        final String methodKey = loggingKey + " updatePayNowFromSubscriberForAOP: ";
        MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
        searchData.setExternalId(stage.getSubscriptionExternalId());
        updateDataFromSubscriptionResponse(loggingKey, stage, subscriptionResponse);
        if (subscriptionResponse.getPurchasedOfferArray() == null
                || subscriptionResponse.getPurchasedOfferArray().isEmpty()) {
            // Payment advice for future offers only. There are no current enrollments.
            return;
        }

        for (ServiceStage ps : stage.getPayNowMap().values()) {
            for (MtxPurchasedOfferInfo poi : subscriptionResponse.getPurchasedOfferArray()) {
                if (ps.getCatalogItemExternalId().equals(poi.getCatalogItemExternalId())
                        && CommonUtils.minusHighIfNull(
                                ps.getOfferResourceId()).longValue() == poi.getResourceId().longValue()) {
                    ps.setPurchasedOfferInfo(poi);
                    VisiblePurchasedOfferExtension poe = (VisiblePurchasedOfferExtension) poi.getAttr();
                    if (StringUtils.isNotBlank(poe.getTaxDetails())) {
                        ServiceTaxResponse taxResponse;
                        try {
                            taxResponse = CommonUtils.getObjectMapper().readValue(
                                    poe.getTaxDetails(), ServiceTaxResponse.class);
                            ps.setGrossPrice(taxResponse.getGrossPrice());
                            ps.setPrevTaxResponse(taxResponse);
                            INFO(
                                    m_logger,
                                    methodKey
                                            + "Updated Paynow Stage from Subscriber's VisiblePurchasedOfferExtension records: "
                                            + ps.toJson());
                        } catch (Exception e) {
                            WARN(
                                    m_logger,
                                    methodKey
                                            + "TaxResponse from VisiblePurchasedOfferExtension for CI "
                                            + StringUtils.SPACE + poi.getCatalogItemExternalId()
                                            + StringUtils.SPACE
                                            + "could not be parsed. GrossPrice and VendorPayableNonProrated will be defaulted and may not be accurate."
                                            + StringUtils.SPACE + ExceptionUtils.getStackTrace(e));
                        }
                    }

                    if (poe.getPaidCycleStartDate() != null) {
                        ps.setEffectivePaidCycleStartDate(poe.getPaidCycleStartDate());
                    } else if (stage.getAdviceFor() == AdviceDataStage.Advice.PAYMENT) {
                        ps.setEffectivePaidCycleStartDate(
                                new MtxDate(
                                        subscriptionResponse.getBillingCycle().getCurrentPeriodStartTime().longValue()));
                    }
                }
            }
        }
    }

    private void replaceBaseServiceStageWithFuturePaymentAdviceStage(String loggingKey,
                                                                     String route,
                                                                     AdviceDataStage aopStage,
                                                                     AdviceDataStage changeAdvicestage,
                                                                     VisibleRequestChangeServiceAdvice request,
                                                                     SubscriptionResponse subscription)
            throws CommonUtilsException, IntrospectionException, IntegrationServiceException {
        final String methodKey = loggingKey
                + " replaceBaseServiceStageWithFuturePaymentAdviceStage: ";
        INFO(m_logger, loggingKey + methodKey);

        CiResourceIdPair baseCiPair = null;
        ServiceStage newBaseService = null;
        MtxTimestamp baseNextCycleStart = null;

        for (CiResourceIdPair key : CommonUtils.emptyIfNull(aopStage.getPayNowMap().keySet())) {
            baseCiPair = key;
            ServiceStage curStage = aopStage.getPayNowMap().get(key);
            baseNextCycleStart = curStage.getNextCycleStartTime();
            if (OFFER_CONSTANTS.OFFER_TYPE_BASE.equalsIgnoreCase(curStage.getOfferType())) {
                // Call new service stage creation
                newBaseService = getNewServiceStageForPaymentAdvice(
                        loggingKey, route, aopStage, subscription,
                        request.getNewCatalogItemExternalId(), request.getGrossPrice(),
                        request.getDiscountPrice(), baseNextCycleStart, null);
                break;
            }
        }

        if (newBaseService.getDiscountPrice() != null
                && newBaseService.getDiscountPrice().signum() > 0) {
            INFO(
                    m_logger, methodKey + "Adding service stage for "
                            + newBaseService.getCatalogItemExternalId());
            aopStage.getPayNowMap().put(
                    new CiResourceIdPair(newBaseService.getCatalogItemExternalId()),
                    newBaseService);
            aopStage.addToTotalEstimatedAmount(newBaseService.getFinalPayableAmount());
        }

        if (baseCiPair != null) {
            INFO(
                    m_logger, methodKey + "Removing service stage for "
                            + baseCiPair.getCatalogItemExternalId());
            aopStage.subtractTotalEstimatedAmount(
                    aopStage.getServiceStage(
                            baseCiPair.getCatalogItemExternalId()).getFinalPayableAmount());
            aopStage.getPayNowMap().remove(baseCiPair);
        }

        for (CiResourceIdPair ciPair : CommonUtils.emptyIfNull(
                changeAdvicestage.getChangeServiceDataStage().getPreactiveOffers())) {
            INFO(
                    m_logger, methodKey + "Removing service stage for preactive "
                            + ciPair.getCatalogItemExternalId());
            ServiceStage preActiveStage = aopStage.getServiceStage(
                    ciPair.getCatalogItemExternalId());
            if (preActiveStage != null) {
                aopStage.subtractTotalEstimatedAmount(preActiveStage.getFinalPayableAmount());
                aopStage.getPayNowMap().remove(ciPair);
            }
        }

        if (request.getCancelItems() != null && !request.getCancelItems().isEmpty()) {
            for (VisibleChangeServiceCancelItem ci : request.getCancelItems()) {
                ServiceStage ss;
                if (ci.getResourceId() != null) {
                    ss = aopStage.getServiceStage(
                            ci.getCatalogItemExternalId(), ci.getResourceId());
                } else {
                    ss = aopStage.getServiceStage(ci.getCatalogItemExternalId());
                }
                if (ss != null) {
                    CiResourceIdPair ciPair = new CiResourceIdPair(
                            ss.getCatalogItemExternalId(), ss.getOfferResourceId());
                    INFO(
                            m_logger, methodKey + "Removing service stage for "
                                    + ciPair.getCatalogItemExternalId());
                    aopStage.subtractTotalEstimatedAmount(ss.getFinalPayableAmount());
                    aopStage.getPayNowMap().remove(ciPair);
                } else {
                    INFO(
                            m_logger,
                            methodKey + "Ignore CancelItems as matching item not found for: "
                                    + ci.toJson());
                }
            }
        }

        if (request.getAddItems() != null && !request.getAddItems().isEmpty()) {
            for (VisibleChangeServiceAddItem ci : request.getAddItems()) {
                // Possible logic / question etc It should be as below.
                // If addon is monthly - align to wallet bill cycle
                // If addon is annual - base is annual - align to base
                // If addon is annual - base is monthly - align to wallet bill cycle. Annual plan
                // can not start until current month ends

                // VER-535 implementation - Always align to base offer next cycle date. Payment
                // advice is provided as per next cycle of base offer.
                // Get AOC and get balance impact on main balance. Use those dates to get current
                // billing cycle

                MtxPurchasedOfferDataBuilder poDataBuilder = (new MtxPurchasedOfferDataBuilder()).withOfferExternalId(
                        ci.getCatalogItemExternalId()).withAmount(ci.getDiscountPrice());

                if (request.getAttrData() != null) {
                    poDataBuilder.withOfferExtn(request.getAttrData());
                }

                MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
                searchData.setExternalId(request.getSubscriptionExternalId());

                MtxResponsePurchase aocResp = getAocCurrencyBalanceImpactInfo(
                        loggingKey, ci.getCatalogItemExternalId(), poDataBuilder.build(),
                        request.getSubscriptionExternalId());
                MtxTimestamp addonNextCycleStart = null;
                MtxTimestamp addonCurrentCycleStart = null;
                if (aocResp != null && aocResp.getPurchaseInfoArray() != null
                        && !aocResp.getPurchaseInfoArray().isEmpty()
                        && aocResp.getAtPurchaseInfoArray(0).getBalanceImpactGroupList() != null
                        && !aocResp.getAtPurchaseInfoArray(
                                0).getBalanceImpactGroupList().isEmpty()) {
                    addonNextCycleStart = aocResp.getAtPurchaseInfoArray(
                            0).getAtBalanceImpactGroupList(0).getCycleEndTime();
                    addonCurrentCycleStart = aocResp.getAtPurchaseInfoArray(
                            0).getAtBalanceImpactGroupList(0).getCycleStartTime();
                } else {
                    addonNextCycleStart = subscription.getBillingCycle().getCurrentPeriodEndTime();
                    addonCurrentCycleStart = subscription.getBillingCycle().getCurrentPeriodStartTime();
                }

                MtxTimestamp addonNextCycleEnd = CommonUtils.getNextCycleEndTime(
                        subscription.getBillingCycle(), aopStage.getSubscriptionTimezone());
                MtxResponsePricingCatalogItem pricingAddon = queryPricingCatalogItem(
                        loggingKey, route, ci.getCatalogItemExternalId());
                pricingAddon.getCatalogItemInfo().getCyclePeriod();
                if (pricingAddon.getCatalogItemInfo() != null
                        && pricingAddon.getCatalogItemInfo().getCyclePeriod() != null
                        && pricingAddon.getCatalogItemInfo().getCyclePeriodInterval() != null) {
                    addonNextCycleEnd = CommonUtils.getCycleEndDate(
                            addonNextCycleStart, subscription.getTimeZone(),
                            pricingAddon.getCatalogItemInfo().getCyclePeriod(),
                            pricingAddon.getCatalogItemInfo().getCyclePeriodInterval(),
                            subscription.getBillingCycle());
                    INFO(
                            m_logger,
                            methodKey
                                    + "Addon cycle end date calculated based on cycle info configured at catalog item: "
                                    + ci.getCatalogItemExternalId());
                }
                ServiceStage newAddonService = getNewServiceStageForPaymentAdvice(
                        loggingKey, route, aopStage, subscription, ci.getCatalogItemExternalId(),
                        ci.getGrossPrice(), ci.getDiscountPrice(), addonNextCycleStart,
                        addonNextCycleEnd);
                INFO(m_logger, methodKey + "Adding service stage for " + newAddonService.toJson());
                aopStage.getPayNowMap().put(
                        new CiResourceIdPair(ci.getCatalogItemExternalId()), newAddonService);
                aopStage.addToTotalEstimatedAmount(newAddonService.getFinalPayableAmount());
            }
        }
    }

    private ServiceStage getNewServiceStageForPaymentAdvice(String loggingKey,
                                                            String route,
                                                            AdviceDataStage stage,
                                                            SubscriptionResponse subscription,
                                                            String catalogItemExternalId,
                                                            BigDecimal grossPrice,
                                                            BigDecimal discountPrice,
                                                            MtxTimestamp nextCycleStartTime,
                                                            MtxTimestamp nextCycleEndTime) {

        ServiceStage newService = new ServiceStage(catalogItemExternalId);
        newService.setDiscountPrice(discountPrice);
        newService.setProratedDiscountPrice(discountPrice);
        newService.setGrossPrice(discountPrice);
        if (grossPrice != null) {
            newService.setGrossPrice(grossPrice);
        }
        newService.setFinalPayableAmount(discountPrice);
        newService.setNonCreditAmount(discountPrice);
        newService.setNextCycleStartTime(subscription.getBillingCycle().getCurrentPeriodEndTime());

        if (nextCycleStartTime != null) {
            newService.setNextCycleStartTime(nextCycleStartTime);
        } else {
            newService.setNextCycleStartTime(
                    subscription.getBillingCycle().getCurrentPeriodEndTime());
        }

        MtxTimestamp nextBillCycleEndDate = CommonUtils.getNextCycleEndTime(
                subscription.getBillingCycle(), stage.getSubscriptionTimezone());
        stage.setNextCycleEndTime(nextBillCycleEndDate);

        MtxResponsePricingCatalogItem pricingCI = queryPricingCatalogItem(
                loggingKey, route, catalogItemExternalId);
        if (nextCycleEndTime != null) {
            newService.setNextCycleEndTime(nextCycleEndTime);
        } else {
            if (newService.getNextCycleStartTime() != null) {
                MtxTimestamp endDate;
                if (pricingCI.getCatalogItemInfo() != null
                        && pricingCI.getCatalogItemInfo().getCyclePeriod() != null
                        && pricingCI.getCatalogItemInfo().getCyclePeriodInterval() != null) {
                    endDate = CommonUtils.getCycleEndDate(
                            newService.getNextCycleStartTime(), subscription.getTimeZone(),
                            pricingCI.getCatalogItemInfo().getCyclePeriod(),
                            pricingCI.getCatalogItemInfo().getCyclePeriodInterval(),
                            subscription.getBillingCycle());
                    newService.setNextCycleEndTime(endDate);
                } else {
                    newService.setNextCycleEndTime(nextBillCycleEndDate);
                }
            }
        }
        if (pricingCI != null && pricingCI.getCatalogItemInfo() != null
                && pricingCI.getCatalogItemInfo().getMetadataList() != null) {
            pricingCI.getCatalogItemInfo().getMetadataList().forEach(pmi -> {
                if (pmi.getName().equalsIgnoreCase(CI_METADATA.TAX_INPUT)) {
                    newService.setTaxInput(pmi.getValue());
                }
                if (pmi.getName().equalsIgnoreCase(CI_METADATA.STANDALONE_TAX_INPUT)) {
                    newService.setStandaloneTaxInput(pmi.getValue());
                }
            });
        }

        if (pricingCI.getCatalogItemInfo().getTemplateAttr() != null
                && (pricingCI.getCatalogItemInfo().getTemplateAttr() instanceof VisibleTemplate)) {
            VisibleTemplate attr = (VisibleTemplate) pricingCI.getCatalogItemInfo().getTemplateAttr();
            newService.setOfferType(attr.getOfferType());
            if (OFFER_CONSTANTS.OFFER_TYPE_BASE.equalsIgnoreCase("" + attr.getOfferType())) {
                stage.setBaseOfferInAdvice(true);
            }
            if (attr.getMinimumCharge() != null) {
                newService.setMinimumCharge(attr.getMinimumCharge());
            } else {
                newService.setMinimumCharge(BigDecimal.ZERO);
            }
            // update paynow with flag value
            if (attr.getIgnoreTax_ForPayableAmount() != null) {
                newService.setIgnoreTax_ForPayableAmount(attr.getIgnoreTax_ForPayableAmount());
            }
        }

        if (newService.getNextCycleStartTime().longValue() > subscription.getBillingCycle().getCurrentPeriodEndTime().longValue()) {
            // New service starts after start of next bill cycle.
            // Set payable amount as zero. setIgnoreTax_ForPayableAmount to true.
            newService.setIgnoreTax_ForPayableAmount("true");
            newService.setAocDiscountPrice(BigDecimal.ZERO);
            newService.setProratedDiscountPrice(BigDecimal.ZERO);
            newService.setNonCreditAmount(BigDecimal.ZERO);
            newService.setFinalPayableAmount(BigDecimal.ZERO);
            newService.setSkipRenewal(true);
            stage.setTotalEstimatedAmount(stage.getTotalEstimatedAmount().subtract(discountPrice));
        }

        return newService;
    }

    private void addServiceStageFromQuoteAdvice(String loggingKey,
                                                String route,
                                                AdviceDataStage stage,
                                                AdviceDataStage quoteAdvicestage,
                                                SubscriptionResponse subscription) {
        final String methodKey = loggingKey + " addServiceStageFromQuoteAdvice: ";
        INFO(m_logger, loggingKey + methodKey);
        CiResourceIdPair baseCiPair = null;

        for (CiResourceIdPair ciRes : CommonUtils.emptyIfNull(
                quoteAdvicestage.getPayNowMap().keySet())) {
            ServiceStage quoteService = quoteAdvicestage.getPayNowMap().get(ciRes);
            if (quoteService.getPurchaseOfferEndTime() != null
                    && CommonUtils.compareMtxTimestampsIgnoreTime(
                            quoteService.getPurchaseOfferEndTime(),
                            quoteService.getMainBalanceImpactCycleEndTime()) <= 0) {
                // Service ends before next cycle. Hence not to be included in payment advice.
                continue;
            }
            ServiceStage newService = new ServiceStage(
                    ciRes.getCatalogItemExternalId(), ciRes.getResourceId());
            newService.setDiscountPrice(quoteService.getDiscountPrice());
            newService.setProratedDiscountPrice(quoteService.getDiscountPrice());
            newService.setGrossPrice(quoteService.getDiscountPrice());
            if (quoteService.getGrossPrice() != null) {
                newService.setGrossPrice(quoteService.getGrossPrice());
            }
            newService.setFinalPayableAmount(quoteService.getDiscountPrice());
            newService.setNonCreditAmount(quoteService.getDiscountPrice());
            newService.setNextCycleStartTime(quoteService.getCycleEndTime());

            if (stage.getNextCycleStartTime() == null) {
                stage.setNextCycleStartTime(quoteAdvicestage.getCycleEndTime());
            }

            if (stage.getNextCycleEndTime() == null) {
                MtxTimestamp nextBillingCycleEndDate = CommonUtils.getNextCycleEndTime(
                        subscription.getBillingCycle(), subscription.getTimeZone());
                stage.setNextCycleEndTime(nextBillingCycleEndDate);
            }

            MtxResponsePricingCatalogItem pricingCI = queryPricingCatalogItem(
                    loggingKey, route, quoteService.getCatalogItemExternalId());
            if (newService.getNextCycleStartTime() != null) {
                MtxTimestamp endDate;
                if (pricingCI.getCatalogItemInfo() != null
                        && pricingCI.getCatalogItemInfo().getCyclePeriod() != null
                        && pricingCI.getCatalogItemInfo().getCyclePeriodInterval() != null) {
                    endDate = CommonUtils.getCycleEndDate(
                            newService.getNextCycleStartTime(), subscription.getTimeZone(),
                            pricingCI.getCatalogItemInfo().getCyclePeriod(),
                            pricingCI.getCatalogItemInfo().getCyclePeriodInterval(),
                            subscription.getBillingCycle());
                } else {
                    endDate = stage.getNextCycleEndTime();
                }
                newService.setNextCycleEndTime(endDate);
            }
            if (pricingCI != null && pricingCI.getCatalogItemInfo() != null
                    && pricingCI.getCatalogItemInfo().getMetadataList() != null) {
                pricingCI.getCatalogItemInfo().getMetadataList().forEach(pmi -> {
                    if (pmi.getName().equalsIgnoreCase(CI_METADATA.TAX_INPUT)) {
                        newService.setTaxInput(pmi.getValue());
                    }
                    if (pmi.getName().equalsIgnoreCase(CI_METADATA.STANDALONE_TAX_INPUT)) {
                        newService.setStandaloneTaxInput(pmi.getValue());
                    }
                    if (pmi.getName().equalsIgnoreCase(CI_METADATA.ZERO_TAX_RESPONSE)) {
                        newService.setZeroTaxResponse(pmi.getValue());
                    }
                });
            }

            if (pricingCI.getCatalogItemInfo().getTemplateAttr() != null
                    && (pricingCI.getCatalogItemInfo().getTemplateAttr() instanceof VisibleTemplate)) {
                VisibleTemplate attr = (VisibleTemplate) pricingCI.getCatalogItemInfo().getTemplateAttr();
                newService.setOfferType(attr.getOfferType());
                if (OFFER_CONSTANTS.OFFER_TYPE_BASE.equalsIgnoreCase("" + attr.getOfferType())) {
                    stage.setBaseOfferInAdvice(true);
                }
                if (attr.getMinimumCharge() != null) {
                    newService.setMinimumCharge(attr.getMinimumCharge());
                } else {
                    newService.setMinimumCharge(BigDecimal.ZERO);
                }
                // update paynow with flag value
                if (attr.getIgnoreTax_ForPayableAmount() != null) {
                    newService.setIgnoreTax_ForPayableAmount(attr.getIgnoreTax_ForPayableAmount());
                }
            }
            INFO(
                    m_logger, loggingKey + methodKey + "Adding service stage for "
                            + newService.getCatalogItemExternalId());
            stage.getPayNowMap().put(
                    new CiResourceIdPair(newService.getCatalogItemExternalId(),newService.getOfferResourceId()), newService);
            stage.addToTotalEstimatedAmount(newService.getFinalPayableAmount());
        }
    }

    public void updateDataFromSubscriptionResponse(String loggingKey,
                                                   AdviceDataStage stage,
                                                   SubscriptionResponse subscriptionResponse) {
        final String methodName = "updateDataFromSubscriptionResponse: ";

        stage.setAvailableMainBalanceAmount(BigDecimal.ZERO);

        if (subscriptionResponse.getWalletBalances() != null) {
            subscriptionResponse.getWalletBalances().forEach(bi -> {
                if (bi.getIsMainBalance()) {
                    stage.setAvailableMainBalanceAmount(bi.getAmount().negate());
                }
            });
        }

        INFO(
                m_logger,
                loggingKey + methodName + StringUtils.SPACE
                        + " Updated mainbalance amount from wallet: "
                        + stage.getAvailableMainBalanceAmount());

        if (subscriptionResponse.getBillingCycle() != null) {
            stage.setCycleStartTime(
                    subscriptionResponse.getBillingCycle().getCurrentPeriodStartTime());
            stage.setCycleEndTime(subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime());
        }

    }

    /**
     * Add All payable amounts as payNow amounts to staging object
     *
     * @param loggingKey
     * @param route
     * @param stage
     * @param purchaseRequest
     * @throws PaymentAdviceException
     * @throws IntrospectionException
     * @throws CommonUtilsException
     */
    private void updateDefaultPaynowAmountsPurchaseServiceMulti(String loggingKey,
                                                                String route,
                                                                AdviceDataStage stage,
                                                                VisibleMultiRequestPurchaseService purchaseRequest)
            throws PaymentAdviceException, CommonUtilsException, IntrospectionException,
            InvalidRequestException {
        String methodKey = loggingKey + " updateDefaultPaynowAmountsPurchaseServiceMulti ";
        MtxResponseWallet wallet = querySubscriptionWallet(
                loggingKey, route, purchaseRequest.getSubscriberExternalId());
        PurchaseAdviceUtils.updateDataFromWallet(loggingKey, stage, wallet);
        BigDecimal proratedPrice = BigDecimal.ZERO;

        for (VisiblePurchaseInfo pi : purchaseRequest.getPurchaseInfo()) {

            //@formatter:off
            MtxPurchasedOfferDataBuilder poDataBuilder = (new MtxPurchasedOfferDataBuilder())
                    .withOfferExternalId(pi.getPurchaseServiceInfo()
                    .getServiceOfferExternalId()).withOrderId(pi.getPurchaseServiceOrderInfo().getOrderId())
                    .withTaxDetails(pi.getPurchaseServiceInfo().getServiceTaxDetails())
                    .withDeviceDetails(pi.getPurchaseServiceInfo().getServiceDetails())
                    .withInfo((new Date()).getTime() + "")
                    .withOfferExtn(pi.getAttrData());
            //@formatter:on

            if (pi.getPurchaseServiceInfo().getChargePurchaseProrationType() != null) {
                poDataBuilder = poDataBuilder.withChargePurchaseProrationType(
                        Long.valueOf(pi.getPurchaseServiceInfo().getChargePurchaseProrationType()));
            }

            ServiceStage payNow = new ServiceStage(
                    pi.getPurchaseServiceInfo().getServiceOfferExternalId());
            if (wallet.getBillingCycle() != null
                    && wallet.getBillingCycle().getCurrentPeriodStartTime() != null) {
                payNow.setCycleStartTime(wallet.getBillingCycle().getCurrentPeriodStartTime());
                payNow.setCycleEndTime(wallet.getBillingCycle().getCurrentPeriodEndTime());
            } else {
                LocalDateTime rightNow = LocalDateTime.now();
                ZoneId systemZone = ZoneId.systemDefault();
                ZoneOffset zoneOffset = systemZone.getRules().getOffset(rightNow);
                LocalDate today = LocalDate.now();
                MtxTimestamp startTime = new MtxTimestamp(
                        today.toString() + "T00:00:00.000000" + zoneOffset);
                payNow.setCycleStartTime(startTime);
                LocalDate todayPlusMonth = LocalDate.now().plusMonths(1);
                MtxTimestamp endTime = new MtxTimestamp(
                        todayPlusMonth.toString() + "T00:00:00.000000" + zoneOffset);
                payNow.setCycleEndTime(endTime);
            }

            if (pi.getPurchaseServiceInfo().getServiceDiscountPrice() != null) {
                poDataBuilder = poDataBuilder.withAmount(
                        new BigDecimal(pi.getPurchaseServiceInfo().getServiceDiscountPrice()));
                payNow.setDiscountPrice(
                        new BigDecimal(pi.getPurchaseServiceInfo().getServiceDiscountPrice()));
            }

            payNow.setFinalPayableAmount(payNow.getProratedDiscountPrice());
            payNow.setGrossPrice(
                    new BigDecimal(pi.getPurchaseServiceInfo().getServiceGrossPrice()));
            MtxResponsePricingCatalogItem pricingCI = queryPricingCatalogItem(
                    loggingKey, route, payNow.getCatalogItemExternalId());

            if (pricingCI != null && pricingCI.getResult() != RESULT_CODES.MTX_SUCCESS) {
                WARN(m_logger, methodKey + pricingCI.getResultText());
                throw new InvalidRequestException(pricingCI.getResult(), pricingCI.getResultText());
            }

            if (pricingCI != null && pricingCI.getCatalogItemInfo() != null
                    && pricingCI.getCatalogItemInfo().getMetadataList() != null) {
                pricingCI.getCatalogItemInfo().getMetadataList().forEach(pmi -> {
                    if (pmi.getName().equalsIgnoreCase(CI_METADATA.TAX_INPUT)) {
                        payNow.setTaxInput(pmi.getValue());
                    }
                    if (pmi.getName().equalsIgnoreCase(CI_METADATA.STANDALONE_TAX_INPUT)) {
                        payNow.setStandaloneTaxInput(pmi.getValue());
                    }
                });
                if (payNow.getCycleStartTime() != null && pricingCI.getCatalogItemInfo() != null
                        && pricingCI.getCatalogItemInfo().getCyclePeriod() != null
                        && pricingCI.getCatalogItemInfo().getCyclePeriodInterval() != null) {
                    MtxTimestamp endDate = CommonUtils.getCycleEndDate(
                            payNow.getCycleStartTime(), stage.getSubscriptionTimezone(),
                            pricingCI.getCatalogItemInfo().getCyclePeriod(),
                            pricingCI.getCatalogItemInfo().getCyclePeriodInterval(),
                            wallet.getBillingCycle());
                    payNow.setCycleEndTime(endDate);
                }
            }

            if (pricingCI.getCatalogItemInfo().getTemplateAttr() != null
                    && (pricingCI.getCatalogItemInfo().getTemplateAttr() instanceof VisibleTemplate)) {
                VisibleTemplate attr = (VisibleTemplate) pricingCI.getCatalogItemInfo().getTemplateAttr();
                payNow.setOfferType(attr.getOfferType());
                if (OFFER_CONSTANTS.OFFER_TYPE_BASE.equalsIgnoreCase("" + attr.getOfferType())) {
                    stage.setBaseOfferInAdvice(true);
                }
                if (attr.getMinimumCharge() != null) {
                    payNow.setMinimumCharge(attr.getMinimumCharge());
                } else {
                    payNow.setMinimumCharge(BigDecimal.ZERO);
                }

                if (attr.getRedeemGoodType() != null) {
                    poDataBuilder.withGoodType(route);
                }

                if (attr.getIgnoreTax_ForPayableAmount() != null) {
                    payNow.setIgnoreTax_ForPayableAmount(attr.getIgnoreTax_ForPayableAmount());
                }
            }

            MtxResponsePurchase aocResponsePurchase = getAocForPurchaseOffer(
                    loggingKey, pi.getPurchaseServiceInfo().getServiceOfferExternalId(),
                    purchaseRequest.getSubscriberExternalId(), poDataBuilder.build());
            payNow.setPurchaseOfferEndTime(
                    aocResponsePurchase.getAtPurchaseInfoArray(0).getEndTime());
            BigDecimal ciProratedPrice = CommonUtils.getCurrencyAmount(aocResponsePurchase);
            payNow.setProratedDiscountPrice(ciProratedPrice);
            payNow.setNonCreditAmount(payNow.getProratedDiscountPrice());
            stage.getPayNowMap().put(
                    new CiResourceIdPair(payNow.getCatalogItemExternalId()), payNow);
            proratedPrice = proratedPrice.add(ciProratedPrice);
        }
        stage.setTotalEstimatedAmount(proratedPrice);
    }

    private MtxResponsePurchase getAocForPurchaseOffer(String loggingKey,
                                                       String ciExternalId,
                                                       String subscriptionExternalId,
                                                       MtxPurchasedOfferData mpod)
            throws PaymentAdviceException {
        final String methodName = "getAocForPurchaseOffer: ";
        MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
        searchData.setExternalId(subscriptionExternalId);

        BigDecimal proratedChargeAmount = BigDecimal.ZERO;
        DEBUG(
                m_logger, loggingKey + StringUtils.SPACE + methodName + StringUtils.SPACE
                        + " Calling purchase offer AOC");

        MtxResponsePurchase purchaseOfferRes = doSubscriberPurchaseOfferAOC(
                loggingKey, ciExternalId, mpod, searchData);
        if (purchaseOfferRes == null || purchaseOfferRes.getResult() != RESULT_CODES.MTX_SUCCESS) {
            Long resultCode = purchaseOfferRes != null
                    ? purchaseOfferRes.getResult() : RESULT_CODES.HTTP_INTERNAL_ERROR;
            String message = LOG_MESSAGES.FAILED_TO_GET_PURCHASE_AOC
                    + (purchaseOfferRes != null ? " - " + purchaseOfferRes.getResultText() : "");
            throw new PaymentAdviceException(resultCode, message);
        }

        return purchaseOfferRes;
    }

    /**
     * Get payNow amounts for based on subscriberEstimateRecurringCharge
     *
     * @param stage
     * @param chargeInfo
     * @param subscriptionResponse
     * @return
     * @throws PaymentAdviceException
     */
    private void updateDefaultPaynowAmountsForAop(String loggingKey,
                                                  String route,
                                                  AdviceDataStage stage,
                                                  MtxResponseRecurringChargeInfo chargeInfo,
                                                  SubscriptionResponse subscriptionResponse)
            throws PaymentAdviceException {
        final String methodKey = loggingKey + "updateDefaultPaynowAmountsForAop: ";
        INFO(m_logger, methodKey);
        // if (chargeInfo.getBalanceImpactGroupList() != null) {
        for (MtxBalanceImpactInfoGroup biInfoGroup : CommonUtils.emptyIfNull(
                chargeInfo.getBalanceImpactGroupList())) {
            if (stage.getNextCycleStartTime() == null
                    || stage.getNextCycleStartTime().longValue() > biInfoGroup.getCycleStartTime().longValue()) {
                // Preference to monthly cycle over annual one.
                stage.setNextCycleStartTime(biInfoGroup.getCycleStartTime());
            }
            if (stage.getNextCycleEndTime() == null
                    || stage.getNextCycleEndTime().longValue() > biInfoGroup.getCycleEndTime().longValue()) {
                stage.setNextCycleEndTime(biInfoGroup.getCycleEndTime());
            }
        }
        updateDefaultPaynowAmounts(
                loggingKey, route, stage, chargeInfo.getBalanceImpactGroupList(),
                subscriptionResponse);
        // }
    }

    private void updateDefaultPaynowAmountsForQuote(String loggingKey,
                                                    String route,
                                                    AdviceDataStage stage,
                                                    List<MtxBalanceImpactInfoGroup> biigList)
            throws PaymentAdviceException {
        updateDefaultPaynowAmounts(loggingKey, route, stage, biigList, null);
    }

    /**
     * Get payNow amounts for list of MtxBalanceImpactInfoGroup
     *
     * @param stage
     * @param biigList
     * @return
     * @throws PaymentAdviceException
     */
    private void updateDefaultPaynowAmounts(String loggingKey,
                                            String route,
                                            AdviceDataStage stage,
                                            List<MtxBalanceImpactInfoGroup> biigList,
                                            SubscriptionResponse subscriptionResponse)
            throws PaymentAdviceException {
        final String methodKey = loggingKey + "updateDefaultPaynowAmounts: ";
        INFO(m_logger, methodKey);
        for (MtxBalanceImpactInfoGroup biInfoGroup : CommonUtils.emptyIfNull(biigList)) {
            for (MtxBalanceImpactInfo biInfo : CommonUtils.emptyIfNull(
                    biInfoGroup.getBalanceImpactList())) {
                if (biInfo.getBalanceClassId().longValue() != BALANCE_CONSTANTS.BALANCE_CLASS_ID_USD) {
                    continue;
                    // MtxResponseRecurringChargeInfo will have info about amounts of all usable
                    // balances. But based on total amount logic should be applied to redistribute
                    // between various balances. To begin with everything should be considered as
                    // payNow amount. After applying logic of referral and other credits
                    // redistribution will be complete.
                    // In a normal scenario sum of USD amount should be same charge amount.
                }
                stage.setTotalEstimatedAmount(
                        stage.getTotalEstimatedAmount().add(biInfo.getImpactAmount()));
                // note amounts by offer external id get catalog items here.
                for (MtxBalanceImpactOfferInfo bioInfo : CommonUtils.emptyIfNull(
                        biInfo.getBalanceImpactOfferList())) {
                    BigDecimal amount = BigDecimal.ZERO;

                    for (MtxBalanceImpactUpdateInfo biuInfo : bioInfo.getBalanceImpactUpdateList()) {
                        amount = amount.add(biuInfo.getAmount());
                    }

                    if (StringUtils.isBlank(bioInfo.getCatalogItemExternalId())) {
                        // No need to report offers that have no catalog item
                        continue;
                    }

                    boolean foundInList = false;
                    for (ServiceStage svcStg : stage.getPayNowMap().values()) {
                        if (svcStg.getCatalogItemExternalId().equals(
                                bioInfo.getCatalogItemExternalId())
                                && svcStg.getOfferResourceId().longValue() == bioInfo.getOfferResourceId().longValue()) {

                            if (svcStg.getNextCycleStartTime() == null) {
                                // Zero dollar offer might be created in previous steps.
                                // Add dates if it appears in recurring charges
                                svcStg.setNextCycleStartTime(biInfoGroup.getCycleStartTime());
                                INFO(
                                        m_logger, methodKey
                                                + "Added CycleStartTime from MtxBalanceImpactInfoGroup.");
                            }
                            if (svcStg.getNextCycleEndTime() == null) {
                                svcStg.setNextCycleEndTime(biInfoGroup.getCycleEndTime());
                                INFO(
                                        m_logger, methodKey
                                                + "Added CycleEndTime from MtxBalanceImpactInfoGroup.");
                            }
                            if (biInfo.getIsMainBalance()
                                    && biInfoGroup.getCycleStartTime() != null) {
                                svcStg.setMainBalanceImpactCycleStartTime(
                                        biInfoGroup.getCycleStartTime());
                            }
                            if (biInfo.getIsMainBalance()
                                    && biInfoGroup.getCycleEndTime() != null) {
                                svcStg.setMainBalanceImpactCycleEndTime(
                                        biInfoGroup.getCycleEndTime());
                            }

                            if (amount.signum() > 0) {
                                if (svcStg.isDiscountPriceFromSubscription()) {
                                    svcStg.setDiscountPrice(amount);
                                    svcStg.setDiscountPriceFromSubscription(false);
                                } else {
                                    svcStg.setDiscountPrice(svcStg.getDiscountPrice().add(amount));
                                }

                            }

                            boolean doNotAccumulate = false;
                            if (AdviceDataStage.Advice.PAYMENT == stage.getAdviceFor()) {
                                MtxTimestamp cycleStartTime = svcStg.getNextCycleStartTime();
                                MtxTimestamp curTimestmp = CommonUtils.getCurrentTimeInZone(
                                        stage.getSubscriptionTimezone());
                                MtxTimestamp monthBeforeNextCycle = CommonUtils.subtractOneMonth(
                                        cycleStartTime, stage.getSubscriptionTimezone());
                                if (monthBeforeNextCycle.longValue() > curTimestmp.longValue()) {
                                    doNotAccumulate = true;
                                }
                            }

                            if (!doNotAccumulate) {
                                svcStg.setAocDiscountPrice(
                                        svcStg.getAocDiscountPrice().add(amount));
                                svcStg.setProratedDiscountPrice(
                                        svcStg.getProratedDiscountPrice().add(amount));
                                svcStg.setNonCreditAmount(svcStg.getProratedDiscountPrice());
                                svcStg.setFinalPayableAmount(svcStg.getProratedDiscountPrice());
                            }

                            foundInList = true;
                        }
                    }

                    if (!foundInList) {
                        MtxTimestamp cycleStartTime = biInfoGroup.getCycleStartTime();
                        MtxTimestamp cycleEndTime = biInfoGroup.getCycleEndTime();
                        if (subscriptionResponse != null) {
                            for (MtxPurchasedOfferInfo poi : subscriptionResponse.getPurchasedOfferArray()) {
                                if (bioInfo.getCatalogItemExternalId().equalsIgnoreCase(
                                        poi.getCatalogItemExternalId())
                                        && poi.getCycleInfo() != null) {
                                    cycleStartTime = poi.getCycleInfo().getCycleEndTime();
                                    cycleEndTime = CommonUtils.getCycleEndDate(
                                            cycleStartTime, subscriptionResponse.getTimeZone(),
                                            poi.getCycleInfo().getPeriod(),
                                            poi.getCycleInfo().getPeriodInterval(),
                                            subscriptionResponse.getBillingCycle());
                                }
                            }
                        }
                        ServiceStage newSvcStg = addPaynowStageToAopQuote(
                                loggingKey, route, stage, bioInfo.getCatalogItemExternalId(),
                                bioInfo.getOfferResourceId(), amount, cycleStartTime, cycleEndTime);
                        if (biInfo.getIsMainBalance() && biInfoGroup.getCycleStartTime() != null) {
                            newSvcStg.setMainBalanceImpactCycleStartTime(
                                    biInfoGroup.getCycleStartTime());
                        }
                        if (biInfo.getIsMainBalance() && biInfoGroup.getCycleEndTime() != null) {
                            newSvcStg.setMainBalanceImpactCycleEndTime(
                                    biInfoGroup.getCycleEndTime());
                        }
                    }
                }
            }
        }
    }

    private ServiceStage addPaynowStageToAopQuote(String loggingKey,
                                                  String route,
                                                  AdviceDataStage stage,
                                                  String catalogItemExternalId,
                                                  long offerResourceId,
                                                  BigDecimal discountPrice,
                                                  MtxTimestamp cycleStartTime,
                                                  MtxTimestamp CycleEndTime) {
        final String methodKey = loggingKey + "addPaynowStageToAopQuote: ";
        INFO(m_logger, methodKey);
        ServiceStage svcStg = new ServiceStage(catalogItemExternalId, offerResourceId);
        svcStg.setAocDiscountPrice(discountPrice);
        svcStg.setProratedDiscountPrice(discountPrice);
        svcStg.setNonCreditAmount(discountPrice);
        svcStg.setFinalPayableAmount(discountPrice);
        svcStg.setDiscountPrice(discountPrice);
        if (AdviceDataStage.Advice.PAYMENT == stage.getAdviceFor()) {
            svcStg.setNextCycleStartTime(cycleStartTime);
            svcStg.setNextCycleEndTime(CycleEndTime);
            // Additional logic for PaymentAdvice of Annual Services - VER-191
            // CycleEndTime comes from recurring charge. If CycleEndTime is more than one month away
            // from today, then it is not a monthly offer.
            MtxTimestamp curTimestmp = CommonUtils.getCurrentTimeInZone(
                    stage.getSubscriptionTimezone());
            MtxTimestamp monthBeforeNextCycle = CommonUtils.subtractOneMonth(
                    cycleStartTime, stage.getSubscriptionTimezone());
            if (monthBeforeNextCycle.longValue() > curTimestmp.longValue()) {
                // Right Now we are more than a month away from next cycle start
                // Set payable amount as zero. setIgnoreTax_ForPayableAmount to true.
                svcStg.setIgnoreTax_ForPayableAmount("true");
                svcStg.setAocDiscountPrice(BigDecimal.ZERO);
                svcStg.setProratedDiscountPrice(BigDecimal.ZERO);
                svcStg.setNonCreditAmount(BigDecimal.ZERO);
                svcStg.setFinalPayableAmount(BigDecimal.ZERO);
                svcStg.setSkipRenewal(true);
                stage.setTotalEstimatedAmount(
                        stage.getTotalEstimatedAmount().subtract(discountPrice));
            }
        } else {
            svcStg.setCycleStartTime(cycleStartTime);
            svcStg.setCycleEndTime(CycleEndTime);
        }

        MtxResponsePricingCatalogItem pricingCI = queryPricingCatalogItem(
                loggingKey, route, catalogItemExternalId);
        if (pricingCI.getCatalogItemInfo().getTemplateAttr() != null
                && (pricingCI.getCatalogItemInfo().getTemplateAttr() instanceof VisibleTemplate)) {
            VisibleTemplate attr = (VisibleTemplate) pricingCI.getCatalogItemInfo().getTemplateAttr();
            svcStg.setOfferType(attr.getOfferType());
            if (OFFER_CONSTANTS.OFFER_TYPE_BASE.equalsIgnoreCase("" + attr.getOfferType())) {
                stage.setBaseOfferInAdvice(true);
            }
            if (attr.getMinimumCharge() != null) {
                svcStg.setMinimumCharge(attr.getMinimumCharge());
            } else {
                svcStg.setMinimumCharge(BigDecimal.ZERO);
            }
            // update paynow with flag value
            if (attr.getIgnoreTax_ForPayableAmount() != null) {
                svcStg.setIgnoreTax_ForPayableAmount(attr.getIgnoreTax_ForPayableAmount());
            }
        }

        if (pricingCI != null && pricingCI.getCatalogItemInfo() != null
                && pricingCI.getCatalogItemInfo().getMetadataList() != null) {
            pricingCI.getCatalogItemInfo().getMetadataList().forEach(pmi -> {
                if (pmi.getName().equalsIgnoreCase(CI_METADATA.TAX_INPUT)) {
                    svcStg.setTaxInput(pmi.getValue());
                }
                if (pmi.getName().equalsIgnoreCase(CI_METADATA.STANDALONE_TAX_INPUT)) {
                    svcStg.setStandaloneTaxInput(pmi.getValue());
                }
                if (pmi.getName().equalsIgnoreCase(CI_METADATA.ZERO_TAX_RESPONSE)) {
                    svcStg.setZeroTaxResponse(pmi.getValue());
                }
            });
        }

        stage.getPayNowMap().put(
                new CiResourceIdPair(
                        svcStg.getCatalogItemExternalId(), svcStg.getOfferResourceId()),
                svcStg);
        INFO(m_logger, methodKey + "Added Paynow Stage: " + svcStg.toShortJson());
        return svcStg;
    }

    /**
     * Calculate AOPamounts based intial payable amounts and credits.
     *
     * @param loggingKey
     * @param route
     * @param subscription
     * @param stage
     * @param ciSet
     * @param balPriMap
     * @return
     * @throws Exception
     */
    private AdviceDataStage updateCreditsForPaymentAndPurchaseAdvice(String loggingKey,
                                                                     String route,
                                                                     MtxResponseSubscription subscription,
                                                                     AdviceDataStage stage)
            throws Exception {
        updateAocCredits(loggingKey, route, subscription, stage);
        updateStartWithGrantBalanceCredits(loggingKey, route, subscription, stage, null, false);
        updateStartWithPurchasedOfferCredits(loggingKey, route, subscription, stage, null, false);

        boolean applyPromo = false;
        for (CreditStage cs : stage.getCreditMap().values()) {
            if (!cs.getApplicableServiceStage().isSkipRenewal()) {
                // Do not apply promo if all applicable services are annual
                applyPromo = true;
                break;
            }
        }

        if (applyPromo) {
            AdviceUtils.updateFinalMinimumCharges(loggingKey, stage);

            // Update initial amounts available in each balance
            stage.updateConsumableCreditsMoreThanChargeCondition(loggingKey);

            // Get redeem order here.
            stage.updateCredits(loggingKey);
        }

        stage.updatePayableAmounts(loggingKey);
        return stage;
    }

    private AdviceDataStage updateCreditsForQuoteAdvice(String loggingKey,
                                                        String route,
                                                        MtxResponseSubscription subscription,
                                                        AdviceDataStage stage,
                                                        VisibleRequestQuoteAdviceService request)
            throws Exception {
        updateStartWithPurchasedOfferCredits(loggingKey, route, subscription, stage, null, false);
        updateQuoteAdviceFuturePromotions(loggingKey, route, subscription, stage, request);
        updateAocCredits(loggingKey, route, subscription, stage);
        updateStartWithGrantBalanceCredits(loggingKey, route, subscription, stage, null, false);
        boolean applyPromo = false;
        for (CreditStage cs : stage.getCreditMap().values()) {
            if (!cs.getApplicableServiceStage().isSkipRenewal()) {
                // Do not apply promo if all applicable services are annual
                applyPromo = true;
                break;
            }
        }

        if (applyPromo) {
            AdviceUtils.updateFinalMinimumCharges(loggingKey, stage);

            // Update initial amounts available in each balance
            stage.updateConsumableCreditsMoreThanChargeCondition(loggingKey);

            // Get redeem order here.
            stage.updateCredits(loggingKey);
        }

        stage.updatePayableAmounts(loggingKey);
        return stage;
    }

    private AdviceDataStage calculatePaymentAmountsSubtractQuoteAmounts(String loggingKey,
                                                                        String route,
                                                                        MtxResponseSubscription subscription,
                                                                        AdviceDataStage stage,
                                                                        AdviceDataStage quoteAdvicestage)
            throws Exception {
        final String methodKey = loggingKey + " calculatePaymentAmountsSubtractQuoteAmounts: ";
        INFO(m_logger, methodKey);
        updateAocCredits(loggingKey, route, subscription, stage);        
        updateStartWithGrantBalanceCredits(
                loggingKey, route, subscription, stage, quoteAdvicestage, false);        
        updateStartWithPurchasedOfferCredits(
                loggingKey, route, subscription, stage, quoteAdvicestage, false);
        AdviceUtils.updateFinalMinimumCharges(loggingKey, stage);    
        
        // Update initial amounts available in each balance
        stage.updateConsumableCreditsMoreThanChargeCondition(loggingKey);

        // Get redeem order here.
        stage.updateCredits(loggingKey);

        // Update PayNow amounts
        stage.updatePayableAmounts(loggingKey);

        return stage;
    }

    private AdviceDataStage calculatePaymentAdviceAmountsWithFuturePromo(String loggingKey,
                                                                         String route,
                                                                         MtxResponseSubscription subscription,
                                                                         VisibleRequestChangeServiceAdvice request,
                                                                         AdviceDataStage aopStage,
                                                                         AdviceDataStage deltaStage)
            throws Exception {
        // Future promo are now used in changeserviceadvice only
        final String methodKey = loggingKey + " calculatePaymentAdviceAmountsWithFuturePromo: ";
        INFO(m_logger, loggingKey + methodKey);
        updateAocCredits(loggingKey, route, subscription, aopStage);
        updateStartWithGrantBalanceCredits(loggingKey, route, subscription, aopStage, null, false);
        updateStartWithPurchasedOfferCredits(
                loggingKey, route, subscription, aopStage, null, false);

        // Adjust numbers based on what is reserved for delta stage
        if (aopStage.getCreditMap() != null && deltaStage.getCreditMap() != null) {
            for (PromoOfferPair aopKey : aopStage.getCreditMap().keySet()) {
                CreditStage aopCredit = aopStage.getCreditMap().get(aopKey);
                CreditStage deltaCredit = deltaStage.getCreditMap().get(aopKey);
                if (deltaCredit == null) {
                    continue;
                }
                aopCredit.getGlobalCreditStage().setAvailableCreditsConsumable(BigDecimal.ZERO);
                aopCredit.getGlobalCreditStage().setAvailableCreditsGrant(
                        deltaCredit.getGlobalCreditStage().getAvailableCreditsGrant());
                if (aopCredit.getGlobalCreditStage().getConsumablesUnavailableToChangeService() != null
                        && aopCredit.getGlobalCreditStage().getConsumablesUnavailableToChangeService().signum() > 0) {
                    aopCredit.getGlobalCreditStage().setAvailableCreditsConsumable(
                            aopCredit.getGlobalCreditStage().getAvailableCreditsConsumable().add(
                                    aopCredit.getGlobalCreditStage().getConsumablesUnavailableToChangeService()));
                }
                aopCredit.getGlobalCreditStage().setAvailableCreditsGrant(
                        aopCredit.getGlobalCreditStage().getAvailableCreditsGrant().subtract(
                                deltaCredit.getRedeemableCredits()));
            }
        }

        updateChangeServiceFuturePromotions(loggingKey, route, request, subscription, aopStage);
        AdviceUtils.updateFinalMinimumCharges(loggingKey, aopStage);

        // Update initial amounts available in each balance
        aopStage.updateConsumableCreditsMoreThanChargeCondition(loggingKey);

        // Get redeem order here.
        aopStage.updateCredits(loggingKey);

        // Update PayNow amounts
        aopStage.updatePayableAmounts(loggingKey);

        return aopStage;
    }

    private AdviceDataStage calculateQuoteAdviceAmountsForNextCycle(String loggingKey,
                                                                    String route,
                                                                    MtxResponseSubscription subscriber,
                                                                    AdviceDataStage stageNextCycle)
            throws IntegrationServiceException, PaymentAdviceException, CommonUtilsException,
            IntrospectionException {
        final String methodKey = loggingKey + " calculateQuoteAdviceAmountsForNextCycle: ";
        INFO(m_logger, methodKey);

        AdviceUtils.updateFinalMinimumCharges(loggingKey, stageNextCycle);

        // Update initial amounts available in each balance
        stageNextCycle.updateConsumableCreditsMoreThanChargeCondition(loggingKey);

        // Get redeem order here.
        stageNextCycle.updateCredits(loggingKey);

        // Update PayNow amounts
        stageNextCycle.updatePayableAmounts(loggingKey);

        return stageNextCycle;
    }

    /**
     * For credit where available amount needs to be calculated using AOC
     *
     * @param loggingKey
     * @param route
     * @param subscription
     * @param stage
     * @return
     * @throws PaymentAdviceException
     * @throws IntrospectionException
     * @throws CommonUtilsException
     * @throws NoSuchMethodException
     * @throws InvocationTargetException
     * @throws IllegalAccessException
     */
    private void updateAocCredits(String loggingKey,
                                  String route,
                                  MtxResponseSubscription subscription,
                                  AdviceDataStage stage)
            throws PaymentAdviceException, CommonUtilsException, IntrospectionException,
            IllegalAccessException, InvocationTargetException, NoSuchMethodException {
        // AOC Logic for Group etc
        final String methodKey = loggingKey + " updateAocCredits: ";
        boolean isChime = false;
        boolean isAmazon = false;
        boolean isVBPP = false;
        boolean isPartyPay = false;

        if (subscription != null && subscription.getAttr() != null) {
            VisibleSubscriberExtension subAttr = (VisibleSubscriberExtension) subscription.getAttr();
            isChime = OFFER_CONSTANTS.RETAIL_CHANNEL_CHIME.equalsIgnoreCase(
                    subAttr.getRetailChannel());
            isAmazon = OFFER_CONSTANTS.AMAZON_BRAND_NAME.equalsIgnoreCase(subAttr.getBrand());
        }

        // Validate Aoc offer to run for specific scenario
        if (stage.getSubscriberGroupList() != null && !stage.getSubscriberGroupList().isEmpty()) {
            for (SubscriberGroup sg : stage.getSubscriberGroupList()) {
                isVBPP = OFFER_CONSTANTS.GROUP_TIER_VBPP.equalsIgnoreCase(sg.getGroupTier());
                if (isVBPP)
                    break;
            }
            for (SubscriberGroup sg : stage.getSubscriberGroupList()) {
                isPartyPay = !OFFER_CONSTANTS.GROUP_TIER_VBPP.equalsIgnoreCase(sg.getGroupTier());
                if (isPartyPay)
                    break;
            }
        }

        INFO(m_logger, methodKey);
        String grantOffersCsv = AppPropertyProvider.getInstance().getString(
                CREDIT_CONSTANTS.AOC_GRANT_OFFERS);
        if (StringUtils.isBlank(grantOffersCsv)) {
            INFO(m_logger, loggingKey + StringUtils.SPACE + "No Aoc promo offers configured. ");
            return;
        }

        String[] grantOffers = grantOffersCsv.split(",");

        for (String grantCI : grantOffers) {
            if (stage.isPromoInCreditMap(grantCI)) {
                INFO(
                        m_logger, loggingKey + StringUtils.SPACE
                                + "Aoc Credit stage already initialized in previous cycle. No need to query pricing again.");
                continue;
            }

            if (grantCI.equalsIgnoreCase(OFFER_CONSTANTS.CHIME_OFFER_NAME) && !isChime) {
                continue;
            } else if ((grantCI.equalsIgnoreCase(OFFER_CONSTANTS.VBPP_GROUP_NAME)
                    || grantCI.equalsIgnoreCase(OFFER_CONSTANTS.VBPP_25_GROUP_NAME)) && !isVBPP) {
                continue;
            } else if ((grantCI.equalsIgnoreCase(OFFER_CONSTANTS.AMAZON_PAID_ON_OFFER_NAME)
                    || grantCI.equalsIgnoreCase(OFFER_CONSTANTS.AMAZON_PREPAY_OFFER_NAME))
                    && !isAmazon) {
                continue;
            } else if (grantCI.equalsIgnoreCase(OFFER_CONSTANTS.PARTYPAY_OFFER_NAME)
                    && !isPartyPay) {
                continue;
            }

            updateSingleAocCredit(loggingKey, route, grantCI, subscription, stage);

        }
    }

    private void updateSingleAocCredit(String loggingKey,
                                       String route,
                                       String grantCI,
                                       MtxResponseSubscription subscription,
                                       AdviceDataStage stage)
            throws PaymentAdviceException, CommonUtilsException, IntrospectionException,
            IllegalAccessException, InvocationTargetException, NoSuchMethodException {
        final String methodKey = loggingKey + " updateSingleAocCredit: ";

        boolean forChangeServiceDelta = (stage.getAdviceFor() == AdviceDataStage.Advice.CHANGE
                && stage.getChangeServiceDataStage().getBillCycle() == ChangeServiceDataStage.BillCycle.CURRENT);

        /*******************************************************************/
        GlobalCreditStage gcs = null;
        // avoid calling sub man api to get CI when possible.
        gcs = stage.getCreditMetadataMap().get(grantCI);
        if (gcs == null) {
            try {
                MtxResponsePricingCatalogItem mtxResponsePricingCatalogItem = queryPricingCatalogItem(
                        loggingKey, route, grantCI);
                gcs = AdviceUtils.getGlobalCreditStageForGrantCI(
                        loggingKey, mtxResponsePricingCatalogItem, stage, false);
            } catch (Exception e) {
                Long resultCode = RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR;
                String message = methodKey + "Could not create Credit Stage for AOC grant offer"
                        + StringUtils.SPACE + grantCI;
                INFO(
                        m_logger, message + StringUtils.SPACE + "Error Message: "
                                + StringUtils.SPACE + ExceptionUtils.getStackTrace(e));
                throw new PaymentAdviceException(
                        resultCode, message + StringUtils.SPACE + "Error Message: "
                                + StringUtils.SPACE + e.getMessage());
            }
        }
        /*******************************************************************/
        if (gcs == null) {
            return;
            // continue;
        }

        VisiblePurchasedOfferExtension poe = null;
        boolean purchasedGrantExists = false;
        MtxPurchasedOfferInfo poi = null;

        for (MtxPurchasedOfferInfo poi1 : CommonUtils.emptyIfNull(
                subscription.getPurchasedOfferArray())) {
            if (grantCI.equalsIgnoreCase(poi1.getCatalogItemExternalId())) {
                poi = poi1;
                poe = (VisiblePurchasedOfferExtension) poi1.getAttr();
                purchasedGrantExists = true;
                break;
            }
        }

        if (poe != null) {
            AdviceUtils.updateCreditWithPurchasedOfferExtension(loggingKey, gcs, poe);
        }

        Set<String> applicableCiSet = gcs.getApplicableCiSet();
        INFO(
                m_logger, methodKey + "Applicable CI Set for AOC promo " + StringUtils.SPACE
                        + applicableCiSet);
        // For Purchase service a promo is not required unless applicable offer is being
        // purchased.
        if (stage.getAdviceFor() == AdviceDataStage.Advice.PURCHASE) {
            boolean keepPromo = false;
            for (String applicableCi : applicableCiSet) {
                if (stage.getCiListInPurchaseService().contains(applicableCi)) {
                    keepPromo = true;
                    break;
                }
            }

            if (!keepPromo) {
                INFO(
                        m_logger,
                        methodKey + "Promo " + gcs.getPromotionName() + StringUtils.SPACE
                                + "is not usable by " + stage.getCiListInPurchaseService()
                                + StringUtils.SPACE + " promo will be skipped.");
                return;
                // continue;
            }
        }

        MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
        searchData.setExternalId(subscription.getExternalId());
        if (CREDIT_CONSTANTS.GRANT_TYPE_PERCENTAGE.equals(gcs.getCreditGrantType())) {
            // skip offer
            INFO(
                    m_logger,
                    methodKey + "AOC credit can not have Percentage grant type. Skipping promotion "
                            + StringUtils.SPACE + gcs.getPromotionName());
            return;
        } else {
            processAocGrant(
                    loggingKey, stage, gcs, searchData, applicableCiSet, forChangeServiceDelta);
        }

        if (subscription.getBalanceArray() != null) {
            for (MtxBalanceInfo bInfo : subscription.getBalanceArray()) {
                if (gcs.getConsumableBalanceName().equalsIgnoreCase(bInfo.getName())) {
                    if (stage.getCycleStartTime().getTimestamp().getTime() <= System.currentTimeMillis()) {
                        // We never advice for past. No datetracking needed here.
                        BigDecimal consAmt = CommonUtils.getBalanceAmount(bInfo);
                        gcs.setAvailableCreditsConsumable(consAmt);
                        INFO(
                                m_logger,
                                methodKey + consAmt + StringUtils.SPACE
                                        + "added from consumable balance to" + StringUtils.SPACE
                                        + gcs.getPromotionName());
                    } else if (AdviceDataStage.Advice.CHANGE == stage.getAdviceFor()
                            && ChangeServiceDataStage.BillCycle.NEXT == stage.getChangeServiceDataStage().getBillCycle()
                            && !CHANGE_SERVICE_CONSTANTS.NIB_SERVICE_CI.equalsIgnoreCase(
                                    stage.getChangeServiceDataStage().getAsisCatalogItem().getCatalogItemExternalId())) {
                        BigDecimal consAmt = CommonUtils.getBalanceAmount(bInfo);
                        gcs.setAvailableCreditsConsumable(consAmt);
                        INFO(
                                m_logger,
                                methodKey + consAmt + StringUtils.SPACE
                                        + "added from consumable balance ignoring dates to"
                                        + StringUtils.SPACE + gcs.getPromotionName()
                                        + StringUtils.SPACE
                                        + ". In Core2Core changes both offers should get same amount for Aoc Promos.");
                    } else {
                        BigDecimal consAmt = CommonUtils.getBalanceAmountOnDate(
                                bInfo, stage.getCycleStartTime());
                        gcs.setAvailableCreditsConsumable(consAmt);
                        INFO(
                                m_logger,
                                methodKey + consAmt + StringUtils.SPACE
                                        + "added from consumable balance as of date"
                                        + StringUtils.SPACE + stage.getCycleStartTime()
                                        + StringUtils.SPACE + "added to" + StringUtils.SPACE
                                        + gcs.getPromotionName());
                    }
                }
            }
        }

        if (poi != null && poi.getRequiredBalanceArray() != null) {
            MtxRequiredBalanceInfo rbi = poi.getRequiredBalanceArray().get(0);
            for (MtxBalanceInfo bi : subscription.getBalanceArray()) {
                if ((rbi.getResourceId().longValue() == bi.getResourceId().longValue())
                        && (rbi.getTemplateId().longValue() == bi.getTemplateId().longValue())
                        && (rbi.getClassId().longValue() == bi.getClassId().longValue())) {
                    gcs.setGrantBalanceName(bi.getName());
                    gcs.setAvailableCreditsGrant(
                            CommonUtils.getBalanceAmountOnDate(bi, stage.getCycleStartTime()));
                }
            }
        }

        gcs.setAvailableCredits(
                gcs.getAvailableCreditsGrant().add(gcs.getAvailableCreditsConsumable()));

        if (gcs.getAvailableCredits().signum() > 0 || forChangeServiceDelta) {
            List<String> discardList = new ArrayList<String>();
            for (CreditStage cs : gcs.getCreditMap().values()) {
                if (!stage.getCiListInPurchaseService().contains(cs.getApplicableCiExternalId())
                        && stage.getAdviceFor() == AdviceDataStage.Advice.PURCHASE) {
                    // For purchase do not report any promo with no redeemables.
                    INFO(
                            m_logger, methodKey + cs.getApplicableCiExternalId() + StringUtils.SPACE
                                    + "is not part of PurchaseServiceRequest. Skip promo.");
                    discardList.add(cs.getApplicableCiExternalId());
                    continue;
                }

                if (forChangeServiceDelta) {
                    // Delta calculation needs to know eligible grant for old offer too.
                    if (cs.getApplicableServiceStage() == null
                            && !cs.getApplicableCiExternalId().equalsIgnoreCase(
                                    stage.getChangeServiceDataStage().getAsisCatalogItem().getCatalogItemExternalId())
                            && !cs.getApplicableCiExternalId().equalsIgnoreCase(
                                    stage.getChangeServiceDataStage().getNewCatalogItemExternalId())) {
                        INFO(
                                m_logger,
                                methodKey + cs.getApplicableCiExternalId() + StringUtils.SPACE
                                        + "is not applicable either old offer or new offer. Skip promo.");
                        cs.setAocGrantToZero();
                        discardList.add(cs.getApplicableCiExternalId());
                        continue;
                    }
                } else {
                    AdviceUtils.updateCreditStageWithPaynowStage(loggingKey, stage, cs);
                    if (cs.getApplicableServiceStage() == null) {
                        // if a paynowstage is not linked to a promo that means applicable offer
                        // is not part of advice. So ignore credit
                        INFO(
                                m_logger, methodKey + cs.getApplicableCiExternalId()
                                        + StringUtils.SPACE + "is not part of advice. Skip promo.");
                        cs.setAocGrantToZero();
                        discardList.add(cs.getApplicableCiExternalId());
                        continue;
                    } else if (cs.getApplicableServiceStage() != null
                            && cs.getApplicableServiceStage().isSkipRenewal()) {
                        // if a paynowstage shows zero dollar payment then credits are not
                        // applicable
                        INFO(
                                m_logger,
                                methodKey + cs.getApplicableCiExternalId() + StringUtils.SPACE
                                        + "does not need any payment. Add promo for class code only.");
                    }
                    AdviceUtils.updateFlagBalanceConditions(loggingKey, stage, subscription, cs);
                    AdviceUtils.applyCreditIncludeAttributeRules(loggingKey, subscription, cs);
                }
            }

            for (String applicableCi : discardList) {
                if (gcs.getCreditMap().get(applicableCi) != null) {
                    gcs.removeCreditStageFor(applicableCi);
                }
            }

            for (CreditStage cs : gcs.getCreditMap().values()) {
                stage.getCreditMap().put(cs.getPromoOfferPair(), cs);
                INFO(
                        m_logger,
                        methodKey + "Added AOC credit : " + StringUtils.SPACE
                                + cs.getPromotionName() + StringUtils.SPACE
                                + cs.getGlobalCreditStage().toJson());
            }

        } else {
            INFO(
                    m_logger,
                    methodKey + gcs.getPromotionName() + StringUtils.SPACE + "not added."
                            + StringUtils.SPACE + "Available credits: "
                            + gcs.getAvailableCredits());
        }

    }

    private void processAocGrant(String loggingKey,
                                 AdviceDataStage stage,
                                 GlobalCreditStage gcs,
                                 MtxSubscriberSearchData searchData,
                                 Set<String> applicableCiSet,
                                 boolean forChangeServiceDelta)
            throws CommonUtilsException, IntrospectionException, PaymentAdviceException {
        final String methodKey = loggingKey + " processAocGrant: " + gcs.getClassCode() + ": ";
        INFO(m_logger, methodKey);

        for (String applicableCi : applicableCiSet) {
            if (stage.getServiceStage(applicableCi) != null || forChangeServiceDelta) {
                MtxPurchasedOfferDataBuilder poDataBuilder = (new MtxPurchasedOfferDataBuilder()).withOfferExternalId(
                        gcs.getRedeemOfferCi()).withCreditGrantType(
                                gcs.getCreditGrantType()).withGoodType(
                                        gcs.getRedeemGoodType()).withCoreBasePlanCI(applicableCi);

                if (forChangeServiceDelta && !applicableCi.equalsIgnoreCase(
                        stage.getChangeServiceDataStage().getAsisCatalogItem().getCatalogItemExternalId())
                        && !applicableCi.equalsIgnoreCase(
                                stage.getChangeServiceDataStage().getNewCatalogItemExternalId())) {
                    continue;
                }

                if (forChangeServiceDelta) {
                    if (AppPropertyParser.getStringList(
                            CHANGE_SERVICE_CONSTANTS.DELTA_FREE_CLASS_CODE_UPPER_CASE_LIST).contains(
                                    gcs.getClassCode().trim().toUpperCase())) {
                        continue;
                    } else {
                        poDataBuilder.withInfo(CHANGE_SERVICE_CONSTANTS.AOC_PROMO_INFO_FOR_DELTA);
                    }
                }

                if (stage.getAdviceFor() == AdviceDataStage.Advice.PURCHASE) {
                    VisiblePurchasedOfferExtension initVpoe = null;
                    boolean notInAdvice = true;
                    for (VisiblePurchaseInfo vpi : stage.getPurchaseRequest().getPurchaseInfo()) {
                        if (vpi.getPurchaseServiceInfo().getServiceOfferExternalId().equals(
                                applicableCi)) {
                            initVpoe = vpi.getAttrData();
                            notInAdvice = false;
                            break;
                        }
                    }
                    if (notInAdvice) {
                        INFO(
                                m_logger,
                                loggingKey + methodKey
                                        + "is not part of advice. Skipping promotion for this CI."
                                        + StringUtils.SPACE + gcs.getPromotionName());
                        continue;
                    }

                    if (initVpoe != null) {
                        poDataBuilder.withOfferExtn(initVpoe);
                        if (applicableCiSet.size() > 1) {
                            INFO(
                                    m_logger,
                                    methodKey
                                            + "Setting Attribute Data for AOC call from input offer"
                                            + StringUtils.SPACE + applicableCi + StringUtils.SPACE
                                            + "to promo" + StringUtils.SPACE
                                            + gcs.getPromotionName() + ".");
                        }
                    }
                }
                BigDecimal aocGrantAmount = getChargeableAmountForPurchaseOffer(
                        loggingKey, gcs.getRedeemOfferCi(), poDataBuilder.build(), searchData);
                CreditStage cs = new CreditStage(gcs, applicableCi);
                cs.setAocGrant(aocGrantAmount.negate());
                if (cs.getAocGrant().signum() <= 0) {
                    INFO(m_logger, methodKey + "AOC promo can not be used if aoc redeem is zero.");
                    cs.setKeepTransferableZero(true);
                }
                cs.getGlobalCreditStage().getCreditMap().put(cs.getApplicableCiExternalId(), cs);
            }
        }
    }

    private void updateOneTimeCreditsForDelta(String loggingKey,
                                              String route,
                                              MtxResponseSubscription subscription,
                                              AdviceDataStage deltaStage,
                                              VisibleRequestChangeServiceAdvice request)
            throws PaymentAdviceException, IllegalAccessException, InvocationTargetException,
            NoSuchMethodException, IntrospectionException {
        final String methodKey = loggingKey + " updateOneTimeCreditsForDelta: ";
        INFO(m_logger, methodKey);
        List<String> restrictedList = new ArrayList<String>();
        request.getDeltaPromotionList().forEach(csp -> {
            if (csp.getDeltaPromotionLimit() != null && csp.getDeltaPromotionLimit().signum() > 0) {
                restrictedList.add(csp.getClassCode());
            }
        });
        updateStartWithGrantBalanceCredits(
                loggingKey, route, subscription, deltaStage, null, true, restrictedList);
        request.getDeltaPromotionList().forEach(csp -> {
            if (deltaStage.getCreditMap() == null) {
                return;
            }
            for (CreditStage cs : deltaStage.getCreditMap().values()) {
                if (cs.getClassCode().equalsIgnoreCase(csp.getClassCode())) {
                    cs.getGlobalCreditStage().setCreditCapOrig(
                            cs.getGlobalCreditStage().getCreditCap());
                    cs.getGlobalCreditStage().setCreditCap(csp.getDeltaPromotionLimit());
                }
            }
        });
    }

    private void updateStartWithGrantBalanceCredits(String loggingKey,
                                                    String route,
                                                    MtxResponseSubscription subscription,
                                                    AdviceDataStage stage,
                                                    // If promo is used here reduce it for new stage
                                                    AdviceDataStage reservedStage,
                                                    boolean keepZeroValuePromo)
            throws PaymentAdviceException, IllegalAccessException, InvocationTargetException,
            NoSuchMethodException, IntrospectionException {
        updateStartWithGrantBalanceCredits(
                loggingKey, route, subscription, stage, reservedStage, keepZeroValuePromo, null);
    }

    private void updateStartWithGrantBalanceCredits(String loggingKey,
                                                    String route,
                                                    MtxResponseSubscription subscription,
                                                    AdviceDataStage stage,
                                                    // If promo is used here reduce it for new stage
                                                    AdviceDataStage reservedStage,
                                                    boolean keepZeroValuePromo,
                                                    // Evaluate only these credits. Ignore the rest.
                                                    // List should have ClassCodes
                                                    List<String> restrictedList)
            throws PaymentAdviceException, IllegalAccessException, InvocationTargetException,
            NoSuchMethodException, IntrospectionException {
        final String methodKey = loggingKey + " updateStartWithGrantBalanceCredits: ";
        INFO(m_logger, methodKey);
        if (subscription.getBalanceArray() == null) {
            return;
        }
        MtxRequestMulti multiReq = new MtxRequestMulti();
        for (MtxBalanceInfo bi : subscription.getBalanceArray()) {
            if (!BALANCE_CONSTANTS.BALANCE_CLASS_CREDITS.equalsIgnoreCase(bi.getClassName() + "")) {
                continue;
            } else if (BALANCE_CONSTANTS.BALANCE_LIFETIME_GOODWILL_METER.equalsIgnoreCase(
                    bi.getName())) {
                continue;
            } else if (!CommonUtils.isBalanceActiveOnDate(
                    loggingKey, m_logger, bi, stage.getCycleStartTime())) {
                continue;
            } else {
                MtxRequestPricingQueryBalance query = new MtxRequestPricingQueryBalance();
                MtxPricingBalanceSearchData searchData = new MtxPricingBalanceSearchData();
                searchData.setBalanceId(bi.getTemplateId());
                query.setBalanceSearchData(searchData);
                multiReq.appendRequestList(query);
            }
        }

        if (multiReq.getRequestList() == null || multiReq.getRequestList().size() <= 0) {
            INFO(
                    m_logger, methodKey + "Subscriber does not have any balances of class "
                            + BALANCE_CONSTANTS.BALANCE_CLASS_CREDITS);
            return;
        }

        MtxResponseMulti multiResp = multiRequest(loggingKey, route, multiReq);

        if (multiResp == null || multiResp.getResult() != RESULT_CODES.MTX_SUCCESS
                || multiResp.getResponseList().size() < multiReq.getRequestListAppender().size()) {
            Long resultCode = multiResp != null
                    ? multiResp.getResult() : RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR;
            String message = methodKey + "Could not query balances from Pricing."
                    + (multiResp != null ? " - " + multiResp.getResultText() : "");
            throw new PaymentAdviceException(resultCode, message);
        }

        for (MtxResponse resp : multiResp.getResponseList()) {
            MtxResponsePricingBalance rpb = (MtxResponsePricingBalance) resp;
            GlobalCreditStage gcs = null;
            if (rpb.getBalanceInfo().getAttrList() == null) {
                INFO(
                        m_logger, methodKey + "No Balance Attribute found for "
                                + rpb.getBalanceInfo().getName());
                continue;
            }
            for (MtxPricingAttrInfo pai : rpb.getBalanceInfo().getAttrList()) {
                if (!BALANCE_CONSTANTS.BALANCE_ATTR_GRANT_CI.equalsIgnoreCase(
                        pai.getName().trim())) {
                    continue;
                }
                if (stage.isPromoInCreditMap(pai.getValue().trim())) {
                    INFO(
                            m_logger, methodKey + pai.getValue() + ": "
                                    + "OneTime purchase based Credit stage already initialized in previous cycle. No need to query pricing again.");
                    continue;
                }

                try {
                    MtxResponsePricingCatalogItem pci = queryPricingCatalogItem(
                            loggingKey, route, pai.getValue().trim());
                    INFO(
                            m_logger,
                            methodKey + pai.getValue() + ": " + "Global Credit Stage created.");
                    AdviceUtils.updateOneTimeCredit(
                            loggingKey, subscription, stage, reservedStage, pci, rpb,
                            keepZeroValuePromo, restrictedList);
                    break;
                } catch (Exception e) {
                    Long resultCode = RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR;
                    String message = methodKey + "Could not create Credit Stage for grant balance"
                            + StringUtils.SPACE + rpb.getBalanceInfo().getName();
                    INFO(
                            m_logger, message + StringUtils.SPACE + "Error Message: "
                                    + StringUtils.SPACE + ExceptionUtils.getStackTrace(e));
                    throw new PaymentAdviceException(
                            resultCode, message + StringUtils.SPACE + "Error Message: "
                                    + StringUtils.SPACE + e.getMessage());
                }
            }
        }
    }

    private void updateStartWithPurchasedOfferCredits(String loggingKey,
                                                      String route,
                                                      MtxResponseSubscription subscription,
                                                      AdviceDataStage stage,
                                                      // If promo is used here reduce it for new
                                                      // stage
                                                      AdviceDataStage reservedStage,
                                                      boolean keepZeroValuePromo)
            throws Exception {
        final String methodKey = loggingKey + " updateStartWithPurchasedOfferCredits: ";
        INFO(m_logger, methodKey);
        if (subscription.getPurchasedOfferArray() == null) {
            return;
        }

        for (MtxPurchasedOfferInfo poi : subscription.getPurchasedOfferArray()) {
            if (StringUtils.isBlank(poi.getCatalogItemExternalId())) {
                // This is not a grant offer so skip
                INFO(
                        m_logger,
                        methodKey + poi.getProductOfferExternalId() + " No catalog item id.Skip");
                continue;
            } else if (CI_EXTERNAL_IDS.SETUP_SERVICES.equalsIgnoreCase(
                    poi.getCatalogItemExternalId())
                    || CI_EXTERNAL_IDS.SETUP_MAINBALANCE.equalsIgnoreCase(
                            poi.getCatalogItemExternalId())) {
                INFO(
                        m_logger,
                        methodKey + poi.getCatalogItemExternalId() + " Not a grant offer.Skip");
                continue;
            } else if (stage.getServiceStage(poi.getCatalogItemExternalId()) != null) {
                // This is not a grant offer so skip
                INFO(
                        m_logger, methodKey + poi.getCatalogItemExternalId()
                                + " Same as to-be Service Offer. Not a grant offer.Skip");
                continue;
            } else if (stage.getAdviceFor() == AdviceDataStage.Advice.CHANGE
                    && poi.getCatalogItemExternalId().equalsIgnoreCase(
                            stage.getChangeServiceDataStage().getAsisCatalogItem().getCatalogItemExternalId())) {
                INFO(
                        m_logger, methodKey + poi.getCatalogItemExternalId()
                                + " Same as as-is Service Offer. Not a grant offer.Skip");
                continue;
            } else if (stage.getChangeServiceDataStage() != null
                    && stage.getChangeServiceDataStage().getAsisCatalogItem() != null
                    && poi.getCatalogItemExternalId().equalsIgnoreCase(
                            stage.getChangeServiceDataStage().getAsisCatalogItem().getCatalogItemExternalId())) {
                INFO(
                        m_logger, methodKey + poi.getCatalogItemExternalId()
                                + " Same as as-is Service Offer. Not a grant offer.Skip");
                continue;
            } else if (!CommonUtils.isOfferActiveOnDate(
                    loggingKey, m_logger, poi, stage.getCycleStartTime())) {
                // Inactive so skip
                INFO(
                        m_logger,
                        methodKey + poi.getProductOfferExternalId() + " skip inactive offer.");
                continue;
            } else if (stage.isPromoInCreditMap(poi.getCatalogItemExternalId().trim())) {
                INFO(
                        m_logger, methodKey
                                + "Subscription based Credit stage already initialized. No need to query pricing again.");
                continue;
            }
            MtxResponsePricingCatalogItem pci = queryPricingCatalogItem(
                    loggingKey, route, poi.getCatalogItemExternalId());

            if (pci == null || pci.getCatalogItemInfo() == null
                    || pci.getCatalogItemInfo().getTemplateAttr() == null
                    || !(pci.getCatalogItemInfo().getTemplateAttr() instanceof VisibleTemplate)) {
                INFO(
                        m_logger, methodKey
                                + "does not have Visible Template attributes. It will not be processed");
                continue;
            } else {
                VisibleTemplate vt = (VisibleTemplate) pci.getCatalogItemInfo().getTemplateAttr();
                INFO(
                        m_logger,
                        methodKey + "Configured Discount Calulation Method: "
                                + vt.getDiscountCalculationMethod() + " compared with: "
                                + CREDIT_CONSTANTS.CALCULATION_METHOD_AOC);

                if (CREDIT_CONSTANTS.CALCULATION_METHOD_AOC.equalsIgnoreCase(
                        vt.getDiscountCalculationMethod())) {
                    updateSingleAocCredit(
                            loggingKey, route, poi.getCatalogItemExternalId(), subscription, stage);
                } else {
                    AdviceUtils.processSubscriptionBasedCredit(
                            loggingKey, route, subscription, pci, stage, reservedStage, poi, null,
                            null, false, keepZeroValuePromo);
                }
            }
        }
    }

    private void updateChangeServiceFuturePromotions(String loggingKey,
                                                     String route,
                                                     VisibleRequestChangeServiceAdvice request,
                                                     MtxResponseSubscription subscription,
                                                     AdviceDataStage stage)
            throws Exception {
        final String methodKey = loggingKey + " updateChangeServiceFuturePromotions: ";
        INFO(
                m_logger, methodKey
                        + "Evaluating future promotions from ChangeServiceAdvice request parameters.");
        List<VisibleChangeServicePromo> newGrantOfferList = request.getNewPromotionList();
        if (newGrantOfferList == null || newGrantOfferList.isEmpty()) {
            return;
        }

        for (VisibleChangeServicePromo csp : newGrantOfferList) {
            MtxResponsePricingCatalogItem pci = queryPricingCatalogItem(
                    loggingKey, route, csp.getGrantOfferCI());
            AdviceUtils.processSubscriptionBasedCredit(
                    loggingKey, route, subscription, pci, stage, null, null,
                    FuturePromo.getFuturePromoFromChangeServicePromo(csp),
                    request.getNewCatalogItemExternalId(), true, false);
        }
    }

    private void updateQuoteAdviceFuturePromotions(String loggingKey,
                                                   String route,
                                                   MtxResponseSubscription subscription,
                                                   AdviceDataStage stage,
                                                   VisibleRequestQuoteAdviceService request)
            throws Exception {
        final String methodKey = loggingKey + " updateQuoteAdviceFuturePromotions: ";
        INFO(
                m_logger,
                methodKey + "Evaluating future promotions from QuoteAdvice request parameters.");
        List<VisibleFuturePromo> newGrantOfferList = request.getAdditionalPromoList();
        if (newGrantOfferList == null || newGrantOfferList.isEmpty()) {
            return;
        }

        for (VisibleFuturePromo fp : newGrantOfferList) {
            MtxResponsePricingCatalogItem pci = queryPricingCatalogItem(
                    loggingKey, route, fp.getGrantOfferCI());
            AdviceUtils.processSubscriptionBasedCredit(
                    loggingKey, route, subscription, pci, stage, null, null,
                    FuturePromo.getFuturePromoFromVisibleFuturePromo(fp), null, true, false);
        }
    }

    /**
     * Build final output
     *
     * @param loggingKey
     * @param route
     * @param stage
     * @param output
     * @return
     * @throws PaymentAdviceException
     * @throws JsonParseException
     * @throws JsonMappingException
     * @throws IOException
     * @throws IntegrationServiceException
     */
    @SuppressWarnings("unchecked")
    private VisibleResponsePaymentAdviceService updateAOPOutput(String loggingKey,
                                                                String route,
                                                                AdviceDataStage stage,
                                                                VisibleResponsePaymentAdviceService output)
            throws PaymentAdviceException, JsonParseException, JsonMappingException, IOException,
            IntegrationServiceException {

        output.setSubscriberExternalId(stage.getSubscriptionExternalId());
        output.setResult(stage.getResultCode());
        output.setResultText(stage.getResultText());
        output.setAvailableMainBalanceAmount(stage.getAvailableMainBalanceAmount());
        output.setConsumableMainBalanceAmount(stage.getConsumableMainBalanceAmount());
        output.setEstimatedPayableAmount(stage.getRechargeAmount());
        output.setTotalEstimatedAmount(stage.getTotalEstimatedAmount());
        if (stage.getSubscriptionResponse() != null
                && stage.getSubscriptionResponse().getAttr() != null
                && stage.getSubscriptionResponse().getAttr() instanceof VisibleSubscriberExtension) {
            VisibleSubscriberExtension attr = (VisibleSubscriberExtension) stage.getSubscriptionResponse().getAttr();
            output.setBrand(attr.getBrand());
            output.setPaymentPreference(attr.getPaymentPreference());
            output.setTerminateDate(attr.getTerminateDate());
            output.setPayerExternalId(stage.getPayerExternalId());
        }

        if (stage.getNextCycleStartTime() != null) {
            output.setCycleStartTime(stage.getNextCycleStartTime().toString());
        }
        if (stage.getNextCycleEndTime() != null) {
            output.setCycleEndTime(stage.getNextCycleEndTime().toString());
        }

        // if (stage.getVisibleOfferDetailsMap() != null
        // && stage.getVisibleOfferDetailsMap().values() != null) {
        for (VisibleOfferDetails vod : CommonUtils.emptyValuesIfNull(
                stage.getVisibleOfferDetailsMap())) {
            if (AdviceDataStage.Advice.PURCHASE == stage.getAdviceFor()) {
                output.appendVisibleOfferDetailsList(vod);
                continue;
            }
            VisibleOfferDetails vodFinal = new VisibleOfferDetails();
            vodFinal.setCatalogItemExternalId(vod.getCatalogItemExternalId());
            vodFinal.setPayableAmount(vod.getPayableAmount());
            vodFinal.setOfferType(vod.getOfferType());
            vodFinal.setChargeAmount(vod.getChargeAmount());

            if (StringUtils.isNotBlank(vod.getResourceId())) {
                vodFinal.setResourceId(vod.getResourceId());
            }

            if (StringUtils.isNotBlank(vod.getStatus())) {
                vodFinal.setStatus(vod.getStatus());
            }

            if (StringUtils.isNotBlank(vod.getPurchaseServiceType())) {
                vodFinal.setPurchaseServiceType(vod.getPurchaseServiceType());
            }

            if (vod.getPaidCycleStartDate() != null) {
                vodFinal.setPaidCycleStartDate(vod.getPaidCycleStartDate());
            }

            if (StringUtils.isNotBlank(vod.getCycleStartTime())) {
                vodFinal.setCycleStartTime(vod.getCycleStartTime());
            }

            if (StringUtils.isNotBlank(vod.getCycleEndTime())) {
                vodFinal.setCycleEndTime(vod.getCycleEndTime());
            }

            if (stage.getAdviceFor() != AdviceDataStage.Advice.CHANGE) {
                vodFinal.setConsumableMainBalanceAmount(vod.getConsumableMainBalanceAmount());
            }

            // if (stage.getAdviceFor() != AdviceDataStage.Advice.PURCHASE) {
            if (vod.getCredits() != null) {
                vod.getCredits().forEach(creditRead -> {
                    vodFinal.appendCredits(creditRead);
                });
            }

            if (StringUtils.isNotEmpty(vod.getTaxDetails())) {
                vodFinal.setTaxDetails(vod.getTaxDetails());
            }
            // }

            output.appendVisibleOfferDetailsList(vodFinal);
        }
        // }

        if (stage.getSubscriberGroupList() != null) {
            for (SubscriberGroup sg : stage.getSubscriberGroupList()) {
                VisibleGroup vg = new VisibleGroup();
                vg.setGroupExternalId(sg.getGroupExternalId());
                vg.setGroupName(sg.getGroupName());
                vg.setGroupTier(sg.getGroupTier());
                vg.setSubscriberMemberCount(sg.getSubscriberMemberCount());
                output.appendSubscriberGroups(vg);
                output.setPayerExternalId(
                        sg.getPayerForBeneficiary(stage.getSubscriptionExternalId()));
            }
        }

        for (CreditStage cs : stage.getCreditMap().values()) {
            if (cs.getAvailableCredits().signum() > 0
                    || stage.getAdviceFor() == AdviceDataStage.Advice.CHANGE) {
                VisibleCredits creditOutput = new VisibleCredits();
                creditOutput.setPromotionName(cs.getPromotionName());
                creditOutput.setClassCode(cs.getClassCode());
                creditOutput.setApplicableCI(cs.getApplicableCiExternalId());
                creditOutput.setEstimatedTransferableCredits(cs.getEstimatedTransferableCredits());

                if (!cs.getApplicableServiceStage().isSkipRenewal()) {
                    creditOutput.setAvailableCredits(cs.getAvailableCredits());
                    creditOutput.setAvailableCreditsGrant(cs.getAvailableCreditsGrant());
                    creditOutput.setAvailableCreditsConsumable(cs.getAvailableCreditsConsumable());
                    creditOutput.setCreditRedeemableOfferCI(cs.getRedeemOfferCi());
                    creditOutput.setDiscountCalculationMethod(cs.getDiscountCalculationMethod());
                    creditOutput.setRedeemableGoodType(cs.getRedeemGoodType());
                    creditOutput.setApplicableCreditsPercentage(cs.getApplicableGrantPercentage());
                    if (StringUtils.isNotBlank(cs.getCreditTaxDetails())) {
                        creditOutput.setTaxDetails(cs.getCreditTaxDetails());
                    } else if (cs.isPromotionTaxable()
                            && StringUtils.isNotBlank(AdviceUtils.getErrorResultText(stage))
                            && !(AdviceUtils.getErrorResultText(stage).equalsIgnoreCase("OK"))) {
                        creditOutput.setTaxDetails(AdviceUtils.getErrorResultText(stage));
                    }

                    if (!cs.isNoCap()) {
                        creditOutput.setCreditCap(cs.getCreditCap());
                    }
                    creditOutput.setRedeemableCredits(cs.getRedeemableCredits());
                }

                output.getCreditsAppender().add(creditOutput);
            }
        }

        for (VisibleSubscriberDevice vsd : stage.getSubscriberDeviceList()) {
            output.appendSubscriberDevices(vsd);
        }
        output.setResultText(
                "SubscriptionExternalID: " + stage.getSubscriptionExternalId() + " "
                        + AdviceUtils.getErrorResultText(stage));

        return output;

    }

    private void updateDeviceDetails(String loggingKey,
                                     String route,
                                     MtxResponseSubscription subscription,
                                     AdviceDataStage stage)
            throws PaymentAdviceException {
        String methodName = "updateDeviceDetails";
        ArrayList<MtxObjectId> deviceArrayId = subscription.getDeviceIdArray();
        for (MtxObjectId deviceId : CommonUtils.emptyIfNull(deviceArrayId)) {
            MtxResponseDevice device = queryDeviceData(loggingKey, route, deviceId);
            SimpleEntry<String, MtxPhone> mdnPair = CommonUtils.getMDN(loggingKey, device);
            if (mdnPair == null || mdnPair.getValue() == null) {
                throw new PaymentAdviceException(
                        RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,
                        "Device present without MDN. MDN could not be determined.");
            }
            VisibleSubscriberDevice vsd = new VisibleSubscriberDevice();
            vsd.setDeviceType(mdnPair.getKey());
            vsd.setAccessNumber(mdnPair.getValue().toString());
            stage.getSubscriberDeviceList().add(vsd);
        }
    }

    /**
     * Quote Advice API.
     *
     * @param input
     * @param output
     * @throws Exception
     */
    public void getQuoteAdvice(VisibleRequestQuoteAdviceService input,
                               VisibleResponseQuoteAdviceService output)
            throws Exception {
        // get logging key and route
        String loggingKey = getLoggingKey(input.getSubscriberExternalId());
        String route = getRoute(MatrixxContext.getRequest());
        String methodKey = loggingKey + "getQuoteAdvice: ";
        INFO(m_logger, methodKey);

        requestValidator.validateRequest(loggingKey, input);

        if (input.getAdditionalPromoList() != null && !input.getAdditionalPromoList().isEmpty()) {
            for (VisibleFuturePromo fp : input.getAdditionalPromoList()) {
                MtxResponsePricingCatalogItem pci = queryPricingCatalogItem(
                        loggingKey, route, fp.getGrantOfferCI());
                requestValidator.validateRequestQuotePromoOfferTemplateAttributes(
                        loggingKey, input, pci);
            }
        }

        // 1. get subscriber details
        MtxResponseSubscription subscription = getSubscriptionDetails(
                loggingKey, input.getSubscriberExternalId());

        AdviceDataStage stageCurrentCycle = new AdviceDataStage(
                subscription, AdviceDataStage.Advice.QUOTE, input.getTaxGeoCode(),
                GENERIC_CONSTANTS.YES.equalsIgnoreCase("" + input.getIncludeTaxDetails()));

        if (GENERIC_CONSTANTS.YES.equalsIgnoreCase(input.getIgnorePayer())) {
            stageCurrentCycle.setIgnorePayer(input.getIgnorePayer());
        }

        // 2. update group details
        updateSubscriptionGroups(loggingKey, route, subscription, stageCurrentCycle);
        updatePayerDetails(loggingKey, stageCurrentCycle);
        updatePaidCycleStartDate(loggingKey, stageCurrentCycle, subscription);

        // Get AOC
        MtxResponsePurchase aoc = getAocForQuote(loggingKey, route, stageCurrentCycle, input);

        // 3. Get Initial Paynow amounts
        updateDefaultPaynowAmountsForQuote(loggingKey, route, input, stageCurrentCycle, aoc);

        MtxResponseWallet wallet = querySubscriptionWalletMinimal(
                loggingKey, route, input.getSubscriberExternalId());
        QuoteAdviceUtils.updateDataFromWallet(loggingKey, stageCurrentCycle, wallet);

        updatePayNowFromQuoteRequest(loggingKey, route, input, stageCurrentCycle);

        // 4.calculate Aop Amounts
        updateCreditsForQuoteAdvice(loggingKey, route, subscription, stageCurrentCycle, input);

        // 5 update taxes for payment stage here
        QuoteAdviceUtils.updateTaxesInServiceStage(loggingKey, route, stageCurrentCycle);

        // 6.update taxes
        AdviceUtils.updateOfferDetails(loggingKey, route, stageCurrentCycle);

        // 7. update Payable Amounts
        AdviceUtils.updatePayableAmountsForProration(loggingKey, route, stageCurrentCycle);

        // 8.update credit taxes
        AdviceUtils.updateCreditTaxDetails(loggingKey, route, stageCurrentCycle, subscription);

        // 10. update final api output
        QuoteAdviceUtils.updateQuoteOutput(
                loggingKey, route, subscription, stageCurrentCycle, RESULT_CODES.MTX_SUCCESS,
                MATRIXX_CONSTANTS.RESULT_TEXT_MTX_SUCCESS, output);

        Date currentDate = new Date();
        if (stageCurrentCycle.getPaidCycleStartDate().getTimestamp().after(currentDate)) {
            // update payments for upcoming bill cycle
            AdviceDataStage stageNextCycle = new AdviceDataStage(
                    subscription, AdviceDataStage.Advice.QUOTE, input.getTaxGeoCode(),
                    GENERIC_CONSTANTS.YES.equalsIgnoreCase("" + input.getIncludeTaxDetails()));

            intializeNextCyclePaymentAdviceDataStage(
                    loggingKey, input, subscription, stageCurrentCycle, stageNextCycle);
            calculateQuoteAdviceAmountsForNextCycle(
                    loggingKey, route, subscription, stageNextCycle);
            QuoteAdviceUtils.updateTaxesInServiceStage(loggingKey, route, stageNextCycle);
            AdviceUtils.updateOfferDetails(loggingKey, route, stageNextCycle);
            AdviceUtils.updatePayableAmountsForProration(loggingKey, route, stageNextCycle);
            AdviceUtils.updateCreditTaxDetails(loggingKey, route, stageNextCycle, subscription);

            // update final api output for next cycle
            output = updateQuoteOutputNextCycle(
                    loggingKey, route, subscription, stageNextCycle, RESULT_CODES.MTX_SUCCESS,
                    MATRIXX_CONSTANTS.RESULT_TEXT_MTX_SUCCESS, output);
        }

        if (GENERIC_CONSTANTS.YES.equalsIgnoreCase(input.getIncludePaymentAdvice())) {
            AdviceDataStage aopToBe = getNextCyclePaymentAdvice(
                    loggingKey, route, input, stageCurrentCycle, subscription);
            if (aopToBe != null) {
                updateQuoteAdviceOutputNextCycleAop(loggingKey, aopToBe, output);
            } else {
                output.setResultText(
                        output.getResultText() + " | "
                                + "NextCyclePaymentAdvice can not be created.");
            }
        }
    }

    /**
     * Validate upcoming payments.
     *
     * @param stage
     * @param subscriber
     * @throws PaymentAdviceException
     * @throws IntegrationServiceException
     * @return
     **/
    private void updatePaidCycleStartDate(String loggingKey,
                                          AdviceDataStage stage,
                                          MtxResponseSubscription subscriber) {

        String methodName = "updatePaidCycleStartDate";

        for (MtxPurchasedOfferInfo poi : CommonUtils.emptyIfNull(
                subscriber.getPurchasedOfferArray())) {
            if (poi.getAttr() != null) {
                VisiblePurchasedOfferExtension poe = (VisiblePurchasedOfferExtension) poi.getAttr();
                if (poe.getPaidCycleStartDate() != null) {
                    stage.setPaidCycleStartDate(poe.getPaidCycleStartDate());
                    INFO(
                            m_logger,
                            loggingKey + methodName + StringUtils.SPACE
                                    + " PaidCycleStartDate found : "
                                    + stage.getPaidCycleStartDate());
                    return;
                }
            }
        }

        stage.defaultPaidCycleStartDate();
        INFO(
                m_logger, loggingKey + methodName + StringUtils.SPACE
                        + " PaidCycleStartDate is defaulted to : " + stage.getPaidCycleStartDate());
    }

    private void intializeNextCyclePaymentAdviceDataStage(String loggingKey,
                                                          VisibleRequestQuoteAdviceService input,
                                                          MtxResponseSubscription subscription,
                                                          AdviceDataStage quoteStage,
                                                          AdviceDataStage nextStage)
            throws PaymentAdviceException {
        final String methodKey = loggingKey + " intializeNextCyclePaymentAdviceDataStage: ";
        INFO(m_logger, methodKey);
        nextStage.setPayerExternalId(quoteStage.getPayerExternalId());
        nextStage.setPayerGeoCode(quoteStage.getPayerGeoCode());
        nextStage.setIgnorePayer(quoteStage.getIgnorePayer());
        nextStage.setPaidCycleStartDate(quoteStage.getPaidCycleStartDate());
        nextStage.setAvailableMainBalanceAmount(
                quoteStage.getAvailableMainBalanceAmount().subtract(
                        quoteStage.getConsumableMainBalanceAmount()));
        for (Entry<CiResourceIdPair, ServiceStage> paynowEntry : quoteStage.getPayNowMap().entrySet()) {
            CiResourceIdPair key = new CiResourceIdPair(
                    paynowEntry.getKey().getCatalogItemExternalId(),
                    paynowEntry.getKey().getResourceId().longValue());
            ServiceStage paynowClone = paynowEntry.getValue().shallowClone();
            paynowClone.setCreditsUsed(BigDecimal.ZERO);
            paynowClone.setFinalPayableAmount(paynowClone.getDiscountPrice());// Full Cycle
            paynowClone.setNonCreditAmount(paynowClone.getDiscountPrice());// Full Cycle
            paynowClone.setProratedDiscountPrice(paynowClone.getDiscountPrice());// Full Cycle
            paynowClone.setAocDiscountPrice(paynowClone.getDiscountPrice());
            paynowClone.setTaxFeeAmount(BigDecimal.ZERO);
            nextStage.getPayNowMap().put(key, paynowClone);
            INFO(
                    m_logger, methodKey + "Next cycle service stage derviced from quote cycle: "
                            + paynowClone.toShortJson());
        }

        for (Entry<PromoOfferPair, CreditStage> enRouteToGcs : quoteStage.getCreditMap().entrySet()) {
            PromoOfferPair key = enRouteToGcs.getKey();
            String promo = key.getPromoCiExternalId();
            CreditStage value = enRouteToGcs.getValue();
            if (value.getGlobalCreditStage().getAvailableCredits().subtract(
                    value.getGlobalCreditStage().getGlobalRedeemables()).signum() <= 0) {
                continue;// All promos used in previous cycle.
            }
            GlobalCreditStage gcs = value.getGlobalCreditStage().shallowClone();
            gcs.setAvailableCredits(
                    value.getGlobalCreditStage().getAvailableCredits().subtract(
                            value.getGlobalCreditStage().getGlobalRedeemables()));
            gcs.setAvailableCreditsGrant(
                    value.getGlobalCreditStage().getAvailableCreditsGrant().subtract(
                            value.getGlobalCreditStage().getGlobalGrantsReserved()));
            gcs.setAvailableCreditsConsumable(
                    value.getGlobalCreditStage().getAvailableCreditsConsumable().subtract(
                            value.getGlobalCreditStage().getGlobalConsumablesReserved()));
            for (Entry<PromoOfferPair, CreditStage> promoEntry : quoteStage.getCreditMap().entrySet()) {
                String promo1 = promoEntry.getKey().getPromoCiExternalId();
                if (promo.equalsIgnoreCase(promo1)) {
                    CreditStage csClone = promoEntry.getValue().shallowClone(gcs);
                    csClone.setCreditTaxApiErrorMessage(StringUtils.EMPTY);
                    csClone.setCreditTaxDetails(StringUtils.EMPTY);
                    csClone.setEstimatedTransferableCreditsToZero();
                    csClone.setPercentageGrantToZero();
                    csClone.setAocGrantToZero();
                    csClone.setRedeemableConsumablesToZero();
                    csClone.setRedeemableCreditsToZero();
                    gcs.addOrReplaceCreditStage(csClone);

                    AdviceUtils.updateCreditStageWithPaynowStage(loggingKey, nextStage, csClone);
                    if (csClone.getApplicableServiceStage() == null) {
                        // if a paynowstage is not linked to a promo that means applicable offer is
                        // not part of advice. So ignore credit
                        continue;
                    }
                    AdviceUtils.updateFlagBalanceConditions(
                            loggingKey, nextStage, subscription, csClone);
                    // AdviceUtils.updateFlagBalanceConditions(loggingKey, nextStage, subscription,
                    // csClone);
                    nextStage.getCreditMap().put(promoEntry.getKey(), csClone);
                }
            }
        }
    }

    /**
     * Update Initial Amounts.
     *
     * @param stage
     * @param aoc
     * @return
     * @throws PaymentAdviceException
     * @throws IntegrationServiceException
     */
    private void updatePayNowFromQuoteRequest(String loggingKey,
                                              String route,
                                              VisibleRequestQuoteAdviceService quoteRequest,
                                              AdviceDataStage stage) {
        final String methodKey = loggingKey + "updatePayNowFromQuoteRequest: ";
        quoteRequest.getCatalogItemList().forEach(ci -> {
            stage.getPayNowMap().values().forEach(ps -> {
                if (ps.getCatalogItemExternalId().equals(ci.getCatalogItemExternalId())) {
                    ps.setDiscountPrice(ci.getDiscountPrice());
                    if (ci.getGrossPrice() != null) {
                        ps.setGrossPrice(ci.getGrossPrice());
                    } else {
                        ps.setGrossPrice(ci.getDiscountPrice());
                    }
                    INFO(
                            m_logger,
                            methodKey + "Updated Paynow Stage from Quote Request: " + ps.toJson());
                }
            });
        });
    }

    private void updateDefaultPaynowAmountsForQuote(String loggingKey,
                                                    String route,
                                                    VisibleRequestQuoteAdviceService request,
                                                    AdviceDataStage stage,
                                                    MtxResponsePurchase aoc)
            throws PaymentAdviceException, IntegrationServiceException {
        final String methodKey = loggingKey + "updateDefaultPaynowAmountsForQuote: ";

        stage.setTotalEstimatedAmount(BigDecimal.ZERO);

        for (MtxPurchaseInfo pi : aoc.getPurchaseInfoArray()) {
            if (pi.getBalanceImpactGroupList() != null
                    && !pi.getBalanceImpactGroupList().isEmpty()) {
                for (MtxBalanceImpactInfoGroup biInfoGroup : pi.getBalanceImpactGroupList()) {
                    if (stage.getCycleStartTime() == null) {
                        stage.setCycleStartTime(biInfoGroup.getCycleStartTime());
                    }
                    if (stage.getCycleEndTime() == null) {
                        stage.setCycleEndTime(biInfoGroup.getCycleEndTime());
                    }
                }
                updateDefaultPaynowAmountsForQuote(
                        loggingKey, route, stage, pi.getBalanceImpactGroupList());
            } else {
                INFO(
                        m_logger,
                        methodKey + "Engine did not provide any balance impact for for offer: "
                                + pi.getCatalogItemExternalId());
                INFO(
                        m_logger, methodKey + "Cycle Info is not available for: "
                                + pi.getCatalogItemExternalId());
                String message = "Advice of Charge not available for non-zero offer: "
                        + pi.getCatalogItemExternalId();
                INFO(m_logger, methodKey + message);
                throw new PaymentAdviceException(RESULT_CODES.HTTP_INTERNAL_ERROR, message);
            }
            if (pi.getEndTime() != null) {
                ServiceStage svcStg = stage.getServiceStage(pi.getCatalogItemExternalId());
                if (svcStg != null) {
                    svcStg.setPurchaseOfferEndTime(pi.getEndTime());
                }
            }
        }
    }

    /**
     * AOC for quote amount
     *
     * @param loggingKey
     * @param route
     * @param billingCycleId
     * @param billingCycleOfset
     * @param searchData
     * @return
     * @throws PaymentAdviceException
     */
    private MtxResponsePurchase getAocForQuote(String loggingKey,
                                               String route,
                                               AdviceDataStage stage,
                                               VisibleRequestQuoteAdviceService input)
            throws PaymentAdviceException {
        final String methodKey = loggingKey + "getAocForQuote: ";
        BigDecimal proratedChargeAmount = BigDecimal.ZERO;
        INFO(m_logger, methodKey + "Calling purchase offer AOC");

        MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
        searchData.setExternalId(input.getSubscriberExternalId());

        MtxRequestMulti multiReq = new MtxRequestMulti();

        // Temporarily enable BillCycle
        MtxRequestSubscriberModify subModify = new MtxRequestSubscriberModify();
        subModify.setSubscriberSearchData(searchData);
        subModify.setBillingCycleDisabled(false);
        multiReq.appendRequestList(subModify);

        // Temporarily set BillCycle
        subModify = new MtxRequestSubscriberModify();
        subModify.setSubscriberSearchData(searchData);
        MtxBillingCycleData bcd = new MtxBillingCycleData();
        bcd.setBillingCycleId(BigInteger.valueOf(input.getBillingCycleId()));
        bcd.setDateOffset(
                input.getBillingCycleOffset() == null ? 0l : input.getBillingCycleOffset());
        subModify.setBillingCycle(bcd);
        multiReq.appendRequestList(subModify);

        MtxRequestSubscriberPurchaseOffer purReq = new MtxRequestSubscriberPurchaseOffer();

        for (VisibleCatalogItem ci : input.getCatalogItemList()) {
            MtxPurchasedOfferData mpod = new MtxPurchasedOfferData();
            mpod.setExternalId(ci.getCatalogItemExternalId());
            VisiblePurchasedOfferExtension attr = new VisiblePurchasedOfferExtension();
            attr.setChargeAmount(ci.getDiscountPrice());
            mpod.setAttr(attr);
            purReq.appendOfferRequestArray(mpod);
        }

        purReq.setSubscriberSearchData(searchData);
        multiReq.appendRequestList(purReq);

        // Set to Advice Mode
        multiReq.setExecuteMode(MATRIXX_CONSTANTS.ADVICE_MODE);

        MtxResponseMulti multiResp = multiRequest(loggingKey, route, multiReq);

        if (multiResp == null || multiResp.getResult() != RESULT_CODES.MTX_SUCCESS
                || multiResp.getResponseList().size() != multiReq.getRequestListAppender().size()) {
            Long resultCode = multiResp != null
                    ? multiResp.getResult() : RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR;
            String message = LOG_MESSAGES.FAILED_TO_GET_PURCHASE_AOC
                    + (multiResp != null ? " - " + multiResp.getResultText() : "");
            INFO(m_logger, methodKey + message);
            throw new PaymentAdviceException(resultCode, message);
        }
        INFO(
                m_logger, methodKey + "Purchase offer AOC response" + StringUtils.SPACE
                        + multiResp.getResponseList().get(2).toJson());
        return (MtxResponsePurchase) multiResp.getResponseList().get(2);
    }

    /**
     * Update Output for Quote Advice
     *
     * @param loggingKey
     * @param route
     * @param subscription
     * @param stage
     * @param resultCode
     * @param resultText
     * @param output
     * @return
     * @throws PaymentAdviceException
     * @throws JsonParseException
     * @throws JsonMappingException
     * @throws IOException
     * @throws IntegrationServiceException
     */

    @SuppressWarnings("unchecked")
    private VisibleResponseQuoteAdviceService updateQuoteOutputNextCycle(String loggingKey,
                                                                         String route,
                                                                         MtxResponseSubscription subscriber,
                                                                         AdviceDataStage stageNextCycle,
                                                                         long resultCode,
                                                                         String resultText,
                                                                         VisibleResponseQuoteAdviceService output)
            throws PaymentAdviceException, JsonParseException, JsonMappingException, IOException,
            IntegrationServiceException, javax.naming.ConfigurationException {

        VisibleUpcomingCycle vuc = new VisibleUpcomingCycle();

        if (stageNextCycle.getVisibleOfferDetailsMap() != null
                && stageNextCycle.getVisibleOfferDetailsMap().values() != null) {
            for (VisibleOfferDetails vod : stageNextCycle.getVisibleOfferDetailsMap().values()) {
                VisibleOfferDetails vod1 = new VisibleOfferDetails();
                vod1.setCatalogItemExternalId(vod.getCatalogItemExternalId());

                vod1.setOfferType(vod.getOfferType());
                vod1.setChargeAmount(vod.getChargeAmount());
                vod1.setAocAmount(vod.getAocAmount());
                vod1.setPayableAmount(vod.getPayableAmount());

                if (StringUtils.isNotBlank(vod.getResourceId())) {
                    vod1.setResourceId(vod.getResourceId());
                }

                if (StringUtils.isNotEmpty(vod.getTaxDetails())) {
                    vod1.setTaxDetails(vod.getTaxDetails());
                }

                if (vod.getCredits() != null) {
                    vod.getCredits().forEach(creditRead -> {
                        vod1.appendCredits(creditRead);
                    });
                }
                vuc.appendVisibleOfferDetailsList(vod1);
            }
        }

        vuc.setAvailableMainBalanceAmount(stageNextCycle.getAvailableMainBalanceAmount());
        vuc.setConsumableMainBalanceAmount(stageNextCycle.getConsumableMainBalanceAmount());
        vuc.setEstimatedPayableAmount(stageNextCycle.getRechargeAmount());
        vuc.setTotalEstimatedAmount(stageNextCycle.getTotalEstimatedAmount());

        VisibleSubscriberExtension subAttr = (VisibleSubscriberExtension) subscriber.getAttr();

        // serviceTaxResponse is tax response when called from rest endpoint
        // But we also need this when called from purchase service.
        for (CreditStage creditStage : stageNextCycle.getCreditMap().values()) {
            if (creditStage.getAvailableCredits().signum() <= 0) {
                continue;
            }
            VisibleCredits creditOutput = new VisibleCredits();
            creditOutput.setPromotionName(creditStage.getPromotionName());
            creditOutput.setApplicableCI(creditStage.getApplicableCiExternalId());
            creditOutput.setClassCode(creditStage.getClassCode());
            creditOutput.setAvailableCredits(creditStage.getAvailableCredits());
            creditOutput.setAvailableCreditsGrant(creditStage.getAvailableCreditsGrant());
            creditOutput.setAvailableCreditsConsumable(creditStage.getAvailableCreditsConsumable());
            if (!creditStage.isNoCap()) {
                creditOutput.setCreditCap(creditStage.getCreditCap());
            }
            creditOutput.setEstimatedTransferableCredits(
                    creditStage.getEstimatedTransferableCredits());
            creditOutput.setCreditRedeemableOfferCI(creditStage.getRedeemOfferCi());
            creditOutput.setDiscountCalculationMethod(creditStage.getDiscountCalculationMethod());
            creditOutput.setRedeemableGoodType(creditStage.getRedeemGoodType());
            if (StringUtils.isNotEmpty(creditStage.getCreditTaxDetails())) {
                creditOutput.setTaxDetails(creditStage.getCreditTaxDetails());
            } else if (creditStage.isPromotionTaxable()
                    && StringUtils.isNotBlank(AdviceUtils.getErrorResultText(stageNextCycle))
                    && !(AdviceUtils.getErrorResultText(stageNextCycle).equalsIgnoreCase(
                            MATRIXX_CONSTANTS.RESULT_TEXT_MTX_SUCCESS))) {
                creditOutput.setTaxDetails(AdviceUtils.getErrorResultText(stageNextCycle));
            }

            creditOutput.setApplicableCI(creditStage.getApplicableCiExternalId());
            creditOutput.setRedeemableCredits(creditStage.getRedeemableCredits());
            creditOutput.setApplicableCreditsPercentage(creditStage.getApplicableGrantPercentage());
            vuc.getCreditsAppender().add(creditOutput);
        }
        if (vuc != null) {
            output.setNextCycle(vuc);
        }
        return output;
    }

    public void getChangeServiceAdvice(VisibleRequestChangeServiceAdvice request,
                                       VisibleResponseChangeServiceAdvice response)
            throws Exception {
        getAdviceForChangeService(request, response, null);
    }

    public void getAdviceForChangeService(VisibleRequestChangeServiceAdvice request,
                                          VisibleResponseChangeServiceAdvice response,
                                          MtxResponseSubscription subscription)
            throws Exception {
        String loggingKey = getSubscriptionLoggingKey(request.getSubscriptionExternalId());
        final String methodKey = loggingKey + " getChangeServiceAdvice: ";
        INFO(m_logger, methodKey + "Validate input request: " + request.toJson());
        requestValidator.validateRequest(loggingKey, request);
        String route = getRoute(MatrixxContext.getRequest());
        request.setSubscriptionExternalId(request.getSubscriptionExternalId().trim());
        request.setNewCatalogItemExternalId(request.getNewCatalogItemExternalId().trim());
        response.setSubscriptionExternalId(request.getSubscriptionExternalId());

        MtxResponsePricingCatalogItem pricingNewCI = queryPricingCatalogItem(
                loggingKey, route, request.getNewCatalogItemExternalId());
        INFO(m_logger, methodKey + "Validate that new offer is of type 'Base'.");
        requestValidator.validateRequestBaseOfferTemplateAttributes(
                loggingKey, request, pricingNewCI);

        for (VisibleChangeServiceAddItem csai : CommonUtils.emptyIfNull(request.getAddItems())) {
            MtxResponsePricingCatalogItem pricingAddon = queryPricingCatalogItem(
                    loggingKey, route, csai.getCatalogItemExternalId());
            INFO(m_logger, methodKey + "Validate that additional offer is of the type 'Addon'.");
            requestValidator.validateRequestAddonOfferTemplateAttributes(
                    loggingKey, request, pricingAddon);
        }

        for (VisibleChangeServiceCancelItem csci : CommonUtils.emptyIfNull(
                request.getCancelItems())) {
            MtxResponsePricingCatalogItem pricingAddon = queryPricingCatalogItem(
                    loggingKey, route, csci.getCatalogItemExternalId());
            INFO(m_logger, methodKey + "Validate that additional offer is of the type 'Addon'.");
            requestValidator.validateRequestAddonOfferTemplateAttributes(
                    loggingKey, request, pricingAddon);
        }

        if (subscription == null) {
            subscription = getSubscriptionDetails(loggingKey, request.getSubscriptionExternalId());
        }

        SubscriptionResponse subscriptionResponse = querySubscriptionByExternalId(
                loggingKey, route, request.getSubscriptionExternalId());
        requestValidator.validateRequestCompareSubscription(
                loggingKey, request, subscriptionResponse);

        AdviceDataStage deltaStage = new AdviceDataStage(
                subscriptionResponse, AdviceDataStage.Advice.CHANGE, request.getTaxGeoCode(), true);
        deltaStage.setResultCode(RESULT_CODES.MTX_SUCCESS);
        deltaStage.setResultText(MATRIXX_CONSTANTS.RESULT_TEXT_MTX_SUCCESS);
        deltaStage.getChangeServiceDataStage().setBillCycle(BillCycle.CURRENT);
        deltaStage.getChangeServiceDataStage().setNewCatalogItemExternalId(
                request.getNewCatalogItemExternalId());

        ChangeAdviceUtils.updateMainBalaceCycleDates(loggingKey, subscriptionResponse, deltaStage);

        updateFromEnrolledOffer(loggingKey, route, request, deltaStage, subscriptionResponse);
        // get payment advice with all credits (zero - non zero) check if any promo can not be used
        // with new offer. Also check attributes find difference.
        updateFromPaymentAdvice(
                loggingKey, route, subscriptionResponse, subscription, deltaStage, request);
        ChangeAdviceUtils.updatePayNowFromChangeServiceAdviceRequest(
                loggingKey, route, request, deltaStage);
        updateDelta(loggingKey, route, request, subscription, deltaStage);
        updateDefaultPaynowStageForDelta(
                loggingKey, route, request, deltaStage, subscription, pricingNewCI);
        ChangeAdviceUtils.updateTaxesInServiceStage(loggingKey, route, deltaStage);
        calculateChangeServiceAdviceAmountsForChangeCycle(
                loggingKey, route, subscription, deltaStage, request);
        AdviceUtils.updateOfferDetails(loggingKey, route, deltaStage);
        AdviceUtils.updatePayableAmountsForProration(loggingKey, route, deltaStage);
        ChangeAdviceUtils.updatePayableAmountsForChangeCycle(loggingKey, route, deltaStage);
        AdviceUtils.updateCreditTaxDetails(loggingKey, route, deltaStage, subscription);
        ChangeAdviceUtils.rechargeCorrectionForChangeService(loggingKey, deltaStage);
        ChangeAdviceUtils.updateChangeAdviceOutputCurrentCycle(
                loggingKey, subscription, deltaStage, response);
        if (deltaStage.getChangeServiceDataStage().getNextCycleDetails() == NextCycleDetails.NEXT_CYCLE_PAYMENT) {
            AdviceDataStage stageNextCycle = new AdviceDataStage(
                    subscriptionResponse, AdviceDataStage.Advice.CHANGE, request.getTaxGeoCode(),
                    true);

            intializeNextCycleChangeAdviceDataStage(
                    loggingKey, subscription, deltaStage, stageNextCycle);

            // calculate and update paynow taxes here
            // updateTaxesInPaynowStage(loggingKey, route, stageNextCycle);
            ChangeAdviceUtils.updateTaxesInServiceStage(loggingKey, route, stageNextCycle);
            calculateChangeServiceAdviceAmountsForNextCycle(
                    loggingKey, route, request, subscription, stageNextCycle);

            // 6.update taxes
            AdviceUtils.updateOfferDetails(loggingKey, route, stageNextCycle);

            // 7. update payable amounts
            AdviceUtils.updatePayableAmountsForProration(loggingKey, route, stageNextCycle);

            // 8.update promotion taxes
            AdviceUtils.updateCreditTaxDetails(loggingKey, route, stageNextCycle, subscription);
            ChangeAdviceUtils.rechargeCorrectionForChangeService(loggingKey, stageNextCycle);

            // update final api output for next cycle
            ChangeAdviceUtils.updateChangeAdviceOutputNextCycle(
                    loggingKey, stageNextCycle, response);
        }

        if (GENERIC_CONSTANTS.YES.equalsIgnoreCase(request.getIncludePaymentAdvice())) {
            AdviceDataStage aopToBe = getNextCyclePaymentAdvice(
                    loggingKey, route, request, deltaStage, subscriptionResponse, subscription);
            ChangeAdviceUtils.updateChangeAdviceOutputNextCycleAop(loggingKey, aopToBe, response);
        }
    }

    private void calculateChangeServiceAdviceAmountsForChangeCycle(String loggingKey,
                                                                   String route,
                                                                   MtxResponseSubscription subscription,
                                                                   AdviceDataStage deltaStage,
                                                                   VisibleRequestChangeServiceAdvice request)
            throws IntegrationServiceException, PaymentAdviceException, CommonUtilsException,
            IntrospectionException, IllegalAccessException, InvocationTargetException,
            NoSuchMethodException {
        final String methodKey = loggingKey
                + " calculateChangeServiceAdviceAmountsForChangeCycle: ";
        INFO(m_logger, methodKey);

        if (deltaStage.getChangeServiceDataStage().getDelta().signum() <= 0) {
            INFO(m_logger, methodKey + "Zero delta. Skip delta promotions.");
            deltaStage.getChangeServiceDataStage().getReverseCreditMap().values().forEach(rs -> {
                VisibleReverseCreditInternal rsi = (VisibleReverseCreditInternal) rs;
                rsi.setNoReverseReason(DontReverseCode.ZERO_DELTA);
            });
        } else if (request.getDeltaPromotionList() == null
                || request.getDeltaPromotionList().isEmpty()) {
            INFO(m_logger, methodKey + "No delta promotions to be applied.");
            deltaStage.getChangeServiceDataStage().getReverseCreditMap().values().forEach(rs -> {
                VisibleReverseCreditInternal rsi = (VisibleReverseCreditInternal) rs;
                rsi.setNoReverseReason(DontReverseCode.NO_DELTA_PROMOS);
            });
        } else {
            INFO(
                    m_logger, methodKey + "Apply delta promotions for delta amount:"
                            + deltaStage.getChangeServiceDataStage().getDelta());

            updateOneTimeCreditsForDelta(loggingKey, route, subscription, deltaStage, request);
            AdviceUtils.updateFinalMinimumCharges(loggingKey, deltaStage);

            if (deltaStage.getCreditMap() != null
                    && !deltaStage.getCreditMap().values().isEmpty()) {
                MtxResponseOneTimeOffer oneTimeOffers = querySubscriptionOneTimeOffer(
                        loggingKey, deltaStage.getSubscriptionExternalId());
                if (oneTimeOffers != null && oneTimeOffers.getOneTimeOfferArray() != null) {
                    for (MtxPurchasedOfferInfo redeemOffer : oneTimeOffers.getOneTimeOfferArray()) {
                        deltaStage.getOneTimeOfferList().add(
                                redeemOffer.getCatalogItemExternalId().trim());
                    }
                }
                INFO(m_logger, methodKey + "Onetime offers: " + deltaStage.getOneTimeOfferList());
            }

            deltaStage.getCreditMap().values().forEach((cs) -> {
                if (deltaStage.getChangeServiceDataStage().getReverseCreditMap() == null) {
                    INFO(m_logger, methodKey + "No credits to be reversed.");
                } else if (!deltaStage.getOneTimeOfferList().contains(cs.getRedeemOfferCi().trim())
                        && cs.getAvailableCreditsConsumable().signum() > 0) {
                    INFO(
                            m_logger, methodKey + cs.getPromotionName() + StringUtils.SPACE
                                    + " is not cancellable promo for this subscriber. Cancellation will NOT move amount to Grant.");
                } else if (cs.getAvailableCreditsConsumable().signum() <= 0) {
                    INFO(
                            m_logger, methodKey + cs.getPromotionName() + StringUtils.SPACE
                                    + " has no consumables for this subscriber. Cancellation not required.");
                } else {
                    if (cs.getDiscountCalculationMethod().equalsIgnoreCase(
                            CREDIT_CONSTANTS.CALCULATION_METHOD_AOC)) {
                        INFO(
                                m_logger, methodKey + cs.getPromotionName() + StringUtils.SPACE
                                        + " is an Aoc promo. Cancellation will reduce amount from Consumable Balance.");
                    }
                    VisibleReverseCredit rcs = deltaStage.getChangeServiceDataStage().getReverseCredit(
                            cs.getRedeemOfferCi());
                    if (rcs != null) {
                        INFO(
                                m_logger,
                                methodKey + " Swap grant and consumable for "
                                        + rcs.getPromotionName()
                                        + " to reflect state after promo reveral.");
                        cs.getGlobalCreditStage().setAvailableCreditsGrant(
                                cs.getGlobalCreditStage().getAvailableCreditsGrant().add(
                                        rcs.getAvailableCreditsConsumable()));
                        cs.getGlobalCreditStage().setAvailableCreditsConsumable(
                                cs.getGlobalCreditStage().getAvailableCreditsConsumable().subtract(
                                        rcs.getAvailableCreditsConsumable()).max(BigDecimal.ZERO));
                    } else if (rcs == null
                            && cs.getGlobalCreditStage().getAvailableCreditsConsumable().signum() > 0
                            && !cs.getGlobalCreditStage().getApplicableCiCsv().contains(
                                    deltaStage.getChangeServiceDataStage().getAsisCatalogItem().getCatalogItemExternalId())) {
                        cs.getGlobalCreditStage().setConsumablesUnavailableToChangeService(
                                cs.getGlobalCreditStage().getAvailableCreditsConsumable());
                        deltaStage.getChangeServiceDataStage().setPromoNaDeltaReason(
                                cs.getClassCode() + " is not applicable to ASIS offer "
                                        + deltaStage.getChangeServiceDataStage().getAsisCatalogItem().getCatalogItemExternalId()
                                        + "."
                                        + "Consumables will be assumed to be not available to TOBE offer "
                                        + request.getNewCatalogItemExternalId());
                        cs.getGlobalCreditStage().setAvailableCreditsConsumable(BigDecimal.ZERO);
                    } else if (rcs == null
                            && cs.getGlobalCreditStage().getAvailableCreditsConsumable().signum() > 0) {
                        cs.getGlobalCreditStage().setConsumablesUnavailableToChangeService(
                                cs.getGlobalCreditStage().getAvailableCreditsConsumable());
                        deltaStage.getChangeServiceDataStage().setPromoNaDeltaReason(
                                cs.getClassCode()
                                        + " is not applicable to delta due unknown reasons. "
                                        + "Consumables will be assumed to be not available to TOBE offer "
                                        + request.getNewCatalogItemExternalId());
                        cs.getGlobalCreditStage().setAvailableCreditsConsumable(BigDecimal.ZERO);
                    }
                }
            });

            // Update initial amounts available in each balance
            deltaStage.updateConsumableCreditsMoreThanChargeCondition(loggingKey);
            // Get redeem order here.
            deltaStage.updateCredits(loggingKey);
        }
        deltaStage.updatePayableAmounts(loggingKey);
    }

    private void calculateChangeServiceAdviceAmountsForNextCycle(String loggingKey,
                                                                 String route,
                                                                 VisibleRequestChangeServiceAdvice request,
                                                                 MtxResponseSubscription subscriber,
                                                                 AdviceDataStage nextCycleStage)
            throws Exception {
        final String methodKey = loggingKey + " calculateChangeServiceAdviceAmountsForNextCycle: ";
        INFO(m_logger, methodKey);
        updateAocCredits(loggingKey, route, subscriber, nextCycleStage);
        updateStartWithGrantBalanceCredits(
                loggingKey, route, subscriber, nextCycleStage, null, true);
        updateStartWithPurchasedOfferCredits(
                loggingKey, route, subscriber, nextCycleStage, null, true);
        updateChangeServiceFuturePromotions(loggingKey, route, request, subscriber, nextCycleStage);

        AdviceUtils.updateFinalMinimumCharges(loggingKey, nextCycleStage);

        if (nextCycleStage.getOneTimeOfferList() == null
                || nextCycleStage.getOneTimeOfferList().isEmpty()) {
            MtxResponseOneTimeOffer oneTimeOffers = querySubscriptionOneTimeOffer(
                    loggingKey, nextCycleStage.getSubscriptionExternalId());
            if (oneTimeOffers != null && oneTimeOffers.getOneTimeOfferArray() != null) {
                for (MtxPurchasedOfferInfo redeemOffer : oneTimeOffers.getOneTimeOfferArray()) {
                    nextCycleStage.getOneTimeOfferList().add(
                            redeemOffer.getCatalogItemExternalId().trim());
                }
            }
            INFO(m_logger, methodKey + "Onetime offers : " + nextCycleStage.getOneTimeOfferList());
        }

        nextCycleStage.getCreditMap().values().forEach((cs) -> {
            if (nextCycleStage.getChangeServiceDataStage().getReverseCreditMap() == null) {
                INFO(m_logger, methodKey + "No credits to be reversed.");
            } else if (!nextCycleStage.getOneTimeOfferList().contains(cs.getRedeemOfferCi().trim())
                    && cs.getAvailableCreditsConsumable().signum() > 0) {
                INFO(
                        m_logger, methodKey + cs.getPromotionName() + StringUtils.SPACE
                                + " is not cancellable promo for this subscriber. Cancellation will NOT move amount to Grant.");
            } else if (cs.getAvailableCreditsConsumable().signum() <= 0) {
                INFO(
                        m_logger, methodKey + cs.getPromotionName() + StringUtils.SPACE
                                + " has no consumables for this subscriber. Cancellation not required.");
            } else {
                if (cs.getDiscountCalculationMethod().equalsIgnoreCase(
                        CREDIT_CONSTANTS.CALCULATION_METHOD_AOC)) {
                    INFO(
                            m_logger, methodKey + cs.getPromotionName() + StringUtils.SPACE
                                    + " is an Aoc promo. Cancellation will reduce amount from Consumable Balance.");
                }
                VisibleReverseCredit rcs = nextCycleStage.getChangeServiceDataStage().getReverseCredit(
                        cs.getRedeemOfferCi());
                if (rcs != null) {
                    INFO(
                            m_logger,
                            methodKey + " Swap grant and consumable for " + rcs.getPromotionName()
                                    + " to reflect state after promo reveral.");
                    cs.getGlobalCreditStage().setAvailableCreditsGrant(
                            cs.getGlobalCreditStage().getAvailableCreditsGrant().add(
                                    rcs.getAvailableCreditsConsumable()));
                    cs.getGlobalCreditStage().setAvailableCreditsConsumable(
                            cs.getGlobalCreditStage().getAvailableCreditsConsumable().subtract(
                                    rcs.getAvailableCreditsConsumable()).max(BigDecimal.ZERO));
                }
            }
        });

        // Update initial amounts available in each balance
        nextCycleStage.updateConsumableCreditsMoreThanChargeCondition(loggingKey);

        // Get redeem order here.
        nextCycleStage.updateCredits(loggingKey);

        // Update PayNow amounts
        nextCycleStage.updatePayableAmounts(loggingKey);
    }

    private void intializeNextCycleChangeAdviceDataStage(String loggingKey,
                                                         MtxResponseSubscription subscription,
                                                         AdviceDataStage deltaStage,
                                                         AdviceDataStage nextStage)
            throws PaymentAdviceException, IllegalAccessException, InvocationTargetException,
            NoSuchMethodException, IntrospectionException {
        final String methodName = "intializeNextCycleChangeAdviceDataStage:";
        INFO(
                m_logger, loggingKey + methodName + StringUtils.SPACE
                        + " Initialize calculations for next cycle.:");
        nextStage.setPaidCycleStartDate(deltaStage.getPaidCycleStartDate());
        nextStage.setAvailableMainBalanceAmount(
                deltaStage.getAvailableMainBalanceAmount().subtract(
                        deltaStage.getConsumableMainBalanceAmount()));
        nextStage.getChangeServiceDataStage().setReservedMainBalanceNextCycle(
                deltaStage.getChangeServiceDataStage().getReservedMainBalanceNextCycle());
        nextStage.getChangeServiceDataStage().setAsisCatalogItem(
                deltaStage.getChangeServiceDataStage().getAsisCatalogItem());
        nextStage.getChangeServiceDataStage().setNewCatalogItemExternalId(
                deltaStage.getChangeServiceDataStage().getNewCatalogItemExternalId());
        nextStage.getChangeServiceDataStage().setBillCycle(BillCycle.NEXT);
        nextStage.getChangeServiceDataStage().setDelta(
                deltaStage.getChangeServiceDataStage().getDelta());
        nextStage.getChangeServiceDataStage().setGapImpactPromos(
                deltaStage.getChangeServiceDataStage().getGapImpactPromos());
        nextStage.getChangeServiceDataStage().getReverseCreditMap().putAll(
                deltaStage.getChangeServiceDataStage().getReverseCreditMap());
        nextStage.getChangeServiceDataStage().setChangeType(
                deltaStage.getChangeServiceDataStage().getChangeType());
        nextStage.setCycleStartTime(deltaStage.getCycleEndTime());

        deltaStage.getSubscriberGroupList().forEach(sg -> {
            nextStage.appendSubscriberGroupList(sg);
        });

        nextStage.setPayerExternalId(deltaStage.getPayerExternalId());
        nextStage.setPayerGeoCode(deltaStage.getPayerGeoCode());

        for (Entry<CiResourceIdPair, ServiceStage> paynowEntry : deltaStage.getPayNowMap().entrySet()) {
            CiResourceIdPair key = new CiResourceIdPair(
                    paynowEntry.getKey().getCatalogItemExternalId());
            ServiceStage paynowClone = paynowEntry.getValue().shallowClone();
            paynowClone.setCreditsUsed(BigDecimal.ZERO);
            paynowClone.setFinalPayableAmount(paynowClone.getDiscountPrice());
            paynowClone.setNonCreditAmount(paynowClone.getDiscountPrice());
            paynowClone.setProratedDiscountPrice(paynowClone.getDiscountPrice());
            paynowClone.setTaxFeeAmount(BigDecimal.ZERO);
            paynowClone.setConsumableMainBalance(BigDecimal.ZERO);
            nextStage.getPayNowMap().put(key, paynowClone);
            break;// Assumption only one offer in changeservice
        }

        for (Entry<PromoOfferPair, CreditStage> enRouteToGcs : deltaStage.getCreditMap().entrySet()) {
            PromoOfferPair key = enRouteToGcs.getKey();
            String promo = key.getPromoCiExternalId();
            CreditStage value = enRouteToGcs.getValue();

            GlobalCreditStage gcs = value.getGlobalCreditStage().shallowClone();
            gcs.setAvailableCredits(
                    value.getGlobalCreditStage().getAvailableCredits().subtract(
                            value.getGlobalCreditStage().getGlobalRedeemables()));
            gcs.setAvailableCreditsGrant(
                    value.getGlobalCreditStage().getAvailableCreditsGrant().subtract(
                            value.getGlobalCreditStage().getGlobalGrantsReserved()));
            gcs.setAvailableCreditsConsumable(
                    value.getGlobalCreditStage().getAvailableCreditsConsumable().subtract(
                            value.getGlobalCreditStage().getGlobalConsumablesReserved()));
            gcs.setCreditCap(gcs.getCreditCapOrig());
            gcs.setNoCap(gcs.isNoCapOrig());
            for (Entry<PromoOfferPair, CreditStage> promoEntry : deltaStage.getCreditMap().entrySet()) {
                String promo1 = promoEntry.getKey().getPromoCiExternalId();
                if (promo.equalsIgnoreCase(promo1)) {
                    CreditStage csClone = promoEntry.getValue().shallowClone(gcs);
                    csClone.setCreditTaxApiErrorMessage(StringUtils.EMPTY);
                    csClone.setCreditTaxDetails(StringUtils.EMPTY);
                    csClone.setEstimatedTransferableCreditsToZero();
                    csClone.setPercentageGrantToZero();
                    csClone.setAocGrantToZero();
                    csClone.setRedeemableConsumablesToZero();
                    csClone.setRedeemableCreditsToZero();
                    gcs.addOrReplaceCreditStage(csClone);

                    AdviceUtils.updateCreditStageWithPaynowStage(loggingKey, nextStage, csClone);
                    if (csClone.getApplicableServiceStage() == null) {
                        // if a paynowstage is not linked to a promo that means applicable offer is
                        // not
                        // part of advice. So ignore credit
                        continue;
                    }
                    AdviceUtils.updateFlagBalanceConditions(
                            loggingKey, nextStage, subscription, csClone);
                    AdviceUtils.applyCreditIncludeAttributeRules(loggingKey, subscription, csClone);
                    nextStage.getCreditMap().put(promoEntry.getKey(), csClone);
                }
            }
        }

        for (String offer : deltaStage.getOneTimeOfferList()) {
            nextStage.getOneTimeOfferList().add(offer);
        }
    }

    private void updateDelta(String loggingKey,
                             String route,
                             VisibleRequestChangeServiceAdvice request,
                             MtxResponseSubscription subscription,
                             AdviceDataStage changeCycleStage)
            throws Exception {
        final String methodName = "updateDelta:";

        List<String> deltaFreeCodes = AppPropertyParser.getStringList(
                CHANGE_SERVICE_CONSTANTS.DELTA_FREE_CLASS_CODE_UPPER_CASE_LIST);

        Map<String, BigDecimal> eventPromoMap = new HashMap<String, BigDecimal>();
        for (String taxString : changeCycleStage.getChangeServiceDataStage().getEventPromoTaxes()) {
            if (StringUtils.isNotBlank(taxString)
                    && CommonUtils.isServiceTaxResponseValid(taxString)) {
                ServiceTaxResponse promoTax = CommonUtils.getServiceTaxResponseFromJsonString(
                        taxString);
                eventPromoMap.put(
                        promoTax.getClassCode().toUpperCase().trim(), promoTax.getDiscountPrice());
                INFO(
                        m_logger,
                        loggingKey + methodName + StringUtils.SPACE
                                + "Event has PromoTax with class code: "
                                + promoTax.getClassCode().toUpperCase().trim());
            }
        }

        Map<String, Object> subDeltaDetails = getDeltaDetailsForSubscriptionBasedPromos(
                loggingKey, route, request, subscription, changeCycleStage, eventPromoMap,
                deltaFreeCodes);
        Map<String, Object> aocDeltaDetails = getDeltaDetailsForAocBasedPromos(
                loggingKey, route, request, subscription, changeCycleStage, eventPromoMap,
                deltaFreeCodes);

        StringJoiner subOldPromoClassCodes = (StringJoiner) subDeltaDetails.get(
                ASIS_PROMO_CLASS_CODES);
        StringJoiner aocOldPromoClassCodes = (StringJoiner) aocDeltaDetails.get(
                ASIS_PROMO_CLASS_CODES);
        StringJoiner oldPromoCodeJoiner = subOldPromoClassCodes.merge(aocOldPromoClassCodes);

        StringJoiner subNewPromoClassCodes = (StringJoiner) subDeltaDetails.get(
                TOBE_PROMO_CLASS_CODES);
        StringJoiner aocNewPromoClassCodes = (StringJoiner) aocDeltaDetails.get(
                TOBE_PROMO_CLASS_CODES);
        StringJoiner newPromoCodeJoiner = subNewPromoClassCodes.merge(aocNewPromoClassCodes);

        BigDecimal deltaImpactOldPromos = ((BigDecimal) subDeltaDetails.get(
                DELTA_IMPACT_ASIS_PROMOS)).add(
                        (BigDecimal) aocDeltaDetails.get(DELTA_IMPACT_ASIS_PROMOS));
        BigDecimal deltaImpactNewPromos = ((BigDecimal) subDeltaDetails.get(
                DELTA_IMPACT_TOBE_PROMOS)).add(
                        (BigDecimal) aocDeltaDetails.get(DELTA_IMPACT_TOBE_PROMOS));

        INFO(
                m_logger,
                loggingKey + methodName + StringUtils.SPACE
                        + "Total promos impacting delta calculation as per old offer: "
                        + deltaImpactOldPromos);

        changeCycleStage.getChangeServiceDataStage().setDeltaImpactNewOfferPromos(
                deltaImpactNewPromos);
        INFO(
                m_logger,
                loggingKey + methodName + StringUtils.SPACE
                        + "Total promos impacting delta calculation as per  new offer: "
                        + deltaImpactNewPromos);
        if (changeCycleStage.getChangeServiceDataStage().getAsisCatalogItem().getEndDate() != null
                && changeCycleStage.getChangeServiceDataStage().getAsisCatalogItem().getEndDate().getTimestamp().getTime() > System.currentTimeMillis()) {
            // To-Be offer starts next bill cycle. As-Is offer ends end of bill cycle. No payments
            // needed in Change Cycle.
            changeCycleStage.getChangeServiceDataStage().setDelta(BigDecimal.ZERO);
            INFO(
                    m_logger, loggingKey + methodName + StringUtils.SPACE
                            + "Current offer ends after current bill cycle. Delta is defaulted to Zero.");
        } else {
            BigDecimal delta = request.getDiscountPrice().subtract(
                    changeCycleStage.getChangeServiceDataStage().getAsisCatalogItem().getDiscountPrice()).add(
                            deltaImpactOldPromos);

            delta = delta.subtract(
                    changeCycleStage.getChangeServiceDataStage().getDeltaImpactNewOfferPromos());

            changeCycleStage.getChangeServiceDataStage().setDelta(BigDecimal.ZERO.max(delta));

            String newPromoClassCodes = "";
            if (newPromoCodeJoiner != null && newPromoCodeJoiner.length() > 0) {
                Set<String> newSet = new HashSet<String>();
                newSet.addAll(Arrays.asList(newPromoCodeJoiner.toString().split(",")));
                newPromoClassCodes = " - " + String.join(",", newSet) + " for New Offer";
            }

            String oldPromoClassCodes = "";
            if (oldPromoCodeJoiner != null && oldPromoCodeJoiner.length() > 0) {
                Set<String> oldSet = new HashSet<String>();
                oldSet.addAll(Arrays.asList(oldPromoCodeJoiner.toString().split(",")));
                oldPromoClassCodes = " - " + String.join(",", oldSet) + " for Old Offer";
            }

            INFO(
                    m_logger,
                    loggingKey + methodName + StringUtils.SPACE
                            + "Delta for current cycle before applying new promos = (New Price"
                            + newPromoClassCodes + ") - (Old Price" + oldPromoClassCodes + ") = "
                            + "(" + request.getDiscountPrice() + " - "
                            + changeCycleStage.getChangeServiceDataStage().getDeltaImpactNewOfferPromos()
                            + ")" + " - ("
                            + changeCycleStage.getChangeServiceDataStage().getAsisCatalogItem().getDiscountPrice()
                            + " - " + deltaImpactOldPromos + ")" + " = "
                            + changeCycleStage.getChangeServiceDataStage().getDelta());
        }

    }

    private Map<String, Object> getDeltaDetailsForSubscriptionBasedPromos(String loggingKey,
                                                                          String route,
                                                                          VisibleRequestChangeServiceAdvice request,
                                                                          MtxResponseSubscription subscription,
                                                                          AdviceDataStage changeCycleStage,
                                                                          Map<String, BigDecimal> eventPromoMap,
                                                                          List<String> deltaFreeCodes)
            throws Exception {
        final String methodKey = loggingKey + " getDeltaDetailsForSubscriptionBasedPromos: ";
        Map<String, Object> retMap = new HashMap<String, Object>();
        StringJoiner toBeSet = new StringJoiner(",");
        StringJoiner asIsSet = new StringJoiner(",");
        retMap.put(TOBE_PROMO_CLASS_CODES, toBeSet);
        retMap.put(ASIS_PROMO_CLASS_CODES, asIsSet);
        retMap.put(DELTA_IMPACT_TOBE_PROMOS, BigDecimal.ZERO);
        retMap.put(DELTA_IMPACT_ASIS_PROMOS, BigDecimal.ZERO);

        List<MtxPurchasedOfferInfo> purchasedOffers = new ArrayList<MtxPurchasedOfferInfo>();
        subscription.getPurchasedOfferArray().forEach(mpoi -> {
            if (mpoi.getCatalogItemExternalId() != null && mpoi.getAttr() != null
                    && mpoi.getAttr() instanceof VisiblePurchasedOfferExtension) {
                if (OFFER_CONSTANTS.OFFER_STATUS_ACTIVE.equalsIgnoreCase(
                        mpoi.getOfferStatusDescription())
                        || OFFER_CONSTANTS.OFFER_STATUS_PRE_ACTIVE.equalsIgnoreCase(
                                mpoi.getOfferStatusDescription())) {
                    VisiblePurchasedOfferExtension attr = (VisiblePurchasedOfferExtension) mpoi.getAttr();
                    // Make a list of all offers that can use promotions
                    purchasedOffers.add(mpoi);
                }
            }
        });

        List<String> toBeList = new ArrayList<String>();
        for (MtxPurchasedOfferInfo offer : purchasedOffers) {
            MtxResponsePricingCatalogItem mtxResponsePricingCatalogItem = queryPricingCatalogItem(
                    loggingKey, route, offer.getCatalogItemExternalId());
            if (!(mtxResponsePricingCatalogItem.getCatalogItemInfo().getTemplateAttr() instanceof VisibleTemplate)) {
                continue;
            }

            VisibleTemplate vt = (VisibleTemplate) mtxResponsePricingCatalogItem.getCatalogItemInfo().getTemplateAttr();
            if (vt == null || StringUtils.isBlank(vt.getOfferType())
                    || !OFFER_CONSTANTS.OFFER_TYPE_PROMO.equalsIgnoreCase(vt.getOfferType())) {
                continue;
            }
            VisiblePurchasedOfferExtension attr = (VisiblePurchasedOfferExtension) offer.getAttr();

            String oldClassCodeUpper = "";
            if (StringUtils.isNotBlank(attr.getClassCode())) {
                // Check if classcode is overridden
                oldClassCodeUpper = attr.getClassCode().toUpperCase();
            } else if (StringUtils.isBlank(vt.getClassCode())) {
                INFO(
                        m_logger,
                        methodKey
                                + "No ClassCode passed. No ClassCode at catalog item attribute. So ignoring promo: "
                                + mtxResponsePricingCatalogItem.getCatalogItemInfo().getExternalId());
                continue;
            } else {
                oldClassCodeUpper = vt.getClassCode().toUpperCase();
            }

            String oldApplicableOffer = "";
            if (StringUtils.isNotBlank(attr.getApplicableOfferName())) {
                // Check if classcode is overridden
                oldApplicableOffer = attr.getApplicableOfferName();
            } else if (StringUtils.isBlank(vt.getApplicableOfferName())) {
                INFO(
                        m_logger,
                        methodKey
                                + "No ApplicableOffer passed. No ApplicableOffer at catalog item attribute. So ignoring promo: "
                                + mtxResponsePricingCatalogItem.getCatalogItemInfo().getExternalId());
                continue;
            } else {
                oldApplicableOffer = vt.getApplicableOfferName();
            }

            if (StringUtils.isNotBlank(oldClassCodeUpper)
                    && !deltaFreeCodes.contains(oldClassCodeUpper)
                    && StringUtils.isNotBlank(oldApplicableOffer) && oldApplicableOffer.contains(
                            changeCycleStage.getChangeServiceDataStage().getAsisCatalogItem().getCatalogItemExternalId())) {
                if (eventPromoMap.get(oldClassCodeUpper) != null
                        && eventPromoMap.get(oldClassCodeUpper).signum() > 0) {
                    retMap.put(
                            DELTA_IMPACT_ASIS_PROMOS,
                            ((BigDecimal) retMap.get(DELTA_IMPACT_ASIS_PROMOS)).add(
                                    eventPromoMap.get(oldClassCodeUpper)));
                } else {
                    if (attr.getPromotionLimit() != null
                            && attr.getPromotionLimit().signum() >= 0) {
                        retMap.put(
                                DELTA_IMPACT_ASIS_PROMOS,
                                ((BigDecimal) retMap.get(DELTA_IMPACT_ASIS_PROMOS)).add(
                                        attr.getPromotionLimit()));
                    } else {
                        retMap.put(
                                DELTA_IMPACT_ASIS_PROMOS,
                                ((BigDecimal) retMap.get(DELTA_IMPACT_ASIS_PROMOS)).add(
                                        vt.getPromotionLimit()));
                    }
                }
                asIsSet.add(oldClassCodeUpper);
            }

            if (StringUtils.isBlank(vt.getApplicableOfferName())
                    || !vt.getApplicableOfferName().contains(
                            request.getNewCatalogItemExternalId())) {
                continue;
            }

            String newClassCodeUpper = oldClassCodeUpper; // Default to current value
            String newApplicableOffer = oldApplicableOffer;// Default to current value
            VisibleChangeServicePromo newPromo = null;
            VisiblePromoExtension pExt = null;
            if (request.getNewPromotionList() != null) {
                for (VisibleChangeServicePromo csp : request.getNewPromotionList()) {
                    if (offer.getCatalogItemExternalId().equalsIgnoreCase(csp.getGrantOfferCI())) {
                        newApplicableOffer = request.getNewCatalogItemExternalId();
                        newPromo = csp;
                        pExt = newPromo.getAttr();
                        break;
                    }
                }
            }

            if (StringUtils.isBlank(newApplicableOffer)
                    || !newApplicableOffer.contains(request.getNewCatalogItemExternalId())) {
                // This means promo is not in Request. And promo is not applicable to new service
                // either by purchased attribute or by template attribute.
                continue;
            }

            if (newPromo != null && pExt != null && StringUtils.isNotBlank(pExt.getClassCode())) {
                newClassCodeUpper = pExt.getClassCode().toUpperCase();
            }

            if (StringUtils.isNotBlank(newClassCodeUpper)
                    && !deltaFreeCodes.contains(newClassCodeUpper)) {
                if (newPromo != null && pExt != null && pExt.getPromotionLimit() != null
                        && pExt.getPromotionLimit().signum() >= 0) {
                    retMap.put(
                            DELTA_IMPACT_TOBE_PROMOS,
                            ((BigDecimal) retMap.get(DELTA_IMPACT_TOBE_PROMOS)).add(
                                    pExt.getPromotionLimit()));
                } else if (attr.getPromotionLimit() != null
                        && attr.getPromotionLimit().signum() >= 0) {
                    retMap.put(
                            DELTA_IMPACT_TOBE_PROMOS,
                            ((BigDecimal) retMap.get(DELTA_IMPACT_TOBE_PROMOS)).add(
                                    attr.getPromotionLimit()));
                } else {
                    retMap.put(
                            DELTA_IMPACT_TOBE_PROMOS,
                            ((BigDecimal) retMap.get(DELTA_IMPACT_TOBE_PROMOS)).add(
                                    vt.getPromotionLimit()));
                }

                // We should find better place to create this. When next cycle payment is not made
                // credit stage for new promo does not get created.
                // This place is a quick and dirty shortcut.
                VisibleChangeServiceCredit csc = new VisibleChangeServiceCredit();
                csc.setGrantOfferCI(offer.getCatalogItemExternalId());
                csc.setResourceId(offer.getResourceId());
                csc.setClassCode(newClassCodeUpper);

                if (newPromo != null
                        && CommonUtils.zeroIfNull(newPromo.getGrantAmount()).signum() > 0
                        && !GENERIC_CONSTANTS.NO.equalsIgnoreCase(
                                CommonUtils.blankIfNull(newPromo.getResetExistingPromo()).trim())) {
                    csc.setGrantAmount(newPromo.getGrantAmount());
                }

                if (StringUtils.isNotBlank(attr.getApplicableOfferName())) {
                    StringJoiner sj = new StringJoiner(",");
                    sj.add(request.getNewCatalogItemExternalId());
                    String[] acis = attr.getApplicableOfferName().split(",");
                    for (String aci : acis) {
                        if (request.getNewCatalogItemExternalId().equalsIgnoreCase(aci.trim())) {
                            continue;
                        }
                        if (changeCycleStage.getChangeServiceDataStage().getAsisCatalogItem().getCatalogItemExternalId().equalsIgnoreCase(
                                aci.trim())) {
                            continue;
                        }
                        sj.add(aci);
                    }
                    attr.setApplicableOfferName(sj.toString());
                }

                if (newPromo != null && pExt != null
                        && StringUtils.isNotBlank(pExt.getPromotionName())) {
                    csc.setPromotionName(pExt.getPromotionName());
                } else if (StringUtils.isNotBlank(attr.getPromotionName())) {
                    csc.setPromotionName(attr.getPromotionName());
                } else {
                    csc.setPromotionName(vt.getPromotionName());
                }

                if (newPromo != null && pExt != null && pExt.getPromotionLimit() != null
                        && pExt.getPromotionLimit().signum() > 0) {
                    csc.setPromotionLimit(pExt.getPromotionLimit());
                } else if (attr.getPromotionLimit() != null
                        && attr.getPromotionLimit().signum() > 0) {
                    csc.setPromotionLimit(attr.getPromotionLimit());
                } else {
                    csc.setPromotionLimit(vt.getPromotionLimit());
                }

                changeCycleStage.getChangeServiceDataStage().getChangeServiceCredits().add(csc);
                String ignoreMessage = LOG_MESSAGES.FUTURE_GRANT_AMOUNT_IGNORED_1001
                        + csc.getClassCode();
                INFO(m_logger, methodKey + ignoreMessage);
                changeCycleStage.getChangeServiceDataStage().setIgnoreFuturePromoReason(
                        ignoreMessage);
                toBeSet.add(vt.getClassCode().toUpperCase());
                toBeList.add(vt.getClassCode().toUpperCase());
            }
        }

        if (request.getNewPromotionList() == null || request.getNewPromotionList().isEmpty()) {
            return retMap;
        }

        for (VisibleChangeServicePromo csp : request.getNewPromotionList()) {
            if (StringUtils.isBlank(csp.getGrantOfferCI())) {
                continue;
            }
            String classCodeUpper = "";
            if (csp.getAttr() != null && StringUtils.isNotBlank(csp.getAttr().getClassCode())) {
                classCodeUpper = csp.getAttr().getClassCode().toUpperCase();
                if (toBeList.contains(classCodeUpper.toUpperCase())) {
                    // Promotion is already a purchased one.
                    continue;
                }
            }

            MtxResponsePricingCatalogItem pci = queryPricingCatalogItem(
                    loggingKey, route, csp.getGrantOfferCI());
            if (pci == null || pci.getResult() != RESULT_CODES.MTX_SUCCESS) {
                String returnMessage = "CatalogItem details not available for promotion: "
                        + csp.getGrantOfferCI() + " : " + pci.getResultText();
                INFO(m_logger, methodKey + returnMessage);
                retMap.put(TOBE_PROMO_IGNORE_ERROR, returnMessage);
                continue;
            }

            VisibleTemplate vt = null;
            if (pci.getCatalogItemInfo() != null
                    && pci.getCatalogItemInfo().getTemplateAttr() != null
                    && pci.getCatalogItemInfo().getTemplateAttr() instanceof VisibleTemplate) {
                vt = (VisibleTemplate) pci.getCatalogItemInfo().getTemplateAttr();
                if (StringUtils.isBlank(classCodeUpper)) {
                    classCodeUpper = vt.getClassCode().toUpperCase();
                }
            } else {
                String returnMessage = "CatalogItem Visible Template Attributes not available for promotion "
                        + csp.getGrantOfferCI();
                INFO(m_logger, methodKey + returnMessage);
                retMap.put(TOBE_PROMO_IGNORE_ERROR, returnMessage);
                continue;
            }

            if (StringUtils.isNotBlank(vt.getOfferType())
                    && !OFFER_CONSTANTS.OFFER_TYPE_PROMO.equalsIgnoreCase(vt.getOfferType())) {
                String returnMessage = "CatalogItem is not a promotion: " + csp.getGrantOfferCI();
                INFO(m_logger, methodKey + returnMessage);
                retMap.put(TOBE_PROMO_IGNORE_ERROR, returnMessage);
                continue;
            }

            if (!vt.getApplicableOfferName().contains(request.getNewCatalogItemExternalId())) {
                // Check if this promo is not applicable to new service.
                String ignoreMessage = LOG_MESSAGES.FUTURE_GRANT_NOT_APPLICABLE_1002
                        + classCodeUpper;
                INFO(m_logger, methodKey + ignoreMessage);
                changeCycleStage.getChangeServiceDataStage().setIgnoreFuturePromoReason(
                        ignoreMessage);
                continue;
            }

            if (toBeList.contains(classCodeUpper)) {
                continue;
            }

            if (deltaFreeCodes.contains(classCodeUpper)) {
                continue;
            }

            VisibleChangeServiceCredit csc = new VisibleChangeServiceCredit();
            csc.setGrantOfferCI(csp.getGrantOfferCI());
            csc.setApplicableCI(request.getNewCatalogItemExternalId());
            csc.setClassCode(classCodeUpper);
            if (csp.getAttr() != null && csp.getAttr().getPromotionLimit() != null
                    && csp.getAttr().getPromotionLimit().signum() >= 0) {
                retMap.put(
                        DELTA_IMPACT_TOBE_PROMOS,
                        ((BigDecimal) retMap.get(DELTA_IMPACT_TOBE_PROMOS)).add(
                                csp.getAttr().getPromotionLimit()));
            } else {
                retMap.put(
                        DELTA_IMPACT_TOBE_PROMOS,
                        ((BigDecimal) retMap.get(DELTA_IMPACT_TOBE_PROMOS)).add(
                                vt.getPromotionLimit()));
            }

            if (csp.getAttr() != null && StringUtils.isNotBlank(csp.getAttr().getPromotionName())) {
                csc.setPromotionName(csp.getAttr().getPromotionName());
            } else {
                csc.setPromotionName(vt.getPromotionName());
            }

            if (csp.getAttr() != null && csp.getAttr().getPromotionLimit() != null
                    && csp.getAttr().getPromotionLimit().signum() > 0) {
                csc.setPromotionLimit(csp.getAttr().getPromotionLimit());
            } else {
                csc.setPromotionLimit(vt.getPromotionLimit());
            }

            if (csp.getGrantAmount() != null && csp.getGrantAmount().signum() > 0) {
                csc.setGrantAmount(csp.getGrantAmount());
            } else {
                csc.setGrantAmount(BigDecimal.ZERO);
            }
            changeCycleStage.getChangeServiceDataStage().getChangeServiceCredits().add(csc);
            toBeSet.add(classCodeUpper);
            toBeList.add(classCodeUpper);
        }
        return retMap;
    }

    private Map<String, Object> getDeltaDetailsForAocBasedPromos(String loggingKey,
                                                                 String route,
                                                                 VisibleRequestChangeServiceAdvice request,
                                                                 MtxResponseSubscription subscription,
                                                                 AdviceDataStage changeCycleStage,
                                                                 Map<String, BigDecimal> eventPromoMap,
                                                                 List<String> deltaFreeCodes)
            throws Exception {
        final String methodName = "getDeltaDetailsForAocBasedPromos:";

        Map<String, Object> retMap = new HashMap<String, Object>();
        StringJoiner toBeSet = new StringJoiner(",");
        StringJoiner asIsSet = new StringJoiner(",");
        retMap.put(TOBE_PROMO_CLASS_CODES, toBeSet);
        retMap.put(ASIS_PROMO_CLASS_CODES, asIsSet);
        retMap.put(DELTA_IMPACT_TOBE_PROMOS, BigDecimal.ZERO);
        retMap.put(DELTA_IMPACT_ASIS_PROMOS, BigDecimal.ZERO);

        updateAocCredits(loggingKey, route, subscription, changeCycleStage);

        for (Entry<PromoOfferPair, CreditStage> entry : changeCycleStage.getCreditMap().entrySet()) {
            CreditStage cs = entry.getValue();
            String classCodeUpper = cs.getClassCode().toUpperCase().trim();

            if (changeCycleStage.getChangeServiceDataStage().getAsisCatalogItem().getCatalogItemExternalId().equalsIgnoreCase(
                    cs.getApplicableCiExternalId())) {
                INFO(
                        m_logger, loggingKey + methodName + StringUtils.SPACE
                                + "Get old offer delta impact for: " + classCodeUpper);
                if (!deltaFreeCodes.contains(classCodeUpper)
                        && eventPromoMap.get(classCodeUpper) != null) {
                    retMap.put(
                            DELTA_IMPACT_ASIS_PROMOS,
                            ((BigDecimal) retMap.get(DELTA_IMPACT_ASIS_PROMOS)).add(
                                    eventPromoMap.get(classCodeUpper)));
                    INFO(
                            m_logger,
                            loggingKey + methodName + StringUtils.SPACE
                                    + eventPromoMap.get(classCodeUpper) + StringUtils.SPACE
                                    + "will be added to old offer delta impact." + StringUtils.SPACE
                                    + "Credit tax is present in recurring event for "
                                    + StringUtils.SPACE + classCodeUpper);
                    asIsSet.add(classCodeUpper);
                } else if (!deltaFreeCodes.contains(classCodeUpper)
                        && eventPromoMap.get(classCodeUpper) == null) {
                    if (CREDIT_CONSTANTS.CALCULATION_METHOD_AOC.equalsIgnoreCase(
                            cs.getDiscountCalculationMethod())) {
                        if (cs.getAocGrant().signum() > 0) {
                            retMap.put(
                                    DELTA_IMPACT_ASIS_PROMOS,
                                    ((BigDecimal) retMap.get(DELTA_IMPACT_ASIS_PROMOS)).add(
                                            cs.getAocGrant()));
                            INFO(
                                    m_logger,
                                    loggingKey + methodName + StringUtils.SPACE + cs.getAocGrant()
                                            + StringUtils.SPACE
                                            + "will be added to old offer delta impact. Amount added from Aoc grant."
                                            + StringUtils.SPACE
                                            + "Credit tax is NOT present in recurring event for "
                                            + StringUtils.SPACE + classCodeUpper);
                            asIsSet.add(classCodeUpper);
                        } else if (cs.getAvailableCreditsConsumable().signum() > 0) {
                            // MTXVER2-139 - In case VBPP if there is an existing balance Aoc
                            // returns zero. This will be issue if payment is already done.
                            // Work around suggested is to get details from Consumable balance.
                            retMap.put(
                                    DELTA_IMPACT_ASIS_PROMOS,
                                    ((BigDecimal) retMap.get(DELTA_IMPACT_ASIS_PROMOS)).add(
                                            cs.getAvailableCreditsConsumable()));
                            INFO(
                                    m_logger,
                                    loggingKey + methodName + StringUtils.SPACE
                                            + cs.getAvailableCreditsConsumable() + StringUtils.SPACE
                                            + "will be added to old offer delta impact. Aoc grants are Zero. Amount added from consumables."
                                            + StringUtils.SPACE
                                            + "Credit tax is NOT present in recurring event for "
                                            + StringUtils.SPACE + classCodeUpper);
                            asIsSet.add(classCodeUpper);
                        }
                    }
                }
            } else if (!deltaFreeCodes.contains(classCodeUpper)
                    && request.getNewCatalogItemExternalId().equalsIgnoreCase(
                            cs.getApplicableCiExternalId())) {
                if (CREDIT_CONSTANTS.CALCULATION_METHOD_AOC.equalsIgnoreCase(
                        cs.getDiscountCalculationMethod())) {
                    retMap.put(
                            DELTA_IMPACT_TOBE_PROMOS,
                            ((BigDecimal) retMap.get(DELTA_IMPACT_TOBE_PROMOS)).add(
                                    cs.getAocGrant()));
                    INFO(
                            m_logger,
                            loggingKey + methodName + StringUtils.SPACE + cs.getAocGrant()
                                    + StringUtils.SPACE
                                    + "will be added to new offer delta impact based on aoc.");
                }
                toBeSet.add(classCodeUpper);
            }
        }

        INFO(
                m_logger, loggingKey + methodName + StringUtils.SPACE
                        + "Credit map  will be cleared for current cycle.");
        changeCycleStage.getCreditMap().clear();
        return retMap;
    }

    private void updateFromPaymentAdvice(String loggingKey,
                                         String route,
                                         SubscriptionResponse subscriptionResponse,
                                         MtxResponseSubscription subscription,
                                         AdviceDataStage deltaStage,
                                         VisibleRequestChangeServiceAdvice request)
            throws Exception {
        final String methodKey = loggingKey + " updateFromPaymentAdvice: ";
        INFO(
                m_logger, methodKey
                        + "Calling Payment Advice to get Distribution of Promotions and Mainbalance.");
        VisibleRequestPaymentAdviceService aopInput = new VisibleRequestPaymentAdviceService();
        aopInput.setSubscriberExternalId(request.getSubscriptionExternalId());
        aopInput.setIncludeTaxDetails(GENERIC_CONSTANTS.NO);
        AdviceDataStage aopStage = getAOPStage(
                loggingKey, route, aopInput, subscriptionResponse, subscription);

        String oldCiId = deltaStage.getChangeServiceDataStage().getAsisCatalogItem().getCatalogItemExternalId();
        requestValidator.validateRequestCompareAopResponse(loggingKey, request, aopStage);

        if (aopStage.getSubscriberGroupList() != null
                && !aopStage.getSubscriberGroupList().isEmpty()) {
            for (SubscriberGroup grp : aopStage.getSubscriberGroupList()) {
                deltaStage.appendSubscriberGroupList(grp);
            }
        }

        // update group details
        updatePayerDetails(loggingKey, deltaStage);

        if (aopStage.getCreditMap() != null && aopStage.getCreditMap().values() != null
                && !aopStage.getCreditMap().values().isEmpty()) {
            INFO(m_logger, methodKey + "Evaluate for potential nonredeemable promotions.");
            for (CreditStage cs : aopStage.getCreditMap().values()) {
                if (aopStage.getVisibleOfferDetailsMap() != null
                        && aopStage.getVisibleOfferDetailsMap().values() != null
                        && !aopStage.getVisibleOfferDetailsMap().values().isEmpty()) {

                    boolean usedByOtherOffer = false;
                    for (VisibleOfferDetails vod : aopStage.getVisibleOfferDetailsMap().values()) {
                        if (vod.getCatalogItemExternalId().equalsIgnoreCase(oldCiId)) {
                            continue;
                        }

                        if (cs.getGlobalCreditStage().getApplicableCiCsv().contains(
                                vod.getCatalogItemExternalId())) {
                            usedByOtherOffer = true;
                            break;
                        }
                    }

                    boolean usedByNewOffer = false;
                    for (VisibleOfferDetails vod : aopStage.getVisibleOfferDetailsMap().values()) {
                        if (cs.getGlobalCreditStage().getApplicableCiCsv().contains(
                                request.getNewCatalogItemExternalId())) {
                            usedByNewOffer = true;
                            break;
                        }
                    }

                    VisibleNonRedeemableCredit nrc = new VisibleNonRedeemableCredit();
                    nrc.setApplicableCI(oldCiId);
                    nrc.setClassCode(cs.getClassCode());
                    nrc.setPromotionName(cs.getPromotionName());
                    nrc.setCreditGrant(cs.getGlobalCreditStage().getAvailableCreditsGrant());
                    nrc.setGrantOfferCI(cs.getGrantOfferCi());
                    if (!usedByOtherOffer && !usedByNewOffer) {
                        INFO(
                                m_logger,
                                methodKey + FREEZE_GRANT_REASONS.APPLICABLE_OFFERS_CHANGE_SERVICE);
                        nrc.setReason(FREEZE_GRANT_REASONS.APPLICABLE_OFFERS_CHANGE_SERVICE);
                        PromoOfferPair promoKey = new PromoOfferPair(oldCiId, cs.getGrantOfferCi());
                        INFO(
                                m_logger,
                                methodKey + "Adding nonredeemable promotions for: " + promoKey);
                        deltaStage.getChangeServiceDataStage().getNonRedeemableCreditMap().put(
                                promoKey, nrc);
                        continue;
                    }

                    VisiblePurchasedOfferExtension extn = new VisiblePurchasedOfferExtension();
                    extn.setOfferChangeType(deltaStage.getChangeServiceDataStage().getChangeType());
                    String freezeReason = AdviceUtils.getFreezeGrantReasons(
                            loggingKey, subscriptionResponse, cs, extn, null);
                    if (!FREEZE_GRANT_REASONS.NONE.equalsIgnoreCase(freezeReason)) {
                        if (FREEZE_GRANT_REASONS.OFFER_ATTRIBUTE.equalsIgnoreCase(freezeReason)) {
                            INFO(m_logger, methodKey + FREEZE_GRANT_REASONS.OFFER_ATTRIBUTE_TO_BE);
                            nrc.setReason(FREEZE_GRANT_REASONS.OFFER_ATTRIBUTE_TO_BE);
                        } else {
                            INFO(m_logger, methodKey + freezeReason);
                            nrc.setReason(freezeReason);
                        }
                        PromoOfferPair promoKey = new PromoOfferPair(oldCiId, cs.getGrantOfferCi());
                        INFO(
                                m_logger,
                                methodKey + "Adding nonredeemable promotions for: " + promoKey);
                        deltaStage.getChangeServiceDataStage().getNonRedeemableCreditMap().put(
                                promoKey, nrc);
                        continue;
                    }
                }
            }
        }

        BigDecimal reservedMainBalance = BigDecimal.ZERO;
        for (VisibleOfferDetails vod : aopStage.getVisibleOfferDetailsMap().values()) {
            if (!vod.getCatalogItemExternalId().equalsIgnoreCase(oldCiId)
                    && vod.getPaidCycleStartDate() != null
                    && (CommonUtils.compareMtxDates(
                            vod.getPaidCycleStartDate(),
                            new MtxDate(vod.getCycleStartTime().split("T")[0])) >= 0)) {
                reservedMainBalance = reservedMainBalance.add(vod.getConsumableMainBalanceAmount());
                INFO(
                        m_logger,
                        methodKey + vod.getConsumableMainBalanceAmount()
                                + " added to reserved main balance for "
                                + vod.getCatalogItemExternalId());
            }
        }
        deltaStage.getChangeServiceDataStage().setReservedMainBalanceNextCycle(reservedMainBalance);
        INFO(
                m_logger, methodKey + " Total reserved main balance for "
                        + deltaStage.getChangeServiceDataStage().getReservedMainBalanceNextCycle());

        if (aopStage.getCreditMap() != null && aopStage.getCreditMap().values() != null
                && !aopStage.getCreditMap().values().isEmpty()) {
            INFO(
                    m_logger, methodKey + "Adding Reverse Promo Blocks to undo promo allocation to "
                            + oldCiId);
            for (CreditStage vc : aopStage.getCreditMap().values()) {
                if (vc.getApplicableCiExternalId().equalsIgnoreCase(oldCiId)
                        && vc.getAvailableCreditsConsumable().signum() > 0) {
                    VisibleReverseCreditInternal rc = new VisibleReverseCreditInternal();
                    rc.setAvailableCreditsConsumable(vc.getAvailableCreditsConsumable());
                    rc.setPromotionName(vc.getPromotionName());
                    rc.setApplicableCI(vc.getApplicableCiExternalId());
                    rc.setRedeemableOfferCI(vc.getRedeemOfferCi());
                    deltaStage.getChangeServiceDataStage().getReverseCreditMap().put(
                            new PromoOfferPair(
                                    vc.getApplicableCiExternalId(), vc.getPromotionName()),
                            rc);
                    INFO(m_logger, methodKey + "Added Reverse Promo Block: " + rc.toJson());
                }
            }
        }

        deltaStage.setRecurringChargeInfo(aopStage.getRecurringChargeInfo());
    }

    @SuppressWarnings("unchecked")
    private void updateFromEnrolledOffer(String loggingKey,
                                         String route,
                                         VisibleRequestChangeServiceAdvice request,
                                         AdviceDataStage stage,
                                         SubscriptionResponse subscriptionResponse)
            throws Exception {
        final String methodKey = loggingKey + " updateFromEnrolledOffer: ";
        PurchasedOfferInfo asisPoi = getEnrolledOffer(
                loggingKey, route, request, stage, subscriptionResponse);
        stage.getChangeServiceDataStage().setAsIsPurchasedOfferInfo(asisPoi);
        requestValidator.validateRequestCompareEnrolledCi(loggingKey, request, asisPoi);

        String offerChangeType = stage.getChangeServiceDataStage().getChangeType();
        requestValidator.validateChangeRequestCycleDates(
                loggingKey, asisPoi, offerChangeType, subscriptionResponse.getTimeZone());

        ServiceStage ps = new ServiceStage(request.getNewCatalogItemExternalId());
        stage.getPayNowMap().put(new CiResourceIdPair(request.getNewCatalogItemExternalId()), ps);
        VisibleCatalogItem asisCi = new VisibleCatalogItem();
        stage.getChangeServiceDataStage().setAsisCatalogItem(asisCi);
        asisCi.setCatalogItemExternalId(asisPoi.getCatalogItemExternalId());
        asisCi.setResourceId(asisPoi.getResourceId());

        VisiblePurchasedOfferExtension asisPoExtn = (VisiblePurchasedOfferExtension) asisPoi.getAttr();
        asisCi.setDiscountPrice(asisPoExtn.getChargeAmount());

        VisiblePurchasedOfferExtension attr = request.getAttrData();

        List<String> immediateChangeTypes = AppPropertyParser.getStringList(
                CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_IMMEDIATE_START_CSV_LIST);
        List<String> realignChangeTypes = AppPropertyParser.getStringList(
                CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_REALIGN_CYCLE_LIST);

        MtxTimestamp billCycleEndDate = subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime();
        if (asisPoi.getCycleInfo() != null && asisPoi.getCycleInfo().getCycleEndTime() != null) {
            billCycleEndDate = asisPoi.getCycleInfo().getCycleEndTime();
        }
        stage.setCycleEndTime(billCycleEndDate);

        MtxTimestamp billCycleStartDate = subscriptionResponse.getBillingCycle().getCurrentPeriodStartTime();
        if (asisPoi.getCycleInfo() != null && asisPoi.getCycleInfo().getCycleStartTime() != null) {
            billCycleStartDate = asisPoi.getCycleInfo().getCycleStartTime();
        }
        stage.setCycleStartTime(billCycleStartDate);
        if (!immediateChangeTypes.contains(offerChangeType)
                && !realignChangeTypes.contains(offerChangeType)) {
            if (asisPoi.getCycleInfo() != null && asisPoi.getCycleInfo().getCycleEndTime() != null
                    && asisPoi.getCycleInfo().getCycleEndTime().longValue() < billCycleEndDate.longValue()) {
                asisCi.setEndDate(asisPoi.getCycleInfo().getCycleEndTime());
            } else {
                asisCi.setEndDate(billCycleEndDate);
            }
        }

        INFO(
                m_logger, methodKey + "ChangeType based on offer : "
                        + stage.getChangeServiceDataStage().getChangeType());

        if (StringUtils.isNotBlank(asisPoExtn.getTaxDetails())
                && CommonUtils.isServiceTaxResponseValid(asisPoExtn.getTaxDetails())) {
            ServiceTaxResponse asisTax = CommonUtils.getServiceTaxResponseFromJsonString(
                    asisPoExtn.getTaxDetails());
            if (asisTax.getGrossPrice() != null) {
                asisCi.setGrossPrice(asisTax.getGrossPrice());
            }
        }

        if (asisPoExtn.getPaidCycleStartDate() != null) {
            stage.setPaidCycleStartDate(asisPoExtn.getPaidCycleStartDate());
        } else {
            stage.defaultPaidCycleStartDate();
            INFO(
                    m_logger, methodKey + "PaidCycleStartDate not found. It is defaulted to "
                            + stage.getPaidCycleStartDate());
        }

        BigDecimal promosInSubscription = BigDecimal.ZERO;
        for (String promoTaxString : CommonUtils.emptyIfNull(
                asisPoExtn.getCreditTaxDetailsArray())) {
            if (StringUtils.isNotBlank(promoTaxString)
                    && CommonUtils.isServiceTaxResponseValid(promoTaxString)) {
                ServiceTaxResponse promoTax = CommonUtils.getServiceTaxResponseFromJsonString(
                        promoTaxString);
                INFO(
                        m_logger,
                        methodKey + "Found promos in CreditTaxDetailsArray: "
                                + promoTax.getClassCode() + StringUtils.SPACE + ":"
                                + promoTax.getDiscountPrice());
                promosInSubscription = promosInSubscription.add(promoTax.getDiscountPrice());
            }
        }
        stage.getChangeServiceDataStage().setGapImpactPromos(promosInSubscription);
        INFO(
                m_logger,
                methodKey + "Total promos for current offer as per CreditTaxDetailsArray: "
                        + stage.getChangeServiceDataStage().getGapImpactPromos());

        INFO(m_logger, methodKey + "Get recurring events from current bill cycle.");
        EventQueryResponseEvents recEvents = queryRecurringEvents(
                subscriptionResponse.getExternalId(), billCycleStartDate);
        MtxRecurringEvent recEvent = null;
        int ciIndex = -1;
        INFO(
                m_logger, methodKey
                        + "Go through recent recurring events and find event with enrolled CI to be replaced.");

        for (EventQueryEventInfo eqei : CommonUtils.emptyIfNull(recEvents.getEventList())) {
            if (!eqei.getEventDetails().getMdcName().equalsIgnoreCase(
                    MtxRecurringEvent.class.getSimpleName())) {
                continue;
            }
            recEvent = (MtxRecurringEvent) eqei.getEventDetails();
            for (MtxEventAppliedCatalogItem eaci : CommonUtils.emptyIfNull(
                    recEvent.getAppliedCatalogItemArray())) {
                if (eaci.getCatalogItemExternalId().equalsIgnoreCase(
                        asisCi.getCatalogItemExternalId())) {
                    ++ciIndex;
                    INFO(m_logger, methodKey + "Found recurring event: " + recEvent.getEventId());
                    break;
                }
            }
            if (ciIndex < 0) {
                // AppliedCatalogItemArray is not null but catalog item was still not found.
                // This means recurring event is not for required offer. So keep looking.
                continue;
            }
        }

        if (recEvent != null) {
            ArrayList<MtxEventAppliedBundle> bundleArray = null;
            ArrayList<MtxEventAppliedOffer> offerArray = null;
            if (recEvent.getAppliedBundleArray() != null
                    && !recEvent.getAppliedBundleArray().isEmpty()) {
                bundleArray = recEvent.getAppliedBundleArray();
            } else if (recEvent.getAppliedOfferArray() != null
                    & !recEvent.getAppliedOfferArray().isEmpty()) {
                offerArray = recEvent.getAppliedOfferArray();
            } else if (StringUtils.isNotBlank(recEvent.getAssociatedEventId())) {
                INFO(
                        m_logger,
                        methodKey
                                + "Recurring event found without detailed info. Reading associated event: "
                                + recEvent.getAssociatedEventId());
                // Recurring event does not have all details. Look into associated purchase event
                EventQueryResponseEvents purEvents = queryEventListByEventIds(
                        loggingKey, route, recEvent.getAssociatedEventId());
                if (purEvents.getEventList() != null && !purEvents.getEventList().isEmpty()
                        && purEvents.getAtEventList(
                                0).getEventDetails().getMdcName().equalsIgnoreCase(
                                        MtxPurchaseEvent.class.getSimpleName())) {
                    MtxPurchaseEvent purEvent = (MtxPurchaseEvent) purEvents.getAtEventList(
                            0).getEventDetails();
                    // if (purEvent.getAppliedCatalogItemArray() != null
                    // & !purEvent.getAppliedCatalogItemArray().isEmpty()) {
                    for (MtxEventAppliedCatalogItem eaci : CommonUtils.emptyIfNull(
                            purEvent.getAppliedCatalogItemArray())) {
                        if (eaci.getCatalogItemExternalId().equalsIgnoreCase(
                                asisCi.getCatalogItemExternalId())) {
                            ++ciIndex;
                            break;
                        }
                    }
                    // }
                    if (ciIndex >= 0) {
                        if (purEvent.getAppliedBundleArray() != null
                                && !purEvent.getAppliedBundleArray().isEmpty()) {
                            bundleArray = purEvent.getAppliedBundleArray();
                        } else if (purEvent.getAppliedOfferArray() != null
                                & !purEvent.getAppliedOfferArray().isEmpty()) {
                            offerArray = purEvent.getAppliedOfferArray();
                        }
                    }
                }
            }

            VisiblePurchasedOfferExtension extn = null;
            if (bundleArray != null && !bundleArray.isEmpty()) {
                for (MtxEventAppliedBundle eab : bundleArray) {
                    if (eab.getAppliedCatalogItemIndex() == ciIndex) {
                        if (eab.getPurchasedBundleAttr().getMdcName().equalsIgnoreCase(
                                VisiblePurchasedOfferExtension.class.getSimpleName())) {
                            extn = (VisiblePurchasedOfferExtension) eab.getPurchasedBundleAttr();
                        }
                    }
                }
            } else if (offerArray != null && !offerArray.isEmpty()) {
                for (MtxEventAppliedOffer eao : offerArray) {
                    if (eao.getAppliedCatalogItemIndex() == ciIndex) {
                        if (eao.getPurchasedOfferAttr().getMdcName().equalsIgnoreCase(
                                VisiblePurchasedOfferExtension.class.getSimpleName())) {
                            extn = (VisiblePurchasedOfferExtension) eao.getPurchasedOfferAttr();
                        }
                    }
                }
            }

            if (extn != null && extn.getCreditTaxDetailsArray() != null
                    && !extn.getCreditTaxDetailsArray().isEmpty()) {
                INFO(m_logger, methodKey + "Get attributes of enrolled offer: " + extn.toJson());
                BigDecimal deltaImpactPromos = BigDecimal.ZERO;
                for (String promoTaxString : extn.getCreditTaxDetailsArray()) {
                    if (StringUtils.isNotBlank(promoTaxString)) {
                        stage.getChangeServiceDataStage().addToEventPromoTaxes(promoTaxString);
                    }
                }
            }
        }

        for (BalanceInfo bal : subscriptionResponse.getWalletBalances()) {
            if (AppPropertyProvider.getInstance().getString(
                    BALANCE_CONSTANTS.BALANCE_NAME_GLOBAL_PASS).trim().equalsIgnoreCase(
                            bal.getName().trim())
                    && bal.getAmount().signum() > 0) {
                VisibleAttribute va = new VisibleAttribute();
                va.setName(CHANGE_SERVICE_CONSTANTS.ATTRIBUTE_NAME_FREE_GLOBAL_PASS);
                va.setValue(bal.getAmount().setScale(0, RoundingMode.FLOOR).toPlainString());
                asisCi.getAttributesAppender().add(va);
            }
        }

    }

    private String getOfferChangeType(String enrolledCi, String newCi)
            throws PaymentAdviceException {
        final String methodKey = "getOfferChangeType: ";
        String propName;
        propName = CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_NAME_PROP_PREFIX + enrolledCi
                + CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_NAME_PROP_OFFER_SEPARATOR_TO + newCi;
        String changeType = AppPropertyProvider.getInstance().getString(propName);
        if (StringUtils.isBlank(changeType)) {
            String resultText = "RSGateway property missing for OfferChangeType:  " + propName;
            INFO(m_logger, methodKey + resultText);
        }
        return changeType;
    }

    private PurchasedOfferInfo getEnrolledOffer(String loggingKey,
                                                String route,
                                                VisibleRequestChangeServiceAdvice request,
                                                AdviceDataStage stage,
                                                SubscriptionResponse subscriptionResponse)
            throws Exception {
        final String methodKey = loggingKey + " getEnrolledOffer: ";
        PurchasedOfferInfo retPoi = null;
        INFO(m_logger, methodKey + "Read enrolled offers to get current base offer.");
        String newCiType = OFFER_CONSTANTS.OFFER_TYPE_BASE;

        // MtxTimestamp curTimestmp = CommonUtils.getCurrentTimeInZone(
        // subscriptionResponse.getTimeZone());
        for (MtxPurchasedOfferInfo poi : subscriptionResponse.getPurchasedOfferArray()) {
            if (poi.getCatalogItemExternalId() == null || !CommonUtils.isOfferPreActive(
                    loggingKey, m_logger, poi,
                    subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime())) {
                continue;
            }

            // if (poi.getCatalogItemExternalId().equalsIgnoreCase(
            // request.getNewCatalogItemExternalId().trim())) {
            // String msg = "Subscription already has preactive offer "
            // + request.getNewCatalogItemExternalId();
            // INFO(m_logger, methodKey + msg);
            // throw new InvalidRequestException(msg);
            // }

            MtxResponsePricingCatalogItem pricingEnrolledCi = queryPricingCatalogItem(
                    loggingKey, route, poi.getCatalogItemExternalId());

            if (pricingEnrolledCi != null && pricingEnrolledCi.getCatalogItemInfo() != null
                    && pricingEnrolledCi.getCatalogItemInfo().getTemplateAttr() != null
                    && (pricingEnrolledCi.getCatalogItemInfo().getTemplateAttr() instanceof VisibleTemplate)) {
                VisibleTemplate attr = (VisibleTemplate) pricingEnrolledCi.getCatalogItemInfo().getTemplateAttr();
                if (newCiType.equalsIgnoreCase(attr.getOfferType())) {
                    stage.getChangeServiceDataStage().getPreactiveOffers().add(
                            new CiResourceIdPair(
                                    poi.getCatalogItemExternalId(), poi.getResourceId()));
                }
            }
        }
        for (MtxPurchasedOfferInfo poi : subscriptionResponse.getPurchasedOfferArray()) {
            if (poi.getCatalogItemExternalId() == null
                    || !OFFER_CONSTANTS.OFFER_STATUS_ACTIVE.equalsIgnoreCase(
                            poi.getOfferStatusDescription())) {
                continue;
            }
            if (poi.getCatalogItemExternalId().equalsIgnoreCase(
                    request.getNewCatalogItemExternalId().trim())) {
                String msg = "Subscription already has active offer "
                        + request.getNewCatalogItemExternalId();
                INFO(m_logger, methodKey + msg);
                throw new InvalidRequestException(msg);
            }
            MtxResponsePricingCatalogItem pricingEnrolledCi = queryPricingCatalogItem(
                    loggingKey, route, poi.getCatalogItemExternalId());
            if (pricingEnrolledCi != null && pricingEnrolledCi.getCatalogItemInfo() != null
                    && pricingEnrolledCi.getCatalogItemInfo().getTemplateAttr() != null
                    && (pricingEnrolledCi.getCatalogItemInfo().getTemplateAttr() instanceof VisibleTemplate)) {
                VisibleTemplate attr = (VisibleTemplate) pricingEnrolledCi.getCatalogItemInfo().getTemplateAttr();
                if (newCiType.equalsIgnoreCase(attr.getOfferType())) {
                    String offerChangeType = getOfferChangeType(
                            poi.getCatalogItemExternalId(), request.getNewCatalogItemExternalId());
                    if (StringUtils.isBlank(offerChangeType)) {
                        continue;
                    } else {
                        stage.getChangeServiceDataStage().setChangeType(offerChangeType);
                        for (MtxPricingMetadataInfo pmi : CommonUtils.emptyIfNull(
                                pricingEnrolledCi.getCatalogItemInfo().getMetadataList())) {
                            if (CI_METADATA.GP_PER_MONTH.equalsIgnoreCase(pmi.getName())
                                    || CI_METADATA.GP_CAP.equalsIgnoreCase(pmi.getName())) {
                                stage.getChangeServiceDataStage().setAsIsHasGlobalPass(true);
                                break;
                            }
                        }
                        retPoi = (PurchasedOfferInfo) poi;
                    }
                }
            }
        }

        if (retPoi != null) {
            return retPoi;
        } else {
            String msg = "Subscription does not have active enrolled offer that is of the same type as "
                    + request.getNewCatalogItemExternalId();
            INFO(m_logger, methodKey + msg);
            throw new InvalidRequestException(msg);
        }
    }

    private MtxResponseSubscription getSubscriptionDetails(String loggingKey,
                                                           String subscriptionExternalId)
            throws IntegrationServiceException, NoSuchMethodException, SecurityException,
            InstantiationException, IllegalAccessException, IllegalArgumentException,
            InvocationTargetException {
        final String methodName = "getSubscriptionDetails:";

        MtxResponseSubscription subscription = querySubscriptionData(
                loggingKey, subscriptionExternalId);
        CommonUtils.validateResponse(
                loggingKey, EXCEPTION_MESSAGES.FAILED_TO_QUERY_SUBSCRIPTION, m_logger,
                PaymentAdviceException.class, subscription);

        return subscription;
    }

    private void updateSubscriptionGroups(String loggingKey,
                                          String route,
                                          MtxResponseSubscription subscription,
                                          AdviceDataStage stage)
            throws IntegrationServiceException, NoSuchMethodException, SecurityException,
            InstantiationException, IllegalAccessException, IllegalArgumentException,
            InvocationTargetException {
        final String methodKey = loggingKey + " updateSubscriptionGroups: ";
        if (subscription.getParentGroupIdArray() != null
                && subscription.getParentGroupIdArray().size() > 0) {

            MtxResponseMulti respMsg = querySubscriptionGroups(loggingKey, route, subscription);

            CommonUtils.validateResponse(
                    loggingKey, LOG_MESSAGES.LOG_FAILED_TO_QUERY_SUBSCRIBER_GROUPS, m_logger,
                    PaymentAdviceException.class, respMsg);

            respMsg.getResponseList().forEach(resp -> {
                if (resp instanceof MtxResponseGroup) {
                    MtxResponseGroup group = (MtxResponseGroup) resp;
                    SubscriberGroup subscriberGroup = new SubscriberGroup(group);
                    stage.appendSubscriberGroupList(subscriberGroup);
                    INFO(
                            m_logger,
                            methodKey + "Added group information: " + subscriberGroup.toJson());
                }
            });
        }
    }

    private void updatePayerDetails(String loggingKey, AdviceDataStage stage)
            throws IntegrationServiceException, NoSuchMethodException, SecurityException,
            InstantiationException, IllegalAccessException, IllegalArgumentException,
            InvocationTargetException {
        final String methodKey = loggingKey + " updatePayerDetails: ";
        String payerExternalId = null;
        for (SubscriberGroup sg : CommonUtils.emptyIfNull(stage.getSubscriberGroupList())) {
            if (StringUtils.isNotBlank(
                    sg.getPayerForBeneficiary(stage.getSubscriptionExternalId()))) {
                payerExternalId = sg.getPayerForBeneficiary(stage.getSubscriptionExternalId());
                break;
            }
        }
        if (StringUtils.isBlank(payerExternalId)) {
            INFO(m_logger, methodKey + "No payer id found.");
            return;
        }
        MtxResponseSubscription payerSub = getSubscriptionDetails(loggingKey, payerExternalId);
        if (SUBSCRIPTION_CONSTANTS.SUBSCRIPTION_STATUS_ACTIVE.equalsIgnoreCase(
                payerSub.getStatusDescription())) {
            stage.setPayerExternalId(payerExternalId);
            VisibleSubscriberExtension attr = (VisibleSubscriberExtension) payerSub.getAttr();
            if (StringUtils.isNotBlank(attr.getGeoCode())) {
                stage.setPayerGeoCode(attr.getGeoCode());
            } else {
                WARN(
                        m_logger, methodKey
                                + "Payer id found. But payer does not have geocode. Benefeciary geocode will be used to calculate taxes instead.");
            }
        } else {
            INFO(m_logger, methodKey + "Payer id found. But payer not active.");
        }
    }

    private void updateDefaultPaynowStageForDelta(String loggingKey,
                                                  String route,
                                                  VisibleRequestChangeServiceAdvice request,
                                                  AdviceDataStage stage,
                                                  MtxResponseSubscription subscription,
                                                  MtxResponsePricingCatalogItem pricingNewCi)
            throws CommonUtilsException, IntrospectionException, IntegrationServiceException {
        final String methodKey = loggingKey + " updateDefaultPaynowStageForDelta: ";

        ServiceStage ps = stage.getServiceStage(request.getNewCatalogItemExternalId());

        for (MtxPricingMetadataInfo pmi : CommonUtils.emptyIfNull(
                pricingNewCi.getCatalogItemInfo().getMetadataList())) {
            if (CI_METADATA.TAX_INPUT.equalsIgnoreCase(pmi.getName())) {
                ps.setTaxInput(StringUtils.normalizeSpace(pmi.getValue()));
            } else if (CI_METADATA.STANDALONE_TAX_INPUT.equalsIgnoreCase(pmi.getName())) {
                ps.setStandaloneTaxInput(StringUtils.normalizeSpace(pmi.getValue()));
            } else if (CI_METADATA.CHANGE_CYCLE_DELTA_TAX_INPUT.equalsIgnoreCase(pmi.getName())) {
                stage.getChangeServiceDataStage().setDeltaTaxInput(
                        StringUtils.normalizeSpace(pmi.getValue()));
            } else if (CI_METADATA.GP_CAP.equalsIgnoreCase(pmi.getName())) {
                ps.setGpCap(BigDecimal.valueOf(Long.valueOf(pmi.getValue())));
            } else if (CI_METADATA.GP_PER_MONTH.equalsIgnoreCase(pmi.getName().trim())) {
                ps.setGpPerMonth(BigDecimal.valueOf(Long.valueOf(pmi.getValue())));
            }
        }

        if (pricingNewCi.getCatalogItemInfo().getTemplateAttr() != null
                && (pricingNewCi.getCatalogItemInfo().getTemplateAttr() instanceof VisibleTemplate)) {
            VisibleTemplate attr = (VisibleTemplate) pricingNewCi.getCatalogItemInfo().getTemplateAttr();
            ps.setOfferType(attr.getOfferType());
            ps.setGoodType(attr.getGoodType());

            if (attr.getMinimumCharge() == null
                    || stage.getChangeServiceDataStage().getBillCycle() == ChangeServiceDataStage.BillCycle.CURRENT) {
                ps.setMinimumCharge(BigDecimal.ZERO);
            } else {
                ps.setMinimumCharge(attr.getMinimumCharge());
            }
            // update paynow with flag value
            if (attr.getIgnoreTax_ForPayableAmount() != null) {
                ps.setIgnoreTax_ForPayableAmount(attr.getIgnoreTax_ForPayableAmount());
            }
        }

        List<String> immediateMonthlyChangeTypes = AppPropertyParser.getStringList(
                CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_IMMEDIATE_START_CSV_LIST);
        List<String> immediateAnnualChangeTypes = AppPropertyParser.getStringList(
                CHANGE_SERVICE_CONSTANTS.CHANGE_TYPE_REALIGN_CYCLE_LIST);

        ps.setCycleStartTime(stage.getCycleStartTime());
        ps.setCycleEndTime(stage.getCycleEndTime());

        MtxPurchasedOfferDataBuilder poDataBuilder = (new MtxPurchasedOfferDataBuilder()).withOfferExternalId(
                request.getNewCatalogItemExternalId()).withAmount(
                        stage.getChangeServiceDataStage().getDelta());

        if (request.getAttrData() != null) {
            poDataBuilder.withOfferExtn(request.getAttrData());
        }

        MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
        searchData.setExternalId(request.getSubscriptionExternalId());

        MtxResponsePurchase aocResp = getAocResponsePurchase(
                loggingKey, request.getNewCatalogItemExternalId(), poDataBuilder.build(),
                request.getSubscriptionExternalId());

        boolean isMonthly = true;
        BigDecimal cycleMonths = BigDecimal.ONE;
        if (pricingNewCi.getCatalogItemInfo().getCyclePeriod() != null
                && pricingNewCi.getCatalogItemInfo().getCyclePeriodInterval() != null) {
            cycleMonths = BigDecimal.valueOf(
                    CommonUtils.getCycleMonths(
                            pricingNewCi.getCatalogItemInfo().getCyclePeriod(),
                            pricingNewCi.getCatalogItemInfo().getCyclePeriodInterval()));
        }
        if (cycleMonths.intValue() > 1) {
            isMonthly = false;
        }

        boolean realignCycle = false;
        BigDecimal aocGP = null;
        if (immediateAnnualChangeTypes.contains(
                stage.getChangeServiceDataStage().getChangeType())) {
            realignCycle = true;
            BigDecimal remainingDaysWithToday = BigDecimal.valueOf(
                    CommonUtils.getDaysRemainingInCycle(
                            stage.getCycleEndTime(), subscription.getTimeZone()));

            BigDecimal daysInCycle;

            if (stage.getChangeServiceDataStage().getAsIsPurchasedOfferInfo() != null
                    && stage.getChangeServiceDataStage().getAsIsPurchasedOfferInfo().getCycleInfo() != null) {
                ps.setCycleStartTime(
                        CommonUtils.getMtxTimestampTodayZeroHours(
                                stage.getChangeServiceDataStage().getAsIsPurchasedOfferInfo().getCycleInfo().getCycleStartTime(),
                                subscription.getTimeZone()));
                ps.setCycleEndTime(
                        stage.getChangeServiceDataStage().getAsIsPurchasedOfferInfo().getCycleInfo().getCycleEndTime());
                daysInCycle = BigDecimal.valueOf(
                        CommonUtils.getDaysInCycleForEndTime(
                                stage.getCycleEndTime(), subscription.getTimeZone(),
                                stage.getChangeServiceDataStage().getAsIsPurchasedOfferInfo().getCycleInfo().getPeriod(),
                                stage.getChangeServiceDataStage().getAsIsPurchasedOfferInfo().getCycleInfo().getPeriodInterval()));
                cycleMonths = BigDecimal.valueOf(
                        CommonUtils.getCycleMonths(
                                stage.getChangeServiceDataStage().getAsIsPurchasedOfferInfo().getCycleInfo().getPeriod(),
                                stage.getChangeServiceDataStage().getAsIsPurchasedOfferInfo().getCycleInfo().getPeriodInterval()));
            } else {
                daysInCycle = BigDecimal.valueOf(
                        CommonUtils.getDaysInCycleForEndTime(
                                stage.getCycleEndTime(), subscription.getTimeZone(),
                                CYCLE_PERIODS.MONTHLY, 1));
            }
            BigDecimal proCoeff = remainingDaysWithToday.divide(
                    daysInCycle, MATRIXX_CONSTANTS.DECIMAL_PRECISION, RoundingMode.CEILING);
            ps.setProratedDiscountPrice(
                    stage.getChangeServiceDataStage().getDelta().multiply(proCoeff).setScale(
                            BRAINTREE_CONSTANTS.BT_AMOUNT_PRECISION, RoundingMode.CEILING));
            DEBUG(
                    m_logger,
                    methodKey
                            + "ProratedDiscountPrice = delta * remainingDaysWithToday / daysInCycle = "
                            + stage.getChangeServiceDataStage().getDelta() + "*"
                            + remainingDaysWithToday + "/" + daysInCycle + " = "
                            + ps.getProratedDiscountPrice());
            ps.setAocDiscountPrice(ps.getProratedDiscountPrice());
            ChangeAdviceUtils.updateGlobalPasses(
                    loggingKey, stage, ps, isMonthly, realignCycle, true, aocGP, cycleMonths);
        } else if (immediateMonthlyChangeTypes.contains(
                stage.getChangeServiceDataStage().getChangeType())) {
            BigDecimal ciProratedPrice = BigDecimal.ZERO;
            if (aocResp != null && aocResp.getPurchaseInfoArray() != null
                    && !aocResp.getPurchaseInfoArray().isEmpty()) {
                for (MtxPurchaseInfo purchaseInfoItem : aocResp.getPurchaseInfoArray()) {
                    ciProratedPrice = ciProratedPrice.add(
                            CommonUtils.getCurrencyAmount(
                                    purchaseInfoItem.getBalanceImpactGroupList()));
                    purchaseInfoItem.getBalanceImpactGroupList().forEach(biig -> {
                        ps.setCycleStartTime(biig.getCycleStartTime());
                        ps.setCycleEndTime(biig.getCycleEndTime());
                    });
                }
            }

            ps.setAocDiscountPrice(ciProratedPrice);
            DEBUG(
                    m_logger, methodKey + "Aoc amount based on impact amounts of aoc response: "
                            + ciProratedPrice);
            ps.setProratedDiscountPrice(
                    BigDecimal.ZERO.add(ciProratedPrice).setScale(
                            BRAINTREE_CONSTANTS.BT_AMOUNT_PRECISION, RoundingMode.CEILING));
            ChangeAdviceUtils.updateGlobalPasses(
                    loggingKey, stage, ps, isMonthly, realignCycle, true, aocGP, cycleMonths);
        } else {
            // New service starts next cycle
            ps.setAocDiscountPrice(BigDecimal.ZERO);
            ps.setProratedDiscountPrice(BigDecimal.ZERO);
            if (stage.getChangeServiceDataStage().getAsIsPurchasedOfferInfo() != null
                    && stage.getChangeServiceDataStage().getAsIsPurchasedOfferInfo().getCycleInfo() != null) {
                ps.setCycleStartTime(
                        stage.getChangeServiceDataStage().getAsIsPurchasedOfferInfo().getCycleInfo().getCycleStartTime());
                ps.setCycleEndTime(
                        stage.getChangeServiceDataStage().getAsIsPurchasedOfferInfo().getCycleInfo().getCycleEndTime());
            }
            for (MtxPurchaseInfo purchaseInfoItem : CommonUtils.emptyIfNull(
                    aocResp.getPurchaseInfoArray())) {
                for (MtxBalanceImpactInfoGroup balanceImpGrpItem : CommonUtils.emptyIfNull(
                        purchaseInfoItem.getBalanceImpactGroupList())) {
                    for (MtxBalanceImpactInfo balanceImpInfoItem : CommonUtils.emptyIfNull(
                            balanceImpGrpItem.getBalanceImpactList())) {
                        if (AppPropertyProvider.getInstance().getString(
                                BALANCE_CONSTANTS.BALANCE_NAME_GLOBAL_PASS).trim().equalsIgnoreCase(
                                        balanceImpInfoItem.getBalanceTemplateName())) {
                            aocGP = balanceImpInfoItem.getCurrentBalanceAmount();
                            DEBUG(
                                    m_logger,
                                    methodKey + "Resulting next cycle global pass as per AoC: "
                                            + aocGP);
                            break;
                        }
                    }
                    if (aocGP != null)
                        break;
                }
                if (aocGP != null) {
                    break;
                } else {
                    Long gpBalResourceId = null;
                    boolean noImpactOnGp = false;
                    for (MtxBalanceInfo bi : subscription.getBalanceArray()) {
                        if (AppPropertyProvider.getInstance().getString(
                                BALANCE_CONSTANTS.BALANCE_NAME_GLOBAL_PASS).trim().equalsIgnoreCase(
                                        bi.getName())) {
                            gpBalResourceId = bi.getResourceId();
                            break;
                        }
                    }
                    if (gpBalResourceId != null) {
                        for (MtxRequiredBalanceInfo rb : purchaseInfoItem.getRequiredBalanceArray()) {
                            if (gpBalResourceId.longValue() == rb.getResourceId().longValue()) {
                                DEBUG(
                                        m_logger,
                                        methodKey + "No impact on global pass count as per AoC");
                                noImpactOnGp = true;
                                break;
                            }
                        }
                    }
                    if (noImpactOnGp) {
                        for (VisibleAttribute asIsAttr : CommonUtils.emptyIfNull(
                                stage.getChangeServiceDataStage().getAsisCatalogItem().getAttributes())) {
                            if (CHANGE_SERVICE_CONSTANTS.ATTRIBUTE_NAME_FREE_GLOBAL_PASS.equalsIgnoreCase(
                                    asIsAttr.getName())
                                    && StringUtils.isNotBlank(asIsAttr.getValue())) {
                                aocGP = new BigDecimal(asIsAttr.getValue());
                            }
                        }
                    }

                }
            }
            ChangeAdviceUtils.updateGlobalPasses(
                    loggingKey, stage, ps, isMonthly, realignCycle, false, aocGP, cycleMonths);
        }
        ps.setFinalPayableAmount(
                BigDecimal.ZERO.add(ps.getAocDiscountPrice()).setScale(
                        BRAINTREE_CONSTANTS.BT_AMOUNT_PRECISION, RoundingMode.CEILING));
        ps.setNonCreditAmount(
                BigDecimal.ZERO.add(ps.getAocDiscountPrice()).setScale(
                        BRAINTREE_CONSTANTS.BT_AMOUNT_PRECISION, RoundingMode.CEILING));

        DEBUG(m_logger, methodKey + "Updated Paynow Stage: " + ps.toJson());
    }

    private void updateQuoteAdviceOutputNextCycleAop(String loggingKey,
                                                     AdviceDataStage stageAop,
                                                     VisibleResponseQuoteAdviceService output) {
        final String methodKey = loggingKey + " updateChangeAdviceOutputNextCycleAop: ";
        VisibleNextCyclePaymentAdvice ncpa = AdviceUtils.getNextCycleAop(loggingKey, stageAop);
        output.setNextCyclePaymentAdvice(ncpa);
        INFO(m_logger, methodKey + " Updated ChangeServiceAdvice output: " + output.toJson());
    }

}
