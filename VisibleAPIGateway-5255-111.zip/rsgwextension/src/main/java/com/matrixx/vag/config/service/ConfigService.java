package com.matrixx.vag.config.service;

import static com.matrixx.platform.LogUtils.INFO;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Iterator;

import org.apache.commons.configuration2.ex.ConfigurationException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.matrixx.datacontainer.mdc.MtxResponse;
import com.matrixx.datacontainer.mdc.VisibleProperty;
import com.matrixx.datacontainer.mdc.VisibleRequestGetConfig;
import com.matrixx.datacontainer.mdc.VisibleRequestReloadConfig;
import com.matrixx.datacontainer.mdc.VisibleResponseGetConfig;
import com.matrixx.vag.common.Constants.MATRIXX_CONSTANTS;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.common.coverage.Generated;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.exception.ConfigServiceException;
import com.matrixx.vag.service.IntegrationService;

/**
 * Configuration data reload service.
 *
 * @author unico
 */
@Configuration
public class ConfigService extends IntegrationService {
	private static final Logger m_logger = LoggerFactory.getLogger(ConfigService.class);
	
	@Generated
    @Bean(name = "ConfigService")
    ConfigService getService() {
        return new ConfigService();
    }
	
    public ConfigService() {
        AppPropertyProvider.getInstance();
    }

    /**
     * Reload system configuration.
     *
     * @param input
     * @param output
     * @throws ConfigServiceException
     */
    @Generated
    public void reloadConfig(VisibleRequestReloadConfig input, MtxResponse output)
            throws ConfigServiceException {
        try {
            AppPropertyProvider.reloadApplicationProperties();
            String message = "Successfully reloaded system configuration";
            INFO(m_logger, message);
            String visibleVersion = null;
            try {
                Process process = Runtime.getRuntime().exec("rpm -qa visibleapigateway");
                BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
                String line = "";
                while ((line = reader.readLine()) != null) {
                	visibleVersion = line;
                }            	
            }catch (Exception e) {
            	//Empty
            }
            
            output.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
            String msg = StringUtils.isNotBlank(visibleVersion)? " Deployed RPM version: " + visibleVersion: "";
            output.setResultText(MATRIXX_CONSTANTS.RESULT_TEXT_MTX_SUCCESS + msg);
        } catch (ConfigurationException e) {
            String message = "Failed to reload system configuration - " + e.getMessage();
            throw new ConfigServiceException(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, message);
        }
    }

    public void getConfig(VisibleRequestGetConfig input, VisibleResponseGetConfig output)
            throws ConfigServiceException, IOException {
        Iterator<String> kIter = AppPropertyProvider.getInstance().getKeys();
        while (kIter.hasNext()) {
            String key = kIter.next();
            VisibleProperty prop = new VisibleProperty();
            prop.setName(key);
            prop.setValue(AppPropertyProvider.getInstance().getString(key));
            output.getVisiblePropertyListAppender().add(prop);
        }
              
        String message = "Successfully obtained system configuration";
        INFO(m_logger, message);
        output.setResult(RESULT_CODES.RESULT_CODE_CUSTOM_SUCCESS);
        output.setResultText(MATRIXX_CONSTANTS.RESULT_TEXT_MTX_SUCCESS);
    }    
}
