package com.matrixx.vag.advice.model;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.matrixx.datacontainer.MtxDate;
import com.matrixx.datacontainer.MtxTimestamp;
import com.matrixx.datacontainer.mdc.MtxPurchasedOfferInfo;
import com.matrixx.datacontainer.mdc.VisiblePurchasedOfferExtension;
import com.matrixx.vag.common.Constants.TAX_CONSTANTS;
import com.matrixx.vag.tax.model.ServiceTaxResponse;

public class ServiceStage {
    private String catalogItemExternalId;    
    private Long offerResourceId;
    private BigDecimal globalPasses;
    private BigDecimal gpCap;
    private BigDecimal gpPerMonth;
    private BigDecimal aocDiscountPrice; // For response message without rounding.
    private BigDecimal proratedDiscountPrice; // aocDiscountPrice may be with rounding    
    private BigDecimal discountPrice; // discount price from input request.
    private boolean discountPriceFromSubscription = false; // discount price from input request.
    private BigDecimal grossPrice; // copy from previous tax response.
    ServiceTaxResponse prevTaxResponse;
    
    private BigDecimal finalPayableAmount; // actual payNow amount
    private BigDecimal nonCreditAmount; // payNow amount + mainbalance amount.
    private BigDecimal consumableMainBalance;
    private BigDecimal redeemableGiftAmount;
    private BigDecimal availableGiftAmount;
    private BigDecimal creditsUsed;
    private BigDecimal minimumCharge; // Minimum Amount that should come from paynow and residual mainbalance
    private BigDecimal maxPromo;    
    private BigDecimal taxFeeAmount; // From new tax response
    private String taxInput; //From Ci Attributes
    private String standaloneTaxInput; //From Ci Attributes    
    private MtxDate effectivePaidCycleStartDate; //Paid cycle start date as per VisiblePurchasedOfferExtension. applicable for AoP only.
    private String taxResponse;
    private String zeroTaxResponse; //Tax response for zero amounts. If configured in metadata
    private String offerType; //From Ci Attributes
    private String goodType; //From Ci Attributes
    private String purchaseServiceType; //From VisiblePurchasedOfferExtension.
    private Boolean ignoreTax_ForPayableAmount;
    private MtxPurchasedOfferInfo purchasedOfferInfo = new MtxPurchasedOfferInfo();
    private MtxTimestamp cycleStartTime;
    private MtxTimestamp cycleEndTime;
    private MtxTimestamp nextCycleStartTime;
    private MtxTimestamp nextCycleEndTime;
    private MtxTimestamp purchaseOfferEndTime; //from MtxPurchaseInfo
    private MtxTimestamp mainBalanceImpactCycleStartTime; //from MtxBalanceImpactInfoGroup
    private MtxTimestamp mainBalanceImpactCycleEndTime;//from MtxBalanceImpactInfoGroup
    
    private boolean skipRenewal;

    public ServiceStage(String catalogItemExternalId) {
        this.catalogItemExternalId = catalogItemExternalId;
        setTaxFeeAmount(BigDecimal.ZERO);
        setProratedDiscountPrice(BigDecimal.ZERO);
	setDiscountPrice(BigDecimal.ZERO);
        setGrossPrice(BigDecimal.ZERO);
        setFinalPayableAmount(BigDecimal.ZERO);
        setNonCreditAmount(BigDecimal.ZERO);
        setCreditsUsed(BigDecimal.ZERO);
        setMinimumCharge(BigDecimal.ZERO);
        setConsumableMainBalance(BigDecimal.ZERO);
        setMaxPromo(BigDecimal.ZERO);
        setAvailableGiftAmount(BigDecimal.ZERO);
        setRedeemableGiftAmount(BigDecimal.ZERO);
        setTaxInput("");
        setStandaloneTaxInput("");
        setOfferType(""); 
        setGoodType("");
	setIgnoreTax_ForPayableAmount("");
        setCycleStartTime(null);
        setCycleEndTime(null);
        setNextCycleStartTime(null);
        setNextCycleEndTime(null);
        setPurchaseOfferEndTime(null);
        setMainBalanceImpactCycleStartTime(null);
        setMainBalanceImpactCycleEndTime(null);
        setGpCap(null);
        setSkipRenewal(false);
    }

    public ServiceStage(String catalogItemExternalId, Long offerResourceId) {
    	this(catalogItemExternalId);
    	this.offerResourceId = offerResourceId;
    }

    public BigDecimal getMinimumCharge() {
        return minimumCharge;
    }

    public void setMinimumCharge(BigDecimal minimumCharge) {
        this.minimumCharge = minimumCharge;
    }

    public String getCatalogItemExternalId() {
        return catalogItemExternalId;
    }

    public Long getOfferResourceId() {
        return offerResourceId;
    }

    public BigDecimal getProratedDiscountPrice() {
        return proratedDiscountPrice;
    }

    public void setProratedDiscountPrice(BigDecimal proratedDiscountPrice) {
        this.proratedDiscountPrice = proratedDiscountPrice;
        if(this.grossPrice == null) {
        	setGrossPrice(proratedDiscountPrice);
        }
    }

    public BigDecimal getDiscountPrice() {
        return discountPrice;
    }

    public void setDiscountPrice(BigDecimal discountPrice) {
        this.discountPrice = discountPrice;
        if (this.grossPrice == null ||this.grossPrice.compareTo(discountPrice)<=0) {
            setGrossPrice(discountPrice);
        }
    }

    public BigDecimal getFinalPayableAmount() {
        return finalPayableAmount;
    }

    public void setFinalPayableAmount(BigDecimal finalPayableAmount) {
        this.finalPayableAmount = finalPayableAmount;
    }

    public BigDecimal getNonCreditAmount() {
        return nonCreditAmount;
    }

    public void setNonCreditAmount(BigDecimal nonCreditAmount) {
        this.nonCreditAmount = nonCreditAmount;
    }

    public BigDecimal getCreditsUsed() {
        return creditsUsed;
    }

    public void setCreditsUsed(BigDecimal creditsUsed) {
        this.creditsUsed = creditsUsed;
    }

    public BigDecimal getGrossPrice() {
        return grossPrice;
    }

    public void setGrossPrice(BigDecimal grossPrice) {
        this.grossPrice = grossPrice;
    }

    public String getTaxInput() {
        return taxInput;
    }

    public void setTaxInput(String taxInput) {
        if (StringUtils.isNotBlank(taxInput)) {
            this.taxInput = StringUtils.normalizeSpace(taxInput);
        }
    }

    public String getStandaloneTaxInput() {
        return standaloneTaxInput;
    }

    public void setStandaloneTaxInput(String standaloneTaxInput) {
        if (StringUtils.isNotBlank(standaloneTaxInput)) {
            this.standaloneTaxInput = StringUtils.normalizeSpace(standaloneTaxInput);
        }
    }

    public MtxDate getEffectivePaidCycleStartDate() {
        return effectivePaidCycleStartDate;
    }

    public void setEffectivePaidCycleStartDate(MtxDate effectivePaidCycleStartDate) {
        this.effectivePaidCycleStartDate = effectivePaidCycleStartDate;
    }

    public Boolean getIgnoreTax_ForPayableAmount() {
        return ignoreTax_ForPayableAmount;
    }

    public void setIgnoreTax_ForPayableAmount(String ignoreTax_ForPayableAmount) {
        if (ignoreTax_ForPayableAmount.trim().equalsIgnoreCase("true")) {
            this.ignoreTax_ForPayableAmount = true;
        } else if (ignoreTax_ForPayableAmount.trim().equalsIgnoreCase("false")) {
            this.ignoreTax_ForPayableAmount = false;
        } else {
            this.ignoreTax_ForPayableAmount = null;
        }
    }

    public String getOfferType() {
        return offerType;
    }

    public void setOfferType(String offerType) {
        this.offerType = offerType.trim();
    }

    @JsonIgnore
    public String getTaxResponse() {
        return taxResponse;
    }

    public void setTaxResponse(String taxResponse) {
        this.taxResponse = taxResponse;
    }

    @JsonIgnore
    public String getZeroTaxResponse() {
        return zeroTaxResponse;
    }

    public void setZeroTaxResponse(String zeroTaxResponse) {
        this.zeroTaxResponse = zeroTaxResponse;
    }

    public String getPreviousGeocode() {
        return prevTaxResponse != null
                && !prevTaxResponse.getMsgID().toUpperCase().trim().startsWith(
                        TAX_CONSTANTS.MSG_PREFIX_GIFT_TAX.toUpperCase())
                                ? prevTaxResponse.getGeocode() : "";
    }

    public String getPreviousPlanId() {
        return prevTaxResponse!=null? prevTaxResponse.getPlanID(): "";
    }

    public BigDecimal getTaxFeeAmount() {
        return taxFeeAmount;
    }

    public void setTaxFeeAmount(BigDecimal taxFeeAmount) {
        this.taxFeeAmount = taxFeeAmount;
    }

    public BigDecimal getConsumableMainBalance() {
        return consumableMainBalance;
    }

    public void setConsumableMainBalance(BigDecimal consumableMainBalance) {
        this.consumableMainBalance = consumableMainBalance;
    }

    public BigDecimal getMaxPromo() {
        return maxPromo;
    }

    public void setMaxPromo(BigDecimal maxPromo) {
        this.maxPromo = maxPromo;
    }

    public String getGoodType() {
        return goodType;
    }

    public void setGoodType(String goodType) {
        this.goodType = goodType;
    }

    public BigDecimal getAocDiscountPrice() {
        return aocDiscountPrice;
    }

    public void setAocDiscountPrice(BigDecimal aocDiscountPrice) {
        this.aocDiscountPrice = aocDiscountPrice;
    }

    public String getStatus() {
        return getPurchasedOfferInfo().getOfferStatusDescription();
    }

    public String getPurchaseServiceType() {
        return purchaseServiceType;
    }

    public MtxPurchasedOfferInfo getPurchasedOfferInfo() {
        return this.purchasedOfferInfo;
    }

    public void setPurchasedOfferInfo(MtxPurchasedOfferInfo purchasedOfferInfo) {
        this.purchasedOfferInfo = purchasedOfferInfo;
        VisiblePurchasedOfferExtension poe = (VisiblePurchasedOfferExtension) purchasedOfferInfo.getAttr();
        if (StringUtils.isNotBlank(poe.getPurchaseServiceType())) {
            this.purchaseServiceType = poe.getPurchaseServiceType();
        }
    }

    public MtxDate getActualPaidCycleStartDate() {
        VisiblePurchasedOfferExtension poe = (VisiblePurchasedOfferExtension) getPurchasedOfferInfo().getAttr();
        if (poe != null && poe.getPaidCycleStartDate() != null) {
            return poe.getPaidCycleStartDate();
        } else {
            return null;
        }
    }

    public MtxTimestamp getCycleStartTime() {
        return cycleStartTime;
    }

    public void setCycleStartTime(MtxTimestamp cycleStartTime) {
        this.cycleStartTime = cycleStartTime;
    }

    public MtxTimestamp getCycleEndTime() {
        return cycleEndTime;
    }

    public void setCycleEndTime(MtxTimestamp cycleEndTime) {
        this.cycleEndTime = cycleEndTime;
    }

    public MtxTimestamp getNextCycleStartTime() {
        return nextCycleStartTime;
    }

    public void setNextCycleStartTime(MtxTimestamp nextCycleStartTime) {
        this.nextCycleStartTime = nextCycleStartTime;
    }

    public MtxTimestamp getNextCycleEndTime() {
        return nextCycleEndTime;
    }

    public void setNextCycleEndTime(MtxTimestamp nextCycleEndTime) {
        this.nextCycleEndTime = nextCycleEndTime;
    }

    public BigDecimal getRedeemableGiftAmount() {
        return redeemableGiftAmount;
    }

    public void setRedeemableGiftAmount(BigDecimal giftRedeemableAmount) {
        this.redeemableGiftAmount = giftRedeemableAmount;
    }

    public BigDecimal getAvailableGiftAmount() {
        return availableGiftAmount;
    }

    public void setAvailableGiftAmount(BigDecimal availableGiftAmount) {
        this.availableGiftAmount = availableGiftAmount;
    }

    public boolean isSkipRenewal() {
        return skipRenewal;
    }

    public void setSkipRenewal(boolean skipRenewal) {
        this.skipRenewal = skipRenewal;
    }

    public BigDecimal getGlobalPasses() {
        return globalPasses;
    }

    public void setGlobalPasses(BigDecimal globalPasses) {
        this.globalPasses = globalPasses;
    }
    
    public BigDecimal getGpCap() {
        return gpCap;
    }

    public void setGpCap(BigDecimal gpCap) {
        this.gpCap = gpCap;
    }

    public BigDecimal getGpPerMonth() {
        return gpPerMonth;
    }

    public void setGpPerMonth(BigDecimal gpPerMonth) {
        this.gpPerMonth = gpPerMonth;
    }
    
    public ServiceTaxResponse getPrevTaxResponse() {
        return prevTaxResponse;
    }

    public void setPrevTaxResponse(ServiceTaxResponse prevTaxResponse) {
        this.prevTaxResponse = prevTaxResponse;
    }

    public MtxTimestamp getPurchaseOfferEndTime() {
        return purchaseOfferEndTime;
    }

    public void setPurchaseOfferEndTime(MtxTimestamp purchaseOfferEndTime) {
        this.purchaseOfferEndTime = purchaseOfferEndTime;
    }

    public boolean isDiscountPriceFromSubscription() {
        return discountPriceFromSubscription;
    }

    public void setDiscountPriceFromSubscription(boolean discountPriceFromSubscription) {
        this.discountPriceFromSubscription = discountPriceFromSubscription;
    }
    
    public MtxTimestamp getMainBalanceImpactCycleStartTime() {
        return mainBalanceImpactCycleStartTime;
    }

    public void setMainBalanceImpactCycleStartTime(MtxTimestamp mainBalanceImpactCycleStartTime) {
        this.mainBalanceImpactCycleStartTime = mainBalanceImpactCycleStartTime;
    }

    public MtxTimestamp getMainBalanceImpactCycleEndTime() {
        return mainBalanceImpactCycleEndTime;
    }

    public void setMainBalanceImpactCycleEndTime(MtxTimestamp mainBalanceImpactCycleEndTime) {
        this.mainBalanceImpactCycleEndTime = mainBalanceImpactCycleEndTime;
    }
    
    public String toJson() {
        ObjectMapper mapper = new ObjectMapper();
        try {
            Map<String, Object> longMap = new HashMap<String, Object>();
            longMap.put("catalogItemExternalId", catalogItemExternalId);
            longMap.put("offerResourceId", offerResourceId);
            longMap.put("proratedDiscountPrice", proratedDiscountPrice);
            longMap.put("discountPrice", discountPrice);
            longMap.put("grossPrice", grossPrice);
            longMap.put("finalPayableAmount", finalPayableAmount);
            longMap.put("nonCreditAmount", nonCreditAmount);
            longMap.put("creditsUsed", creditsUsed);
            longMap.put("taxFeeAmount", taxFeeAmount);
            longMap.put("minimumCharge", minimumCharge);
            longMap.put("taxInput", taxInput);
            longMap.put("standaloneTaxInput", standaloneTaxInput);
            longMap.put("paidCycleStartDate", effectivePaidCycleStartDate);
            longMap.put("taxResponse", taxResponse);
            longMap.put("offerType", offerType);
            longMap.put("goodType", goodType);
            longMap.put("ignoreTax_ForPayableAmount", ignoreTax_ForPayableAmount);
            longMap.put("consumableMainBalance", consumableMainBalance);
            longMap.put("purchaseServiceType", purchaseServiceType);
            longMap.put("cycleStartTime", cycleStartTime);
            longMap.put("cycleEndTime", cycleEndTime);
            longMap.put("nextCycleStartTime", nextCycleStartTime);
            longMap.put("nextCycleEndTime", nextCycleEndTime);
//            longMap.put("availableGiftAmount", availableGiftAmount);
//            longMap.put("redeemableGiftAmount", redeemableGiftAmount);
            longMap.put("skipRenewal", skipRenewal);
            longMap.put("status", purchasedOfferInfo.getOfferStatusDescription());
            longMap.put("globalPasses", globalPasses);
            longMap.put("gpCap", gpCap);
            longMap.put("gpPerMonth", gpPerMonth);
            longMap.put("purchaseOfferEndTime", purchaseOfferEndTime);
            longMap.put("purchasedOfferInfo", purchasedOfferInfo.toJson());            
            return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(longMap);
        } catch (JsonProcessingException e) {
            return null;
        }
    }
        
    public String toShortJson() {
        ObjectMapper mapper = new ObjectMapper();
        try {
            Map<String, Object> shortMap = new HashMap<String, Object>();
            shortMap.put("catalogItemExternalId", catalogItemExternalId);
            shortMap.put("offerResourceId", offerResourceId);
            shortMap.put("proratedDiscountPrice", proratedDiscountPrice);
            shortMap.put("finalPayableAmount", finalPayableAmount);
            shortMap.put("nonCreditAmount", nonCreditAmount);
            shortMap.put("consumableMainBalance", consumableMainBalance);
            shortMap.put("creditsUsed", creditsUsed);
//            shortMap.put("availableGiftAmount", availableGiftAmount);
//            shortMap.put("redeemableGiftAmount", redeemableGiftAmount);
            shortMap.put("discountPrice", discountPrice);
            shortMap.put("taxFeeAmount", taxFeeAmount);
            shortMap.put("proratedDiscountPrice", proratedDiscountPrice);
            return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(shortMap);
        } catch (JsonProcessingException e) {
            return null;
        }
    }

    public ServiceStage shallowClone() {
        ServiceStage clone = new ServiceStage(this.catalogItemExternalId);
        clone.offerResourceId = this.offerResourceId;
        clone.proratedDiscountPrice = this.proratedDiscountPrice;
        clone.discountPrice = this.discountPrice;
        clone.grossPrice = this.grossPrice;
        clone.finalPayableAmount = this.finalPayableAmount;
        clone.nonCreditAmount = this.nonCreditAmount;
        clone.creditsUsed = this.creditsUsed;
        clone.taxFeeAmount = this.taxFeeAmount;
        clone.minimumCharge = this.minimumCharge;
        clone.taxInput = this.taxInput;
        clone.standaloneTaxInput = this.standaloneTaxInput;
        clone.effectivePaidCycleStartDate = this.effectivePaidCycleStartDate;
        clone.taxResponse = this.taxResponse;
        clone.offerType = this.offerType;
        clone.goodType = this.goodType;
        clone.ignoreTax_ForPayableAmount = this.ignoreTax_ForPayableAmount;
        clone.consumableMainBalance = this.consumableMainBalance;
        clone.purchaseServiceType = this.purchaseServiceType;
        clone.cycleStartTime = this.cycleStartTime;
        clone.cycleEndTime = this.cycleEndTime;
        clone.nextCycleStartTime = this.nextCycleStartTime;
        clone.nextCycleEndTime = this.nextCycleEndTime;
        clone.purchasedOfferInfo = this.purchasedOfferInfo;
        clone.skipRenewal = this.skipRenewal;
        clone.globalPasses = this.globalPasses;
        clone.gpCap = this.gpCap;
        clone.gpPerMonth = this.gpPerMonth;
        clone.purchaseOfferEndTime = this.purchaseOfferEndTime;
        clone.mainBalanceImpactCycleStartTime = this.mainBalanceImpactCycleStartTime;
        clone.mainBalanceImpactCycleEndTime = this.mainBalanceImpactCycleEndTime;
        return clone;
    }

}