package com.matrixx.vag.advice.service;

import static com.matrixx.platform.LogUtils.INFO;
import static com.matrixx.platform.LogUtils.WARN;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.matrixx.datacontainer.mdc.MtxBalanceInfo;
import com.matrixx.datacontainer.mdc.MtxBalanceInfoSimple;
import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import com.matrixx.datacontainer.mdc.MtxResponseWallet;
import com.matrixx.datacontainer.mdc.VisibleCredits;
import com.matrixx.datacontainer.mdc.VisibleGroup;
import com.matrixx.datacontainer.mdc.VisibleOfferDetails;
import com.matrixx.datacontainer.mdc.VisibleResponseQuoteAdviceService;
import com.matrixx.datacontainer.mdc.VisibleSubscriberExtension;
import com.matrixx.vag.advice.model.CreditStage;
import com.matrixx.vag.advice.model.ServiceStage;
import com.matrixx.vag.advice.model.SubscriberGroup;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.Constants.CI_METADATA;
import com.matrixx.vag.common.Constants.GENERIC_CONSTANTS;
import com.matrixx.vag.common.Constants.LOG_MESSAGES;
import com.matrixx.vag.common.Constants.MATRIXX_CONSTANTS;
import com.matrixx.vag.common.Constants.OFFER_CONSTANTS;
import com.matrixx.vag.common.Constants.TAX_CONSTANTS;
import com.matrixx.vag.common.request.builder.ServiceTaxRequestBuilder;
import com.matrixx.vag.exception.IntegrationServiceException;
import com.matrixx.vag.exception.PaymentAdviceException;
import com.matrixx.vag.tax.model.ServiceTaxRequest;
import com.matrixx.vag.tax.model.ServiceTaxResponse;

public class QuoteAdviceUtils {

    private static final Logger m_logger = LoggerFactory.getLogger(QuoteAdviceUtils.class);

    public static void updateTaxesInServiceStage(String loggingKey,
                                                 String route,                                                
                                                 AdviceDataStage stage) {
        final String methodKey = loggingKey + " updateTaxesInServiceStage: ";
        INFO(m_logger, methodKey + "update taxes for " + stage.getAdviceFor());

        if (!stage.isAdviceWithTaxes()) {
            INFO(m_logger, methodKey + "Advice is without taxes. Taxapi will not be called.");
            return;
        }

        for (ServiceStage paynow : CommonUtils.emptyIfNull(stage.getPayNowMap().values())) {
            if (paynow.getProratedDiscountPrice().signum() <= 0) {
                continue;
            }
            // if (paynow.getProratedDiscountPrice().signum() > 0) {
            String taxTemplateName = "";
            if ((paynow.getOfferType().equalsIgnoreCase(OFFER_CONSTANTS.OFFER_TYPE_ADDON)
                    && stage.isBaseOfferInAdvice())) {
                taxTemplateName = CI_METADATA.TAX_INPUT;
            } else if ((paynow.getOfferType().equalsIgnoreCase(OFFER_CONSTANTS.OFFER_TYPE_ADDON))) {
                taxTemplateName = CI_METADATA.STANDALONE_TAX_INPUT;
            } else {
                taxTemplateName = CI_METADATA.TAX_INPUT;
            }
            String taxTemplate = taxTemplateName.equalsIgnoreCase(CI_METADATA.STANDALONE_TAX_INPUT)
                    ? paynow.getStandaloneTaxInput() : paynow.getTaxInput();

            String geoCode;
            if (StringUtils.isNotBlank(stage.getRequestGeoCode())) {
                geoCode = stage.getRequestGeoCode();             
            } else if (StringUtils.isNotBlank(stage.getPayerGeoCode())
                    && !GENERIC_CONSTANTS.YES.equalsIgnoreCase(stage.getIgnorePayer())) {
                geoCode = stage.getPayerGeoCode();
            } else {
                if (StringUtils.isNotBlank(stage.getSubscriberGeoCode())) {
                    geoCode = stage.getSubscriberGeoCode();
                } else {
                    String noGeocodeMsg = "No valid geocode passed for tax calculation"
                            + StringUtils.SPACE + "requestGeoCode: " + stage.getRequestGeoCode()
                            + StringUtils.SPACE + "subscriberGeoCode: "
                            + stage.getSubscriberGeoCode();
                    WARN(
                            m_logger,
                            methodKey + LOG_MESSAGES.LOG_FAILED_SERVICE_TAX + StringUtils.SPACE
                                    + GENERIC_CONSTANTS.ERROR_PREFIX + noGeocodeMsg);
                    paynow.setTaxResponse(GENERIC_CONSTANTS.ERROR_PREFIX + noGeocodeMsg);
                    stage.setServiceTaxApiErrorMessage(
                            LOG_MESSAGES.LOG_FAILED_SERVICE_TAX + StringUtils.SPACE
                                    + GENERIC_CONSTANTS.ERROR_PREFIX + noGeocodeMsg);
                    return;
                }
            }
            // @formatter:off
            ServiceTaxRequestBuilder taxReqBuilder = (new ServiceTaxRequestBuilder())
                    .withRequestTemplate(taxTemplate)
                    .withGrossPrice(paynow.getGrossPrice())
                    .withDiscountPrice(paynow.getProratedDiscountPrice())
                    .withBrand(stage.getBrand())
                    .withGeoCode(geoCode);
            // @formatter:on
            try {
                ServiceTaxRequest taxRequest = taxReqBuilder.build();
                if (StringUtils.isNotBlank(stage.getPayerExternalId())
                        && !GENERIC_CONSTANTS.YES.equalsIgnoreCase(stage.getIgnorePayer())) {
                    taxRequest.setMsgID(
                            String.format(
                                    TAX_CONSTANTS.MSG_FORMAT_ADVICE, taxRequest.getMsgID(),
                                    stage.getPayerExternalId()));
                }

                INFO(
                        m_logger, methodKey
                                + "Call TaxApi to calculate service taxes for quote or change service advice");

                String taxResp = AdviceUtils.getTaxDetailsWithoutRefTax(
                        loggingKey, route, taxRequest);

                if (StringUtils.isNotBlank(taxResp)
                        && !taxResp.toUpperCase().startsWith(GENERIC_CONSTANTS.ERROR_PREFIX)) {
                    paynow.setTaxResponse(taxResp);
                    ServiceTaxResponse taxDetails = CommonUtils.getServiceTaxResponseFromJsonString(
                            taxResp);
                    paynow.setTaxFeeAmount(
                            taxDetails.getTransactionElement().get(0).getTotalFeeAmount());
                    INFO(
                            m_logger,
                            methodKey + "Fee amount : " + taxDetails.getTransactionElement().get(
                                    0).getTotalFeeAmount());
                } else {
                    WARN(
                            m_logger, methodKey + LOG_MESSAGES.LOG_FAILED_SERVICE_TAX
                                    + StringUtils.SPACE + taxResp);
                    paynow.setTaxResponse(taxResp);
                    stage.setServiceTaxApiErrorMessage(
                            LOG_MESSAGES.LOG_FAILED_SERVICE_TAX + StringUtils.SPACE + taxResp);
                }
            } catch (Exception ex) {
                WARN(
                        m_logger, methodKey + LOG_MESSAGES.LOG_FAILED_SERVICE_TAX
                                + StringUtils.SPACE + ExceptionUtils.getStackTrace(ex));
                paynow.setTaxResponse(GENERIC_CONSTANTS.ERROR_PREFIX + ex.getMessage());
                stage.setServiceTaxApiErrorMessage(
                        LOG_MESSAGES.LOG_FAILED_SERVICE_TAX + StringUtils.SPACE + ex.getMessage());
            }
        }
    }

    public static void updateDataFromWallet(String loggingKey,
                                            AdviceDataStage stage,
                                            MtxResponseWallet wallet) {
        final String methodKey = loggingKey + " updateDataFromWallet: ";
        stage.setAvailableMainBalanceAmount(BigDecimal.ZERO);
        stage.setReservedMainBalanceAmount(BigDecimal.ZERO);
        Date currentDate = new Date();
        for (MtxBalanceInfo bi : CommonUtils.emptyIfNull(wallet.getBalanceArray())) {
            if (bi instanceof MtxBalanceInfoSimple
                    && ((MtxBalanceInfoSimple) bi).getIsMainBalance()) {
                if (stage.getPaidCycleStartDate().getTimestamp().after(currentDate)) {
                    stage.setReservedMainBalanceAmount(bi.getAmount().negate());
                } else {
                    stage.setAvailableMainBalanceAmount(bi.getAmount().negate());
                }
            }
        }

        INFO(
                m_logger, loggingKey + methodKey + "Updated mainbalance amount from wallet: "
                        + stage.getReservedMainBalanceAmount());

        if (wallet.getBillingCycle() != null) {
            stage.setCycleStartTime(wallet.getBillingCycle().getCurrentPeriodStartTime());
            stage.setCycleEndTime(wallet.getBillingCycle().getCurrentPeriodEndTime());
            INFO(
                    m_logger, loggingKey + methodKey
                            + "Updated cycle start date and cycle end date from wallet bill cycle.");
        }
    }

    @SuppressWarnings("unchecked")
    public static void updateQuoteOutput(String loggingKey,
                                         String route,
                                         MtxResponseSubscription subscription,
                                         AdviceDataStage stage,
                                         long resultCode,
                                         String resultText,
                                         VisibleResponseQuoteAdviceService output)
            throws PaymentAdviceException, JsonParseException, JsonMappingException, IOException,
            IntegrationServiceException, javax.naming.ConfigurationException {
        output.setSubscriberExternalId(subscription.getExternalId());
        VisibleSubscriberExtension attr = (VisibleSubscriberExtension) subscription.getAttr();
        output.setBrand(attr.getBrand());
        if (StringUtils.isNotBlank(stage.getPayerExternalId())) {
            output.setPayerExternalId(stage.getPayerExternalId());
        }
        if (stage.getCycleStartTime() != null) {
            output.setCycleStartTime(stage.getCycleStartTime().toString());
        }
        if (stage.getCycleEndTime() != null) {
            output.setCycleEndTime(stage.getCycleEndTime().toString());
        }

        if (stage.getVisibleOfferDetailsMap() != null
                && stage.getVisibleOfferDetailsMap().values() != null) {
            for (VisibleOfferDetails vod : stage.getVisibleOfferDetailsMap().values()) {
                VisibleOfferDetails vod1 = new VisibleOfferDetails();
                vod1.setCatalogItemExternalId(vod.getCatalogItemExternalId());
                vod1.setOfferType(vod.getOfferType());
                vod1.setChargeAmount(vod.getChargeAmount());
                vod1.setAocAmount(vod.getAocAmount());
                vod1.setPayableAmount(vod.getPayableAmount());

                if (StringUtils.isNotBlank(vod.getResourceId())) {
                    vod1.setResourceId(vod.getResourceId());
                }

                if (StringUtils.isNotBlank(vod.getTaxDetails())) {
                    vod1.setTaxDetails(vod.getTaxDetails());
                }

                if (vod.getCredits() != null) {
                    vod.getCredits().forEach(creditRead -> {
                        vod1.appendCredits(creditRead);
                    });
                }

                if (StringUtils.isNotBlank(vod.getCycleStartTime())) {
                    vod1.setCycleStartTime(vod.getCycleStartTime());
                }

                if (StringUtils.isNotBlank(vod.getCycleEndTime())) {
                    vod1.setCycleEndTime(vod.getCycleEndTime());
                }

                output.appendVisibleOfferDetailsList(vod1);
            }
        }

        output.setAvailableMainBalanceAmount(stage.getAvailableMainBalanceAmount());
        output.setConsumableMainBalanceAmount(stage.getConsumableMainBalanceAmount());
        if (stage.getReservedMainBalanceAmount() != null
                && stage.getReservedMainBalanceAmount().signum() == 1) {
            output.setReservedMainBalanceAmount(stage.getReservedMainBalanceAmount());
            output.setAvailableMainBalanceAmount(
                    stage.getConsumableMainBalanceAmount().add(
                            stage.getReservedMainBalanceAmount()));
        }
        output.setEstimatedPayableAmount(stage.getRechargeAmount());
        output.setTotalEstimatedAmount(stage.getTotalEstimatedAmount());

        for (SubscriberGroup sg : CommonUtils.emptyIfNull(stage.getSubscriberGroupList())) {
            VisibleGroup vg = new VisibleGroup();
            vg.setGroupExternalId(sg.getGroupExternalId() + "");
            vg.setGroupName(sg.getGroupName());
            vg.setGroupTier(sg.getGroupTier());
            vg.setSubscriberMemberCount(sg.getSubscriberMemberCount());
            output.appendSubscriberGroups(vg);
        }

        VisibleSubscriberExtension subAttr = (VisibleSubscriberExtension) subscription.getAttr();

        // serviceTaxResponse is tax response when called from rest endpoint
        // But we also need this when called from purchase service.
        for (CreditStage creditStage : stage.getCreditMap().values()) {
            if (creditStage.getAvailableCredits().signum() <= 0) {
                continue;
            }
            VisibleCredits creditOutput = new VisibleCredits();
            creditOutput.setPromotionName(creditStage.getPromotionName());
            creditOutput.setApplicableCI(creditStage.getApplicableCiExternalId());
            creditOutput.setClassCode(creditStage.getClassCode());
            creditOutput.setAvailableCredits(creditStage.getAvailableCredits());
            creditOutput.setAvailableCreditsGrant(creditStage.getAvailableCreditsGrant());
            creditOutput.setAvailableCreditsConsumable(creditStage.getAvailableCreditsConsumable());
            if (!creditStage.isNoCap()) {
                creditOutput.setCreditCap(creditStage.getCreditCap());
            }
            creditOutput.setEstimatedTransferableCredits(
                    creditStage.getEstimatedTransferableCredits());
            creditOutput.setCreditRedeemableOfferCI(creditStage.getRedeemOfferCi());
            creditOutput.setDiscountCalculationMethod(creditStage.getDiscountCalculationMethod());
            creditOutput.setRedeemableGoodType(creditStage.getRedeemGoodType());
            if (StringUtils.isNotEmpty(creditStage.getCreditTaxDetails())) {
                creditOutput.setTaxDetails(creditStage.getCreditTaxDetails());
            } else if (creditStage.isPromotionTaxable()
                    && StringUtils.isNotBlank(AdviceUtils.getErrorResultText(stage))
                    && !(AdviceUtils.getErrorResultText(stage).equalsIgnoreCase(
                            MATRIXX_CONSTANTS.RESULT_TEXT_MTX_SUCCESS))) {
                creditOutput.setTaxDetails(AdviceUtils.getErrorResultText(stage));
            }

            creditOutput.setApplicableCI(creditStage.getApplicableCiExternalId());
            creditOutput.setRedeemableCredits(creditStage.getRedeemableCredits());
            creditOutput.setApplicableCreditsPercentage(creditStage.getApplicableGrantPercentage());
            output.getCreditsAppender().add(creditOutput);
        }

        if (stage.getPaidCycleStartDate() != null && !stage.isPaidCycleStartDateDefaulted()) {
            output.setPaidCycleStartDate(stage.getPaidCycleStartDate());
        } else if (stage.isPaidCycleStartDateDefaulted()) {
            output.setPaidCycleStartDate(
                    CommonUtils.getToday(stage.getCycleStartTime(), subscription.getTimeZone()));
        }
        output.setResultText(
                "SubscriberExternalID: " + subscription.getExternalId() + " "
                        + AdviceUtils.getErrorResultText(stage));
        output.setResult(resultCode);
    }

}
