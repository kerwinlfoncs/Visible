package com.matrixx.vag.advice.service;

import static com.matrixx.platform.LogUtils.INFO;
import static com.matrixx.platform.LogUtils.WARN;

import java.io.IOException;
import java.math.BigDecimal;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.matrixx.datacontainer.mdc.MtxBalanceInfoSimple;
import com.matrixx.datacontainer.mdc.MtxResponseWallet;
import com.matrixx.datacontainer.mdc.VisibleCredits;
import com.matrixx.datacontainer.mdc.VisibleGroup;
import com.matrixx.datacontainer.mdc.VisibleOfferDetails;
import com.matrixx.datacontainer.mdc.VisiblePurchaseInfo;
import com.matrixx.datacontainer.mdc.VisibleSubscriberDevice;
import com.matrixx.datacontainer.mdc.VisibleSubscriberExtension;
import com.matrixx.vag.advice.model.CreditStage;
import com.matrixx.vag.advice.model.SubscriberGroup;
import com.matrixx.vag.advice.model.VisibleOfferDetailsInternal;
import com.matrixx.vag.advice.model.VisibleResponsePurchaseAdvice;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.Constants.GENERIC_CONSTANTS;
import com.matrixx.vag.exception.IntegrationServiceException;
import com.matrixx.vag.exception.PaymentAdviceException;
import com.matrixx.vag.tax.model.ServiceTaxResponse;

public class PurchaseAdviceUtils {

    private static final Logger m_logger = LoggerFactory.getLogger(PurchaseAdviceUtils.class);

    public static void updateTaxesInServiceStage(String loggingKey,
                                                 String route,
                                                 AdviceDataStage stage) {
        final String methodKey = loggingKey + " updateTaxesInServiceStage: ";
        INFO(m_logger, methodKey + "update taxes for " + stage.getAdviceFor());
        stage.getPayNowMap().values().forEach(paynow -> {
            String taxResp = "";
            for (VisiblePurchaseInfo vpi : stage.getPurchaseRequest().getPurchaseInfo()) {
                if (vpi.getPurchaseServiceInfo().getServiceOfferExternalId().equalsIgnoreCase(
                        paynow.getCatalogItemExternalId())) {
                    if (StringUtils.isNotBlank(
                            vpi.getPurchaseServiceInfo().getServiceTaxDetails())) {
                        taxResp = vpi.getPurchaseServiceInfo().getServiceTaxDetails();
                        break;
                    }
                }
            }
            if (StringUtils.isNotBlank(taxResp)) {
                paynow.setTaxResponse(taxResp);
                try {
                    ServiceTaxResponse taxDetails = CommonUtils.getServiceTaxResponseFromJsonString(
                            taxResp);
                    paynow.setTaxFeeAmount(
                            taxDetails.getTransactionElement().get(0).getTotalFeeAmount());
                } catch (Exception ex) {
                    WARN(
                            m_logger,
                            methodKey + "Tax String supplied by purchase service is not parseable."
                                    + StringUtils.SPACE + ExceptionUtils.getStackTrace(ex));
                    paynow.setTaxResponse(GENERIC_CONSTANTS.ERROR_PREFIX + ex.getMessage());
                    stage.setServiceTaxApiErrorMessage(
                            "Tax String supplied by purchase service is not parseable."
                                    + StringUtils.SPACE + ex.getMessage());
                }
            }
        });
    }

    public static void updateDataFromWallet(String loggingKey,
                                            AdviceDataStage stage,
                                            MtxResponseWallet wallet) {
        final String methodKey = loggingKey + " updateDataFromWallet: ";
        stage.setAvailableMainBalanceAmount(BigDecimal.ZERO);

        if (wallet.getBalanceArray() != null) {
            wallet.getBalanceArray().forEach(bi -> {
                if (bi instanceof MtxBalanceInfoSimple) {
                    if (((MtxBalanceInfoSimple) bi).getIsMainBalance()) {
                        stage.setAvailableMainBalanceAmount(bi.getAmount().negate());
                    }
                }
            });
        }

        INFO(
                m_logger, loggingKey + methodKey + "Updated mainbalance amount from wallet: "
                        + stage.getAvailableMainBalanceAmount());

        if (wallet.getBillingCycle() != null) {
            stage.setCycleStartTime(wallet.getBillingCycle().getCurrentPeriodStartTime());
            stage.setCycleEndTime(wallet.getBillingCycle().getCurrentPeriodEndTime());
            INFO(
                    m_logger, loggingKey + methodKey
                            + "Updated cycle start date and cycle end date from wallet bill cycle.");
        }
    }

    public static void updatePurchaseAdviceOutput(String loggingKey,
                                                  String route,
                                                  AdviceDataStage stage,
                                                  VisibleResponsePurchaseAdvice output)
            throws PaymentAdviceException, JsonParseException, JsonMappingException, IOException,
            IntegrationServiceException {

        output.setSubscriberExternalId(stage.getSubscriptionExternalId());
        output.setResult(stage.getResultCode());
        output.setResultText(stage.getResultText());
        output.setAvailableMainBalanceAmount(stage.getAvailableMainBalanceAmount());
        output.setConsumableMainBalanceAmount(stage.getConsumableMainBalanceAmount());
        output.setEstimatedPayableAmount(stage.getRechargeAmount());
        output.setTotalEstimatedAmount(stage.getTotalEstimatedAmount());
        if (stage.getSubscriptionResponse() != null
                && stage.getSubscriptionResponse().getAttr() != null
                && stage.getSubscriptionResponse().getAttr() instanceof VisibleSubscriberExtension) {
            VisibleSubscriberExtension attr = (VisibleSubscriberExtension) stage.getSubscriptionResponse().getAttr();
            output.setBrand(attr.getBrand());
            output.setPaymentPreference(attr.getPaymentPreference());
            output.setTerminateDate(attr.getTerminateDate());
            output.setPayerExternalId(stage.getPayerExternalId());
        }

        if (stage.getNextCycleStartTime() != null) {
            output.setCycleStartTime(stage.getNextCycleStartTime().toString());
        }
        if (stage.getNextCycleEndTime() != null) {
            output.setCycleEndTime(stage.getNextCycleEndTime().toString());
        }

        for (VisibleOfferDetails vod : CommonUtils.emptyValuesIfNull(
                stage.getVisibleOfferDetailsMap())) {
            output.appendToVodList((VisibleOfferDetailsInternal) vod);
            output.appendVisibleOfferDetailsList(vod);
        }

        if (stage.getSubscriberGroupList() != null) {
            for (SubscriberGroup sg : stage.getSubscriberGroupList()) {
                VisibleGroup vg = new VisibleGroup();
                vg.setGroupExternalId(sg.getGroupExternalId());
                vg.setGroupName(sg.getGroupName());
                vg.setGroupTier(sg.getGroupTier());
                vg.setSubscriberMemberCount(sg.getSubscriberMemberCount());
                output.appendSubscriberGroups(vg);
                output.setPayerExternalId(
                        sg.getPayerForBeneficiary(stage.getSubscriptionExternalId()));
            }
        }

        for (CreditStage cs : stage.getCreditMap().values()) {
            if (cs.getAvailableCredits().signum() > 0) {
                VisibleCredits creditOutput = new VisibleCredits();
                creditOutput.setPromotionName(cs.getPromotionName());
                creditOutput.setClassCode(cs.getClassCode());
                creditOutput.setApplicableCI(cs.getApplicableCiExternalId());
                creditOutput.setEstimatedTransferableCredits(cs.getEstimatedTransferableCredits());

                if (!cs.getApplicableServiceStage().isSkipRenewal()) {
                    creditOutput.setAvailableCredits(cs.getAvailableCredits());
                    creditOutput.setAvailableCreditsGrant(cs.getAvailableCreditsGrant());
                    creditOutput.setAvailableCreditsConsumable(cs.getAvailableCreditsConsumable());
                    creditOutput.setCreditRedeemableOfferCI(cs.getRedeemOfferCi());
                    creditOutput.setDiscountCalculationMethod(cs.getDiscountCalculationMethod());
                    creditOutput.setRedeemableGoodType(cs.getRedeemGoodType());
                    creditOutput.setApplicableCreditsPercentage(cs.getApplicableGrantPercentage());
                    if (StringUtils.isNotBlank(cs.getCreditTaxDetails())) {
                        creditOutput.setTaxDetails(cs.getCreditTaxDetails());
                    } else if (cs.isPromotionTaxable()
                            && StringUtils.isNotBlank(AdviceUtils.getErrorResultText(stage))
                            && !(AdviceUtils.getErrorResultText(stage).equalsIgnoreCase("OK"))) {
                        creditOutput.setTaxDetails(AdviceUtils.getErrorResultText(stage));
                    }

                    if (!cs.isNoCap()) {
                        creditOutput.setCreditCap(cs.getCreditCap());
                    }
                    creditOutput.setRedeemableCredits(cs.getRedeemableCredits());
                }

                output.getCreditsAppender().add(creditOutput);
            }
        }

        for (VisibleSubscriberDevice vsd : stage.getSubscriberDeviceList()) {
            output.appendSubscriberDevices(vsd);
        }
        output.setResultText(
                "SubscriptionExternalID: " + stage.getSubscriptionExternalId() + " "
                        + AdviceUtils.getErrorResultText(stage));
    }

}
