package com.matrixx.vag.common.request.builder;

import java.math.BigDecimal;

import org.apache.commons.lang3.StringUtils;

import com.matrixx.datacontainer.mdc.MtxChargeMethodData;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberRecharge;
import com.matrixx.datacontainer.mdc.MtxSubscriberSearchData;
import com.matrixx.datacontainer.mdc.VisibleBraintreeChargeMethodExtension;
import com.matrixx.datacontainer.mdc.VisibleRechargeExtension;

public class MtxRequestSubscriberRechargeBuilder {

    String subscriberExternalId;
    String reason;
    String info;
    boolean payNow;
    BigDecimal amount;
    MtxChargeMethodData chargeMethodData;
    VisibleRechargeExtension attr;
    VisibleBraintreeChargeMethodExtension btExtension;

    public MtxRequestSubscriberRecharge build() {

        MtxRequestSubscriberRecharge recharge = new MtxRequestSubscriberRecharge();

        if (StringUtils.isNotBlank(subscriberExternalId)) {
            MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
            searchData.setExternalId(subscriberExternalId);
            recharge.setSubscriberSearchData(searchData);
        }
        
        recharge.setPayNow(payNow);

        if (StringUtils.isNotBlank(reason)) {
            recharge.setReason(reason);
        }

        if (StringUtils.isNotBlank(info)) {
            recharge.setInfo(info);
        }
        
        if (chargeMethodData != null) {
            recharge.setChargeMethodData(chargeMethodData);
        }

        if (amount != null) {
            recharge.setAmount(amount);
        }

        if (this.attr != null) {
            recharge.setRechargeAttr(attr);
        }

        if (this.btExtension != null) {
            MtxChargeMethodData cmd = new MtxChargeMethodData();
            cmd.setChargeMethodAttr(btExtension);
            recharge.setChargeMethodData(cmd);
        }

        return recharge;
    }

    public MtxRequestSubscriberRechargeBuilder withSubscriberExternalId(String subscriberExternalId) {
        if (StringUtils.isNotBlank(subscriberExternalId)) {
            this.subscriberExternalId = subscriberExternalId;
        }
        return this;
    }

    public MtxRequestSubscriberRechargeBuilder withReason(String reason) {
        if (StringUtils.isNotBlank(reason)) {
            this.reason = reason;
        }
        return this;
    }

    public MtxRequestSubscriberRechargeBuilder withInfo(String info) {
        if (StringUtils.isNotBlank(info)) {
            this.info = info;
        }
        return this;
    }
    
    public MtxRequestSubscriberRechargeBuilder withPayNow(boolean payNow) {
        this.payNow = payNow;
        return this;
    }

    public MtxRequestSubscriberRechargeBuilder withAmount(BigDecimal amount) {
        this.amount = amount;
        return this;
    }

    public MtxRequestSubscriberRechargeBuilder withChargeMethodData(MtxChargeMethodData chargeMethodData) {
        if (chargeMethodData != null) {
            this.chargeMethodData = chargeMethodData;
        }
        return this;
    }

    public MtxRequestSubscriberRechargeBuilder withAttr(VisibleRechargeExtension attr) {
        if (attr != null) {
            this.attr = attr;
        }
        return this;
    }

    public MtxRequestSubscriberRechargeBuilder withBTExtension(VisibleBraintreeChargeMethodExtension btExtension) {
        if (btExtension != null) {
            this.btExtension = btExtension;
        }
        return this;
    }
}
