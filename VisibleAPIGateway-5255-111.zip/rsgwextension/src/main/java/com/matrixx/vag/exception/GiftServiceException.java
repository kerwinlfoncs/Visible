package com.matrixx.vag.exception;

public class GiftServiceException extends IntegrationServiceException {

    private static final long serialVersionUID = 6691033100485720644L;

    public GiftServiceException(Long resultCode, String message) {
        super(resultCode, message);
    }
}
