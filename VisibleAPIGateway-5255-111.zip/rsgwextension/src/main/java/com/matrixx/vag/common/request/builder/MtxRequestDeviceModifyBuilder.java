package com.matrixx.vag.common.request.builder;

import com.matrixx.datacontainer.mdc.MtxDeviceSearchData;
import com.matrixx.datacontainer.mdc.MtxRequestDeviceModify;
import com.matrixx.vag.common.coverage.Generated;

@Generated
public class MtxRequestDeviceModifyBuilder {
	MtxDeviceSearchData searchData;
    public MtxRequestDeviceModify build() {
		if(searchData==null) {
			this.searchData = new MtxDeviceSearchData();	
		}
    	MtxRequestDeviceModify device = new MtxRequestDeviceModify();
    	device.setDeviceSearchData(searchData);
    	return device;
    }
}
