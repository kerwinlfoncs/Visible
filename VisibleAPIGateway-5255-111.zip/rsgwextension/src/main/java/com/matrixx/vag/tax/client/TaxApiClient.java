package com.matrixx.vag.tax.client;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.matrixx.datacontainer.mdc.MtxPricingMetadataInfo;
import com.matrixx.datacontainer.mdc.MtxResponsePricingCatalogItem;
import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.common.Constants.TAX_CONSTANTS;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.exception.TaxApiException;
import com.matrixx.vag.service.IntegrationService;
import com.matrixx.vag.tax.model.ServiceTaxRequest;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

import java.io.IOException;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;

import static com.matrixx.platform.LogUtils.DEBUG;
import static com.matrixx.platform.LogUtils.WARN;

@JsonIgnoreProperties(ignoreUnknown = true)
public class TaxApiClient {
	private static final Logger m_logger = LoggerFactory.getLogger(TaxApiClient.class);

    /**
     * Calls the TAX API to calculate the tax results.
     *
     * @param loggingKey
     * @param route
     * @param body
     * @return
     * @throws TaxApiException 
     * @throws IOException 
     * @throws Exception 
     */
    public static String getTaxApiResult(String loggingKey, String body) throws TaxApiException, IOException
            {
    	final String methodName = "getTaxApiResult: ";
        DEBUG(m_logger, loggingKey + methodName+ "Sending to TAXAPI\n" + body);
        final String URL_PATH = AppPropertyProvider.getInstance().getString(
                TAX_CONSTANTS.TAX_ON_SERVICES_API_ENDPOINT);
        URL url;
        HttpURLConnection con = null;

        OutputStream os = null;
        String retVal = "";
        int responseCode = 0;
        try {
            url = new URL(URL_PATH);
            con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            con.setRequestProperty("Accept", "application/json");
            if (body != null) {
                con.setDoOutput(true);
                os = con.getOutputStream();
                os.write(body.getBytes());
            }

            responseCode = con.getResponseCode();
            retVal = CommonUtils.readResponse(con.getInputStream());
            DEBUG(m_logger, loggingKey + methodName+ "Received from TAXAPI\n" + retVal);
        } catch (MalformedURLException e) {
            WARN(m_logger, ExceptionUtils.getStackTrace(e));
            throw new TaxApiException(
                    RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,
                    URL_PATH + " is malformed. Refer to configuration property "
                            + TAX_CONSTANTS.TAX_ON_SERVICES_API_ENDPOINT);
        } catch (IOException e) {

            // @formatter:off

            StringBuilder errorMessage = new StringBuilder();
            if(responseCode >= HttpStatus.BAD_REQUEST.value()) { // Should really distinguish between infrastructure and business (eg. bad requests 4xx)
                errorMessage.append("TAX API returned HttpStatus ").append(responseCode)
                            .append(" (").append(HttpStatus.valueOf(responseCode).getReasonPhrase()).append("). Error response payload: ")
                            .append(CommonUtils.getHttpErrorMessage(con));
            }
            else {
                errorMessage.append("Failed to read response from TAX API. responseCode: ")
                            .append(responseCode).append(". IOException: ").append(e.getMessage());
            }

            // @formatter:on
            WARN(m_logger, loggingKey+ methodName+ errorMessage.toString());
            WARN(m_logger, loggingKey+ methodName+ ExceptionUtils.getStackTrace(e));
            throw e;

        } finally {
            try {
                if (con != null) {
                    if (os != null) {
                        os.close();
                    }
                    con.disconnect();
                }
            } catch (Exception ex) {
                // Do nothing - we tried...
            	WARN(m_logger, loggingKey+ methodName+ ExceptionUtils.getStackTrace(ex));
            }
        }

        if(StringUtils.isBlank(retVal)) {
        	WARN(m_logger, loggingKey+ methodName+ "Did not get response from Tax Api");
        	throw new TaxApiException(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, "Did not get response from Tax Api");
        }
        return retVal;
    }

    /**
     * Call tax api and get tax string for purchase api calls
     *
     * @param subscriber
     * @param discountPrice
     * @param grossPrice
     * @param offer606RevAdjDailyRecog
     * @param ciExternalId
     * @param goodType
     * @param serviceType
     * @param loggingKey
     * @param route
     * @return
     * @throws TaxApiException 
     * @throws Exception 
     */
    public static String getServiceTaxDetails(MtxResponseSubscription subscriber,
                                              MtxResponsePricingCatalogItem pricingNewCIService,
                                              MtxResponsePricingCatalogItem pricingNewCIInsurance,
                                              BigDecimal discountPrice,
                                              BigDecimal grossPrice,
                                              BigDecimal offer606RevAdjDailyRecog,
                                              String ciExternalId,
                                              String goodType,
                                              String serviceType,
                                              String loggingKey,
                                              String route) throws TaxApiException, IOException {
    	final String methodName = "getServiceTaxDetails: ";
        String taxApiResult = "";
        ServiceTaxRequest taxApiRequest = null;
        String taxTemplateService = "";
        String taxTemplateInsurnace = "";

        //Tax template Service and Insurance
        if (serviceType.equals(IntegrationService.SERVICE_TYPE_SERVICE)) {
            if (pricingNewCIService != null && pricingNewCIService.getCatalogItemInfo() != null && pricingNewCIService.getCatalogItemInfo().getMetadataList() != null) {
                for (MtxPricingMetadataInfo pmi : pricingNewCIService.getCatalogItemInfo().getMetadataList()) {
                    taxTemplateService = pmi.getValue();
                }
                if (StringUtils.isNotBlank(taxTemplateService)) {
                    taxApiRequest = CommonUtils.getServiceTaxRequestFromJsonString(taxTemplateService);
                }
                else {
                    WARN(m_logger, loggingKey + methodName + StringUtils.SPACE
                            + "TaxDetails are not available");
                    return null;
                }
            }
        } else if (serviceType.equals(IntegrationService.SERVICE_TYPE_INSURANCE)) {
            if (pricingNewCIInsurance != null && pricingNewCIInsurance.getCatalogItemInfo() != null && pricingNewCIInsurance.getCatalogItemInfo().getMetadataList() != null) {
                for (MtxPricingMetadataInfo pmi : pricingNewCIInsurance.getCatalogItemInfo().getMetadataList()) {
                    taxTemplateInsurnace = pmi.getValue();
                }
                if (StringUtils.isNotBlank(taxTemplateInsurnace)) {
                    taxApiRequest = CommonUtils.getServiceTaxRequestFromJsonString(taxTemplateInsurnace);
                }
                else {
                    WARN(m_logger, loggingKey + methodName + StringUtils.SPACE
                            + "TaxDetails are not available");
                    return null;
                }
            }
        } else {
            WARN(m_logger, loggingKey + methodName + "Error while calculating tax for - " + ciExternalId + " Good Type - " + goodType
                    + ".  Unknown service type " + serviceType);
            throw new TaxApiException(
                    RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,
                    "Error while calculating tax for - " + ciExternalId + " Good Type - " + goodType
                            + ".  Unknown service type " + serviceType);
        }

        // Get geocode from subscriber data
        String geoCode = CommonUtils.getSubscriberGeoCode(subscriber);
        if (geoCode != null) {
            taxApiRequest.setGeocode(geoCode);
        }
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date currentDate = new Date();
        dateFormat.format(currentDate);

        taxApiRequest.setGlDate(dateFormat.format(currentDate));
        taxApiRequest.setDiscountPrice(discountPrice);
        taxApiRequest.setGrossPrice(grossPrice);
        if (offer606RevAdjDailyRecog != null) {
            taxApiRequest.setOffer606RevAdjDailyRecog(offer606RevAdjDailyRecog);
        }
        // Call Tax API
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            taxApiResult = getTaxApiResult(
                    loggingKey, objectMapper.writeValueAsString(taxApiRequest));
        } catch (IOException e) {
        	WARN(m_logger, loggingKey+ methodName+"Error while calculating tax for - " + ciExternalId + " Good Type - " + goodType
                    + ". Tax engine returned error." + StringUtils.LF+ ExceptionUtils.getStackTrace(e));

            throw new TaxApiException(
            		RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,
                    "Error while calculating tax for - " + ciExternalId + " Good Type - " + goodType
                            + ". Tax engine returned error.");
        }
        if(StringUtils.isBlank(taxApiResult)) {
        	WARN(m_logger, loggingKey+ methodName+ "Did not get response from Tax Api");
            throw new TaxApiException(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,"Did not get response from Tax Api");
        }
        return taxApiResult;
    }
}