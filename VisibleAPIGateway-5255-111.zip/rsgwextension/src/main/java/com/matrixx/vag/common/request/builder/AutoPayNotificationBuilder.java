package com.matrixx.vag.common.request.builder;

import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.matrixx.datacontainer.MtxObjectId;
import com.matrixx.vag.common.Constants.NOTIFICATION_CONSTANTS;
import com.matrixx.vag.config.AppPropertyProvider;

public class AutoPayNotificationBuilder {

    String contactEmail;
    String containerName;
    String cycleLength;
    String expirationNotificationOffsetType;
    String notificationStatus;
    String objectExternalId;
    String payerExternalId;
    String paymentMethodName;
    String payerPaymentMethodName;
    String paymentPreference;

    boolean addPayerDetails = false;
    long beforeCycleEnd;
    long expirationNotificationOffset;
    long notificationType;
    long objectType;

    BigDecimal amount;

    ZonedDateTime expirationTime;
    ZonedDateTime notifTime;

    MtxObjectId objectId;
    List<String> offerList = new ArrayList<String>();

    public String build() {
        JsonObject jobj = new JsonObject();

        jobj.addProperty(
                AppPropertyProvider.getInstance().getString(
                        NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_OBJECT_TYPE_KEY),
                this.objectType);

        if (objectId != null) {
            jobj.addProperty(NOTIFICATION_CONSTANTS.OBJECT_ID_KEY, this.objectId.toString());
        }

        if (StringUtils.isNotBlank(this.objectExternalId)) {
            jobj.addProperty(
                    AppPropertyProvider.getInstance().getString(
                            NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_OBJECT_EXTERNAL_ID_KEY),
                    this.objectExternalId);
        }

        if (StringUtils.isNotBlank(this.paymentMethodName)) {
            jobj.addProperty(
                    AppPropertyProvider.getInstance().getString(
                            NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_PAYMENT_METHOD_NAME_KEY),
                    this.paymentMethodName);
        }

        if (this.amount != null) {
            jobj.addProperty(NOTIFICATION_CONSTANTS.AMOUNT_KEY, this.amount.toPlainString());
        }

        jobj.addProperty(
                AppPropertyProvider.getInstance().getString(
                        NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_STATUS_KEY),
                this.notificationStatus);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSSSSSSZ");
        if (objectId != null && notifTime != null) {
            String notificationId = objectId + "|" + notifTime.format(formatter);
            jobj.addProperty(
                    AppPropertyProvider.getInstance().getString(
                            NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_NOTIFICATION_ID_KEY),
                    notificationId);
        } else if (objectId != null) {
            String notificationId = objectId + "|" + ZonedDateTime.now().format(formatter);
            jobj.addProperty(
                    AppPropertyProvider.getInstance().getString(
                            NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_NOTIFICATION_ID_KEY),
                    notificationId);
        } else {
            String notificationId = ZonedDateTime.now().format(formatter);
            jobj.addProperty(
                    AppPropertyProvider.getInstance().getString(
                            NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_NOTIFICATION_ID_KEY),
                    notificationId);
        }

        jobj.addProperty(
                AppPropertyProvider.getInstance().getString(
                        NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_NOTIFICATION_TYPE_KEY),
                this.notificationType);

        if (StringUtils.isNotBlank(this.paymentPreference)) {
            jobj.addProperty(
                    AppPropertyProvider.getInstance().getString(
                            NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_PAYMENT_PREFERENCE_KEY),
                    this.paymentPreference);
        }

        if (StringUtils.isNotBlank(this.contactEmail)) {
            jobj.addProperty(NOTIFICATION_CONSTANTS.CONTACT_EMAIL_KEY, this.contactEmail);
        }

        if (StringUtils.isNotBlank(this.cycleLength)) {
            jobj.addProperty(NOTIFICATION_CONSTANTS.CYCLE_LENGTH, this.cycleLength);
        }

        jobj.addProperty(NOTIFICATION_CONSTANTS.BEFORE_CYCLE_END, this.beforeCycleEnd);

        jobj.addProperty(
                NOTIFICATION_CONSTANTS.NOTIFICATION_EXPIRATION_OFFSET_KEY,
                this.expirationNotificationOffset);

        if (StringUtils.isNotBlank(this.expirationNotificationOffsetType)) {
            jobj.addProperty(
                    NOTIFICATION_CONSTANTS.NOTIFICATION_EXPIRATION_OFFSET_TYPE_KEY,
                    this.expirationNotificationOffsetType);
        }

        if (this.expirationTime != null) {
            jobj.addProperty(
                    NOTIFICATION_CONSTANTS.EXPIRATION_TIME_KEY,
                    this.expirationTime.toOffsetDateTime().toString());
        }

        if (StringUtils.isNotBlank(this.containerName)) {
            jobj.addProperty(
                    AppPropertyProvider.getInstance().getString(
                            NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_NOTIFICATION_NAME_KEY),
                    this.containerName);
        }

        if (!offerList.isEmpty()) {
            JsonArray offerArray = new JsonArray();
            offerList.forEach(ciExId -> {
                offerArray.add(ciExId);
            });
            jobj.add(NOTIFICATION_CONSTANTS.OFFER_LIST_KEY, offerArray);
        }
        if (addPayerDetails) {
            JsonObject payerObj = new JsonObject();
            payerObj.addProperty(
                    AppPropertyProvider.getInstance().getString(
                            NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_NOTIFICATION_NAME_KEY),
                    NOTIFICATION_CONSTANTS.PAYER_CONTAINER_NAME);

            if (StringUtils.isNotBlank(this.payerExternalId)) {
                payerObj.addProperty(
                        NOTIFICATION_CONSTANTS.PAYER_EXTERNAL_ID_KEY, this.payerExternalId);
            }
            if (StringUtils.isNotBlank(this.payerPaymentMethodName)) {
                payerObj.addProperty(
                        AppPropertyProvider.getInstance().getString(
                                NOTIFICATION_CONSTANTS.NOTIFICATION_PROPERTY_NOTIFICATION_PAYMENT_METHOD_NAME_KEY),
                        this.payerPaymentMethodName);
            }

            jobj.add(NOTIFICATION_CONSTANTS.PAYER_KEY, payerObj);
        }
        return jobj.toString();
    }

    public AutoPayNotificationBuilder withObjectType(long objectType) {
        this.objectType = objectType;
        return this;
    }

    public AutoPayNotificationBuilder withObjectId(MtxObjectId mtxObjectId) {
        if (mtxObjectId != null) {
            this.objectId = mtxObjectId;
        }
        return this;
    }

    public AutoPayNotificationBuilder withObjectExternalId(String objectExternalId) {
        if (StringUtils.isNotBlank(objectExternalId)) {
            this.objectExternalId = objectExternalId;
        }
        return this;
    }

    public AutoPayNotificationBuilder withPayerExternalId(String payerExternalId) {
        if (StringUtils.isNotBlank(payerExternalId)) {
            this.payerExternalId = payerExternalId;
            addPayerDetails = true;
        }
        return this;
    }

    public AutoPayNotificationBuilder withPaymentMethodName(String paymentMethodName) {
        if (StringUtils.isNotBlank(paymentMethodName)) {
            this.paymentMethodName = paymentMethodName;
        }
        return this;
    }

    public AutoPayNotificationBuilder withPayerPaymentMethodName(String payerPaymentMethodName) {
        if (StringUtils.isNotBlank(payerPaymentMethodName)) {
            this.payerPaymentMethodName = payerPaymentMethodName;
            addPayerDetails = true;
        }
        return this;
    }

    public AutoPayNotificationBuilder withAmount(BigDecimal amount) {
        if (amount != null) {
            this.amount = amount;
        }
        return this;
    }

    public AutoPayNotificationBuilder withStatus(String status) {
        if (StringUtils.isNotBlank(status)) {
            this.notificationStatus = status;
        }
        return this;
    }

    public AutoPayNotificationBuilder withNotificationType(long notificationType) {
        this.notificationType = notificationType;
        return this;
    }

    public AutoPayNotificationBuilder withPaymentPreference(String paymentPreference) {
        if (StringUtils.isNotBlank(paymentPreference)) {
            this.paymentPreference = paymentPreference;
        }
        return this;
    }

    public AutoPayNotificationBuilder withContactEmail(String contactEmail) {
        if (StringUtils.isNotBlank(contactEmail)) {
            this.contactEmail = contactEmail;
        }
        return this;
    }

    public AutoPayNotificationBuilder withBeforeCycleEnd(long beforeCycleEnd) {
        this.beforeCycleEnd = beforeCycleEnd;
        return this;
    }

    public AutoPayNotificationBuilder withExpirationNotificationOffset(long expirationNotificationOffset) {
        this.expirationNotificationOffset = expirationNotificationOffset;
        return this;
    }

    public AutoPayNotificationBuilder withExpirationNotificationOffsetType(String expirationNotificationOffsetType) {
        if (StringUtils.isNotBlank(expirationNotificationOffsetType)) {
            this.expirationNotificationOffsetType = expirationNotificationOffsetType;
        }
        return this;
    }

    public AutoPayNotificationBuilder withExpirationTime(ZonedDateTime expirationTime) {
        if (expirationTime != null) {
            this.expirationTime = expirationTime;
        }
        return this;
    }

    public AutoPayNotificationBuilder withNotifTime(ZonedDateTime notifTime) {
        if (notifTime != null) {
            this.notifTime = notifTime;
        }
        return this;
    }

    public AutoPayNotificationBuilder withContainerName(String containerName) {
        if (StringUtils.isNotBlank(containerName)) {
            this.containerName = containerName;
        }
        return this;
    }

    public AutoPayNotificationBuilder withOffer(String catalogItemExternalId) {
        if (StringUtils.isNotBlank(catalogItemExternalId)) {
            offerList.add(catalogItemExternalId);
        }
        return this;
    }

    public AutoPayNotificationBuilder withCycleLength(String cycleLength) {
        if (StringUtils.isNotBlank(cycleLength)) {
            this.cycleLength = cycleLength;
        }
        return this;
    }

}
