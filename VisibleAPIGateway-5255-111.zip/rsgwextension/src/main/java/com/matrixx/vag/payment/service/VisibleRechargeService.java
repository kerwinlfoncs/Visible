package com.matrixx.vag.payment.service;

import static com.matrixx.platform.LogUtils.INFO;

import java.lang.reflect.InvocationTargetException;
import java.util.AbstractMap.SimpleEntry;
import java.util.ArrayList;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;

import com.matrixx.datacontainer.DataContainer;
import com.matrixx.datacontainer.DataContainerFactory;
import com.matrixx.datacontainer.MtxObjectId;
import com.matrixx.datacontainer.MtxPhone;
import com.matrixx.datacontainer.mdc.BalanceInfo;
import com.matrixx.datacontainer.mdc.MtxPurchasedOfferData;
import com.matrixx.datacontainer.mdc.MtxRequestMulti;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberPurchaseOffer;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberRecharge;
import com.matrixx.datacontainer.mdc.MtxRequestSubscriberTransferBalance;
import com.matrixx.datacontainer.mdc.MtxResponseDevice;
import com.matrixx.datacontainer.mdc.MtxResponseMulti;
import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import com.matrixx.datacontainer.mdc.MtxResponseUser;
import com.matrixx.datacontainer.mdc.MtxSubscriberSearchData;
import com.matrixx.datacontainer.mdc.SubscriptionResponse;
import com.matrixx.datacontainer.mdc.VisibleApiEventData;
import com.matrixx.datacontainer.mdc.VisibleRechargeExtension;
import com.matrixx.datacontainer.mdc.VisibleRequestRecharge;
import com.matrixx.datacontainer.mdc.VisibleResponseRecharge;
import com.matrixx.datacontainer.mdc.VisibleRiskData;
import com.matrixx.platform.JsonObject;
import com.matrixx.platform.MatrixxContext;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.Constants.DEVICE_CONSTANTS;
import com.matrixx.vag.common.Constants.LOG_MESSAGES;
import com.matrixx.vag.common.Constants.MATRIXX_CONSTANTS;
import com.matrixx.vag.common.Constants.OFFER_CONSTANTS;
import com.matrixx.vag.common.Constants.PAYMENT_CONSTANTS;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.common.coverage.Generated;
import com.matrixx.vag.common.request.builder.MtxPurchasedOfferDataBuilder;
import com.matrixx.vag.common.request.builder.MtxRequestSubscriberPurchaseOfferBuilder;
import com.matrixx.vag.common.request.builder.MtxRequestSubscriberTransferBalanceBuilder;
import com.matrixx.vag.common.request.builder.VisibleApiEventDataBuilder;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.exception.IntegrationServiceException;
import com.matrixx.vag.exception.InvalidRequestException;
import com.matrixx.vag.exception.MtxResponseException;
import com.matrixx.vag.exception.VisibleRechargeException;
import com.matrixx.vag.service.IntegrationService;

@Configuration
public class VisibleRechargeService extends IntegrationService {

    private static final Logger m_logger = LoggerFactory.getLogger(VisibleRechargeService.class);

    public VisibleRechargeService() {
    }

    @Generated()
    VisibleRechargeService getService() {
        return new VisibleRechargeService();
    }

    @SuppressWarnings("unchecked")
    public void recharge(VisibleRequestRecharge request, VisibleResponseRecharge response)
            throws IntegrationServiceException, NoSuchMethodException, SecurityException,
            InstantiationException, IllegalAccessException, IllegalArgumentException,
            InvocationTargetException, MtxResponseException {

        String route = getRoute(MatrixxContext.getRequest());
        INFO(m_logger, " Visible Recharge Request: " + request.toJson());
        MtxSubscriberSearchData benSearchData = request.getSubscriberSearchData();
        String loggingKey = StringUtils.isNotBlank(benSearchData.getExternalId())
                ? getLoggingKey(benSearchData.getExternalId())
                : getLoggingKey(benSearchData.getObjectId().toString());
        final String methodKey = loggingKey + " recharge: ";

        try {
            RequestValidator.validateRequest(loggingKey, request);
        } catch (InvalidRequestException e) {
            response.setResult(e.getResultCode());
            response.setResultText(e.getMessage());
            throw e;
        }

        String payerExternalId = request.getPayerExternalId();
        String purchaseServiceType = request.getPurchaseServiceType();

        VisibleRechargeExtension requestRechargeAttr = (VisibleRechargeExtension) request.getRechargeAttr();

        MtxRequestMulti multiRequest = new MtxRequestMulti();

        MtxResponseUser benUser;
        if (StringUtils.isNotBlank(benSearchData.getExternalId())) {
            benUser = queryUserBySubscriptionExternalId(loggingKey, benSearchData.getExternalId());
        } else {
            benUser = queryUserBySubscriptionObjectId(loggingKey, benSearchData.getObjectId());
        }
        CommonUtils.validateMtxResponse(loggingKey, "User(Beneficiary) not found.", benUser);
        
        SubscriptionResponse benSubsRes;
        if (StringUtils.isNotBlank(benSearchData.getExternalId())) {
            benSubsRes = querySubscriptionByExternalId(
                    loggingKey, route, benSearchData.getExternalId());
        } else {
            benSubsRes = querySubscriptionByObjectId(
                    loggingKey, route, benSearchData.getObjectId().toString());
        }
        CommonUtils.validateMtxResponse(loggingKey, "subscription(Beneficiary) not found.", benSubsRes);

        MtxResponseUser payUser = null;
        SubscriptionResponse paySubsRes = null;
        if (StringUtils.isNotBlank(payerExternalId)) {
            payUser = queryUserBySubscriptionExternalId(
                    loggingKey, payerExternalId);
            CommonUtils.validateMtxResponse(loggingKey, "User(Payer) not found.", payUser);
            
            paySubsRes = querySubscriptionByExternalId(
                    loggingKey, route, payerExternalId);
            CommonUtils.validateMtxResponse(loggingKey, "Subscription(Payer) not found.", paySubsRes);
        }
        
        Long benResourceId = null;
        for (BalanceInfo bi : CommonUtils.emptyIfNull(benSubsRes.getWalletBalances())) {
            if (bi.getIsMainBalance()) {
                benResourceId = bi.getResourceId();
                break;
            }
        }

        if (benResourceId == null) {
            response.setResult(RESULT_CODES.HTTP_CONFLICT);
            response.setResultText(LOG_MESSAGES.BENEFICIARY_HAS_NO_MAINBALANCE);
            throw new VisibleRechargeException(
                    RESULT_CODES.HTTP_CONFLICT, LOG_MESSAGES.BENEFICIARY_HAS_NO_MAINBALANCE);
        }

        String aedOrderId = null;
        VisibleApiEventData requestApiEventData = null;
        if (request.getApiEventData() != null
                && (request.getApiEventData() instanceof VisibleApiEventData)) {
            requestApiEventData = (VisibleApiEventData) request.getApiEventData();
            aedOrderId = requestApiEventData.getOrderId();
        }

        String orderId = StringUtils.isNotBlank(aedOrderId)
                ? aedOrderId : requestRechargeAttr.getOrderId();

        if (StringUtils.isBlank(requestRechargeAttr.getOrderId())) {
            requestRechargeAttr.setOrderId(orderId);
        }
        if (StringUtils.isBlank(requestRechargeAttr.getServiceMDN())) {
            String benMDN = getServiceMDN(loggingKey, route, benSubsRes);
            requestRechargeAttr.setServiceMDN(benMDN);
        }
        if (StringUtils.isBlank(requestRechargeAttr.getBeneficiaryFirstName())) {
            requestRechargeAttr.setBeneficiaryFirstName(benUser.getFirstName());
        }
        if (StringUtils.isBlank(requestRechargeAttr.getBeneficiaryLastName())) {
            requestRechargeAttr.setBeneficiaryLastName(benUser.getLastName());
        }
        if (StringUtils.isBlank(requestRechargeAttr.getBeneficiaryExternalId())) {
            requestRechargeAttr.setBeneficiaryExternalId(benSubsRes.getExternalId());
        }
        
        if (paySubsRes!=null) {           
            Long payResourceId = null;
            for (BalanceInfo bi : CommonUtils.emptyIfNull(paySubsRes.getWalletBalances())) {
                if (bi.getIsMainBalance()) {
                    payResourceId = bi.getResourceId();
                    break;
                }
            }
            if (payResourceId == null) {
                response.setResult(RESULT_CODES.HTTP_CONFLICT);
                String msg = LOG_MESSAGES.PAYER_HAS_NO_MAINBALANCE + " PayerExternalId: "
                        + request.getPayerExternalId();
                response.setResultText(msg);
                throw new VisibleRechargeException(RESULT_CODES.HTTP_CONFLICT, msg);
            }

            if (StringUtils.isBlank(requestRechargeAttr.getPayerMDN())) {
                String payerMDN = getServiceMDN(loggingKey, route, paySubsRes);
                requestRechargeAttr.setPayerMDN(payerMDN);
            }
            if (StringUtils.isBlank(requestRechargeAttr.getPayerFirstName())) {
                requestRechargeAttr.setPayerFirstName(payUser.getFirstName());
            }
            if (StringUtils.isBlank(requestRechargeAttr.getPayerLastName())) {
                requestRechargeAttr.setPayerLastName(payUser.getLastName());
            }
            MtxRequestSubscriberRecharge mtxRechargeRequest = getMtxRequestSubscriberRecharge(
                    loggingKey, request);
            multiRequest.getRequestListAppender().add(mtxRechargeRequest);

            addTransferBalanceRequest(
                    loggingKey, request, multiRequest, benResourceId, payResourceId);

            response.setPayerExternalId(request.getPayerExternalId());
        } else {
            MtxRequestSubscriberRecharge mtxRechargeRequest = getMtxRequestSubscriberRecharge(
                    loggingKey, request);
            multiRequest.getRequestListAppender().add(mtxRechargeRequest);
        }

        if (StringUtils.isBlank(purchaseServiceType)
                || PAYMENT_CONSTANTS.PURCHASE_SERVICE_TYPE_RENEWAL.equalsIgnoreCase(
                        purchaseServiceType)) {
            CommonUtils.doNothing();
        } else if (StringUtils.isNotBlank(payerExternalId)) {
            String propCsv = AppPropertyProvider.getInstance().getString(
                    PAYMENT_CONSTANTS.PURCHASE_SERVICE_TYPE_FOR_PBLINK_CSV_LIST);
            if (StringUtils.isBlank(propCsv)) {
                INFO(
                        m_logger,
                        methodKey + "Missing property "
                                + PAYMENT_CONSTANTS.PURCHASE_SERVICE_TYPE_FOR_PBLINK_CSV_LIST
                                + " PBLINK offer will be purchased.");
                addPurchaseOfferRequest(
                        loggingKey, request, response, multiRequest, benSubsRes, orderId);
            } else if (!propCsv.contains(purchaseServiceType)) {
                CommonUtils.doNothing();
            } else if (CommonUtils.csvContainsIgnoreCase(propCsv, purchaseServiceType)) {
                addPurchaseOfferRequest(
                        loggingKey, request, response, multiRequest, benSubsRes, orderId);
            }
        }

        // Create api eventdata
        // @formatter:off
        VisibleApiEventDataBuilder aedBuilder = (new VisibleApiEventDataBuilder())
                .withExistingApiEventData(requestApiEventData)
                .withOrderId(orderId);
        // @formatter:on
        VisibleApiEventData aed = aedBuilder.build();

        multiRequest.setApiEventData(aed);
        MtxResponseMulti multiResponse = multiRequest(loggingKey, route, multiRequest);
        if (multiResponse != null && multiResponse.getResponseList() != null) {
            VisibleRiskData vrd = getRiskData(multiResponse.getResponseList(), 0);
            response.setRiskData(vrd);
        }
        response.setResult(multiResponse.getResult());
        setResponseMessage(response, multiResponse.getResultText());
        response.setSubscriptionExternalId(benSearchData.getExternalId());
        if (multiResponse != null && RESULT_CODES.MTX_SUCCESS == multiResponse.getResult()) {
            response.setRechargeAmount(request.getAmount());
            if (StringUtils.isNotBlank(payerExternalId)) {
                response.setTransferedAmount(request.getAmount());
            }
        }

        INFO(
                m_logger, methodKey + "result -  : " + response.getResult() + " result text -  : "
                        + response.getResultText());
    }

    private void setResponseMessage(VisibleResponseRecharge response, String message) {
        if (StringUtils.isNotBlank(response.getResultText())) {
            response.setResultText(message + "|" + response.getResultText());
        } else {
            response.setResultText(message);
        }
    }

    private void addPurchaseOfferRequest(String loggingKey,
                                         VisibleRequestRecharge request,
                                         VisibleResponseRecharge response,
                                         MtxRequestMulti multiRequest,
                                         SubscriptionResponse benSubsRes,
                                         String orderId) {
        final String methodKey = loggingKey + " addPurchaseOfferRequest: ";
        if (StringUtils.isBlank(
                AppPropertyProvider.getInstance().getString(
                        OFFER_CONSTANTS.CI_EXTERNAL_ID_PBLINK))) {
            setResponseMessage(response, "PBLINK offer not purchased.");
            INFO(
                    m_logger, methodKey + "PBLINK offer not purchased due to missing property : "
                            + OFFER_CONSTANTS.CI_EXTERNAL_ID_PBLINK);
            return;
        }
        MtxPurchasedOfferDataBuilder dataBuilder = (new MtxPurchasedOfferDataBuilder()).withOfferExternalId(
                AppPropertyProvider.getInstance().getString(
                        OFFER_CONSTANTS.CI_EXTERNAL_ID_PBLINK)).withOrderId(orderId).withBeneficiaryExternalId(
                                benSubsRes.getExternalId());
        MtxPurchasedOfferData offerData = dataBuilder.build();
        MtxRequestSubscriberPurchaseOfferBuilder offerBuilder = (new MtxRequestSubscriberPurchaseOfferBuilder()).withSubscriberExternalId(
                request.getPayerExternalId()).withOfferData(offerData);
        MtxRequestSubscriberPurchaseOffer requestPO = offerBuilder.build();
        INFO(
                m_logger, methodKey + "Adding to multirequest," + offerData.getExternalId()
                        + " purchase request: " + requestPO.toJson());
        CommonUtils.addRequestToMulti(multiRequest, requestPO);
    }

    private void addTransferBalanceRequest(String loggingKey,
                                           VisibleRequestRecharge request,
                                           MtxRequestMulti multiRequest,
                                           long benResourceId,
                                           long payResourceId) {
        final String methodKey = loggingKey + " addTransferBalanceRequest: ";
        INFO(m_logger, methodKey);
        // Transfer Balance Request

        MtxSubscriberSearchData paySearchData = new MtxSubscriberSearchData();
        paySearchData.setExternalId(request.getPayerExternalId());

        // @formatter:off
        MtxRequestSubscriberTransferBalanceBuilder stbb = (new MtxRequestSubscriberTransferBalanceBuilder())
                .withSubscriberSearchData(paySearchData)
                .withTargetSubscriberSearchData(request.getSubscriberSearchData())
                .withResourceId(payResourceId)
                .withTargetResourceId(benResourceId)
                .withGiftAmount(request.getAmount())
                .withReason(request.getReason());
       // @formatter:on

        MtxRequestSubscriberTransferBalance stb = stbb.build();
        CommonUtils.addRequestToMulti(multiRequest, stb);
    }

    private MtxRequestSubscriberRecharge getMtxRequestSubscriberRecharge(String loggingKey,
                                                                         VisibleRequestRecharge request) {
        final String methodKey = loggingKey + " getMtxRequestSubscriberRecharge: ";
        INFO(m_logger, methodKey);
        MtxSubscriberSearchData newSearch = null;
        if (StringUtils.isNotBlank(request.getPayerExternalId())) {
            newSearch = new MtxSubscriberSearchData();
            newSearch.setExternalId(request.getPayerExternalId());
        }
        JsonObject jo = new JsonObject();
        request.toJson(jo);
        jo.remove(PAYMENT_CONSTANTS.PAYER_EXTERNAL_ID_FIELD_NAME);
        jo.remove(PAYMENT_CONSTANTS.PURCHASE_SERVICE_TYPE_FIELD_NAME);
        jo.remove(PAYMENT_CONSTANTS.API_EVENT_DATA_FIELD_NAME);
        jo.attribute(
                MATRIXX_CONSTANTS.CONTAINER_FIELD_NAME,
                MtxRequestSubscriberRecharge.class.getSimpleName());
        DataContainerFactory dcf = DataContainerFactory.getInstance();
        DataContainer dc = new DataContainer(dcf);
        dc.readFrom(jo);
        MtxRequestSubscriberRecharge retVal = new MtxRequestSubscriberRecharge(dc);
        if (newSearch != null) {
            retVal.setSubscriberSearchData(newSearch);
        }
        return retVal;
    }

    private String getServiceMDN(String loggingKey,
                                 String route,
                                 MtxResponseSubscription subscription) {
        String methodKey = loggingKey + " getServiceMDN: ";
        INFO(m_logger, methodKey);
        ArrayList<MtxObjectId> deviceArrayId = subscription.getDeviceIdArray();
        for (MtxObjectId deviceId : CommonUtils.emptyIfNull(deviceArrayId)) {
            MtxResponseDevice device = queryDeviceData(loggingKey, route, deviceId);
            SimpleEntry<String, MtxPhone> mdnPair = CommonUtils.getMDN(loggingKey, device);
            if (mdnPair != null && mdnPair.getValue() != null
                    && DEVICE_CONSTANTS.DEVICE_TYPE_SERVICE.equalsIgnoreCase(mdnPair.getKey())) {
                INFO(m_logger, methodKey + mdnPair);

                return mdnPair.getValue().toString();
            }
        }
        return null;
    }
}
