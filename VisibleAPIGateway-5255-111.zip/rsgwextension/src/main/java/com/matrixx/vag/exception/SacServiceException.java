package com.matrixx.vag.exception;

public class SacServiceException extends IntegrationServiceException {

    private static final long serialVersionUID = -2036046927166143294L;

    public SacServiceException(Long resultCode, String message) {
        super(resultCode, message);
    }
}
