package com.matrixx.vag.exception;


public class MtxResponseException extends VisibleServiceException {
    private static final long serialVersionUID = -1844774067577077541L;

    public MtxResponseException(Long resultCode, String message) {
        super(resultCode, message);
    }
}
