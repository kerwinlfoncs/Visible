package com.matrixx.vag.advice.model;

public class PromoOfferPair {
    private final String offerCiExternalId;
    private final String promoCiExternalId;
    private static final String KEY_FLD_SEPARATOR = "#";

    public PromoOfferPair(String offerCiExternalId, String promoCiExternalId) {    	
    	this.offerCiExternalId = offerCiExternalId;
    	this.promoCiExternalId = promoCiExternalId;
    }

	public String getOfferCiExternalId() {
		return offerCiExternalId;
	}


	public String getPromoCiExternalId() {
		return promoCiExternalId;
	}
	
    @Override
    public String toString() {
        return offerCiExternalId + KEY_FLD_SEPARATOR + promoCiExternalId;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((offerCiExternalId == null) ? 0 : offerCiExternalId.hashCode());
        result = prime * result + ((promoCiExternalId == null) ? 0 : promoCiExternalId.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        PromoOfferPair other = (PromoOfferPair) obj;
        if (offerCiExternalId == null) {
            if (other.offerCiExternalId != null) {
                return false;
            }
        } else if (!offerCiExternalId.equals(other.offerCiExternalId)) {
            return false;
        }
        if (promoCiExternalId == null) {
            if (other.promoCiExternalId != null) {
                return false;
            }
        } else if (!promoCiExternalId.equals(other.promoCiExternalId)) {
            return false;
        }
        return true;
    }



}
