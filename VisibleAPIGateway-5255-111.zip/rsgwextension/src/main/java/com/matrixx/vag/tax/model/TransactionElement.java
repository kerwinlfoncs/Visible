package com.matrixx.vag.tax.model;

import java.math.BigDecimal;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL) // Ignore unused fields to reduce payload size.
public class TransactionElement {

    private String btcTransactionCode;
    @JsonSerialize(using = TaxBigDecimalSerializer.class)
    private BigDecimal totalTaxAmount;
    @JsonSerialize(using = TaxBigDecimalSerializer.class)
    private BigDecimal totalFeeAmount;
    @JsonSerialize(using = TaxBigDecimalSerializer.class)
    private BigDecimal totalNetRevenue;
    private BigDecimal modifiedDisplayNetRevenue;
    private List<DpcGroupTax> dpcGroupList;

    public String getBtcTransactionCode() {
        return btcTransactionCode;
    }

    public void setBtcTransactionCode(String btcTransactionCode) {
        this.btcTransactionCode = btcTransactionCode;
    }

    public BigDecimal getTotalTaxAmount() {
        return totalTaxAmount;
    }

    public void setTotalTaxAmount(BigDecimal totalTaxAmount) {
        this.totalTaxAmount = totalTaxAmount;
    }

    public BigDecimal getTotalFeeAmount() {
        return totalFeeAmount;
    }

    public void setTotalFeeAmount(BigDecimal totalFeeAmount) {
        this.totalFeeAmount = totalFeeAmount;
    }

    public BigDecimal getTotalNetRevenue() {
        return totalNetRevenue;
    }

    public void setTotalNetRevenue(BigDecimal totalNetRevenue) {
        this.totalNetRevenue = totalNetRevenue;
    }

    public BigDecimal getModifiedDisplayNetRevenue() {
        return modifiedDisplayNetRevenue;
    }

    public void setModifiedDisplayNetRevenue(BigDecimal modifiedDisplayNetRevenue) {
        this.modifiedDisplayNetRevenue = modifiedDisplayNetRevenue;
    }

    public List<DpcGroupTax> getDpcGroupList() {
        return dpcGroupList;
    }

    public void setDpcGroupList(List<DpcGroupTax> dpcGroupList) {
        this.dpcGroupList = dpcGroupList;
    }

}
