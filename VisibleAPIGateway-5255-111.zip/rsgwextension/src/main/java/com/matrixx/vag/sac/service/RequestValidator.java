package com.matrixx.vag.sac.service;

import static com.matrixx.platform.LogUtils.DEBUG;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.matrixx.datacontainer.mdc.VisibleRequestCaLink;
import com.matrixx.datacontainer.mdc.VisibleRequestCaUnlink;
import com.matrixx.datacontainer.mdc.VisibleRequestSacSetUpPayment;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.exception.InvalidRequestException;
import com.matrixx.vag.exception.MissingRequestParametersException;

/**
 * Validate incoming requests.
 *
 * @author unico
 */
public class RequestValidator {

    private static final Logger m_logger = LoggerFactory.getLogger(RequestValidator.class);

    public void validateRequest(String loggingKey, VisibleRequestSacSetUpPayment request)
            throws InvalidRequestException {

        DEBUG(m_logger, loggingKey + "Validating SAC add default payment request");
        String missingMandatoryParamName = null;

        // Validating mandatory fields
        if (StringUtils.isEmpty(request.getSubscriberExternalId())) {
            missingMandatoryParamName = "SubscriberExternalId";
        } else if (request.getNonce() == null) {
            missingMandatoryParamName = "Nonce";
        } // validating the values:
        if (missingMandatoryParamName != null) {
            throw new MissingRequestParametersException(
                    "Missing mandatory parameter: " + missingMandatoryParamName);
        }
    }

    public void validateRequest(String loggingKey, VisibleRequestCaLink request)
            throws InvalidRequestException {

        DEBUG(m_logger, loggingKey + "Validating " + VisibleRequestCaLink.class.getSimpleName());
        // Validating mandatory fields
        if (StringUtils.isBlank(request.getBeneficiaryExternalId())) {
            throw new MissingRequestParametersException(
                    "Missing mandatory parameter: " + "BeneficiaryExternalId");
        } else if (StringUtils.isBlank(request.getPayerExternalId())) {
            throw new MissingRequestParametersException(
                    "Missing mandatory parameter: " + "PayerExternalId");
        } else if (StringUtils.isNotBlank(request.getPayerExternalId())
                && StringUtils.isNotBlank(request.getBeneficiaryExternalId())
                && request.getBeneficiaryExternalId().equalsIgnoreCase(
                        request.getPayerExternalId())) {
            throw new InvalidRequestException(
                    "Payer and Beneficiary can not be same" + " :PayerExternalId:"
                            + request.getPayerExternalId() + " :BeneficiaryExternalId:"
                            + request.getPayerExternalId());
        }
    }

    public void validateRequest(String loggingKey, VisibleRequestCaUnlink request)
            throws InvalidRequestException {

        DEBUG(m_logger, loggingKey + "Validating " + VisibleRequestCaUnlink.class.getSimpleName());
        // Validating mandatory fields
        if (StringUtils.isBlank(request.getBeneficiaryExternalId())) {
            throw new MissingRequestParametersException(
                    "Missing mandatory parameter: " + "BeneficiaryExternalId");
        }
    }

}
