package com.matrixx.vag.payment.service;

import java.util.ArrayList;
import java.util.List;

import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.matrixx.datacontainer.mdc.VisiblePurchasedOfferExtension;
import com.matrixx.vag.common.CommonUtils;

public class CatalogItemUpdate {
    private String catalogItemExternalId;
    private long resourceId;
    private VisiblePurchasedOfferExtension purchasedOfferExtension;
    private List<String> creditTaxList;
    private static final Logger m_logger = LoggerFactory.getLogger(CatalogItemUpdate.class);
    
    private CatalogItemUpdate(String catalogItemExternalId, 
    						  long resourceId) {
    	this.catalogItemExternalId = catalogItemExternalId.trim();
    	this.resourceId = resourceId;
    	this.purchasedOfferExtension =  null;
    	this.creditTaxList = new ArrayList<String>();
    }

    public String getCatalogItemExternalId() {
        return catalogItemExternalId;
    }

	public VisiblePurchasedOfferExtension getPurchasedOfferExtension() {
		return purchasedOfferExtension;
	}

	public List<String> getCreditTaxList() {
		return creditTaxList;
	}

	public void addCreditTaxList(String creditTax) {
		this.creditTaxList.add(creditTax.trim());
	}

	public void clearCreditTaxList() {
		this.creditTaxList = new ArrayList<String>();
	}

	public long getResourceId() {
		return resourceId;
	}

	public void setVisiblePurchasedOfferExtension(VisiblePurchasedOfferExtension purchasedOfferExtension) {
		this.purchasedOfferExtension = purchasedOfferExtension;
	}
	
    public static CatalogItemUpdate createCatalogItemUpdate(String catalogItemExternalId, long resourceId) {    	
    	return new CatalogItemUpdate(catalogItemExternalId, resourceId);
    }

    public CatalogItemUpdate withPurchasedOfferExtension(VisiblePurchasedOfferExtension purchasedOfferExtension) {
    	this.setVisiblePurchasedOfferExtension(purchasedOfferExtension);
    	return this;
    }
    
    public static CatalogItemUpdate createCatalogItemUpdate(String loggingKey, String catalogItemExternalId, MtxResponseSubscription subscriber) {
    	return new CatalogItemUpdate(
    			catalogItemExternalId, 
    			CommonUtils.getPurchasedOfferInfo(loggingKey, subscriber, catalogItemExternalId).getResourceId());
    }
}
