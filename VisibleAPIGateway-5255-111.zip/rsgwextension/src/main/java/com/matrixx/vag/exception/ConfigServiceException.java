package com.matrixx.vag.exception;

/**
 * Exception thrown upon encountering an error with reloading system configuration.
 *
 * @author unico
 */
public class ConfigServiceException extends IntegrationServiceException {

    private static final long serialVersionUID = 7740580333397642541L;

    public ConfigServiceException(Long resultCode, String message) {
        super(resultCode, message);
    }
}
