package com.matrixx.vag.tax.model;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL) // Ignore unused fields to reduce payload size.
public class DpcItem {

    private String dpcItem;
    private BigDecimal cP;
    private BigDecimal cycleNSR;
    private String glReference;

    public String getDpcItem() {
        return dpcItem;
    }

    public void setDpcItem(String dpcItem) {
        this.dpcItem = dpcItem;
    }

    public BigDecimal getcP() {
        return cP;
    }

    public void setcP(BigDecimal cP) {
        this.cP = cP;
    }

    public BigDecimal getCycleNSR() {
        return cycleNSR;
    }

    public void setCycleNSR(BigDecimal cycleNSR) {
        this.cycleNSR = cycleNSR;
    }

    public String getGlReference() {
        return glReference;
    }

    public void setGlReference(String glReference) {
        this.glReference = glReference;
    }

}
