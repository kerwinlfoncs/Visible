package com.matrixx.vag.device.service;

import java.math.BigDecimal;

import com.matrixx.vag.common.CommonUtils;

public class PurchaseDeviceOrder {

    @SuppressWarnings("unused")
	private final String originalOrderId;
    private String parentOrderId;
    private BigDecimal refundAmount;
    private Long refundBalanceResourceId;
    private String refundAdjustmentReason;
    private String shipToBid;
    
    PurchaseDeviceOrder(String originalOrderId) {
    	this.originalOrderId = originalOrderId;
    	this.refundAmount = BigDecimal.ZERO;
    	this.refundAdjustmentReason = CommonUtils.REVERSAL_PREFIX;
    }

	public String getParentOrderId() {
		return parentOrderId;
	}

	public void setParentOrderId(String parentOrderId) {
		this.parentOrderId = parentOrderId;
	}

	public BigDecimal getRefundAmount() {
		return refundAmount;
	}

	public void addRefundAmount(BigDecimal refundAmount) {
		this.refundAmount = this.refundAmount.add(refundAmount);
	}

	public Long getRefundBalanceResourceId() {
		return refundBalanceResourceId;
	}

	public void setRefundBalanceResourceId(Long refundBalanceResourceId) {
		this.refundBalanceResourceId = refundBalanceResourceId;
	}

	public String getRefundAdjustmentReason() {
		return refundAdjustmentReason;
	}

	public void appendEventIdToRefundAdjustmentReason(String eventId) {
		this.refundAdjustmentReason = refundAdjustmentReason+" "+eventId;
	}

	public String getShipToBid() {
		return shipToBid;
	}

	public void setShipToBid(String shipToBid) {
		this.shipToBid = shipToBid;
	}

	
}
