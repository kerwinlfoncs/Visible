package com.matrixx.vag.advice.service;

import static com.matrixx.platform.LogUtils.INFO;
import static com.matrixx.platform.LogUtils.WARN;

import java.beans.IntrospectionException;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.matrixx.datacontainer.MtxTimestamp;
import com.matrixx.datacontainer.mdc.MtxBalanceInfo;
import com.matrixx.datacontainer.mdc.MtxPricingCatalogItemDetailInfo;
import com.matrixx.datacontainer.mdc.MtxPricingMetadataInfo;
import com.matrixx.datacontainer.mdc.MtxPurchasedOfferInfo;
import com.matrixx.datacontainer.mdc.MtxRequiredBalanceInfo;
import com.matrixx.datacontainer.mdc.MtxResponsePricingBalance;
import com.matrixx.datacontainer.mdc.MtxResponsePricingCatalogItem;
import com.matrixx.datacontainer.mdc.MtxResponseSubscription;
import com.matrixx.datacontainer.mdc.PurchasedOfferInfo;
import com.matrixx.datacontainer.mdc.SubscriptionResponse;
import com.matrixx.datacontainer.mdc.VisibleCredits;
import com.matrixx.datacontainer.mdc.VisibleNextCyclePaymentAdvice;
import com.matrixx.datacontainer.mdc.VisibleOfferDetails;
import com.matrixx.datacontainer.mdc.VisiblePromoExtension;
import com.matrixx.datacontainer.mdc.VisiblePurchasedOfferExtension;
import com.matrixx.datacontainer.mdc.VisibleSubscriberExtension;
import com.matrixx.datacontainer.mdc.VisibleTemplate;
import com.matrixx.vag.advice.model.ChangeServiceDataStage;
import com.matrixx.vag.advice.model.CiResourceIdPair;
import com.matrixx.vag.advice.model.CreditStage;
import com.matrixx.vag.advice.model.FuturePromo;
import com.matrixx.vag.advice.model.GlobalCreditStage;
import com.matrixx.vag.advice.model.Incompatibility;
import com.matrixx.vag.advice.model.IncompatibilityCondition;
import com.matrixx.vag.advice.model.IncompatibilityList;
import com.matrixx.vag.advice.model.PromoOfferPair;
import com.matrixx.vag.advice.model.ServiceStage;
import com.matrixx.vag.advice.model.VisibleOfferDetailsInternal;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.Constants.BRAINTREE_CONSTANTS;
import com.matrixx.vag.common.Constants.CI_METADATA;
import com.matrixx.vag.common.Constants.CREDIT_CONSTANTS;
import com.matrixx.vag.common.Constants.FREEZE_GRANT_REASONS;
import com.matrixx.vag.common.Constants.GENERIC_CONSTANTS;
import com.matrixx.vag.common.Constants.LOG_MESSAGES;
import com.matrixx.vag.common.Constants.MATRIXX_CONSTANTS;
import com.matrixx.vag.common.Constants.MDC_NAMES;
import com.matrixx.vag.common.Constants.OFFER_CONSTANTS;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.common.Constants.TAX_CONSTANTS;
import com.matrixx.vag.common.request.builder.ServiceTaxRequestBuilder;
import com.matrixx.vag.exception.IntegrationServiceException;
import com.matrixx.vag.exception.PaymentAdviceException;
import com.matrixx.vag.tax.client.TaxApiClient;
import com.matrixx.vag.tax.model.DpcGroupTax;
import com.matrixx.vag.tax.model.DpcItemTax;
import com.matrixx.vag.tax.model.ServiceTaxRequest;
import com.matrixx.vag.tax.model.ServiceTaxResponse;
import com.matrixx.vag.tax.model.TaxItem;
import com.matrixx.vag.tax.model.TransactionElement;

public class AdviceUtils {

    private static final Logger m_logger = LoggerFactory.getLogger(AdviceUtils.class);

    public static String getTaxDetailsWithoutRefTax(String loggingKey,
                                                    String route,
                                                    ServiceTaxRequest taxApiRequest)
            throws javax.naming.ConfigurationException, JsonParseException, JsonMappingException,
            IOException {
        final String methodName = "getTaxDetailswithoutRefTax:";
        INFO(m_logger, loggingKey + methodName);

        LocalDate now = LocalDate.now();
        taxApiRequest.setGlDate(
                now.format(DateTimeFormatter.ofPattern(TAX_CONSTANTS.GL_DATE_FORMAT)));
        // Call Tax API
        ObjectMapper objectMapper = CommonUtils.getObjectMapper();
        try {
            String taxApiRequestString = objectMapper.writeValueAsString(taxApiRequest);
            INFO(
                    m_logger, loggingKey + methodName + StringUtils.SPACE
                            + "Call taxapi with request: " + taxApiRequestString);
            String taxApiResponse = TaxApiClient.getTaxApiResult(loggingKey, taxApiRequestString);
            INFO(
                    m_logger, loggingKey + methodName + StringUtils.SPACE + "Taxapi response: "
                            + taxApiResponse);
            return taxApiResponse;
        } catch (Exception ex) {
            WARN(
                    m_logger,
                    loggingKey + methodName + StringUtils.SPACE
                            + LOG_MESSAGES.LOG_FAILED_SERVICE_TAX + StringUtils.SPACE
                            + ExceptionUtils.getStackTrace(ex));
            return GENERIC_CONSTANTS.ERROR_PREFIX + ex.getMessage();
        }
    }

    public static String getCreditTaxBySubtraction(String loggingKey,
                                                   String route,
                                                   String fullServiceTax,
                                                   String serviceTaxNoCredit,
                                                   BigDecimal credits,
                                                   String promotionName,
                                                   String brand)
            throws JsonParseException, JsonMappingException, IOException, PaymentAdviceException {
        final String methodKey = loggingKey + " getCreditTaxBySubtraction: ";
        INFO(
                m_logger, methodKey
                        + "Calculate credit taxes by subtracting taxes for each dpc item, of Tax for (DiscountPrice-RedeemableCredit) from actual service tax.");
        ObjectMapper objectMapper = CommonUtils.getObjectMapper();
        ServiceTaxResponse fullTax = objectMapper.readValue(
                fullServiceTax, ServiceTaxResponse.class);

        ServiceTaxResponse creditLessTaxResponse = objectMapper.readValue(
                serviceTaxNoCredit, ServiceTaxResponse.class);

        if (creditLessTaxResponse.getTransactionElement().size() != fullTax.getTransactionElement().size()) {
            String msg = GENERIC_CONSTANTS.ERROR_PREFIX
                    + "mismatch of number of TransactionElements";
            INFO(
                    m_logger, methodKey + msg + ": " + fullTax.getTransactionElement().size() + "!="
                            + creditLessTaxResponse.getTransactionElement().size());
            return msg;
        }
        Map<String, BigDecimal> taxMap = new HashMap<String, BigDecimal>();
        Map<String, String> glRefMap = new HashMap<String, String>();
        String NET_REVENUE = "NetRevenue";
        String TAX_AMOUNT = "TaxAmount";
        String FEE_AMOUNT = "FeeAmount";
        String DISPLAY_NET_REVENUE = "DisplayNetRevenue";
        String keyFormat = "%s%s#";
        fullTax.getTransactionElement().forEach(te -> {
            String btcPrefix = String.format(keyFormat, "", te.getBtcTransactionCode());
            taxMap.put(btcPrefix + NET_REVENUE, te.getTotalNetRevenue());
            taxMap.put(btcPrefix + TAX_AMOUNT, te.getTotalTaxAmount());
            taxMap.put(btcPrefix + FEE_AMOUNT, te.getTotalFeeAmount());
            taxMap.put(btcPrefix + DISPLAY_NET_REVENUE, te.getModifiedDisplayNetRevenue());
            te.getDpcGroupList().forEach(dgt -> {
                String grpPrefix = String.format(keyFormat, btcPrefix, dgt.getDpcGroup());
                dgt.getDpcItemList().forEach(dit -> {
                    String itemPrefix = String.format(keyFormat, grpPrefix, dit.getGlReference());
                    if (glRefMap.get(dit.getDpcItem()) == null
                            || (glRefMap.get(dit.getDpcItem()) != null && glRefMap.get(
                                    dit.getDpcItem()).length() > dit.getGlReference().length())) {
                        glRefMap.put(dit.getDpcItem(), dit.getGlReference());
                    }
                    taxMap.put(itemPrefix + NET_REVENUE, dit.getDpcItemNetRevenue());
                    taxMap.put(itemPrefix + TAX_AMOUNT, dit.getDpcItemTaxAmount());
                    taxMap.put(itemPrefix + FEE_AMOUNT, dit.getDpcItemFeeAmount());
                    dit.getTaxItemList().forEach(ti -> {
                        String taxItemPrefix = String.format(
                                keyFormat, itemPrefix, ti.getTaxItemKey());
                        if (taxMap.get(taxItemPrefix + TAX_AMOUNT) != null) {
                            taxMap.put(
                                    taxItemPrefix + TAX_AMOUNT,
                                    taxMap.get(taxItemPrefix + TAX_AMOUNT).add(ti.getTaxAmount()));
                        } else {
                            taxMap.put(taxItemPrefix + TAX_AMOUNT, ti.getTaxAmount());
                        }
                    });
                });
            });
        });
        final DecimalFormat numFormat = new DecimalFormat("#.########");
        numFormat.setMinimumFractionDigits(0);
        numFormat.setMaximumFractionDigits(TAX_CONSTANTS.TAX_API_PRECISION);
        numFormat.setMinimumIntegerDigits(1);
        Map<String, DpcItemTax> itemMap = new HashMap<String, DpcItemTax>(); // dpcItemId-dpcItem-Map
        // Subtract two responses to get intermediate subtracted taxResponse
        for (int i = 0; i < creditLessTaxResponse.getTransactionElement().size(); i++) {
            TransactionElement te = creditLessTaxResponse.getTransactionElement().get(i);
            String btcPrefix = String.format(keyFormat, "", te.getBtcTransactionCode());
            if (taxMap.get(btcPrefix + TAX_AMOUNT) != null) {
                BigDecimal teTaxAmount = taxMap.get(btcPrefix + TAX_AMOUNT).subtract(
                        te.getTotalTaxAmount());
                INFO(
                        m_logger,
                        methodKey
                                + "Calculate credit TotalTaxAmount by subtracting for BtcTransactionCode "
                                + te.getBtcTransactionCode() + ": "
                                + numFormat.format(taxMap.get(btcPrefix + TAX_AMOUNT)) + "-"
                                + numFormat.format(te.getTotalTaxAmount()) + "="
                                + numFormat.format(teTaxAmount));
                te.setTotalTaxAmount(teTaxAmount);
            } else {
                String msg = GENERIC_CONSTANTS.ERROR_PREFIX + "no match found in service tax for "
                        + btcPrefix + TAX_AMOUNT;
                INFO(m_logger, methodKey + msg);
                return msg;
            }

            if (taxMap.get(btcPrefix + NET_REVENUE) != null) {
                BigDecimal teNetRevenue = taxMap.get(btcPrefix + NET_REVENUE).subtract(
                        te.getTotalNetRevenue());
                INFO(
                        m_logger,
                        methodKey
                                + "Calculate credit TotalNetRevenue by subtracting for BtcTransactionCode "
                                + te.getBtcTransactionCode() + ": "
                                + numFormat.format(taxMap.get(btcPrefix + NET_REVENUE)) + "-"
                                + numFormat.format(te.getTotalNetRevenue()) + "="
                                + numFormat.format(teNetRevenue));
                te.setTotalNetRevenue(teNetRevenue);
                ;
            } else {
                String msg = GENERIC_CONSTANTS.ERROR_PREFIX + "no match found in service tax for "
                        + btcPrefix + NET_REVENUE;
                INFO(m_logger, methodKey + msg);
                return msg;
            }

            if (taxMap.get(btcPrefix + DISPLAY_NET_REVENUE) != null) {
                BigDecimal dispNetRevenue = taxMap.get(btcPrefix + DISPLAY_NET_REVENUE).subtract(
                        te.getModifiedDisplayNetRevenue());
                INFO(
                        m_logger,
                        methodKey
                                + "Calculate credit ModifiedDisplayNetRevenue by subtracting for BtcTransactionCode "
                                + te.getBtcTransactionCode() + ": "
                                + numFormat.format(taxMap.get(btcPrefix + DISPLAY_NET_REVENUE))
                                + "-" + numFormat.format(te.getModifiedDisplayNetRevenue()) + "="
                                + numFormat.format(dispNetRevenue));
                te.setModifiedDisplayNetRevenue(dispNetRevenue);
            }

            if (taxMap.get(btcPrefix + FEE_AMOUNT) != null) {
                BigDecimal teFee = taxMap.get(btcPrefix + FEE_AMOUNT).subtract(
                        te.getTotalFeeAmount());
                INFO(
                        m_logger,
                        methodKey
                                + "Calculate credit ModifiedDisplayNetRevenue by subtracting for BtcTransactionCode "
                                + te.getBtcTransactionCode() + ": "
                                + numFormat.format(taxMap.get(btcPrefix + FEE_AMOUNT)) + "-"
                                + numFormat.format(te.getTotalFeeAmount()) + "="
                                + numFormat.format(teFee));
                te.setTotalFeeAmount(teFee);
            }

            Map<String, String> rollupMsgMap = new HashMap<String, String>();
            Map<String, String> rollupResultMap = new HashMap<String, String>();
            for (int j = 0; j < te.getDpcGroupList().size(); j++) {
                DpcGroupTax dgt = te.getDpcGroupList().get(j);
                String grpPrefix = String.format(keyFormat, btcPrefix, dgt.getDpcGroup());
                for (int k = 0; k < dgt.getDpcItemList().size(); k++) {
                    DpcItemTax dit = dgt.getDpcItemList().get(k);
                    String itemPrefix = String.format(keyFormat, grpPrefix, dit.getGlReference());
                    if (taxMap.get(itemPrefix + TAX_AMOUNT) != null) {
                        BigDecimal ditTaxAmount = taxMap.get(itemPrefix + TAX_AMOUNT).subtract(
                                dit.getDpcItemTaxAmount());
                        INFO(
                                m_logger,
                                methodKey + "Calculate credit DpcItemTaxAmount by subtracting for "
                                        + dit.getGlReference() + ": "
                                        + numFormat.format(taxMap.get(itemPrefix + TAX_AMOUNT))
                                        + "-" + numFormat.format(dit.getDpcItemTaxAmount()) + "="
                                        + numFormat.format(ditTaxAmount));
                        dit.setDpcItemTaxAmount(ditTaxAmount);
                    } else {
                        String msg = GENERIC_CONSTANTS.ERROR_PREFIX
                                + "no match found in service tax for " + itemPrefix + TAX_AMOUNT;
                        INFO(m_logger, methodKey + msg);
                        return msg;
                    }

                    if (taxMap.get(itemPrefix + NET_REVENUE) != null) {
                        BigDecimal ditNetRevenue = taxMap.get(itemPrefix + NET_REVENUE).subtract(
                                dit.getDpcItemNetRevenue());
                        INFO(
                                m_logger,
                                methodKey + "Calculate credit DpcItemNetRevenue by subtracting for "
                                        + dit.getGlReference() + ": "
                                        + numFormat.format(taxMap.get(itemPrefix + NET_REVENUE))
                                        + "-" + numFormat.format(dit.getDpcItemNetRevenue()) + "="
                                        + numFormat.format(ditNetRevenue));
                        dit.setDpcItemNetRevenue(ditNetRevenue);
                    } else {
                        String msg = GENERIC_CONSTANTS.ERROR_PREFIX
                                + "no match found in service tax for " + itemPrefix + NET_REVENUE;
                        INFO(m_logger, methodKey + msg);
                        return msg;
                    }

                    for (int m = 0; m < dit.getTaxItemList().size(); m++) {
                        TaxItem ti = dit.getTaxItemList().get(m);
                        String taxItemPrefix = String.format(
                                keyFormat, itemPrefix, ti.getTaxItemKey());
                        if (taxMap.get(taxItemPrefix + TAX_AMOUNT) != null) {
                            BigDecimal tiTaxAmount = taxMap.get(
                                    taxItemPrefix + TAX_AMOUNT).subtract(ti.getTaxAmount());
                            INFO(
                                    m_logger,
                                    methodKey + "Calculate credit tax amount by subtracting for "
                                            + ti.getDescription() + " taxCategory "
                                            + ti.getTaxCategory() + ": "
                                            + numFormat.format(
                                                    taxMap.get(taxItemPrefix + TAX_AMOUNT))
                                            + "-" + numFormat.format(ti.getTaxAmount()) + "="
                                            + numFormat.format(tiTaxAmount));
                            ti.setTaxAmount(tiTaxAmount);
                        } else {
                            String msg = GENERIC_CONSTANTS.ERROR_PREFIX
                                    + "no match found in service tax for " + taxItemPrefix
                                    + TAX_AMOUNT;
                            INFO(m_logger, methodKey + msg);
                            return msg;
                        }
                    }

                    String feePrefix = "DpcItemFeeAmount for " + glRefMap.get(dit.getDpcItem());
                    String taxPrefix = "DpcItemTaxAmount for " + glRefMap.get(dit.getDpcItem());
                    String netPrefix = "DpcItemNetRevenue for " + glRefMap.get(dit.getDpcItem());
                    String cpPrefix = "CP for " + glRefMap.get(dit.getDpcItem());

                    if (itemMap.get(btcPrefix + dit.getDpcItem()) != null) {
                        // Roll-Up block. Add / Consolidate dpcitem from each group into one.
                        DpcItemTax item = itemMap.get(btcPrefix + dit.getDpcItem());
                        rollupMsgMap.put(
                                feePrefix, rollupMsgMap.get(feePrefix) + "+"
                                        + numFormat.format(dit.getDpcItemFeeAmount()));
                        rollupMsgMap.put(
                                taxPrefix, rollupMsgMap.get(taxPrefix) + "+"
                                        + numFormat.format(dit.getDpcItemTaxAmount()));
                        rollupMsgMap.put(
                                netPrefix, rollupMsgMap.get(netPrefix) + "+"
                                        + numFormat.format(dit.getDpcItemNetRevenue()));
                        rollupMsgMap.put(
                                cpPrefix,
                                rollupMsgMap.get(cpPrefix) + "+" + numFormat.format(dit.getcP()));

                        item.setDpcItemFeeAmount(
                                item.getDpcItemFeeAmount().add(dit.getDpcItemFeeAmount()));
                        item.setDpcItemTaxAmount(
                                item.getDpcItemTaxAmount().add(dit.getDpcItemTaxAmount()));
                        item.setDpcItemNetRevenue(
                                item.getDpcItemNetRevenue().add(dit.getDpcItemNetRevenue()));
                        item.setcP(item.getcP().add(dit.getcP()));

                        rollupResultMap.put(
                                taxPrefix, "" + numFormat.format(item.getDpcItemTaxAmount()));
                        rollupResultMap.put(
                                feePrefix, "" + numFormat.format(item.getDpcItemFeeAmount()));
                        rollupResultMap.put(
                                netPrefix, "" + numFormat.format(item.getDpcItemNetRevenue()));
                        rollupResultMap.put(cpPrefix, "" + numFormat.format(item.getcP()));

                        item.getTaxItemList().forEach(ti1 -> {
                            String tiid1 = ti1.getTaxItemKey();
                            dit.getTaxItemList().forEach(ti2 -> {
                                String tiid2 = ti2.getTaxItemKey();
                                if (tiid1.equalsIgnoreCase(tiid2)) {
                                    ti1.setTaxAmount(ti1.getTaxAmount().add(ti2.getTaxAmount()));
                                }
                            });
                        });
                    } else {
                        itemMap.put(btcPrefix + dit.getDpcItem(), dit);
                        rollupMsgMap.put(taxPrefix, numFormat.format(dit.getDpcItemTaxAmount()));
                        rollupMsgMap.put(feePrefix, numFormat.format(dit.getDpcItemFeeAmount()));
                        rollupMsgMap.put(netPrefix, numFormat.format(dit.getDpcItemNetRevenue()));
                        rollupMsgMap.put(cpPrefix, numFormat.format(dit.getcP()));

                        rollupResultMap.put(taxPrefix, numFormat.format(dit.getDpcItemTaxAmount()));
                        rollupResultMap.put(feePrefix, numFormat.format(dit.getDpcItemFeeAmount()));
                        rollupResultMap.put(
                                netPrefix, numFormat.format(dit.getDpcItemNetRevenue()));
                        rollupResultMap.put(cpPrefix, numFormat.format(dit.getcP()));
                    }
                }
            }
            rollupMsgMap.forEach((k, v) -> {
                INFO(
                        m_logger,
                        methodKey + "Rollup " + k + " : " + v + "=" + rollupResultMap.get(k));
            });
        }

        INFO(
                m_logger, methodKey + "Intermediate Credit Tax Response after subtraction: "
                        + creditLessTaxResponse.toJson());

        // Create a second copy to create final response
        ServiceTaxResponse creditTax = objectMapper.readValue(
                creditLessTaxResponse.toJson(), ServiceTaxResponse.class);
        creditTax.setDiscountPrice(credits);
        creditTax.setPromotionCredit(true);
        creditTax.setGrossPrice(credits);
        creditTax.setPromotionName(promotionName);
        creditTax.setBrand(brand);
        Collection<String> glRefList = glRefMap.values();
        for (int i = 0; i < creditTax.getTransactionElement().size(); i++) {
            // Keep only one set of unique dpcitems for final response
            TransactionElement te = creditTax.getTransactionElement().get(i);
            String btcPrefix = String.format(keyFormat, "", te.getBtcTransactionCode());
            String dpgGroupId = te.getDpcGroupList().get(0).getDpcGroup();
            te.getDpcGroupList().clear();
            DpcGroupTax dgt = new DpcGroupTax();
            dgt.setDpcGroup(dpgGroupId);
            for (Entry<String, DpcItemTax> entry : itemMap.entrySet()) {
                if (entry.getKey().startsWith(btcPrefix)) {
                    DpcItemTax item = entry.getValue();
                    item.setGlReference(glRefMap.get(item.getDpcItem()));
                    dgt.getDpcItemList().add(item);
                }
            }
            te.getDpcGroupList().add(dgt);
        }

        return objectMapper.writeValueAsString(creditTax);

    }

    /**
     * create output result text
     *
     * @param stage
     * @return
     */

    public static String getErrorResultText(AdviceDataStage stage) {

        StringBuffer taxErrors = new StringBuffer("");
        List<String> msgList = new ArrayList<String>();

        if (StringUtils.isNotEmpty(stage.getServiceTaxApiErrorMessage().toString())) {
            msgList.add(
                    "Tax message for Service: " + stage.getServiceTaxApiErrorMessage().toString());
        }
        for (CreditStage cs : stage.getCreditMap().values()) {
            if (StringUtils.isNotEmpty(cs.getCreditTaxApiErrorMessage())) {
                msgList.add(
                        "Tax message for " + cs.getClassCode() + " : "
                                + cs.getCreditTaxApiErrorMessage());
            }
        }

        boolean addPipe = false;
        for (String msg : msgList) {
            if (addPipe) {
                taxErrors.append("|" + msg);
            } else {
                taxErrors.append(msg);
            }
        }
        return StringUtils.isNotEmpty(taxErrors.toString())
                ? taxErrors.toString() : MATRIXX_CONSTANTS.RESULT_TEXT_MTX_SUCCESS;
    }

    public static VisibleNextCyclePaymentAdvice getNextCycleAop(String loggingKey,
                                                                AdviceDataStage stageAop) {
        final String methodKey = loggingKey + " getNextCycleAop: ";
        VisibleNextCyclePaymentAdvice ncpa = new VisibleNextCyclePaymentAdvice();
        ncpa.setRechargeAmount(stageAop.getRechargeAmount());
        ncpa.setConsumableMainBalanceAmount(stageAop.getConsumableMainBalanceAmount());
        ncpa.setTotalPayableAmount(stageAop.getTotalEstimatedAmount());
        stageAop.getVisibleOfferDetailsMap().values().forEach(vod -> {
            ncpa.appendVisibleOfferDetailsList(vod);
        });

        stageAop.getCreditMap().values().forEach(cs -> {
            VisibleCredits co = new VisibleCredits();
            co.setPromotionName(cs.getPromotionName());
            co.setClassCode(cs.getClassCode());
            co.setApplicableCI(cs.getApplicableCiExternalId());
            co.setAvailableCredits(cs.getAvailableCredits());
            co.setAvailableCreditsGrant(cs.getAvailableCreditsGrant());
            co.setAvailableCreditsConsumable(cs.getAvailableCreditsConsumable());
            co.setEstimatedTransferableCredits(cs.getEstimatedTransferableCredits());
            co.setCreditRedeemableOfferCI(cs.getRedeemOfferCi());
            co.setDiscountCalculationMethod(cs.getDiscountCalculationMethod());
            co.setRedeemableGoodType(cs.getRedeemGoodType());
            co.setApplicableCreditsPercentage(cs.getApplicableGrantPercentage());
            if (StringUtils.isNotBlank(cs.getCreditTaxDetails())) {
                co.setTaxDetails(cs.getCreditTaxDetails());
            } else if (cs.isPromotionTaxable()
                    && StringUtils.isNotBlank(AdviceUtils.getErrorResultText(stageAop))
                    && !(AdviceUtils.getErrorResultText(stageAop).equalsIgnoreCase("OK"))) {
                co.setTaxDetails(AdviceUtils.getErrorResultText(stageAop));
            }
            if (!cs.isNoCap()) {
                co.setCreditCap(cs.getCreditCap());
            }
            co.setRedeemableCredits(cs.getRedeemableCredits());
            ncpa.appendCredits(co);
        });
        return ncpa;
    }

    public static GlobalCreditStage getGlobalCreditStageForGrantCI(String loggingKey,
                                                                   MtxResponsePricingCatalogItem mtxResponsePricingCatalogItem,
                                                                   AdviceDataStage stage,
                                                                   boolean isPostChangeServicePromo) {
        final String methodKey = loggingKey + " getGlobalCreditStageForGrantCI: ";
        final String grantCI = mtxResponsePricingCatalogItem.getCatalogItemInfo().getExternalId();
        final String promoKey = methodKey + grantCI + StringUtils.SPACE;
        if (!(mtxResponsePricingCatalogItem != null
                && mtxResponsePricingCatalogItem.getCatalogItemInfo() != null
                && mtxResponsePricingCatalogItem.getCatalogItemInfo().getTemplateAttr() != null
                && mtxResponsePricingCatalogItem.getCatalogItemInfo().getTemplateAttr() instanceof VisibleTemplate)) {
            INFO(
                    m_logger, promoKey
                            + "does not have Visible Template attributes. It will not be processed");
            return null;
        }

        VisibleTemplate tempAttr = (VisibleTemplate) mtxResponsePricingCatalogItem.getCatalogItemInfo().getTemplateAttr();
        GlobalCreditStage gcs = new GlobalCreditStage(grantCI, tempAttr);
        if (StringUtils.isBlank(tempAttr.getOfferType())
                || (!OFFER_CONSTANTS.OFFER_TYPE_PROMO.equalsIgnoreCase(tempAttr.getOfferType())
                        && !OFFER_CONSTANTS.OFFER_TYPE_GIFT.equalsIgnoreCase(
                                tempAttr.getOfferType()))) {
            INFO(m_logger, promoKey + "is not a promo or gift. It will not be processed");
            return null;
        }

        if (StringUtils.isBlank(tempAttr.getApplicableOfferName())) {
            INFO(m_logger, promoKey + "does not have applicable offer. It will not be processed");
            return null;
        } else {
            gcs.setApplicableCiCsv(tempAttr.getApplicableOfferName());
        }

        if (StringUtils.isBlank(tempAttr.getPromotionName())) {
            INFO(m_logger, promoKey + "does not have promotion name. It will not be processed");
            return null;
        } else {
            gcs.setPromotionName(tempAttr.getPromotionName());
        }

        if (StringUtils.isBlank(tempAttr.getClassCode())) {
            INFO(m_logger, promoKey + "does not have class code. It will not be processed");
            return null;
        } else {
            gcs.setClassCode(tempAttr.getClassCode());
        }

        if (StringUtils.isBlank(tempAttr.getIgnoreTax_ForPayableAmount())) {
            INFO(m_logger, promoKey + "does not have IgnoreTax_ForPayableAmount Flag.");
        } else {
            gcs.setIgnoreTax_ForPayableAmount(tempAttr.getIgnoreTax_ForPayableAmount());
        }

        if (StringUtils.isBlank(tempAttr.getDiscountCalculationMethod())) {
            INFO(m_logger, promoKey + "does not have grant type. It will not be processed");
            return null;
        } else {
            gcs.setDiscountCalculationMethod(tempAttr.getDiscountCalculationMethod());
        }

        if (CREDIT_CONSTANTS.CALCULATION_METHOD_AOC.equalsIgnoreCase(
                gcs.getDiscountCalculationMethod())) {
            INFO(
                    m_logger,
                    promoKey + "DiscountCalculationMethod is "
                            + CREDIT_CONSTANTS.CALCULATION_METHOD_AOC
                            + ". CreditGrantType will be defaulted to "
                            + CREDIT_CONSTANTS.GRANT_TYPE_DOLLAR);
            gcs.setCreditGrantType(CREDIT_CONSTANTS.GRANT_TYPE_DOLLAR);
        } else if (CREDIT_CONSTANTS.CALCULATION_METHOD_READ_METADATA.equalsIgnoreCase(
                gcs.getDiscountCalculationMethod())) {
            if (StringUtils.isBlank(tempAttr.getCreditGrantType())) {
                INFO(
                        m_logger,
                        promoKey + "DiscountCalculationMethod is "
                                + gcs.getDiscountCalculationMethod()
                                + ". CreditGrantType is not present. It will be defaulted to "
                                + CREDIT_CONSTANTS.GRANT_TYPE_DOLLAR + ". Please check.");
                gcs.setCreditGrantType(CREDIT_CONSTANTS.GRANT_TYPE_DOLLAR);
            } else {
                gcs.setCreditGrantType(tempAttr.getCreditGrantType());
            }
        } else if (CREDIT_CONSTANTS.CALCULATION_METHOD_READ_OFFER_INSTANCE.equalsIgnoreCase(
                gcs.getDiscountCalculationMethod())) {
            if (StringUtils.isBlank(tempAttr.getCreditGrantType())) {
                INFO(
                        m_logger,
                        promoKey + "DiscountCalculationMethod is "
                                + gcs.getDiscountCalculationMethod()
                                + ". CreditGrantType is not present. It will be read from offer instances, otherwise defaulted to "
                                + CREDIT_CONSTANTS.GRANT_TYPE_DOLLAR + ". Please check.");
                gcs.setCreditGrantType(CREDIT_CONSTANTS.GRANT_TYPE_DOLLAR);
            } else {
                gcs.setCreditGrantType(tempAttr.getCreditGrantType());
            }
        } else {
            INFO(
                    m_logger,
                    promoKey + "DiscountCalculationMethod " + gcs.getDiscountCalculationMethod()
                            + ". CreditGrantType will be defaulted to "
                            + CREDIT_CONSTANTS.GRANT_TYPE_DOLLAR + ". Please check.");
            gcs.setCreditGrantType(CREDIT_CONSTANTS.GRANT_TYPE_DOLLAR);
        }

        if (StringUtils.isBlank(tempAttr.getConsumableBalanceName())) {
            INFO(
                    m_logger,
                    promoKey + "does not have consumable balance name. It will not be processed");
        } else {
            gcs.setConsumableBalanceName(tempAttr.getConsumableBalanceName());
        }

        if (StringUtils.isBlank(tempAttr.getRedeemOffer())) {
            INFO(m_logger, promoKey + "does not have redeem offer. It will not be processed");
            return null;
        } else {
            gcs.setRedeemOfferCi(tempAttr.getRedeemOffer().trim());
        }

        if (tempAttr.getPromotionPriority() == null) {
            INFO(m_logger, promoKey + "does not have promotion priority. It will not be processed");
            return null;
        } else {
            gcs.setCreditPriority(tempAttr.getPromotionPriority());
        }

        if (StringUtils.isBlank(tempAttr.getOfferType())) {
            INFO(m_logger, promoKey + "does not have offer type. Please check.");
        } else {
            gcs.setGrantOfferType(tempAttr.getOfferType());
        }

        if (StringUtils.isBlank(tempAttr.getRedeemGoodType())) {
            INFO(m_logger, promoKey + "does not have redeem good type. Please check.");
        } else {
            gcs.setRedeemGoodType(tempAttr.getRedeemGoodType());
        }

        if (tempAttr.getMinimumCharge() == null) {
            INFO(m_logger, promoKey + "does not have minimum charge. Please check.");
        } else {
            gcs.setMinimumCharge(tempAttr.getMinimumCharge());
        }

        if (StringUtils.isBlank(tempAttr.getPromotionIsTaxable())) {
            INFO(
                    m_logger, promoKey
                            + "does not have credit taxability configured. By default all credits are taxable. Please check.");
            gcs.setPromotionIsTaxable(true);
        } else {
            gcs.setPromotionIsTaxable(
                    tempAttr.getPromotionIsTaxable().equalsIgnoreCase(GENERIC_CONSTANTS.YES));
        }

        if (tempAttr.getPromotionLimit() == null) {
            INFO(m_logger, promoKey + "does not have promotion limit. Please check.");
            gcs.setNoCap(true);
            gcs.setNoCapOrig(true);
        } else {
            gcs.setCreditCap(tempAttr.getPromotionLimit());
            gcs.setCreditCapOrig(tempAttr.getPromotionLimit());
        }

        if (StringUtils.isBlank(tempAttr.getCreditIncludeFlagName())) {
            INFO(m_logger, promoKey + "does not have CreditIncludeFlagName. Please check.");
        } else {
            gcs.setCreditIncludeFlagName(tempAttr.getCreditIncludeFlagName());
        }

        if (StringUtils.isBlank(tempAttr.getCreditIncludeFlagValues())) {
            INFO(m_logger, promoKey + "does not have CreditIncludeFlagValues. Please check.");
        } else {
            gcs.addCreditIncludeFlagValues(tempAttr.getCreditIncludeFlagValues());
        }

        if (StringUtils.isBlank(tempAttr.getTaxResponseUnchanged())) {
            INFO(
                    m_logger, promoKey
                            + "does not have TaxResponseUnchanged. Will be defaulted to 'N'. Please check.");
        } else {
            gcs.setTaxCalculationMethodFromTaxResponseUnchanged(tempAttr.getTaxResponseUnchanged());
        }

        if (StringUtils.isBlank(tempAttr.getIncompatiblePromotions())) {
            INFO(m_logger, promoKey + "does not have IncompatiblePromotions. Please check.");
        } else {
            try {
                IncompatibilityList inc = CommonUtils.getObjectMapper().readValue(
                        tempAttr.getIncompatiblePromotions(), IncompatibilityList.class);
                gcs.setIncompatiblePromotions(inc);
            } catch (Exception e) {
                INFO(
                        m_logger,
                        methodKey + "Due parsing issues incompatibility condition is ignored for"
                                + StringUtils.SPACE + grantCI + "." + StringUtils.SPACE
                                + GENERIC_CONSTANTS.ERROR_PREFIX + ExceptionUtils.getStackTrace(e));
            }
        }

        if (tempAttr.getCreditIncludeAttributeValues() != null
                && !tempAttr.getCreditIncludeAttributeValues().isEmpty()) {
            gcs.setCreditIncludeAttributeValues(tempAttr.getCreditIncludeAttributeValues());
        }

        String jsonString = "";
        String jsonStringCreditBaseOffer = "";
        if (mtxResponsePricingCatalogItem.getCatalogItemInfo().getMetadataList() != null) {
            gcs.addTaxTemplates(
                    mtxResponsePricingCatalogItem.getCatalogItemInfo().getMetadataList());
            for (MtxPricingMetadataInfo pmi : mtxResponsePricingCatalogItem.getCatalogItemInfo().getMetadataList().stream().collect(
                    Collectors.toList())) {
                if ((pmi.getName().equalsIgnoreCase(CI_METADATA.TAX_INPUT))) {
                    jsonString = pmi.getValue();
                }
                if ((pmi.getName().equalsIgnoreCase(CI_METADATA.BASE_OFFER_TAX_INPUT))) {
                    jsonStringCreditBaseOffer = pmi.getValue();
                }
            }
        }

        if (gcs.getTaxTemplates() == null || gcs.getTaxTemplates().size() == 0) {
            INFO(
                    m_logger, promoKey
                            + "does not have credit tax template configured. Credit will be treated as not taxable. Please check.");
            gcs.setPromotionIsTaxable(false);
        }

        if (StringUtils.isBlank(jsonStringCreditBaseOffer)) {
            INFO(
                    m_logger, promoKey
                            + "does not have BaseOfferTaxInput MetadataList attribute configured. Please check.");
        } else {
            gcs.setCreditTaxBaseOfferRequestTemplate(jsonStringCreditBaseOffer);
        }
        gcs.setPostChangeServicePromo(isPostChangeServicePromo);
        stage.getCreditMetadataMap().put(gcs.getGrantOfferCi(), gcs.shallowClone());
        return gcs;
    }

    public static void updateCreditWithPurchasedOfferExtension(String loggingKey,
                                                               GlobalCreditStage gcs,
                                                               VisiblePurchasedOfferExtension poe)
            throws PaymentAdviceException {
        final String methodKey = loggingKey + " updateCreditWithPurchasedOfferExtension: ";
        final String promoKey = methodKey + gcs.getGrantOfferCi() + StringUtils.SPACE;
        INFO(m_logger, promoKey);

        if (StringUtils.isNotBlank(poe.getDiscountCalculationMethod())
                && CREDIT_CONSTANTS.CALCULATION_METHOD_READ_METADATA.equalsIgnoreCase(
                        poe.getDiscountCalculationMethod())) {
            // If offer instance level value is not read metadata instance do not do anything just
            // return
            INFO(
                    m_logger,
                    promoKey + "Offer Instance level Discount Calculation Method is "
                            + poe.getDiscountCalculationMethod() + StringUtils.SPACE
                            + ". No Overriding will be done from offer instance values.");
            return;
        } else if (StringUtils.isBlank(poe.getDiscountCalculationMethod())
                && StringUtils.isNotBlank(gcs.getDiscountCalculationMethod())
                && CREDIT_CONSTANTS.CALCULATION_METHOD_READ_METADATA.equalsIgnoreCase(
                        gcs.getDiscountCalculationMethod())) {
            // If TemplateAttribute level setup is not read metadata instance and there is no
            // overriding here...
            // do not do anything just return
            INFO(
                    m_logger,
                    promoKey + "Discount Calculation Method is not present at Offer Instance level."
                            + StringUtils.SPACE
                            + "Template attribute level Discount Calculation Method is "
                            + gcs.getDiscountCalculationMethod() + StringUtils.SPACE
                            + ". No Overriding will be done from offer instance values.");
            return;
        }

        String offerType = poe.getOfferType();
        String grantofferType = gcs.getGrantOfferType();
        if (StringUtils.isNotBlank(offerType) && Stream.of(
                OFFER_CONSTANTS.OFFER_TYPE_PROMO, OFFER_CONSTANTS.OFFER_TYPE_GIFT).noneMatch(
                        otype -> (otype.equalsIgnoreCase(offerType)))) {
            // If offer instance level value is not Promo or Gift and do not do anything just return
            INFO(
                    m_logger,
                    promoKey + "OfferType in Offer Instance is " + poe.getOfferType()
                            + StringUtils.SPACE
                            + ". No Overriding will be done from offer instance values.");
            return;
        } else if (StringUtils.isBlank(poe.getOfferType())
                && StringUtils.isNotBlank(gcs.getGrantOfferType())
                && Stream.of(
                        OFFER_CONSTANTS.OFFER_TYPE_PROMO,
                        OFFER_CONSTANTS.OFFER_TYPE_GIFT).noneMatch(
                                otype -> (otype.equalsIgnoreCase(grantofferType)))) {
            // If TemplateAttribute level setup is not Promo and there is no overriding here...
            // do not do anything just return
            INFO(
                    m_logger,
                    promoKey + "OfferType is not present in Offer Instance. " + StringUtils.SPACE
                            + "OfferType in Template Attribute is " + gcs.getGrantOfferType()
                            + StringUtils.SPACE
                            + ". No Overriding will be done from offer instance values.");
            return;
        }

        if (StringUtils.isNotBlank(poe.getClassCode())) {
            INFO(
                    m_logger, promoKey
                            + "Overwrite ClassCode with value from grant offer instance VisiblePurchasedOfferExtension.");
            gcs.setClassCode(poe.getClassCode());
        }

        if (StringUtils.isNotBlank(poe.getConsumableBalanceName())) {
            INFO(
                    m_logger, promoKey
                            + "Overwrite ConsumableBalanceName with value from grant offer instance VisiblePurchasedOfferExtension.");
            gcs.setConsumableBalanceName(poe.getConsumableBalanceName());
        }

        if (StringUtils.isNotBlank(poe.getCreditGrantType())) {
            INFO(
                    m_logger, promoKey
                            + "Overwrite CreditGrantType with value from grant offer instance VisiblePurchasedOfferExtension.");
            gcs.setCreditGrantType(poe.getCreditGrantType());
        }

        if (StringUtils.isNotBlank(gcs.getCreditGrantType())
                && CREDIT_CONSTANTS.GRANT_TYPE_PERCENTAGE.equalsIgnoreCase(
                        gcs.getCreditGrantType())) {
            if (poe.getChargeAmount() == null) {
                INFO(
                        m_logger,
                        promoKey + "Percentage is not supplied as charge amountfor grant type "
                                + CREDIT_CONSTANTS.GRANT_TYPE_PERCENTAGE + StringUtils.SPACE
                                + ". promotion " + StringUtils.SPACE + gcs.getPromotionName()
                                + StringUtils.SPACE + "will be ignored.");
            } else if (poe.getChargeAmount().signum() <= 0) {
                INFO(
                        m_logger,
                        promoKey + "Invalid Percentage is supplied as charge amountfor grant type "
                                + CREDIT_CONSTANTS.GRANT_TYPE_PERCENTAGE + StringUtils.SPACE
                                + ". promotion " + StringUtils.SPACE + gcs.getPromotionName()
                                + StringUtils.SPACE + "will be ignored.");
            } else {
                gcs.setApplicableGrantPercentage(poe.getChargeAmount());
            }
        }

        if (StringUtils.isNotBlank(poe.getDiscountCalculationMethod())) {
            INFO(
                    m_logger, promoKey
                            + "Overwrite DiscountCalculationMethod with value from grant offer instance VisiblePurchasedOfferExtension.");
            gcs.setDiscountCalculationMethod(poe.getDiscountCalculationMethod());
        }

        if (StringUtils.isNotBlank(poe.getCreditIncludeFlagName())) {
            INFO(
                    m_logger, promoKey
                            + "Overwrite CreditIncludeFlagName with value from grant offer instance VisiblePurchasedOfferExtension.");
            gcs.setCreditIncludeFlagName(poe.getCreditIncludeFlagName());
        }

        if (StringUtils.isNotBlank(poe.getCreditIncludeFlagValues())) {
            INFO(
                    m_logger, promoKey
                            + "Overwrite CreditIncludeFlagValues with value from grant offer instance VisiblePurchasedOfferExtension.");
            gcs.clearCreditIncludeFlagValues();
            gcs.addCreditIncludeFlagValues(poe.getCreditIncludeFlagValues());

        }

        if (StringUtils.isNotBlank(poe.getPromotionIsTaxable())) {
            INFO(
                    m_logger, promoKey
                            + "Overwrite PromotionIsTaxable with value from grant offer instance VisiblePurchasedOfferExtension.");
            gcs.setPromotionIsTaxable(
                    GENERIC_CONSTANTS.YES.equalsIgnoreCase(poe.getPromotionIsTaxable().trim()));
        }

        if (StringUtils.isNotBlank(poe.getPromotionName())) {
            INFO(
                    m_logger, promoKey
                            + "Overwrite PromotionName with value from grant offer instance VisiblePurchasedOfferExtension.");
            gcs.setPromotionName(poe.getPromotionName());
        }

        if (StringUtils.isNotBlank(poe.getPromotionPriority())) {
            if (StringUtils.isNumeric(poe.getPromotionPriority())) {
                INFO(
                        m_logger, promoKey
                                + "Overwrite PromotionPriority with value from grant offer instance VisiblePurchasedOfferExtension.");
                gcs.setCreditPriority(Long.parseLong(poe.getPromotionPriority()));
            } else {
                INFO(
                        m_logger, promoKey
                                + "Invalid PromotionPriority in from grant offer instance VisiblePurchasedOfferExtension.");
            }
        }

        if (StringUtils.isNotBlank(poe.getRedeemGoodType())) {
            INFO(
                    m_logger, promoKey
                            + "Overwrite RedeemGoodType with value from grant offer instance VisiblePurchasedOfferExtension.");
            gcs.setRedeemGoodType(poe.getRedeemGoodType());
        }

        if (StringUtils.isNotBlank(poe.getRedeemOffer())) {
            INFO(
                    m_logger, promoKey
                            + "Overwrite RedeemOffer with value from grant offer instance VisiblePurchasedOfferExtension.");
            gcs.setRedeemOfferCi(poe.getRedeemOffer());
        }

        if (poe.getMinimumCharge() != null) {
            INFO(
                    m_logger, promoKey
                            + "Overwrite MinimumCharge with value from grant offer instance VisiblePurchasedOfferExtension.");
            gcs.setMinimumCharge(poe.getMinimumCharge());
        }

        if (poe.getPromotionLimit() != null) {
            INFO(
                    m_logger, promoKey
                            + "Overwrite PromotionLimit with value from grant offer instance VisiblePurchasedOfferExtension.");
            gcs.setCreditCap(poe.getPromotionLimit());
            gcs.setCreditCapOrig(poe.getPromotionLimit());
        }

        if (StringUtils.isBlank(poe.getIncompatiblePromotions())) {
            INFO(
                    m_logger, promoKey + gcs.getGrantOfferCi() + StringUtils.SPACE
                            + "does not have IncompatiblePromotions. Please check.");
        } else {
            try {
                IncompatibilityList inc = CommonUtils.getObjectMapper().readValue(
                        poe.getIncompatiblePromotions(), IncompatibilityList.class);
                gcs.setIncompatiblePromotions(inc);
            } catch (Exception e) {
                INFO(
                        m_logger,
                        promoKey + "Due parsing issues incompatibility condition is ignored for"
                                + StringUtils.SPACE + gcs.getGrantOfferCi() + "."
                                + StringUtils.SPACE + GENERIC_CONSTANTS.ERROR_PREFIX
                                + ExceptionUtils.getStackTrace(e));
            }
        }

        if (StringUtils.isNotBlank(poe.getTaxResponseUnchanged())) {
            INFO(
                    m_logger, promoKey
                            + "Overwrite TaxResponseUnchanged with value from grant offer instance VisiblePurchasedOfferExtension.");
            gcs.setTaxCalculationMethodFromTaxResponseUnchanged(poe.getTaxResponseUnchanged());
        }

        if (StringUtils.isNotBlank(poe.getApplicableOfferName())
                && gcs.getVisibleTemplate().getApplicableOfferName().contains(
                        poe.getApplicableOfferName())) {
            INFO(
                    m_logger, promoKey
                            + "Overwrite ApplicableOfferName with value from grant offer instance VisiblePurchasedOfferExtension.");
            gcs.setApplicableCiCsv(poe.getApplicableOfferName());
        } else if (StringUtils.isNotBlank(poe.getApplicableOfferName())
                && !gcs.getVisibleTemplate().getApplicableOfferName().contains(
                        poe.getApplicableOfferName())) {
            INFO(
                    m_logger, promoKey
                            + "ApplicableOfferName is not from ApplicableOfferNames configured in template attributes of grant offer. It will be ignored.");
        }
    }

    public static void updateCreditStageWithPaynowStage(String loggingKey,
                                                        AdviceDataStage builder,
                                                        CreditStage cs) {
        final String methodName = "updateCreditStageWithPaynowStage: ";
        for (ServiceStage ps : builder.getPayNowMap().values()) {
            if (ps.getCatalogItemExternalId().trim().equalsIgnoreCase(
                    cs.getApplicableCiExternalId().trim())) {
                cs.setApplicableServiceStage(ps);
                INFO(
                        m_logger,
                        loggingKey + methodName + "Linked promo " + cs.getPromotionName()
                                + " with paynow stage with external id "
                                + cs.getApplicableCiExternalId());
                break;
            }
        }
    }

    /**
     * Check conditions for flag balaces. If conditions are met, mark grant amounts as
     * non-transferable. consumable amount can not be controlled so do not touch that.
     */
    public static void updateFlagBalanceConditions(String loggingKey,
                                                   AdviceDataStage builder,
                                                   MtxResponseSubscription subscription,
                                                   CreditStage cs) {
        final String methodName = "updateFlagBalanceConditions: ";

        if (cs.getAvailableCreditsGrant() == null || cs.getAvailableCreditsGrant().signum() <= 0) {
            // consumable balance will not be affected by flag balances.
            return;
        }

        String flagBalance = cs.getCreditIncludeFlagName();
        BigDecimal flagBalVal = null;
        if (StringUtils.isBlank(flagBalance)) {
            return;
        }

        if (cs.getCreditIncludeFlagValues() == null
                || cs.getCreditIncludeFlagValues().size() == 0) {
            return;
        }

        if (subscription.getBalanceArray() == null) {
            return;
        }
        boolean includeConditionMet = false;
        boolean foundFlagBalance = false;
        for (MtxBalanceInfo bInfo : subscription.getBalanceArray()) {
            foundFlagBalance = false;
            if (!bInfo.getName().equals(flagBalance)) {
                continue;
            } else {
                if (!CommonUtils.isBalanceActiveOnDate(
                        loggingKey, m_logger, bInfo, builder.getCycleStartTime())) {
                    continue;
                }
                foundFlagBalance = true;
                flagBalVal = bInfo.getAmount().negate();
            }

            // Flag Balance found with subscriber check values.
            // Check if include needs to applied
            Set<String> includeValArray = cs.getCreditIncludeFlagValues();
            for (String fBal : includeValArray) {
                if (!StringUtils.isNumeric(fBal)) {
                    continue;
                }

                BigDecimal includeVal = new BigDecimal(fBal);

                if (flagBalVal.compareTo(includeVal) == 0) {
                    // flag balance value is same as include value.
                    // Mark grant as non-transferable
                    includeConditionMet = true;
                    break;
                }
            }
            if (foundFlagBalance) {
                break;
            }
        }
        if (!foundFlagBalance) {
            INFO(
                    m_logger,
                    loggingKey + methodName + "Flag Balance " + flagBalance + " was not found. "
                            + " In this case " + cs.getPromotionName()
                            + " credits may be redeemed from Grant.");

        } else if (foundFlagBalance && includeConditionMet) {
            INFO(
                    m_logger,
                    loggingKey + methodName + "Flag Balance " + flagBalance + " has value "
                            + flagBalVal + ". " + " In this case " + cs.getPromotionName()
                            + " credits will be redeemed from Grant.");
        } else {
            INFO(
                    m_logger,
                    loggingKey + methodName + "Flag Balance " + flagBalance + " has value "
                            + flagBalVal + ". " + " Expected values are "
                            + cs.getCreditIncludeFlagValues() + ". " + " In this case "
                            + cs.getPromotionName() + " credits will not be redeemed from Grant.");
            cs.updateGrantsAsNonTransferable();
        }
    }

    public static String getFreezeGrantReasons(String loggingKey,
                                               MtxResponseSubscription subscription,
                                               CreditStage cs,
                                               VisiblePurchasedOfferExtension toBePoAttr,
                                               VisibleSubscriberExtension toBeSubAttr)
            throws IllegalAccessException, InvocationTargetException, NoSuchMethodException,
            IntrospectionException {
        final String methodName = "getFreezeGrantReasons: ";

        if (cs.getGlobalCreditStage().getCreditIncludeAttributeValues() == null
                || cs.getGlobalCreditStage().getCreditIncludeAttributeValues().isEmpty()) {
            return FREEZE_GRANT_REASONS.NONE;
        }

        VisibleSubscriberExtension subAttr = (VisibleSubscriberExtension) subscription.getAttr();
        VisiblePurchasedOfferExtension poAttr = null;
        boolean newAttr = false;

        if (toBePoAttr != null) {
            poAttr = toBePoAttr;
            newAttr = true;
        }

        if (toBeSubAttr != null) {
            subAttr = toBeSubAttr;
            newAttr = true;
        }

        if (!newAttr) {
            if (subscription.getPurchasedOfferArray() == null
                    || subscription.getPurchasedOfferArray().isEmpty()) {
                if (toBePoAttr == null) {
                    cs.updateGrantsAsNonTransferable(FREEZE_GRANT_REASONS.NO_APPLICABLE_OFFERS);
                }
                return FREEZE_GRANT_REASONS.NO_APPLICABLE_OFFERS;
            }

            boolean foundApplicableOffer = false;

            for (MtxPurchasedOfferInfo poi : subscription.getPurchasedOfferArray()) {
                if (StringUtils.isBlank(poi.getCatalogItemExternalId())) {
                    continue;
                }

                MtxTimestamp curTimestmp = new MtxTimestamp((new Date()).getTime());
                if (!CommonUtils.isOfferActiveOnDate(loggingKey, m_logger, poi, curTimestmp)) {
                    continue;
                }

                if (!cs.getApplicableCiExternalId().equalsIgnoreCase(
                        poi.getCatalogItemExternalId())) {
                    continue;
                } else {
                    foundApplicableOffer = true;
                    poAttr = (VisiblePurchasedOfferExtension) poi.getAttr();
                }

                if (foundApplicableOffer) {
                    break;
                }
            }

            if (!foundApplicableOffer) {
                if (toBePoAttr == null) {
                    cs.updateGrantsAsNonTransferable(FREEZE_GRANT_REASONS.NO_APPLICABLE_OFFERS);
                }
                return FREEZE_GRANT_REASONS.NO_APPLICABLE_OFFERS;
            }

            if (poAttr == null) {
                INFO(
                        m_logger, loggingKey + methodName
                                + "Applicable offer does not have attributes. Promo eligibility will not change. ");
                return FREEZE_GRANT_REASONS.NONE;
            }
        }

        INFO(m_logger, loggingKey + methodName + poAttr.toJson());

        String blockPromoExpressions = "";
        for (String attrRule : cs.getGlobalCreditStage().getCreditIncludeAttributeValues()) {
            if (!attrRule.contains(GENERIC_CONSTANTS.EQUALS)) {
                INFO(
                        m_logger, loggingKey + methodName
                                + "Ignoring Attribute expression without '=' sign. " + attrRule);
                continue;
            }

            String[] ruleSplit = attrRule.split("=");
            String expectedAttrValue = ruleSplit[1].trim();

            if (StringUtils.isBlank(expectedAttrValue)) {
                INFO(
                        m_logger,
                        loggingKey + methodName
                                + "Ignoring Attribute expression without expected value. "
                                + attrRule);
                continue;
            }

            if (!attrRule.contains(GENERIC_CONSTANTS.DOT)) {
                INFO(
                        m_logger, loggingKey + methodName
                                + "Ignoring Attribute expression without '.' sign. " + attrRule);
                continue;
            }

            String[] tempAttrSplit = ruleSplit[0].split(GENERIC_CONSTANTS.DOT_REGEX);
            String externsionName = tempAttrSplit[0];
            String fieldName = tempAttrSplit[1];

            String actualAttrValue = "";

            if (MDC_NAMES.PURCHASED_OFFER_EXTENSION.equalsIgnoreCase(externsionName)
                    && poAttr != null) {
                actualAttrValue = CommonUtils.getContainerFieldAsString(poAttr, fieldName);
            } else if (MDC_NAMES.SUBSCRIBER_EXTENSION.equalsIgnoreCase(externsionName)
                    && subAttr != null) {
                actualAttrValue = CommonUtils.getContainerFieldAsString(subAttr, fieldName);
            } else {
                INFO(
                        m_logger,
                        loggingKey + methodName
                                + "Ignoring attribute expression with unknown container.  "
                                + attrRule);
                continue;
            }

            if (expectedAttrValue.equalsIgnoreCase(actualAttrValue)) {
                // If one rule is satisfied, no need to evaluate further. Logical OR
                INFO(
                        m_logger,
                        loggingKey + methodName
                                + "Promotion is usable based on attribute expression .  " + attrRule
                                + " Actual attribute value is " + actualAttrValue);
                return FREEZE_GRANT_REASONS.NONE;
            } else {
                blockPromoExpressions += "|" + attrRule;
            }
        }

        if (StringUtils.isNotBlank(blockPromoExpressions)) {
            // There are evaluated expressions that block promo
            INFO(
                    m_logger,
                    loggingKey + methodName
                            + "Promotion is not usable based on attribute expression .  "
                            + blockPromoExpressions + "|");
            if (toBePoAttr == null) {
                cs.updateGrantsAsNonTransferable(FREEZE_GRANT_REASONS.OFFER_ATTRIBUTE);
            }
            return FREEZE_GRANT_REASONS.OFFER_ATTRIBUTE;
        }

        return FREEZE_GRANT_REASONS.NONE;
    }

    /**
     * Check PurchasedOfferExtension and Subscriber Extension. If attributes are present, apply
     * rules. If no attributes are configured, promo should not be blocked..
     * 
     * @throws NoSuchMethodException
     * @throws InvocationTargetException
     * @throws IllegalAccessException
     * @throws IntrospectionException
     */
    public static void applyCreditIncludeAttributeRules(String loggingKey,
                                                        MtxResponseSubscription subscription,
                                                        CreditStage cs)
            throws IllegalAccessException, InvocationTargetException, NoSuchMethodException,
            IntrospectionException {
        final String methodName = "applyCreditIncludeAttributeRules: ";
        String freezeReason = getFreezeGrantReasons(loggingKey, subscription, cs, null, null);
        if (FREEZE_GRANT_REASONS.OFFER_ATTRIBUTE.equalsIgnoreCase(freezeReason)) {
            cs.updateGrantsAsNonTransferable(FREEZE_GRANT_REASONS.OFFER_ATTRIBUTE_AS_IS);
            INFO(m_logger, loggingKey + methodName + FREEZE_GRANT_REASONS.OFFER_ATTRIBUTE_AS_IS);
        }
    }

    public static void processSubscriptionBasedCredit(String loggingKey,
                                                      String route,
                                                      MtxResponseSubscription subscription,
                                                      MtxResponsePricingCatalogItem ciPricing,
                                                      AdviceDataStage stage,
                                                      // If promo is used here reduce it for new
                                                      // stage
                                                      AdviceDataStage reservedStage,
                                                      MtxPurchasedOfferInfo poi,
                                                      FuturePromo futurePromo,
                                                      // apply credit for this Ci only
                                                      String applicableCiId,
                                                      boolean isPostChangeServicePromo,
                                                      boolean keepZeroValuePromo)
            throws Exception {
        final String methodKey = loggingKey + " processSubscriptionBasedCredit: ";
        INFO(m_logger, methodKey);
        /****************************************************************************************************/
        GlobalCreditStage gcs = null;
        String grantCiId = "";
        // avoid calling sub man api to get CI when possible.
        if (futurePromo != null) {
            grantCiId = futurePromo.getGrantOfferCI().trim();
        } else if (poi != null) {
            grantCiId = poi.getCatalogItemExternalId();
        }

        if (StringUtils.isNotBlank(grantCiId)) {
            gcs = stage.getCreditMetadataMap().get(grantCiId);
        }

        if (gcs == null) {
            gcs = AdviceUtils.getGlobalCreditStageForGrantCI(
                    loggingKey, ciPricing, stage, isPostChangeServicePromo);
        }

        /****************************************************************************************************/

        if (gcs == null) {
            // For what ever credit was not created
            INFO(m_logger, methodKey + "Global Credit Stage was not created. Skip.");
            return;
        }

        if (gcs.getVisibleTemplate() == null
                || StringUtils.isBlank(gcs.getVisibleTemplate().getApplicableOfferName())) {
            INFO(
                    m_logger,
                    methodKey
                            + "Applicable offers are not configured in template attributes of grant catalog item. Ignore grant offer : "
                            + grantCiId);
            return;
        } else if (StringUtils.isNotBlank(applicableCiId)
                && !gcs.getVisibleTemplate().getApplicableOfferName().contains(applicableCiId)) {
            INFO(
                    m_logger,
                    methodKey + "Provided applicable offer, " + applicableCiId
                            + " is not listed in template attributes of grant catalog item. Ignore grant offer : "
                            + grantCiId);
            return;
        }

        if (poi != null && poi.getAttr() != null
                && (poi.getAttr() instanceof VisiblePurchasedOfferExtension)) {
            VisiblePurchasedOfferExtension poe = (VisiblePurchasedOfferExtension) poi.getAttr();
            AdviceUtils.updateCreditWithPurchasedOfferExtension(loggingKey, gcs, poe);
        }

        if (StringUtils.isNotBlank(applicableCiId)) {
            gcs.setApplicableCiCsv(applicableCiId);
        }
        if (futurePromo != null) {
            if (futurePromo.getAttr() != null) {
                VisiblePromoExtension pe = futurePromo.getAttr();
                if (pe.getPromotionLimit() != null) {
                    gcs.setCreditCap(pe.getPromotionLimit());
                }
                if (StringUtils.isNotBlank(pe.getClassCode())) {
                    gcs.setClassCode(pe.getClassCode());
                }
                if (StringUtils.isNotBlank(pe.getPromotionName())) {
                    gcs.setPromotionName(pe.getPromotionName());
                }
            }
        }

        stage.getCreditMetadataMap().put(gcs.getGrantOfferCi(), gcs);

        if (StringUtils.isBlank(gcs.getGrantOfferType())) {
            INFO(m_logger, methodKey + "OfferType is blank. Not a promotion.");
            return;
        }

        String offerType = gcs.getGrantOfferType();
        if (Stream.of(OFFER_CONSTANTS.OFFER_TYPE_PROMO, OFFER_CONSTANTS.OFFER_TYPE_GIFT).noneMatch(
                otype -> (otype.equalsIgnoreCase(offerType)))) {
            // if offertype is not promo do not create credit
            INFO(
                    m_logger, methodKey + "OfferType is " + gcs.getGrantOfferType()
                            + StringUtils.SPACE + ". Neither a promotion nor a Gift.");
            return;
        }

        Set<String> applicableCiSet = gcs.getApplicableCiSet();
        if (stage.getAdviceFor() == AdviceDataStage.Advice.PURCHASE) {
            // For Purchase service a promo is not required unless applicable offer is being
            // purchased.
            boolean keepPromo = false;
            for (String applicableCi : applicableCiSet) {
                if (stage.getCiListInPurchaseService().contains(applicableCi)) {
                    keepPromo = true;
                    break;
                }
            }

            if (!keepPromo) {
                INFO(
                        m_logger,
                        methodKey + "Promo " + gcs.getPromotionName() + StringUtils.SPACE
                                + "is not usable by " + stage.getCiListInPurchaseService()
                                + StringUtils.SPACE + " promo will be skipped.");
                return;
            }
        }

        if (stage.getAdviceFor() == AdviceDataStage.Advice.CHANGE) {
            // For Change service a promo is not required unless applicable offer is being
            // purchased.
            boolean keepPromo = false;
            for (String applicableCi : applicableCiSet) {
                for (ServiceStage ps : stage.getPayNowMap().values()) {
                    if (ps.getCatalogItemExternalId().equalsIgnoreCase(applicableCi)) {
                        keepPromo = true;
                        break;
                    }
                }
                if (keepPromo) {
                    break;
                }
            }

            if (!keepPromo) {
                INFO(
                        m_logger, methodKey + "Promo " + gcs.getPromotionName() + StringUtils.SPACE
                                + "is not usable by new offer, promo will be skipped.");
                return;
            }
        }

        for (MtxBalanceInfo bi : subscription.getBalanceArray()) {
            // Consumable balance can be overridden in offer instance. Eventhough highly unlikely
            if (StringUtils.isNotBlank(gcs.getConsumableBalanceName())
                    && gcs.getConsumableBalanceName().trim().equalsIgnoreCase(bi.getName())) {
                gcs.setAvailableCreditsConsumable(
                        CommonUtils.getBalanceAmountOnDate(bi, stage.getCycleStartTime()));
            }
        }

        if (CREDIT_CONSTANTS.GRANT_TYPE_PERCENTAGE.equals(gcs.getCreditGrantType())
                && !CREDIT_CONSTANTS.CALCULATION_METHOD_READ_OFFER_INSTANCE.equalsIgnoreCase(
                        gcs.getDiscountCalculationMethod())) {
            INFO(
                    m_logger,
                    methodKey
                            + "Percentage grant type can only be used with discount calculation method of "
                            + CREDIT_CONSTANTS.CALCULATION_METHOD_READ_OFFER_INSTANCE
                            + StringUtils.SPACE
                            + "Percentage value has to be read from Charge Amount of grant offer. Ignoring promotion "
                            + StringUtils.SPACE + gcs.getPromotionName());
            return;
        } else if (CREDIT_CONSTANTS.GRANT_TYPE_PERCENTAGE.equals(gcs.getCreditGrantType())
                && CREDIT_CONSTANTS.CALCULATION_METHOD_READ_OFFER_INSTANCE.equalsIgnoreCase(
                        gcs.getDiscountCalculationMethod())) {
            for (String applicableCi : applicableCiSet) {
                CreditStage cs = new CreditStage(gcs, applicableCi);
                updateCreditStageWithPaynowStage(loggingKey, stage, cs);
                if (cs.getApplicableServiceStage() == null) {
                    INFO(
                            m_logger,
                            methodKey
                                    + "Applicable CI for Percentage based promo is not in advice. Promo "
                                    + "Grant can not be calculated." + cs.getPromotionName()
                                    + StringUtils.SPACE + "will be Ignored.");
                    // if a paynowstage is not linked to a promo that means applicable offer is not
                    // part of advice. So ignore credit
                    continue;
                } else if (cs.getApplicableServiceStage().getProratedDiscountPrice() == null) {
                    INFO(
                            m_logger,
                            methodKey
                                    + "Discount price for Applicable CI is invalid. Percentage Promo "
                                    + StringUtils.SPACE + "Grant can not be calculated."
                                    + cs.getPromotionName() + StringUtils.SPACE
                                    + "will be Ignored.");
                    cs.setPercentageGrantToZero();
                } else if (cs.getApplicableGrantPercentage() == null
                        || cs.getApplicableGrantPercentage().signum() <= 0
                        || cs.getApplicableGrantPercentage().compareTo(new BigDecimal("100")) > 0) {
                    INFO(
                            m_logger,
                            methodKey + "Invalid value for grant percentage. Promo "
                                    + StringUtils.SPACE + "Grant can not be calculated."
                                    + cs.getPromotionName() + StringUtils.SPACE
                                    + "will be Ignored.");
                    cs.setPercentageGrantToZero();
                } else {
                    // MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
                    // searchData.setExternalId(subscription.getExternalId());
                    BigDecimal derivedGrantAmount = cs.getApplicableServiceStage().getProratedDiscountPrice().multiply(
                            cs.getApplicableGrantPercentage()).divide(new BigDecimal("100"));
                    cs.setPercentageGrant(derivedGrantAmount);
                    updateFlagBalanceConditions(loggingKey, stage, subscription, cs);
                    applyCreditIncludeAttributeRules(loggingKey, subscription, cs);
                    stage.getCreditMap().put(cs.getPromoOfferPair(), cs);
                    gcs.getCreditMap().put(cs.getApplicableCiExternalId(), cs);
                }
            }
            gcs.setAvailableCreditsGrantFromPercentageGrants();
        } else if (poi != null && poi.getRequiredBalanceArray() != null) {
            if (poi.getRequiredBalanceArray().size() > 1) {
                INFO(
                        m_logger, methodKey + grantCiId + StringUtils.SPACE
                                + "has multiple required balances. Offer needs to have a single grant balance. It will be skipped as purchased offer instance credit. ");
                return;
            }

            MtxRequiredBalanceInfo rbi = poi.getRequiredBalanceArray().get(0);
            for (MtxBalanceInfo bi : subscription.getBalanceArray()) {
                if ((rbi.getResourceId().longValue() == bi.getResourceId().longValue())
                        && (rbi.getTemplateId().longValue() == bi.getTemplateId().longValue())
                        && (rbi.getClassId().longValue() == bi.getClassId().longValue())) {
                    gcs.setGrantBalanceName(bi.getName());
                    gcs.setAvailableCreditsGrant(
                            CommonUtils.getBalanceAmountOnDate(bi, stage.getCycleStartTime()));

                    if (reservedStage != null && reservedStage.getCreditMap() != null
                            && !reservedStage.getCreditMap().isEmpty()) {
                        // Reduce consumables first and grants next
                        for (CreditStage csReserved : reservedStage.getCreditMap().values()) {
                            if (csReserved.getGrantOfferCi().equalsIgnoreCase(
                                    gcs.getGrantOfferCi())) {
                                if (csReserved.getRedeemableCredits().compareTo(
                                        gcs.getAvailableCredits()) >= 0) {
                                    // all credits reserved.
                                    gcs.setAvailableCreditsConsumable(BigDecimal.ZERO);
                                    gcs.setAvailableCreditsGrant(BigDecimal.ZERO);
                                } else if (csReserved.getRedeemableCredits().compareTo(
                                        gcs.getAvailableCreditsConsumable()) <= 0) {
                                    // reserved credits are less than consumables
                                    gcs.setAvailableCreditsConsumable(
                                            gcs.getAvailableCreditsConsumable().subtract(
                                                    csReserved.getRedeemableCredits()));
                                } else {
                                    // Reserved credits are more than consumables. All credits are
                                    // not reserved. So Available credits is more than reserved.
                                    BigDecimal reservedFromGrant = csReserved.getRedeemableCredits().subtract(
                                            gcs.getAvailableCreditsConsumable());
                                    gcs.setAvailableCreditsGrant(
                                            gcs.getAvailableCreditsGrant().subtract(
                                                    reservedFromGrant));
                                    gcs.setAvailableCreditsConsumable(BigDecimal.ZERO);
                                }
                            }
                        }
                    }
                }
            }
        }

        if (futurePromo != null) {
            // In case of any pre-existing grant csp grant is ignored.
            BigDecimal newGrant = futurePromo.getGrantAmount();
            if (newGrant != null && newGrant.signum() > 0) {
                for (String applicableCi : applicableCiSet) {
                    CreditStage cs = new CreditStage(gcs, applicableCi);
                    updateCreditStageWithPaynowStage(loggingKey, stage, cs);
                    if (cs.getApplicableServiceStage() == null) {
                        INFO(
                                m_logger,
                                methodKey
                                        + "Applicable CI for Future promo is not in advice. Promo "
                                        + cs.getPromotionName() + StringUtils.SPACE
                                        + "will be Ignored.");
                        // if a paynowstage is not linked to a promo that means applicable offer is
                        // not part of advice. So ignore credit
                        continue;
                    } else if (cs.getGlobalCreditStage().getAvailableCredits().signum() <= 0) {
                        cs.addToFutureGrant(newGrant);
                    }

                    updateFlagBalanceConditions(loggingKey, stage, subscription, cs);
                    applyCreditIncludeAttributeRules(loggingKey, subscription, cs);
                    stage.getCreditMap().put(cs.getPromoOfferPair(), cs);
                    gcs.getCreditMap().put(cs.getApplicableCiExternalId(), cs);
                }
            }
        }
        gcs.setAvailableCredits(
                gcs.getAvailableCreditsGrant().add(gcs.getAvailableCreditsConsumable()));
        if (CREDIT_CONSTANTS.GRANT_TYPE_PERCENTAGE.equals(gcs.getCreditGrantType())
                && CREDIT_CONSTANTS.CALCULATION_METHOD_READ_OFFER_INSTANCE.equalsIgnoreCase(
                        gcs.getDiscountCalculationMethod())) {

            if (gcs.getAvailableCredits().signum() > 0) {
                // Ignore credit if there is no amount
                INFO(
                        m_logger,
                        methodKey + "Using Purchased Grant Offer Instance" + StringUtils.SPACE
                                + grantCiId + StringUtils.SPACE
                                + "added percentage based promotion " + StringUtils.SPACE
                                + gcs.getPromotionName() + StringUtils.SPACE + gcs.toJson());
            } else {
                INFO(
                        m_logger,
                        methodKey + "Percentage based promotion" + StringUtils.SPACE
                                + gcs.getPromotionName() + StringUtils.SPACE + " for "
                                + StringUtils.SPACE + grantCiId + StringUtils.SPACE
                                + "was not added." + StringUtils.SPACE + gcs.toJson());
            }
        } else if (poi == null && AdviceDataStage.Advice.CHANGE == stage.getAdviceFor()) {
            if (gcs.getAvailableCredits().signum() > 0) {
                // Ignore credit if there is no amount
                INFO(
                        m_logger,
                        methodKey + "Added future grant for grantCi" + StringUtils.SPACE + grantCiId
                                + StringUtils.SPACE + gcs.getPromotionName() + StringUtils.SPACE
                                + gcs.toJson());
            }
        } else {
            if (gcs.getAvailableCredits().signum() > 0 || keepZeroValuePromo) {
                // Ignore credit if there is no amount
                for (String applicableCi : applicableCiSet) {
                    CreditStage cs = new CreditStage(gcs, applicableCi);
                    updateCreditStageWithPaynowStage(loggingKey, stage, cs);
                    if (cs.getApplicableServiceStage() == null) {
                        // if a paynowstage is not linked to a promo that means applicable offer is
                        // not part of advice. So ignore credit
                        continue;
                    } else if (cs.getApplicableServiceStage() != null
                            && cs.getApplicableServiceStage().isSkipRenewal()) {
                        // Since offer does not need payment skip promo
                        stage.getCreditMap().put(cs.getPromoOfferPair(), cs);
                        cs.getGlobalCreditStage().getCreditMap().put(
                                cs.getApplicableCiExternalId(), cs);
                        INFO(
                                m_logger, methodKey + cs.getApplicableCiExternalId()
                                        + " does not need any payment. Skip promo.");
                        continue;
                    }
                    updateFlagBalanceConditions(loggingKey, stage, subscription, cs);
                    applyCreditIncludeAttributeRules(loggingKey, subscription, cs);
                    stage.getCreditMap().put(cs.getPromoOfferPair(), cs);
                    cs.getGlobalCreditStage().getCreditMap().put(
                            cs.getApplicableCiExternalId(), cs);
                    if (OFFER_CONSTANTS.OFFER_TYPE_GIFT.equalsIgnoreCase(cs.getGrantOfferType())) {
                        cs.getApplicableServiceStage().setAvailableGiftAmount(
                                cs.getApplicableServiceStage().getAvailableGiftAmount().add(
                                        cs.getAvailableCredits()));
                    }
                }
                INFO(
                        m_logger,
                        methodKey + "Using Purchased Grant Offer Instance" + StringUtils.SPACE
                                + grantCiId + StringUtils.SPACE + "added credit "
                                + StringUtils.SPACE + gcs.getPromotionName() + StringUtils.SPACE
                                + gcs.toJson());
            }
        }
    }

    /**
     * Update Credit Taxes.
     *
     * @param loggingKey
     * @param route
     * @param stage
     * @param subscription
     * @return
     * @throws JsonParseException
     * @throws JsonMappingException
     * @throws IOException
     * @throws PaymentAdviceException
     */
    public static void updateCreditTaxDetails(String loggingKey,
                                              String route,
                                              AdviceDataStage stage,
                                              MtxResponseSubscription subscription)
            throws PaymentAdviceException, JsonParseException, JsonMappingException, IOException {
        final String methodKey = loggingKey + " updateCreditTaxDetails: ";
        // Get List of taxable credits, calculate taxes for each of them.
        if (!stage.isAdviceWithTaxes() || stage.getCreditMap() == null
                || stage.getCreditMap().size() == 0) {
            return;
        }

        for (CreditStage creditStage : CommonUtils.emptyIfNull(stage.getCreditMap().values())) {
            if (!creditStage.isPromotionTaxable()) {
                String msg = creditStage.getClassCode() + " is not taxable. Skip.";
                INFO(m_logger, methodKey + msg);
                continue;
            }

            if (creditStage.getApplicableServiceStage().isSkipRenewal()) {
                String msg = creditStage.getApplicableServiceStage().getCatalogItemExternalId()
                        + " is not due for renewal next bill cycle. Skip.";
                INFO(m_logger, methodKey + msg);
                continue;
            }

            if (creditStage.getAvailableCredits() == null
                    || creditStage.getAvailableCredits().signum() <= 0) {
                String msg = creditStage.getClassCode() + " has no available credits. Skip.";
                INFO(m_logger, methodKey + msg);
                continue;
            }

            if (creditStage.getRedeemableCredits() == null
                    || creditStage.getRedeemableCredits().signum() <= 0) {
                String msg = creditStage.getClassCode() + " has no redeemable credits. Skip.";
                INFO(m_logger, methodKey + msg);
                continue;
            }

            INFO(
                    m_logger,
                    methodKey + "Calculate credit taxes for " + creditStage.getPromotionName()
                            + " for redeemable credit value " + creditStage.getRedeemableCredits());
            String promoTaxWithServicePrice = null;
            ServiceStage servicePs = null;
            if (stage.getVisibleOfferDetails(
                    creditStage.getApplicableCiExternalId().trim()) == null) {
                INFO(
                        m_logger,
                        methodKey + "VisibleOfferDetails is not created for applicable offer"
                                + StringUtils.SPACE + creditStage.getApplicableCiExternalId());
                promoTaxWithServicePrice = GENERIC_CONSTANTS.ERROR_PREFIX
                        + "VisibleOfferDetails is not created for applicable offer"
                        + StringUtils.SPACE + creditStage.getApplicableCiExternalId();
                setCreditTaxApiErrorMessage(
                        methodKey, creditStage,
                        LOG_MESSAGES.LOG_ERROR_CALCULATING + StringUtils.SPACE
                                + creditStage.getPromotionName() + StringUtils.SPACE
                                + LOG_MESSAGES.LOG_CREDIT_TAX + StringUtils.SPACE
                                + promoTaxWithServicePrice);
                continue;
            }

            // else {
            VisibleOfferDetails vod = stage.getVisibleOfferDetails(
                    creditStage.getApplicableCiExternalId());
            if (StringUtils.isBlank(vod.getTaxDetails())) {
                INFO(
                        m_logger,
                        methodKey
                                + "VisibleOfferDetails is found without any tax details for applicable offer"
                                + StringUtils.SPACE + creditStage.getApplicableCiExternalId());
                promoTaxWithServicePrice = GENERIC_CONSTANTS.ERROR_PREFIX
                        + "VisibleOfferDetails is found without any tax details for applicable offer"
                        + StringUtils.SPACE + creditStage.getApplicableCiExternalId();
            } else {
                if (stage.getServiceStage(creditStage.getApplicableCiExternalId()) != null) {
                    servicePs = stage.getServiceStage(creditStage.getApplicableCiExternalId());
                    INFO(
                            m_logger, methodKey + "Tax Response as promo:" + StringUtils.SPACE
                                    + creditStage.getTaxResponseAsPromo());
                    if (StringUtils.isBlank(creditStage.getTaxResponseAsPromo())) {
                        BigDecimal vendorPayableNonProrated = BigDecimal.ZERO;
                        if (servicePs.getPrevTaxResponse() != null
                                && servicePs.getPrevTaxResponse().getVendorPayableNonProrated() != null) {
                            vendorPayableNonProrated = servicePs.getPrevTaxResponse().getVendorPayableNonProrated();
                        }
                        if (StringUtils.isNotBlank(
                                creditStage.getCreditTaxBaseOfferRequestTemplate())) {
                            // @formatter:off
                                ServiceTaxRequestBuilder requestBuilder = (new ServiceTaxRequestBuilder())
                                        .withRequestTemplate(creditStage.getCreditTaxBaseOfferRequestTemplate())
                                        .withGrossPrice(servicePs.getGrossPrice())
                                        .withDiscountPrice(servicePs.getProratedDiscountPrice())
                                        .withVendorPayableNonProrated(vendorPayableNonProrated)
                                        .withVendorPayable(vendorPayableNonProrated)
                                        .withBrand(stage.getBrand());
                                // @formatter:on
                            ServiceTaxRequest taxRequest = requestBuilder.build();
                            if (StringUtils.isNotBlank(stage.getPayerExternalId())
                                    && !GENERIC_CONSTANTS.YES.equalsIgnoreCase(
                                            stage.getIgnorePayer())) {
                                taxRequest.setMsgID(
                                        creditStage.getClassCode()
                                                + TAX_CONSTANTS.MSG_FIELD_DELIMITER
                                                + TAX_CONSTANTS.MSG_FIELD_PAYER_TAX
                                                + stage.getPayerExternalId());
                            }
                            String taxBaseOfferDetails = getTaxDetailsWithoutRefTax(
                                    loggingKey, taxRequest, stage,
                                    servicePs.getPrevTaxResponse().getGeocode());

                            promoTaxWithServicePrice = taxBaseOfferDetails;
                        } else {
                            promoTaxWithServicePrice = servicePs.getTaxResponse();
                        }
                    }
                    promoTaxWithServicePrice = creditStage.getTaxResponseAsPromo();

                } else {
                    INFO(
                            m_logger, methodKey + "PayNowStage not found for applicable offer"
                                    + StringUtils.SPACE + creditStage.getApplicableCiExternalId());
                    promoTaxWithServicePrice = GENERIC_CONSTANTS.ERROR_PREFIX
                            + "PayNowStage not found for applicable offer" + StringUtils.SPACE
                            + creditStage.getApplicableCiExternalId();
                }
            }
            // }

            if (promoTaxWithServicePrice.startsWith(GENERIC_CONSTANTS.ERROR_PREFIX)) {
                setCreditTaxApiErrorMessage(
                        methodKey, creditStage,
                        LOG_MESSAGES.LOG_ERROR_CALCULATING + StringUtils.SPACE
                                + creditStage.getPromotionName() + StringUtils.SPACE
                                + LOG_MESSAGES.LOG_CREDIT_TAX + StringUtils.SPACE
                                + promoTaxWithServicePrice);
                // WARN(
                // m_logger,
                // methodKey + LOG_MESSAGES.LOG_ERROR_CALCULATING + StringUtils.SPACE
                // + creditStage.getPromotionName() + StringUtils.SPACE
                // + LOG_MESSAGES.LOG_CREDIT_TAX + StringUtils.SPACE
                // + promoTaxWithServicePrice);
                //
                // creditStage.setCreditTaxApiErrorMessage(
                // LOG_MESSAGES.LOG_ERROR_CALCULATING + StringUtils.SPACE
                // + creditStage.getPromotionName() + StringUtils.SPACE
                // + LOG_MESSAGES.LOG_CREDIT_TAX + StringUtils.SPACE
                // + promoTaxWithServicePrice);
            } else if (creditStage.getGlobalCreditStage().getTaxCalculationMethod() == GlobalCreditStage.TaxMethod.UNCHANGED) {
                INFO(
                        m_logger,
                        methodKey + "Calling getCreditTaxesFromTaxApi for "
                                + creditStage.getPromotionName()
                                + " when tax calculation method is NORMAL");
                creditStage.setCreditTaxDetails(
                        getCreditTax(
                                loggingKey, stage, servicePs, promoTaxWithServicePrice, creditStage,
                                creditStage.getRedeemableCredits(), true));
            } else {
                if (servicePs.getProratedDiscountPrice().subtract(
                        creditStage.getRedeemableCredits()).signum() <= 0) {
                    INFO(
                            m_logger,
                            methodKey + " Service Discount Price is same as redeemable credits for "
                                    + creditStage.getPromotionName()
                                    + " Subtraction method will not be used to calculate promo tax ");
                    INFO(
                            m_logger,
                            methodKey + "Calling getCreditTaxesFromTaxApi for "
                                    + creditStage.getPromotionName()
                                    + " when Service Discount Price is same as redeemable promos.");
                    creditStage.setCreditTaxDetails(
                            getCreditTax(
                                    loggingKey, stage, servicePs, promoTaxWithServicePrice,
                                    creditStage, creditStage.getRedeemableCredits(), true));
                } else {
                    INFO(
                            m_logger, methodKey + "Calling getTaxDetailsLessOneCredit for "
                                    + creditStage.getPromotionName());
                    String taxForServiceMinusCredit = getTaxDetailsLessOneCredit(
                            loggingKey, route, subscription, stage, servicePs,
                            promoTaxWithServicePrice, creditStage, false);
                    if (taxForServiceMinusCredit.startsWith(GENERIC_CONSTANTS.ERROR_PREFIX)) {
                        setCreditTaxApiErrorMessage(
                                methodKey, creditStage,
                                LOG_MESSAGES.LOG_ERROR_CALCULATING + StringUtils.SPACE
                                        + creditStage.getPromotionName() + StringUtils.SPACE
                                        + LOG_MESSAGES.LOG_CREDIT_TAX + StringUtils.SPACE
                                        + taxForServiceMinusCredit);
                    } else {
                        INFO(
                                m_logger, methodKey + "Calling getCreditTaxBySubtraction for "
                                        + creditStage.getPromotionName());
                        creditStage.setCreditTaxDetails(
                                AdviceUtils.getCreditTaxBySubtraction(
                                        loggingKey, route, promoTaxWithServicePrice,
                                        taxForServiceMinusCredit,
                                        creditStage.getRedeemableCredits(),
                                        creditStage.getPromotionName(), stage.getBrand()));
                    }
                }
            }
        }
    }

    private static void setCreditTaxApiErrorMessage(String methodKey,
                                                    CreditStage creditStage,
                                                    String message) {
        WARN(m_logger, methodKey + message);
        creditStage.setCreditTaxApiErrorMessage(message);
    }

    private static String getTaxDetailsWithoutRefTax(String loggingKey,
                                                     ServiceTaxRequest taxApiRequest,
                                                     AdviceDataStage stage,
                                                     // String payerGeoCode,
                                                     // String subscriberGeoCode,
                                                     // String requestGeoCode,
                                                     String refTaxGeoCode)
            throws JsonParseException, JsonMappingException, IOException {
        final String methodName = "getTaxDetailswithoutRefTax:";
        INFO(m_logger, loggingKey + methodName);

        if (StringUtils.isNotBlank(stage.getRequestGeoCode())) {
            taxApiRequest.setGeocode(stage.getRequestGeoCode());
        } else if (StringUtils.isNotBlank(stage.getPayerGeoCode())
                && !GENERIC_CONSTANTS.YES.equalsIgnoreCase(stage.getIgnorePayer())) {
            taxApiRequest.setGeocode(stage.getPayerGeoCode());
        } else {
            if (StringUtils.isNotBlank(stage.getSubscriberGeoCode())) {
                taxApiRequest.setGeocode(stage.getSubscriberGeoCode());
            } else if (StringUtils.isNotBlank(refTaxGeoCode)) {
                taxApiRequest.setGeocode(refTaxGeoCode);
            } else {
                String noGeocodeMsg = "No valid geocode passed for tax calculation"
                        + StringUtils.SPACE + "requestGeoCode: " + stage.getRequestGeoCode()
                        + StringUtils.SPACE + "subscriberGeoCode: " + stage.getSubscriberGeoCode()
                        + StringUtils.SPACE + "refTaxGeoCode: " + refTaxGeoCode;
                WARN(m_logger, loggingKey + methodName + StringUtils.SPACE + noGeocodeMsg);
                return GENERIC_CONSTANTS.ERROR_PREFIX + noGeocodeMsg;
            }
        }

        LocalDate now = LocalDate.now();
        taxApiRequest.setGlDate(
                now.format(DateTimeFormatter.ofPattern(TAX_CONSTANTS.GL_DATE_FORMAT)));

        if (taxApiRequest.getGrossPrice() == null
                || taxApiRequest.getGrossPrice().compareTo(taxApiRequest.getDiscountPrice()) < 0) {
            taxApiRequest.setGrossPrice(taxApiRequest.getDiscountPrice());
        }

        // Call Tax API
        ObjectMapper objectMapper = CommonUtils.getObjectMapper();
        try {
            String taxApiRequestString = objectMapper.writeValueAsString(taxApiRequest);
            INFO(
                    m_logger, loggingKey + methodName + StringUtils.SPACE
                            + "Call taxapi with request: " + taxApiRequestString);
            String taxApiResponse = TaxApiClient.getTaxApiResult(loggingKey, taxApiRequestString);
            INFO(
                    m_logger, loggingKey + methodName + StringUtils.SPACE + "Taxapi response: "
                            + taxApiResponse);
            return taxApiResponse;
        } catch (Exception ex) {
            WARN(
                    m_logger,
                    loggingKey + methodName + StringUtils.SPACE
                            + LOG_MESSAGES.LOG_FAILED_SERVICE_TAX + StringUtils.SPACE
                            + ExceptionUtils.getStackTrace(ex));
            return GENERIC_CONSTANTS.ERROR_PREFIX + ex.getMessage();
        }

    }

    private static String getTaxDetailsLessOneCredit(String loggingKey,
                                                     String route,
                                                     MtxResponseSubscription subscription,
                                                     AdviceDataStage stage,
                                                     ServiceStage servicePs,
                                                     String serviceFullTax,
                                                     CreditStage creditStage,
                                                     boolean isPromotionCredit)
            throws JsonParseException, JsonMappingException, PaymentAdviceException, IOException {
        final String methodName = "getTaxDetailsLessOneCredit:";
        INFO(
                m_logger,
                loggingKey + methodName + StringUtils.SPACE + "Calculate service taxes by reducing "
                        + creditStage.getPromotionName() + " redeemable credit "
                        + creditStage.getRedeemableCredits() + " from discount price "
                        + servicePs.getProratedDiscountPrice());

        String retVal = getCreditTax(
                loggingKey, stage, servicePs, serviceFullTax, creditStage,
                servicePs.getProratedDiscountPrice().subtract(creditStage.getRedeemableCredits()),
                isPromotionCredit);
        if (retVal == null) {
            retVal = GENERIC_CONSTANTS.ERROR_PREFIX + "TaxDetails are not available";
        }

        return retVal;
    }

    private static String getCreditTax(String loggingKey,
                                       // MtxResponseSubscription subscription,
                                       AdviceDataStage stage,
                                       ServiceStage servicePs,
                                       String serviceFullTax,
                                       CreditStage creditStage,
                                       BigDecimal discountPriceForTax,
                                       boolean isPromotionCredit)
            throws JsonParseException, JsonMappingException, IOException, PaymentAdviceException {
        final String methodKey = loggingKey + " getCreditTax: ";
        ServiceTaxRequest taxApiRequest;
        String retTax = "";
        String specificTemplate = "";
        String defaultTemplate = "";
        String taxTemplate = "";

        if (creditStage.getGlobalCreditStage().getTaxTemplates() != null
                && !creditStage.getGlobalCreditStage().getTaxTemplates().isEmpty()) {
            for (MtxPricingMetadataInfo pmi : creditStage.getGlobalCreditStage().getTaxTemplates()) {
                if (pmi.getName().trim().equalsIgnoreCase(
                        creditStage.getApplicableCiExternalId().trim() + CI_METADATA.TAX_INPUT)) {
                    specificTemplate = pmi.getValue();
                }
                if (pmi.getName().trim().equalsIgnoreCase(CI_METADATA.TAX_INPUT)) {
                    defaultTemplate = pmi.getValue();
                }
            }
        }

        if (StringUtils.isNotBlank(specificTemplate)) {
            taxTemplate = specificTemplate;
        } else {
            taxTemplate = defaultTemplate;
        }

        if (StringUtils.isNotBlank(taxTemplate)) {
            taxApiRequest = CommonUtils.getServiceTaxRequestFromJsonString(taxTemplate);
        } else {
            WARN(m_logger, methodKey + "TaxDetails are not available");
            return null;
        }

        taxApiRequest.setDiscountPrice(discountPriceForTax);

        if (StringUtils.isNotBlank(creditStage.getPromotionName())) {
            taxApiRequest.setPromotionName(creditStage.getPromotionName());
        }
        if (StringUtils.isNotBlank(stage.getBrand())) {
            taxApiRequest.setBrand(stage.getBrand());
        }

        if (creditStage.getGlobalCreditStage().getTaxCalculationMethod() == GlobalCreditStage.TaxMethod.UNCHANGED) {
            taxApiRequest.setGrossPrice(discountPriceForTax);
        } else {
            taxApiRequest.setGrossPrice(servicePs.getProratedDiscountPrice());
        }
        taxApiRequest.setPromotionCredit(isPromotionCredit);

        LocalDate now = LocalDate.now();
        taxApiRequest.setGlDate(
                now.format(DateTimeFormatter.ofPattern(TAX_CONSTANTS.GL_DATE_FORMAT)));

        taxApiRequest.setClassCode(creditStage.getClassCode());

        if (StringUtils.isNotBlank(creditStage.getRedeemGoodType())) {
            // There are no specific requirements provided for promotion reason.
            // Using redeem good type, similar to redeem credit recharge reason & good type
            taxApiRequest.setPromotionReason(creditStage.getRedeemGoodType());
        } else {
            // Promotion reason mandatory if promotion credit is true
            // Defaulting to promo name if template parameter is not set for redeem good type.
            taxApiRequest.setPromotionReason(creditStage.getPromotionName());
        }

        if (StringUtils.isNotBlank(stage.getPayerExternalId())
                && !GENERIC_CONSTANTS.YES.equalsIgnoreCase(stage.getIgnorePayer())) {
            taxApiRequest.setMsgID(
                    creditStage.getClassCode() + TAX_CONSTANTS.MSG_FIELD_DELIMITER
                            + TAX_CONSTANTS.MSG_FIELD_PAYER_TAX + stage.getPayerExternalId());
        }

        if (StringUtils.isNotBlank(serviceFullTax)
                && !serviceFullTax.startsWith(GENERIC_CONSTANTS.ERROR_PREFIX)) {
            mapGeoCodeToCreditTaxRequest(serviceFullTax, taxApiRequest, stage);
            try {
                String taxApiRequestString = CommonUtils.getObjectMapper().writeValueAsString(
                        taxApiRequest);
                INFO(m_logger, methodKey + "TaxApiRequest: " + taxApiRequestString);
                retTax = TaxApiClient.getTaxApiResult(loggingKey, taxApiRequestString);
                INFO(m_logger, methodKey + "TaxApiResponse: " + retTax);
            } catch (Exception ex) {
                WARN(m_logger, methodKey + "Tax Request: " + taxApiRequest.toJson());
                WARN(
                        m_logger,
                        methodKey + LOG_MESSAGES.LOG_ERROR_CALCULATING + StringUtils.SPACE
                                + creditStage.getPromotionName() + StringUtils.SPACE
                                + LOG_MESSAGES.LOG_CREDIT_TAX + StringUtils.SPACE
                                + ex.getMessage());
                creditStage.setCreditTaxApiErrorMessage(
                        LOG_MESSAGES.LOG_ERROR_CALCULATING + StringUtils.SPACE
                                + creditStage.getPromotionName() + StringUtils.SPACE
                                + LOG_MESSAGES.LOG_CREDIT_TAX + StringUtils.SPACE
                                + ex.getMessage());
                retTax = GENERIC_CONSTANTS.ERROR_PREFIX
                        + "Error while calling taxapi. Check logs for details.";
            }

        } else {
            WARN(
                    m_logger, methodKey + creditStage.getPromotionName()
                            + LOG_MESSAGES.LOG_TAX_NOT_AVAILABLE_GEOCODE_CANNOT_BE_READ);
            creditStage.setCreditTaxApiErrorMessage(
                    creditStage.getPromotionName()
                            + LOG_MESSAGES.LOG_TAX_NOT_AVAILABLE_GEOCODE_CANNOT_BE_READ);
        }

        return retTax;
    }

    private static void mapGeoCodeToCreditTaxRequest(String serviceTax,
                                                     ServiceTaxRequest taxApiRequest,
                                                     // MtxResponseSubscription subscription,
                                                     AdviceDataStage stage)
            // ,String transactionGeoCode,
            // String payerGeoCode)
            throws JsonParseException, JsonMappingException, IOException, PaymentAdviceException {

        // VisibleSubscriberExtension subAttr = (VisibleSubscriberExtension) subscription.getAttr();

        ServiceTaxResponse serviceTaxResponse = CommonUtils.getObjectMapper().readValue(
                serviceTax, ServiceTaxResponse.class);
        if (StringUtils.isNotBlank(stage.getRequestGeoCode())) {
            taxApiRequest.setGeocode(stage.getRequestGeoCode());
        } else if (StringUtils.isNotBlank(stage.getPayerGeoCode())
                && !GENERIC_CONSTANTS.YES.equalsIgnoreCase(stage.getIgnorePayer())) {
            taxApiRequest.setGeocode(stage.getPayerGeoCode());
        } else {
            if (StringUtils.isNotBlank(stage.getSubscriberGeoCode())) {
                taxApiRequest.setGeocode(stage.getSubscriberGeoCode());
            } else if (StringUtils.isNotBlank(serviceTaxResponse.getGeocode())) {
                taxApiRequest.setGeocode(serviceTaxResponse.getGeocode());
            } else {
                throw new PaymentAdviceException(
                        RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR,
                        "Geocode could not be determined. Tax can not be calculated.");
            }
        }
    }

    public static void updateOneTimeCredit(String loggingKey,
                                           MtxResponseSubscription subscription,
                                           AdviceDataStage stage,
                                           // If promo is used here reduce it for new stage
                                           AdviceDataStage reservedStage,
                                           MtxResponsePricingCatalogItem pci,
                                           MtxResponsePricingBalance rpb,
                                           boolean keepZeroValuePromo,
                                           // Evaluate only these credits. Ignore the rest.
                                           // List should have ClassCodes
                                           List<String> restrictedList)
            throws PaymentAdviceException, IllegalAccessException, InvocationTargetException,
            NoSuchMethodException, IntrospectionException {
        final String methodKey = loggingKey + " updateOneTimeCredit: ";
        INFO(m_logger, methodKey);
        /****************************************************************************************************/
        // avoid calling sub man api to get CI when possible.
        GlobalCreditStage gcs = stage.getCreditMetadataMap().get(
                pci.getCatalogItemInfo().getExternalId());
        if (gcs == null) {
            gcs = AdviceUtils.getGlobalCreditStageForGrantCI(loggingKey, pci, stage, false);
        }
        INFO(
                m_logger, methodKey + pci.getCatalogItemInfo().getExternalId() + ": "
                        + "Global Credit Stage created.");

        /****************************************************************************************************/

        if (gcs == null) {
            INFO(m_logger, methodKey + ": " + "No Global Credit Stage was created.");
            return;
        }

        if (restrictedList != null && !restrictedList.contains(gcs.getClassCode().trim())) {
            INFO(
                    m_logger, methodKey + gcs.getClassCode() + " is not part of restricted list: "
                            + restrictedList);
            return;
        }

        Set<String> applicableCiSet = gcs.getApplicableCiSet();
        // For Purchase service a promo is not required unless applicable offer is being
        // purchased.
        if (stage.getAdviceFor() == AdviceDataStage.Advice.PURCHASE) {
            boolean keepPromo = false;
            for (String applicableCi : applicableCiSet) {
                if (stage.getCiListInPurchaseService().contains(applicableCi)) {
                    keepPromo = true;
                    break;
                }
            }

            if (!keepPromo) {
                INFO(
                        m_logger,
                        methodKey + "Promo " + gcs.getPromotionName() + StringUtils.SPACE
                                + "is not usable by " + stage.getCiListInPurchaseService()
                                + StringUtils.SPACE + " promo will be skipped.");
                return;
            }
        }

        if (stage.isPromoInCreditMap(gcs.getGrantOfferCi())) {
            INFO(
                    m_logger, methodKey + gcs.getGrantOfferCi() + StringUtils.SPACE
                            + "is already considered for calculations. It will be skipped as read balance credit. ");
            return;
        }

        if (CREDIT_CONSTANTS.GRANT_TYPE_PERCENTAGE.equals(gcs.getCreditGrantType())) {
            // skip offer
            INFO(
                    m_logger,
                    methodKey
                            + "Onetime grant balance based credit can not have Percentage grant type. Skipping promotion "
                            + StringUtils.SPACE + gcs.getPromotionName());
            return;
        }

        gcs.setGrantBalanceName(rpb.getBalanceInfo().getName());

        for (MtxBalanceInfo bi : subscription.getBalanceArray()) {
            if (bi.getName().trim().equalsIgnoreCase(rpb.getBalanceInfo().getName().trim())) {
                gcs.setAvailableCreditsGrant(
                        CommonUtils.getBalanceAmountOnDate(bi, stage.getCycleStartTime()));
                INFO(
                        m_logger, methodKey + "Available grant for " + gcs.getPromotionName()
                                + " is: " + gcs.getAvailableCreditsGrant());

            }
            if (StringUtils.isNotBlank(gcs.getConsumableBalanceName())
                    && bi.getName().equalsIgnoreCase(gcs.getConsumableBalanceName().trim())) {
                gcs.setAvailableCreditsConsumable(
                        CommonUtils.getBalanceAmountOnDate(bi, stage.getCycleStartTime()));
                INFO(
                        m_logger, methodKey + "Available consumables for " + gcs.getPromotionName()
                                + " is: " + gcs.getAvailableCreditsConsumable());

            }
        }
        if (reservedStage != null && reservedStage.getCreditMap() != null
                && !reservedStage.getCreditMap().isEmpty()) {
            // Reduce consumables first and grants next
            for (CreditStage csReserved : reservedStage.getCreditMap().values()) {
                if (csReserved.getGrantOfferCi().equalsIgnoreCase(gcs.getGrantOfferCi())) {
                    if (csReserved.getRedeemableCredits().compareTo(
                            gcs.getAvailableCredits()) >= 0) {
                        // all credits reserved.
                        gcs.setAvailableCreditsConsumable(BigDecimal.ZERO);
                        gcs.setAvailableCreditsGrant(BigDecimal.ZERO);
                    } else if (csReserved.getRedeemableCredits().compareTo(
                            gcs.getAvailableCreditsConsumable()) <= 0) {
                        // reserved credits are less than consumables
                        gcs.setAvailableCreditsConsumable(
                                gcs.getAvailableCreditsConsumable().subtract(
                                        csReserved.getRedeemableCredits()));
                    } else {
                        // Reserved credits are more than consumables. All credits are not
                        // reserved. So Available credits is more than reserved.
                        BigDecimal reservedFromGrant = csReserved.getRedeemableCredits().subtract(
                                gcs.getAvailableCreditsConsumable());
                        gcs.setAvailableCreditsGrant(
                                gcs.getAvailableCreditsGrant().subtract(reservedFromGrant));
                        gcs.setAvailableCreditsConsumable(BigDecimal.ZERO);
                    }
                }
            }
        }
        gcs.setAvailableCredits(
                gcs.getAvailableCreditsGrant().add(gcs.getAvailableCreditsConsumable()));
        if (gcs.getAvailableCredits().signum() > 0 || keepZeroValuePromo) {
            // Ignore credit if there is no amount
            for (String applicableCi : applicableCiSet) {
                if (!stage.getCiListInPurchaseService().contains(applicableCi)
                        && stage.getAdviceFor() == AdviceDataStage.Advice.PURCHASE) {
                    // For purchase do not report any promo with no redeemables.
                    continue;
                }
                CreditStage cs = new CreditStage(gcs, applicableCi);
                AdviceUtils.updateCreditStageWithPaynowStage(loggingKey, stage, cs);
                if (cs.getApplicableServiceStage() == null) {
                    // if a paynowstage is not linked to a promo that means applicable offer is
                    // not part of advice. So ignore credit
                    INFO(
                            m_logger,
                            methodKey
                                    + "If a paynowstage is not linked to a promo that means applicable offer is not part of advice. So ignore "
                                    + cs.getPromotionName() + " for "
                                    + cs.getApplicableCiExternalId());
                    continue;
                } else if (cs.getApplicableServiceStage() != null
                        && cs.getApplicableServiceStage().isSkipRenewal()) {
                    // if a paynowstage is not linked to a promo that means applicable offer is
                    // not part of advice. So ignore credit
                    INFO(
                            m_logger, methodKey + cs.getApplicableCiExternalId()
                                    + " needs zero payments. Skip promo.");
                    stage.getCreditMap().put(cs.getPromoOfferPair(), cs);
                    cs.getGlobalCreditStage().getCreditMap().put(
                            cs.getApplicableCiExternalId(), cs);
                    continue;
                }
                AdviceUtils.updateFlagBalanceConditions(loggingKey, stage, subscription, cs);
                AdviceUtils.applyCreditIncludeAttributeRules(loggingKey, subscription, cs);
                stage.getCreditMap().put(cs.getPromoOfferPair(), cs);
                cs.getGlobalCreditStage().getCreditMap().put(cs.getApplicableCiExternalId(), cs);
                INFO(
                        m_logger,
                        methodKey + "Added Read Balance credit : " + StringUtils.SPACE
                                + cs.getPromotionName() + StringUtils.SPACE
                                + cs.getGlobalCreditStage().toJson());
            }
        } else {
            INFO(m_logger, methodKey + "Skipped Read Balance credit. No usable credits available.");
        }

    }

    public static void updateFinalMinimumCharges(String loggingKey, AdviceDataStage stage) {
        final String methodKey = loggingKey + " updateFinalMinimumCharges: ";
        INFO(m_logger, methodKey);
        // For each paymentStage
        stage.getPayNowMap().values().forEach(ps -> {
            // Get all credit stages if minimum charge is not defined, default to zero
            if (ps.getMinimumCharge() == null) {
                ps.setMinimumCharge(BigDecimal.ZERO);
            }
        });

        for (ServiceStage ps : stage.getPayNowMap().values()) {
            boolean setByCredit = false;
            // Get all credit stages with applicable offer as payament stage CI
            for (CreditStage cs : stage.getCreditMap().values()) {
                if (ps.getCatalogItemExternalId().equalsIgnoreCase(
                        cs.getApplicableCiExternalId())) {
                    if (cs.getMinimumCharge() != null && (!setByCredit
                            || ps.getMinimumCharge().compareTo(cs.getMinimumCharge()) < 0)) {
                        ps.setMinimumCharge(cs.getMinimumCharge());
                        setByCredit = true;
                        INFO(
                                m_logger,
                                methodKey + "Minimum Charge set based on promo "
                                        + cs.getPromotionName() + StringUtils.SPACE + " for "
                                        + ps.getCatalogItemExternalId() + StringUtils.SPACE + "to "
                                        + ps.getMinimumCharge());
                    }
                }
            }

            if (stage.getAdviceFor() == AdviceDataStage.Advice.CHANGE
                    && stage.getChangeServiceDataStage().getBillCycle() == ChangeServiceDataStage.BillCycle.CURRENT) {
                ps.setMinimumCharge(BigDecimal.ZERO);
                INFO(
                        m_logger, methodKey
                                + "Minimum Charge not applicable for Delta component. Current offer is already paid with enrolled offer.");
                BigDecimal moneyOnlyAmount = BigDecimal.ZERO;
                if (ps.getTaxFeeAmount() != null && ps.getTaxFeeAmount().signum() > 0) {
                    moneyOnlyAmount = ps.getTaxFeeAmount();
                    INFO(
                            m_logger, methodKey + "Promo should not be applicable to fixed fee: "
                                    + moneyOnlyAmount);
                }

                if (stage.getCreditMap() != null && !stage.getCreditMap().values().isEmpty()) {
                    ps.setMaxPromo(
                            ps.getProratedDiscountPrice().subtract(moneyOnlyAmount).max(
                                    BigDecimal.ZERO));
                } else {
                    ps.setMaxPromo(BigDecimal.ZERO);
                }
            } else {
                BigDecimal moneyOnlyAmount = BigDecimal.ZERO;
                if (ps.getMinimumCharge().compareTo(ps.getTaxFeeAmount()) >= 0) {
                    moneyOnlyAmount = ps.getMinimumCharge();
                } else if (ps.getAvailableGiftAmount() == null
                        || ps.getAvailableGiftAmount().signum() <= 0) {
                    moneyOnlyAmount = ps.getTaxFeeAmount();
                } else if (ps.getAvailableGiftAmount().compareTo(ps.getTaxFeeAmount()) >= 0) {
                    // Fee will be paid by gift no need to pay by cash
                    moneyOnlyAmount = ps.getMinimumCharge();
                } else {
                    moneyOnlyAmount = ps.getTaxFeeAmount().subtract(ps.getAvailableGiftAmount());
                }

                INFO(
                        m_logger,
                        methodKey
                                + "Promo should not be applicable to MAX(fixed fee, minimum charge): "
                                + moneyOnlyAmount);
                ps.setMaxPromo(ps.getProratedDiscountPrice().subtract(moneyOnlyAmount));

                INFO(
                        m_logger,
                        methodKey
                                + "Max Promo Limit = New Offer Price - Amount For which Promotions Can not be applied = "
                                + ps.getProratedDiscountPrice() + " - " + moneyOnlyAmount + " = "
                                + ps.getMaxPromo());
            }
        }
    }

    @SuppressWarnings("unchecked")
    public static AdviceDataStage updateOfferDetails(String loggingKey,
                                                     String route,
                                                     AdviceDataStage stage)
            throws PaymentAdviceException, JsonParseException, JsonMappingException,
            IntegrationServiceException, IOException {
        final String methodKey = loggingKey + " updateOfferDetails: ";
        // boolean isEnrolledInBase = stage.isBaseOfferInAdvice();
        Boolean isIgnoreTaxField = null;

        for (ServiceStage paynow : stage.getPayNowMap().values()) {
            INFO(
                    m_logger, methodKey + "Updating VisibleOfferDetails for "
                            + paynow.getCatalogItemExternalId());
            VisibleOfferDetailsInternal vod = new VisibleOfferDetailsInternal();
            vod.setCatalogItemExternalId(paynow.getCatalogItemExternalId());
            vod.setAocAmount(paynow.getAocDiscountPrice());

            if (paynow.getOfferResourceId() != null) {
                vod.setResourceId(paynow.getOfferResourceId() + "");
            }

            if (StringUtils.isNotBlank(paynow.getStatus())) {
                vod.setStatus(paynow.getStatus());
            }

            if (StringUtils.isNotBlank(paynow.getPurchaseServiceType())) {
                vod.setPurchaseServiceType(paynow.getPurchaseServiceType());
            }

            if (paynow.getActualPaidCycleStartDate() != null) {
                vod.setPaidCycleStartDate(paynow.getActualPaidCycleStartDate());
            }

            if (paynow.getPurchaseOfferEndTime() != null) {
                vod.setPurchaseOfferEndTime(paynow.getPurchaseOfferEndTime());
            }

            if (AdviceDataStage.Advice.PAYMENT == stage.getAdviceFor()) {
                if (paynow.getNextCycleStartTime() != null) {
                    vod.setCycleStartTime(paynow.getNextCycleStartTime().toString());
                }
                if (paynow.getNextCycleEndTime() != null) {
                    vod.setCycleEndTime(paynow.getNextCycleEndTime().toString());
                }
            } else {
                if (paynow.getCycleStartTime() != null) {
                    vod.setCycleStartTime(paynow.getCycleStartTime().toString());
                }

                if (paynow.getCycleEndTime() != null) {
                    vod.setCycleEndTime(paynow.getCycleEndTime().toString());
                    vod.setPurchaseCycleEndTime(paynow.getCycleEndTime());
                }
            }

            // Add logic to validate IgnoreTax_ForPayableAmount field for Credits
            for (CreditStage cs : stage.getCreditMap().values()) {
                if (paynow.getCatalogItemExternalId().equalsIgnoreCase(
                        cs.getApplicableCiExternalId())) {
                    if (cs.getIgnoreTax_ForPayableAmount() == null) {
                        isIgnoreTaxField = true;
                        break;
                    } else if (cs.getIgnoreTax_ForPayableAmount() == false) {
                        isIgnoreTaxField = true;
                        break;
                    } else {
                        isIgnoreTaxField = false;
                    }
                }
            }

            if (isIgnoreTaxField != null && isIgnoreTaxField == false) {
                vod.setPayableAmount(paynow.getFinalPayableAmount());
            } else {
                if (paynow.getNonCreditAmount().compareTo(paynow.getTaxFeeAmount()) >= 0) {
                    // Noncredit amount includes consumable mainbalance
                    vod.setPayableAmount(paynow.getFinalPayableAmount());
                } else if ((paynow.getIgnoreTax_ForPayableAmount() != null
                        && paynow.getIgnoreTax_ForPayableAmount() == true)) {
                    // Validate IgnoreTax_ForPayableAmount field in Base Offer
                    vod.setPayableAmount(paynow.getFinalPayableAmount());
                } else if (paynow.getNonCreditAmount().add(
                        paynow.getRedeemableGiftAmount()).compareTo(
                                paynow.getTaxFeeAmount()) >= 0) {
                    vod.setPayableAmount(paynow.getFinalPayableAmount());
                } else {
                    vod.setPayableAmount(paynow.getTaxFeeAmount());
                }
            }

            vod.setConsumableMainBalanceAmount(paynow.getConsumableMainBalance());
            vod.setOfferType(paynow.getOfferType());
            vod.setChargeAmount(paynow.getDiscountPrice());

            if (stage.isAdviceWithTaxes()) {
                if (StringUtils.isNotBlank(paynow.getTaxResponse())
                        && !paynow.getTaxResponse().toUpperCase().startsWith(
                                GENERIC_CONSTANTS.ERROR_PREFIX)) {
                    vod.setTaxDetails(paynow.getTaxResponse());
                }
            }

            stage.getCreditMap().values().forEach(cs -> {
                if (vod.getCatalogItemExternalId().equals(cs.getApplicableCiExternalId())
                        && cs.getRedeemableCredits().signum() > 0) {
                    VisibleCredits vc = new VisibleCredits();
                    vc.setPromotionName(cs.getPromotionName());
                    vc.setRedeemableCredits(cs.getRedeemableCredits());
                    vc.setClassCode(cs.getClassCode());
                    vod.getCreditsAppender().add(vc);
                }
            });
            stage.appendVisibleOfferDetailsMap(
                    paynow.getCatalogItemExternalId(), paynow.getOfferResourceId(), vod);
            INFO(
                    m_logger, methodKey + "Added VisibleOfferDetails to base offer "
                            + paynow.getCatalogItemExternalId() + StringUtils.SPACE + vod.toJson());
        }
        return stage;
    }

    public static void updatePayableAmountsForProration(String loggingKey,
                                                        String route,
                                                        AdviceDataStage stage)
            throws PaymentAdviceException, JsonParseException, JsonMappingException,
            IntegrationServiceException, IOException {

        final String methodKey = loggingKey + " updatePayableAmountsForProration: ";
        INFO(m_logger, methodKey);
        BigDecimal totalEstimatedAmount = BigDecimal.ZERO;
        BigDecimal mainBalanceAccount = stage.getAvailableMainBalanceAmount();

        for (VisibleOfferDetails vod : stage.getVisibleOfferDetailsMap().values()) {
            totalEstimatedAmount = totalEstimatedAmount.add(vod.getPayableAmount());
        }

        stage.setTotalEstimatedAmount(
                totalEstimatedAmount.setScale(
                        BRAINTREE_CONSTANTS.BT_AMOUNT_PRECISION, RoundingMode.CEILING));

        if (totalEstimatedAmount.signum() == 0) {
            // Everything paid by promos
            stage.setRechargeAmount(BigDecimal.ZERO);
            stage.setConsumableMainBalanceAmount(BigDecimal.ZERO);
        } else if (mainBalanceAccount.signum() == -1) {
            // The scenario is handled for negative balance
            INFO(m_logger, methodKey + "Apply correction for negative mainbalance.");
            INFO(m_logger, methodKey + "Change recharge amount from: " + stage.getRechargeAmount());
            stage.setRechargeAmount(
                    totalEstimatedAmount.subtract(stage.getAvailableMainBalanceAmount()));
            INFO(m_logger, methodKey + "Change recharge amount to: " + stage.getRechargeAmount());
            stage.setConsumableMainBalanceAmount(BigDecimal.ZERO);
        } else if (totalEstimatedAmount.compareTo(mainBalanceAccount) >= 0) {
            stage.setRechargeAmount(totalEstimatedAmount.subtract(mainBalanceAccount));
            stage.setConsumableMainBalanceAmount(mainBalanceAccount);
        } else {
            stage.setRechargeAmount(BigDecimal.ZERO);
            stage.setConsumableMainBalanceAmount(totalEstimatedAmount);
        }
    }

    public static AdviceDataStage updateServiceStageFromSubscription(String loggingKey,
                                                                     String route,
                                                                     AdviceDataStage stage,
                                                                     SubscriptionResponse subscriptionResponse)
            throws PaymentAdviceException {
        final String methodKey = loggingKey + "updateServiceStageFromSubscription: ";
        ArrayList<MtxPurchasedOfferInfo> offerArray = subscriptionResponse.getPurchasedOfferArray();

        for (MtxPurchasedOfferInfo poi : CommonUtils.emptyIfNull(offerArray)) {
            PurchasedOfferInfo offerInfo = (PurchasedOfferInfo) poi;
            if (StringUtils.isBlank(offerInfo.getCatalogItemExternalId())) {
                continue;
            }
            if (offerInfo.getAttr() == null) {
                continue;
            }

            if (!poi.getOfferStatusDescription().toString().equalsIgnoreCase(
                    OFFER_CONSTANTS.OFFER_STATUS_ACTIVE)
                    && !poi.getOfferStatusDescription().toString().equalsIgnoreCase(
                            OFFER_CONSTANTS.OFFER_STATUS_PRE_ACTIVE)) {
                continue;
            }

            // SubscriptionResponse already has catalogitem. We should stop querying pricing for
            // this.
            // MtxResponsePricingCatalogItem pricingCI = queryPricingCatalogItem(
            // loggingKey, route, offerInfo.getCatalogItemExternalId());
            MtxPricingCatalogItemDetailInfo pricingCI = offerInfo.getCatalogItemDetails();

            VisibleTemplate tempAttr;
            if (pricingCI.getTemplateAttr() != null
                    && (pricingCI.getTemplateAttr() instanceof VisibleTemplate)) {
                tempAttr = (VisibleTemplate) pricingCI.getTemplateAttr();
                if (StringUtils.isBlank(tempAttr.getOfferType())) {
                    continue;
                }
                if (OFFER_CONSTANTS.OFFER_TYPE_BASE.equalsIgnoreCase(
                        tempAttr.getOfferType().trim())) {
                    stage.setBaseOfferInAdvice(true);
                } else if (OFFER_CONSTANTS.OFFER_TYPE_ADDON.equalsIgnoreCase(
                        tempAttr.getOfferType().trim())
                        || OFFER_CONSTANTS.OFFER_TYPE_INSURANCE.equalsIgnoreCase(
                                tempAttr.getOfferType().trim())) {
                } else {
                    // Ignore every other type of offer like setup services, device offers,
                    // gifts, shipping offers, promos etc.
                    continue;
                }
            } else {
                continue;
            }

            VisiblePurchasedOfferExtension offerExtn = (VisiblePurchasedOfferExtension) offerInfo.getAttr();
            BigDecimal amount = BigDecimal.ZERO;
            if (offerExtn.getChargeAmount() != null) {
                amount = offerExtn.getChargeAmount();
            }

            ServiceStage payNow;
            if (stage.getServiceStage(offerInfo.getCatalogItemExternalId()) == null) {
                payNow = new ServiceStage(
                        offerInfo.getCatalogItemExternalId(), offerInfo.getResourceId());
            } else {
                payNow = stage.getServiceStage(offerInfo.getCatalogItemExternalId());
            }

            boolean isPreactive = CommonUtils.isOfferPreActive(
                    loggingKey, m_logger, offerInfo,
                    subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime());
            boolean isActiveNextCycle = CommonUtils.willOfferBeActive(
                    loggingKey, m_logger, poi,
                    subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime());

            if (isActiveNextCycle) {
                payNow.setDiscountPrice(amount);
                payNow.setDiscountPriceFromSubscription(true);
                if (isPreactive) {
                    payNow.setProratedDiscountPrice(amount);
                    payNow.setAocDiscountPrice(amount);
                    payNow.setNonCreditAmount(payNow.getProratedDiscountPrice());
                    payNow.setFinalPayableAmount(payNow.getProratedDiscountPrice());
                } else {
                    payNow.setProratedDiscountPrice(BigDecimal.ZERO);
                    payNow.setAocDiscountPrice(BigDecimal.ZERO);
                    payNow.setNonCreditAmount(BigDecimal.ZERO);
                    payNow.setFinalPayableAmount(BigDecimal.ZERO);
                }

                if (offerInfo.getAutoActivationTime() != null && isPreactive) {
                    payNow.setNextCycleStartTime(offerInfo.getAutoActivationTime());
                } else if (offerInfo.getStartTime() != null && isPreactive) {
                    payNow.setNextCycleStartTime(offerInfo.getStartTime());
                } else if (offerInfo.getCycleInfo() != null
                        && offerInfo.getCycleInfo().getCycleEndTime() != null) {
                    payNow.setNextCycleStartTime(offerInfo.getCycleInfo().getCycleEndTime());
                }

                if (payNow.getNextCycleStartTime() != null) {
                    if (CommonUtils.compareMtxTimestampsIgnoreTime(
                            subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime(),
                            payNow.getNextCycleStartTime()) < 0) {
                        // Next offer cycle is later than next bill cycle
                        payNow.setSkipRenewal(true);
                    }
                    MtxTimestamp endDate;
                    if (offerInfo.getCatalogItemDetails() != null
                            && offerInfo.getCatalogItemDetails().getCyclePeriod() != null
                            && offerInfo.getCatalogItemDetails().getCyclePeriodInterval() != null) {
                        endDate = CommonUtils.getCycleEndDate(
                                payNow.getNextCycleStartTime(), subscriptionResponse.getTimeZone(),
                                offerInfo.getCatalogItemDetails().getCyclePeriod(),
                                offerInfo.getCatalogItemDetails().getCyclePeriodInterval(),
                                subscriptionResponse.getBillingCycle());
                    } else {
                        endDate = CommonUtils.getNextCycleEndTime(
                                subscriptionResponse.getBillingCycle(),
                                subscriptionResponse.getTimeZone());
                    }
                    payNow.setNextCycleEndTime(endDate);
                }

                if (pricingCI != null && pricingCI.getMetadataList() != null) {
                    pricingCI.getMetadataList().forEach(pmi -> {
                        if (pmi.getName().equalsIgnoreCase(CI_METADATA.TAX_INPUT)) {
                            payNow.setTaxInput(pmi.getValue());
                        }
                        if (pmi.getName().equalsIgnoreCase(CI_METADATA.STANDALONE_TAX_INPUT)) {
                            payNow.setStandaloneTaxInput(pmi.getValue());
                        }
                        if (pmi.getName().equalsIgnoreCase(CI_METADATA.ZERO_TAX_RESPONSE)) {
                            payNow.setZeroTaxResponse(pmi.getValue());
                        }
                    });
                }

                tempAttr = (VisibleTemplate) pricingCI.getTemplateAttr();
                payNow.setOfferType(tempAttr.getOfferType());

                if (tempAttr.getMinimumCharge() != null) {
                    payNow.setMinimumCharge(tempAttr.getMinimumCharge());
                } else {
                    payNow.setMinimumCharge(BigDecimal.ZERO);
                }
                // update paynow with flag value
                if (tempAttr.getIgnoreTax_ForPayableAmount() != null) {
                    payNow.setIgnoreTax_ForPayableAmount(tempAttr.getIgnoreTax_ForPayableAmount());
                }

                stage.getPayNowMap().put(
                        new CiResourceIdPair(
                                payNow.getCatalogItemExternalId(), payNow.getOfferResourceId()),
                        payNow);
                INFO(m_logger, methodKey + "Added Paynow Stage for offer: " + payNow.toShortJson());
            }
        }

        if (subscriptionResponse.getBillingCycle() != null
                && subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime() != null) {
            stage.setNextCycleStartTime(
                    subscriptionResponse.getBillingCycle().getCurrentPeriodEndTime());
            INFO(
                    m_logger,
                    methodKey + "Added current period end time as next period start time: "
                            + stage.getNextCycleStartTime());
        }

        return stage;
    }

    /**
     * Check if any credit is incompatible with other credits. Remove incompatible credit if there
     * is no consumable
     */
    public static void applyIncompatibilityRules(String loggingKey, AdviceDataStage stage) {

        final String methodName = "applyIncompatibilityRules: ";
        Iterator<CreditStage> itr = stage.getCreditMap().values().iterator();

        Set<PromoOfferPair> toBeDropped = new HashSet<PromoOfferPair>();
        while (itr.hasNext()) {

            CreditStage curPromo = itr.next();
            if (curPromo.getIncompatiblePromotions() == null
                    || curPromo.getIncompatiblePromotions().getIncompatibilityList() == null
                    || curPromo.getIncompatiblePromotions().getIncompatibilityList().size() == 0) {
                continue;
            }

            List<Incompatibility> incList = curPromo.getIncompatiblePromotions().getIncompatibilityList();
            for (Incompatibility incompatibility : incList) {
                List<CreditStage> incompatibleCredits = stage.getCreditMap().values().stream().filter(
                        cStage -> cStage.getClassCode() != null
                                && cStage.getClassCode().equalsIgnoreCase(
                                        incompatibility.getClassCode())).filter(
                                                cStage -> cStage.getApplicableCiExternalId().equalsIgnoreCase(
                                                        curPromo.getApplicableCiExternalId())).collect(
                                                                Collectors.toList());
                for (CreditStage incPromo : incompatibleCredits) {
                    if (incompatibility.getCondition() != null) {
                        IncompatibilityCondition cond = incompatibility.getCondition();
                        if (cond.getAmount().signum() >= 0) {
                            if (cond.getOperator().equalsIgnoreCase(
                                    IncompatibilityCondition.OPERATOR_GT)) {
                                if (cond.getOn().equalsIgnoreCase(
                                        IncompatibilityCondition.ON_CURRENT_PROMO_AMOUNT)) {
                                    if (curPromo.getRedeemableCredits().compareTo(
                                            cond.getAmount()) == 1) {
                                        // remove incPromo
                                        toBeDropped.add(
                                                new PromoOfferPair(
                                                        incPromo.getApplicableCiExternalId(),
                                                        incPromo.getGrantOfferCi()));
                                    } else {
                                        // keep credit
                                        continue;
                                    }
                                } else if (cond.getOn().equalsIgnoreCase(
                                        IncompatibilityCondition.ON_INCOMPATIBLE_PROMO_AMOUNT)) {
                                    if (incPromo.getRedeemableCredits().compareTo(
                                            cond.getAmount()) == 1) {
                                        // remove incPromo
                                        toBeDropped.add(
                                                new PromoOfferPair(
                                                        incPromo.getApplicableCiExternalId(),
                                                        incPromo.getGrantOfferCi()));
                                    } else {
                                        // keep credit
                                        continue;
                                    }
                                } else {
                                    // invalid condition ignore rule
                                    continue;
                                }
                            } else if (cond.getOperator().equalsIgnoreCase(
                                    IncompatibilityCondition.OPERATOR_GE)) {
                                if (cond.getOn().equalsIgnoreCase(
                                        IncompatibilityCondition.ON_CURRENT_PROMO_AMOUNT)) {
                                    if (curPromo.getRedeemableCredits().compareTo(
                                            cond.getAmount()) >= 0) {
                                        // remove incPromo
                                        toBeDropped.add(
                                                new PromoOfferPair(
                                                        incPromo.getApplicableCiExternalId(),
                                                        incPromo.getGrantOfferCi()));
                                    } else {
                                        // keep credit
                                        continue;
                                    }
                                } else if (cond.getOn().equalsIgnoreCase(
                                        IncompatibilityCondition.ON_INCOMPATIBLE_PROMO_AMOUNT)) {
                                    if (incPromo.getRedeemableCredits().compareTo(
                                            cond.getAmount()) >= 0) {
                                        // remove incPromo
                                        toBeDropped.add(
                                                new PromoOfferPair(
                                                        incPromo.getApplicableCiExternalId(),
                                                        incPromo.getGrantOfferCi()));
                                    } else {
                                        // keep credit
                                        continue;
                                    }
                                } else {
                                    // invalid condition ignore rule
                                    continue;
                                }
                            } else if (cond.getOperator().equalsIgnoreCase(
                                    IncompatibilityCondition.OPERATOR_LT)) {
                                if (cond.getOn().equalsIgnoreCase(
                                        IncompatibilityCondition.ON_CURRENT_PROMO_AMOUNT)) {
                                    if (curPromo.getRedeemableCredits().compareTo(
                                            cond.getAmount()) == -1) {
                                        // remove incPromo
                                        toBeDropped.add(
                                                new PromoOfferPair(
                                                        incPromo.getApplicableCiExternalId(),
                                                        incPromo.getGrantOfferCi()));
                                    } else {
                                        // keep credit
                                        continue;
                                    }
                                } else if (cond.getOn().equalsIgnoreCase(
                                        IncompatibilityCondition.ON_INCOMPATIBLE_PROMO_AMOUNT)) {
                                    if (incPromo.getRedeemableCredits().compareTo(
                                            cond.getAmount()) == -1) {
                                        // remove incPromo
                                        toBeDropped.add(
                                                new PromoOfferPair(
                                                        incPromo.getApplicableCiExternalId(),
                                                        incPromo.getGrantOfferCi()));
                                    } else {
                                        // keep credit
                                        continue;
                                    }
                                } else {
                                    // invalid condition ignore rule
                                    continue;
                                }
                            } else if (cond.getOperator().equalsIgnoreCase(
                                    IncompatibilityCondition.OPERATOR_LE)) {
                                if (cond.getOn().equalsIgnoreCase(
                                        IncompatibilityCondition.ON_CURRENT_PROMO_AMOUNT)) {
                                    if (curPromo.getRedeemableCredits().compareTo(
                                            cond.getAmount()) <= 0) {
                                        // remove incPromo
                                        toBeDropped.add(
                                                new PromoOfferPair(
                                                        incPromo.getApplicableCiExternalId(),
                                                        incPromo.getGrantOfferCi()));
                                    } else {
                                        // keep credit
                                        continue;
                                    }
                                } else if (cond.getOn().equalsIgnoreCase(
                                        IncompatibilityCondition.ON_INCOMPATIBLE_PROMO_AMOUNT)) {
                                    if (incPromo.getRedeemableCredits().compareTo(
                                            cond.getAmount()) <= 0) {
                                        // remove incPromo
                                        toBeDropped.add(
                                                new PromoOfferPair(
                                                        incPromo.getApplicableCiExternalId(),
                                                        incPromo.getGrantOfferCi()));
                                    } else {
                                        // keep credit
                                        continue;
                                    }
                                } else {
                                    // invalid condition ignore rule
                                    continue;
                                }
                            } else if (cond.getOperator().equalsIgnoreCase(
                                    IncompatibilityCondition.OPERATOR_EQ)) {
                                if (cond.getOn().equalsIgnoreCase(
                                        IncompatibilityCondition.ON_CURRENT_PROMO_AMOUNT)) {
                                    if (curPromo.getRedeemableCredits().compareTo(
                                            cond.getAmount()) == 0) {
                                        // remove incPromo
                                        toBeDropped.add(
                                                new PromoOfferPair(
                                                        incPromo.getApplicableCiExternalId(),
                                                        incPromo.getGrantOfferCi()));
                                    } else {
                                        // keep credit
                                        continue;
                                    }
                                } else if (cond.getOn().equalsIgnoreCase(
                                        IncompatibilityCondition.ON_INCOMPATIBLE_PROMO_AMOUNT)) {
                                    if (incPromo.getRedeemableCredits().compareTo(
                                            cond.getAmount()) == 0) {
                                        // remove incPromo
                                        toBeDropped.add(
                                                new PromoOfferPair(
                                                        incPromo.getApplicableCiExternalId(),
                                                        incPromo.getGrantOfferCi()));
                                    } else {
                                        // keep credit
                                        continue;
                                    }
                                } else {
                                    // invalid condition ignore rule
                                    continue;
                                }
                            } else {
                                // invalid condition ignore rule
                                continue;
                            }
                        } else {
                            // invalid condition ignore rule
                            continue;
                        }
                    } else {
                        // ic should be deleted
                        toBeDropped.add(
                                new PromoOfferPair(
                                        incPromo.getApplicableCiExternalId(),
                                        incPromo.getGrantOfferCi()));
                    }
                }
            }
        }

        toBeDropped.forEach(cName -> {
            CreditStage cs = stage.getCreditMap().get(cName);
            cs.updateGrantsAsNonTransferable();
        });

        INFO(
                m_logger, loggingKey + methodName + StringUtils.SPACE + "Incompatibile credits: "
                        + toBeDropped);
    }

}
