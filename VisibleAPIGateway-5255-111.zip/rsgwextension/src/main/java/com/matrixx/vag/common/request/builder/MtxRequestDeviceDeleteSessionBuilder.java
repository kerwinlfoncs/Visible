package com.matrixx.vag.common.request.builder;

import com.matrixx.datacontainer.mdc.MtxDeviceSearchData;
import com.matrixx.datacontainer.mdc.MtxRequestDeviceDeleteSession;
import com.matrixx.vag.common.coverage.Generated;

@Generated
public class MtxRequestDeviceDeleteSessionBuilder {
	MtxDeviceSearchData searchData;
    public MtxRequestDeviceDeleteSession build() {
		if(searchData==null) {
			this.searchData = new MtxDeviceSearchData();	
		}
		MtxRequestDeviceDeleteSession device = new MtxRequestDeviceDeleteSession();
    	device.setDeviceSearchData(searchData);
    	return device;
    }
}
