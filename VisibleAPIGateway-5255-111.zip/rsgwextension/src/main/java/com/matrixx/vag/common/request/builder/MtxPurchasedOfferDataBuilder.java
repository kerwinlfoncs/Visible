package com.matrixx.vag.common.request.builder;

import java.beans.IntrospectionException;
import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;

import com.matrixx.datacontainer.MtxTimestamp;
import com.matrixx.datacontainer.mdc.MtxPurchasedOfferData;
import com.matrixx.datacontainer.mdc.VisiblePurchasedOfferExtension;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.exception.CommonUtilsException;
import org.apache.commons.lang3.StringUtils;

/**
 * Defines property names and constants used by the API gateway.
 *
 * @author unico
 */
public class MtxPurchasedOfferDataBuilder {

    String brand;
    String beneficiaryExternalId;
    String chargeId;
    String classCode;
    String coreBasePlanCI;
    String creditGrantType;
    String creditReason;
    String deviceDetails;
    String deviceSku;
    String info;
    String goodType;
    String groupName;
    String groupTier;
    String offerChangeType;
    String offerCiExternalId;
    String orderId;
    String planID;
    String promotionName;
    String taxDetails;

    BigDecimal amount;
    BigDecimal promotionLimit;

    Long groupMemberCount;
    Long chargePurchaseProrationType;

    boolean needExtn = false;
    Boolean preActiveState = null;

    MtxTimestamp endTime;
    MtxTimestamp autoActivationTime;

    Set<String> creditTaxDetailsArray = new HashSet<String>();

    VisiblePurchasedOfferExtension existingOfferExtn;

    public MtxPurchasedOfferData build() {

        VisiblePurchasedOfferExtension offerExtn = null;

        if (this.existingOfferExtn != null) {
            offerExtn = this.existingOfferExtn;
        } else if (needExtn) {
            offerExtn = new VisiblePurchasedOfferExtension();
        }

        if (StringUtils.isNotBlank(this.orderId) && StringUtils.isBlank(offerExtn.getOrderId())) {
            offerExtn.setOrderId(this.orderId);
        }

        if (this.amount != null && offerExtn.getChargeAmount() == null) {
            offerExtn.setChargeAmount(this.amount);
        }

        if (StringUtils.isNotBlank(this.creditReason)
                && StringUtils.isBlank(offerExtn.getCreditReason())) {
            offerExtn.setCreditReason(this.creditReason);
        }

        if (StringUtils.isNotBlank(this.info) && StringUtils.isBlank(offerExtn.getInfo())) {
            offerExtn.setInfo(this.info);
        }

        if (StringUtils.isNotBlank(this.goodType) && StringUtils.isBlank(offerExtn.getGoodType())) {
            offerExtn.setGoodType(this.goodType);
        }

        if (StringUtils.isNotBlank(this.planID) && StringUtils.isBlank(offerExtn.getPlanID())) {
            offerExtn.setPlanID(this.planID);
        }

        if (StringUtils.isNotBlank(this.taxDetails)
                && StringUtils.isBlank(offerExtn.getTaxDetails())) {
            offerExtn.setTaxDetails(this.taxDetails);
        }

        if (StringUtils.isNotBlank(this.deviceDetails)
                && StringUtils.isBlank(offerExtn.getDeviceDetails())) {
            offerExtn.setDeviceDetails(this.deviceDetails);
        }

        if (StringUtils.isNotBlank(this.deviceSku) && StringUtils.isBlank(offerExtn.getSku())) {
            offerExtn.setSku(this.deviceSku);
        }

        if (StringUtils.isNotBlank(this.chargeId) && StringUtils.isBlank(offerExtn.getChargeId())) {
            offerExtn.setChargeId(this.chargeId);
        }

        if (StringUtils.isNotBlank(this.creditGrantType)
                && StringUtils.isBlank(offerExtn.getCreditGrantType())) {
            offerExtn.setCreditGrantType(this.creditGrantType);
        }

        if (StringUtils.isNotBlank(this.brand) && StringUtils.isBlank(offerExtn.getBrand())) {
            offerExtn.setBrand(this.brand);
        }

        if (StringUtils.isNotBlank(this.beneficiaryExternalId)) {
            offerExtn.setBeneficiaryExternalId(this.beneficiaryExternalId);
        }
        
        if (StringUtils.isNotBlank(this.groupName)
                && StringUtils.isBlank(offerExtn.getGroupName())) {
            offerExtn.setGroupName(this.groupName);
        }

        if (StringUtils.isNotBlank(this.groupTier)
                && StringUtils.isBlank(offerExtn.getGroupTier())) {
            offerExtn.setGroupTier(this.groupTier);
        }

        if (StringUtils.isNotBlank(this.offerChangeType)
                && StringUtils.isBlank(offerExtn.getOfferChangeType())) {
            offerExtn.setOfferChangeType(this.offerChangeType);
        }

        if (this.groupMemberCount != null && offerExtn.getGroupMemberCount() == null) {
            offerExtn.setGroupMemberCount(this.groupMemberCount);
        }

        if (StringUtils.isNotBlank(this.coreBasePlanCI)
                && StringUtils.isBlank(offerExtn.getCoreBasePlanCI())) {
            offerExtn.setCoreBasePlanCI(this.coreBasePlanCI);
        }

        if (StringUtils.isNotBlank(this.classCode)
                && StringUtils.isBlank(offerExtn.getClassCode())) {
            offerExtn.setClassCode(this.classCode);
        }

        if (StringUtils.isNotBlank(this.promotionName)
                && StringUtils.isBlank(offerExtn.getPromotionName())) {
            offerExtn.setPromotionName(this.promotionName);
        }

        if (this.promotionLimit != null && offerExtn.getPromotionLimit() == null) {
            offerExtn.setPromotionLimit(this.promotionLimit);
        }

        if ((this.creditTaxDetailsArray != null && !this.creditTaxDetailsArray.isEmpty())
                && (offerExtn.getCreditTaxDetailsArray() == null
                        || offerExtn.getCreditTaxDetailsArray().isEmpty())) {
            for (String taxString : this.creditTaxDetailsArray) {
                if (StringUtils.isNotBlank(taxString)) {
                    offerExtn.getCreditTaxDetailsArrayAppender().add(taxString);
                }
            }
        }

        MtxPurchasedOfferData offerData = new MtxPurchasedOfferData();
        if (StringUtils.isNotBlank(this.offerCiExternalId)) {
            offerData.setExternalId(this.offerCiExternalId);
        }

        offerData.setAttr(offerExtn);

        if (this.chargePurchaseProrationType != null) {
            offerData.setChargePurchaseProrationType(this.chargePurchaseProrationType);
        }

        if (this.endTime != null) {
            offerData.setEndTime(this.endTime);
        }

        if (this.autoActivationTime != null) {
            offerData.setAutoActivationTime(autoActivationTime);
        }

        if (preActiveState != null) {
            offerData.setPreActiveState(preActiveState.booleanValue());
        }

        return offerData;
    }

    public MtxPurchasedOfferDataBuilder withOfferExternalId(String offerCiExternalId) {
        this.offerCiExternalId = offerCiExternalId;
        return this;
    }

    public MtxPurchasedOfferDataBuilder withOrderId(String orderId) {
        this.orderId = orderId;
        needExtn = true;
        return this;
    }

    public MtxPurchasedOfferDataBuilder withDeviceSku(String deviceSku) {
        this.deviceSku = deviceSku;
        needExtn = true;
        return this;
    }

    public MtxPurchasedOfferDataBuilder withAmount(BigDecimal amount) {
        this.amount = amount;
        needExtn = true;
        return this;
    }

    public MtxPurchasedOfferDataBuilder withTaxDetails(String taxDetails) {
        this.taxDetails = taxDetails;
        needExtn = true;
        return this;
    }

    public MtxPurchasedOfferDataBuilder withDeviceDetails(String deviceDetails) {
        this.deviceDetails = deviceDetails;
        needExtn = true;
        return this;
    }

    public MtxPurchasedOfferDataBuilder withChargeId(String chargeId) {
        this.chargeId = chargeId;
        needExtn = true;
        return this;
    }

    public MtxPurchasedOfferDataBuilder withGoodType(String goodType) {
        this.goodType = goodType;
        needExtn = true;
        return this;
    }

    public MtxPurchasedOfferDataBuilder withInfo(String info) {
        this.info = info;
        needExtn = true;
        return this;
    }

    public MtxPurchasedOfferDataBuilder withCreditGrantType(String creditGrantType) {
        this.creditGrantType = creditGrantType;
        needExtn = true;
        return this;
    }

    public MtxPurchasedOfferDataBuilder withCreditReason(String creditReason) {
        this.creditReason = creditReason;
        needExtn = true;
        return this;
    }

    public MtxPurchasedOfferDataBuilder withChargePurchaseProrationType(Long chargePurchaseProrationType) {
        this.chargePurchaseProrationType = chargePurchaseProrationType;
        return this;
    }

    public MtxPurchasedOfferDataBuilder withEndTime(MtxTimestamp endTime) {
        this.endTime = endTime;
        return this;
    }

    public MtxPurchasedOfferDataBuilder withAutoActivationTime(MtxTimestamp autoActivationTime) {
        this.autoActivationTime = autoActivationTime;
        return this;
    }

    public MtxPurchasedOfferDataBuilder withOfferExtn(VisiblePurchasedOfferExtension existingOfferExtn)
            throws CommonUtilsException, IntrospectionException {
        this.existingOfferExtn = CommonUtils.cloneVisiblePurchasedOfferExtension(existingOfferExtn);
        return this;
    }

    public MtxPurchasedOfferDataBuilder withGroupName(String groupName) {
        this.groupName = groupName;
        needExtn = true;
        return this;
    }

    public MtxPurchasedOfferDataBuilder withBrand(String brand) {
        this.brand = brand;
        needExtn = true;
        return this;
    }

    public MtxPurchasedOfferDataBuilder withBeneficiaryExternalId(String beneficiaryExternalId) {
        if (StringUtils.isNotBlank(beneficiaryExternalId)) {
            this.beneficiaryExternalId = beneficiaryExternalId;
            needExtn = true;
        }
        return this;
    }
    
    public MtxPurchasedOfferDataBuilder withGroupTier(String groupTier) {
        this.groupTier = groupTier;
        needExtn = true;
        return this;
    }

    public MtxPurchasedOfferDataBuilder withGroupMemberCount(Long groupMemberCount) {
        this.groupMemberCount = groupMemberCount;
        needExtn = true;
        return this;
    }

    public MtxPurchasedOfferDataBuilder withCreditTaxDetails(String creditTaxDetails) {
        if (StringUtils.isNotBlank(creditTaxDetails)) {
            this.creditTaxDetailsArray.add(creditTaxDetails);
            needExtn = true;
        }
        return this;
    }

    public MtxPurchasedOfferDataBuilder withCoreBasePlanCI(String coreBasePlanCI) {
        this.coreBasePlanCI = coreBasePlanCI;
        needExtn = true;
        return this;
    }

    public MtxPurchasedOfferDataBuilder withOfferChangeType(String offerChangeType) {
        this.offerChangeType = offerChangeType;
        needExtn = true;
        return this;
    }

    public MtxPurchasedOfferDataBuilder withClassCode(String classCode) {
        this.classCode = classCode;
        needExtn = true;
        return this;
    }

    public MtxPurchasedOfferDataBuilder withPromotionName(String promotionName) {
        this.promotionName = promotionName;
        needExtn = true;
        return this;
    }

    public MtxPurchasedOfferDataBuilder withPromotionLimit(BigDecimal promotionLimit) {
        this.promotionLimit = promotionLimit;
        needExtn = true;
        return this;
    }

    public MtxPurchasedOfferDataBuilder withPreActiveState(boolean preActiveState) {
        if (preActiveState) {
            this.preActiveState = Boolean.TRUE;
        } else {
            this.preActiveState = Boolean.FALSE;
        }
        return this;
    }

    public MtxPurchasedOfferDataBuilder withPlanID(String planID) {
        this.planID = planID;
        needExtn = true;
        return this;
    }
}
