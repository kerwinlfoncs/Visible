/**
 * 
 */
package com.matrixx.vag.exception;

import com.matrixx.vag.common.Constants.RESULT_CODES;

/**
 * @author mnguyen
 */
public class ManualPayException extends IntegrationServiceException {

    private static final long serialVersionUID = 2492033412624981760L;

    /**
     * @param resultCode
     * @param message
     */
    public ManualPayException(Long resultCode, String message) {
        super(resultCode, message);
    }

    public ManualPayException(String message) {
        super(RESULT_CODES.RESULT_CODE_CUSTOM_INTERNAL_ERROR, message);
    }
}
