package com.matrixx.vag.exception;

/**
 * Exception thrown upon encountering an error with processing subscriber offers.
 *
 * @author unico
 */
public class CommonUtilsException extends VisibleServiceException {

    private static final long serialVersionUID = -7127081010006047559L;

    public CommonUtilsException(Long resultCode, String message) {
        super(resultCode, message);
    }
}
