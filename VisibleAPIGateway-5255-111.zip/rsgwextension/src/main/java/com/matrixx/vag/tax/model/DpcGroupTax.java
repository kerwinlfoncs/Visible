package com.matrixx.vag.tax.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.ArrayList;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL) // Ignore unused fields to reduce payload size.
public class DpcGroupTax {

    private String dpcGroup;

    private String planID;

    private String classCode;

    private List<String> taxTypeExclusionList;
    private final List<DpcItemTax> dpcItemList = new ArrayList<DpcItemTax>();

    public String getDpcGroup() {
        return dpcGroup;
    }

    public void setDpcGroup(String dpcGroup) {
        this.dpcGroup = dpcGroup;
    }

    public String getPlanID() {
        return planID;
    }

    public void setPlanID(String planID) {
        this.planID = planID;
    }

    public String getClassCode() {
        return classCode;
    }

    public void setClassCode(String classCode) {
        this.classCode = classCode;
    }

    public List<String> getTaxTypeExclusionList() {
        return taxTypeExclusionList;
    }

    public void setTaxTypeExclusionList(List<String> taxTypeExclusionList) {
        this.taxTypeExclusionList = taxTypeExclusionList;
    }

    public List<DpcItemTax> getDpcItemList() {
        return dpcItemList;
    }

}
