package com.matrixx.vag.common.request.builder;

import org.apache.commons.lang3.StringUtils;

import com.matrixx.datacontainer.mdc.VisibleApiEventData;

public class VisibleApiEventDataBuilder {

    String orderId;
    VisibleApiEventData existingApiEventData;

    public VisibleApiEventData build() {
        VisibleApiEventData apiEventData = new VisibleApiEventData();

        if (existingApiEventData != null) {
            apiEventData = existingApiEventData;
        }else {
            apiEventData = new VisibleApiEventData(); 
        }
        if (StringUtils.isNotBlank(orderId)) {
            apiEventData.setOrderId(orderId);
        }   
        return apiEventData;
    }

    public VisibleApiEventDataBuilder withExistingApiEventData(VisibleApiEventData existingApiEventData) {
        if (existingApiEventData!=null) {
            this.existingApiEventData = existingApiEventData;
        }
        return this;
    }

    public VisibleApiEventDataBuilder withOrderId(String orderId) {
        if (StringUtils.isNotBlank(orderId)) {
            this.orderId = orderId;
        }
        return this;
    }    
}
