package com.matrixx.vag.advice.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.matrixx.datacontainer.MtxDate;
import com.matrixx.datacontainer.MtxTimestamp;
import com.matrixx.datacontainer.mdc.*;
import com.matrixx.vag.advice.model.ChangeServiceDataStage;
import com.matrixx.vag.advice.model.CiResourceIdPair;
import com.matrixx.vag.advice.model.CreditStage;
import com.matrixx.vag.advice.model.GlobalCreditStage;
import com.matrixx.vag.advice.model.Incompatibility;
import com.matrixx.vag.advice.model.IncompatibilityCondition;
import com.matrixx.vag.advice.model.PromoOfferPair;
import com.matrixx.vag.advice.model.ServiceStage;
import com.matrixx.vag.advice.model.SubscriberGroup;
import com.matrixx.vag.common.Constants.BALANCE_CONSTANTS;
import com.matrixx.vag.common.Constants.BRAINTREE_CONSTANTS;
import com.matrixx.vag.common.Constants.CREDIT_CONSTANTS;
import com.matrixx.vag.common.Constants.OFFER_CONSTANTS;
import com.matrixx.vag.common.coverage.Generated;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.exception.PaymentAdviceException;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.*;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import static com.matrixx.platform.LogUtils.DEBUG;
import static com.matrixx.platform.LogUtils.INFO;

public class AdviceDataStage {

    enum Advice {
        PAYMENT, QUOTE, PURCHASE, CHANGE
    }

    private String subscriptionExternalId;
    private String payerExternalId;
    private String subscriptionTimezone;
    private Advice adviceFor;
    private boolean adviceWithTaxes;
    private String requestGeoCode;
    private String subscriberGeoCode;
    private String payerGeoCode;
    private String ignorePayer;
    private String brand;
    private boolean isBaseOfferInAdvice; // Based on this decide tax template to be used
    private BigDecimal totalEstimatedAmount;
    private BigDecimal availableMainBalanceAmount;
    private BigDecimal consumableMainBalanceAmount;
    private BigDecimal reservedMainBalanceAmount;
    private BigDecimal rechargeAmount;
    private String serviceTaxApiErrorMessage;
    private MtxTimestamp cycleStartTime;
    private MtxTimestamp cycleEndTime;
    private MtxTimestamp nextCycleStartTime;
    private MtxTimestamp nextCycleEndTime;
    private final Map<CiResourceIdPair, VisibleOfferDetails> visibleOfferDetailsMap = new HashMap<CiResourceIdPair, VisibleOfferDetails>();
    private final Map<CiResourceIdPair, ServiceStage> payNowMap = new HashMap<CiResourceIdPair, ServiceStage>();

    // key - credit name, value-credit details
    private final Map<PromoOfferPair, CreditStage> creditMap = new HashMap<PromoOfferPair, CreditStage>();
    private final List<SubscriberGroup> subscriberGroupList = new ArrayList<SubscriberGroup>();;
    private final List<VisibleSubscriberDevice> subscriberDeviceList = new ArrayList<VisibleSubscriberDevice>();;
    private final long DEFAULT_CREDIT_PRIORITY = 0;
    private final List<String> ciListInPurchaseService = new ArrayList<String>();

    // applicable for MultiPurchase advice only
    private VisibleMultiRequestPurchaseService purchaseRequest;
    private static final Logger m_logger = LoggerFactory.getLogger(AdviceDataStage.class);
    private long resultCode;
    private String resultText;
    private MtxDate paidCycleStartDate; // Used by QuoteAdvice and ChangeServiceAdvice.
    private boolean paidCycleStartDateDefaulted;
    private final ChangeServiceDataStage changeServiceDataStage = new ChangeServiceDataStage();

    // key - GrantOfferName, value-Values from CI and Purchased offer. To avoid multiple subman
    // calls to read CI
    private final Map<String, GlobalCreditStage> creditMetadataMap = new HashMap<String, GlobalCreditStage>();
    private MtxResponseRecurringChargeInfo recurringChargeInfo;
    private SubscriptionResponse subscriptionResponse;
    private final List<String> oneTimeOfferList = new ArrayList<String>();

    AdviceDataStage(SubscriptionResponse subscription,
                    Advice adviceFor,
                    String requestGeoCode,
                    boolean adviceWithTaxes) {
        setSubscriptionResponse(subscription);
        setIntialValuesWithSubscription(subscription, adviceFor, requestGeoCode, adviceWithTaxes);
    }

    AdviceDataStage(MtxResponseSubscription subscription,
                    Advice adviceFor,
                    String requestGeoCode,
                    boolean adviceWithTaxes) {
        setIntialValuesWithSubscription(subscription, adviceFor, requestGeoCode, adviceWithTaxes);
    }

    private void setIntialValuesWithSubscription(MtxResponseSubscription subscription,
                                                 Advice adviceFor,
                                                 String requestGeoCode,
                                                 boolean adviceWithTaxes) {
        this.subscriptionExternalId = subscription.getExternalId();
        this.setSubscriptionTimezone(subscription.getTimeZone());

        this.adviceFor = adviceFor;
        this.requestGeoCode = requestGeoCode;
        this.adviceWithTaxes = adviceWithTaxes;

        VisibleSubscriberExtension se = (VisibleSubscriberExtension) subscription.getAttr();
        this.subscriberGeoCode = se.getGeoCode();

        if (StringUtils.isBlank(this.subscriberGeoCode)) {
            this.subscriberGeoCode = subscription.getGeoCode();
        }
        
        if (StringUtils.isNotBlank(se.getBrand())) {
            setBrand(se.getBrand());
        } else {
            setBrand("");
        }

        setIntialValues();
    }

    private void setIntialValues() {
        this.paidCycleStartDateDefaulted = false;
        setBaseOfferInAdvice(false);
        setTotalEstimatedAmount(BigDecimal.ZERO);
        setAvailableMainBalanceAmount(BigDecimal.ZERO);
        setConsumableMainBalanceAmount(BigDecimal.ZERO);
        setRechargeAmount(BigDecimal.ZERO);
        setServiceTaxApiErrorMessage("");
        setCycleStartTime(null);
        setCycleEndTime(null);
    }

    public Map<PromoOfferPair, CreditStage> getCreditMap() {
        return creditMap;
    }

    public BigDecimal getTotalEstimatedAmount() {
        return totalEstimatedAmount;
    }

    public void setTotalEstimatedAmount(BigDecimal totalEstimatedAmount) {
        this.totalEstimatedAmount = totalEstimatedAmount;
    }

    public void subtractTotalEstimatedAmount(BigDecimal subtractAmount) {
        this.totalEstimatedAmount = totalEstimatedAmount.subtract(subtractAmount);
    }

    public void addToTotalEstimatedAmount(BigDecimal addAmount) {
        this.totalEstimatedAmount = totalEstimatedAmount.add(addAmount);
    }

    public BigDecimal getAvailableMainBalanceAmount() {
        return availableMainBalanceAmount;
    }

    public void setAvailableMainBalanceAmount(BigDecimal availableMainBalanceAmount) {
        this.availableMainBalanceAmount = availableMainBalanceAmount;
    }

    public BigDecimal getRechargeAmount() {
        return rechargeAmount;
    }

    public void setRechargeAmount(BigDecimal rechargeAmount) {
        this.rechargeAmount = rechargeAmount;
    }

    public Map<CiResourceIdPair, VisibleOfferDetails> getVisibleOfferDetailsMap() {
        return visibleOfferDetailsMap;
    }

    public VisibleOfferDetails getVisibleOfferDetails(String ciExternalId) {
        for (VisibleOfferDetails vod : visibleOfferDetailsMap.values()) {
            if (ciExternalId.equalsIgnoreCase(vod.getCatalogItemExternalId())) {
                return vod;
            }
        }
        return null;
    }

    public void appendVisibleOfferDetailsMap(String ciExternalId,
                                             Long resourceId,
                                             VisibleOfferDetails visibleOfferDetails) {
        visibleOfferDetailsMap.put(
                new CiResourceIdPair(ciExternalId, resourceId), visibleOfferDetails);
    }

    public String getServiceTaxApiErrorMessage() {
        return serviceTaxApiErrorMessage;
    }

    public void setServiceTaxApiErrorMessage(String serviceTaxApiErrorMessage) {
        this.serviceTaxApiErrorMessage = serviceTaxApiErrorMessage;
    }

    public BigDecimal getConsumableMainBalanceAmount() {
        return consumableMainBalanceAmount;
    }

    public void setConsumableMainBalanceAmount(BigDecimal consumableMainBalanceAmount) {
        this.consumableMainBalanceAmount = consumableMainBalanceAmount;
    }

    public MtxTimestamp getCycleStartTime() {
        return cycleStartTime;
    }

    public void setCycleStartTime(MtxTimestamp cycleStartTime) {
        this.cycleStartTime = cycleStartTime;
    }

    public MtxTimestamp getCycleEndTime() {
        return cycleEndTime;
    }

    public void setCycleEndTime(MtxTimestamp cycleEndTime) {
        this.cycleEndTime = cycleEndTime;
    }

    public MtxTimestamp getNextCycleStartTime() {
        return nextCycleStartTime;
    }

    public void setNextCycleStartTime(MtxTimestamp nextCycleStartTime) {
        this.nextCycleStartTime = nextCycleStartTime;
    }

    public MtxTimestamp getNextCycleEndTime() {
        return nextCycleEndTime;
    }

    public void setNextCycleEndTime(MtxTimestamp nextCycleEndTime) {
        this.nextCycleEndTime = nextCycleEndTime;
    }

    public List<SubscriberGroup> getSubscriberGroupList() {
        return subscriberGroupList;
    }

    public void appendSubscriberGroupList(SubscriberGroup subscriberGroup) {
        subscriberGroupList.add(subscriberGroup);
    }

    public Map<CiResourceIdPair, ServiceStage> getPayNowMap() {
        return payNowMap;
    }

    public void appendPayNowMap(CiResourceIdPair subscriptionId, ServiceStage payNow) {
        this.payNowMap.put(subscriptionId, payNow);
    }

    public ServiceStage getServiceStage(String ciExternalId, Long resourceId) {
        return payNowMap.get(new CiResourceIdPair(ciExternalId, resourceId));
    }

    public ServiceStage getServiceStage(String ciExternalId) {
        for (Entry<CiResourceIdPair, ServiceStage> entry : payNowMap.entrySet()) {
            if (entry.getKey().getCatalogItemExternalId().equals(ciExternalId)) {
                return entry.getValue();
            }
        }
        return null;
    }

    public Advice getAdviceFor() {
        return adviceFor;
    }

    public boolean isBaseOfferInAdvice() {
        return isBaseOfferInAdvice;
    }

    public void setBaseOfferInAdvice(boolean isBaseOfferInAdvice) {
        this.isBaseOfferInAdvice = isBaseOfferInAdvice;
    }

    public boolean isAdviceWithTaxes() {
        return adviceWithTaxes;
    }

    public String getRequestGeoCode() {
        return requestGeoCode;
    }

    public String getSubscriberGeoCode() {
        return subscriberGeoCode;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public List<String> getCiListInPurchaseService() {
        return ciListInPurchaseService;
    }

    public void addCiListInPurchaseService(String ci) {
        if (StringUtils.isNotBlank(ci)) {
            this.ciListInPurchaseService.add(ci.trim());
        }
    }

    public VisibleMultiRequestPurchaseService getPurchaseRequest() {
        return purchaseRequest;
    }

    public void setPurchaseRequest(VisibleMultiRequestPurchaseService purchaseRequest) {
        this.purchaseRequest = purchaseRequest;
    }

    public long getResultCode() {
        return resultCode;
    }

    public void setResultCode(long resultCode) {
        this.resultCode = resultCode;
    }

    public String getResultText() {
        return resultText;
    }

    public void setResultText(String resultText) {
        this.resultText = resultText;
    }

    public String getSubscriptionExternalId() {
        return subscriptionExternalId;
    }

    public void setSubscriptionExternalId(String subscriptionExternalId) {
        this.subscriptionExternalId = subscriptionExternalId;
    }

    public MtxDate getPaidCycleStartDate() {
        return paidCycleStartDate;
    }

    public void setPaidCycleStartDate(MtxDate paidCycleStartDate) {
        this.paidCycleStartDate = paidCycleStartDate;
    }

    public void defaultPaidCycleStartDate() {
        this.paidCycleStartDate = new MtxDate(
                Instant.now().toEpochMilli() - TimeUnit.DAYS.toMillis(1));
        this.paidCycleStartDateDefaulted = true;
    }

    public ChangeServiceDataStage getChangeServiceDataStage() {
        return changeServiceDataStage;
    }

    public boolean isPaidCycleStartDateDefaulted() {
        return paidCycleStartDateDefaulted;
    }

    public List<VisibleSubscriberDevice> getSubscriberDeviceList() {
        return subscriberDeviceList;
    }

    public Map<String, GlobalCreditStage> getCreditMetadataMap() {
        return creditMetadataMap;
    }

    public String getSubscriptionTimezone() {
        return subscriptionTimezone;
    }

    public void setSubscriptionTimezone(String subscriptionTimezone) {
        this.subscriptionTimezone = subscriptionTimezone;
    }

    public SubscriptionResponse getSubscriptionResponse() {
        return subscriptionResponse;
    }

    public void setSubscriptionResponse(SubscriptionResponse subscriptionResponse) {
        this.subscriptionResponse = subscriptionResponse;
    }

    public MtxResponseRecurringChargeInfo getRecurringChargeInfo() {
        return recurringChargeInfo;
    }

    public void setRecurringChargeInfo(MtxResponseRecurringChargeInfo recurringChargeInfo) {
        this.recurringChargeInfo = recurringChargeInfo;
    }
    
    public String getPayerExternalId() {
        return payerExternalId;
    }

    public void setPayerExternalId(String payerExternalId) {
        if(StringUtils.isNotBlank(payerExternalId)) {
            this.payerExternalId = payerExternalId;    
        }        
    }

    public String getPayerGeoCode() {
        return payerGeoCode;
    }

    public void setPayerGeoCode(String payerGeoCode) {
        if(StringUtils.isNotBlank(payerGeoCode)) {
            this.payerGeoCode = payerGeoCode;    
        }        
    }
    
    public List<String> getOneTimeOfferList() {
        return oneTimeOfferList;
    }

    public BigDecimal getReservedMainBalanceAmount() {
        return reservedMainBalanceAmount;
    }

    public void setReservedMainBalanceAmount(BigDecimal reservedMainBalanceAmount) {
        this.reservedMainBalanceAmount = reservedMainBalanceAmount;
    }

    public boolean isPromoInCreditMap(String grantCi) {
        for (CreditStage cs : this.creditMap.values()) {
            if (cs.getGrantOfferCi() != null && grantCi.equalsIgnoreCase(cs.getGrantOfferCi())) {
                return true;
            }
        }
        return false;
    }

    public String getIgnorePayer() {
        return ignorePayer;
    }

    public void setIgnorePayer(String ignorePayer) {
        this.ignorePayer = ignorePayer;
    }

    @Generated
    public String toJson() {
        ObjectMapper mapper = new ObjectMapper();
        try {
            Map<String, Object> longMap = new HashMap<String, Object>();    
            longMap.put("subscriptionExternalId", subscriptionExternalId);
            longMap.put("adviceFor", adviceFor);
            longMap.put("adviceWithTaxes", adviceWithTaxes);
            
            if(StringUtils.isNotBlank(requestGeoCode)) {
                longMap.put("requestGeoCode", requestGeoCode);    
            }
            
            longMap.put("subscriberGeoCode", subscriberGeoCode);
            if(StringUtils.isNotBlank(brand)) {
                longMap.put("brand", brand);
            }

            longMap.put("isBaseOfferInAdvice", isBaseOfferInAdvice);
            longMap.put("totalEstimatedAmount", totalEstimatedAmount);
            
            longMap.put("availableMainBalanceAmount", availableMainBalanceAmount);
            if(consumableMainBalanceAmount!=null) {
                longMap.put("consumableMainBalanceAmount", consumableMainBalanceAmount);    
            }
            
            if(reservedMainBalanceAmount!=null) {
                longMap.put("reservedMainBalanceAmount", reservedMainBalanceAmount);                
            }

            longMap.put("rechargeAmount", rechargeAmount);
            if(StringUtils.isNotBlank(serviceTaxApiErrorMessage)) {
                longMap.put("serviceTaxApiErrorMessage", serviceTaxApiErrorMessage);    
            }
            
            longMap.put("cycleStartTime", cycleStartTime);
            longMap.put("cycleEndTime", cycleEndTime);
            longMap.put("visibleOfferDetailsMap", visibleOfferDetailsMap);
            longMap.put("payNowMap", payNowMap);
            longMap.put("creditMap", creditMap);
            longMap.put("subscriberGroupList", subscriberGroupList);
            longMap.put("ciListInPurchaseService", ciListInPurchaseService);
            longMap.put("resultCode", resultCode);
            longMap.put("resultText", resultText);
            longMap.put("paidCycleStartDate", paidCycleStartDate);
            longMap.put("paidCycleStartDateDefaulted", paidCycleStartDateDefaulted);
            longMap.put("subscriptionTimezone", subscriptionTimezone);
            if(StringUtils.isNotBlank(payerExternalId)) {
                longMap.put("payerExternalId", payerExternalId);    
            }
            if(StringUtils.isNotBlank(ignorePayer)) {
                longMap.put("ignorePayer", ignorePayer);    
            }
            
            return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(longMap);
        } catch (JsonProcessingException e) {
            DEBUG(m_logger, " toJson Error: " + ExceptionUtils.getStackTrace(e));
            return null;
        }
    }

    /**
     * Check if total consumable balance is more than overall eligible charges. If yes, mark all
     * grants as non transferable.
     *
     * @param eligibleCreditCiMap
     */
    public void updateConsumableCreditsMoreThanChargeCondition(String loggingKey) {
        final String methodName = "updateConsumableCreditsMoreThanChargeCondition: ";
        for (CreditStage cs : this.getCreditMap().values()) {
            BigDecimal applicableCharges = BigDecimal.ZERO;
            BigDecimal applicableMaxPromo = BigDecimal.ZERO;
            for (String applicableCI : cs.getGlobalCreditStage().getApplicableCiSet()) {
                for (ServiceStage ps : this.getPayNowMap().values()) {
                    if (applicableCI.equalsIgnoreCase(ps.getCatalogItemExternalId())) {
                        applicableCharges = applicableCharges.add(ps.getProratedDiscountPrice());
                        applicableMaxPromo = applicableMaxPromo.add(ps.getMaxPromo());
                    }
                }
            }
            if (applicableCharges.compareTo(cs.getAvailableCreditsConsumable()) <= 0) {
                INFO(
                        m_logger,
                        loggingKey + methodName + StringUtils.SPACE + cs.getPromotionName()
                                + " can not be used. Consumable credits are more than charges."
                                + StringUtils.SPACE + "applicable charges for "
                                + cs.getGlobalCreditStage().getApplicableCiCsv() + StringUtils.SPACE
                                + "are" + StringUtils.SPACE + applicableCharges);
            }
            if (applicableMaxPromo.compareTo(cs.getAvailableCreditsConsumable()) <= 0) {
                INFO(
                        m_logger,
                        loggingKey + methodName + StringUtils.SPACE + cs.getPromotionName()
                                + " can not be used. Consumable credits are more than maximum redeemable promotions."
                                + StringUtils.SPACE + "maximum redeemable promotions for "
                                + cs.getGlobalCreditStage().getApplicableCiCsv() + StringUtils.SPACE
                                + "are" + StringUtils.SPACE + applicableMaxPromo);
            }
        }
    }

    /**
     * update default order
     */
    private void updateDefaultRedeemOrder() {
        long highestPriority = 0;
        for (CreditStage credit : getCreditMap().values()) {
            if (credit.getCreditPriority() < 0) {
                credit.getGlobalCreditStage().setCreditPriority(DEFAULT_CREDIT_PRIORITY);
            }
            if (credit.getCreditPriority() > highestPriority) {
                highestPriority = credit.getCreditPriority();
            }
        }

        for (CreditStage credit : getCreditMap().values()) {
            credit.getGlobalCreditStage().setRedeemOrder(
                    highestPriority - credit.getCreditPriority() + 1);
        }
    }


    private void applyPercentagePromoEntiretyRules(String loggingKey) {
        final String methodName = "applyPercentagePromoEntiretyRules: ";
        Iterator<CreditStage> itr = this.creditMap.values().iterator();

        while (itr.hasNext()) {
            CreditStage cs = itr.next();
            if (!CREDIT_CONSTANTS.GRANT_TYPE_PERCENTAGE.equalsIgnoreCase(cs.getCreditGrantType())) {
                continue;
            }

            if (cs.getAvailableCreditsConsumable().signum() > 0) {
                INFO(
                        m_logger, loggingKey + methodName + StringUtils.SPACE
                                + cs.getPromotionName() + " is percentage based promo.");
                INFO(
                        m_logger,
                        loggingKey + methodName + StringUtils.SPACE + cs.getPromotionName()
                                + " has consumables. Adding grants will result in redeemables more than allowed percentage. Ignoring promo.");
            } else if (cs.getRedeemableCredits().compareTo(cs.getAvailableCredits()) != 0) {
                INFO(
                        m_logger, loggingKey + methodName + StringUtils.SPACE
                                + cs.getPromotionName() + " is percentage based promo.");
                INFO(
                        m_logger,
                        loggingKey + methodName + StringUtils.SPACE + cs.getPromotionName()
                                + " has redeemables more than allowed percentage. Ignoring promo.");
            }

            if (cs.getRedeemableCredits().compareTo(cs.getAvailableCredits()) != 0
                    || cs.getAvailableCreditsConsumable().signum() > 0) {
                // Make grants non transferable so redeemable will be within percent
                cs.setRedeemableCreditsToZero();
                cs.updateGrantsAsNonTransferable();
                INFO(
                        m_logger,
                        loggingKey + methodName + StringUtils.SPACE + cs.getPromotionName()
                                + " updated. Promo will be ignored due to entirety rule.");
                INFO(
                        m_logger, loggingKey + methodName + StringUtils.SPACE
                                + cs.getPromotionName() + " : " + cs.toShortJson());
            }
        }
    }

    /**
     * Update credit amounts based on availability and usage/charges
     *
     * @param eligibleCharges
     * @param eligibleCiSet
     */
    private void redeemCredits(String loggingKey) {
        final String methodKey = loggingKey + " redeemCredits: ";
        INFO(m_logger, methodKey);
        Map<PromoOfferPair, Long> CreditOrderMap = new HashMap<PromoOfferPair, Long>();
        for (CreditStage credit : this.getCreditMap().values()) {
            CreditOrderMap.put(
                    new PromoOfferPair(
                            credit.getApplicableCiExternalId(), credit.getGrantOfferCi()),
                    credit.getCiPromoRedeemOrder());
        }

        // Set will handle multiple credits with same redeem order
        Set<Long> promoRedeemOrderSet = new HashSet<Long>(CreditOrderMap.values());

        // Sort redeem orders
        List<Long> promoRedeemOrderList = (new ArrayList<Long>(
                new HashSet<Long>(promoRedeemOrderSet)));
        promoRedeemOrderList.sort(Comparator.naturalOrder());
        DEBUG(m_logger, methodKey + "Map of promo redeem orders " + CreditOrderMap);
        DEBUG(m_logger, methodKey + "List of promo redeem orders " + promoRedeemOrderList);

        for (Long promoOrder : promoRedeemOrderList) {
            for (PromoOfferPair ciPromoKey : CreditOrderMap.keySet()) {
                if (CreditOrderMap.get(ciPromoKey).longValue() != promoOrder.longValue()) {
                    continue;
                }
                // else
                CreditStage credit = this.getCreditMap().get(ciPromoKey);
                if (credit.getApplicableServiceStage() == null) {
                    // if a paynowstage is not linked to a promo that means applicable offer is not
                    // part of advice. So ignore credit
                    continue;
                }
                BigDecimal remainingChargesBeforeConsumable = getRemainingChargesForConsumables(
                        credit.getApplicableServiceStage());
                if (remainingChargesBeforeConsumable.signum() < 0) {
                    continue;
                }

                redeemSingleConsumable(loggingKey, remainingChargesBeforeConsumable, credit);
            }
        }

        for (Long promoOrder : promoRedeemOrderList) {
            for (PromoOfferPair ciPromoKey : CreditOrderMap.keySet()) {

                if (CreditOrderMap.get(ciPromoKey).longValue() != promoOrder.longValue()) {
                    continue;
                }

                // else
                CreditStage credit = this.getCreditMap().get(ciPromoKey);
                if (credit.getApplicableServiceStage() == null) {
                    // if a paynowstage is not linked to a promo that means applicable offer is not
                    // part of advice. So ignore credit
                    continue;
                }

                ServiceStage ps = credit.getApplicableServiceStage();
                BigDecimal alreadyRedeemed = getRedeemedForService(ps);
                BigDecimal redeemLimit = BigDecimal.ZERO;

                if (OFFER_CONSTANTS.OFFER_TYPE_GIFT.equalsIgnoreCase(credit.getGrantOfferType())) {
                    if (ps.getTaxFeeAmount().compareTo(ps.getMaxPromo()) >= 0) {
                        redeemLimit = ps.getTaxFeeAmount().subtract(alreadyRedeemed);
                    } else {
                        redeemLimit = ps.getMaxPromo().subtract(alreadyRedeemed);
                    }
                } else {
                    redeemLimit = ps.getMaxPromo().subtract(alreadyRedeemed);
                }

                if (redeemLimit.signum() < 0) {
                    continue;
                }

                redeemSingleGrant(loggingKey, redeemLimit, credit);
            }
        }

        roundCredits();

        for (PromoOfferPair ciPromoKey : CreditOrderMap.keySet()) {
            CreditStage credit = this.getCreditMap().get(ciPromoKey);
            ServiceStage service = this.getServiceStage(ciPromoKey.getOfferCiExternalId());
            if (OFFER_CONSTANTS.OFFER_TYPE_GIFT.equalsIgnoreCase(credit.getGrantOfferType())) {
                service.setRedeemableGiftAmount(credit.getRedeemableCredits());
            }
        }
    }

    private void roundCredits() {
        for (CreditStage credit : this.getCreditMap().values()) {

            if (credit.isNoCap()) {
            } else if (credit.getCreditCap() == null) {
            }
            // Use floor to make sure that redeeming never exceeds cap
            else if (credit.getEstimatedTransferableCredits() != null
                    && credit.getEstimatedTransferableCredits().signum() > 0) {
                if (credit.getRedeemableCredits().compareTo(credit.getCreditCap()) < 0) {
                    credit.setEstimatedTransferableCredits(
                            credit.getEstimatedTransferableCredits().setScale(
                                    BRAINTREE_CONSTANTS.BT_AMOUNT_PRECISION, RoundingMode.FLOOR));
                    // It is not accurate to round down two numbers and expect them to be in sync.
                    // Should be relooked in future for a better approach
                    credit.setRedeemableCredits(
                            credit.getRedeemableCredits().setScale(
                                    BRAINTREE_CONSTANTS.BT_AMOUNT_PRECISION, RoundingMode.FLOOR));

                } else {
                    // This condition mostly does not happen. Only possibility is when
                    // consumption balance has more than credit cap.
                    credit.setEstimatedTransferableCredits(
                            credit.getEstimatedTransferableCredits().setScale(
                                    BRAINTREE_CONSTANTS.BT_AMOUNT_PRECISION, RoundingMode.CEILING));
                    credit.setRedeemableCredits(
                            credit.getRedeemableCredits().setScale(
                                    BRAINTREE_CONSTANTS.BT_AMOUNT_PRECISION, RoundingMode.CEILING));

                }
            }
        }
    }

    private BigDecimal getRedeemedForService(ServiceStage pStage) {
        // final String methodName = "getRemainingChargesForGrants:";
        BigDecimal alreadyRedeemed = BigDecimal.ZERO;

        for (CreditStage cs : this.creditMap.values()) {
            // This loop will take care of redeemables from consumables
            if (cs.getApplicableCiExternalId() != null) {
                if (pStage.getCatalogItemExternalId().equalsIgnoreCase(
                        cs.getApplicableCiExternalId())) {
                    alreadyRedeemed = alreadyRedeemed.add(cs.getRedeemableCredits());
                }
            }
        }

        return alreadyRedeemed;
    }

    private BigDecimal getRemainingChargesForConsumables(ServiceStage pStage) {
        // final String methodName = "getRemainingChargesForConsumables:";
        BigDecimal alreadyRedeemed = BigDecimal.ZERO;
        for (CreditStage cs : this.creditMap.values()) {
            // This loop will take care of redeemables from consumables
            if (cs.getApplicableCiExternalId() != null) {
                if (pStage.getCatalogItemExternalId().equalsIgnoreCase(
                        cs.getApplicableCiExternalId())) {
                    alreadyRedeemed = alreadyRedeemed.add(cs.getRedeemableCredits());
                }
            }
        }

        if (pStage.getTaxFeeAmount() != null
                && pStage.getTaxFeeAmount().compareTo(pStage.getProratedDiscountPrice()) >= 0) {
            return pStage.getTaxFeeAmount().subtract(alreadyRedeemed);
        } else {
            return pStage.getProratedDiscountPrice().subtract(alreadyRedeemed);
        }
    }

    private void redeemSingleGrant(String loggingKey,
                                   BigDecimal remainingCharges,
                                   CreditStage credit) {
        final String methodKey = loggingKey + " redeemSingleGrant: ";
        INFO(m_logger, methodKey);

        BigDecimal newCap = BigDecimal.ZERO;
        if (credit.isKeepTransferableZero()) {
            INFO(m_logger, methodKey + "Return due to isKeepTransferableZero: " + credit.isKeepTransferableZero());
            return;
        }
        BigDecimal grant = (credit.getAvailableCreditsGrant() != null)
                ? credit.getAvailableCreditsGrant() : BigDecimal.ZERO;
        if (grant.signum() <= 0) {
            // No grant
            INFO(m_logger, methodKey + "Return due to grant value: " + grant);
            return;
        }

        if (credit.getAvailableCreditsGrant().add(credit.getAvailableCreditsConsumable()).compareTo(
                credit.getGlobalRedeemables()) <= 0) {
            INFO(m_logger, methodKey + "Already redeemed: " + credit.getGlobalRedeemables()+" is greater than available credits: "+credit.getAvailableCreditsGrant().add(credit.getAvailableCreditsConsumable()));
            // Everything is already redeemed
            return;
        }

        if (credit.isNoCap()
                || OFFER_CONSTANTS.OFFER_TYPE_GIFT.equalsIgnoreCase(credit.getGrantOfferType())) {
            newCap = remainingCharges;
        } else {
            if (credit.getCreditCap().signum() > 0) {
                newCap = credit.getCreditCap();
            }
            if (credit.getRedeemableCredits() != null
                    && credit.getRedeemableCredits().signum() > 0) {
                newCap = credit.getCreditCap().subtract(credit.getRedeemableCredits()).signum() < 0
                        ? BigDecimal.ZERO
                        : credit.getCreditCap().subtract(credit.getRedeemableCredits());
            }
            if (newCap.compareTo(remainingCharges) >= 0) {
                newCap = remainingCharges;
            }
        }

        BigDecimal grantInRedeemable = credit.getRedeemableCredits().subtract(
                credit.getAvailableCreditsConsumable());
        BigDecimal remainingGrant = grant.subtract(grantInRedeemable).subtract(
                credit.getGrantsReservedForOtherCi());
        if (remainingGrant.compareTo(newCap) >= 0) {
            credit.setRedeemableCredits(credit.getRedeemableCredits().add(newCap));
        } else {
            credit.setRedeemableCredits(credit.getRedeemableCredits().add(remainingGrant));
        }

        credit.setEstimatedTransferableCredits(
                credit.getRedeemableCredits().subtract(credit.getRedeemableConsumables()));
        INFO(
                m_logger, methodKey + "updated Credit " + credit.getPromotionName()
                        + StringUtils.SPACE + credit.toJson());

        // Set value of remaining charges for next credit / iteration
        remainingCharges = remainingCharges.subtract(credit.getEstimatedTransferableCredits());
        if (remainingCharges.signum() < 0) {
            remainingCharges = BigDecimal.ZERO;
        }
        newCap = BigDecimal.ZERO;
    }

    private void redeemSingleConsumable(String loggingKey,
                                        BigDecimal remainingChargesWithMinCharge,
                                        CreditStage credit) {
        final String methodKey = loggingKey + " redeemSingleConsumable: ";

        if (credit.getAvailableCreditsConsumable().signum() <= 0) {
            INFO(m_logger, methodKey + "No consumables available.");
            return;
        }

        if (credit.getAvailableCreditsGrant().add(credit.getAvailableCreditsConsumable()).compareTo(
                credit.getGlobalRedeemables()) <= 0) {
            INFO(
                    m_logger,
                    methodKey + "All credits aready redeemed. Grant+Consumables= "
                            + credit.getAvailableCreditsGrant() + "+"
                            + credit.getAvailableCreditsConsumable() + "="
                            + credit.getAvailableCreditsGrant().add(
                                    credit.getAvailableCreditsConsumable())
                            + ">=" + credit.getGlobalRedeemables());
            return;
        }

        BigDecimal remainingConsumables = credit.getAvailableCreditsConsumable().subtract(
                credit.getGlobalCreditStage().getGlobalConsumablesReserved());
        if (remainingConsumables.signum() <= 0) {
            remainingConsumables = BigDecimal.ZERO;
        }

        if (credit.getAvailableCreditsConsumable() != null
                && remainingChargesWithMinCharge.compareTo(remainingConsumables) < 0) {
            // Consumable Credits more than remaining charges with min charge
            credit.setRedeemableConsumables(
                    remainingChargesWithMinCharge.add(credit.getRedeemableConsumables()));
            credit.setRedeemableCredits(
                    remainingChargesWithMinCharge.add(credit.getRedeemableCredits()));
        } else {
            // Charges are more than consumables. Add all consumables to redeemables.
            credit.setRedeemableConsumables(
                    remainingConsumables.add(credit.getRedeemableConsumables()));
            credit.setRedeemableCredits(remainingConsumables.add(credit.getRedeemableCredits()));
        }

        INFO(
                m_logger, methodKey + "Updated Credit " + credit.getPromotionName()
                        + StringUtils.SPACE + credit.toJson());
    }

    /**
     * Update credits
     *
     * @param eligibleCiSet
     * @param balPriMap
     * @throws PaymentAdviceException
     */
    public void updateCredits(String loggingKey) throws PaymentAdviceException {
        final String methodKey = loggingKey + " updateCredits: ";
        INFO(m_logger, methodKey);
        updateDefaultRedeemOrder();

        redeemCredits(loggingKey);// 1st Iteration

        AdviceUtils.applyIncompatibilityRules(loggingKey, this);
        applyPercentagePromoEntiretyRules(loggingKey);

        // Make all redeemables and transferables zero so that actual numbers will be put back in
        // second iteration of RedeemConsumables and RedeemGrants
        this.getCreditMap().values().forEach(cs -> {
            cs.setRedeemableCreditsToZero();
            cs.setRedeemableConsumablesToZero();
            cs.setEstimatedTransferableCreditsToZero();
        });

        redeemCredits(loggingKey);// 2nd Iteration
    }

    /**
     * Round up amounts as per braintree precision
     *
     * @return
     */
    public void updatePayableAmounts(String loggingKey) {
        final String methodKey = loggingKey + " updatePayableAmounts: ";

        for (ServiceStage pstage : this.getPayNowMap().values()) {
            // If fixed fee is updated. Update payable and total amounts with same.
            if (pstage.getTaxFeeAmount() != null) {
                if (pstage.getIgnoreTax_ForPayableAmount() != null
                        && pstage.getIgnoreTax_ForPayableAmount()) {
                    if (pstage.getTaxFeeAmount().compareTo(
                            pstage.getFinalPayableAmount().add(
                                    pstage.getRedeemableGiftAmount())) > 0) {
                        INFO(
                                m_logger, methodKey
                                        + "Fee amount will be ignored as IgnoreTax_ForPayableAmount=True ");
                    }
                } else {
                    if (pstage.getTaxFeeAmount().compareTo(
                            pstage.getFinalPayableAmount().add(
                                    pstage.getRedeemableGiftAmount())) > 0) {
                        pstage.setFinalPayableAmount(pstage.getTaxFeeAmount());
                        INFO(
                                m_logger,
                                methodKey
                                        + "Fee amount is greater than Final amount. Changing Final Payable Amount to: "
                                        + pstage.getFinalPayableAmount());
                    }
                    if (pstage.getTaxFeeAmount().compareTo(
                            pstage.getNonCreditAmount().add(
                                    pstage.getRedeemableGiftAmount())) > 0) {
                        pstage.setNonCreditAmount(pstage.getTaxFeeAmount());
                        INFO(
                                m_logger,
                                methodKey
                                        + "Fee amount is greater than Non Credit amount. Changing Non Credit Amount to: "
                                        + pstage.getNonCreditAmount());
                    }
                }
            }
        }

        // ROUND_FLOOR is a dirty workaround. Available amount should never be calculated as more
        // than it is.
        this.setAvailableMainBalanceAmount(
                this.getAvailableMainBalanceAmount().setScale(
                        BRAINTREE_CONSTANTS.BT_AMOUNT_PRECISION, RoundingMode.FLOOR));

        // ROUND_CEILING is a dirty workaround. Total estimated amount should never be calculated as
        // less than it is.
        this.setTotalEstimatedAmount(
                this.getTotalEstimatedAmount().setScale(
                        BRAINTREE_CONSTANTS.BT_AMOUNT_PRECISION, RoundingMode.CEILING));

        BigDecimal totalRedeemableCredits = BigDecimal.ZERO;

        BigDecimal remainingMainbalance = BigDecimal.ZERO;

        if (this.getAdviceFor() == AdviceDataStage.Advice.CHANGE) {
            remainingMainbalance = this.getAvailableMainBalanceAmount().subtract(
                    this.getChangeServiceDataStage().getReservedMainBalanceNextCycle()).max(
                            BigDecimal.ZERO);
        } else {
            remainingMainbalance = this.getAvailableMainBalanceAmount();
        }

        // Set order of mainbalance usage here
        List<String> serviceList = Arrays.asList(
                AppPropertyProvider.getInstance().getString(
                        BALANCE_CONSTANTS.MAINBALANCE_USAGE_PRIORITY_LIST));

        // Create prioritised PayNowList
        List<ServiceStage> orderedPaynowList = new ArrayList<ServiceStage>();

        // Add CIs listed in property balance.usage.priority.list.mainbalance
        List<ServiceStage> priorityList = new ArrayList<ServiceStage>();
        for (String ci : serviceList) {
            List<ServiceStage> ciPayNowList = this.getPayNowMap().values().stream().filter(
                    pstage -> pstage.getCatalogItemExternalId().equals(ci)).collect(
                            Collectors.toList());
            for (ServiceStage pstage : ciPayNowList) {
                // to avoide java.util.ConcurrentModificationException
                priorityList.add(pstage);
            }
        }
        if (!priorityList.isEmpty()) {
            for (ServiceStage pstage : priorityList) {
                orderedPaynowList.add(pstage);
                appendPayNowMap(
                        new CiResourceIdPair(
                                pstage.getCatalogItemExternalId(), pstage.getOfferResourceId()),
                        pstage);
            }
        }

        List<ServiceStage> noPriorityList = new ArrayList<ServiceStage>();
        // Add CIs NOT listed in property balance.usage.priority.list.mainbalance
        for (ServiceStage pstage : this.getPayNowMap().values()) {
            if (!serviceList.contains(pstage.getCatalogItemExternalId())) {
                // to avoid java.util.ConcurrentModificationException
                noPriorityList.add(pstage);
            }
        }
        
        if (!noPriorityList.isEmpty()) {
            for (ServiceStage pstage : noPriorityList) {
                   orderedPaynowList.add(pstage);
                appendPayNowMap(
                        new CiResourceIdPair(
                                pstage.getCatalogItemExternalId(), pstage.getOfferResourceId()),
                        pstage);
            }
        }

        BigDecimal skipRenewalAmount = BigDecimal.ZERO;
        for (ServiceStage paynow : orderedPaynowList) {
            if (paynow.isSkipRenewal()) {
                skipRenewalAmount = skipRenewalAmount.add(paynow.getDiscountPrice());
                continue;
            }
            BigDecimal redeemedConsumableCredits = adjustPayablesWithCreditCurrencyBalances(
                    loggingKey, paynow);
            BigDecimal redeemableCredits = adjustPayablesWithCreditBalanceTransfers(
                    loggingKey, paynow, redeemedConsumableCredits);
            totalRedeemableCredits = totalRedeemableCredits.add(redeemableCredits);
            paynow.setFinalPayableAmount(paynow.getNonCreditAmount());

            if (paynow.getFinalPayableAmount().signum() == 0) {
                paynow.setFinalPayableAmount(BigDecimal.ZERO);
                paynow.setConsumableMainBalance(BigDecimal.ZERO);
            } else if (remainingMainbalance.signum() == 0) {
                paynow.setFinalPayableAmount(paynow.getFinalPayableAmount());
                paynow.setConsumableMainBalance(BigDecimal.ZERO);
            } else if (remainingMainbalance.signum() == -1) {
                // The scenario is handled for negative balance
                paynow.setFinalPayableAmount(paynow.getFinalPayableAmount());
                paynow.setConsumableMainBalance(BigDecimal.ZERO);
            } else if (paynow.getFinalPayableAmount().compareTo(remainingMainbalance) >= 0) {
                paynow.setFinalPayableAmount(paynow.getFinalPayableAmount());
                paynow.setConsumableMainBalance(BigDecimal.ZERO.add(remainingMainbalance));
                remainingMainbalance = BigDecimal.ZERO;
            } else {
                paynow.setConsumableMainBalance(
                        BigDecimal.ZERO.add(paynow.getFinalPayableAmount()));
                remainingMainbalance = remainingMainbalance.subtract(
                        paynow.getFinalPayableAmount());
            }

            paynow.setNonCreditAmount(
                    paynow.getNonCreditAmount().setScale(
                            BRAINTREE_CONSTANTS.BT_AMOUNT_PRECISION, RoundingMode.CEILING));
            paynow.setFinalPayableAmount(
                    paynow.getFinalPayableAmount().setScale(
                            BRAINTREE_CONSTANTS.BT_AMOUNT_PRECISION, RoundingMode.CEILING));

            INFO(
                    m_logger, methodKey + "Paynow stage after mainbalance allocation: "
                            + paynow.toShortJson());
        }

        this.setConsumableMainBalanceAmount(
                this.getConsumableMainBalanceAmount().subtract(remainingMainbalance));
        this.setRechargeAmount(
                this.getPayNowMap().values().stream().map(
                        pStage -> pStage.getFinalPayableAmount()).reduce(
                                BigDecimal.ZERO, BigDecimal::add));
        if (totalRedeemableCredits.add(this.getAvailableMainBalanceAmount()).compareTo(
                this.getTotalEstimatedAmount()) <= 0) {
            this.setConsumableMainBalanceAmount(this.getAvailableMainBalanceAmount());

        } else {
            this.setConsumableMainBalanceAmount(
                    this.getTotalEstimatedAmount().subtract(totalRedeemableCredits));
            if (this.getConsumableMainBalanceAmount().compareTo(
                    this.getAvailableMainBalanceAmount()) > 0) {
                this.setConsumableMainBalanceAmount(this.getAvailableMainBalanceAmount());
            }
        }
    }

    /**
     * Reduce transferable amount from taxable mainbalance amount. Make sure to keep enough amount
     * in mainbalance/paynow so that minimum payable e911 requirements are met.
     *
     * @return - Total redeemableCredits that were accounted for adjustment
     */
    private BigDecimal adjustPayablesWithCreditBalanceTransfers(String loggingKey,
                                                                ServiceStage paynow,
                                                                BigDecimal totalRedeemableCredits) {
        final String methodName = "adjustPayablesWithCreditBalanceTransfers:";

        // Set will handle multiple credits with same redeem order
        Set<Long> redeemOrdersSet = this.getCreditMap().values().stream().map(
                cs -> cs.getCiPromoRedeemOrder()).collect(Collectors.toSet());
        List<Long> redeemOrdersList = (new ArrayList<Long>(new HashSet<Long>(redeemOrdersSet)));
        // Natural order sort ensures that credits with higher priority get consumed first
        redeemOrdersList.sort(Comparator.naturalOrder());
        // get credit to redeem order map.
        Map<PromoOfferPair, Long> CreditOrderMap = new HashMap<PromoOfferPair, Long>();
        for (CreditStage credit : this.getCreditMap().values()) {
            CreditOrderMap.put(
                    new PromoOfferPair(
                            credit.getApplicableCiExternalId(), credit.getGrantOfferCi()),
                    credit.getCiPromoRedeemOrder());
        }

        for (Long order : redeemOrdersList) {
            for (PromoOfferPair key : CreditOrderMap.keySet()) {
                if (CreditOrderMap.get(key).longValue() != order.longValue()) {
                    continue;
                }

                CreditStage credit = this.getCreditMap().get(key);

                if (!credit.getApplicableCiExternalId().equalsIgnoreCase(
                        paynow.getCatalogItemExternalId())) {
                    continue;
                }
                BigDecimal reducePaynowBy = credit.getEstimatedTransferableCredits();
                if (paynow.getNonCreditAmount().signum() <= 0) {
                    // If NonCredits is zero do not do anything
                } else if (paynow.getNonCreditAmount().compareTo(paynow.getMinimumCharge()) <= 0) {
                    // NonCredits is less than MinMainbalance. Give up, you can not get min
                    // amount as non-credit. Reduce transferables from credits.
                    credit.setEstimatedTransferableCredits(
                            credit.getEstimatedTransferableCredits().subtract(reducePaynowBy));
                    credit.setRedeemableCredits(
                            credit.getRedeemableCredits().subtract(reducePaynowBy));

                    // Since this step does not add to credit consumption. Do not adjust
                    // anything to offer level credits.
                    reducePaynowBy = BigDecimal.ZERO;
                } else if (reducePaynowBy.signum() == 0) {
                    // If taxable is zero do not do anything. Transferables is zero. Give up, no
                    // room for any adjustment.
                } else {
                    // (If credit grant type is AOC)
                    // (If grant is more than transferable)
                    // RedFlag. Do not reduce taxables. Remove credit usage completely.
                    // Otherwise Taxes will be updated for mainbalance / paynow .But actual
                    // purchase may get completed by credits. In next month the same money
                    // may again get taxed.
                    if (paynow.getNonCreditAmount().subtract(paynow.getMinimumCharge()).subtract(
                            reducePaynowBy).signum() >= 0) {
                        // If taxable is zero do not do anything
                        // Taxables is larger than MinMainbalance and
                        // Transferables+MinMainBalance
                        paynow.setNonCreditAmount(
                                paynow.getNonCreditAmount().subtract(reducePaynowBy));
                        paynow.setCreditsUsed(reducePaynowBy);
                        reducePaynowBy = BigDecimal.ZERO;
                    } else {
                        // Taxables is larger than MinMainbalance but less than
                        // Transferables+MinMainBalance
                        BigDecimal origTransferableCredits = credit.getEstimatedTransferableCredits();
                        reducePaynowBy = reducePaynowBy.subtract(
                                paynow.getNonCreditAmount().subtract(paynow.getMinimumCharge()));
                        if (paynow.getNonCreditAmount().compareTo(paynow.getMinimumCharge()) <= 0) {
                            paynow.setCreditsUsed(BigDecimal.ZERO);
                        } else {
                            paynow.setCreditsUsed(
                                    paynow.getNonCreditAmount().subtract(
                                            paynow.getMinimumCharge()));
                        }

                        if (origTransferableCredits.compareTo(
                                paynow.getNonCreditAmount().subtract(
                                        paynow.getMinimumCharge())) > 0) {
                            BigDecimal newTransferableCredits = paynow.getNonCreditAmount().subtract(
                                    paynow.getMinimumCharge());
                            paynow.setNonCreditAmount(paynow.getMinimumCharge());
                            // Transfer just enough to keep taxable to minmainbalance
                            credit.setEstimatedTransferableCredits(newTransferableCredits);
                            credit.setRedeemableCredits(
                                    newTransferableCredits.add(
                                            credit.getAvailableCreditsConsumable()));
                        } else {
                            credit.setEstimatedTransferableCredits(
                                    credit.getEstimatedTransferableCredits().subtract(
                                            paynow.getMinimumCharge()));
                            credit.setRedeemableCredits(
                                    credit.getRedeemableCredits().subtract(
                                            paynow.getMinimumCharge()));
                            paynow.setNonCreditAmount(paynow.getMinimumCharge());
                        }
                    }
                }

                totalRedeemableCredits = totalRedeemableCredits.add(
                        credit.getEstimatedTransferableCredits());
            }
        }
        INFO(
                m_logger, loggingKey + methodName + StringUtils.SPACE + "updated paynow: "
                        + paynow.toShortJson());
        return totalRedeemableCredits;
    }

    /**
     * Read currency balances and reduce amount from mainbalance related transfers. By default
     * everything would be accounted as charged-from-mainbalance. Credit consumption balances have
     * higher priority during actual purchase. If there is an amount in credit consumption balance,
     * that amount should be reduced from mainbalace/paynow as it can not be used in purchase.
     * 
     * @param paynow2
     * @return - Total redeemableCredits that were accounted for adjustment
     */
    private BigDecimal adjustPayablesWithCreditCurrencyBalances(String loggingKey,
                                                                ServiceStage paynow) {
        final String methodName = "adjustPayablesWithCreditCurrencyBalances:";
        BigDecimal totalRedeemableCredits = BigDecimal.ZERO;
        for (CreditStage credit : this.getCreditMap().values()) {
            // Consumables always get used. There is no way to avoid that as they higher priority
            // than mainbalance. Account for consumables in no perticular order
            // BigDecimal reducePaynowBy = credit.getAvailableCreditsConsumable();
            BigDecimal reducePaynowBy = credit.getRedeemableConsumables();
            if (!credit.getApplicableCiExternalId().equalsIgnoreCase(
                    paynow.getCatalogItemExternalId())) {
                continue;
            }

            INFO(
                    m_logger,
                    loggingKey + methodName + StringUtils.SPACE + "Processing promotion: "
                            + credit.getPromotionName() + StringUtils.SPACE + "and offer: "
                            + credit.getApplicableCiExternalId());

            if (paynow.getNonCreditAmount().signum() == 0 || reducePaynowBy.signum() == 0) {

            } else if (paynow.getNonCreditAmount().compareTo(reducePaynowBy) >= 0) {
                paynow.setNonCreditAmount(paynow.getNonCreditAmount().subtract(reducePaynowBy));
                paynow.setCreditsUsed(reducePaynowBy);
                reducePaynowBy = BigDecimal.ZERO;
            } else {
                reducePaynowBy = reducePaynowBy.subtract(paynow.getNonCreditAmount());
                paynow.setCreditsUsed(paynow.getNonCreditAmount());
                paynow.setNonCreditAmount(BigDecimal.ZERO);
            }

            totalRedeemableCredits = totalRedeemableCredits.add(
                    // Even if consumable is higher all of it can not be used.
                    credit.getAvailableCreditsConsumable().compareTo(
                            credit.getRedeemableCredits()) < 0
                                    ? credit.getAvailableCreditsConsumable()
                                    : credit.getRedeemableCredits());
        }
        INFO(
                m_logger, loggingKey + methodName + StringUtils.SPACE + "updated paynow: "
                        + paynow.toShortJson());
        return totalRedeemableCredits;
    }


}
