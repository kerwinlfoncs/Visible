package com.matrixx.vag.common.request.builder;

import com.matrixx.datacontainer.mdc.MtxRequestDeviceCreate;
import com.matrixx.datacontainer.mdc.VisibleDeviceExtension;
import com.matrixx.datacontainer.mdc.VisiblePurchasedOfferExtension;
import com.matrixx.vag.common.coverage.Generated;

@SuppressWarnings("unused")
@Generated
public class MtxRequestDeviceCreateBuilder {
	VisibleDeviceExtension existingAttr;
	boolean needExtn = false;
    public MtxRequestDeviceCreate build() {
    	VisibleDeviceExtension attr = null;
    	
    	if(this.existingAttr != null) {
    		attr = this.existingAttr;
    	}else if(needExtn) {
    		attr = new VisibleDeviceExtension();
    	}
    	MtxRequestDeviceCreate device = new MtxRequestDeviceCreate();
    	return device;
    }
}
