package com.matrixx.vag.common.request.builder;

import org.apache.commons.lang3.StringUtils;
import com.matrixx.datacontainer.mdc.VisibleBraintreeChargeMethodExtension;

public class VisibleBraintreeChargeMethodExtensionBuilder {
	String orderId;
	String transactionType;
	boolean recurringOverride;
	
	VisibleBraintreeChargeMethodExtension existingExtension;
	
	public VisibleBraintreeChargeMethodExtension build() {
		
    	boolean newAttr = true;
    	VisibleBraintreeChargeMethodExtension btExtension = new VisibleBraintreeChargeMethodExtension();

        if(existingExtension != null) {
            btExtension = existingExtension;
            newAttr = false;
        }
        
        if (StringUtils.isNotBlank(this.orderId) 
        		&& (newAttr || StringUtils.isBlank(btExtension.getOrderId()))) {
        	btExtension.setOrderId(this.orderId);
        }
        
        if (StringUtils.isNotBlank(this.transactionType) 
        		&& (newAttr || StringUtils.isBlank(btExtension.getTransactionType()))) {
        	 btExtension.setTransactionType(transactionType);
        }        

        if (newAttr || btExtension.getVisibleRecurringOverride()==null) {
        	 btExtension.setVisibleRecurringOverride(recurringOverride);
        }
        
        return btExtension;
	}
	
    public VisibleBraintreeChargeMethodExtensionBuilder withOrderId(String orderId) {
    	if(StringUtils.isNotBlank(orderId)) {
    		this.orderId = orderId;	
    	}    	
        return this;
    }
    
    public VisibleBraintreeChargeMethodExtensionBuilder withTransactionType(String transactionType) {
    	if(StringUtils.isNotBlank(transactionType)) {
    		this.transactionType = transactionType;	
    	}    	
        return this;
    }
    
    public VisibleBraintreeChargeMethodExtensionBuilder withRecurringOverride(boolean recurringOverride) {
    	this.recurringOverride = recurringOverride;	  	
        return this;
    }
}
