package com.matrixx.vag.advice.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;

import com.matrixx.datacontainer.mdc.PurchasedOfferInfo;
import com.matrixx.datacontainer.mdc.VisibleCatalogItem;
import com.matrixx.datacontainer.mdc.VisibleChangeServiceCredit;
import com.matrixx.datacontainer.mdc.VisibleNonRedeemableCredit;
import com.matrixx.datacontainer.mdc.VisibleReverseCredit;

public class ChangeServiceDataStage {

    public enum BillCycle {
        CURRENT, NEXT
    }

    public enum NextCycleDetails {
        NONE, REVERSE_PROMO_ONLY, NEXT_CYCLE_PAYMENT
    }

    private boolean asIsHasGlobalPass = false;
    private BillCycle billCycle = BillCycle.CURRENT;
    private NextCycleDetails nextCycleDetails = NextCycleDetails.NONE;
    private String changeType;
    private String newCatalogItemExternalId;
    private String deltaTaxInput = "";
    private String ignoreFuturePromoReason = "";
    private String promoNaDeltaReason = "";

    private BigDecimal reservedMainBalanceNextCycle = BigDecimal.ZERO;
    private BigDecimal delta = BigDecimal.ZERO;
    private BigDecimal gapNextCycle = BigDecimal.ZERO;
    private BigDecimal gapImpactPromos = BigDecimal.ZERO;
    private final List<String> eventPromoTaxes = new ArrayList<String>();
    private final Set<CiResourceIdPair> preactiveOffers = new HashSet<CiResourceIdPair>();
    private BigDecimal deltaImpactNewOfferPromos = BigDecimal.ZERO;
    private final Map<PromoOfferPair, VisibleReverseCredit> reverseCreditMap = new HashMap<PromoOfferPair, VisibleReverseCredit>();
    private final Map<PromoOfferPair, VisibleNonRedeemableCredit> nonRedeemableCreditMap = new HashMap<PromoOfferPair, VisibleNonRedeemableCredit>();
    private final List<VisibleChangeServiceCredit> changeServiceCredits = new ArrayList<VisibleChangeServiceCredit>();
    
    private VisibleCatalogItem asisCatalogItem;
    private PurchasedOfferInfo asIsPurchasedOfferInfo = new PurchasedOfferInfo();

    public String getChangeType() {
        return changeType;
    }

    public void setChangeType(String changeType) {
        this.changeType = changeType;
    }

    public BigDecimal getReservedMainBalanceNextCycle() {
        return reservedMainBalanceNextCycle;
    }

    public void setReservedMainBalanceNextCycle(BigDecimal reservedMainBalanceNextCycle) {
        this.reservedMainBalanceNextCycle = reservedMainBalanceNextCycle;
    }

    public Map<PromoOfferPair, VisibleReverseCredit> getReverseCreditMap() {
        return reverseCreditMap;
    }

    public VisibleReverseCredit getReverseCredit(String redeemOfferExternalId) {
        for (VisibleReverseCredit rc : reverseCreditMap.values()) {
            if (rc.getRedeemableOfferCI().equalsIgnoreCase(redeemOfferExternalId)) {
                return rc;
            }
        }
        return null;
    }

    public BigDecimal getDelta() {
        return delta;
    }

    public void setDelta(BigDecimal delta) {
        this.delta = delta;
    }

    public BigDecimal getGapNextCycle() {
        return gapNextCycle;
    }

    public void setGapNextCycle(BigDecimal gapNextCycle) {
        this.gapNextCycle = gapNextCycle;
    }

    public BigDecimal getGapImpactPromos() {
        return gapImpactPromos;
    }

    public void setGapImpactPromos(BigDecimal gapImpactPromos) {
        this.gapImpactPromos = gapImpactPromos;
    }

    public VisibleCatalogItem getAsisCatalogItem() {
        return asisCatalogItem;
    }

    public void setAsisCatalogItem(VisibleCatalogItem asisCatalogItem) {
        this.asisCatalogItem = asisCatalogItem;
    }

    public String getDeltaTaxInput() {
        return deltaTaxInput;
    }

    public void setDeltaTaxInput(String deltaTaxInput) {
        this.deltaTaxInput = deltaTaxInput;
    }

    public BillCycle getBillCycle() {
        return billCycle;
    }

    public void setBillCycle(BillCycle billCycle) {
        this.billCycle = billCycle;
    }

    public BigDecimal getDeltaImpactNewOfferPromos() {
        return deltaImpactNewOfferPromos;
    }

    public void setDeltaImpactNewOfferPromos(BigDecimal deltaImpactNewOfferPromos) {
        this.deltaImpactNewOfferPromos = deltaImpactNewOfferPromos;
    }

    public List<String> getEventPromoTaxes() {
        return eventPromoTaxes;
    }

    public void addToEventPromoTaxes(String taxString) {
        if (StringUtils.isNotBlank(taxString)) {
            eventPromoTaxes.add(taxString.trim());
        }
    }

    public String getNewCatalogItemExternalId() {
        return newCatalogItemExternalId;
    }

    public void setNewCatalogItemExternalId(String newCatalogItemExternalId) {
        this.newCatalogItemExternalId = newCatalogItemExternalId;
    }

    public Map<PromoOfferPair, VisibleNonRedeemableCredit> getNonRedeemableCreditMap() {
        return nonRedeemableCreditMap;
    }

    public VisibleNonRedeemableCredit getNonRedeemableCreditMap(String promotionName) {
        for (VisibleNonRedeemableCredit nrc : nonRedeemableCreditMap.values()) {
            if (nrc.getPromotionName().equalsIgnoreCase(promotionName)) {
                return nrc;
            }
        }
        return null;
    }

    public List<VisibleChangeServiceCredit> getChangeServiceCredits() {
        return changeServiceCredits;
    }

    public PurchasedOfferInfo getAsIsPurchasedOfferInfo() {
        return asIsPurchasedOfferInfo;
    }

    public void setAsIsPurchasedOfferInfo(PurchasedOfferInfo asIsPurchasedOfferInfo) {
        this.asIsPurchasedOfferInfo = asIsPurchasedOfferInfo;
    }

    public String getIgnoreFuturePromoReason() {
        return ignoreFuturePromoReason;
    }

    public void setIgnoreFuturePromoReason(String ignoreFuturePromoReason) {
        this.ignoreFuturePromoReason = ignoreFuturePromoReason;
    }

    public NextCycleDetails getNextCycleDetails() {
        return nextCycleDetails;
    }

    public void setNextCycleDetails(NextCycleDetails nextCycleDetails) {
        this.nextCycleDetails = nextCycleDetails;
    }

    public String getPromoNaDeltaReason() {
        return promoNaDeltaReason;
    }

    public void setPromoNaDeltaReason(String promoNaDeltaReason) {
        this.promoNaDeltaReason = promoNaDeltaReason;
    }

    public boolean getAsIsHasGlobalPass() {
        return asIsHasGlobalPass;
    }
    
    public void setAsIsHasGlobalPass(boolean asIsHasGlobalPass) {
        this.asIsHasGlobalPass = asIsHasGlobalPass;
    }

    public Set<CiResourceIdPair> getPreactiveOffers() {
        return preactiveOffers;
    }

}
