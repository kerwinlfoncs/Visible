package com.matrixx.vag.tax.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL) // Ignore unused fields to reduce payload size.
public class DpcGroup {

    private String dpcGroup;
    private String planID;
    private String classCode;
    private List<String> taxTypeExclusionList;
    private List<DpcItem> dpcItemList;

    public String getDpcGroup() {
        return dpcGroup;
    }

    public void setDpcGroup(String dpcGroup) {
        this.dpcGroup = dpcGroup;
    }

    public String getPlanID() {
        return planID;
    }

    public void setPlanID(String planID) {
        this.planID = planID;
    }

    public String getClassCode() {
        return classCode;
    }

    public void setClassCode(String classCode) {
        this.classCode = classCode;
    }

    public List<String> getTaxTypeExclusionList() {
        return taxTypeExclusionList;
    }

    public void setTaxTypeExclusionList(List<String> taxTypeExclusionList) {
        this.taxTypeExclusionList = taxTypeExclusionList;
    }

    public List<DpcItem> getDpcItemList() {
        return dpcItemList;
    }

    public void setDpcItemList(List<DpcItem> dpcItemList) {
        this.dpcItemList = dpcItemList;
    }

}
