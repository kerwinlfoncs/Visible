package com.matrixx.vag.subscriber.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.matrixx.datacontainer.MtxTimestamp;
import com.matrixx.datacontainer.mdc.*;
import com.matrixx.platform.MatrixxContext;
import com.matrixx.vag.advice.model.VisibleOfferDetailsInternal;
import com.matrixx.vag.advice.model.VisibleResponsePurchaseAdvice;
import com.matrixx.vag.advice.service.PaymentAdviceService;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.Constants.*;
import com.matrixx.vag.common.coverage.Generated;
import com.matrixx.vag.common.request.builder.*;
import com.matrixx.vag.config.AppPropertyParser;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.exception.*;
import com.matrixx.vag.service.IntegrationService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.beans.IntrospectionException;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import static com.matrixx.platform.LogUtils.*;
import static com.matrixx.vag.common.Constants.MATRIXX_CONSTANTS.CHRG_PURCHASE_FULL_AMOUNT;

@SuppressWarnings("unused")
@Configuration
public class SubscriberService extends IntegrationService {

    @Autowired
    private PaymentAdviceService paymentAdviceService;

    private RequestValidator requestValidator;

    private final ObjectMapper objectMapper = new ObjectMapper();
    private static final String FAILED_TO_PURCHASE_SERVICE = "Failed to purchase service";
    private static final Logger m_logger = LoggerFactory.getLogger(SubscriberService.class);
    private final String PURCHASE_TIMESTAMP = (new Date()).getTime() + "";
    private String ROUTE;

    @Generated
    @Bean(name = "SubscriberService")
    SubscriberService getService() {
        return new SubscriberService();
    }

    /**
     * Constructor.
     */
    public SubscriberService() {
        this.requestValidator = new RequestValidator();
    }

    /**
     * Add Service Recharge, cumulativeRechargeOfferPurchase ,purchase to multi request
     *
     * @param loggingKey
     * @param searchData
     * @param offerAttributes
     * @param multiReqPurchaseService
     * @param pi
     * @param advice
     * @param output
     * @return
     * @throws SubscriberServiceException
     * @throws IntrospectionException
     * @throws CommonUtilsException
     */
    @SuppressWarnings("unchecked")
    private void addServiceToMulti(String loggingKey,
                                   MtxSubscriberSearchData searchData,
                                   Map<String, String> offerAttributes,
                                   MtxRequestMulti multiReqPurchaseService,
                                   VisiblePurchaseInfo pi,
                                   VisibleResponsePurchaseAdvice advice,
                                   VisibleMultiResponsePurchaseService output)
            throws SubscriberServiceException, CommonUtilsException, IntrospectionException {
        final String methodKey = loggingKey + "addServiceToMulti: ";
        Boolean creditTaxUpdateViaSubscriberOffer = null;
        Long chargePurchaseProrationType = null;
        MtxTimestamp endTimeMulti = null;
        VisiblePurchaseServiceInfo psi = pi.getPurchaseServiceInfo();
        VisiblePurchaseServiceOrderInfo psoi = pi.getPurchaseServiceOrderInfo();
        VisiblePurchasedOfferExtension poExtn = pi.getAttrData();

        // Add MtxRequestSubscriberPurchaseOffer for service offer being purchased
        // Get good_type from offerAttributes
        // Info = timestamp
        if (StringUtils.isNotBlank(psi.getChargePurchaseProrationType())) {
            chargePurchaseProrationType = Long.valueOf(psi.getChargePurchaseProrationType());
        }
        if (StringUtils.isNotBlank(psi.getEndTime())) {
            endTimeMulti = new MtxTimestamp(psi.getEndTime());
        }

        BigDecimal serviceAmount = (new BigDecimal(
                pi.getPurchaseServiceInfo().getServiceDiscountPrice())).setScale(
                        BRAINTREE_CONSTANTS.BT_AMOUNT_PRECISION, RoundingMode.HALF_UP);
        INFO(
                m_logger,
                methodKey + "Charge for " + pi.getPurchaseServiceInfo().getServiceOfferExternalId()
                        + ":" + serviceAmount);

        //@formatter:off
        MtxPurchasedOfferData serviceOfferData = (new MtxPurchasedOfferDataBuilder())
                .withOfferExternalId(psi.getServiceOfferExternalId())
                .withOrderId(psoi.getOrderId())
                .withAmount(serviceAmount)
                .withTaxDetails(psi.getServiceTaxDetails())
                .withDeviceDetails(psi.getServiceDetails())
                .withGoodType(offerAttributes.get(ATTR_NAME_GOOD_TYPE))
                .withChargePurchaseProrationType(chargePurchaseProrationType)
                .withEndTime(endTimeMulti)
                .withInfo(PURCHASE_TIMESTAMP)
                .withOfferExtn(poExtn).build();
        //@formatter:on

        VisiblePurchasedOfferExtension visibleOfferExt = (VisiblePurchasedOfferExtension) serviceOfferData.getAttr();

        String offerType = "";
        for (VisibleOfferDetailsInternal od : advice.getVodList()) {
            if (od.getCatalogItemExternalId().equalsIgnoreCase(psi.getServiceOfferExternalId())) {
                if (StringUtils.isNotBlank(od.getOfferType())) {
                    offerType = od.getOfferType();
                }
                break;
            }
        }

        if (OFFER_CONSTANTS.OFFER_TYPE_BASE.equalsIgnoreCase(offerType)) {
            visibleOfferExt.setBrand(advice.getBrand());

            if (!CommonUtils.emptyIfNull(advice.getSubscriberGroups()).isEmpty()
                    && CommonUtils.zeroIfNull(
                            advice.getAtSubscriberGroups(0).getSubscriberMemberCount()) > 0) {
                DEBUG(
                        m_logger,
                        methodKey + "Setting group member count to purchase offer extension");
                visibleOfferExt.setGroupMemberCount(
                        advice.getAtSubscriberGroups(0).getSubscriberMemberCount());
                visibleOfferExt.setGroupTier(advice.getAtSubscriberGroups(0).getGroupTier());
                visibleOfferExt.setGroupName(advice.getAtSubscriberGroups(0).getGroupName());
            }
        }

        // If the current offer is eligible to use any credits then add
        // creditTaxdetails to this offer
        for (VisibleCredits vc : CommonUtils.emptyIfNull(advice.getCredits())) {
            if (vc.getApplicableCI().equalsIgnoreCase(psi.getServiceOfferExternalId())
                    && vc.getRedeemableCredits() != null && vc.getRedeemableCredits().signum() > 0
                    && StringUtils.isNotBlank(vc.getTaxDetails())
                    && CommonUtils.isServiceTaxResponseValid(vc.getTaxDetails())) {
                visibleOfferExt.getCreditTaxDetailsArrayAppender().add(vc.getTaxDetails());
            }
        }

        multiReqPurchaseService.appendRequestList(
                CommonUtils.getSubscriberPurchaseOfferRequest(searchData, serviceOfferData));

        if (StringUtils.isBlank(pi.getPurchaseServiceInfo().getNextPlanId())) {
            return;
        }

        MtxTimestamp newOfferStartDate = null;
        for (VisibleOfferDetailsInternal offer : CommonUtils.emptyIfNull(advice.getVodList())) {
            if (psi.getServiceOfferExternalId().equalsIgnoreCase(
                    offer.getCatalogItemExternalId())) {
                if (offer.getPurchaseOfferEndTime() != null) {
                    newOfferStartDate = offer.getPurchaseOfferEndTime();
                }
            }
        }

        if (newOfferStartDate == null) {
            output.setResultText(
                    "Warning: " + pi.getPurchaseServiceInfo().getNextPlanId()
                            + " was not purchased. There is no enddate for "
                            + pi.getPurchaseServiceInfo().getServiceOfferExternalId());
            return;
        }

        //@formatter:off
        MtxPurchasedOfferData fallbackOfferData = (new MtxPurchasedOfferDataBuilder())
                .withOfferExternalId(pi.getPurchaseServiceInfo().getNextPlanId())
                .withPreActiveState(true)
                .withOrderId(psoi.getOrderId())
                .withAmount(new BigDecimal(pi.getPurchaseServiceInfo().getNextPlanAmount()))
                .withGoodType(offerAttributes.get(ATTR_NAME_GOOD_TYPE))
                .withChargePurchaseProrationType(chargePurchaseProrationType)
                .withInfo(PURCHASE_TIMESTAMP)
                .withAutoActivationTime(newOfferStartDate).build();
        //@formatter:on
        multiReqPurchaseService.appendRequestList(
                CommonUtils.getSubscriberPurchaseOfferRequest(searchData, fallbackOfferData));
    }

    private MtxRequestMulti addSubscrptionModifyMultiPurchase(String loggingKey,
                                                              VisibleMultiRequestPurchaseService input,
                                                              MtxRequestMulti multiReq,
                                                              VisibleResponsePurchaseAdvice advice) {
        final String methodKey = loggingKey + "addSubscrptionModifyMultiPurchase: ";
        String cycleLength = "";
        for (VisibleOfferDetailsInternal vod : CommonUtils.emptyIfNull(advice.getVodList())) {
            if (!OFFER_CONSTANTS.OFFER_TYPE_BASE.equalsIgnoreCase(vod.getOfferType())) {
                continue;
            }
            LocalDate ldStart = LocalDate.parse(
                    vod.getCycleStartTime().substring(0, vod.getCycleStartTime().indexOf("T")));
            LocalDate ldEnd = LocalDate.parse(
                    vod.getCycleEndTime().substring(0, vod.getCycleStartTime().indexOf("T")));
            if (ldStart.plusYears(1).isBefore(ldEnd) || ldStart.plusYears(1).isEqual(ldEnd)) {
                cycleLength = CYCLE_LENGTHS.YEAR;
            } else if (ldStart.plusMonths(1).isBefore(ldEnd)) {
                cycleLength = CYCLE_LENGTHS.MULTI_MONTH;
            } else {
                cycleLength = CYCLE_LENGTHS.MONTH;
            }
        }

        if (StringUtils.isNotBlank(cycleLength)) {
            MtxRequestSubscriptionModifyBuilder smb = (new MtxRequestSubscriptionModifyBuilder()).withSubscriberExternalId(
                    input.getSubscriberExternalId()).withCycleLength(cycleLength);
            MtxRequestSubscriptionModify sm = smb.build();
            INFO(
                    m_logger,
                    methodKey + "Add " + MtxRequestSubscriptionModify.class.getSimpleName()
                            + " request to update cycle length attribute: " + sm.toJson());
            multiReq.appendRequestList(sm);
        }
        return multiReq;
    }

    public void purchaseService(VisibleRequestPurchaseService input,
                                VisibleResponsePurchaseService output)
            throws Exception {
        String loggingKey = getLoggingKey(input.getSubscriberExternalId());
        // Validate the request
        requestValidator.validateRequest(loggingKey, input);
        VisibleMultiRequestPurchaseService multiInput = new VisibleMultiRequestPurchaseService();
        multiInput.setApiEventData(input.getApiEventData());
        multiInput.setSubscriberExternalId(input.getSubscriberExternalId());
        VisiblePurchaseInfo vpi = new VisiblePurchaseInfo();
        vpi.setPurchaseServiceInfo(input.getPurchaseServiceInfo());
        vpi.setPurchaseServiceOrderInfo(input.getPurchaseServiceOrderInfo());
        vpi.setPurchaseFraudInfo(input.getPurchaseFraudInfo());
        multiInput.appendPurchaseInfo(vpi);
        VisibleMultiResponsePurchaseService multiOutput = new VisibleMultiResponsePurchaseService();
        purchaseMultiService(multiInput, multiOutput);
        output.setResult(multiOutput.getResult());
        output.setResultText(multiOutput.getResultText());
        if (multiOutput.getRiskData() != null && multiOutput.getRiskData().size() != 0) {
            output.setRiskData(multiOutput.getRiskData().get(0));
        }
    }

    /**
     * api to purchase multiple services for a subscriber
     *
     * @param input
     * @param output
     * @throws Exception
     */
    public void purchaseMultiService(VisibleMultiRequestPurchaseService input,
                                     VisibleMultiResponsePurchaseService output)
            throws Exception {
        // Setup the logging key
        String loggingKey = getLoggingKey(input.getSubscriberExternalId());

        // Determine routing data
        String ROUTE = getRoute(MatrixxContext.getRequest());
        final String methodKey = loggingKey + "purchaseMultiService: ";

        input.setSubscriberExternalId(input.getSubscriberExternalId().trim());
        input.getPurchaseInfo().forEach(pi -> {
            pi.getPurchaseServiceInfo().setServiceOfferExternalId(
                    pi.getPurchaseServiceInfo().getServiceOfferExternalId().trim());
        });

        // Validate the request
        requestValidator.validateRequest(loggingKey, input);

        // Get Subscriber data with mainbalance
        DEBUG(m_logger, methodKey + "Querying subscriber data in MATRIXX");
        MtxResponseSubscription subscriber = querySubscriptionData(
                loggingKey, input.getSubscriberExternalId());

        MtxRequestMulti multiReqPurchaseService = new MtxRequestMulti();

        // Get AOP estimates for all offers in the request considering all credits used
        DEBUG(m_logger, methodKey + "Calling Purchase Advice");

        VisibleResponsePurchaseAdvice advice = paymentAdviceService.getPurchaseAdvice(
                loggingKey, ROUTE, input, subscriber);
        INFO(m_logger, methodKey + "Received Estimate from Purchase Advice: " + advice.toJson());

        for (VisibleCredits credit : CommonUtils.emptyIfNull(advice.getCredits())) {
            if (StringUtils.isNotBlank(credit.getTaxDetails())
                    && !CommonUtils.isServiceTaxResponseValid(credit.getTaxDetails())) {
                String msg = "Invalid promotion tax json for " + credit.getPromotionName() + " : "
                        + credit.getTaxDetails();
                ERROR(m_logger, methodKey + msg);
                throw new SubscriberServiceException(RESULT_CODES.HTTP_INTERNAL_ERROR, msg);

            }
        }

        if (advice.getEstimatedPayableAmount().signum() > 0) {
            ERROR(
                    m_logger, methodKey + "Error based on EstimatedPayableAmount."
                            + StringUtils.SPACE + LOG_MESSAGES.NOT_ENOUGH_BALANCE_TO_PURCHASE);
            output.setResult(RESULT_CODES.HTTP_INTERNAL_ERROR);
            output.setResultText(
                    "SubscriberExternalID: " + input.getSubscriberExternalId() + " Error Message: "
                            + LOG_MESSAGES.NOT_ENOUGH_BALANCE_TO_PURCHASE);
            return;
        }

        MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
        searchData.setExternalId(input.getSubscriberExternalId());
        extractCreditDataAndAddBalanceTransferRequests(
                loggingKey, input, advice, multiReqPurchaseService, searchData);

        String purchaseTimestamp = (new Date()).getTime() + "";
        // Loop through all the catalog items in the input
        for (VisiblePurchaseInfo pi : input.getPurchaseInfo()) {
            Map<String, String> offerAttributes = getOfferAttributes(
                    loggingKey, ROUTE, pi.getPurchaseServiceInfo().getServiceOfferExternalId());
            addServiceToMulti(
                    loggingKey, searchData, offerAttributes, multiReqPurchaseService, pi, advice,
                    output);
        }

        multiReqPurchaseService = addSubscrptionModifyMultiPurchase(
                loggingKey, input, multiReqPurchaseService, advice);
        multiReqPurchaseService.setApiEventData(input.getApiEventData());

        // Call multi Send the multi-request to MATRIXX and receive the multi-response
        MtxResponseMulti multiRespMulti = runPurchaseMultiRequest(
                loggingKey, multiReqPurchaseService);

        // Prepare the API response
        output.setResult(multiRespMulti.getResult());
        if (StringUtils.isNotBlank(output.getResultText())) {
            output.setResultText(
                    "SubscriberExternalID: " + subscriber.getExternalId() + " Response: "
                            + multiRespMulti.getResultText() + "|" + output.getResultText());
        } else {
            output.setResultText(
                    "SubscriberExternalID: " + subscriber.getExternalId() + " Response: "
                            + multiRespMulti.getResultText());
        }

    }

    /**
     * Extract creditData from AOP response and add balance transfer purchase requests
     *
     * @param loggingKey
     * @param input
     * @param advice
     * @param multiReqPurchaseService
     * @param searchData
     * @return
     * @throws IntegrationServiceException
     * @throws IntrospectionException
     * @throws CommonUtilsException
     */
    private void extractCreditDataAndAddBalanceTransferRequests(String loggingKey,
                                                                VisibleMultiRequestPurchaseService input,
                                                                VisibleResponsePurchaseAdvice advice,
                                                                MtxRequestMulti multiReqPurchaseService,
                                                                MtxSubscriberSearchData searchData)
            throws IntegrationServiceException, CommonUtilsException, IntrospectionException {
        final String methodName = "extractCreditDataAndAddBalanceTransferRequests: ";
        ArrayList<VisibleCredits> visibleCreditsList;
        String purchaseTimestamp = (new Date()).getTime() + "";

        if (advice.getCredits() == null || advice.getCredits().isEmpty()) {
            return;
        }

        visibleCreditsList = advice.getCredits();

        for (VisibleCredits credit : visibleCreditsList) {

            DEBUG(
                    m_logger, loggingKey + methodName + StringUtils.SPACE + " Processing promo : "
                            + credit.getPromotionName());

            DEBUG(
                    m_logger,
                    loggingKey + methodName + StringUtils.SPACE + "RedeemCalculationMethod is "
                            + credit.getDiscountCalculationMethod());

            // BigDecimal estimatedTransAmt = null;

            // As discussed with Gopal in VER-6 discusssions AOC offers pricing will be changed
            // so that partial redeeming is allowed.

            boolean isCreditTaxValid = StringUtils.isBlank(credit.getTaxDetails())
                    || CommonUtils.isServiceTaxResponseValid(credit.getTaxDetails());

            if (credit.getEstimatedTransferableCredits() != null
                    && credit.getEstimatedTransferableCredits().signum() != 0
                    && credit.getEstimatedTransferableCredits() != null) {
                // If the EstimatedTransferableCredits is not equal to zero then only add
                // balance transfer purchase requests

                // If the balance transfer purchase fails then add
                // EstimatedTransferableCredits to charge amount in paynow

                // Add balance transfer requests if it has tax available.
                // Flag Balances check will be done in AOP ,so AOP response will be considering Flag
                // balances.
                if (isCreditTaxValid) {
                    DEBUG(
                            m_logger,
                            loggingKey + methodName + StringUtils.SPACE
                                    + "Estimated transferrable credits for the credit type "
                                    + credit.getPromotionName() + " : "
                                    + credit.getEstimatedTransferableCredits());
                    DEBUG(
                            m_logger,
                            loggingKey + methodName + StringUtils.SPACE
                                    + "Amount in balance transfer purchase request : "
                                    + (credit.getEstimatedTransferableCredits() == BigDecimal.ZERO
                                            ? null : credit.getEstimatedTransferableCredits()));

                    String orderIdsOfEligibleOffer = getOrderIdForEligibleOffer(
                            input, credit.getApplicableCI());
                    String goodType = null;

                    addRedeemPurchaseToMulti(
                            multiReqPurchaseService, searchData, purchaseTimestamp,
                            orderIdsOfEligibleOffer, credit, input);

                } else {
                    ERROR(
                            m_logger,
                            loggingKey + methodName + StringUtils.SPACE
                                    + "Invalid promotion tax json for "
                                    + credit.getPromotionName());
                    throw new SubscriberServiceException(
                            RESULT_CODES.HTTP_INTERNAL_ERROR,
                            "Invalid promotion tax json for " + credit.getPromotionName());
                }
            }
        }
    }

    /**
     * Add RedeemPurchaseRequest to multiRequest
     *
     * @param multiReqPurchaseService
     * @param searchData
     * @param purchaseTimestamp
     * @param redeemCreditofferName
     * @param creditReason
     * @param estimatedTransAmt
     * @param orderIdsOfEligibleOffer
     * @param goodType
     * @param credit
     * @param input
     * @throws IntrospectionException
     * @throws CommonUtilsException
     */
    private void addRedeemPurchaseToMulti(MtxRequestMulti multiReqPurchaseService,
                                          MtxSubscriberSearchData searchData,
                                          String purchaseTimestamp,
                                          String orderIdsOfEligibleOffer,
                                          VisibleCredits credit,
                                          VisibleMultiRequestPurchaseService input)
            throws CommonUtilsException, IntrospectionException {
        //@formatter:off
        MtxPurchasedOfferDataBuilder podb = (new MtxPurchasedOfferDataBuilder())
                .withOfferExternalId(credit.getCreditRedeemableOfferCI())
                .withOrderId(orderIdsOfEligibleOffer)
                .withGoodType(credit.getRedeemableGoodType())
                .withInfo(purchaseTimestamp)
                .withCreditReason(credit.getRedeemableGoodType());
        //@formatter:on
        VisiblePurchasedOfferExtension initVpoe = null;

        if (CREDIT_CONSTANTS.CALCULATION_METHOD_AOC.equals(credit.getDiscountCalculationMethod())) {
            for (VisiblePurchaseInfo vpi : input.getPurchaseInfo()) {
                if (vpi.getPurchaseServiceInfo().getServiceOfferExternalId().equals(
                        credit.getApplicableCI())) {
                    initVpoe = vpi.getAttrData();
                    break;
                }
            }

            if (initVpoe != null) {
                podb.withOfferExtn(initVpoe);
            }
        }

        if (credit.getEstimatedTransferableCredits().signum() > 0) {
            podb.withAmount(credit.getEstimatedTransferableCredits());
        }

        if (credit.getApplicableCreditsPercentage() != null
                && credit.getApplicableCreditsPercentage().signum() > 0) {
            podb.withCreditGrantType(CREDIT_CONSTANTS.GRANT_TYPE_PERCENTAGE);
        }

        multiReqPurchaseService.appendRequestList(
                getSubscriberPurchaseOfferRequest(searchData, podb.build()));
    }

    /**
     * Run purchase multi request.Validate and process if the credit balance transfer purchase
     * failed
     *
     * @param loggingKey
     * @param searchData
     * @param multiReqPurchaseService
     * @param advice
     * @return
     * @throws SubscriberServiceException
     * @throws MtxResponseException
     */
    private MtxResponseMulti runPurchaseMultiRequest(String loggingKey,
                                                     MtxRequestMulti multiReqPurchaseService)
            throws MtxResponseException {
        final String methodName = "runPurchaseMultiRequest: ";
        // Send the multi-request to MATRIXX and receive the multi-response
        MtxResponseMulti multiRespMulti = multiRequest(loggingKey, ROUTE, multiReqPurchaseService);
        CommonUtils.validateMtxResponse(loggingKey, FAILED_TO_PURCHASE_SERVICE, multiRespMulti);
        return multiRespMulti;
    }

    /**
     * Execute the multi-request passed in.
     *
     * @param input
     * @param output
     * @throws VisibleServiceException
     */
    public void executeMultiRequest(VisibleMultiRequest input, VisibleResponseMulti output)
            throws VisibleServiceException {
        String loggingKey = getLoggingKey("COMMON::MULTI_REQUEST");
        String ROUTE = getRoute(MatrixxContext.getRequest());
        String subscriberExternalID = null;

        // Validate the request
        requestValidator.validateRequest(loggingKey, input);
        MtxRequestMulti mult = new MtxRequestMulti();

        // Add the requests to MultiRequest.
        input.getRequestList().forEach(req -> {
            mult.appendRequestList(req);
        });
        mult.setApiEventData(input.getApiEventData());
        DEBUG(m_logger, loggingKey + "Final Multi Request sent: \n" + mult.toJson());
        MtxResponseMulti response = multiRequest(loggingKey, ROUTE, mult);

        for (MtxRequest singleRequest : input.getRequestList()) {
            if (singleRequest.getMdcName().equalsIgnoreCase("MtxRequestSubscriberPurchaseOffer")) {
                MtxRequestSubscriberPurchaseOffer spo = (MtxRequestSubscriberPurchaseOffer) singleRequest;
                if (StringUtils.isNotBlank(spo.getSubscriberSearchData().getExternalId())) {
                    subscriberExternalID = spo.getSubscriberSearchData().getExternalId();
                }
            } else if (singleRequest.getMdcName().equalsIgnoreCase("MtxRequestSubscriberModify")) {
                MtxRequestSubscriberModify sm = (MtxRequestSubscriberModify) singleRequest;
                if (StringUtils.isNotBlank(sm.getSubscriberSearchData().getExternalId())) {
                    subscriberExternalID = sm.getSubscriberSearchData().getExternalId();
                }
            } else if (singleRequest.getMdcName().equalsIgnoreCase(
                    "MtxRequestSubscriberRecharge")) {
                MtxRequestSubscriberRecharge sr = (MtxRequestSubscriberRecharge) singleRequest;
                if (StringUtils.isNotBlank(sr.getSubscriberSearchData().getExternalId())) {
                    subscriberExternalID = sr.getSubscriberSearchData().getExternalId();
                }
            }
        }

        if (subscriberExternalID != null) {
            output.setResult(response.getResult());
            output.setResultText(
                    "SubscriberExternalID: " + subscriberExternalID + " "
                            + response.getResultText());
        } else {
            output.setResult(response.getResult());
            output.setResultText(response.getResultText());
        }
        if (response.getResponseList() != null && !response.getResponseList().isEmpty()) {
            // Fix for CIM4557 MTXTAX-1847
            for (MtxResponse resp : response.getResponseList()) {
                output.appendResponseList(resp);
            }
        }
    }

    /**
     * Get order id of the purchase request of an credit eligible offer
     *
     * @param input
     * @param eligibleOfferList
     * @return
     */
    private String getOrderIdForEligibleOffer(VisibleMultiRequestPurchaseService input,
                                              String eligibleOffer) {
        String orderIdOfEligibleOffer = null;
        for (VisiblePurchaseInfo pi : input.getPurchaseInfo()) {
            if (pi.getPurchaseServiceInfo().getServiceOfferExternalId() != null
                    && pi.getPurchaseServiceInfo().getServiceOfferExternalId().equalsIgnoreCase(
                            eligibleOffer)
                    && pi.getPurchaseServiceOrderInfo().getOrderId() != null) {
                orderIdOfEligibleOffer = pi.getPurchaseServiceOrderInfo().getOrderId();
                break;
            }
        }
        return orderIdOfEligibleOffer;
    }
}
