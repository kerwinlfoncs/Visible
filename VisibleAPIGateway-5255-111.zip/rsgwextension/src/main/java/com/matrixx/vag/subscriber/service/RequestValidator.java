package com.matrixx.vag.subscriber.service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.matrixx.datacontainer.MtxObjectId;
import com.matrixx.datacontainer.MtxTimestamp;
import com.matrixx.datacontainer.mdc.*;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.Constants;
import com.matrixx.vag.common.Constants.CHANGE_SERVICE_CONSTANTS;
import com.matrixx.vag.common.Constants.EXCEPTION_MESSAGES;
import com.matrixx.vag.common.Constants.LOG_MESSAGES;
import com.matrixx.vag.common.Constants.RESULT_CODES;
import com.matrixx.vag.common.Constants.SUBSCRIBER_SERVICE_CONSTANTS;
import com.matrixx.vag.common.Constants.VISIBLE_EXTN_CONSTANTS;
import com.matrixx.vag.config.AppPropertyProvider;
import com.matrixx.vag.exception.InvalidRequestException;
import com.matrixx.vag.tax.model.ServiceTaxResponse;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.naming.ConfigurationException;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.DateTimeException;
import java.util.HashSet;
import java.util.Set;

import static com.matrixx.platform.LogUtils.DEBUG;

/**
 * @author unico
 */
public class RequestValidator {

    private static final Logger m_logger = LoggerFactory.getLogger(RequestValidator.class);

    /**
     * Validate the refund service request.
     *
     * @param request
     * @throws InvalidRequestException
     */
    public void validateRefundRequest(String loggingKey, VisibleRequestRefundService request)
            throws InvalidRequestException {

        DEBUG(m_logger, loggingKey + "Validating refund service request");

        String missingMandatoryParamName = null;
        if (StringUtils.isEmpty(request.getSubscriberExternalId())) {
            missingMandatoryParamName = "SubscriberExternalId";
        }
        if (CommonUtils.emptyIfNull(request.getRecurringEventIds()).size() <= 0) {
            missingMandatoryParamName = "RecurringEventIds";
        }
        if (CommonUtils.emptyIfNull(request.getPaymentAuthEventIds()).size() <= 0) {
            missingMandatoryParamName = "PaymentAuthEventIds";
        } else if (request.getRefundServiceOrderInfo() == null) {
            missingMandatoryParamName = "RefundServiceOrderInfo";
        } else if (StringUtils.isBlank(request.getRefundServiceOrderInfo().getReturnOrderId())) {
            missingMandatoryParamName = "RefundServiceOrderInfo.ReturnOrderId";
        } else if (StringUtils.isBlank(
                request.getRefundServiceOrderInfo().getServiceOfferExternalId())) {
            missingMandatoryParamName = "RefundServiceOrderInfo.ServiceOfferExternalId";
        }
        if (missingMandatoryParamName != null) {
            throw new InvalidRequestException(
                    RESULT_CODES.HTTP_BAD_REQUEST,
                    "Missing mandatory parameter: " + missingMandatoryParamName);
        }

        if (SUBSCRIBER_SERVICE_CONSTANTS.GIFT_SERVICE_REFUND.equalsIgnoreCase(
                request.getRefundType())) {
            if (CommonUtils.emptyIfNull(request.getRecurringEventIds()).size() > 1) {
                throw new InvalidRequestException(
                        RESULT_CODES.HTTP_BAD_REQUEST,
                        LOG_MESSAGES.GIFT_REFUND_SINGLE_RECUR_EVENT);
            }
            if (CommonUtils.emptyIfNull(request.getPaymentAuthEventIds()).size() > 1) {
                throw new InvalidRequestException(
                        RESULT_CODES.HTTP_BAD_REQUEST,
                        LOG_MESSAGES.GIFT_REFUND_SINGLE_PAYAUTH_EVENT);
            }
        }
    }
    
    /**
     * Validate the refund service request.
     *
     * @param request
     * @throws InvalidRequestException
     */
    public void validateRefundRequestV3(String loggingKey, VisibleRequestRefundService request)
            throws InvalidRequestException {

        DEBUG(m_logger, loggingKey + "Validating refund service request");

        String missingMandatoryParamName = null;
        if (StringUtils.isEmpty(request.getSubscriberExternalId())) {
            missingMandatoryParamName = "SubscriberExternalId";
        } else if (CommonUtils.emptyIfNull(request.getEventGroupList()).size() <= 0) {
            missingMandatoryParamName = "EventGroupList";
        } else if (request.getRefundServiceOrderInfo() == null) {
            missingMandatoryParamName = "RefundServiceOrderInfo";
        } else if (StringUtils.isBlank(request.getRefundServiceOrderInfo().getReturnOrderId())) {
            missingMandatoryParamName = "RefundServiceOrderInfo.ReturnOrderId";
        } else if (StringUtils.isBlank(
                request.getRefundServiceOrderInfo().getServiceOfferExternalId())) {
            missingMandatoryParamName = "RefundServiceOrderInfo.ServiceOfferExternalId";
        }
        if (missingMandatoryParamName != null) {
            throw new InvalidRequestException(
                    RESULT_CODES.HTTP_BAD_REQUEST,
                    "Missing mandatory parameter: " + missingMandatoryParamName);
        }

        if (CommonUtils.emptyIfNull(request.getEventGroupList()).size() > 1) {
            if (SUBSCRIBER_SERVICE_CONSTANTS.BILL_CYCLE_FLAT.equalsIgnoreCase(
                    request.getRefundType())) {
                throw new InvalidRequestException(
                        RESULT_CODES.HTTP_BAD_REQUEST, LOG_MESSAGES.BASE_REFUND_SINGLE_RECUR_EVENT);
            }
            if (SUBSCRIBER_SERVICE_CONSTANTS.BILL_CYCLE_PRORATE.equalsIgnoreCase(
                    request.getRefundType())) {
                throw new InvalidRequestException(
                        RESULT_CODES.HTTP_BAD_REQUEST,
                        LOG_MESSAGES.PRORATED_INSURANCE_REFUND_SINGLE_RECUR_EVENT);
            }
            if (SUBSCRIBER_SERVICE_CONSTANTS.GIFT_SERVICE_REFUND.equalsIgnoreCase(
                    request.getRefundType())) {
                throw new InvalidRequestException(
                        RESULT_CODES.HTTP_BAD_REQUEST, LOG_MESSAGES.GIFT_REFUND_SINGLE_RECUR_EVENT);
            }
        }

        for (RefundServiceEventGroup rseg : request.getEventGroupList()) {
            try {
                new MtxObjectId(rseg.getRecurringEventId());
            } catch (Exception e) {
                throw new InvalidRequestException(
                        RESULT_CODES.HTTP_BAD_REQUEST,
                        "Invalid recurring event Id: " + rseg.getRecurringEventId());
            }
            if (CommonUtils.emptyIfNull(rseg.getPaymentAuthorizationEventIds()).size() == 0) {
                throw new InvalidRequestException(
                        RESULT_CODES.HTTP_BAD_REQUEST,
                        "Payment Authorization Event Id should be present with Recurring Event Id.");
            }
            if (CommonUtils.emptyIfNull(rseg.getPaymentAuthorizationEventIds()).size() > 1) {
                if (SUBSCRIBER_SERVICE_CONSTANTS.GIFT_SERVICE_REFUND.equalsIgnoreCase(
                        request.getRefundType())) {
                    throw new InvalidRequestException(
                            RESULT_CODES.HTTP_BAD_REQUEST,
                            LOG_MESSAGES.GIFT_REFUND_SINGLE_PAYAUTH_EVENT);
                }
            }
            for (String paeid : rseg.getPaymentAuthorizationEventIds()) {
                try {
                    new MtxObjectId(paeid);
                } catch (Exception e) {
                    throw new InvalidRequestException(
                            RESULT_CODES.HTTP_BAD_REQUEST,
                            "Invalid payment authorization event event Id: " + paeid);
                }
            }
        }
    }

    /**
     * Validate the purchase service request.
     *
     * @param request
     * @throws InvalidRequestException
     */
    public void validateRequest(String loggingKey, VisibleRequestPurchaseService request)
            throws InvalidRequestException {
        DEBUG(m_logger, loggingKey + "Validating purchase service request");
        String missingMandatoryParamName = null;
        if (StringUtils.isBlank(request.getSubscriberExternalId())) {
            missingMandatoryParamName = "SubscriberExternalId";
        } else if (request.getPurchaseServiceOrderInfo()==null) {
            missingMandatoryParamName = "PurchaseServiceOrderInfo";
        } else if (StringUtils.isBlank(request.getPurchaseServiceOrderInfo().getOrderId())) {        
            missingMandatoryParamName = "PurchaseServiceOrderInfo.OrderId";
        } else if (StringUtils.isBlank(
                request.getPurchaseServiceInfo().getServiceOfferExternalId())) {
            missingMandatoryParamName = "PurchaseServiceInfo.ServiceOfferExternalId";
        } else if (StringUtils.isBlank(
                request.getPurchaseServiceInfo().getServiceDiscountPrice())) {
            missingMandatoryParamName = "PurchaseServiceInfo.ServiceDiscountPrice";
        } else if (StringUtils.isBlank(request.getPurchaseServiceInfo().getServiceSku())) {
            missingMandatoryParamName = "PurchaseServiceInfo.ServiceSku";

        } /*
           * else if (StringUtils.isEmpty(request.getPurchaseServiceInfo().getServiceTaxDetails()))
           * { missingMandatoryParamName = "PurchaseServiceInfo.ServiceTaxDetails"; }
           */ else {
            if (request.getPurchaseFraudInfo() != null) {

                if (request.getPurchaseFraudInfo().getFraudHomeAddress() == null) {
                    missingMandatoryParamName = "PurchaseFraudInfo.FraudHomeAddress";
                } else if (request.getPurchaseFraudInfo().getFraudShippingAddress() == null) {
                    missingMandatoryParamName = "PurchaseFraudInfo.FraudShippingAddress";
                } else if (request.getPurchaseFraudInfo().getTransactionType() == null) {
                    missingMandatoryParamName = "PurchaseFraudInfo.TransactionType";
                }
            }
            try {
                new BigDecimal(request.getPurchaseServiceInfo().getServiceDiscountPrice());
            } catch (NumberFormatException e) {
                throw new InvalidRequestException(                       
                        "Invalid value specified for parameter: PurchaseServiceInfo.ServiceDiscountPrice - "
                                + e.getMessage());
            }
        }

        if (missingMandatoryParamName != null) {
            throw new InvalidRequestException(
                    "Missing mandatory parameter: " + missingMandatoryParamName);
        }
    }

    public void validateRequest(String loggingKey, VisibleMultiRequestPurchaseService request)
            throws InvalidRequestException, ConfigurationException, JsonParseException,
            JsonMappingException, IOException {
        DEBUG(m_logger, loggingKey + "Validating purchase service request");
        String missingMandatoryParamName = null;
        if (StringUtils.isEmpty(request.getSubscriberExternalId())) {
            missingMandatoryParamName = "SubscriberExternalId";
        }
        final String basepath = "VisibleMultiRequestPurchaseService.VisiblePurchaseInfo";
        final String DOT = ".";
        String serviceTaxString;
        for (VisiblePurchaseInfo vpi : request.getPurchaseInfo()) {
            if (StringUtils.isEmpty(vpi.getPurchaseServiceOrderInfo().getOrderId())) {
                missingMandatoryParamName = basepath + DOT + "PurchaseServiceOrderInfo.OrderId";

            } else if (StringUtils.isEmpty(
                    vpi.getPurchaseServiceInfo().getServiceOfferExternalId())) {
                missingMandatoryParamName = basepath + DOT
                        + "PurchaseServiceInfo.ServiceOfferExternalId";
            } else if (StringUtils.isEmpty(
                    vpi.getPurchaseServiceInfo().getServiceDiscountPrice())) {
                missingMandatoryParamName = basepath + DOT
                        + "PurchaseServiceInfo.ServiceDiscountPrice";
            } else if (StringUtils.isEmpty(vpi.getPurchaseServiceInfo().getServiceSku())) {
                missingMandatoryParamName = basepath + DOT + "PurchaseServiceInfo.ServiceSku";
            } else {
                try {
                    new BigDecimal(vpi.getPurchaseServiceInfo().getServiceDiscountPrice());
                } catch (NumberFormatException e) {
                    throw new InvalidRequestException(
                            "Invalid value specified for parameter: PurchaseServiceInfo.ServiceDiscountPrice - "
                                    + e.getMessage());
                }

                if (StringUtils.isNotBlank(
                        vpi.getPurchaseServiceInfo().getChargePurchaseProrationType())) {
                    try {
                        new BigDecimal(
                                vpi.getPurchaseServiceInfo().getChargePurchaseProrationType());
                    } catch (NumberFormatException e) {
                        throw new InvalidRequestException(
                                "Invalid value specified for parameter: PurchaseServiceInfo.ChargePurchaseProrationType - "
                                        + e.getMessage());
                    }
                }

                if (StringUtils.isNotBlank(vpi.getPurchaseServiceInfo().getEndTime())) {
                    try {
                        new MtxTimestamp(vpi.getPurchaseServiceInfo().getEndTime());
                    } catch (DateTimeException e) {
                        throw new InvalidRequestException(
                                "Invalid value specified for parameter: PurchaseServiceInfo.EndTime - "
                                        + e.getMessage());
                    }
                }
                
                if(StringUtils.isNotBlank(vpi.getPurchaseServiceInfo().getNextPlanId())
                        && StringUtils.isBlank(vpi.getPurchaseServiceInfo().getNextPlanAmount())){
                    throw new InvalidRequestException(
                            "If NextPlanId is supplied, NextPlanAmount should also be supplied.");
                }

            }

            serviceTaxString = vpi.getPurchaseServiceInfo().getServiceTaxDetails();
            if (StringUtils.isNotBlank(serviceTaxString)) {
                ServiceTaxResponse serviceTaxResp = CommonUtils.getServiceTaxResponseFromJsonString(
                        serviceTaxString);
                if (StringUtils.isBlank(serviceTaxResp.getPlanID())) {
                    missingMandatoryParamName = basepath + DOT
                            + "PurchaseServiceInfo.ServiceTaxDetails.PlanID";
                    throw new InvalidRequestException(
                            "Wrong tax input as PlanID is missing: " + missingMandatoryParamName);
                }
                if (StringUtils.isBlank(serviceTaxResp.getClassCode())) {
                    missingMandatoryParamName = basepath + DOT
                            + "PurchaseServiceInfo.ServiceTaxDetails.ClassCode";
                    throw new InvalidRequestException(
                            "Wrong tax input as ClassCode is missing: "
                                    + missingMandatoryParamName);
                }
            }
        }

        if (!StringUtils.isEmpty(missingMandatoryParamName)) {
            throw new InvalidRequestException(
                    "Missing mandatory parameter: " + missingMandatoryParamName);
        }

    }

    /**
     * Validate the visible multi request.
     *
     * @param request
     * @throws InvalidRequestException
     */
    public void validateRequest(String loggingKey, VisibleMultiRequest request)
            throws InvalidRequestException {

        DEBUG(m_logger, loggingKey + "Validating visible multi request");

        int maxAllowedMultiRequests = AppPropertyProvider.getInstance().getInt(
                VISIBLE_EXTN_CONSTANTS.VISIBLE_MULTI_REQUESTS_NUMBER_MAX);
        if (request.getRequestList().size() > maxAllowedMultiRequests) {
            throw new InvalidRequestException(
                    "Unable to execute the multi-request, as it exceeds the max allowed number of requests: "
                            + maxAllowedMultiRequests);
        }

        // Instead of trying to check for a generic MtxRequest we should be checking for the
        // specific acceptable requests
        for (MtxRequest req : request.getRequestList()) {
            if (!(req instanceof MtxRequest)) {
                throw new InvalidRequestException(
                        "Unable to execute the multi-request, as there are invalid requests: "
                                + req);
            }
        }
    }

    /**
     * Validate the visible multi request.
     *
     * @param request
     * @throws InvalidRequestException
     */
    public void validateRequest(String loggingKey, VisibleRequestChangeService request)
            throws InvalidRequestException {

        DEBUG(
                m_logger,
                loggingKey + "Validating " + VisibleRequestChangeService.class.getSimpleName());

        Set<String> missingParameters = new HashSet<String>();
        if (StringUtils.isEmpty(request.getSubscriptionExternalId())) {
            throw new InvalidRequestException(
                    "Missing mandatory parameter: SubscriptionExternalId");
        }

        if (request.getChangeOfferInfo() == null) {
            throw new InvalidRequestException(
                    "Missing mandatory parameter: ChangeOfferInfo");
        }

        if (request.getChangeOfferInfo().getNewCatalogItem() == null) {
            throw new InvalidRequestException(
                    "Missing mandatory parameter: ChangeOfferInfo.NewCatalogItem");
        }

        if (StringUtils.isBlank(
                request.getChangeOfferInfo().getNewCatalogItem().getCatalogItemExternalId())) {
            throw new InvalidRequestException(
                    "Missing mandatory parameter: ChangeOfferInfo.NewCatalogItem.CatalogItemExternalId");
        }

        if (request.getChangeOfferInfo().getNewCatalogItem().getDiscountPrice() == null) {
            throw new InvalidRequestException(
                    "Missing mandatory parameter: ChangeOfferInfo.NewCatalogItem.DiscountPrice");
        }

        if (request.getChangeOfferInfo().getNewCatalogItem().getDiscountPrice().signum() < 0) {
            throw new InvalidRequestException(
                    "Invalid DiscountPrice : "
                            + request.getChangeOfferInfo().getNewCatalogItem().getDiscountPrice().toPlainString());
        }

        if (request.getChangeOfferInfo().getNewCatalogItem().getGrossPrice() != null
                && request.getChangeOfferInfo().getNewCatalogItem().getDiscountPrice().compareTo(
                        request.getChangeOfferInfo().getNewCatalogItem().getGrossPrice()) > 0) {
            if (missingParameters.size() > 0) {
                throw new InvalidRequestException(
                        "DiscountPrice should be less than Gross Price.");
            }
        }

        String disallowedTargetOffers = AppPropertyProvider.getInstance().getString(
                CHANGE_SERVICE_CONSTANTS.CI_DISALLOWED_AS_TARGET_LIST);

        if (disallowedTargetOffers.toUpperCase().contains(
                request.getChangeOfferInfo().getNewCatalogItem().getCatalogItemExternalId().toUpperCase())) {
            // Once new CreateConfig and Pricing are available change this condition.
            throw new InvalidRequestException(
                    EXCEPTION_MESSAGES.CAN_NOT_ENROLL_WITH_CHANGE_SERVICE);
        }

        if (request.getDeltaPromotionList() != null && !request.getDeltaPromotionList().isEmpty()) {
            for (VisibleDeltaPromo dp : request.getDeltaPromotionList()) {
                if (StringUtils.isBlank(dp.getClassCode())) {
                    throw new InvalidRequestException(
                            EXCEPTION_MESSAGES.DELTA_PROMO_NO_CLASS_CODE);
                }

                if (dp.getDeltaPromotionLimit() == null) {
                    throw new InvalidRequestException(
                            EXCEPTION_MESSAGES.DELTA_PROMO_NO_LIMIT);
                }
            }
        }
    }

    public void validateRequest(String loggingKey, VisibleRequestGiftService request)
            throws InvalidRequestException {

        DEBUG(m_logger, loggingKey + "Validating gift service request");
        String missingMandatoryParamName = null;
        if (StringUtils.isBlank(request.getGifterExternalId())) {
            missingMandatoryParamName = "GifterExternalId";
        } else if (StringUtils.isBlank(request.getGifteeExternalId())) {
            missingMandatoryParamName = "GifteeExternalId";
        } else if (StringUtils.isBlank(
                request.getGiftingServiceInfo().getCatalogItemExternalId())) {
            missingMandatoryParamName = "CatalogItemExternalId";
        } else if (request.getAttrData() == null) {
            missingMandatoryParamName = "AttrData";
        } else if (request.getAttrData() != null
                && StringUtils.isBlank(request.getAttrData().getOrderId())) {
            missingMandatoryParamName = "AttrData.OrderId";
        }

        if (missingMandatoryParamName != null) {
            throw new InvalidRequestException(
                    "Missing mandatory parameter: " + missingMandatoryParamName);
        }

    }

    public void validateRequest(String loggingKey, SubscriptionResponse gifteeSubsRes)
            throws InvalidRequestException {

        DEBUG(m_logger, loggingKey + "Validating Giftee Subscription response");
        String missingMandatoryParamName = null;

        if (gifteeSubsRes.getBillingCycle() == null) {
            missingMandatoryParamName = "bill cycle";
        } else if (gifteeSubsRes.getWalletBalances() == null) {
            missingMandatoryParamName = "Wallet Balances ";
        } else if (gifteeSubsRes.getWalletBalances() != null
                && gifteeSubsRes.getWalletBalances().isEmpty()) {
            missingMandatoryParamName = "Wallet Balances ";
        } else if (gifteeSubsRes.getWalletBalances() != null) {
            boolean isMainBal = false;
            for (BalanceInfo bi : gifteeSubsRes.getWalletBalances()) {
                if (bi.getIsMainBalance()) {
                    isMainBal = true;
                }
            }
            if (isMainBal == false) {
                missingMandatoryParamName = "Main Balance ";
            }
        }

        if (gifteeSubsRes.getPurchasedOfferArray() == null) {
            missingMandatoryParamName = "Set up Services";
        } else if (gifteeSubsRes.getPurchasedOfferArray() != null
                && gifteeSubsRes.getPurchasedOfferArray().isEmpty()) {
            missingMandatoryParamName = "Set up Services";
        } else if (gifteeSubsRes.getPurchasedOfferArray() != null) {
            boolean isSetServ = false;
            for (MtxPurchasedOfferInfo offerArray : gifteeSubsRes.getPurchasedOfferArray()) {
                if (offerArray.getProductOfferExternalId() != null
                        && offerArray.getProductOfferExternalId().equalsIgnoreCase(
                                Constants.CI_EXTERNAL_IDS.SETUP_SERVICES)) {
                    isSetServ = true;
                }
            }

            if (isSetServ == false) {
                missingMandatoryParamName = "Set up Services";
            }
        }

        if (gifteeSubsRes.getAttr() != null) {
            VisibleSubscriberExtension visibleSubsExt = (VisibleSubscriberExtension) gifteeSubsRes.getAttr();
            if (StringUtils.isEmpty(visibleSubsExt.getGeoCode())) {
                missingMandatoryParamName = "geocode";
            }
        }

        if (missingMandatoryParamName != null) {
            throw new InvalidRequestException(                    
                    "Giftee does not have " + missingMandatoryParamName);
        }

    }

}
