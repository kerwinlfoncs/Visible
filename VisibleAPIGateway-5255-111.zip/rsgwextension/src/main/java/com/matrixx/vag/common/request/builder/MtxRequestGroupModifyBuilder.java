package com.matrixx.vag.common.request.builder;

import java.util.ArrayList;
import java.util.HashSet;

import org.apache.commons.lang3.StringUtils;

import com.matrixx.datacontainer.MtxObjectId;
import com.matrixx.datacontainer.mdc.MtxGroupSearchData;
import com.matrixx.datacontainer.mdc.MtxRequestGroupModify;
import com.matrixx.datacontainer.mdc.VisibleCAGroupExtension;
import com.matrixx.vag.common.CommonUtils;
import com.matrixx.vag.common.coverage.Generated;

@Generated
public class MtxRequestGroupModifyBuilder {

    
    MtxObjectId groupOid;
    VisibleCAGroupExtension caAttr;
    HashSet<String> relationshipArray;
    @SuppressWarnings("unchecked")
    public MtxRequestGroupModify build() {
        MtxGroupSearchData searchData = new MtxGroupSearchData();        
        
        if (groupOid != null) {
            searchData.setObjectId(groupOid);
        }
        
        if (caAttr == null && relationshipArray!=null && !relationshipArray.isEmpty()) {
            caAttr = new VisibleCAGroupExtension();
        }
        for(String relationship:CommonUtils.emptyIfNull(relationshipArray)) {
            caAttr.getRelationshipArrayAppender().add(relationship);
        }

        MtxRequestGroupModify grpMod = new MtxRequestGroupModify();        
        grpMod.setGroupSearchData(searchData);        
        grpMod.setAttr(caAttr);
        return grpMod;
    }
    
    public MtxRequestGroupModifyBuilder withGroupOid(MtxObjectId groupOid) {
        if (groupOid!=null) {
            this.groupOid = groupOid;
        }
        return this;
    }
    
    public MtxRequestGroupModifyBuilder withAttr(VisibleCAGroupExtension caAttr) {
        if (caAttr!=null) {
            this.caAttr = caAttr;
        }
        return this;
    }
    
    public MtxRequestGroupModifyBuilder withRelationship(String relationship) {
        if (StringUtils.isNotBlank(relationship)) {
            if (relationshipArray==null) {
                this.relationshipArray = new HashSet<String>();
            }
            this.relationshipArray.add(relationship);
        }
        return this;
    }
}
