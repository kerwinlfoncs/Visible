package com.matrixx.vag.exception;

/**
 * Base class for exceptions.
 *
 * @author unico
 */
public abstract class VisibleServiceException extends Exception {

    private static final long serialVersionUID = 7671021757401507470L;
    private final Long resultCode;

    public VisibleServiceException(Long resultCode, String message) {
        super(message);
        this.resultCode = resultCode;
    }

    public VisibleServiceException(Long resultCode, String message, Throwable cause) {
        super(message, cause);
        this.resultCode = resultCode;
    }

    public Long getResultCode() {
        return resultCode;
    }

}
