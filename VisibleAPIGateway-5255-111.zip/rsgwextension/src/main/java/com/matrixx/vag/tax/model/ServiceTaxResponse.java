package com.matrixx.vag.tax.model;

import java.math.BigDecimal;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL) // Ignore unused fields to reduce payload size.
public class ServiceTaxResponse {

    private String msgID;
    private String customerType;
    private String planID;
    @JsonSerialize(using = TaxBigDecimalSerializer.class)
    private BigDecimal grossPrice;
    @JsonSerialize(using = TaxBigDecimalSerializer.class)
    private BigDecimal discountPrice;
    @JsonSerialize(using = TaxBigDecimalSerializer.class)
    private BigDecimal vendorPayable;
    @JsonSerialize(using = TaxBigDecimalSerializer.class)
    private BigDecimal vendorPayableNonProrated;
    private Boolean promotionCredit;
    @JsonSerialize(using = TaxBigDecimalSerializer.class)
    private BigDecimal offer606RevAdjDailyRecog;
    private String promotionReason;
    private String geocode;
    private String taxTreatment;
    private String classCode;
    private String glDate;
    private String promotionName;
    private String brand;
    private List<TransactionElement> transactionElement;

    public String getMsgID() {
        return msgID;
    }

    public void setMsgID(String msgID) {
        this.msgID = msgID;
    }

    public String getCustomerType() {
        return customerType;
    }

    public void setCustomerType(String customerType) {
        this.customerType = customerType;
    }

    public String getPlanID() {
        return planID;
    }

    public void setPlanID(String planID) {
        this.planID = planID;
    }

    public BigDecimal getGrossPrice() {
        return grossPrice;
    }

    public void setGrossPrice(BigDecimal grossPrice) {
        this.grossPrice = grossPrice;
    }

    public BigDecimal getDiscountPrice() {
        return discountPrice;
    }

    public void setDiscountPrice(BigDecimal discountPrice) {
        this.discountPrice = discountPrice;
    }

    public String getGeocode() {
        return geocode;
    }

    public void setGeocode(String geocode) {
        this.geocode = geocode;
    }

    public String getTaxTreatment() {
        return taxTreatment;
    }

    public void setTaxTreatment(String taxTreatment) {
        this.taxTreatment = taxTreatment;
    }

    public String getClassCode() {
        return classCode;
    }

    public void setClassCode(String classCode) {
        this.classCode = classCode;
    }

    public String getGlDate() {
        return glDate;
    }

    public void setGlDate(String glDate) {
        this.glDate = glDate;
    }

    public List<TransactionElement> getTransactionElement() {
        return transactionElement;
    }

    public void setTransactionElement(List<TransactionElement> transactionElement) {
        this.transactionElement = transactionElement;
    }

    public BigDecimal getVendorPayable() {
        return vendorPayable;
    }

    public void setVendorPayable(BigDecimal vendorPayable) {
        this.vendorPayable = vendorPayable;
    }

    public BigDecimal getVendorPayableNonProrated() {
        return vendorPayableNonProrated;
    }

    public void setVendorPayableNonProrated(BigDecimal vendorPayableNonProrated) {
        this.vendorPayableNonProrated = vendorPayableNonProrated;
    }

    public Boolean getPromotionCredit() {
        return promotionCredit;
    }

    public void setPromotionCredit(Boolean promotionCredit) {
        this.promotionCredit = promotionCredit;
    }

    public BigDecimal getOffer606RevAdjDailyRecog() {
        return offer606RevAdjDailyRecog;
    }

    public void setOffer606RevAdjDailyRecog(BigDecimal offer606RevAdjDailyRecog) {
        this.offer606RevAdjDailyRecog = offer606RevAdjDailyRecog;
    }

    public String getPromotionReason() {
        return promotionReason;
    }

    public void setPromotionReason(String promotionReason) {
        this.promotionReason = promotionReason;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getPromotionName() {
        return promotionName;
    }

    public void setPromotionName(String promotionName) {
        this.promotionName = promotionName;
    }

    public String toJson() {
        ObjectMapper mapper = new ObjectMapper();
        try {
            return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(this).replaceAll(
                    "[\\r\\n]", "");
        } catch (JsonProcessingException e) {
            return null;
        }
    }

    public String toJsonPretty() {
        ObjectMapper mapper = new ObjectMapper();
        try {
            return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(this);
        } catch (JsonProcessingException e) {
            return null;
        }
    }
}
