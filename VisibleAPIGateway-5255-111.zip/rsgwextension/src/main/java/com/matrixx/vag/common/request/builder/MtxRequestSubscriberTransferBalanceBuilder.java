package com.matrixx.vag.common.request.builder;

import com.matrixx.datacontainer.mdc.MtxRequestSubscriberTransferBalance;
import com.matrixx.datacontainer.mdc.MtxSubscriberSearchData;

import java.math.BigDecimal;

public class MtxRequestSubscriberTransferBalanceBuilder {


    MtxSubscriberSearchData subscriberSearchData;

    MtxSubscriberSearchData targetSubscriberSearchData;

    Long resourceId;

    Long targetBalanceResourceId;

    BigDecimal giftAmount;

    String reason;

    public MtxRequestSubscriberTransferBalance build() {
        if(subscriberSearchData==null) {
            this.subscriberSearchData = new MtxSubscriberSearchData();
        }

        if(targetSubscriberSearchData==null) {
            this.targetSubscriberSearchData = new MtxSubscriberSearchData();
        }

        MtxRequestSubscriberTransferBalance subTransferBalance = new MtxRequestSubscriberTransferBalance();

        subTransferBalance.setSubscriberSearchData(subscriberSearchData);
        subTransferBalance.setTargetSubscriberSearchData(targetSubscriberSearchData);
        subTransferBalance.setBalanceResourceId(resourceId);
        subTransferBalance.setTargetBalanceResourceId(targetBalanceResourceId);
        subTransferBalance.setAmount(giftAmount);
        subTransferBalance.setReason(reason);
        subTransferBalance.setAmountIsPct(false);
        return subTransferBalance;
    }

    public MtxRequestSubscriberTransferBalanceBuilder withSubscriberSearchData(
            MtxSubscriberSearchData subscriberSearchData) {
        if(subscriberSearchData != null) {
            this.subscriberSearchData = subscriberSearchData;
        }
        return this;
    }

    public MtxRequestSubscriberTransferBalanceBuilder withTargetSubscriberSearchData(
            MtxSubscriberSearchData targetSubscriberSearchData) {
        if(targetSubscriberSearchData != null) {
            this.targetSubscriberSearchData = targetSubscriberSearchData;
        }
        return this;
    }

    public MtxRequestSubscriberTransferBalanceBuilder withResourceId(Long resourceId) {
        if (resourceId != null) {
            this.resourceId = resourceId;
        }
        return this;
    }

    public MtxRequestSubscriberTransferBalanceBuilder withTargetResourceId(Long targetBalanceResourceId) {
        if (targetBalanceResourceId != null) {
            this.targetBalanceResourceId = targetBalanceResourceId;
        }
        return this;
    }

    public MtxRequestSubscriberTransferBalanceBuilder withGiftAmount(BigDecimal giftAmount) {
        if (giftAmount != null) {
            this.giftAmount = giftAmount;
        }
        return this;
    }

    public MtxRequestSubscriberTransferBalanceBuilder withReason(String reason) {
        if (reason != null) {
            this.reason = reason;
        }
        return this;
    }

}
