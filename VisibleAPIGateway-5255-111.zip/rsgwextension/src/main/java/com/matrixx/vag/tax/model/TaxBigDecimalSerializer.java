package com.matrixx.vag.tax.model;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.DecimalFormat;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.matrixx.vag.common.Constants.TAX_CONSTANTS;

public class TaxBigDecimalSerializer extends JsonSerializer<BigDecimal>{

	@Override
	public void serialize(BigDecimal value, JsonGenerator gen, SerializerProvider serializers) throws IOException {
        if (null == value) {
            gen.writeNull();
        } else {
            final DecimalFormat numFormat = new DecimalFormat( "#.########" );
            numFormat.setMinimumFractionDigits(0);
            numFormat.setMaximumFractionDigits(TAX_CONSTANTS.TAX_API_PRECISION);
            numFormat.setMinimumIntegerDigits(1);
            numFormat.setGroupingUsed(false);
            final String output = numFormat.format(value);
            gen.writeNumber(output);
        }		
	}

}
