package com.matrixx.vag.device.service;

/**
 * Device type.
 *
 * @author Unico
 */
public enum DeviceType {

    sp, // Service providing device
    nsp, // Non-service providing device

}
