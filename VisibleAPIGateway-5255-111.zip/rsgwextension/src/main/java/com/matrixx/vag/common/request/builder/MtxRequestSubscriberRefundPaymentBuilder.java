package com.matrixx.vag.common.request.builder;

import java.math.BigDecimal;

import org.apache.commons.lang3.StringUtils;

import com.matrixx.datacontainer.mdc.MtxRequestSubscriberRefundPayment;
import com.matrixx.datacontainer.mdc.MtxSubscriberSearchData;
import com.matrixx.vag.common.coverage.Generated;

@Generated
public class MtxRequestSubscriberRefundPaymentBuilder {

    String subscriberExternalId;
    Long paymentMethodResourceId;
    BigDecimal amount;
    String reason;
    String info;

    public MtxRequestSubscriberRefundPayment build() {
        MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
        if (StringUtils.isNotBlank(subscriberExternalId)) {
            searchData.setExternalId(subscriberExternalId);
        }
        
        MtxRequestSubscriberRefundPayment refund = new MtxRequestSubscriberRefundPayment();
        refund.setSubscriberSearchData(searchData);
        if (paymentMethodResourceId!=null) {
            refund.setResourceId(paymentMethodResourceId);
        }
        if (amount!=null) {
            refund.setAmount(amount);
        }        
        if (StringUtils.isNotBlank(reason)) {
            refund.setReason(reason);
        }
        if (StringUtils.isNotBlank(info)) {
            refund.setInfo(info);
        }

        return refund;
    }

    public MtxRequestSubscriberRefundPaymentBuilder withSubscriberExternalId(String subscriberExternalId) {
        if (StringUtils.isNotBlank(subscriberExternalId)) {
            this.subscriberExternalId = subscriberExternalId;
        }
        return this;
    }
    
    public MtxRequestSubscriberRefundPaymentBuilder withPaymentMethodResourceId(Long paymentMethodResourceId) {
        if (paymentMethodResourceId != null) {
            this.paymentMethodResourceId = paymentMethodResourceId;
        }
        return this;
    }
    
    public MtxRequestSubscriberRefundPaymentBuilder withAmount(BigDecimal amount) {
        if (amount != null) {
            this.amount = amount;
        }
        return this;
    }
    
    public MtxRequestSubscriberRefundPaymentBuilder withReason(String reason) {
        if (StringUtils.isNotBlank(reason)) {
            this.reason = reason;
        }
        return this;
    }
    
    public MtxRequestSubscriberRefundPaymentBuilder withInfo(String info) {
        if (StringUtils.isNotBlank(info)) {
            this.info = info;
        }
        return this;
    }
}
