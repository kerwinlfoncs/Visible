package com.matrixx.vag.exception;

/**
 * Exception thrown upon encountering an error with processing subscriber offers.
 *
 * @author unico
 */
public class IntegrationServiceException extends VisibleServiceException {

    private static final long serialVersionUID = -660254766051199869L;

    public IntegrationServiceException(Long resultCode, String message) {
        super(resultCode, message);
    }

    public IntegrationServiceException(Long resultCode, String message, Throwable cause) {
        super(resultCode, message, cause);
    }

}
