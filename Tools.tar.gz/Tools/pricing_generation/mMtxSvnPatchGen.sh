#!/usr/bin/env bash

#Setup needed variables:
BASE1=`dirname ${PWD}`
BASE2=`dirname $BASE1`
DOMAIN=`basename $BASE1`
MTXUID=`basename ${PWD}`
DATESTAMP=`date +'%y%m%d-%s'`
DATEYMD=`date +'%y%m%d'`
CLNAME=Script-$MTXUID
OLPREFIX=u$MTXUID.$DATESTAMP

if [[  $BASE2 != /var/cache/tomcat/temp/mtx_workspaces ]]; then
	echo "Run in a MyMatrix Domain user directory"
	exit 1
fi 

if [[ ! -d ~/patchMM ]] ; then
	echo "Requires a patchMM directory in the root users home directory to write output to"
	exit 1
fi 

echo "Generating svn diff for current directory $MTXUID"
REVISION=$(svn info . | grep Revision | awk '{print $2}')
FPREFIX=u$MTXUID.r$REVISION.$DATESTAMP
OUTDIR=u$MTXUID.r$REVISION.$DATEYMD
FOUTDIR=~/patchMM/$OUTDIR

if [[ ! -d $FOUTDIR ]] ; then
	mkdir $FOUTDIR
fi 

OUTLOG=$FOUTDIR/$OLPREFIX.logfile

echo "Patch Gen for domain $DOMAIN, user $MTXUID, Revision $REVISION at datestamp $DATESTAMP" |tee $OUTLOG
echo >> $OUTLOG
echo "Variables used:" >> $OUTLOG
echo "BASE1 = $BASE1" >> $OUTLOG
echo "BASE2 = $BASE2" >> $OUTLOG
echo "DOMAIN = $DOMAIN" >> $OUTLOG
echo "MTXUID = $MTXUID" >> $OUTLOG
echo "CLNAME = $CLNAME" >> $OUTLOG
echo "REVISION = $REVISION" >> $OUTLOG
echo >> $OUTLOG

# Get a list of all changed files, excluding ones not in svn and the local ErrorList
# Also remove extra lines not starting A, M, C or D as sometimes ErrorList can be conflicted
FILELST=$(svn status . |egrep -v '^\?|ErrorList.xml' | egrep '^M |^A |^C |^D' )

# Check that there are chnaged files, exit if not
if [[ -z "$FILELST" ]] ; then
	echo "No files changed, exiting" | tee -a $OUTLOG
	exit 1
fi

# Make sure there are no conflicted files:
if [[ "$(echo "$FILELST" | egrep '^C')" != "" ]] ; then
	echo "Conflicted file found, please resolve first" | tee -a $OUTLOG
	exit 1
fi

svn info . >> $OUTLOG
echo >> $OUTLOG

# Convert the list into a single string, newlines replaced by spaces
FILESTR=$(echo "$FILELST" | awk '{print $2}' | sed -e :a -e'$!N; s/\n/ /;ta')

echo "Changed File count: $(echo "$FILELST" | wc -l)" | tee -a $OUTLOG
echo "Modified: $(echo "$FILELST" | egrep '^M' | wc -l)" | tee -a $OUTLOG
echo "Added: $(echo "$FILELST" | egrep '^A' | wc -l)" | tee -a $OUTLOG
echo "Deleted: $(echo "$FILELST" | egrep '^D' | wc -l)" | tee -a $OUTLOG
# Check for deleted files. The user will have to be careful merging these
if [[ "$(echo "$FILELST" | egrep '^D')" ]] ; then
        echo "Deleted files found, please take care when merging the patch in " | tee -a $OUTLOG
fi

echo | tee -a $OUTLOG
echo "File List:"  >> $OUTLOG
echo "$FILELST" >> $OUTLOG
echo >> $OUTLOG
echo "File String:" >> $OUTLOG
echo "$FILESTR" >> $OUTLOG
echo >> $OUTLOG

# Use a changelist, as it is possible that the number of files chnanged exceeds the number possible to input directly into an svn diff
echo "Creating Changelist $CLNAME" | tee -a $OUTLOG
svn changelist $CLNAME $FILESTR >> $OUTLOG

echo | tee -a $OUTLOG
echo "Outputing Changelist into log only:" >> $OUTLOG
svn status --cl $CLNAME >> $OUTLOG

echo "$FILELST"  > $FOUTDIR/$FPREFIX.status
echo "Status File created as $FPREFIX.status" | tee -a $OUTLOG
svn diff --cl $CLNAME > $FOUTDIR/$FPREFIX.diff
echo "Svn diff file created as $FPREFIX.diff" | tee -a $OUTLOG
echo "Log file generated as $FPREFIX.logfile" | tee -a $OUTLOG

echo "Cleaning up Changelist $CLNAME:" >> $OUTLOG
svn changelist --cl $CLNAME --remove $FILESTR >> $OUTLOG

echo "Start CL cleanup check:" >> $OUTLOG
svn status --cl $CLNAME >> $OUTLOG 
echo "End CL cleanup check" >> $OUTLOG

cd ~/patchMM/
tar cfz $FPREFIX.tzp $OUTDIR
chmod 644 $FPREFIX.tzp
cp -p $FPREFIX.tzp /tmp/
echo "Tar Zip file generated as $FPREFIX.tzp and copied to /tmp" | tee -a $OUTLOG

