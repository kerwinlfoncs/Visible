#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-12-03T09:27:22
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-12-03T09:27:22
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-12-03T09:27:21

# Imports (keep to a minimum)
from __future__ import print_function
import os, sys, pprint, re, copy
import primitives as PRIM
import xmltodict

# Global data
beatData = {}
beatDataName = {}

rateTagData = {}
rateTagDataName = {}

denialData = {}

newLine = '\n'

# ------------------------------------------------------------------------------
def processRateTags(options, configDct):
        global rateTagData
        global rateTagDataName

        # Get full path to this file
        filePath = options.svnDir + '/RateTag/*.xml'

        # Process all the files
        cmd = 'ls ' + filePath + ' 2>/dev/null'
        listOfFiles = PRIM.runCmd(cmd).split("\n")
        #print listOfFiles
        for singleFile in listOfFiles:
                # Skip if blank
                if not singleFile: continue
                
                # Get object ID
                Id = singleFile.split('/')[-1].split('.')[0]
                
                # Get data
                with open(singleFile) as fd:
                        doc = xmltodict.parse(fd.read())
                        name = doc['rate_tag']['@name']
                
                # Store in global data
                rateTagData[Id] = name
                rateTagDataName[name] = Id
        '''
        print 'Rate Tags:'
        pprint.pprint(rateTagDataName)
        '''
        

# ------------------------------------------------------------------------------
def processDenialCodes(options, configDct):
        global denialData

        # Get full path to this file
        filePath = options.svnDir + '/admin/ErrorCodes/*.xml'

        # Process all the files
        cmd = 'ls ' + filePath + ' 2>/dev/null'
        listOfFiles = PRIM.runCmd(cmd).split("\n")
        #print listOfFiles
        for singleFile in listOfFiles:
                # Skip if blank
                if not singleFile: continue
                
                # Get object ID
                Id = singleFile.split('/')[-1].split('.')[0]
                
                # Get data
                with open(singleFile) as fd:
                        doc = xmltodict.parse(fd.read())
                        code = doc['error_code']['@detail_code']
                        text = doc['error_code']['@error_text']
                        
                # Store in global data
                denialData[code] = Id
                denialData[text] = Id
        
        '''
        print 'Denial Data:'
        pprint.pprint(denialData)
        '''
        
# ------------------------------------------------------------------------------
def processBeats(options, configDct):
        global beatData
        global beatDataName

        # Get full path to this file
        filePath = options.svnDir + '/admin/ServiceTypes/*.xml'

        # Process all the files
        cmd = 'ls ' + filePath
        listOfFiles = PRIM.runCmd(cmd).split("\n")
        #print listOfFiles
        for singleFile in listOfFiles:
                # Skip if blank
                if not singleFile: continue
                
                # Get object ID
                Id = singleFile.split('/')[-1]
                
                # Setup global data
                beatData[Id] = {}
                beatDataName[Id] = {}

                # Get data
                with open(singleFile) as fd:
                        doc = xmltodict.parse(fd.read())
                        
                        # If not present then skip
                        if 'BeatDefnArray' not in doc['service_type']['MtxServiceTypeObject']: continue
                        
                        # Process each beat.  May not be a lsit...
                        if type(doc['service_type']['MtxServiceTypeObject']['BeatDefnArray']['MtxPriceLoaderBeatDefn']) is not list:
                                doc['service_type']['MtxServiceTypeObject']['BeatDefnArray']['MtxPriceLoaderBeatDefn'] = [doc['service_type']['MtxServiceTypeObject']['BeatDefnArray']['MtxPriceLoaderBeatDefn']]
                        
                        for beat in doc['service_type']['MtxServiceTypeObject']['BeatDefnArray']['MtxPriceLoaderBeatDefn']:
                                beatName = beat['Name']
                                beatId   = beat['Id']
                                
                                # Store in global data
                                beatData[Id][beatId] = beatName
                                beatDataName[Id][beatName] = beatId
        '''
        print 'Beats:'
        pprint.pprint(beatData)
        '''

# ------------------------------------------------------------------------------
def main():
        print('Hello')

# ------------------------------------------------------------------------------
if __name__ ==  '__main__':
    main()

