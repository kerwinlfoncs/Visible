#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-12-03T09:27:23
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-12-03T09:27:23
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-12-03T09:27:22
# coding: latin-1

# Imports (keep to a minimum)
from __future__ import print_function
# from builtins import str
# from builtins import hex
# from builtins import str
# from builtins import hex
import os, sys, pprint
import re
import primitives as PRIM

# Globals 
normalizerData = {}
normalizerDataId = {}

# ------------------------------------------------------------------------------
# XLS cells with data separated by new lines saves as CSV with double quotes around the field but the new lines present.
# One needs to process this and recombine the data into comma-separated items.  
# This function assume there are three items per row (value, result, description) and thus 
def massageInput(configDct, inputDir):
        # Get input file
        inputFile = configDct['inputFile']
        
        # Sanity check this file exists
        if inputDir[-1] != '/': inputDir += '/'
        inputPath = inputDir + inputFile
        if not os.path.exists(inputPath): sys.exit('ERROR: input file ' + inputDir + inputFile + ' does not exist')
        
        # Get the file creation time
        fileCreation = os.path.getctime(inputPath)
        
        # See if processed file exists, so we don't re-process a file
        processedFile = inputPath + '.processed'
        try:
                processedCreation = os.path.getctime(processedFile)
        except: processedCreation = fileCreation
        
        # If we already processed this file, then nothing to do
        if processedCreation > fileCreation:
                print('Reusing previously processed file "' + processedFile + '"')
                return processedFile
        
        # Open file for writing
        fd = open(processedFile, "w")
        
        # If here, then need to process input file
        # Read file
        fileData = open(inputPath).read().strip().split('\n')
        
        print("Read file ' " + inputPath + "'")
        #pprint.pprint(fileData)
        
        # Start with empty data
        data = []
                
        # Process each line.
        currentIndex = 0
        inQuote = False
        for entry in fileData:
                # Skip blank line
                entry = entry.strip()
                if not entry: continue
                
                # Split on a tab
                entry = entry.split('\t')
                #print 'entry: ' + str(entry)
                
                # Process each entry
                for item in entry:
                        #print 'item: ' + str(item)
                        # Check if no quotes
                        if not item.count('"'):
                                # If not in a quote then field is ending
                                if not inQuote:
                                        # Populate field
                                        data.append((item))
                                        
                                        # Bump index
                                        currentIndex += 1
                                else:
                                        # Remain in quote.  Add item to field
                                        data[currentIndex] += ',' + item
                        else:
                                # We found a quote.
                                # If in a quote then end the field, else start the field.
                                if inQuote:
                                        data[currentIndex] += ',' + item[:-1]
                                        inQuote = False
                                
                                        # Bump index, as we want to go to the next field
                                        currentIndex += 1
                                else:
                                        data.append((item[1:]))
                                        inQuote = True
                                
                # If back to the start then write record
                if not inQuote:
                        # Join the array so it's a tab separate list
                        outStr = '\t'.join(data) + '\n'
                        
                        # Write to the processed file
                        fd.write(outStr)
                        
                        # Reset index
                        currentIndex = 0
                        
                        # Restart with empty data
                        del data
                        data = []
                
        # Close processed file
        fd.close()
        
        # Return file to continue with
        return processedFile
        
# ------------------------------------------------------------------------------
# Combine consecutive numbers in a phone match normalizer.
# The algorithm only tries to combine consecutive numbers.  It doesn't perform
# any logic on pattersn in the middle of numbers.
def processPhoneMatchNormalizer(records):
        # Setup locals
        currentRangeValue = None
        currentRangeStart = None
        currentRangeEnd = None
        currentDescription = None
        newRecords = []
        
        # Sort the records based on result (makes subsequent logic easier).
        # If patterns used then sort would fail.
        try: records = sorted(records, key=lambda x: int(x[1]))
        except: pass
        
        # Process each record
        for i,record in enumerate(records, start=1):
                # Progress report
                if not (i%1000): print('Processing record ' + str(i))
                
                # Split into components:
                (value, results, descriptions) = record
                
                # See if this is a new value
                if currentRangeValue and (value != currentRangeValue):
                        #print 'New value - writing existing record'
                        writePattern(newRecords, currentRangeValue, currentDescription, currentRangeStart, currentRangeEnd)
                        currentRangeStart = None
                        currentRangeEnd = None
                        currentRangeValue = value
                        currentDescription = None
                
                # Split input into lists
                results = results.split(',')
                description = descriptions.split(',')[0].strip()
                #print 'processPhoneMatchNormalizer: processing record: value = ' + str(value) + ', description = ' + str(description) + ', results = ' + str(results)
                
                # Process results
                for result in results:
                        # If not a number then asume it's already a pattern
                        if not result.isdigit():
                                # Write in-progress record if defined
                                if currentRangeStart:
                                        #print 'Non-digit value - writing existing record'
                                        writePattern(newRecords, currentRangeValue, currentDescription, currentRangeStart, currentRangeEnd)
                                
                                # Write this record
                                #print 'Non-digit value - writing new record'
                                writePattern(newRecords, value, description, result, None)
                                
                                # Reset per-record values
                                currentRangeStart = None
                                currentRangeValue = None
                                currentRangeEnd = None
                                currentDescription = None
                                
                                # Go to next record
                                continue
                                
                        # Check for new range
                        if not currentRangeStart:
                                # Set locals
                                currentRangeStart = result
                                currentRangeEnd = result
                                currentDescription = description
                                currentRangeValue = value
                                
                        # See if sequential
                        elif int(result) == int(currentRangeEnd) + 1: currentRangeEnd = result
                        else:
                                #print 'New range:  currentRangeEnd = ' + str(currentRangeEnd) + ', result = ' + str(result)
                                # New range.  Write current entry
                                writePattern(newRecords, currentRangeValue, currentDescription, currentRangeStart, currentRangeEnd)
                                
                                # Set locals
                                currentRangeStart = result
                                currentRangeEnd = result
                                currentDescription = description
        
        # Write last entry:
        if currentRangeStart:
                #print 'End of processing - writing existing record'
                writePattern(newRecords, currentRangeValue, currentDescription, currentRangeStart, currentRangeEnd)
        
        print('Finished processPhoneMatchNormalizer')
        
        # Return modified records
        print('New number of records: ' + str(len(newRecords)))
        return newRecords
        
# ------------------------------------------------------------------------------
def writePattern(newRecords, value, description, rangeStart, rangeEnd):
        # See if we have a range
        if rangeEnd and rangeEnd != rangeStart:
                _range = '[' + rangeStart + '-' + rangeEnd + ']'
        else:   _range = rangeStart
        
        # Put wild card at the end iff not already there
        if rangeStart[-1] != '*': _range += '*'
        
        # Write the record
        newRecords.append((value, _range, description))
                                
        return
        
# ------------------------------------------------------------------------------
def getRecords(processedFile, configDct):
        xlateTable = {}
        
        # process translation table
        try:
                # Read the file (never very big so get into variable all at once
                fileData = open('xlateData').read().strip().split('\n')
                #print fileData
                
                # Process each record
                for record in fileData:
                        #print record
                        
                        # Skip blank lines and comment lines
                        if not record or record[0] == '#': continue
                        
                        # Split record into parts and assign to dictionary
                        record = record.split(',')
                        
                        # Make sure there's a leading 0x
                        if record[0].startswith('x'): record[0] = '0' + record[0]
                        if not record[0].startswith('0x'): record[0] = '0x' + record[0]
                        
                        # Update translation table
                        xlateTable[str(record[0])] = record[1]
        except: pass
        #pprint.pprint(xlateTable)
        
        newRecords = []
        result = True
        
        # Get file data into an array
        records = open(processedFile).read().strip().split('\n')
        
        # Get the config data values
        columns = configDct['columns'].split(',')
        
        # Map columns so they're the 0-based index into the record
        for i,column in enumerate(columns):
                # If not a digit, then translate assuing 0 is 'A'
                if not column.isdigit(): columns[i] = ord(column.upper()) - ord('A')
                else:                    columns[i] = int(column)
        
        # Process each record
        for i,record in enumerate(records):
                # Check for non-ASCII
                try: xlateRecord = record.encode('ascii')
                except UnicodeEncodeError:
                        #print 'Record ' + str(i) + ' has non-ASCII characters: ' + record
                        xlateRecord = ""
                        for char in record.decode("utf-8"):
                                if ord(char) >= 128:
                                        #print 'Looking to decode ' + repr(char)
                                        if hex(ord(char)) in xlateTable: xlateRecord += xlateTable[hex(ord(char))]
                                        else:   xlateRecord += char
                                else:   xlateRecord += char
                        #print 'Decoded string: ' + repr(xlateRecord.decode("utf-8"))
                
                        # Check for non-ASCII after translations
                        try: record = xlateRecord.encode('ascii')
                        except UnicodeEncodeError:
                                print('Record ' + str(i) + ' has non-ASCII characters after translations: ' + repr(xlateRecord))
                                result = False
                        else: print('Translated record ' + str(i) + ': ' + record)
                
                # No reason to continue processing if we're going to return false
                if not result: continue
                
                # Split into fields
                record = record.split(',')
                #record = record.split('\t')
                #pprint.pprint(record)
                
                # Start command to run
                cmd = 'newRecords.append(('
                
                # Define string for array adding
                for column in columns: cmd += 'record[' + str(column) + '],'
                
                # Build remainder of command and execute
                cmd = cmd[:-1] + '))'
                #print cmd
                exec(cmd)
        
        return newRecords,result
        
# ------------------------------------------------------------------------------
def copyNorm(filePath, itemId):
        global normalizerData
        global normalizerDataId
        
        # Setup global data
        normalizerData[itemId] = {}
        normalizerDataId[itemId] = {}
        
        # Read in current normalizer
        cmd = 'grep "value id" ' + filePath + ' | cut -f2,4,8 -d"\'" | tr "\'" "\t"'
        values = PRIM.runCmd(cmd).split("\n")
        
        # Process each value
        for value in values:
                # Split into fields
                (valueId,valueIndex,name) = value.split("\t")
                
                # Store into array
                normalizerData[itemId][name]            = ((int(valueId), int(valueIndex)))
                normalizerDataId[itemId][int(valueId)]  = ((name, int(valueIndex)))
                
# ------------------------------------------------------------------------------
def processNormalizer(options, configDct, key):
        global normalizerData
        global normalizerDataId
        
        dirString = 'normalizers'
        
        # Get item ID.  Names are non-numeric, so ID is first numeric.
        itemId = key[re.search("\d", key).start():]
        
        # Get full path to this file
        filePath = options.svnDir + '/' + dirString + '/' + itemId + '.xml'
        
        # Sanity check this file exists
        if not os.path.exists(filePath): sys.exit('ERROR: ' + dirString + ' file ' + filePath + ' does not exist')
        
        # Get existing normalizer data
        copyNorm(filePath, itemId)
        
        # Exit if a copy
        if key.lower().startswith('copy'):
                print('Copied ' + str(len(normalizerData[itemId])) + ' values from normalizer ' + str(itemId))
                #pprint.pprint(normalizerData[itemId])
                return
        
        # Get config data for this item
        configData = configDct[key]
        
        # Sanity check the input data
        if 'columns' not in configData:
                print('WARNING: Should specify normalizer columns (value, result, description).  Will assume the first three columns in the file (A, B, C).')
                configData['columns'] = '0,1,2'
        
        # Massage input data to address how XLS data copies to a Unix file when there are new lines in the XLS data
        processedFile = massageInput(configData, options.inputDir)
                
        # Now get the columns from the config for this normalizer
        (records,result) = getRecords(processedFile, configData)
        if not result: sys.exit("Stopping processing until record data is fixed")
        
        print('Processing ' + str(len(records)) + ' records from the processed file')
        #pprint.pprint(records)
        
        # If a phone match then need to due further processing of results
        cmd = 'grep "algorithm=\'phonePattern\'" ' + filePath + ' | wc -l'
        count = PRIM.runCmd(cmd)
        if int(count):
                records = processPhoneMatchNormalizer(records)
                print('Processing ' + str(len(records)) + ' records post phone pattern shrinking')
                #pprint.pprint(records)
        
        # TEST: get list of integers
        intList = ((M[1] for L in normalizerData[itemId] for M in normalizerData[itemId][L]))
        
        # Current index to start with is the number of lines to save
        if configData['index'] == 'all':
                # Get highest index and ID (not necessarily the same, with GUI deletions)
                currentIndex = max((normalizerData[itemId][L][1] for L in normalizerData[itemId]))
                currentValueId = max((normalizerData[itemId][L][0] for L in normalizerData[itemId]))
        else:
                # Configured value is number if indices to save.  Since indices start at 0, we want to subtract 1 to get the current index.
                # This assumes these are sequential at the start of the file...
                currentIndex = int(configData['index']) - 1
                currentValueId = int(configData['index']) - 1
        
        # Debug output
        '''
        print 'currentIndex = ' + str(currentIndex)
        print 'currentValueId = ' + str(currentValueId)
        '''
        
        # Need the starting value 
        startIndex = currentIndex
        startValueId = currentValueId
        
        # The number of lines to get from this file is 3 + the index (account for file header lines and the fact that indices start at 0)
        linesToSave = 3 + currentIndex
        
        # Get those lines
        cmd = "head -" + str(linesToSave) + ' ' + filePath
        linesStart = PRIM.runCmd(cmd)
        linesStart += '\n'
        
        # Lines between values and results:
        middleLines = "    </values>\n   <results>\n"
        
        # If doing a delta then keep all current results
        if 'results' in configData and configData['results'].lower() == 'delta':
                cmd = 'grep "result index" ' + filePath
                middleLines += PRIM.runCmd(cmd) + '\n'
        elif 'results' not in configData: configData['results'] = 'replace'
        
        # End of the object
        endLines = "    </results>\n</normalizer>"
        
        # Set exact string
        if configData['exact'].lower() == 'none':
                exactString = ' '
        else:   exactString = " exact='" + configData['exact'].lower() + "' "
        
        # Setup defaults
        currentValue = None
        usedValues = []
        
        # Now process normalizer entries.  
        # Sort as we want all common value items together (and this facilitates dup detection).
        records = sorted(records, key=lambda x: x[0])
        for i,record in enumerate(records):
                # Sanity check if we already processed this.  Skip first record (not sure what [:0] does...
                if i and record in records[:i]:
                        print('Warning: found a duplicate record: "' + str(record) + '".  Skipping it.')
                        '''
                        pprint.pprint(records[:i])
                        kef
                        '''
                        continue
                
                '''
                print "Processing record " + str(i)
                pprint.pprint(record)
                '''
                
                # Split into components:
                (values, results, descriptions) = record
                
                # Split each into lists
                values = values.split(',')
                results = results.split(',')
                descriptions = descriptions.split(',')
                descIndex = 0
                
                # Sanity check.  Should never have multiple values, as everything maps to a single entitiy
                if len(values) > 1:
                        # Not good...
                        print('ERROR: found multiple values: ' + str(values) + '.  Part of record"' + str(record) + '"')
                        sys.exit('ERROR: Exiting')
                
                # Set to single value
                value = values[0]
                
                # See if a new value referenced and (new to normalizer data or above the starting index)
                if value != currentValue and (value not in normalizerData[itemId] or normalizerData[itemId][value][0] > startValueId):
                        # Bump indices
                        currentValueId += 1
                        currentIndex += 1
                        
                        # Add entry
                        normalizerData[itemId][value] = ((currentValueId, currentIndex))
                        normalizerDataId[itemId][int(currentValueId)] = ((value, currentIndex))
                        
                        # Add to the end of the start of the file
                        linesStart += "        <value id='" + str(currentValueId) + "' index='" + str(currentIndex) + "' color='#ffff00' name='" + value + "' description='" + descriptions[descIndex] + "' />\n"
                        
                        # Bump other index.
                        # Don't let descriptions run over.  As long as we get each one entered at least once that's good.
                        descIndex += 1
                        if descIndex >= len(descriptions): descIndex = 0
                        
                # Unconditionally update local
                currentValue = value
                
                # Update the entey to indicate it's been used
                usedValues.append((value))
                        
                # Process each result.  Add to the middle.
                # Normalizer result "index" actually references the value "id", not the "index".  Never understood that...
                for result in results: middleLines += "        <result index='" + str(normalizerData[itemId][value][0]) + "' value='" + result + "'" + exactString + " />\n"
        
        # Now change the value and description for entries that haven't been used unless doing a delta update
        if configData['results'].lower() != 'delta':
                # Need to get default and no_field_normalization_value indices (as these are never remapped)
                firstList = linesStart.split('\n')[0].split(' ')
                indexNotChanged = []
                for attrib in firstList:
                        if attrib.startswith('default') or attrib.startswith('no_field_normalization_value'): indexNotChanged.append(attrib.split("'")[1])
                        
                # Debug what's IDs won't be changed.
                #print 'indexNotChanged: ' + str(indexNotChanged)
                
                # Walk each value in the normalizer
                for value in normalizerData[itemId]:
                        # Check if not referenced AND not in the "don't change" indeices
                        if value not in usedValues and str(normalizerData[itemId][value][0]) not in indexNotChanged:
                                #print 'Changing value "' + value + '" which has ID ' + str(normalizerData[itemId][value][0])
                                
                                # Want to change the name and description.  Description is hard, so stick to the name.
                                linesStart = linesStart.replace("name='"+value+"'","name='"+value+"_NOTREFERENCED'")
                        
        # All done.  Write the SVN cached file.
        f = open(filePath, 'w') 
        f.write(linesStart + middleLines + endLines)
        f.close()
        print('Updated file ' + filePath)

# ------------------------------------------------------------------------------
def main():
        print('Hello')

# ------------------------------------------------------------------------------
if __name__ ==  '__main__':
    main()

