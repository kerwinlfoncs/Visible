#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-12-03T09:26:46
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-12-03T09:26:44
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-12-03T09:26:41

# Imports (keep to a minimum)
from __future__ import print_function
# from builtins import str
# from builtins import str
import copy, os, copy, pprint, sys
import xmltodict
import primitives as PRIM

decisionTableData = {}
newLine = '\n'

# ------------------------------------------------------------------------------
def processDecisionTable(options, configDct, lclDCT):
       global decisionTableData
       
       dirString = 'decisionTable'
       
       # Set to local variables (original code was based on local variables)
       for parameter in list(lclDCT.keys()):
                cmd = parameter + ' = lclDCT["' + parameter + '"]'
                exec(cmd)
        
       # Different actions 
       if action == 'init':
        # Init DT information
        
        # Initialize global data
        decisionTableData[itemId] = {}
        
        # Get full path to this file
        filePath = options.svnDir + '/' + dirString + '/' + itemId + '.xml'
        
        # Sanity check this file exists
        if not os.path.exists(filePath): sys.exit('ERROR: ' + dirString + ' file ' + filePath + ' does not exist')
        
        # The number of lines to get from this file is everything up to and including the "<data>" line
        '''
        cmd = 'grep -n "<data>" ' + filePath + ' | cut -f1 -d: '
        linesToSave = PRIM.runCmd(cmd)
        '''
        # NOTE: Only save first line
        linesToSave = 1
        
        # Get those lines
        cmd = "head -" + str(linesToSave) + ' ' + filePath
        startLines = PRIM.runCmd(cmd)
        startLines += newLine
        
        '''
        # Get the normalizers IDs from the file (not from config)
        cmd = 'grep -n "column name" ' + filePath
        columns = PRIM.runCmd(cmd).split('\n')
        normalizers = []
        for entry in columns: normalizers.append(entry.split("'")[5])
        decisionTableData[itemId]['normalizers'] = copy.deepcopy(normalizers)
        '''
        
        # End of the object
        endLines = "    </data>\n</decision_table>"
        
        # Populate global data
        decisionTableData[itemId]['start'] = startLines
        decisionTableData[itemId]['end']   = endLines
        decisionTableData[itemId]['rows']   = '    <data>' + newLine
        
       elif action == 'norm':
        # Define column data
        # Save input normalizers (just in case)
        decisionTableData[itemId]['normalizers'] = copy.deepcopy(lclDCT['normalizers'])
        
        # Build columns data
        decisionTableData[itemId]['columns'] = '    <columns>' + newLine
        for normId in lclDCT['normalizers']:
                # Get the name of the normalizer.  Really should read into ET and get from parameter name...
                # Will fail if the normalizer name has an equal sign in it (=)...
                filePath = options.svnDir + '/normalizers/' + normId + '.xml'
                with open(filePath) as fd:
                        doc = xmltodict.parse(fd.read())
                        normName = doc['normalizer']['@name']

                # Add to DT file
                decisionTableData[itemId]['columns'] += "         <column name='" + normName + "' attribute='norm" + str(normId) + "' normalizerId='" + str(normId) + "' column_width='256' />" + newLine
        
        # Close columns
        decisionTableData[itemId]['columns'] += '    </columns>' + newLine
        
       elif action == 'row':
        # Put row number into data
        decisionTableData[itemId]['rows'] += '        <row id=\'' + number + '\'>' + newLine
                
        # Define row data
        for row in rows:
                # Separate entry
                (normId,normValue) = row
                
                # Put into data
                decisionTableData[itemId]['rows'] += '            <cell name=\'norm' + str(normId) + '\'>' + str(normValue) + '</cell>' + newLine
                
        # Close row 
        decisionTableData[itemId]['rows'] += '        </row>' + newLine
        
       elif action == 'write':
        # write the DT
        # Get full path to this file
        filePath = options.svnDir + '/' + dirString + '/' + itemId + '.xml'
        
        # Write DT file in proper order
        outStr = decisionTableData[itemId]['start'] + decisionTableData[itemId]['columns'] + decisionTableData[itemId]['rows'] + decisionTableData[itemId]['end']
        
        # See if testing or real
        if options.testing:
                print('DT ' + str(itemId) + ': ')
                print(outStr)
        else:
                print('Writing DT ' + str(itemId) + ' to file ' + filePath)
                fd = open(filePath, "w")
                fd.write(outStr)
                fd.close()
        
       '''
       print 'DT data after action ' + action + ':'
       pprint.pprint(decisionTableData)
       '''
        
#================== Main function  ================================================
def main():
        print('Hello')
        
if __name__ ==  '__main__':
    main()

