#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-12-03T09:27:26
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-12-03T09:27:26
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-12-03T09:27:25

# Imports (keep to a minimum)
from __future__ import print_function
# from builtins import str
# from builtins import str
import os, sys, pprint, re, copy
import primitives as PRIM
import decisionTables as DT
import normalizers as NORM
import miscObjects as MISC
import xmltodict

rateTableData = {}
newLine = '\n'

# ------------------------------------------------------------------------------
def processRateTable(options, configDct, key):
        global rateTableData
        
        dirString = 'matrix'
        
        # Get item ID
        itemId = key[2:]
        
        # Initialize global data
        rateTableData[itemId] = {}
        
        # Get full path to this file
        filePath = options.svnDir + '/' + dirString + '/' + itemId + '.xml'
        
        # Sanity check this file exists
        if not os.path.exists(filePath): sys.exit('ERROR: ' + dirString + ' file ' + filePath + ' does not exist')
        
        # The number of lines to get from this file is everything up to and including the "<data>" line.
        checkStr = '<results>'
        cmd = 'grep -n "' + checkStr + '" ' + filePath + ' | cut -f1 -d: '
        #print cmd
        linesToSave = PRIM.runCmd(cmd)
        
        # May not have results, so check for both cases
        if not linesToSave:
                checkStr = '<results />'
                cmd = 'grep -n "' + checkStr + '" ' + filePath + ' | cut -f1 -d: '
                #print cmd
                linesToSave = PRIM.runCmd(cmd)
        
        # If still nothing then error
        if not linesToSave: sys.exit('ERROR: did not find any result string in file ' + filePath)
                
        # Get those lines
        cmd = "head -" + str(linesToSave) + ' ' + filePath
        #print cmd
        startLines = PRIM.runCmd(cmd)
        startLines += '\n'
        
        # End of the object
        endLines = "        </results>\n    </decision_table_ref>\n</matrix>"
        
        # Read the file in so we can grab specific fields
        with open(filePath) as fd:
                doc = xmltodict.parse(fd.read())
                
                dtId = doc['matrix']['decision_table_ref']['@decision_table_id']
                defaultBeat = doc['matrix']['defaultbeat']['@id']
                defaultBeatOverride = doc['matrix']['defaultbeat']['@override']
                eventTypeId = doc['matrix']['@eventTypeId']
                
        # Update global data
        rateTableData[itemId]['start'] = startLines
        rateTableData[itemId]['end'] = endLines
        rateTableData[itemId]['dt'] = dtId
        rateTableData[itemId]['rows'] = ''
        rateTableData[itemId]['defaultBeat'] = defaultBeat
        rateTableData[itemId]['defaultBeatOverride'] = defaultBeatOverride
        rateTableData[itemId]['eventTypeId'] = eventTypeId
        
        '''
        print 'RT data:'
        pprint.pprint(rateTableData)
        '''
        
        # Process the start of the DT
        lclDCT = {}
        lclDCT['action'] = 'init'
        lclDCT['itemId'] = dtId
        DT.processDecisionTable(options, configDct, lclDCT)
        
        # Now process input file
        
        # Get config data for this item
        configData = PRIM.configDct[key]
        
        # Sanity check input
        if 'inputFile' not in configData: sys.exit('ERROR: Must specify an input file in the RT section of the configuration  file')
        
        # Force other elements to be defaulted (so we can always check configData for default values)
        for name,value in [('multiple', 1.0), ('intercept', 0.0), ('units', None), ('beat', None), ('rateTag', None), ('attributes', None)]:
                if name not in configData: configData[name] = str(value)
        #pprint.pprint(configData)
        
        # Put file in local vriable (for ease of reading/typing)
        inputFile = configData['inputFile']
        
        # If config file is full or relative path, then ignore configDir
        if inputFile[0] not in ['.', '/']:
                # If inputDir exists and doesn't end in a slash, then add one
                if options.inputDir and options.inputDir[-1] != '/': options.inputDir += '/'
        
                # Set absolute path
                inputFile = options.inputDir + inputFile
                
        # Sanity check the config file exists
        if not os.path.exists(inputFile): sys.exit('ERROR: RT input file "' + inputFile + '" does not exist')
        print(key + ' input file "' + inputFile + '" exists')
        
        # Read input file
        records = open(inputFile).read().strip().split('\n')
        
        # Proces first line - need to see how many normalizers
        prefix = 'NORM'
        normalizers = [x[len(prefix):] for x in records[0].split(',') if x.startswith(prefix)]
        print('Normalizers: ' + str(normalizers))
        
        # Process DT normalizers
        lclDCT['action'] = 'norm'
        lclDCT['normalizers'] = copy.deepcopy(normalizers)
        DT.processDecisionTable(options, configDct, lclDCT)
        
        # Copy each normalizer if not already present
        for normalizer in normalizers: NORM.processNormalizer(options, configDct, 'COPY'+normalizer)
        '''
        print 'Normalizers:'
        pprint.pprint(NORM.normalizerData)
        '''
        
        # Process remainder of the lines
        for row,record in enumerate(records[1:]):
                # Separate into a list
                record = record.split(',')
                normValues = []
                
                # Get normalizer data
                for j,normalizer in enumerate(normalizers):
                        # Get the normalizer value
                        normData = record[j]
                        
                        # Find the ID.  The value may be the ID or the field name
                        try:
                                normData = NORM.normalizerData[normalizer][normData][0]
                                #print 'Translated record ' + str(row) + ' normalizer "' + normalizer + '" from "' + str(record[j]) + '" to index ' + str(normData)
                        except: print('Using input normalizer ID ' + str(normData))
                        
                        '''
                        if not normData.isdigit():
                                # Make sure it's in the read data
                                if normData not in NORM.normalizerData[normalizer]:
                                        print 'ERROR: normalizer input value "' + normData + '" not in normalizer ' + str(normalizer)
                                        pprint.pprint(NORM.normalizerData[normalizer])
                                        sys.exit('Eiting due to errors')
                        
                                # If here, then found the item.  get the index
                                normData = NORM.normalizerData[normalizer][normData][0]
                                #print 'Translated normalizer value of "' + record[row] + '" to index ' + str(normData)
                        else:   print 'Using input normalizer ID ' + str(normData)
                        '''
                        
                        # Add norm ID and value to rows array
                        normValues.append((normalizer,normData))
                
                # Add to DT rows
                lclDCT['action'] = 'row'
                lclDCT['number'] = str(row)
                lclDCT['rows'] = copy.deepcopy(normValues)
                DT.processDecisionTable(options, configDct, lclDCT)
                
                # *** Now process RT information.
                # Open the row
                rowData = '            <result id=\'' + str(row) + '\'>' + newLine
                
                # Get the formula data
                formula = record[j+1:]
                #print 'Formula; ' + str(formula)
                
                # See if a skip
                if   formula[0] == 'skip':              rowData += '                <skip />' + newLine + '                <attributes />' + newLine
                elif formula[0].startswith('deny'):
                        # Get denial code
                        code = formula[1]
                        print('Code = ' + code)
                        
                        # Code may be the text or the denial code.  Will also work for the file ID iff the codes start above the file IDs...
                        try: code = MISC.denialData[code]
                        except: pass
                        
                        # Write the result
                        rowData += "                <error error_id='" + code + "' />" + newLine
                else:
                        # Need to process the whole formula.  Never sure how many items were entered...
                        i=0
                        for (entry,defaultValue) in [('slope', 0), ('multiple', 0), ('intercept', 0), ('units', ''), ('beat', 0), ('ratetag', None), ('attributes', None)]:
                                try:
                                        cmd = entry + ' = formula[' + str(i) + ']'
                                        exec(cmd)
                                except:
                                        cmd = entry + ' = configData[' + entry + '] if ' + entry + ' in configData else ' + str(defaultValue)
                                        exec(cmd)
                        try:    multiple = formula[1]
                        except: multiple = configData['multiple']
                        try:    intercept = formula[2]
                        except: intercept = configData['intercept']
                        try:    units = formula[3]
                        except: units = configData['units']
                        if units == 'None': units = ''
                        try:    beat = formula[4]
                        except: beat = configData['beat']
                        try:    rateTag = formula[5]
                        except: rateTag = configData['rateTag']
                        try:    attributes = formula[6]
                        except: attributes = configData['attributes']
                        
                        # Beat may not be overrideable or not ahve been specified in the row
                        if rateTableData[itemId]['defaultBeatOverride'].lower() == 'false' or not beat: beat = rateTableData[itemId]['defaultBeat']
                        
                        # Write the row
                        rowData += "                <formula intercept='" + intercept + "' slope='" + slope + "' multiple='" + multiple + "' units='" + units + "'"
                        
                        # Beat is optional
                        if beat not in ["", "None"]:
                                # Beat may be the name or the ID.  Note that the name is relative to the service beat definitions.
                                try: beat = MISC.beatDataName[rateTableData[itemId]['eventTypeId']][beat]
                                except: pass
                                rowData +=  " beatid='" + beat + "'"
                        
                        # Ratetag is optional
                        if rateTag not in ["", "None"]:
                                # Rate tag may be the name or the ID
                                try: rateTag = MISC.rateTagDataName[rateTag]
                                except: pass
                                rowData +=  " ratetag='" + rateTag + "'"
                        
                        # Always close the row and add new line
                        rowData += " />" + newLine
                        
                        # At the moment, the tool doesn't support per-row attributes
                        rowData += '                <attributes />' + newLine
                        
                # Close the row
                rowData += '            </result>' + newLine
                
                # Update global string
                #print rowData
                rateTableData[itemId]['rows'] += rowData
                
        # Write the DT
        lclDCT['action'] = 'write'
        DT.processDecisionTable(options, configDct, lclDCT)
        
        # Write RT file in proper order
        outStr = rateTableData[itemId]['start'] + rateTableData[itemId]['rows'] + rateTableData[itemId]['end']
        
        # If testing then show what would be written
        if options.testing:
                print('RT ' + str(itemId) + ' data:')
                print(outStr)
        else:
                print('Writing RT ' + str(itemId) + ' to file ' + filePath)
                fd = open(filePath, "w")
                fd.write(outStr)
                fd.close()
        
#================== Main function  ================================================
def main():
        print('Hello')
        
if __name__ ==  '__main__':
    main()

