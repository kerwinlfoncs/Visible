#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-12-03T09:27:25
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-12-03T09:27:25
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-12-03T09:27:24

# Imports (keep to a minimum)
from __future__ import print_function
# from builtins import str
from future import standard_library
standard_library.install_aliases()
# from builtins import str
import subprocess, os, sys, pprint, re, copy
try:
    import configparser
except:
    from six.moves import configparser

configDct = {}

#===============================================================================
# This reads from a traditional LDAP-style init file:
'''
[Operations]
# Only performing Diameter operations with this config
Diameter        : True

[Diameter]
# Unique host/realm, so obvious where these came from
OriginHost              : MATRIXX-INFINITY-HOST
OriginRealm             : MATRXIX-INFINITY-REALM
'''
# The results are stored in a standards Python dictionary

def getConfig(configIniFile):
        global configDct
        
        if not os.path.exists(configIniFile):
                print('cannot find file ' + configIniFile + ' in the current directory')
                sys.exit(1)
        
        print('reading configuration data from ' + str(configIniFile))
        configG = configparser.ConfigParser()
        
        # Setup so option name case is preserved (default is to change to lower case)
        configG.optionxform=str
        
        # Read the file
        configG.read(configIniFile)
        
        # Play with this.  See if we can get every section and every field within every section
        sections = configG.sections()
        
        retData = {}
        for section in sections:
                retData[section] = {}
                for (option,value) in configG.items(section): retData[section][option] = value
        
#       print 'config dictionary: '
#       pprint.pprint(retData)
        
        # Save in global data
        configDct = copy.deepcopy(retData)
        
        return (retData)

#===============================================================================
# This function is used to run bash scripts.
def runCmd(cmd):
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    out = p.stdout.read().strip()
    return out  #This is the stdout from the shell command

#================== Main function  ================================================
def main():
        print('Hello')


if __name__ ==  '__main__':
    main()

