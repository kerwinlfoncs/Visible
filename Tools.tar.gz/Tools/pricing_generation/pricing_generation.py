#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-12-03T09:27:24
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-12-03T09:27:24
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-12-03T09:27:23

# Imports (keep to a minimum)
from __future__ import print_function
# from builtins import str
from future import standard_library
standard_library.install_aliases()
# from builtins import str
from optparse import OptionParser
try:
    import configparser
except:
    from six.moves import configparser
import os, sys, copy, pprint
import normalizers as NORM
import rateTables as RT
import primitives as PRIM
import miscObjects as MISC

# ------------------------------------------------------------------------------
# Define input
def commandInput():
        global options
        global args

        # -----------------------------------------------------------------------------
        # Program Usage and Options
        # -----------------------------------------------------------------------------
        #define the options and parameter
        parser = OptionParser(usage="usage: %prog [options] filename",
                      version="%prog 0.1")

        parser.add_option("-v", "--verbose",  action="store", default=None, type="string", help="verbose flag",)
        parser.add_option("-d", "--configDir", action="store", default="./", type="string", help="Configuration Directory",)
        parser.add_option("-i", "--configFile", action="store", default=None, type="string", help="Configuration file",)
        parser.add_option("", "--inputDir", action="store", default='./', type="string", help="Input file directory",)
        parser.add_option("-s", "--svnDir", action="store", default=None, type="string", help="SVN workspace path directory",)
        parser.add_option("-w", "--workspace", action="store", default='admin', type="string", help="SVN workspace (defaults to admin)",)
        parser.add_option("", "--domain", action="store", default=None, type="string", help="Pricing domain to update",)
        parser.add_option("-r", "--release", action="store", default=None, type="int", help="Engine Release",)
        parser.add_option("-t", "--testing", action="store_true", default=False, help="Test flag",)
        
        # Process inputs
        (options, args) = parser.parse_args()
        
        # Query release if not passed in
        if not options.release:
                options.release = PRIM.runCmd('rpm -q matrixxsw-mymatrixx | grep mymatr | cut -f3 -d- | cut -f1 -d.')
                if not options.release: options.release=4700
                else:                   options.release = int(options.release)
                print('Running on release ' + str(options.release))
        
        # Sanity check input
        if not options.configFile: sys.exit('ERROR: Must specify a configuration file')
        
        # If config file is full or relative path, then ignore configDir
        if options.configFile[0] in ['.', '/']: options.configDir = ""
        
        # If configDir still remains and doesn't end in a slash, then add one
        if options.configDir and options.configDir[-1] != '/': options.configDir += '/'
        
        # Sanity check the config file exists
        if not os.path.exists(options.configDir + options.configFile): sys.exit('ERROR: configuration file ' + options.configDir + options.configFile + ' does not exist')
        
        # Verify the input directory exists
        if not os.path.isdir(options.inputDir): sys.exit('ERROR: input directory "' + options.inputDir + '" doesn\'t exist')
        
        # SVN checks
        if not options.domain: sys.exit('ERROR: Must specify a pricing domain')
        
        # Default SVN dir if not specified
        if not options.svnDir:
           if options.release < 5100:
                cmd='grep CATALINA_TMPDIR /etc/sysconfig/tomcat* | cut -f2 -d\'"\''
                options.svnDir = PRIM.runCmd(cmd)
                options.svnDir += "/mtx_workspaces"
           else: options.svnDir = '/var/mtx_catalog_builder/temp/mtx_workspaces'
        print('Setting svnDir to ' + options.svnDir)
        
        # Make sure workspace is a number
        if not options.workspace.isdigit():
                # Find the user.  Use "." instead of single tick as that seems to not get through the bash commnd to th einvoked command... 
                cmd = 'grep "name=.' + options.workspace + '." /var/mtx_catalog_builder/data/_configuration/Credentials/*xml | cut -f7 -d"/" | cut -f1 -d"."'
                oldValue = options.workspace
                options.workspace = PRIM.runCmd(cmd)
                print('Changed workspace name from "' + oldValue + '" to "' + options.workspace + '"')
        
        # Add SVN domain and workspace
        options.svnDir += '/' + options.domain + '/' + options.workspace
        
        # Make sure directory exists
        if not os.path.isdir(options.svnDir): sys.exit('ERROR: SVN directory "' + options.svnDir + '" doesn\'t exist')
        
        # Return input data
        return options,args
        
#================== Main function  ================================================
def main():
        # Get input parameters
        (options, args) = commandInput()
        
        # Get configuration
        configDct = PRIM.getConfig(options.configDir + options.configFile)
        #pprint.pprint(configDct)
        
        # Process all event types
        MISC.processBeats(options, configDct)
        MISC.processRateTags(options, configDct)
        MISC.processDenialCodes(options, configDct)
                
        prefix = 'NORM'
        # Process each Normalizer
        for key in configDct:
                # Process all normalizers first (copies and overwrites).
                # Skip if not desired type.
                if not (key.startswith(prefix) or key.startswith('COPY')): continue
                
                # Process this normalizer
                print('Looking at normalizer ' + key[len(prefix):])
                
                # Now process the normalizer
                NORM.processNormalizer(options, configDct, key)
                
        prefix = 'RT'
        # Process rate tables
        for key in configDct:
                # Skip if not desired type
                if not key.startswith(prefix): continue
                
                # Process this normalizer
                print('Looking at rate table ' + key[len(prefix):])
                
                # Now process the normalizer
                RT.processRateTable(options, configDct, key)
                
        
if __name__ ==  '__main__':
    main()

