from distutils.core import setup
setup(name='mtx-services-viewMEF',
	version='4710.0',
	description='MATRIXX Services MEF viewer',
        packages=['viewMEFData'],
	scripts=['viewMEF.py'],
	author='Karl Freter',
	author_email='karl.freter@matrixxsw.com',
	url='www.matrixxsw.com',
      )

