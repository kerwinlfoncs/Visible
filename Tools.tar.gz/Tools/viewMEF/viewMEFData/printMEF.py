#!/usr/bin/python
from __future__ import print_function
from __future__ import absolute_import
from future import standard_library
standard_library.install_aliases()
# from builtins import range
import sys, os, copy
try:
    import configparser
except:
    from six.moves import configparser
from subprocess import call
import subprocess
import optparse
import time
#pylint: disable=import-error,multiple-imports
import urllib.request, urllib.parse, urllib.error
import xml.etree.ElementTree as ET
from . import dataMEF as DATA
from primitives import primGeneric as GENERIC
from primitives import primGET as GET

#===============================================================================
def printBalanceTrackingHeading(dctEvent):
	
        print('------------------------  ' + dctEvent['eventName'] + ' ' + '<No Event ID>' + ' at time ' + dctEvent['ProcessTime'] + ' -----------------------\n')

#===============================================================================
def printNotificationEventHeading(dctEvent):
	
        print('------------------------  ' + dctEvent['eventName'] + ' ' + dctEvent['NotificationId'] + ' at time ' + dctEvent['NotificationTime'] + ' -----------------------\n')

#===============================================================================
def printEventEventHeading(dctEvent):
	
        print('------------------------  ' + dctEvent['eventName'] + ' ' + dctEvent['EventId'] + ' at time ' + dctEvent['EventTime'] + ' -----------------------\n')

#===============================================================================
def printNotifictionObjectData(dctEvent, configDct):
	# Print heading
	print('Objects:')
	
	# Define output format
	format = "%-10s %-12s %-40s\n"
	sys.stdout.write(format % ('Type', 'OID', 'ID'))
	
	# Get the type of the initiator
	if   dctEvent['ObjectType'] == '1': initiatorType = 'Subscriber'
	elif dctEvent['ObjectType'] == '2': initiatorType = 'Group'
	elif dctEvent['ObjectType'] == '3': initiatorType = 'Device'
	else:
		print('Hmmm.  Unexpected ObjectType value of ' + dctEvent['ObjectType'])
		initiatorType = None
	
	# If nothing returned, then exit
	if not initiatorType:
		print('Hmmm.  Couldn\'t find the type of the initiator')
		return
	
	# Store so it's usable later
	dctEvent['initiatorType'] = initiatorType
	
	# Output depends on whether there's a difference
	sys.stdout.write(format % (initiatorType.capitalize(), dctEvent['ObjectId'], dctEvent['ObjectExternalId']+'(E)'))
	
	print()
	
#===============================================================================
def printBalanceTrackingObjectData(dctEvent, configDct):
	# Print heading
	print('Object:')
	
	# Define output format
	format = "%-10s %-12s %-40s\n"
	sys.stdout.write(format % ('Type', 'OID', 'ID'))
	
	# Get the type of the initiator
	initiatorType = GET.getObjectType(dctEvent['OwnerId'])
	
	# If nothing returned, then exit
	if not initiatorType:
		print('Hmmm.  Couldn\'t find the type of the initiator')
		return
	
	# Store so it's usable later
	dctEvent['initiatorType'] = initiatorType
	
	# Output 
	sys.stdout.write(format % (initiatorType.capitalize(), dctEvent['OwnerId'], dctEvent['OwnerExternalId']+'(E)'))
	
#===============================================================================
def printEventObjectData(dctEvent, configDct):
	# Print heading
	print('Objects:')
	
	# Define output format
	format = "%-10s %-12s %-40s\n"
	sys.stdout.write(format % ('Type', 'OID', 'ID'))
	
	# Get the type of the initiator
	initiatorType = GET.getObjectType(dctEvent['InitiatorId'])
	
	# If nothing returned, then exit
	if not initiatorType:
		print('Hmmm.  Couldn\'t find the type of the initiator')
		return
	
	# Store so it's usable later
	dctEvent['initiatorType'] = initiatorType
	
	# See if there's a different impacted wallet
	if dctEvent['InitiatorId'] != dctEvent['WalletOwnerId']:
		# Want the type of the target
		impactedType = GET.getObjectType(dctEvent['WalletOwnerId'])
		
		# Sanity check this as well, but don't exit
		if not impactedType: print('Hmmm.  Couldn\'t find the type of the impacted object')
	else:	impactedType = None
	
	# Store so it's usable later
	dctEvent['impactedType'] = impactedType
	
	# Add indication if source/dest are different
	if impactedType:
		initiatorType += '(I)'
		impactedType  += '(W)'
	
	# Output depends on whether there's a difference
	sys.stdout.write(format % (initiatorType.capitalize(), dctEvent['InitiatorId'], dctEvent['InitiatorExternalId']+'(E)'))
	
	# Output impacted only if different
	if impactedType: sys.stdout.write(format % (impactedType.capitalize(), dctEvent['WalletOwnerId'], dctEvent['WalletOwnerExternalId']+'(E)'))
	
	# If device present, then output
	if 'InitiatorDeviceId' in dctEvent:
		# Get device MSISDN
        	msisdn = GENERIC.runCmd('curl -s http://' + configDct['Rest']['hostname'] + ':' + configDct['Rest']['hostport'] + '/rsgateway/data/v3/device/' + dctEvent['InitiatorDeviceId'] + ' | grep value | cut -f2 -d">" | cut -f1 -d"<"')

	        # If msisdn not present, then device may already have been deleted
        	if not msisdn: msisdn = "Not Present"
		
		sys.stdout.write(format % ('Device', dctEvent['InitiatorDeviceId'], msisdn+'(M)'))
	print()
	
#===============================================================================
# This function processes usage events
def printNotificationEvent(dctEvent, configDct, options):
        # Print heading
        printNotificationEventHeading(dctEvent)
	
	# Print object data
	printNotifictionObjectData(dctEvent, configDct)
	
	# Loop through the event containers and process each one
	for item in DATA.dataList:
		name = item[0]
		
		# All sections accounted for
		cmd = 'print' + name + '(dctEvent, configDct, options)'
		exec(cmd)
	
#===============================================================================
# This function processes balance tracking events
def printBalanceTrackingEvent(dctEvent, configDct, options):
        # Print heading
        printBalanceTrackingHeading(dctEvent)
	
	# Print object data
	printBalanceTrackingObjectData(dctEvent, configDct)
	
	# Should print 
#===============================================================================
# This function processes usage events
def printEventEvent(dctEvent, configDct, options):
        # Print heading
        printEventEventHeading(dctEvent)
	
	# Print object data
	printEventObjectData(dctEvent, configDct)
	
        # *** Data massaging ***
        # Update duration to remove usec component
        if 'duration' in dctEvent: dctEvent['duration'] = dctEvent['duration'][:-6]
        else:                      dctEvent['duration'] = 'Not Specified'

        # Convert request type value to string
        if 'ccrequesttype' in dctEvent:
                if   dctEvent['ccrequesttype'] == '2': dctEvent['ccrequesttype'] = 'initial'
                elif dctEvent['ccrequesttype'] == '3': dctEvent['ccrequesttype'] = 'update'
                elif dctEvent['ccrequesttype'] == '4': dctEvent['ccrequesttype'] = 'term'
                elif dctEvent['ccrequesttype'] == '1': dctEvent['ccrequesttype'] = 'event'
        else:   dctEvent['ccrequesttype'] = 'n/a'
	
	# Loop through the event containers and process each one
	for item in DATA.dataList:
		name = item[0]
		
		# All sections accounted for
		cmd = 'print' + name + '(dctEvent, configDct, options)'
		exec(cmd)
	
        return 

#===============================================================================
def printBalanceUpdateArray(dctEvent, configDct, options):
        # May not have any balance impacts
        key = 'BalanceUpdateArray'
        if key not in dctEvent: return

	# Define output format
	format = "%-30s %-30s %-10s %-10s\n"
	
	# Fields we'll want from this structure
        items = ['BalanceClassId', 'BalanceTemplateId', 'Amount', 'QuantityUnit']
	
	# Print heading
        print('Balance Updates:')

        # Loop through each impacted balance
        for idx in range(len(dctEvent[key])):
                # Convert balance class and template to names
                (dctEvent[key][idx]['BalanceClassId'], dctEvent[key][idx]['BalanceTemplateId'], dctEvent[key][idx]['QuantityUnit']) =  \
                        GET.getBalanceClassAndTemplateNames(dctEvent[key][idx]['BalanceTemplateId'], configDct['Rest']['hostname'], configDct['Rest']['hostport'])
	
	# Write header
        sys.stdout.write(format % ('Class', 'Template', 'Amount', 'Units'))
	
	# Process each entry
	printAllEntry(dctEvent[key], items, format)

        return

#===============================================================================
def printContactArray(dctEvent, configDct, options):
        # May not have any data
        key = 'ContactArray'
        if key not in dctEvent: return
	
	# Define output format
	format = "%-11s %-20s %-15s\n"
	
	# Fields we'll want from this structure
        items = ['SubscriberId', 'externalId', 'notificationText']
	
        print('Subscriber Contact:')
	
        # Loop through each event
        for idx in range(len(dctEvent[key])):
                # Get external ID
		dctEvent[key][idx]['externalId'] = GET.getSubscriberExternalId(dctEvent[key][idx]['SubscriberId'])
		
		# Map notification flags to name
		if   dctEvent[key][idx]['NotificationFlags'] == '1': dctEvent[key][idx]['notificationText'] = 'email'
		elif dctEvent[key][idx]['NotificationFlags'] == '2': dctEvent[key][idx]['notificationText'] = 'text'
		elif dctEvent[key][idx]['NotificationFlags'] == '3': dctEvent[key][idx]['notificationText'] = 'email or text'
		else:						     dctEvent[key][idx]['notificationText'] = 'none'	
		
	# Write header
        sys.stdout.write(format % ('OID', 'External ID', 'Notification'))
	
	# Process each entry
	printAllEntry(dctEvent[key], items, format)

	return
	
#===============================================================================
def printRolloverBalanceEndTimeUpdateArray(dctEvent, configDct, options):
        # May not have any data
        key = 'RolloverBalanceEndTimeUpdateArray'
        if key not in dctEvent: return

#        print 'Rollover Balance EndTime Updates:'
	
	return
	
#===============================================================================
def printChargeList(dctEvent, configDct, options):
        # May not have any data
        key = 'ChargeList'
        if key not in dctEvent: return

#        print 'ChargeList List:'
	
	return
	
#===============================================================================
def printUsageQuantityList(dctEvent, configDct, options):
        # May not have any data
        key = 'UsageQuantityList'
        if key not in dctEvent: return

#        print 'Usage Quantity List:'
	
	return
	
#===============================================================================
def printBundleInfoArray(dctEvent, configDct, options):
        # May not have any data
        key = 'BundleInfoArray'
        if key not in dctEvent: return
	
	# Define output format
	format = "%-10s %-45s\n"
	
	# Fields we'll want from this structure
        items = ['BundleId', 'ExternalId']
	
	# Stuff to do before output
        for idx in range(len(dctEvent[key])):
                # Merge version if non-zero
		if dctEvent[key][idx]['BundleVersion'] != '0': dctEvent[key][idx]['BundleId'] += '-' + dctEvent[key][idx]['BundleVersion']
		
	# Print heading
        print('Bundles:')
	
	# Write header
        sys.stdout.write(format % ('ID', 'External ID'))
	
	# Process each entry
	printAllEntry(dctEvent[key], items, format)

#===============================================================================
def printOfferInfoArray(dctEvent, configDct, options):
        # May not have any data
        key = 'OfferInfoArray'
        if key not in dctEvent: return
	
	# Define output format
	format = "%-10s %-45s %-32s %-32s\n"
	
	# Fields we'll want from this structure
        items = ['OfferId', 'ExternalId', 'StartTime', 'EndTime']
	
	# Stuff to do before output
        for idx in range(len(dctEvent[key])):
                # Merge version if non-zero
		if dctEvent[key][idx]['OfferVersion'] != '0': dctEvent[key][idx]['OfferId'] += '-' + dctEvent[key][idx]['OfferVersion']
		
		# Want to remove msec from the times, as they add no value
		for timeValue in ['StartTime', 'EndTime']:
			# Get the entry in pieces
			timeArray = dctEvent[key][idx][timeValue].split('.')
			
			# Remove the leading numbers after the period
			timeArray[1] = timeArray[1][6:]
			
			# Join them back up with no separation
			dctEvent[key][idx][timeValue] = "".join(timeArray)
			
		# Check for end time set to infinity (and change string to "None")
		if dctEvent[key][idx]['EndTime'].startswith('65535'): dctEvent[key][idx]['EndTime'] = 'None'
		
	# Print heading
        print('Offers:')
	
	# Write header
        sys.stdout.write(format % ('ID', 'External ID', 'Start Time', 'End Time'))
	
	# Process each entry
	printAllEntry(dctEvent[key], items, format)

#===============================================================================
def printAppliedBundleArray(dctEvent, configDct, options):
        # May not have any data
        key = 'AppliedBundleArray'
        if key not in dctEvent: return
	
	# Define output format
	format = "%-10s %-45s\n"
	
	# Fields we'll want from this structure
        items = ['BundleId', 'BundleExternalId']
	
	# Stuff to do before output
        for idx in range(len(dctEvent[key])):
                # Merge version if non-zero
		if dctEvent[key][idx]['BundleVersion'] != '0': dctEvent[key][idx]['BundleId'] += '-' + dctEvent[key][idx]['BundleVersion']
		
	# Print heading
        print('Applied Bundles:')
	
	# Write header
        sys.stdout.write(format % ('Offer ID', 'External ID'))
	
	# Process each entry
	printAllEntry(dctEvent[key], items, format)

#===============================================================================
def printAppliedOfferArray(dctEvent, configDct, options):
        # May not have any data
        key = 'AppliedOfferArray'
        if key not in dctEvent: return
	
	# Fields we'll want from this structure
	# NOTE: recurring operations report unit data but it's invalid (i.e. N/A)
	# Remove from string if so.
	if dctEvent['baseName'].count('Recurring'): 
		# Define output format
		format = "%-10s %-45s %-40s\n"
		
		# Items to report
	        items = ['ProductOfferId', 'ProductOfferExternalId', 'Target']
	else:
		# Define output format
		format = "%-10s %-45s %-17s %-40s\n"
		
		# Items to report
	        items = ['ProductOfferId', 'ProductOfferExternalId', 'UsageQuantity', 'Target']
	
	# Stuff to do before output
        for idx in range(len(dctEvent[key])):
		# If the offer was targeted at a different user, then need to resolve that here.
		# Store null string in the target
		dctEvent[key][idx]['Target'] = ''
		
		# Not all events have this field
		if 'ProductOfferOwnerId' in dctEvent[key][idx]:
			# See if different
			if dctEvent['InitiatorId'] != dctEvent[key][idx]['ProductOfferOwnerId']:
				# Get target type
				recipientType = GET.getObjectType(dctEvent[key][idx]['ProductOfferOwnerId'])
				
				# If nothing returned, then print, else store external ID and object type indication)
				if not recipientType: print('Hmmm.  Couldn\'t find the type of the recipientType with OID ' + dctEvent[key][idx]['ProductOfferOwnerId'])
				else: dctEvent[key][idx]['Target'] = dctEvent[key][idx]['ProductOfferOwnerExternalId'] + '(' + recipientType.capitalize() + ')'
		else:
			# Should be a global offer then
			if dctEvent[key][idx]['ProductOfferExternalOwnerId'].lower().startswith('global'): dctEvent[key][idx]['ProductOfferExternalId'] += '(Global)'
			else: print('Hmmm.  Offer is not global and doesn\'t have a target OID...')
	
                # Merge version if non-zero
		if dctEvent[key][idx]['ProductOfferVersion'] != '0': dctEvent[key][idx]['ProductOfferId'] += '-' + dctEvent[key][idx]['ProductOfferVersion']
		
		# If bundle, then indicate that
		if 'AppliedBundleIndex' in dctEvent[key][idx]: dctEvent[key][idx]['ProductOfferId'] += '(B)'
		
	# Print heading
        print('Applied Offers:')
	
	# Write header
	if dctEvent['baseName'].count('Recurring'): 
		sys.stdout.write(format % ('Offer ID', 'External ID', 'Target'))
        else:
		sys.stdout.write(format % ('Offer ID', 'External ID', 'Amount', 'Target'))
	
	# Process each entry
	printAllEntry(dctEvent[key], items, format)

#===============================================================================
def printAllEntry(dct, items, format):
	# Process each entry in the array
        for idx in range(len(dct)):
		# Default data to nothing.
		data = []
		
		# Process each item 
                for item in items:
			# If defined, use the value, else set to None
                        if item in dct[idx]: data.append((dct[idx][item]))
                        else:                data.append(('None'))
		
		# Now join the array and make a string that works for output
		data = "'" + "','".join(data) + "'"
#		print 'Data: ' + str(data)
		
		# Output the data.  Need indirection to get the data variable to work for this command...
		cmd = 'sys.stdout.write(format % (' + data + '))'
		exec(cmd)
	
	# Add separation
	print()
	
#===============================================================================
def translateCommonNotificationFields(dctEvent, configDct):
        if   dctEvent['ThresholdTrigger'] == '0': dctEvent['ThresholdTrigger'] = 'unspecified'
        elif dctEvent['ThresholdTrigger'] == '1': dctEvent['ThresholdTrigger'] = 'purchase'
        elif dctEvent['ThresholdTrigger'] == '2': dctEvent['ThresholdTrigger'] = 'cancel'
        else:                                     dctEvent['ThresholdTrigger'] = 'unknown value'

        if   dctEvent['ObjectType'] == '1': dctEvent['ObjectType'] = 'subscriber'
        elif dctEvent['ObjectType'] == '2': dctEvent['ObjectType'] = 'group'
        elif dctEvent['ObjectType'] == '3': dctEvent['ObjectType'] = 'device'
        else:                               dctEvent['ObjectType'] = 'unknown value'

        if   dctEvent['ContactArrayType'] == '1': dctEvent['ContactArrayType'] = 'subscribers'
        elif dctEvent['ContactArrayType'] == '2': dctEvent['ContactArrayType'] = 'group admins'
        elif dctEvent['ContactArrayType'] == '3': dctEvent['ContactArrayType'] = 'group members'
        else:                                     dctEvent['ContactArrayType'] = 'unknown value'

        # Get balance class and template names
        (dctEvent['ClassId'], dctEvent['TemplateId'], dctEvent['QuantityUnit']) = GET.getBalanceClassAndTemplateNames(dctEvent['TemplateId'], configDct['Rest']['hostname'], configDct['Rest']['hostport'])

        return

#===============================================================================
def printBalanceThresholdNotification(dctEvent, configDct, options):
        # For ease of reading the output
        recType = 'Balance Threshold Notification'
        print('------------------------  ' + recType + ' Event -----------------------')

        # Need to change some values from integers to strings
        if dctEvent['Type'] == '1': dctEvent['Type'] = 'credit limit'
        else:                       dctEvent['Type'] = 'other'

        if dctEvent['BalanceType'] == '1': dctEvent['BalanceType'] = 'gross'
        else:                              dctEvent['BalanceType'] = 'reserved'

        # Translate common notification dictionary fields
        translateCommonNotificationFields(dctEvent, configDct)

        # Print data
        line = ''
        items = ['ObjectType', 'ObjectId', 'ObjectExternalId']
        printIndividualItems(dctEvent, items, line)

        line = ''
        items = ['Type', 'BalanceType', 'ThresholdId', 'ThresholdName', 'ThresholdAmount', 'ThresholdLimit']
        printIndividualItems(dctEvent, items, line)

        line = ''
        items = ['ClassId', 'TemplateId', 'Amount', 'QuantityUnit', 'StartTime', 'EndTime']
        printIndividualItems(dctEvent, items, line)

        # Print the data event - single items
        line = 'Notification Information: '
        items = ['PhoneNumber', 'SubscriberId']
        printIndividualItems(dctEvent['ContactArray'][0], items, line)

        return

#===============================================================================
def printIndividualItems(dctEvent, items, line):
        print()
        for item in items:
#               print 'Checking for item ' + item
                if item in dctEvent: line += item + ': ' + dctEvent[item] + ', '

        # Output the information if anything is present
        if line: print(line[:-2] + '\n')

        return

#===============================================================================
# This function processes device status Notifications
def printDeviceStatusNotification(dctEvent, configDct, options=None):

        # Heading
        recType = 'Device'
        print('------------------------  ' + recType + ' Notification -----------------------')

        # Want to get the device MSISDN
        dctEvent['MSISDN'] = GENERIC.runCmd('curl -s http://' + configDct['Rest']['hostname'] + ':' + configDct['Rest']['hostport'] + '/rsgateway/data/v3/device/' + dctEvent['DeviceId'] + ' | grep value | cut -f2 -d">" | cut -f1 -d"<"')

        # If msisdn not present, then device may already have been deleted
        if not dctEvent['MSISDN']: dctEvent['MSISDN'] = "Not Present"

        # Print the data event - single items
        line = ''
        items = ['DeviceId', 'MSISDN']
        printIndividualItems(dctEvent, items, line)

        # Print the data event - single items
        line = ''
        items = ['DescriptionBefore', 'DescriptionAfter', 'NotificationTime']
        printIndividualItems(dctEvent, items, line)

        # Print the data event - single items
        line = 'Notification Info: '
        items = ['PhoneNumber', 'SubscriberId']
        printIndividualItems(dctEvent['ContactArray'][0], items, line)

        return
	
#================== Main function  ================================================
def main():
    print('hello')

if __name__ ==  '__main__':
    main()
