#!/usr/bin/python

# Define MEF output data 
dataList = (('UsageQuantityList',       'MtxEventUsageQuantity'),
            ('AppliedOfferArray',       'MtxEventAppliedOffer',	'PurchasedOfferAttr'),
            ('AppliedBundleArray',      'MtxEventAppliedBundle'),
            ('OfferInfoArray',          'MtxPurchaseEventOfferInfo'),
            ('BundleInfoArray',         'MtxEventBundleInfo'),
            ('BalanceUpdateArray',      'MtxBalanceUpdate'),
            ('ChargeList',              'MtxEventCharge'),
            ('RolloverBalanceEndTimeUpdateArray',          'MtxBalanceEndTimeUpdate'),
	    ('ContactArray',  'MtxNotificationContact'),
           )

