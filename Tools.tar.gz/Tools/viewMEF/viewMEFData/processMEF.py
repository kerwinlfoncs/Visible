#!/usr/bin/python
from __future__ import print_function
from __future__ import absolute_import
from future import standard_library
standard_library.install_aliases()
import sys, os, copy
try:
    import configparser
except:
    from six.moves import configparser
from subprocess import call
import subprocess
import optparse
import time
#pylint: disable=import-error,multiple-imports
import urllib.request, urllib.parse, urllib.error
import xml.etree.ElementTree as ET
from . import dataMEF as DATA

from primitives import primXML as XML

#================== Process EDRs  ================================================
def processEvents(q):
	return processNotificationEvent(q)

#================== Process Notifications  ================================================
def processNotificationEvent(q):
	dctRcv = {}
	
	### Put in a separate function ###
	XML.getObjectBaseFields(q, dctRcv)
				
	# Loop through entries
	for combo in DATA.dataList:
		# Get key fields
		field1 = combo[0]
		field2 = combo[1]
		
		# Look for top level items
		for item in q.findall(field1):
			# Assume only one top level item (for now)
			dctRcv[field1] = []
			
			# Look for second level items
			for itemDetails in item.findall(field2):
				# Clear entry
				tmpdctRcv = {}
				
				# Get fields associated with this structure
				XML.getObjectBaseFields(itemDetails, tmpdctRcv)
				
				# Append to overall field array
				dctRcv[field1].append(tmpdctRcv)
						
	return dctRcv
	
#================== Process Non-Notifications  ================================================
def processEventEvent(q):
	dctRcv = {}
	
	### Put in a separate function ###
	XML.getObjectBaseFields(q, dctRcv)
				
	# Loop through entries
	for combo in DATA.dataList:
		# Get key fields
		field1 = combo[0]
		field2 = combo[1]
		
		# Look for top level items
		for item in q.findall(field1):
			# Assume only one top level item (for now)
			dctRcv[field1] = []
			
			# Look for second level items
			for itemDetails in item.findall(field2):
				# Clear entry
				tmpdctRcv = {}
				
				# Get fields associated with this structure
				XML.getObjectBaseFields(itemDetails, tmpdctRcv)
				
				# Append to overall field array
				dctRcv[field1].append(tmpdctRcv)
						
	return dctRcv
	
#================== Main function  ================================================
def main():
    print('hello')
    
if __name__ ==  '__main__':
    main()
