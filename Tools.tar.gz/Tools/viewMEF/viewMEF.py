#!/usr/bin/python
from __future__ import print_function
from __future__ import absolute_import
from future import standard_library
standard_library.install_aliases()
import sys, os, copy
try:
    import configparser
except:
    from six.moves import configparser
from subprocess import call
import subprocess
import optparse
import time
#pylint: disable=import-error,multiple-imports
import urllib.request, urllib.parse, urllib.error
from datetime import datetime
import xml.etree.ElementTree as ET
from .viewMEFData import printMEF as PRINT
from .viewMEFData import processMEF as PROCESS
from primitives import primXML as PRIMXML
from primitives import primHTTP as HTTP
from primitives import primGeneric as GENERIC
from primitives import primGET as GET

# Define EDR events
global processUsageEvent
global options

options = {}

#===============================================================================
# A slick way to read a parameter within a section of a config file
def ConfigSectionMap(Config, section):
    dict1 = {}
    options = Config.options(section)
    for option in options:
        try:
            dict1[option] = Config.get(section, option)
            if dict1[option] == -1:
                DebugPrint("skip: %s" % option)
        except:
            print("exception on %s!" % option)
            dict1[option] = None
    #print 'dict1 = ' + str(dict1)
    return dict1

#===============================================================================
# This function reads the config file for the view parameters
def readConfigFile(options):
        dctRcv = {}

        # Get the directory where these files are stored
#        if options.dir: dir=options.dir
#        else:           dir=os.path.expandvars(os.getenv('TOOLS', '.'))
#        #print 'Using directory ' + dir + ' for config file reading'

        # Get config file to read
#        file = dir + '/config_' + os.getenv('customer', 'Training') + '.ini'
        #print 'reading config file: ' + file
	file = './config_Training.ini'

        # Read config file
        Config = configparser.ConfigParser()
        Config.read(file)

        # Get all config data (even if not all required by the command)
	# Define non-notification MEF items
        dctRcv['UsageEventName'] = ConfigSectionMap(Config, 'Event-Names')['usage']
        dctRcv['RecurringEventName'] = ConfigSectionMap(Config, 'Event-Names')['recurring']
        dctRcv['PurchaseEventName'] = ConfigSectionMap(Config, 'Event-Names')['purchase']
        dctRcv['CancelEventName'] = ConfigSectionMap(Config, 'Event-Names')['cancel']
        dctRcv['FirstuseEventName'] = ConfigSectionMap(Config, 'Event-Names')['firstuse']
		
	# Define notification MEF items
        dctRcv['DeviceStatusNotificationName'] = ConfigSectionMap(Config, 'Event-Names')['devicestatus']
        dctRcv['SubscriberStatusNotificationName'] = ConfigSectionMap(Config, 'Event-Names')['subscriberstatus']
        dctRcv['BalanceThresholdNotificationName'] = ConfigSectionMap(Config, 'Event-Names')['balancethreshold']
        dctRcv['BalanceCreateNotificationName'] = ConfigSectionMap(Config, 'Event-Names')['balancecreate']
        dctRcv['BalanceExpirationNotificationName'] = ConfigSectionMap(Config, 'Event-Names')['balanceexpiration']
        dctRcv['OfferPurchaseNotificationName'] = ConfigSectionMap(Config, 'Event-Names')['offerpurchase']
        dctRcv['OfferCancelNotificationName'] = ConfigSectionMap(Config, 'Event-Names')['offercancel']
        dctRcv['OfferExpirationNotificationName'] = ConfigSectionMap(Config, 'Event-Names')['offerexpiration']
        dctRcv['FirstUseChargeNotificationName'] = ConfigSectionMap(Config, 'Event-Names')['firstusecharge']
        dctRcv['RecurringChargeNotificationName'] = ConfigSectionMap(Config, 'Event-Names')['recurringcharge']
	
	# Get key data from config file
	dctRcv['hostname'] = ConfigSectionMap(Config, 'Server-Access')['hostname']
	dctRcv['hostport'] = ConfigSectionMap(Config, 'Server-Access')['hostport']

	return dctRcv
	
#===============================================================================
# This function processes usage events
def filterCheck(dctEvent, filterList, key):
	global options
	
	# See if filtering is on and we shouldn't print this
	found = None
	
	# Check external ID filtering
	if filterList and key in dctEvent:
		for item in filterList:
			if dctEvent[key].count(item):
				found = key
				break
		# If not found, then we failed the filter
		if not found: found = 'failed_' + key
	
	else: found = key
	
	return found
	
#===================== Check if any Filter applies ==========================================================
def filterApplyCheck(dctRcv):
	# Check various filters
	found = filterCheck(dctRcv, options.imsi, 'Imsi')
	if found.count('failed'): return False
	
	found = filterCheck(dctRcv, options.msisdn, 'Msisdn')
	if found.count('failed'): return False
	
	found = filterCheck(dctRcv, options.session, 'sessionId')
	if found.count('failed'): return False
			
	# Several external ID checks
	for extId in (('ObjectExternalId', 'InitiatorExternalId', 'WalletOwnerExternalId')):
		found = filterCheck(dctRcv, options.externalId, extId)
		if found.count('failed'): return False
			
	return True
	
#===============================================================================
# This function processes command line inputs
def commandInput(usage='VIEW'):
    ########### Do command line processing ###################
    parser = optparse.OptionParser()
    parser.add_option("-f", "--file",       action='append', help='File to process')
    parser.add_option("", "--dir",          action='append', help='directory to process')
    parser.add_option("-i", "--imsi",       action='append', help="IMSI to filter on")
    parser.add_option("-m", "--msisdn",     action='append', help="MSISDN to filter on")
    parser.add_option("-x", "--externalId", action='append', help='Object external ID to filter on')
    parser.add_option("-s", "--session",    action='append', help='Session to filter on')
    parser.add_option("",   "--config",     action='store', help='Config file', default='/opt/mtx/services/config/config_primitives.ini')
    parser.add_option("-c", "--currency",   action='store_true', default=False, help='Flag to signal only currency balances should be displayed')

    # Process command line params
    (options, args) = parser.parse_args()

    # Sanity check the data
    if not options.file and not options.dir:
	print('ERROR: need to input either a list of files or a list of directories')
	sys.exit('Early exit due to errors')
    
#    if options.imsi: print 'options.imsi = ' + str(options.imsi)
    
    return options,args

#================== Process MEF file XML  ================================================
def processMefXmlDict(q, configDct, customData, msgString = 'MtxEventRecordData'):
	global options
	
#	HTTP.printDictionaryLevel(configDct)
#	HTTP.printDictionaryLevel(customData)
	
	# Define events to always skip
	alwaysSkipList = ['MtxTxnIdData']
	
	# Process every record
	eventCount = recordCount = 0
	for record in q.findall(msgString):
		recordCount += 1
		
		# Process every list in the record
		for list in record:
			# Process every event in the list
			for event in list:
				# Get name (which is what we want)
				eventName = event.tag
				
				# See if we should skip
				if eventName in alwaysSkipList: continue
				
				# Valid event to process
				eventCount += 1
#				print 'Found event: ' + eventName
#				print str(customData[eventName])
				
				# Need to get the Mtx (base) name for this event.  If custom then map to base name.
				if eventName in customData['setOfStuffToCheckFor']: nameToUse = eventName
				else:
					# Get the base name from the custom name.
					# NOTE: for backwards compatibility, not all containers are in all releases.
					#	If we didn't find this structure, then skip it.
					try:
						nameToUse = customData[eventName]
					except:
						continue
				
#				print 'Base name for this event: ' + nameToUse
#				ET.dump(event)
				
				# Process the event
				dctRcv = PROCESS.processEvents(event)
				dctRcv['eventName'] = eventName
				dctRcv['baseName'] = nameToUse
					
				# Debug output
#				print 'Returned dictionary:\n'
#				HTTP.printDictionaryLevel(dctRcv)
				
                                # Skip if filtered out or data not defined
                                if not (filterApplyCheck(dctRcv) and dctRcv): continue
					
				# Print the data.  Each of the following are EDR major categories.
				# They won't change except for major releases, so hard-code here.
				# Not sure I could find this dynamically anyways...
				if   nameToUse.count('Notification'):		PRINT.printNotificationEvent(dctRcv, configDct, options)
				elif nameToUse.count('MtxBalanceTrackingData'):	PRINT.printBalanceTrackingEvent(dctRcv, configDct, options)
				else: 				    		PRINT.printEventEvent(dctRcv, configDct, options)
				
	return
			
def dummy():
		
		# Process each event type
		for eventType in (('Usage', 'Recurring', 'Purchase', 'Cancel')):
				# Bump event type counter
				cmd = eventType + 'EventCount = 0'
				exec(cmd)
				
				# Get the record string
				cmd = 'recordName = configDct[\'' + eventType + 'EventName\']'
				#print 'cmd = ' + cmd
				exec(cmd)
				
				# Process each type 
				for dataEvent in event.findall(recordName): 
					# Clear dictionary
					dctRcv = {}
					
					# Process the specific event type
					cmd = 'PROCESS.process' + eventType + 'Event(dataEvent, dctRcv)'
					#print 'cmd = ' + cmd
					exec(cmd)
				
					# Print if not filtered out and data is defined
					if filterApplyCheck(dctRcv) and dctRcv: 
						cmd = 'PRINT.print' + eventType + 'Event(dctRcv, configDct, options)'
						#print 'cmd = ' + cmd
						exec(cmd)
				
		# Process every notification in the record
		notificationCount = 0
		for event in record.findall('NotificationList'):
			notificationCount += 1
			
			# Process each event type
			for eventType in (('DeviceStatus', 'SubscriberStatus', 'BalanceThreshold', 'BalanceExpiration', 'OfferPurchase', 'OfferCancel', 'OfferExpiration', 'FirstUseCharge', 'RecurringCharge')):
				# Bump event type counter
				cmd = eventType + 'NotificationCount = 0'
				exec(cmd)
				
				# Get the record string
				cmd = 'recordName = configDct[\'' + eventType + 'NotificationName\']'
				#print 'cmd = ' + cmd
				exec(cmd)
				
				# Process each type 
				for dataEvent in event.findall(recordName): 
					# Clear dictionary
					dctRcv = {}
					
					# Process the specific event type.
					# NOTE:  As of today, notifications are generic in their structure.  Use a common processor.
					cmd = 'PROCESS.processGenericNotification(dataEvent, dctRcv)'
					#print 'cmd = ' + cmd
					exec(cmd)
				
					# Print if not filtered out and data is defined
					if filterApplyCheck(dctRcv) and dctRcv: 
						cmd = 'PRINT.print' + eventType + 'Notification(dctRcv, configDct, options)'
						#print 'cmd = ' + cmd
						exec(cmd)
				
		return
	
#================== Main function  ================================================
def main():
    global options
    
    # Define locals
    objDct = {}
    configDct = {}

    # Path is always the current directory
    path = os.getcwd()

    ########### Do command line processing ###################
    # Get command line data
    (options, args) = commandInput()

    # Init global data
    (customData, config) = GENERIC.initData(options.config)
#    print 'Config = ' + str(config)
    
    # If REST host and port were input, then set the values in the GET file
    if 'Rest' in config:
    	if  'hostname' in config['Rest']:
#		print '*** Setting GET host name to: ' + config['Rest']['hostname'] + ' ***'
		GET.RestHost = config['Rest']['hostname']
        if  'hostport' in config['Rest']:
#		print '*** Setting GET host port to ' + config['Rest']['hostport'] + ' ***'
		GET.RestPort = config['Rest']['hostport']
    
    # Start time for statistical reasons
    start_time = datetime.now()
    start_time_str = start_time.strftime('%d-%b-%YT%H-%M-%S')
    print('Starting operation at time: ' + start_time_str)
    
    fileToProcess = []
    
    # If file list specified, honor that
    if options.file: 
		# Code taken from a web query...
		fileToProcess = [(x,os.path.getmtime(x)) for x in options.file]
		fileToProcess.sort(key=lambda x: x[1])
		
    elif options.dir:
	# Want files in time sorted order...
	files = []
	
	# Go through each directory
	for dir in options.dir:
	        # Process all files in that directory.
	        # Include all lower level directories.
        	for dirName, subDirList, fileList in os.walk(dir):
			# Want full path file names
			for file in fileList: files.append(dirName + '/' + file)
		
	# Get files in time-sorted order.
	# Code taken from a web query...
	fileToProcess = [(x,os.path.getmtime(x)) for x in files]
	fileToProcess.sort(key=lambda x: x[1])
		
    # Debug output
    print('Processing files: ')
    for file in fileToProcess: print(file[0])

    # Process all input files
    for file in fileToProcess:
	# Pull out file name from tuple
	file = file[0]
	
	# If ends in known compressed formats, then uncompress
	#print 'file extension check: ' + file.split('.')[-1]
	if file.split('.')[-1] == 'gz': 
		# unzip the file
		GENERIC.runCmd('gunzip ' + file)
		
		# Remove trailing extension
		file = file[:-3]

	elif file.split('.')[-1] == 'xz': 
		# unzip the file
		GENERIC.runCmd('unxz ' + file)
		
		# Remove trailing extension
		file = file[:-3]
		
	# Sanity check that the file ends now in "mef"
	if file[-3:] != 'mef': 
		print('Encountered non-MEF-named file (' + file + ').  Skipping')
		continue
	
	# If a mef file (compressed or not), then run through conversion
#	if file.split('.')[-1] == 'gz' or file.split('.')[-1] == 'mef':
#		# Print out the file as XML.  
#		x=GENERIC.runCmd('print_data_container_file.py -qEf ' + file + ' > ' + newFile)
#	elif newFile != file:
#		# Copy file to local dir
#		x=GENERIC.runCmd('cp ' + file + ' ' + newFile)
	
	# Want it stored in local dir, NOT in dir the file may be in (e.g. the official MEF directory)
	newFile = file.split('/')[-1] + '_tmp'
	
	# OK; need to add a dummy heading, as the library expects one record per file...
	GENERIC.runCmd('cat /home/mtx/workspace/trunk/MTXQA/Tools/viewMEF/viewMEFData/pre ' + file + ' /home/mtx/workspace/trunk/MTXQA/Tools/viewMEF/viewMEFData/post > ' + newFile)
	
	# If newfile is not file, then we created an intermediate file.  Remove that here.
#	if newFile != file: x=GENERIC.runCmd('rm -f ' + newFile + ' >/dev/null 2>&1')
	
	# Debug Output
	print('\n*** Start File: ' + file + ' ***********\n')
	
	# Process XML based file
	q = PRIMXML.parseXmlResponse(newFile)
 
	# OK, now need to go find all the entries or each event type
	processMefXmlDict(q, config, customData)
	
	# Debug Output
	print('\n*** Stop File: ' + file + ' ***********\n')
	
    # Remove temp file
    GENERIC.runCmd('rm *_tmp >/dev/null 2>&1')
    
#================== Template  ================================================

if __name__ ==  '__main__':
    main()
