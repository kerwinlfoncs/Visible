from distutils.core import setup
setup(name='mtx-services-viewEventStore',
	version='4710.0',
	scripts=['viewEventStore.py'],
	description='MATRIXX Services Event Store Viewing Tool',
	author='Karl Freter',
	author_email='karl.freter@matrixxsw.com',
	url='www.matrixx.com',
      )

