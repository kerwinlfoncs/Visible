#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-11-12T00:06:21
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-11-12T00:06:20
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-11-12T00:06:19
# coding: latin-1

#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================
from __future__ import print_function
from __future__ import division
# from builtins import str
# from builtins import range
# from builtins import str
# from builtins import range
from past.utils import old_div
import sys, time, string, os, pprint, re, copy, json, subprocess, operator, string
import xml.etree.ElementTree as ET
from datetime import datetime
from optparse import OptionParser
from primitives import primXML as XML
from primitives import primGET as GET
from primitives import primGeneric as GENERIC
from primitives import engineRestPrim as ENGINE
from primitives import timeToMDCtime as MDCTIME
from primitives import primData as DATA
try: from prettytable import PrettyTable
except: pass

# Added primary/secondary FDs later
fdPrimary = None
fdSecondary = None

# Having issues pricing non-ASCII characters...
OnlyAscii = lambda s: re.match('^[\x00-\x7F]+$', s) != None

# Get time stamp
timeNow=datetime.now()
timeNow=timeNow.isoformat().split('.')[0].replace(':','-')

# Returned engine data
eventMapings = {}
dctRcvBal = {}
dctRcvClass = {}
dctRcvBalName = {}
dctRcvClassName = {}

# Populate update type .  Can't query these.
dctUpdateTypeIdToName = {}
dctUpdateTypeIdToName['1'] = 'Charge'
dctUpdateTypeIdToName['2'] = 'Discount'
dctUpdateTypeIdToName['3'] = 'Grant'
dctUpdateTypeIdToName['4'] = 'Adjustment'
dctUpdateTypeIdToName['5'] = 'Cancel Refund'
dctUpdateTypeIdToName['6'] = 'Cancel Forfeit'
dctUpdateTypeIdToName['7'] = 'Forfeit'
dctUpdateTypeIdToName['8'] = 'Usage Refund'
dctUpdateTypeIdToName['9'] = 'Transfer To'
dctUpdateTypeIdToName['10'] = 'Transfer From'
dctUpdateTypeIdToName['11'] = 'Rollover To'
dctUpdateTypeIdToName['12'] = 'Rollover From'
dctUpdateTypeIdToName['13'] = 'Payment'
dctUpdateTypeIdToName['14'] = 'Tax'
dctUpdateTypeIdToName['15'] = 'Cancel Tax Refund'
dctUpdateTypeIdToName['16'] = 'Usage Tax Refund'
dctUpdateTypeIdToName['17'] = 'Recharge'
dctUpdateTypeIdToName['18'] = 'Payment Refund'
dctUpdateTypeIdToName['19'] = 'Late Charge'
dctUpdateTypeIdToName['20'] = 'Early Termination Charge'
dctUpdateTypeIdToName['21'] = 'Write-Off'
dctUpdateTypeIdToName['22'] = 'Finance'
dctUpdateTypeIdToName['23'] = 'Debt Payment'

# Populate revenue recognition type .  Can't query these.
dctRevRecIdToName = {}
dctRevRecIdToName['1'] = 'Immediate'
dctRevRecIdToName['2'] = 'Specific Date'
dctRevRecIdToName['3'] = 'Time'
dctRevRecIdToName['4'] = 'Consumption'
dctRevRecIdToName['5'] = 'Deferred'

# Populate secondary event type map;pings
SecondaryEventTypeMapping = {}
SecondaryEventTypeMapping['1'] = 'Sponsor'
SecondaryEventTypeMapping['2'] = 'Wholesale'
SecondaryEventTypeMapping['3'] = 'Royalty'
SecondaryEventTypeMapping['4'] = 'Transfer'

# Object dictionaries
subDct = {}
groupDct = {}
userDct = {}
objDct = {}

# Set of records to output
overallRecords = []

# List of balance items (so one can sort easier)
bclassList = []
btemplateList= []
bamountList = []
bupdateTypeList = []
bstartTimeList = []
bownerList = []
notificationContent = {}
glInfoArray = {}
glPostingData = {}
    
# Default curl commands
curlCmd = 'curl -s '
curlQueryCmd = ''
curlEventStoreCmd = ''
curlEventStoreNotificationCmd = ''

# List of objects to report
objectsDev = []
objectsSub = []
objectsGroup = []
objectsUser = []

# Dictionaries to store event data
appliedCatalogItems = {}
appliedBundleItems = {}
appliedOfferItems = {}
balanceUpdateArray = {}
chargeListArray = {}
bundleInfoArray = {}
offerInfoArray = {}
usageArray = {}
sessions = {}

# Capture secondary event
secondaryEventList = []
processedSecondaryEventList = []

#==========================================================
# Define input
def commandInput():
    global curlCmd
    global curlQueryCmd
    global curlEventStoreCmd
    global curlEventStoreNotificationCmd
    
    # -----------------------------------------------------------------------------
    # Program Usage and Options
    # -----------------------------------------------------------------------------
    #define the options and parameter
    parser = OptionParser(usage="usage: %prog [options]", version="%prog 1.0")
    
    # Input/output file(s)
    parser.add_option("-f", "--inputFile", action='store', type='string', default=None, help='Input files process (comma separate multiple files)')
    parser.add_option("",   "--outputFile", action='store', type='string', default=None, help='Output file to write (defalts to VES + time stamp.txt)')
    
    # Misc
    parser.add_option("", "--scope", action='store', type='string', default='None', help='Process objects above or below the specified item.  Doesn\'t work with input file.')
    parser.add_option("", "--tz", action='store', type='string', default=None, help='Time zone to use')
    parser.add_option("", "--xtraDebug", action='store_true', default=False, help='report extra debug information')
    
    # Subscriber items
    parser.add_option("-s", "--subscriber", action='store', type='string', default='10', help='Subscriber external ID (defaults to 10)')
    parser.add_option("-o", "--soid", action='store', type='string', default=None, help="Subscriber's OID value")
    parser.add_option("-d", "--deviceId", action='store', type='string', default=None, help="One of the subscriber's device IMSI values")
    parser.add_option("-a", "--accessNumbers", action='store', type='string', default=None, help="One of the subscriber's device MSISDN values")
    parser.add_option("-i", "--imsi", action='store', type='string', default=None, help="Device IMSI value")
    parser.add_option("-m", "--msisdn", action='store', type='string', default=None, help="Device MSISDN value")
    parser.add_option("",   "--loginId", action='store', type='string', default=None, help="Device Login ID value")

    # Group items
    parser.add_option("-g", "--groupId", action='store', type='string', default=None, help="Group external ID")
    parser.add_option("", "--goid", action='store', type='string', default=None, help="Group OID value")
    
    # User items
    parser.add_option("", "--userId", action='store', type='string', default=None, help="User external ID")
    parser.add_option("", "--uoid", action='store', type='string', default=None, help="User OID value")
    
    # Subscription items
    parser.add_option("", "--subxid", action='store', type='string', default=None, help='Subscription external ID)')
    parser.add_option("", "--suboid", action='store', type='string', default=None, help="Subscription's OID value")
    
    # Response filtering items
    parser.add_option("-n", "--resultSize", action='store', type='string', default=None, help="Number of results to return")
    parser.add_option("-l", "--eventTimeLowerBound", action='store', type='string', default=None, help="Lower time bound")
    parser.add_option("-u", "--eventTimeUpperBound", action='store', type='string', default=None, help="Upper time bound")
    parser.add_option("-x", "--applyDefaultFilter", action='store_true', default=False, help="T/F default filter status (default false)")
    parser.add_option("", "--showNotificationContent", action='store_true', default=False, help="T/F show notification content in notification done event (default false)")
    parser.add_option("", "--hideNotificationDone", action='store_true', default=False, help="Hide notification done events (default false)")
    parser.add_option("", "--displayAllCharges", action='store_true', default=False, help="T/F show all charges when there's more than one impacting a balande (default false)")
    parser.add_option("-e", "--eventTypes", action='store', type='string', default=None, help="Event types to return (name or number).  Specify --showEventTypes to see the supported names.")
    parser.add_option("", "--onlySecondaryEvents", action='store_true', default=False, help="Only return secondary events")
    parser.add_option("", "--noSecondaryEvents", action='store_true', default=False, help="Omit secondary events")
    parser.add_option("", "--singleLine", action='store_true', default=False, help="Write each record as a single line (good for processing)")
    
    # Additional filtering based on returned data
#    parser.add_option("-c", "--catalogItem", action='store', type='string', default=None, help="Filter results based on Catalog Item name")
#    parser.add_option("",   "--catalogExternalId", action='store', type='string', default=None, help="Filter results based on Catalog Item name")
    parser.add_option("",   "--eventId", action='store', type='string', default=None, help="Filter results based on event ID")
    parser.add_option("-t", "--translate", action='store_true', default=False, help="Translate balance and GL information")
    parser.add_option("",   "--glTranslate", action='store_true', default=False, help="Translate only GL information")
    parser.add_option("",   "--dontSearchInMemoryDatabase", action='store_true', default=False, help="Limit search to ES only")
    parser.add_option("",   "--showBalanceStartTime", action='store_true', default=False, help="Add this from ouput (long and adds little)")
    parser.add_option("",   "--showBalanceBeforeAfter", action='store_true', default=False, help="Show balance before and after values")
    parser.add_option("",   "--showGl", action='store_true', default=False, help="Show Gl Info for each record")
    parser.add_option("",   "--showPosting", action='store_true', default=False, help="Show Gl Posting summary")
    parser.add_option("",   "--postingFile", action='store', type='string', default=None, help="GL posting file (applicable only if showPosting is true)")
    
    # Authentication and Security
    parser.add_option("",   "--httpAuthUsername", action='store', type='string', default=None, help="HTTP basic auth Username")
    parser.add_option("",   "--httpAuthPassword", action='store', type='string', default=None, help="HTTP basic auth Password")
    parser.add_option("",   "--ssl", action='store_true', default=False, help="Use SSL")
   
    # Display help
    parser.add_option("-r",   "--reverse", action='store_true', default=False, help="Display records from oldest to youngest")
    
    # Debug help
    parser.add_option("-z", "--showEventTypes", action='store_true', default=False, help="Show Event types that can be input")
    
    # Parse input
    (options, args) = parser.parse_args()
    
    # Sanity check the input.  Need MSISDN/IMSI numbers to be <= 15 characters
    for param in ['deviceId', 'accessNumbers', 'msisdn', 'imsi']:
        value = getattr(options, param)
        if value and len(value) > 15: sys.exit("ERROR: input parameter " + param + " is too long (> 15 characters): " + str(value))
    
    # If input files specified then can't show notification content
    if options.inputFile and options.showNotificationContent:
        print('Warning: can\'t show notification content when input files are supplied.  Disabling this option.')
        options.showNotificationContent = False
    
    # Add auth if defined - could be either locally defined or globall defined (local has priority)
    cmdStart = GENERIC.primGetCurlUrlStart(options)
    
    # Build remainder of strings used in this tool
    curlQueryCmd      = cmdStart + '/rsgateway/data/json/'
    curlEventStoreCmd = curlQueryCmd + 'eventstore/'
    curlEventStoreNotificationCmd = curlEventStoreCmd + 'notification/'

    # Return what was read
    return options, args
#==========================================================
def massageInputData(options):
    # See if we need to get the current time zone from the engine.
    # If not on an engine the command will return an empty string.
    if not options.tz:
        cmd = 'grep "^What is the system time zone" /opt/mtx/custom/create_config.info 2>/dev/null | cut -f2 -d"?"'
        options.tz = GENERIC.runCmd(cmd)
        if options.tz: print('Setting time zone based on /opt/mtx/custom/create_config.info to ' + options.tz)
        
        # Update primitive global used to store timezone (legacy code...)
        MDCTIME.systemTimeZone = options.tz
    
    # Get current time
    currentTime = MDCTIME.getTime()
    
    # Set global used by other primitives
    GET.commandTime = currentTime
    
    # Time parameters may use words like "today", "yesterday", etc.  Translate the time here.
    if options.eventTimeLowerBound:
        # Start with input
        offset = options.eventTimeLowerBound
        
        # See if anything special entered
        if   offset.lower() == 'today':     offset = 'next_0_day'
        elif offset.lower() == 'yesterday': offset = 'next_-1_day'
        elif offset.lower() == 'week':      offset = 'next_0_week'
        elif offset.lower() == 'month':     offset = 'next_0_month'
        elif offset.lower() == 'year':      offset = 'next_0_year'
        
        # Invoke time change 
        old = options.eventTimeLowerBound
        options.eventTimeLowerBound = MDCTIME.getCommandLineTime(None, offset, currentTime, ',')
        if options.eventTimeLowerBound != old: print('Updated options.eventTimeLowerBound from "' + old + '" to "' + options.eventTimeLowerBound + '"')
        
    if options.eventTimeUpperBound:
        # Start with input
        offset = options.eventTimeUpperBound
        
        # See if anything special entered
        if   offset.lower() == 'today':     offset = 'next_0_day'
        '''
        elif offset == 'yesterday': offset = 'next_1_day'
        elif offset == 'week':      offset = 'next_1_week'
        elif offset == 'month':     offset = 'next_1_month'
        '''
        
        # Invoke time change 
        old = options.eventTimeUpperBound
        options.eventTimeUpperBound = MDCTIME.getCommandLineTime(None, offset, currentTime, ',')
        if options.eventTimeUpperBound != old: print('Updated options.eventTimeUpperBound from "' + old + '" to "' + options.eventTimeUpperBound + '"')
        
#==========================================================
def showEvents(options):
    print()
    
    # Get key data
    eventMapings = ENGINE.getEventTypeMappings()
    
    # Make leading number 2 digits (so it works better for a numeric sort)
    for key in list(eventMapings.keys()):
        # Pad single digits to two digits.  Also add leading 0 to items that have children (e.g. x.y.z).
        if len(eventMapings[key]) == 1 or eventMapings[key].count('.'): eventMapings[key] = '0' + eventMapings[key]
        
        # Want undefined to come out first, so need to make non-zero or it will be blank (lstrip below)
        if eventMapings[key] == '00': eventMapings[key] = '(0)'
    
    # Want option to sort numerically.  Some values are 1.1.1 (so not a float).
    # Manipulate values so it comes out looking numerical.
    if options.reverse:
        # Sort on value
        eventMapings = sorted(list(eventMapings.items()), key=operator.itemgetter(1))
        
        # Build output table.
        # Use try/except in case people don't have PrettyTable package.
        try:
            t = PrettyTable(['ID', 'Name', 'ID ', 'Name '])
            t.align["ID"] = 'r'
            t.align["ID "] = 'r'
            t.align["Name"] = 'l'
            t.align["Name "] = 'l'
            halfway = old_div(len(eventMapings), 2)
            for i in range(halfway): t.add_row([eventMapings[i][1].lstrip('0'), eventMapings[i][0], eventMapings[i+halfway][1].lstrip('0'), eventMapings[i+halfway][0]])
            if len(eventMapings) % 2: t.add_row(['','', eventMapings[-1][1].lstrip('0'), eventMapings[-1][0]])
            print(t)
        except:
            print('NOTE: falling back to old output.  Please run "sudo pip install PrettyTable" to get the latest packages.')
            print("%6s: %s" % ("ID", "Name"))
            for item in eventMapings: print("%6s: %s" % (item[1].lstrip('0'), item[0]))
    else:
        # Build output table.
        # Sort on key
        eventMapings = sorted(list(eventMapings.items()), key=operator.itemgetter(0))
        
        # Use try/except in case people don't have PrettyTable package.
        try:
            # Build output table
            t = PrettyTable(['Name', 'ID', 'Name ', 'ID '])
            t.align["ID"] = 'r'
            t.align["ID "] = 'r'
            t.align["Name"] = 'l'
            t.align["Name "] = 'l'
            
            # Standard sort
            halfway = old_div(len(eventMapings), 2)
            for i in range(halfway): t.add_row([eventMapings[i][0], eventMapings[i][1].lstrip('0'), eventMapings[i+halfway][0], eventMapings[i+halfway][1].lstrip('0')])
            if len(eventMapings) % 2: t.add_row(['','', eventMapings[-1][0], eventMapings[-1][1].lstrip('0')])
            print(t)
        except:
            print('NOTE: falling back to old output.  Please run "sudo pip install PrettyTable" to get the latest packages.')
            print("%25s: %s" % ("Name", "ID"))
            for item in eventMapings: print("%25s: %s" % (item[0], item[1].lstrip('0')))
    
    print()
    
#==========================================================
def main():
    # Too many globals...  
    global fdPrimary
    global fdSecondary
    global eventMapings
    global dctRcvBal
    global dctRcvClass
    global dctRcvBalName
    global dctRcvClassName
    global objectsSub
    global objectsGroup
    global overallRecords
    global secondaryEventList
    global processedSecondaryEventList
    
    fd = None
    
    # Get input
    (options, args) = commandInput()
    
    # If requesting to see event, then do so and exit
    if options.showEventTypes:
        showEvents(options)
        return
    
    # Process/massage input data
    massageInputData(options)
    
    # Get event data.  Only do if querying for data.
    if not options.inputFile and options.eventTypes: eventMapings = ENGINE.getEventTypeMappings()
    
    # Get balance data if translation is desired
    if options.translate:
        (dctRcvBal, dctRcvClass, dctRcvBalName, dctRcvClassName) = ENGINE.getBalances()
        
        # Having issues with NON-ASCII pricing.  Fix here at the source
        for idx in list(dctRcvBalName.keys()):
            if not OnlyAscii(dctRcvBalName[idx]): dctRcvBalName[idx] = '(Non-ASCII characters)'
        for idx in list(dctRcvClassName.keys()):
            if not OnlyAscii(dctRcvClassName[idx]): dctRcvClassName[idx] = '(Non-ASCII characters)'
            
        #pprint.pprint(dctRcvClassName)
    
    # See if input files specified
    if options.inputFile:
        # Process all the files
        processInputFiles(options.inputFile, options)
    
        # Print data
        printResults(overallRecords, options)
        
        # Exit here
        return
    
    # Really want to build list of groups, from top-down, and then subscriber.  
    # If executed in this order then no object will ever be unknown.
    
    # Process subscriber inputs
    if options.soid:
        obj = 'Subscriber'
        search = 'ObjectId'
        value = options.soid
        objectsSub.append((obj, search, value))
    elif options.loginId:
        obj = 'Subscriber'
        search = 'LoginId'
        value = options.loginId
        objectsSub.append((obj, search, value))
    elif options.accessNumbers or options.msisdn:
        if options.accessNumbers:
            value = options.accessNumbers
        else:   value = options.msisdn
        obj = 'Subscriber'
        search = 'AccessNumber'
        objectsSub.append((obj, search, value))
    elif options.deviceId or options.imsi:
        if options.deviceId:
            value = options.deviceId
        else:   value = options.imsi
        obj = 'Subscriber'
        search = 'PhoneNumber'
        objectsSub.append((obj, search, value))
    
    # Process group inputs
    elif options.groupId:
        obj = 'Group'
        search = 'ExternalId'
        value = options.groupId
        objectsGroup.insert(0,(obj, search, value))
    elif options.goid:
        obj = 'Group'
        search = 'ObjectId'
        value = options.goid
        objectsGroup.insert(0,(obj, search, value))
    
    # Process user inputs
    elif options.userId:
        obj = 'User'
        search = 'ExternalId'
        value = options.userId
        objectsUser.insert(0,(obj, search, value))
    elif options.uoid:
        obj = 'User'
        search = 'ObjectId'
        value = options.uoid
        objectsUser.insert(0,(obj, search, value))
    
    # Process subscription inputs
    elif options.subxid:
        obj = 'Subscription'
        search = 'ExternalId'
        value = options.subxid
        objectsSub.append((obj, search, value))
    elif options.suboid:
        obj = 'Subscription'
        search = 'ObjectId'
        value = options.suboid
        objectsSub.append((obj, search, value))
    
    # Process default last
    elif options.subscriber:
        obj = 'Subscriber'
        search = 'ExternalId'
        value = options.subscriber
        objectsSub.append((obj, search, value))
    
    else:   sys.exit('Error: Need to specify an input file or some search criteria')
    
    # If scope is up, or group and scope is down, then build lists here
    if   options.scope.lower() == 'up': ENGINE.getParentOIDs(obj, search, options, value, objectsSub, objectsGroup, objectsDev, objectsUser)
    elif options.scope.lower() == 'down':   ENGINE.getChildOIDs(obj, search, options, value, objectsSub, objectsGroup, objectsDev, objectsUser)
    
    # Open file.  If name specified use it, else use the command invocation time.
    if options.outputFile:
        # See if extension is needed
        if not options.outputFile.count('.'):   fName = options.outputFile + ".txt"
        else:                   fName = options.outputFile
        
    else:   fName = 'VES_' + timeNow + '.txt'
    
    # Open the file(s)
    if options.singleLine:
        # Want two files
        fdPrimary = open(fName+'.primary', 'w')
        fdSecondary = open(fName+'.secondary', 'w')
    else:   fd = open(fName, 'w')
    
    # Loop through all elements; groups first.  No devices in this logic
    for element in objectsGroup + objectsSub + objectsUser: 
        # Split entry
        (obj, search, value) = element
        
        # Invoke element processing function
        processURLOptions(obj, search, options, value, fd)
        
        # Add secondary event iff defined and not blocked
        if len(secondaryEventList) and not options.noSecondaryEvents:
            # Debug
            print('Secondary event list:')
            pprint.pprint(secondaryEventList)
            
            # Process each record
            for event in set(secondaryEventList): processURLOptions(obj, search, options, event, fd, 'single', 'secondary')
            
            # Capture what's been processed
            processedSecondaryEventList.extend(secondaryEventList)
            
            # Clear secondary list
            secondaryEventList = []
        
        # If supposed to show notification content then get that here
        if options.showNotificationContent: processNotificationContent(obj, search, options, value, fd)
    
    # Close the file
    if options.singleLine:
        fdPrimary.close()
        fdSecondary.close()
    else:   fd.close()
    
    # Print data
    printResults(overallRecords, options)
    
    # Add space at the end
    if options.singleLine:
        print('\nSet of events displayed here are in local files: ' + fName + '.(primary/secondary)\n')
    else:   print('\nSet of events displayed here are in local file: ' + fName + '\n')
    
#==========================================================
def processNotificationContent(obj, search, options, value, fd):
    # Get notification data
    processURLOptions(obj, search, options, value, fd, 'notifications')
    
#==========================================================
def processURLOptions(obj, search, options, value, fd, items='event', eventType='primary'):
    global eventMapings
    
    # URL is pretty straight-forward
    if   items == 'event':      getCmd = curlEventStoreCmd + obj.lower() + '/' + search + '+' + value
    elif items == 'notifications':  getCmd = curlEventStoreNotificationCmd + obj.lower() + '/' + search + '+' + value
    else:               getCmd = curlEventStoreCmd + 'query/EventId/' + value
    
    # Add options
    delim = '?'
    for param in ['resultSize', 'eventTypes', 'eventTimeLowerBound', 'eventTimeUpperBound', 'applyDefaultFilter']:
        paramValue = getattr(options, param)
        
        # Need to do event type mappings if input
        if param == 'eventTypes' and paramValue:
            # Build string
            outstr = ''
            
            # This parameter can be a comma separated list
            for paramItem in paramValue.split(','):
                # Translate if found, else use as-is
                try:
                    # Want to reference any "cust_" values here.  See if they exist.
                    if "cust_"+paramItem in eventMapings:
                        outstr += eventMapings["cust_"+paramItem]
                    else:   outstr += eventMapings[paramItem]
                    
                    # Add parameter seperator
                    outstr += ','
                except: outstr += paramItem + ','
            
            # Take all but trailing comma
            paramValue = outstr[:-1]
        
        # Need to convert time
        if param in ['eventTimeLowerBound', 'eventTimeUpperBound'] and paramValue: paramValue = ENGINE.convertTimeToUrlFormat(paramValue)
        
        # Want false for T/F options to be sent
        if param == 'applyDefaultFilter': paramValue = str(paramValue).lower()
        
        # See if parameter is set
        if paramValue:
            # Add parameter to the URL
            getCmd += delim + param + '=' + str(paramValue)
            
            # Delimiter always changes to amersand
            delim = '\&'
    
    # Check if we should not search OCS in-memory DB
    if items == 'event':
        if options.dontSearchInMemoryDatabase: getCmd += delim + "searchInMemoryDatabase=false"
    
    # Run the command
    print('Command: ' + getCmd) 
    response = GENERIC.runCmd(getCmd)
    
    # Translate response to a single line if requested
    if options.singleLine:
        # Go to a single line
        response = response.replace("\n", " ")
        
        # Don't want lines that have no event list
        if not response.count('EventList'): return
    
    # Record data 
    if eventType == 'primary':
        # Don't record command if only doing secondary
        if not options.singleLine:
            fd.write('\nCommand: ' + getCmd + '\n')
            fd.write(response + '\n')
        else:   fdPrimary.write(response + '\n')
    else:
        # Only write command if looking at everything.
        if not options.singleLine:
            fd.write('\nCommand: ' + getCmd + '\n')
            fd.write(response + '\n')
        else:   fdSecondary.write(response + '\n')
    
    #print 'Response: "' + response + '"'
    
    # Different actions depending on event vs notifications
    if items != 'notifications':
        # Invoke generic string processing function
        overallRecords.extend(processEventResponse(response, options, obj, eventType))
        return
    else:   return processNotificationResponse(response, options, obj)
    
#==========================================================
def processInputFiles(files, options):
    global overallRecords
    
    # Process each file
    print('\n\n')
    for inFile in files.split(','):
        print('Processing file: ' + inFile)
        
        # Read the file
        response = open(inFile).read().strip()
        '''
        print lclRead
        print '\n\n'
        '''
        
        # Invoke generic string processing function
        overallRecords.extend(processEventResponse(response, options, 'obj'))

#==========================================================
def processNotificationResponse(response, options, obj):
    global notificationContent
    
        # Import to Python dictionary
    j = json.loads(response)
    
        # Debug output
    #print json.dumps(j, sort_keys=True, indent=4, separators=(',', ': '))
    
        # Check if anything returned
    kewWord = "NotificationList"
    event = []
    if kewWord not in j:
        print('NOTE: No event queried from the DB')
        return
    
    # Process each event
    for event in j[kewWord]: 
        # Store notification content in event ID index.  Not all event have content.
        try: notificationContent[event["EventId"]] = event["NotificationContent"]
        except: pass

#==========================================================
def processEventResponse(response, options, obj, eventType='primary'):
    global eventMapings
    global dctRcvBal
    global dctRcvClass
    global dctRcvBalName
    global dctRcvClassName
    global subDct
    global groupDct
    global userDct
    global objDct
    global bclassList
    global btemplateLis
    global bamountList
    global bupdateTypeList
    global bstartTimeList
    global bownerList
    global secondaryEventList
    global processedSecondaryEventList
    
    space = ' '
    records = []
    
    # Remove leading cmment lines (tool output file adds lines; want this tool to be able to read it's own utput)
    response = response.split('\n')
    while not response[0].startswith('{'): del response[0]
    response = '\n'.join(response)

    # Import to Python dictionary
    j = json.loads(response)
    
    # Debug output
    #print json.dumps(j, sort_keys=True, indent=4, separators=(',', ': '))
    
    # Check if anything returned
    event = []
    if "EventList" not in j:
        print('NOTE: No event queried from the DB')
        print(j)
        return records

    '''
    # Get event IDs
    for event in j["EventList"]: event.append((event["EventId"]))
    
    # Process each event
    for eventId in event:
    print 'eventId: ' + str(eventId)
    '''
    
    for event in j["EventList"]:
        # Want to process device events as well as subscription event store requests.
        try: event = event["EventDetails"]
        except: pass
        
        '''
        print 'Event:'
        pprint.pprint(event)
        print "\n"
        '''
        
        # *** If any inputs then see abut filtering ***
        
        # Get event time
        #pprint.pprint(event)
        eventTime = event["EventTime"]
        
        # Put everything into local time so it sorts easily
        if eventTime[-1] == 'Z':
            #print 'Time before call to MDCTIME.convertTimeZones: ' + str(eventTime)
            eventTime = MDCTIME.convertTimeZones(eventTime[:-1], 'UTC', options.tz)
            
            # Add in colon seperator
            eventTime = eventTime[:-2] + ':' + eventTime[-2:]
            #print 'Time after  call to MDCTIME.convertTimeZones: ' + str(eventTime)
            
        # Get time without usec but with timezone
        eventTime = eventTime.split('.')
        if len(eventTime) > 1:  eventTime = eventTime[0] + eventTime[1][6:]
        else:           eventTime = eventTime[0]
        #print 'Time being used: ' + str(eventTime)
        
        # If lower and/or upper time input, then filter here
        # This should already have been done by the input command...
        if options.eventTimeLowerBound and GENERIC.checkIfTime2GreaterTime1(eventTime, options.eventTimeLowerBound): continue
        if options.eventTimeUpperBound and GENERIC.checkIfTime2GreaterTime1(options.eventTimeUpperBound, eventTime): continue
        
        # Get all event IDs
        eventId = event["EventId"]
        
        # Add single primary event ID (if present)
        try: eventId += '/' + event["PrimaryEventId"] + '(P)'
        except: pass
        
        # Add associate event (list or individual item, if present)
        try:
            for item in event["AssociatedEventIdList"]: eventId += '/' + item + '(A)'
        except: 
            try:    eventId += '/' + event["AssociatedEventId"] + '(A)'
            except: pass

        # Add secondary event list (if present)
        try:
            for item in event['SecondaryEventIdList']:
                eventId += '/' + item  + '(S)'
                
                # Save secondary event (need to query separately) only if not already processed.
                if item not in processedSecondaryEventList: secondaryEventList.append(item)
        except: pass
        
        # Check for event ID filter
        if options.eventId and not eventId.count(options.eventId): continue
        
        # Check if secondary only wanted
        if eventType == 'primary' and options.onlySecondaryEvents: continue
        
        # Get name
        eventName = event['$']
        
        # KEF: Should have a mapping between event input names or numbers and returned event names.  Then can filter here. TBD...
        # Reject if notification done
        if eventName.count('NotificationDone') and options.hideNotificationDone: continue
        
        '''
        # Build start of string
        outstr = ''
        
        # Get balance data
        if "BalanceUpdateArray" in event:
            seperatorChar = ''
            for balance in event["BalanceUpdateArray"]:
                outstr += seperatorChar + str(balance['BalanceClassId']) + ' ' + str(balance['BalanceTemplateId']) + ' ' + str(balance['Amount']) + ' ' + str(balance['BalanceStartTime'])
                seperatorChar = ' | '
        '''
        
        # Object is stored in the event for secondary event (so overwrite what's passed in)
        if eventName.count('SecondaryEvent'):
            try:    obj = event["WalletOwnerType"].strip('"')
            except: obj = '2'
        
        # Get ID of event owner
        try:    ownerId = event['WalletOwnerId']
        except: ownerId = event['InitiatorId']
        '''
        try:    ownerExternalId = event['WalletOwnerExternalId']
        except: ownerExternalId = event['InitiatorExternalId']
        '''
    
        # Set new object indices
        if   obj.lower().count('subscri'):
            if ownerId not in subDct:   subDct[ownerId] = str(len(subDct))
        elif obj.lower() == 'group':
                if  ownerId not in groupDct:    groupDct[ownerId] = str(len(groupDct))
        elif obj.lower() == 'user':
            if  ownerId not in userDct: userDct[ownerId] = str(len(userDct))
        elif ownerId not in objDct:     objDct[ownerId] = str(len(objDct))
        
        # Per event key item data
        (keyItem, outstr, retIndex, eventName) = getEventKeyData(event, options, obj, ownerId)
        
        # If both returned parameters are none, then skip
        if keyItem == None and outstr == None: continue
        
        # Append record
        records.append((eventTime, eventId, eventName, keyItem, outstr, retIndex))
        
    return records
    
#==========================================================
def getIDs(event, obj, ownerId):
    keyItem = ''
    '''
    # Now add who the change is for.  If device ID present then it's the device
    if "InitiatorDeviceId" in event:
        keyItem += ' ' + event["InitiatorDeviceId"]
        if "InitiatorDeviceExternalId" in event: keyItem += '/' + event["InitiatorDeviceExternalId"]
        keyItem += ' (D)'
    '''
    
    # Get event name
    eventName = event['$']
    
    # What to use for the index depends on event type
    if not eventName.count('SecondaryEvent'):
        try:    ownerId = event["InitiatorId"]
        except: ownerId = 'Unknown'
    else:
        try:    
            ownerId = event["WalletOwnerId"]
            obj = event["WalletOwnerType"].strip('"')
        except: ownerId = 'Unknown'
    
    # Account for subscriber and subscription strings
    if   obj.lower().count('subscri') and ownerId in subDct:  keyItem += ' (S' + subDct[ownerId] + ')'
    elif obj.lower() == 'group'       and ownerId in groupDct:keyItem += ' (G' + groupDct[ownerId] + ')'
    elif obj.lower() == 'user'        and ownerId in userDct: keyItem += ' (U' + userDct[ownerId] + ')'
    elif                     ownerId in objDct:   keyItem += ' (O' + objDct[ownerId] + ')'
    else:                             keyItem += ' (Unknown Owner)'
        
    '''
    keyItem += ' ' + event["InitiatorId"]
        if "InitiatorExternalId" in event: keyItem += '/' + event["InitiatorExternalId"]
    '''
    
    return keyItem
        
#==========================================================
def getEventKeyData(event, options, obj, ownerId):
    global appliedCatalogItems
    global appliedBundleItems
    global appliedOfferItems
    global balanceUpdateArray
    global chargeListArray
    global bundleInfoArray
    global offerInfoArray
    global usageArray
    global sessions
    global glInfoArray
    global glPostingData
    global SecondaryEventTypeMapping
    
    outstr = []
    
    # Dictionaries are kept aligned, so can use any to get the next index.
    retIndex = len(list(appliedCatalogItems.keys()))
        
    # Get event name
    eventName = event['$']
    #pprint.pprint(event)
    
    # Get event IDs
    eventName += getIDs(event, obj, ownerId)
        
    # Get owner iff not secondary event
    if (not eventName.count('SecondaryEvent')) and 'WalletOwnerId' in event:
        ownerId = event['WalletOwnerId']
    
    # Map owner to 
    if   ownerId in subDct:     bowner = '(S' + subDct[ownerId] + ')'
    elif ownerId in groupDct:   bowner = '(G' + groupDct[ownerId] + ')'
    elif ownerId in userDct:    bowner = '(U' + userDct[ownerId] + ')'
    elif ownerId in objDct:     bowner = '(O' + objDct[ownerId] + ')'
    else:
                    print('getEventKeyData - map owner code: unknown owner ID (' + str(ownerId) + ') for obj ' + str(obj))
                    bowner = '(G?)'
        
    # Build key item information
    keyItem = ''
    
    # Reason and Info are always key items
    if "Reason" in event:   keyItem += event["Reason"]
    if "Info"   in event:
        if keyItem: keyItem += '|' 
        keyItem += event["Info"]
    if keyItem: keyItem += '|' 
    
    # Set usage flag
    eventNameLower = eventName.lower()
    if eventNameLower.count('voiceevent') or eventNameLower.count('textevent') or eventNameLower.count('mmsevent'):
        # Add A and B party values
        try:    keyItem += 'Calling Station: ' + event['CallingStationId'] + ', Called Station: ' + event['CalledStationId'] + '|'
        except: pass
    # Certain messages have important data
    if eventName.count('StatusChangeEvent'):
        # Key data is status before/after items
        # Different status messages use different key names...
        if  "StatusDescriptionBefore" in event:
            descBefore = str(event["StatusDescriptionBefore"])
        elif    "DescriptionBefore" in event:
            descBefore = str(event["DescriptionBefore"])
        else: descBefore = "N/A"
        
        if  "DescriptionAfter" in event:
            descAfter = str(event["DescriptionAfter"])
        elif    "StatusDescriptionAfter" in event:
            descAfter = str(event["StatusDescriptionAfter"])
        else: descAfter = "N/A"
        
        if  "StatusBefore" in event:
            statusBefore = str(event["StatusBefore"])
        elif    "StatusValueBefore" in event:
            statusBefore = str(event["StatusValueBefore"])
        else:   statusBefore = "N/A"
        
        if  "StatusAfter" in event:
            statusAfter = str(event["StatusAfter"])
        elif    "StatusValueAfter" in event:
            statusAfter = str(event["StatusValueAfter"])
        else:   statusAfter = "N/A"
        
        # Make a list   
        if keyItem: keyItem = [((keyItem))]
        else:       keyItem = []
    
        keyItem.append(('Before: ' + descBefore + '(' + statusBefore + ')'))
        keyItem.append(('After:  ' + descAfter  + '(' + statusAfter  + ')'))
        
        # Add indication if API initiated or not
        try:
            if str(event["IsSysInit"]).lower() == 'true':
                keyItem.append(('NOT initiated by API'))
            else:
                keyItem.append(('Initiated by API'))
        except: keyItem.append(('No indication if initiated by API or not'))
    
    elif eventName.count('PolicyChangeEvent'):
        # Make a list   
        if keyItem: keyItem = [((keyItem))]
        else:       keyItem = []
    
        # Key data is policy 
        #pprint.pprint(event)
        for entry in event['PolicyProfileInfoArray']:
            keyItem.append((entry["ProfileName"]))  
        
    elif eventName.count('PeriodEndTimeChangeEvent'):
                # Make a list
                if keyItem: keyItem = [((keyItem))]
                else:       keyItem = []

                # Key data is policy
                #pprint.pprint(event)
                try:
                        keyItem.append((event["PeriodEndTimeBefore"] + '(B)'))
                        keyItem.append((event["PeriodEndTimeAfter"]  + '(A)'))
                except: pass

                # Get balance if present
                balanceUpdateArray[retIndex] = []
                try:
                        # Store data
                        bclass = 'UNK'
                        btemplate = str(event["CycleBalanceTemplateId"])
                        bamount = ''
                        bstartTime = event["PeriodStartTime"]
                        bowner = 'N/A'
                        bupdateType = 'N/A'

                        # Translate names if requested
                        if bclass in dctRcvClassName and options.translate: bclass = dctRcvClassName[bclass] + '(' + bclass + ')'
                        if btemplate in dctRcvBalName and options.translate: btemplate = dctRcvBalName[btemplate] + '(' + btemplate + ')'
                        balanceUpdateArray[retIndex].append((bclass, btemplate, event["CycleBalanceResourceId"], bstartTime, bamount))

                        # Store in tuple
                        outstr.append((bclass, btemplate, bamount, bupdateType, bstartTime, bowner))

                        # Store in other arrays so we can auto-format (as I can't figure out how to sort based on a tuple item...)
                        bclassList.append((bclass))
                        btemplateList.append(btemplate)
                        bamountList.append(bamount)
                        bupdateTypeList.append(bupdateType)
                        bstartTimeList.append(bstartTime)
                        bownerList.append(bowner)

                except: pass

    elif eventName.count('PurchasedItemModifyEvent'):
        # key data is either under the Bundle attr or the offer attr
        # *** Data that changed here is always under offer.
        arrayName = "Offer"
        
        # Get to the modified list
        entry = event[arrayName+'InfoArray'][0]
        #pprint.pprint(entry)
        
        # Make a list   
        if keyItem: keyItem = [((keyItem))]
        else:       keyItem = []
    
        # Want start and end times if provided
        try:
            keyItem.append(('Start time: ' + entry['StartTime']))
            keyItem.append(('End   time: ' + entry['EndTime']))
        except: pass
    
    elif eventName.count('PeriodCloseEvent'):
        # Make ID the key items
        keyItem += event["TemplateName"] + '(' + str(event["TemplateId"]) + ') Amount = ' + str(event["Amount"])
        
    elif eventName.count('ModifyEvent'):
        # Make ID the key items
        keyItem += event["InitiatorId"]
        
        # Add second one iff different
        if "InitiatorExternalId" in event and event["InitiatorExternalId"] != event["InitiatorId"]:
            keyItem += '/' + event["InitiatorExternalId"]
        
        # Put modified data in the outstr (same as for modified offers)
        found = True
        for objType in ['User', 'Device', 'Subscription', 'Group']:
            if eventName.count(objType): break
        else:
            print('NOTE: did not process modify details for event ' + eventName)
            found = False
        
        # Get modified contents if object type supported
        if found:
            # Process every field
            for field in list(event[objType+'InfoModified'].keys()):
                # Skip if dollar sign
                if field == '$': continue
                
                if field == 'Attr':
                    entry = event[objType+'InfoModified'][field]
                    for key in list(entry.keys()):
                        # Skip if dollar sign
                        if key == '$': continue
                        
                        # Store in tuple - use balances as keyItem will be prioritized below CI data
                        try:
                            outstr.append(('', '', key, str(entry[key]), '', ''))
                            fieldValue = str(entry[key])
                        except:
                            fieldValue = 'Non-ASCII'
                            outstr.append(('', '', key, fieldValue, '', ''))
                        
                        # Store in other arrays so we can auto-format (as I can't figure out how to sort based on a tuple item...)
                        bupdateTypeList.append(fieldValue)
                        bamountList.append(key)
                else:
                        # Get field value (easier to understand)
                        fieldValue = str(event[objType+'InfoModified'][field])
                        
                        # Store in tuple - use balances as keyItem will be prioritized below CI data
                        outstr.append(('', '', field, fieldValue, '', ''))
                        
                        # Store in other arrays so we can auto-format (as I can't figure out how to sort based on a tuple item...)
                        bupdateTypeList.append(fieldValue)
                        bamountList.append(field)
                    
    elif eventName.count('NotificationDoneEvent'):
        # Key data is notification info
        keyItem += event["NotificationType"] + '|' + event["NotificationStatus"] + '|' + event["NotificationId"]
        
    elif eventName.count('SessionEndEvent') or eventName.count('SessionContextEndEvent'):
        # Key data 
        keyItem += event["SessionId"]
        
    elif eventName.count('CreateEvent') or eventName.count('DeleteEvent'):
        keyItem += event["InitiatorId"]
        
        # add second one iff different
        if "InitiatorExternalId" in event and event["InitiatorExternalId"] != event["InitiatorId"]:
            keyItem += '/' + event["InitiatorExternalId"]
        
    elif eventName.count('SubscriberAddDeviceEvent'):
        # Key data 
        #pprint.pprint(event)
        if "DeviceId" in event:
         if   "Imsi"    in event["DeviceAttr"]: keyItem += str(event["DeviceId"]) + '|' + str(event["DeviceAttr"]["Imsi"]) + '|'
         elif "LoginId" in event["DeviceAttr"]: keyItem += str(event["DeviceId"]) + '|' + str(event["DeviceAttr"]["LoginId"]) + '|'
         try : keyItem += str(event["DeviceAttr"]["AccessNumberArray"])
         except : pass
        
    elif eventName.count('BalanceAdjustEvent') or eventName.count('Recharge'):
        # Make a list   
        if keyItem: keyItem = [((keyItem))]
        else:       keyItem = []
    
        # Key data.  Multiple ways to get here (private balance internal adjustment or adjust API call) and different data per type.
        for entry in ["BalanceStateUpdateArray", "BalanceUpdateArray"]:
            if entry in event:
                # Changing the start doesn't result in an "old start".  Check for end date (mostly what's done) and fall back to start adjust. 
                if "OldBalanceEndTime" in event[entry][0]:
                    keyItem.append(('End time:   ' + event[entry][0]["OldBalanceEndTime"]+'(Old)')) 
                    keyItem.append(('End time:   ' + event[entry][0]["BalanceEndTime"]+'(New)'))
                else:
                    keyItem.append(('Start time: ' + event[entry][0]["BalanceStartTime"]+'(New)'))
                    keyItem.append(('End time:   ' + event[entry][0]["BalanceEndTime"]+'(New)'))
                
                # Only report one or the other
                break
            
    elif eventName.count('BalanceTopupEvent'):
        # Key data 
        try:
            keyItem += str(event["Voucher"])
        except: keyItem += "(None)"
    elif eventName.count('MembershipEvent'):
        # Array of subscribers and/or groups
        #pprint.pprint(event)
        for strToChck in ["SubscriberArray", "SubGroupArray"]:
            if strToChck in event:
                for obj in event[strToChck]:
                    keyItem += strToChck[:-5] + ':' + obj["ObjectId"]
                    try: keyItem += '(' + obj["ExternalId"] + '), '
                    except: keyItem += ', '
        
        # Remove trailing characters
        keyItem = keyItem [:-2]
        
    elif eventName.count('BalanceRolloverEvent'): keyItem += '(' + str(event["TriggerBalanceResourceId"]) + '/' + str(event["TriggerBalanceIntervalId"]) + ')'
    
    elif eventName.count('SecondaryEvent'): keyItem += 'Secondary Event - ' + SecondaryEventTypeMapping[str(event['SecondaryEventType'])]
    
    elif eventName.count('BillingCycleChangeEvent'):
        # Trial and error
        try: keyItem += 'Old ID: ' + str(event["BillingCycleIdBefore"]) + ', '
        except: pass
        try: keyItem += 'New ID: ' + str(event["BillingCycleIdAfter"]) + ', '
        except: pass
        try: keyItem += 'New Cycle Offset: ' + str(event["CycleOffsetAfter"]) + ','
        except: pass
        try: keyItem += 'Cycle End time: ' + str(event["NextCycleEndTime"])
        except: pass
    
    # Save indentation...
    if True:    
        # Capture key item data from event that also have other data we want.
        # Gather data that's present
        appliedCatalogItems[retIndex] = []
        
        # Check for contract stuff (reported different from other event)
        if "CycleCatalogItemExternalId" in event:
            extId = event["CycleCatalogItemExternalId"]
            try:    iD = event["CycleCatalogItemId"]
            except: iD = ""
            try:    resId = event["CyclePurchasedItemResourceId"]
            except: resId = ""
            appliedCatalogItems[retIndex].append((extId, iD, resId))
        else:
         key = "AppliedCatalogItemArray"
         if key in event:
            for item in event[key]:
                extId = None
                for elem in ["CatalogItemExternalId", "CycleCatalogItemExternalId"]:
                    if elem in item:
                        extId = item[elem]
                        break
                if not extId: extId = ""
                
                iD = None
                for elem in ["CatalogItemId", "CycleCatalogItemId"]: 
                    if elem in item:
                        iD = item[elem]
                        break
                if not iD: iD = ""
                
                resId = None
                for elem in ["CatalogItemResourceId", "CyclePurchasedItemResourceId"]: 
                    if elem in item:
                        resId = item[elem]
                        break
                if not resId: resId = ""
                
                '''
                # If CI filter input then check if matching here.
                # NOTE: Not sue this works anymore with updated logic...
                if (options.catalogItem       and options.catalogItem       == iD)    or \
                   (options.catalogExternalId and options.catalogExternalId == extId):
                '''
                appliedCatalogItems[retIndex].append((extId, iD, resId))
            
        appliedBundleItems[retIndex] = []
        key = "AppliedBundleArray"
        if key in event:
            for item in event[key]:
                if   "BundleItemExternalId"  in item:   extId = item["BundleItemExternalId"]
                elif "BundleExternalId"  in item:   extId = item["BundleExternalId"]
                else:                       extId = None
                if "BundleResourceId"  in item:     resId = item["BundleResourceId"]
                else:                   resId = None
                if "AppliedCatalogItemIndex"  in item:  ciId = item["AppliedCatalogItemIndex"]
                else:                       ciId = None
                appliedBundleItems[retIndex].append((extId, item["BundleId"], resId, ciId))
        else: appliedBundleItems[retIndex].append((None, None, None, None))
        #print 'Added the following to appliedBundleItems[' + str(retIndex) + ']: ' + str(appliedBundleItems[retIndex])
            
        bundleInfoArray[retIndex] = []
        key = "BundleInfoArray"
        if key in event:
            for item in event[key]:
                if "BundleResourceId" in item:      resId = item["BundleResourceId"]
                if "ResourceId" in item:        resId = item["ResourceId"]
                else:                   resId = None
                if "BundleId" in item:          bundleId = item["BundleId"]
                else:                   bundleId = None
                if "CatalogItemExternalId" in item: ciExtId = item["CatalogItemExternalId"]
                else:                       ciExtId = None
                if "PreActiveState" in item:        preAct = item["PreActiveState"]
                else:                       preAct = None
                if "ExternalId" in item:        bundleExtId = item["ExternalId"]
                else:                   bundleExtId = None
                bundleInfoArray[retIndex].append((ciExtId, item["CatalogItemId"], bundleId, resId, preAct, bundleExtId))
        else: bundleInfoArray[retIndex].append((None, None, None, None, None, None))
        #print 'Added the following to bundleInfoArray[' + str(retIndex) + ']: ' + str(bundleInfoArray[retIndex])
            
        offerInfoArray[retIndex] = []
        key = "OfferInfoArray"
        if key in event:
            for item in event[key]:
                # Might be an offer and a CI.  Check offer.
                if "ResourceId" in item:    resId = item["ResourceId"]
                else:               resId = None
                if "OfferId" in item:       Id = item["OfferId"]
                else:               Id = None
                if "ExternalId" in item:    extId = item["ExternalId"]
                else:               extId = None
                offerInfoArray[retIndex].append((extId, Id, resId))
                
                # Check CI
                if "CatalogItemExternalId" in item:
                    Id = item["CatalogItemId"]
                    extId = item["CatalogItemExternalId"]
                    resId = item["ResourceId"]
                    appliedCatalogItems[retIndex].append((extId, Id, resId))
                    
        else: offerInfoArray[retIndex].append((None, None, None))
        #print 'Added the following to offerInfoArray[' + str(retIndex) + ']: ' + str(offerInfoArray[retIndex])
            
        appliedOfferItems[retIndex] = []
        key = "AppliedOfferArray"
        if key in event:
            for item in event[key]:
                # Offer may reference a CI or a bundle
                if "AppliedCatalogItemIndex" in item: ciRef = item["AppliedCatalogItemIndex"]
                else:                     ciRef = ""
                if "AppliedBundleIndex"      in item: bundleRef = item["AppliedBundleIndex"]
                else:                     bundleRef = ""
                if "ProductOfferExternalId"  in item: extId = item["ProductOfferExternalId"]
                else:                     extId = None
                if "ProductOfferResourceId"  in item: resId = item["ProductOfferResourceId"]
                else:                     resId = None
                appliedOfferItems[retIndex].append((extId, item["ProductOfferId"], resId, bundleRef, ciRef))
        else: appliedOfferItems[retIndex].append((None, None, None, None, None))
        #print 'Added the following to appliedOfferItems[' + str(retIndex) + ']: ' + str(appliedOfferItems[retIndex])
            
        chargeListArray[retIndex] = []
        key = "ChargeList"
        if key in event:
            for item in event[key]:
                try:    offerIdx = item["AppliedOfferIndex"]
                except: offerIdx = None
                chargeListArray[retIndex].append((item["BalanceUpdateIndex"], offerIdx, str(item["Amount"]), str(item["UpdateType"])))
        else:   chargeListArray[retIndex].append(( None, None, None, None))
            
        balanceUpdateArray[retIndex] = []
        key = "BalanceUpdateArray"
        if key in event:
            for item in event[key]:
                bclass = str(item["BalanceClassId"])
                if bclass in dctRcvClassName and options.translate: bclass = dctRcvClassName[bclass] + '(' + bclass + ')'
                btemplate = str(item["BalanceTemplateId"])
                if btemplate in dctRcvBalName and options.translate: btemplate = dctRcvBalName[btemplate] + '(' + btemplate + ')'
                
                btemplate += '('
                try: btemplate += str(item["BalanceResourceId"])
                except: pass
                try: btemplate += '/' + str(item["BalanceIntervalId"])
                except: pass
                btemplate += ')'
                
                amount = str(item["Amount"])
                #amount += ' (' + str(item["GrossAmountBefore"]) + '/' + str(item["GrossAmountAfter"]) + ')'
                
                # Add gross amounts if present
                try: amount += ' (' + str(item["GrossAmountBefore"]) + '/' + str(item["GrossAmountAfter"]) + ')'
                except: pass
                amount = amount.rstrip('0').rstrip('.')
                #print 'Amount = ' + amount + ', GrossAmountBefore/GrossAmountAfter = ' + str(item["GrossAmountBefore"]) + '/' + str(item["GrossAmountAfter"])
                
                # Get start time
                bstartTime = item["BalanceStartTime"]
                
                # Store data
                balanceUpdateArray[retIndex].append((bclass, btemplate, item["BalanceResourceId"], bstartTime, amount))
                
                # If we have a charge list, then process below
                if chargeListArray[retIndex][0][0] != None: continue
                
        # Process charge list to generate per-balance impacts
        for item in chargeListArray[retIndex]:
            # If balance impact defined, then don't store anything here
            if "BalanceImpactList" in event: continue
            
            #print 'Charge List item: ' + str(item)
            
            # Update type for secondary event is in charge list.  Try to get from there.
            (balanceIndex, offerIdx, amount, bupdateType) = item
            
            # If we have a None entry, then skip
            if balanceIndex == None: continue
            
            # Convert update type to name
            try: bupdateType = DATA.UpdateTypeMapping[bupdateType] + '(' + bupdateType + ')'
            except: pass
            
            # Do owner ID work.  Owner is in different field in secondary event.
            try:
                #ownerId = event['WalletOwnerId']
                if   ownerId in subDct:     bowner = '(S' + subDct[ownerId] + ')'
                elif ownerId in groupDct:   bowner = '(G' + groupDct[ownerId] + ')'
                elif ownerId in userDct:    bowner = '(U' + userDct[ownerId] + ')'
                elif ownerId in objDct:     bowner = '(O' + objDct[ownerId] + ')'
                else:               
                                print('getEventKeyData - BalanceUpdateArray code: unknown owner ID (' + str(ownerId) + ') for obj ' + str(obj))
                                bowner = '(G?)'
            except: bowner = 'NA'
            
            # Point to balance
            balanceItem = balanceUpdateArray[retIndex][balanceIndex]
            #print 'Balance item: ' + str(balanceItem)
            (bclass, btemplate, balanceResourceId, bstartTime, _x) = balanceItem
            
            # Store data
            #print 'Storing: ' + str((bclass, btemplate, amount, bupdateType, bstartTime, bowner))
            outstr.append((bclass, btemplate, amount, bupdateType, bstartTime, bowner))
            
            # Store in other arrays so we can auto-format (as I can't figure out how to sort based on a tuple item...)
            bclassList.append((bclass))
            btemplateList.append(btemplate)
            bamountList.append(amount)
            bupdateTypeList.append(bupdateType)
            bstartTimeList.append(bstartTime)
            bownerList.append(bowner)
        
        key = "MeterUpdateArray"
        if key in event:
            for item in event[key]:
                bclass = 'Meter (0)'
                btemplate = str(item["TemplateId"])
                if btemplate in dctRcvBalName and options.translate: btemplate = dctRcvBalName[btemplate] + '(' + btemplate + ')'
                bresourceId = "?"
                bamount = str(item["Amount"]).rstrip('0').rstrip('.')
                bstartTime = ""
                bupdateType = ""
                balanceUpdateArray[retIndex].append((bclass, btemplate, bresourceId, bstartTime, bamount))
        
        # Ensure there's at least one entry in the array
        if ("BalanceUpdateArray" not in event) and ("MeterUpdateArray" not in event): balanceUpdateArray[retIndex].append((None, None, None, None, None))
            
        glInfoArray[retIndex] = []
        key = "GlInfoArray"
        if (options.showGl or options.showPosting) and key in event:
            #pprint.pprint(event[key])
            for item in event[key]:
                #pprint.pprint(item)
                try:
                        txnType = item['TxnType']
                        account1 = item['Account1']
                        account2 = item['Account2']
                        if txnType not in glPostingData: glPostingData[txnType] = {}
                        if account1 not in glPostingData[txnType]: glPostingData[txnType][account1] = {}
                        if account2 not in glPostingData[txnType][account1]: glPostingData[txnType][account1][account2] = 0
                        glPostingData[txnType][account1][account2] += float(item['Amount'])
                        glInfoArray[retIndex].append((account1, account2, txnType,     item['Amount'], item["RevenueRecognitionType"], item['UpdateType']))

                except: glInfoArray[retIndex].append(('NoAct1', 'NoAct2', 'NoTxnType', item['Amount'], item["RevenueRecognitionType"], 'NoUpdType'))
        
        usageArray[retIndex] = []
        sessionStr = None
        key = "UsageQuantityList"
        if key in event:
            # Session ID not always returned...
            sessionIdStr = "SessionId"
            if sessionIdStr in event:
                usageArray[retIndex].append((event[sessionIdStr]))
                sessionStr = sessionIdStr
            sessionIdStr = "sessionId"
            if sessionIdStr in event:
                usageArray[retIndex].append((event[sessionIdStr]))
                sessionStr = sessionIdStr
            
            # Process each key
            if   'RatingGroup'   in event:  ratingGroup = event['RatingGroup']
            elif 'RatingGroupId' in event:  ratingGroup = event['RatingGroupId']
            else:               ratingGroup = 'UNK'
            for item in event[key]:
                # Never sure what's reported...
                if "MsgAmount" in item:    msgAmount = item["MsgAmount"]
                else:              continue
                if "QuantityUnit" in item: quantityUnit = item["QuantityUnit"]
                else:              quantityUnit = None
                if "RatingAmount" in item: ratingAmount = item["RatingAmount"]
                else:              continue
                
                # Store in global
                usageArray[retIndex].append(str(ratingGroup) + '/' + (str(msgAmount).rstrip('0').rstrip('.') + '/' + str(ratingAmount).rstrip('0').rstrip('.') + '/' + str(quantityUnit)))
                
                # Add to event name (why not...)
                #eventName += ' (' + str(msgAmount) + '/' + str(ratingAmount) + '/' + str(quantityUnit) + ')'
        else: usageArray[retIndex].append((""))
            
        # Store session ID information if defined
        sessions[retIndex] = []
        if sessionStr:
            # Build session string
            sessionIdStr = str(event[sessionStr]) + '/'
            if "ccRequestNumber" in event:
                sessionIdStr += str(event["ccRequestNumber"]) + '/'
                if "ccRequestType" in event:
                    sessionIdStr += DATA.diameterRequestTypeMapping[str(event["ccRequestType"])] + '(' + str(event["ccRequestType"]) + ')'
                else:   sessionIdStr += 'No Type'
            
            # Store session string
            sessions[retIndex].append((sessionIdStr))
        
        # Store balance impact list.  
        # If no balance, then it's a group event and we want the balance impact list
        if "BalanceImpactList" in event:
            for balance in event["BalanceImpactList"]:
                # Get data
                bclass = str(balance["BalanceClassId"])
                if bclass in dctRcvClassName and options.translate: bclass = dctRcvClassName[bclass] + '(' + bclass + ')'
                btemplate = str(balance["BalanceTemplateId"])
                if btemplate in dctRcvBalName and options.translate: btemplate = dctRcvBalName[btemplate] + '(' + btemplate + ')'
                
                btemplate += '('
                try: btemplate += str(balance["BalanceResourceId"])
                except: pass
                try: btemplate += '/' + str(balance["BalanceIntervalId"])
                except: pass
                btemplate += ')'
                
                bamount = str(balance["ImpactAmount"]).rstrip('0').rstrip('.')
                
                # Capture all impacts
                #pprint.pprint(balance)
                if "BalanceImpactOfferList" in balance:
                 if len(balance["BalanceImpactOfferList"][0]['BalanceImpactUpdateList']) > 1:
                  # If options say to display them all, then do so, else show "mixed"
                  if options.displayAllCharges:
                    bupdateType = '[' 
                    for offer in balance["BalanceImpactOfferList"][0]['BalanceImpactUpdateList']:
                        bupdateType  += str(offer['Amount']) + '/' 
                        bupdateType2 =  str(offer["UpdateType"])
                        try:    bupdateType += DATA.UpdateTypeMapping[bupdateType2] + '(' + bupdateType2 + '), '
                        except: bupdateType += ', '
                    bupdateType = bupdateType[:-2] + ']' 
                  else: bupdateType = 'mixed'
                 else:  bupdateType = str(balance["BalanceImpactOfferList"][0]["BalanceImpactUpdateList"][0]["UpdateType"])
                else: bupdateType = ''
                
                # Convert update type to name
                if bupdateType in DATA.UpdateTypeMapping: bupdateType = DATA.UpdateTypeMapping[bupdateType] + '(' + bupdateType + ')'
                
                # Remove usec from here if it exists
                bstartTime = str(balance["BalanceStartTime"])
                if len(balance["BalanceStartTime"].split('.')) > 1:
                    bstartTime = balance["BalanceStartTime"].split('.')[0] + balance["BalanceStartTime"].split('.')[1][6:]
                
                # Add UTC time for common reference
                #bstartTime += '(' + MDCTIME.getUTCTime(bstartTime) + ')'
                
                # Do owner ID work
                #ownerId = balance['BalanceOwnerId']
                if   ownerId in subDct:     bowner = '(S' + subDct[ownerId] + ')'
                elif ownerId in groupDct:   bowner = '(G' + groupDct[ownerId] + ')'
                elif ownerId in userDct:    bowner = '(U' + userDct[ownerId] + ')'
                elif ownerId in objDct:     bowner = '(O' + objDct[ownerId] + ')'
                else:
                                    print('getEventKeyData - BalanceImpactList code: unknown owner ID (' + str(ownerId) + ') for obj ' + str(obj))
                                    bowner = '(G?)'
                
                # Address non-ASCII issues
                if not OnlyAscii(bclass):   bclass = '(Non-ASCII characters)'
                if not OnlyAscii(btemplate):    btemplate = '(Non-ASCII characters)'
                
                # Store in tuple
                outstr.append((bclass, btemplate, bamount, bupdateType, bstartTime, bowner))
                
                # Store in other arrays so we can auto-format (as I can't figure out how to sort based on a tuple item...)
                bclassList.append((bclass))
                btemplateList.append(btemplate)
                bamountList.append(bamount)
                bupdateTypeList.append(bupdateType)
                bstartTimeList.append(bstartTime)
                bownerList.append(bowner)
        
        # Also process meters
        if "MeterUpdateArray" in event:
            for balance in event["MeterUpdateArray"]:
                # Get data
                bclass = 'Meter(0)'
                btemplate = str(balance["TemplateId"])
                try:
                    if btemplate in dctRcvBalName and options.translate: btemplate = dctRcvBalName[btemplate] + '(' + btemplate + ')'
                except: pass
                
                # Amount always present
                bamount = str(balance["Amount"])
            
                # Store in tuple
                outstr.append((bclass, btemplate, bamount, "", "", ""))
            
        # Add blank entry if nothing in impacted
        if ("BalanceImpactList" not in event) and ("MeterUpdateArray" not in event): outstr.append(('', '', '', '', '', ''))    
    
    # CI could have been filled in multiple places.  If nothing populated then add dummy entry
    if not len(appliedCatalogItems[retIndex]): appliedCatalogItems[retIndex].append((None, None, None))
    
    # If no key data and a suspend/resume event, then get data from the offer.
    '''
    if not keyItem and eventName.count('ResumeEvent') or eventName.count('SuspendEvent'):
        # Key data is offer ID
        keyItem = str(event["OfferInfoArray"][0]["OfferId"])
        try:
            keyItem += '(' + str(event["OfferInfoArray"][0]["ExternalIdId"]) + ')'
        except: pass
        keyItem += '(' + str(event["OfferInfoArray"][0]["ResourceId"]) + '/' + str(event["OfferInfoArray"][0]["OfferVersion"]) + ')'
    '''
        
    # Clean up trailing characters in fields and set to a list.
    try:    keyItem = keyItem.rstrip('|').split('|')
    except: pass
    
    # Return data
    return keyItem, outstr, retIndex, eventName

#==========================================================
def processPosting(options):
        global glPostingData

        print("\nProcessing GL posting data\n")

        # Each TXN type
        for txnType in glPostingData:
            # Each from account
            for account1 in glPostingData[txnType]:
                 # Each to account
                 for account2 in glPostingData[txnType][account1]:
                         # Amount is the sum of all TxnTypes for these from/to accounts
                         amount = glPostingData[txnType][account1][account2]

                         # See if we should compare to a file
                         if options.postingFile:
                             # Get data from posting file
                             cmd = 'egrep "Account1|Account2|TxnType|Amount" ' + options.postingFile + ' | grep -A1 -B2 ' + str(txnType)
                             results = GENERIC.runCmd(cmd).split('\n')

                             # Compare data
                             glAccount1 = results[0].split('>')[1].split('<')[0]
                             if glAccount1 != str(account1): print('txnType ' + str(txnType) + ' Account1 mismatch: Posting/MEF: ' + str(glAccount1) + '/' + str(account1))

                             glAccount2 = results[1].split('>')[1].split('<')[0]
                             if glAccount2 != str(account2): print('txnType ' + str(txnType) + ' Account2 mismatch: Posting/MEF: ' + str(glAccount2) + '/' + str(account2))

                             glAmount = results[3].split('>')[1].split('<')[0]
                             if abs(float(glAmount) - float(amount)) > 0.001: print('txnType ' + str(txnType) + ' Amount mismatch: Posting/MEF: ' + str(glAmount) + '/' + str(amount))
                         else:
                             # Report to standard out
                             print('          <Account1>' + str(account1) + '</Account1>')
                             print('          <Account2>' + str(account2) + '</Account2>')
                             print('          <TxnType>'  + str(txnType)  + '</TxnType>')
                             print('          <Amount>'   + str(amount)   + '</Amount>')
                             print('--')

#==========================================================
def printResults(records, options):
    # Lots of globals...
    global appliedCatalogItems
    global appliedBundleItems
    global appliedOfferItems
    global balanceUpdateArray
    global chargeListArray
    global bundleInfoArray
    global usageArray
    global bclassList
    global btemplateLis
    global bamountList
    global bupdateTypeList
    global bstartTimeList
    global bownerList
    global notificationContent
    global glInfoArray
    
    # If showing GL posting data, then process here.
    if options.showPosting:
            processPosting(options)
            return

    # Debug for specific message types
    debugFlag = options.xtraDebug
    
    # Print objects in question:
    # Readability
    print('\n')
    
    # Subscriber has longest name, so just print as-is
    for item in sorted(subDct): print('Subscriber ' + item + ' is index (S' + subDct[item] + ')')
    
    # Really trivial point, but set the padding so everything lines up
    if   len(subDct): name = 'Group      '
    elif len(objDct): name = 'Group  '
    else:         name = 'Group '
    for item in sorted(groupDct):   print(name + item + ' is index (G' + groupDct[item] + ')')
    
    # Same trivial point, but set the padding so everything lines up
    if   len(userDct): name = 'User:      '
    else:          name = 'User:  '
    for item in sorted(userDct):    print(name + item + ' is index (U' + userDct[item] + ')')
    
    # Same trivial point, but set the padding so everything lines up
    if   len(subDct): name = 'Object     '
    else:         name = 'Object '
    for item in sorted(objDct): print(name + item + ' is index (O' + objDct[item] + ')')
    
    # Readability
    print('\n')
    
    # If nothing found, then exit
    if not len(records):
        print('No records found')
        return
    
    # Debug
    #pprint.pprint(records)
    
    # Get indentation for key information (may span several lines)
    keyInfoIndent = len(max((L[0] for L in records), key=len)) + len(max((L[1] for L in records), key=len)) + len(max((L[2] for L in records), key=len))
    
    # Records with a key index may have multiple entries to print
    KeyInfoArray = {}
    for record in records:
        # Split into entries
        (eventTime, eventId, eventName, catalogItem, balances, keyIndex) = record
        
        # If no keyIndex, then nothing special to do
        if keyIndex == None: continue
        
        # Initalize key info array
        KeyInfoArray[keyIndex] = []
        
        # Set bundle print flag
        if  eventName.count('DataEvent')  or \
            eventName.count('VoiceEvent') or \
            eventName.count('TextEvent')  or \
            eventName.count('MmsEvent')   or \
            eventName.count('VasEvent')   or \
            eventName.count('TerminationEvent')   or \
            eventName.count('RecurringEvent'):
            bundlePrintFlag = False
        else:   bundlePrintFlag = True
        
        # Populate with CI, Bundle, Offer data
        for i in range(max(len(appliedCatalogItems[keyIndex]),len(appliedBundleItems),len(appliedOfferItems), len(bundleInfoArray[keyIndex]), len(offerInfoArray[keyIndex]))):
            # Clear entry string
            string = ""
            
            # Process CIs and bundles as single entry
            if len(appliedCatalogItems[keyIndex]) > i:
                # Split for readability
                (extId, iD, resId) = appliedCatalogItems[keyIndex][i]
                
                # Build output str
                if iD != None:
                    if extId:  string += str(extId)
                    string += '(C' + str(iD)
                    if resId: string += '/' + str(resId)
                    string += ')'
            
            # Add entry
            if string:
                # Add entry, then create new entry
                KeyInfoArray[keyIndex].append((string))
                string = ""
                addedCi = True
            else:   addedCi = False
            
            # Process Bundles.  Skip for usage.
            # NOTE: Info is everything touched.  Applied is everything that caused a balance impact.  Focus on all touched.
            if len(bundleInfoArray[keyIndex]) > i:
                                # Some event with no balance impacts don't have item arrays
                                # Split for readability
                                (ciExtId, ciId, bundleId, resId, preActiveState, bundleExtId) = bundleInfoArray[keyIndex][i]
            else:   bundleId = None
            
            # Build output str if bundle ID specified
            if bundleId != None:
                # If no CI, then add here
                if (not addedCi) and ciId:
                    if ciExtId: string += str(ciExtId)
                    string += '(C' + str(ciId)
                    
                    if resId: string += '/' + str(resId)
                    string += ')'
                
                    # Add entry, then create new entry
                    KeyInfoArray[keyIndex].append((string))
                    string = ""
                
                # Add bundle data
                #if extId: string += extId
                if bundleExtId: string += bundleExtId
                string += '(B' + str(bundleId)
                string += ')'
            elif len(appliedBundleItems[keyIndex]) > i:
                # Split for readability
                (extId, bundleId, resId, ciId) = appliedBundleItems[keyIndex][i]
                
            # Build output str
            if bundleId != None:
                    # Record Bundle. CI will be present if taking applied bundle.
                    string += '(B' + str(bundleId)
                    if resId: string += '/' + str(resId)
                    string += ')'
                    
            # Add entry iff not usage
            if string and bundlePrintFlag:
                # Add entry, then create new entry
                KeyInfoArray[keyIndex].append((string))
                string = ""
            
            # Process Offers (each as a separate entry)
            string = ''
            if len(offerInfoArray[keyIndex]) > i:
                # Split for readability
                (extId, productOfferId, resId) = offerInfoArray[keyIndex][i]
            else:   productOfferId = None
                
            # Build output str if offer ID specified
            if productOfferId != None:
                if extId: string += str(extId)
                string += '(O' + str(productOfferId)
                if resId: string +=  '/' + str(resId)
                string += ')'
            elif len(appliedOfferItems[keyIndex]) > i:
                # Split for readability
                (extId, productOfferId, resId, bundleRef, ciRef) = appliedOfferItems[keyIndex][i]
                
                # Build output str
                if productOfferId != None:
                    if extId: string += str(extId) 
                    string += '(O' + str(productOfferId)
                    if resId: string += '/' + str(resId)
                    string += ')'
            
            # Add output string to key Info
            if string: KeyInfoArray[keyIndex].append((string))
        
    # Get length of each field for output formatting
    outFormat = ''
    
    eventTimeLen = len(max((L[0] for L in records), key=len))
    outFormat += '%-' + str(eventTimeLen) + 's '
    
    eventIdLen = 25
    outFormat += '%-' + str(eventIdLen) + 's '
    
    # Will add usage to event name array, so accont for it's size here
    eventNameLen = len(max((L[2] for L in records), key=len))
    if len(usageArray): eventNameLen = max(eventNameLen, len(max((str(L) for K in usageArray for L in usageArray[K]), key=len)))
    outFormat += '%-' + str(eventNameLen) + 's '
    
    # Set key information length to fixed length
    keyInformationLen = 55
    outFormat += '%-' + str(keyInformationLen) + 's '
    
    # Last item is a tuple, which evidently one can't iterate over.  Thus we created separate lists for each item.
    # NOTE: if no event has a balance impact, then need to default stuff here.
    if not len(bclassList):
        bclassList.append(('     '))
        btemplateList.append(('     '))
        bamountList.append(('     '))
        bupdateTypeList.append(('     '))
        bstartTimeList.append(('     '))
        bownerList.append(('     '))
    
    # Build format using largest of the field values, accounting for headings (fix values in max command)
    bclassListLen = max(len(max((L for L in bclassList), key=len)),8)
    outFormat += '%-' + str(bclassListLen) + 's '
    
    # Template may be in two lists
    btemplateListLen = max(len(max((L for L in btemplateList), key=len)),5)
    '''
    balTemplateLen = len(max((str(M[1]) if M[1] else '1' for L in balanceUpdateArray for M in balanceUpdateArray[L]), key=len))
    btemplateListLen = max(btemplateListLen, balTemplateLen)
    '''
    outFormat += '%-' + str(btemplateListLen) + 's '
    
    # Amount may involve two pieces of data
    bamountListLen = max(len(max((L for L in bamountList), key=len)),6)
    if options.showBalanceBeforeAfter:
        balAmountLen = len(max((str(M[-1]) if M[-1] else '1' for L in balanceUpdateArray for M in balanceUpdateArray[L]), key=len))
        bamountListLen = max(bamountListLen, balAmountLen)
    # Cap this, as some can include lots of charges
    if bamountListLen > 20: bamountListLen = 20
    outFormat += '%-' + str(bamountListLen) + 's '
    
    try:    bupdateTypeListLen = max(len(max((str(L) for L in bupdateTypeList), key=len)),2)
    except: bupdateTypeListLen = 35
    outFormat += '%-' + str(bupdateTypeListLen) + 's '
    
    if options.showBalanceStartTime:
        bstartTimeListLen = len(max((L for L in bstartTimeList), key=len))
        bstartString = 'Balance Start Time'
    else:
        bstartTimeListLen = 0
        bstartString = ''
    outFormat += '%-' + str(bstartTimeListLen) + 's '
    
    bownerLen = max(len(max((L for L in bownerList), key=len)),5)
    outFormat += '%-' + str(bownerLen) + 's '
    
    # Last field is always just -s
    if options.showGl:
        glInfoLen = ['50', '50', '3', '9', '2', '2']
        glString = ['GL: From', 'To', 'Txn', 'Amount', 'RT', 'UT']
        outFormat += '%-' + glInfoLen[0] + 's %-' + glInfoLen[1] + 's %-' + glInfoLen[2] + 's %' + glInfoLen[3] + 's %-' + glInfoLen[4] + 's %' + glInfoLen[5] + 's'
    else:
        glInfoLen = [0, 0, 0, 0, 0, 0]
        glString = ['', '', '', '', '', '']
        outFormat += '%-1s %-1s %-1s %-1s %-1s %-1s'
    
    # Always add newline
    outFormat += '\n'
    #print 'format = ' + outFormat
    
    # Print headers
    sys.stdout.write(outFormat % \
                (\
                    'Event Time',  \
                    'Event Ids',  \
                    'Event Name',  \
            'Key Information',  \
                    'Class', \
            'ID', \
            'Amount', \
            'UT', \
            bstartString, \
            'Owner', \
            glString[0],
            glString[1],
            glString[2],
            glString[3],
            glString[4],
            glString[5],
            ))
    
    # Print separater line
    sys.stdout.write(outFormat % \
                (\
                    '-'*eventTimeLen,  \
                    '-'*eventIdLen,  \
                    '-'*eventNameLen, \
                    '-'*keyInformationLen,  \
                    '-'*bclassListLen, \
                    '-'*btemplateListLen, \
                    '-'*bamountListLen, \
                    '-'*bupdateTypeListLen, \
                    '-'*bstartTimeListLen, \
                    '-'*bownerLen, \
            '-'*int(glInfoLen[0]), \
            '-'*int(glInfoLen[1]), \
            '-'*int(glInfoLen[2]), \
            '-'*int(glInfoLen[3]), \
            '-'*int(glInfoLen[4]), \
            '-'*int(glInfoLen[5]), \
            ))
    
    keyInfoFieldLength = 50
    
    # Sort records based on event time and then ID
    records.sort(key = operator.itemgetter(0, 1))
    if options.reverse: records.reverse()
    
    #pprint.pprint(balanceUpdateArray)
    
    # Print each record
    for record in records:
        if debugFlag: print("\n\nNewRecord")
        
        # Split into entries
        (eventTime, eventId, eventName, keyInformationRecord, balances, keyIndex) = record
        
        # Add event name to usageArray so we report both in the same column
        if keyIndex != None:
            # These arrays all have a dummy entry.  If this one is empty then remove it.
            if usageArray[keyIndex][0] == '': del usageArray[keyIndex][0]
            
            # Add to front of list
            usageArray[keyIndex].insert(0,eventName)
            usageLen = len(usageArray[keyIndex])
        else:   usageLen = 0
        
        # If not balances impacted (e.g. create event), then set to empty record
        if balances == None:
            balances = []
            balances.append(('', '', '', '', '', ''))
        
        # Minor(?) Hack:  Session ID is quite long.  Causing stuff to exceed line width.  So put as a separate key iem.
        if keyIndex != None and len(sessions[keyIndex]):
            # Add to key index
            KeyInfoArray[keyIndex].insert(0,sessions[keyIndex][0])
        
        # Minor(?) Hack:  May have multiple entries for key information.  Split as needed
        if keyIndex != None and type(keyInformationRecord) == type(list()):
            # Add to key index
            for i in range(len(keyInformationRecord)): KeyInfoArray[keyIndex].append(keyInformationRecord[i])
        
        # Split event IDs (better for output)
        eventIds = eventId.split('/')
        
        # Process items with arrays
        if keyIndex != None:    keyLen = len(KeyInfoArray[keyIndex])
        else:           keyLen = 0
        for i in range(max(len(balances), len(eventIds), len(glInfoArray[keyIndex]), usageLen, keyLen, 1)):
            # See if there are balances here
            if len(balances) > i:
                # Split the balance list
                (bclass, btemplate, bamount, bupdateType, bstartTime, bowner) = balances[i]
                
                # Need to get the amount from a different array
                '''
                if len(balanceUpdateArray) > keyIndex and len(balanceUpdateArray[keyIndex]) > i:
                    if str(balanceUpdateArray[keyIndex][i][-1]).lower() != "none": bamount = balanceUpdateArray[keyIndex][i][-1]
                '''
                
                # Debug for specific message types
                if debugFlag == True:
                    print('Balance: ')
                    pprint.pprint(balances[i])
            else:
                # Clear the entries
                bclass = btemplate = bamount = bupdateType = bstartTime = bowner = ''       
            
            # Clear optional fields that are not requested
            if not options.showBalanceStartTime: bstartTime = ''
            
            # Get GL Info.  Convert to list so it can be manipulated below.
            try:    glInfo = list(glInfoArray[keyIndex][i])
            except: glInfo = ['', '', '', '', '', '']
                
            # Translate if desired
            if (options.translate or options.glTranslate) and glInfo[0] != '' and len(glInfo) > 3:
              try:
                '''
                print 'glInfo:' 
                pprint.pprint(glInfo)
                '''
                
                glInfo[0] += ' (Debit)'
                glInfo[1] += ' (Credit)'
                
                val = str(glInfo[4])
                glInfo[4] = dctRevRecIdToName[val] + '(' + val + ')'
                
                val = str(glInfo[5])
                glInfo[5] = dctUpdateTypeIdToName[val] + '(' + val + ')'
              except: pass
                
            # Convert GL info to a string
            #glInfo = str(glInfo)
            
            if debugFlag == True: print('GlInfo: ' + str(glInfo))
            
            # See if key information is present
            if keyLen and len(KeyInfoArray[keyIndex]) > i:
                keyInformation = KeyInfoArray[keyIndex][i]
                if debugFlag == True:
                    print('KeyInfoArray: ')
                    pprint.pprint(KeyInfoArray[keyIndex][i])
            else:   keyInformation = keyInformationRecord
            
            # Get event ID
            if len(eventIds) > i:
                eventId = eventIds[i]
                if debugFlag == True:
                    print('eventId: ')
                    pprint.pprint(eventIds[i])
            else:   eventId = ''
            
            # Get event name column value
            if keyIndex == None and i == 0:
                eventName = eventName
            elif len(usageArray[keyIndex]) > i:
                eventName = usageArray[keyIndex][i]
                if debugFlag == True:
                    print('usageArray: ')
                    pprint.pprint(usageArray[keyIndex][i])
            else:   eventName = ''
            
            # Output event
            sys.stdout.write(outFormat % \
                            (\
                                eventTime,  \
                                eventId,  \
                                eventName,  \
                    keyInformation,  \
                    bclass,  \
                    btemplate,  \
                    bamount,  \
                    bupdateType,  \
                    bstartTime, \
                    bowner, \
                    glInfo[0], \
                    glInfo[1], \
                    glInfo[2], \
                    glInfo[3], \
                    glInfo[4], \
                    glInfo[5], \
                    ))
            
            # Clear non-array data for subsequent loops
            eventTime = keyInformationRecord = ''
    
        # If processing an notification and the user wants the notification content, do that here
        if eventName.count('NotificationDoneEvent') and options.showNotificationContent:
            print('*'*70 + '\n')
            try:
                print(notificationContent[eventId])
            except: print('WARNING: event ID ' + eventId + ' did not have notification content defined')
            print('*'*70 + '\n')
        
if __name__ ==  '__main__':
    main()

#=====================================================================================================
#
# Copyright 2011,2012,2013,2014,2015,2016,2017,2018,2019 Matrixx Software, Inc. All rights reserved.
#
#=====================================================================================================

