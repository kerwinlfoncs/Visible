#!/bin/bash

#Prerequisites: mtx user needs to have privilege to /bin/su
# Argument = -n vernumber -s suitename -p optional path for amq
## script usage help
usage()
{
cat << EOF
usage: $0 options

This script allows to install rpm and start the test suite with version number and test suite name provided 
also allow activemq, active connector ,notifier , notifier client to be  started on hp2-bld04 only 
note, the -m option allows active connector to be configured for notification as 2 phase management mode

OPTIONS:
   -h      Show this message
   -n      required arguement, rpm version number, eg. 4600-989 
   -s      optional argument suite name, eg. base, vtime, rest, notification..., default is null  
   -p      optional path for amq, default is  /opt/ActiveMQ
   -m      optional arguement for activemq connector, ack queue mode, 1 is 2 phase management notification, 
           0 is to turn off 2 phase management. default value is 1
   -b      blade host name to start activemq, connector , notifier , default is mtx-hp2-bld04.dc1.matrixxsw.com. 
EOF
}

suite=""
verNum=""
bhost="mtx-hp2-bld04.dc1.matrixxsw.com"
path="/opt/ActiveMQ"
mode=1

while getopts ":n:s:p:m:b:" OPTION;
do
     case $OPTION in
         n)
             verNum=$OPTARG
             echo install rpm version $verNum
             ;;
         s) 
             suite=$OPTARG
             echo running suite $suite
             ;;
         p)
             path=$OPTARG
             echo activemq installed path $path
             ;;
         m)
             mode=$OPTARG
             echo activemq connector ack queue mode $mode
             ;; 
         b)
             bhost=$OPTARG
             echo blade  host name to install activema, connector
             ;;

         *)
             usage
             exit
             ;;
     esac
done

installrpm(){
   echo installing rpms .......
   cd /tmp
   rpms=`ls *$verNum*.rpm | grep $verNum`
   for rpm in $rpms;
   do
      if [[ "$rpm" =~ "engine" ]] || [[ "$rpm" =~ "bizapps-common" ]] || [[ "$rpm" =~ "bizapps-misc" ]] ||[[ "$rpm" =~ "gateway-proxy" ]] || [[ "$rpm" =~ "rsgateway" ]] || [[ "$rpm" =~ "notifier" ]] || [[ "$rpm" =~ "netproto-gateway" ]] || [[ "$rpm" =~ "payment-service" ]]
      then 
         sudo rpm -i $rpm
      fi
   done
}

uninstallrpm(){
   echo uninstalliing rpms ......
   cd /tmp
   installedrpms=`sudo rpm -qa | grep matrixx`
   for rpm in $installedrpms;
   do
      if [[ "$rpm" =~ "traffic-manager" ]] 
      then
         tmrpm=$rpm
      elif [[ "$rpm" =~ "bizapps-common" ]]
      then
         bizcomrpm=$rpm
      else
         sudo rpm -e $rpm
      fi
   done
   sudo rpm -e $tmrpm $bizcomrpm
}

chkinstalledrpm(){
   echo checking installed rpm
   found=""
   cd /tmp
   installedrpms=`sudo rpm -qa | grep matrixx`
   if [ ${#installedrpms} -eq 0 ]
   then
         #echo  no rpm  installed
         return 0
   fi 
  
   for rpm in $installedrpms;
   do
     #echo rpm in check $rpm
     #echo verNum $1
     found=`echo $rpm | grep $verNum`
   done
   #echo $found
   if [ ! -z $found ]
   then
        #echo rpms alread installed
        return 1
   fi
   #found new version of rpm to be installed
   return 2
}


if [ -z $verNum ]
then
     usage
     exit 1
fi


#check rpm version # existing or not
cd /tmp
rpms=""
rpms=`ls *$verNum*.rpm | grep $verNum`
echo rpms to be installed $rpms
if [ ${#rpms} -eq 0 ]
then
    echo " rpms $verNum not found"
    exit 1
fi

#check installed rpm before uninstalling
#installedrpms=`sudo rpm -qa | grep matrixx`
chkinstalledrpm
chk=$?
echo check value of instaleed rpm $chk

#remove /opt/mtx/conf/*notifier* before installing new rpms
echo remove /opt/mtx/conf/*notifier*
rm /opt/mtx/conf/*notifier*
ls /opt/mtx/conf/*notifier*

case $chk in
         0)
             echo no rpm installed , installing new vesion of rpm
             installrpm 
             ;;
         1)
             echo rpm already installed, retart engine anyway....
             stop_engine.py --no_prompt
             ;;
         2)
             echo installing new version of rpm
             #stop engine before uninstall old version
             stop_engine.py --no_prompt
             uninstallrpm
             installrpm
             ;;
         *)
             echo not valid rpm to be intstalled 
             exit
esac

#remove the log files
rm /var/log/mtx/*.log
rm /var/log/mtx/blade_1_1_1/*.log
rm  /var/log/mtx/blade_1_1_1/*.gz

#call get_config.py to run create_config.py for QA environment
get_config.py

#if script running on specified blade hostname, notificaiton address has to be localhost:61618
hostname=`hostname`
if [ $hostname == $bhost ]
then
    sed -i "s/10.*.*.*:61618/127.0.0.1:61618/" /opt/mtx/custom/create_config.info 
    create_config.py
fi

#start ActiveMQ if specify, other default install is under /opt/Activemq
if [ -z "$path" ]
then
   $path = '/opt/Activemq'
fi 

$path/apache-activemq-5.*.*/bin/activemq restart

sleep 5
#wait for amq to start
netout=`netstat -an | grep 61616 | grep LISTEN`
echo $netout
if [ ${#netout} -eq 0 ]
then
    echo activemq is not started, port 61616 not established
fi

#start notifier
#/opt/mtx/bin/start_notifier_camel.py 


start_engine.py
# Wait for the engine to be ready
echo Wait for engine to be ready
waitForEngineReady.py

restart_gateway_proxy.sh
sleep 5

restart_rsgateway.sh

#start notifier
restart_notifier.sh
sleep 5

restart_payment_service.sh
#payment-service.sh start
sleep 5

print_blade_stats.py -C


#get and load Pricing
if [ "$CatalogBuilderHost" != "None" ]
then
        #get_and_load_pricing
        #create /tmp/PRICING directory, cp pricing file over
        if [ ! -d /tmp/PRICING ]
        then
            mkdir -p /tmp/PRICING
        fi

        cp /opt/mtx/custom/mtx_pricing_Functional_Tests.xml /tmp/PRICING
fi

#if suite option is not null, then invoke go_restart.py to run suite
echo $suite
if [ ! -z "$suite" ]
then
   cd ${QADIR}/QA/Tests/main_tests_driver
   rm nohup.out

   nohup  go_restart.py -n $suite & 
fi 

exit 0
