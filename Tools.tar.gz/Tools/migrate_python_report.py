#!/usr/bin/python
#===============================================================================
#
# Copyright 2021-2021, MATRIXX Software, Inc. All rights reserved.
#
#-------------------------------------------------------------------------------
#
# @file
# @author     original: Florin-Dan Galan
# @author     last modified by: $Author: mark.germain $
# @date       $Date: 2021-06-15 04:06:50 -0400 (Tue, 15 Jun 2021) $
#
# $Id: migrate_python_report.py 83176 2021-06-15 08:06:50Z mark.germain $
#
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-04-06T16:32:51
#
# @futurizeManager mark.germain : Tue 2021-03-02T12:24:00
#===============================================================================
#
from __future__ import print_function
from builtins import str
import glob
import os
import subprocess
import sys
from argparse import ArgumentParser
import common_functions
import time
import fileinput
import multiprocessing
import migrate_python_lib as migr_lib

kReportFileName = 'report.csv'
# kReportFormat = '%-30s %-30s %-30s %-30s %-50s'
kReportFormat = '%s%s%s%s%s'


def insertRow(fileToProcess, reportFile, managerName, lastModifyDate):
    futurizeCommand = 'futurize --stage2  --no-diffs ' + fileToProcess
    process = subprocess.Popen(futurizeCommand, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    output = process.communicate()[0]
    # print(output)
    if 'No files need to be modified' in output:
        print(kReportFormat % (managerName \
            + ',', 'stage2 no adjustments needed,', '--,', lastModifyDate + ',', fileToProcess), file=reportFile)
    elif ' error ' in output:
        if not os.path.exists(fileToProcess):
            print(kReportFormat % (managerName \
                 + ',', 'error: no file found,', '--,', lastModifyDate + ',', fileToProcess), file=reportFile)
        else:
            print(kReportFormat % (managerName + \
                 ',', 'error during futurize,', '--,', lastModifyDate + ',', fileToProcess), file=reportFile)
    elif 'Files that need to be modified' in output:
        print(kReportFormat % (managerName + ',', \
            'not migrated,', '--,', lastModifyDate + ',', fileToProcess), file=reportFile)
    else:
        print(kReportFormat % (managerName + ',', \
            'cannot analyze,', '--,', lastModifyDate + ',', fileToProcess), file=reportFile)

def insertFileMigrationRecord(fileToProcess, reportFile=None):
    if not migr_lib.checkFileInSVN(fileToProcess):
        return None
    print('Processing : ' + fileToProcess)
    fileLines = migr_lib.getFileLines(fileToProcess)
    manager = migr_lib.getManagerName(fileLines)
    migratedDate = migr_lib.getMigrationDate(fileLines)
    lastModifyDate = migr_lib.getLastModificationDate(fileLines)

    if migr_lib.searchInFile(fileLines, '@DoNotMigrate'):
        print(kReportFormat % (manager + \
            ',', '@DoNotMigrate,', '--,', lastModifyDate + ',', fileToProcess), file=reportFile)
    elif migr_lib.searchInFile(fileLines, '@2to3'):
        print(kReportFormat % (manager + \
            ',', 'stage3,', migratedDate + ',', lastModifyDate + ',', fileToProcess), file=reportFile)
    elif migr_lib.searchInFile(fileLines, '@futurize --stage2'):
        print(kReportFormat % (manager + \
            ',', 'stage2,', migratedDate + ',', lastModifyDate + ',', fileToProcess), file=reportFile)
    elif migr_lib.searchInFile(fileLines, '@futurize --stage1'):
        print(kReportFormat % (manager + \
            ',', 'stage1,', migratedDate + ',', lastModifyDate + ',', fileToProcess), file=reportFile)
    elif migr_lib.searchInFile(fileLines, 'from __future__ import print_function'):
        print(kReportFormat % (manager + \
            ',', 'stage1,', migratedDate + ',', lastModifyDate + ',', fileToProcess), file=reportFile)
    else:
        insertRow(fileToProcess, reportFile, manager, lastModifyDate)
    reportFile.flush()

def processFilesInPath(path, reportFile):
    jobs = []
    for filesInPath in os.walk(path):
        for fileToProcess in glob.glob(os.path.join(filesInPath[0], '*.py')):
            if fileToProcess.find("/node_modules/") == -1 and \
                fileToProcess.find("/publish_linux/") == -1 and \
                fileToProcess.find("/tools/") == -1:
                process = multiprocessing.Process(target=insertFileMigrationRecord,
                                          args=(fileToProcess, reportFile))
                jobs.append(process)
    for job in jobs:
        job.start()
    for job in jobs:
        job.join()

def processFilesForUser(path, reportFile, name):
    jobs = []
    for filesInPath in os.walk(path):
        for fileToProcess in glob.glob(os.path.join(filesInPath[0], '*.py')):
            if fileToProcess.find("/node_modules/") == -1 and \
                fileToProcess.find("/publish_linux/") == -1 and \
                fileToProcess.find("/tools/") == -1 \
                    and migr_lib.getManagerName(migr_lib.getFileLines(fileToProcess)) == name:
                process = multiprocessing.Process(target=insertFileMigrationRecord,
                                          args=(fileToProcess, reportFile))
                jobs.append(process)
    for job in jobs:
        job.start()
    for job in jobs:
        job.join()

def insertManager(managerDictionary, fileToProcess):
    foundManagerInDict = False
    futurizeManager = '@futurizeManager '
    try:
        trimFilePath = str(fileToProcess.replace(common_functions.topDir + '/', ''))
        comment = futurizeManager + managerDictionary[trimFilePath]
        foundManagerInDict = True
    except KeyError:
        print('Error getting the manager for : ' + fileToProcess)
    fileLines = migr_lib.getFileLines(fileToProcess)
    if foundManagerInDict and not migr_lib.searchInFile(fileLines, futurizeManager):
        alreadyHave = False
        if migr_lib.searchInFile(fileLines, futurizeManager):
            alreadyHave = True
        if not alreadyHave:
            for _, line in enumerate(fileinput.input(fileToProcess, inplace=1)):
                if (alreadyHave and (futurizeManager in line)):
                    sys.stdout.write('# ' + comment + ' : ' + \
                        time.strftime('%a %Y-%m-%dT%H:%M:%S') + '\n')
                elif ((not alreadyHave) and ('# $Id' in line)):
                    sys.stdout.write(line)
                    sys.stdout.write('#\n')
                    sys.stdout.write('# ' + comment + ' : ' + \
                        time.strftime('%a %Y-%m-%dT%H:%M:%S') + '\n')
                else:
                    sys.stdout.write(line)

def addManagerHeader(path, managerDictionary):
    for filesInPath in os.walk(path):
        for fileToProcess in glob.glob(os.path.join(filesInPath[0], '*.py')):
            if fileToProcess.find("/node_modules/") == -1 and \
                fileToProcess.find("/tools/") == -1:
                print('Processing : ' + str(fileToProcess))
                insertManager(managerDictionary, fileToProcess)

def printHelp():
    print('************************************************')
    print('Example : migrate_python_report.py -path <directory_for_report>')
    print('Example : migrate_python_report.py -user florindan.galan\
        -path <directory_for_report>')
    print('migrate_python_report.py -setManager <path_to_csv_file/name_of_csv.csv>  \
        -path <directory_for_report>')
    print('Example : migrate_python_report.py')
    print('More info on confluence page :')
    print(' https://j.m0012242008.com/confluence/display/EN/Python+Migration+Report')
    print('************************************************')

def main():
    start = time.time()
    cmd = 'command -v futurize'
    process = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    output = process.communicate()[0]
    if (len(output) == 0):
        print('************************************************')
        print('ERROR: Please install python3-devel')
        print('sudo yum install python3 python3-devel python2-future python3-future')
        print('************************************************')
        sys.exit(1)
    pathToSearch = str('')
    reportFile = None

    parser = ArgumentParser(description='generate report for python migration')
    parser.add_argument("-path", "--path", help="migrate_python_report.py --path <directory_to_report> \
        The script will verify each python file for stage1 , stage 2, or DoNotMigrate \
        and generate report.csv file")
    parser.add_argument("-user", "--user", help="migrate_python_report.py --user <user_name> \
        It will display all the files where the manager name matches the name provided")
    parser.add_argument("-setManager", "--setManager", help="migrate_python_report.py --setManager <manager_file_csv> \
        will add the maanger names in the file header for all python files")

    try:
        args = parser.parse_args()
    except:
        printHelp()
        sys.exit(0)

    pathToSearch = args.path
    user = args.user
    managerFile = args.setManager

    reportFile = open('report.csv', 'w')

    if pathToSearch and (not user) and (not managerFile):
        with open(kReportFileName, 'w') as reportFile:
            print(kReportFormat % \
                ('manager,', 'latest state,', 'migrated date,', 'modified since,', 'path_to file'), file=reportFile)
            reportFile.flush()
            processFilesInPath(pathToSearch, reportFile)
        print('Migration report created: %s' % kReportFileName)
    elif user:
        with open(kReportFileName, 'w') as reportFile:
            print(kReportFormat % \
                ('manager,', 'latest state,', 'migrated date,', 'modified since,', 'path_to file'), file=reportFile)
            reportFile.flush()
            if not pathToSearch:
                pathToSearch = str(os.path.abspath(os.getcwd()))
            processFilesForUser(pathToSearch, reportFile, user)
        print('Migration report created: %s' % kReportFileName)
    elif managerFile:
        managerDictionary = migr_lib.initDictionary(managerFile)
        if not pathToSearch:
            pathToSearch = str(os.path.abspath(os.getcwd()))
        addManagerHeader(pathToSearch, managerDictionary)
    else:
        with open(kReportFileName, 'w') as reportFile:
            print(kReportFormat % \
                ('manager,', 'latest state,', 'migrated date,', 'modified since,', 'path_to file'), file=reportFile)
            reportFile.flush()
            pathToSearch = str(os.path.abspath(os.getcwd()))
            processFilesInPath(pathToSearch, reportFile)
        print('Migration report created: %s' % kReportFileName)

    reportFile.close()
    migr_lib.sortReport('report.csv')
    end = time.time()
    print('Duration : ')
    print('   ' + str(end - start) + ' seconds')
    sys.exit(0)

#===============================================================================

if __name__ == '__main__':
    main()
