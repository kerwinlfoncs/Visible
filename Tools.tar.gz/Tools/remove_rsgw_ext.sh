#!/bin/bash


echo "Starting to delete extension jars in /opt/mtx/ext/rsgateway"
#rm /opt/mtx/ext/rsgateway/rsgw-productcatalog.jar
rm /opt/mtx/ext/rsgateway/rsgw-referral-rewards.jar

echo "Starting to delete  /opt/mtx/conf/extension-containers.properties"
rm /opt/mtx/conf/extension-containers.properties

#echo "Starting to remove refer mdc in rsgateway.properties"
#sed -i '/referral_rewards/d' /opt/mtx/conf/rsgateway.properties

echo "Starting to remove refer mdc in rsgateway.yaml"
sed -i '/referral_rewards/,+4d' /opt/mtx/conf/rsgateway.yaml

restart_rsgateway.sh
