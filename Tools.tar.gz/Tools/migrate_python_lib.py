#!/usr/bin/python
#===============================================================================
#
# Copyright 2021-2021, MATRIXX Software, Inc. All rights reserved.
#
#-------------------------------------------------------------------------------
#
# @file
# @author     original: Florin-Dan Galan
# @author     last modified by: $Author: mark.germain $
# @date       $Date: 2021-06-15 04:06:50 -0400 (Tue, 15 Jun 2021) $
#
# $Id: migrate_python_lib.py 83176 2021-06-15 08:06:50Z mark.germain $
#
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-04-06T16:30:08
#
# @futurizeManager mark.germain : Tue 2021-03-02T12:24:00
#===============================================================================
#
from __future__ import print_function
from builtins import map
import os
import subprocess
import sys

def sortReport(reportFile):
    reportList = []
    if os.path.exists(reportFile):
        with open(reportFile) as unsortedFile:
            fileLines = unsortedFile.readlines()
            for line in fileLines:
                lineElem = line.strip().split(',')
                reportList.append(lineElem)
        reportList = sorted(reportList, key=lambda x: (x[0], x[1], x[4]))
        with open(reportFile, 'w') as sortedFile:
            for row in reportList:
                formattedLine = ",".join(map(str, row))
                sortedFile.write(formattedLine + '\n')

def initDictionary(managerFile):
    migrFileDict = {}
    if not os.path.exists(managerFile):
        print('migration manager file does not exist, exiting')
        print('either place one in current folder or provide in input')
        sys.exit(1)
    with open(managerFile) as fileToCheck:
        fileLines = fileToCheck.readlines()
        for line in fileLines:
            lineElem = line.strip().split(',')
            if(len(lineElem) == 3):
                migrFileDict[lineElem[0]] = lineElem[2]
    return migrFileDict

def checkFileInSVN(fileName):
    svnCommand = 'cd_top ; svn info ' + fileName + ' | grep Revision  | awk \'{print $2}\''
    process = subprocess.Popen(svnCommand, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    output = process.communicate()[0]
    if(len(output) > 0 and ('E155007' not in output) and ('E200009' not in output) and ('W155010' not in output)):
        return True
    return False

def searchInFile(fileLines, comment):
    count = 0
    for line in fileLines:
        count = count + 1
        if comment in line:
            return True
        if count > 245:
            return False
    return False

def getFileLines(fileToProcess):
    fileLines = []
    with open(fileToProcess) as fileToCheck:
        fileLines = fileToCheck.readlines()
    return fileLines

def getManagerName(fileLines):
    managerName = 'unknown'
    for line in fileLines:
        if '@futurizeManager ' in line:
            managerName = line.split(' ')[2].strip()
            return managerName
    return managerName

def getMigrationDate(fileLines):
    migrationDate = '--'
    for line in fileLines:
        if '@futurize ' in line:
            tokens = line.split(' : ')
            if len(tokens) > 1:
                migrationDate = line.split(' : ')[1].strip()
                if '--stage2' in line:
                    return migrationDate
            else:
                migrationDate = '--'
                return migrationDate
    return migrationDate

def getLastModificationDate(fileLines):
    lastDate = '--'
    for line in fileLines:
        if '# $Id:' in line:
            tokens = line.split(' ')
            if len(tokens) > 4:
                lastDate = tokens[4].strip() + 'T' + tokens[5]
                return lastDate
            else:
                lastDate = '--'
                return lastDate
    return lastDate

def checkMigrationTag(fileLines, tag):
    if searchInFile(fileLines, tag):
        return True
    return False

def checkStep1Migration(fileLines):
    return checkMigrationTag(fileLines, '@futurize --stage1')

def checkStep2Migration(fileLines):
    return checkMigrationTag(fileLines, '@futurize --stage2')

def checkStep3Migration(fileLines):
    return checkMigrationTag(fileLines, '@2to3')
