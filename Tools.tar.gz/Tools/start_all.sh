rm /var/log/mtx/blade_1_1_1/*
rm /var/log/mtx/*.log
rm /var/log/mtx/mtx_debug.log*
rm -rf /var/log/mtx/obsolete_*

/opt/Activemq/apache-activemq-5.*.*/bin/activemq start
sleep 1
start_engine.py
sleep 2
cd /tmp/PRICING/; load_pricing.py -f  /tmp/PRICING/mtx_pricing_Functional_Tests.xml
start_gateway_proxy.sh
#sudo /usr/sbin/tomcat start
start_rsgateway.sh -j -Drsgateway.engine.address=localhost -j -Drsgateway.engine.port=4070
sleep 80
start_notifier.sh
restart_payment_service.sh
#restart_network_protocol_gateway.sh

