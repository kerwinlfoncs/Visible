#!/bin/bash
#Prerequisites: mtx user needs to have privilege to /bin/su

if [ -z $1 ]
then
   echo 'please enter the root path of activemq, otherwise use default activemq root path, /opt/ActiveMQ'
   rootPath='/opt/ActiveMQ'
else
   rootPath=$1
fi

# kill notifier client process first
#pid=""
#pid=`ps -ef | grep  mtx_notification_client.jar | grep -v grep | awk {'print $2'}`
#echo stopping mtx_notification_client process ...pid=$pid
#if [ -z $pid ]
#then
#    echo 'not able to find mtx_notification_client pid'
#fi
#kill -9 $pid

#stop the notifier
/opt/mtx/bin/mtx_notifier.sh stop

#stop amq connector
sudo su - mtx_activemq -c "/opt/mtx_activemq_connector/bin/stop_activemq_connector.py"

#stop amq
$rootPath/apache-activemq-5.*.0/bin/activemq stop

