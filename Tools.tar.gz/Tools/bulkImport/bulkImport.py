#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-12-03T09:29:29
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-12-03T09:29:29
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-12-03T09:29:29

# System imports
from __future__ import print_function
# from builtins import str
# from builtins import range
# from builtins import str
# from builtins import range
# from builtins import str
# from builtins import range
import os, glob, time, sys, pprint
from datetime import datetime

# MTX Service imports
from bulkImportData import convertInputFileToBulkFiles as CONVERT
from bulkImportData import prim as PRIM
from bulkImportData import data2 as DATA
from bulkImportData import data_fcns as DATAFCN
from bulkImportData import bulkDiameter as BULKDIAM
from bulkImportData import getResourceIds as RESOURCE
from bulkImportData import validate as VALIDATE
from primitives     import primGeneric as GENERIC

# Point to debug file
debugLogFile = os.path.expandvars(os.getenv('MTX_LOG_DIR', '/var/log/mtx')) + '/mtx_debug.log'
        
# File name that will hold offers read
offerListFileName = DATA.outputFileDir + '/offerList'
removeOfferListFileName = False

# ------------------------------------------------------------------------------
def convertData(errorCount):
        global debugLogFile
        global removeOfferListFileName
        
        # Check if conversion not desired
        if not DATA.config['Program']['convertFiles']:
                print('Skipping bulk import file generation due to Program variable convertFiles set to False or missing')
                return errorCount,0
        
        # Get supported operations
        operations = list(DATA.CONFIGDATA['Operations'].keys())
#       cmd = 'egrep "^Device|^Subscriber|^Group" ' + DATA.options.config + ' | cut -f1 -d" "'
#       operations = GENERIC.runCmd(cmd).split("\n")
        
        # See if we should read offers.
        # Only need if input validation is desired.
        if DATA.config['Program']['inputValidation'] and not DATA.options.offers:
                # get Rest data
                host = DATA.config['Rest']['hostname']
                port = DATA.config['Rest']['hostport']
                        
                # If we have the data, then get the offer list
                if host:
                        # Debug output
                        print('Retrieving offers from host:port ' + host + ':' + port)
                        
                        # Get offers
                        cmd = 'curl -s -H "Cache-Control: no-cache" http://' + host + ':' + port + '/rsgateway/data/v3/pricing/offers | grep ExternalId | cut -f2 -d">" | cut -f1 -d "<" > ' + offerListFileName
                        GENERIC.runCmd(cmd)
                        
                        # Update the options value to signal we have this
                        DATA.options.offers = offerListFileName
                        
                        # Signal that we should remove this file, as it wasn't present at the start
                        removeOfferListFileName = True
                else:
                        # No offer file
                        print('WARNING:  no offer file input and Rest configuration file data not populated.  No offer external ID checking will be done.')
                
        # Check errors in debug log
        #errorCount = GENERIC.checkDebugLogForErrors(errorCount, debugLogFile)

        # Expect only one argument (CSV file)
        if len(DATA.args) != 1:
                print(str(len(DATA.args)) + ' arguments passed in (' + str(DATA.args) + ').  Expecting only 1 argument.')
                sys.exit('Exiting due to errors')

        # Prompt for conversion to begin
        print('Ready to convert file ' + DATA.args[0] + ' to bulk import files')
        
        # Only pause the first time through
        PRIM.pauseCheck()
                
        # If the user needs to retrieve object resource IDs, then do that up front
        if DATA.options.getResourceIds:
                # Initialize generator function.  Input don't matter here.
                RESOURCE.resourceIdFunction = RESOURCE.GetObjectResourceIds(None)
                RESOURCE.resourceIdFunction.send(None)
                
                # Convert the file - will create global data to be used later
                CONVERT.convertInputFileToBulkFiles(DATA.args[0], DATA.config, operations, getResourceIds=True)
                
                # Invoke generator so it'll terminate threads
                RESOURCE.resourceIdFunction.send(None)
                
                # Clear global setting
                DATA.options.getResourceIds = False
        
        # Convert the input file to bulk files
        (retCode,lineCount) = CONVERT.convertInputFileToBulkFiles(DATA.args[0], DATA.config, operations)
        if not retCode:
                print('ERROR:  failure in conversion of input file to bulk files.  Exiting.')
                return errorCount,lineCount
        
                # Check errors in debug log
                errorCount = GENERIC.checkDebugLogForErrors(errorCount, debugLogFile)
        else:
                print('Success converting input file to bulk files.')
        
        # Warn if any records skipped
        file = glob.glob('./' + DATA.outputFileDir + '/*skip')[0]
        statinfo = os.stat(file)
        if int(statinfo.st_size): 
                print('\nSome input lines were skipped.  Please review file ' + str(file) + ' and decide if this should continue.')
                PRIM.pauseCheck(True)
        
        return errorCount,lineCount
        
# ------------------------------------------------------------------------------
def executeData(errorCount):
        # If here, then need to execute the import files
        
        # Get list of files
#       f = []
#       for (dirpath, dirnames, filenames) in os.walk('./output'):
#               # Get files
#               f.extend(filenames)
#               
#               # Only care about top level directory (in case someone does something silly...)
#               break
        
        # Now start to execute.
        # Prompt to go ahead
        print('Ready to bulk import files')
        PRIM.pauseCheck()
        
        # Remove old files in output directory
        cmd = 'rm ./' + DATA.outputFileDir + '/*testapp_results* 2>/dev/null'
        GENERIC.runCmd(cmd)
        
        # Prioritize operations.  NOTE: Moved Add to the end so it works with adding subs to the group.  Otherwise there were issues.
        # THIS doesn't work with device offer purchase, so may need to move Add before Required if doing device purchase (and then hopefully not groups involved...)
        try:
                if DATA.config['Program']['skipDelete']: operationList = ['Create', 'Required', 'Optional', 'Input', 'Modify', 'Cancel', 'Stop', 'Adjust', 'Add', 'Finish']
                else:                                    operationList = ['Remove', 'Delete', 'Create', 'Required', 'Optional', 'Input', 'Modify', 'Cancel', 'Stop', 'Adjust', 'Add', 'Finish']
        except: operationList = ['Remove', 'Delete', 'Create', 'Required', 'Optional', 'Input', 'Modify', 'Cancel', 'Stop', 'Adjust', 'Add', 'Finish']
        
        # If we're supposed to validate before input, then add that at the start
        if DATA.config['Program']['preImportQuery']:
                # Prepend query operation
                operationList.insert(0, 'QueryPre')
                
                # Query count should be 0, as this will signal pre-bulk query
                queryCount = 0
        else:
                # Query count should be 1, as there is no pre-bulk query
                queryCount = 1
        
        # If we're supposed to validate output, then add that at the end
        if DATA.config['Program']['postImportQuery']: operationList.append('QueryPost')
        
        # Different commands depending on input options (mainly local/remote execution)
        if DATA.options.host:
                tool = 'send_data_container_file.py -H ' + DATA.options.host + ' -P ' + DATA.options.print_format
        else:   tool = 'test_app -m xml -e ' + DATA.options.engine + ' -c ' + DATA.options.cluster + ' -b ' + DATA.options.blade
        
        # Loop through operations
        for operation in operationList:
                # Prioritize areas.  Do group first in case anyone joining a group.  Do group before subscriber, in case we're testing subscriber grants to the group (so need group required offers purchased first).
                for area in ['Group', 'User', 'Subscriber', 'Device']:
                        # Get list of files matching the area + operations
                        fileList = sorted(glob.glob('./' + DATA.outputFileDir + '/*' + area + operation + '*.mdc'))
                        #print 'File list: ' + str(fileList)
                        
                        # Process each file
                        for file in fileList:
                                # Add full path to file (for output)
                                file = os.getcwd() + '/' + file
                                
                                # Skip if empty
                                statinfo = os.stat(file)
                                if not int(statinfo.st_size): continue
                        
                                # Found something to process!
                                # Prompt to go ahead.
                                print('\n\t\t\t**** File to bulk load: ' + file + ' ****\n')
                                PRIM.pauseCheck()
                                
                                # Define output file
                                outputFile = file + '_results'
                                
                                # Build command
                                if not DATA.options.host:
                                        # test_app parameters
                                        cmd = tool + ' -C ' + file + ' -r ' + outputFile
                                        
                                        # If doing an add operation, then want it sync'd (otherwise we see TX retry errors)
                                        if file.count('Add'): cmd += ' -s'
                                
                                else:   cmd = tool + ' -f ' + file + ' > ' + outputFile
                                
                                # Run the command
                                print('Executing command: ' + cmd)
                                GENERIC.runCmd(cmd)
                                
                                # Get time (in case validation and review covers the desired sleep time)
                                GENERIC.captureTime()
                                
                                # Seeing a strange case where the result file is not written.  Check for this here.
                                if not os.path.exists(outputFile):
                                        print('WARNING:  file "' + outputFile + '" does not exist.  The previous command failed to execute.')
                                        print('Please verify errors and decide whether to continue.')
                                        GENERIC.pauseCheck(check=True)
                                        
                                        # Skip remainder of this loop
                                        continue
                                
                                # Validate MDC result file
                                VALIDATE.validateBulkImportResults(outputFile, DATA.options.rmvFlag)
                                
                                # Check errors in debug log.  NOte: debug log may not be present so don't use if running remotely.
                                if not DATA.options.host: errorCount = GENERIC.checkDebugLogForErrors(errorCount, debugLogFile)
                                
                                # Sleep between files
                                timeToSleep = DATA.config['Program']['executeFileDelay']
                                if timeToSleep and int(timeToSleep):
                                        # Get time delta since starting clock
                                        delta = GENERIC.deltaTimeInSeconds()
                                        
                                        # See if any time still needed
                                        if int(timeToSleep) > int(delta):
                                                # Get time to sleep
                                                tts = int(timeToSleep) - int(delta)
                                                
                                                # Sleep
                                                print('Will sleep remaining ' + str(tts) + ' seconds before importing the next file')
                                                time.sleep(tts)
                                        
                                        else:   print('Sleep skipped, as it\'s already been ' + str(delta) + ' seconds since executing last bulk import and setting is ' + str(timeToSleep) + '.')
                                                
                # If a query, then bump query count
                if operation != 'Query': queryCount += 1
                                
        return
        
# ------------------------------------------------------------------------------
#  MAIN
# ------------------------------------------------------------------------------
def main():
        global offerListFileName
        
        # Assume no errors at the start
        errorCount = '0'
        
        # Total line count
        totalLineCount = 0
                
        # Init global data
        DATAFCN.initData()
        
        # Update global after input processed
        offerListFileName = DATA.outputFileDir + '/offerList'
        
        # Create output directory if needed
        try:
                os.makedirs(DATA.outputFileDir)
        except:
                x = 1
        
        # Remove old files in output directory iff we're converting
        if DATA.config['Program']['convertFiles']:
                for item in DATA.MDCLIST:
                        cmd = 'rm ' + DATA.outputFileDir + '/*' + item + '* 2>/dev/null'
                        GENERIC.runCmd(cmd)
        
        # Start time for statistical reasons
        start_time = datetime.now()
        start_time_str = start_time.strftime('%d-%b-%YT%H-%M-%S')
        print('Starting data conversion at time: ' + start_time_str)
        
        # Repeat conversion using input parameter
        for i in range(DATA.options.repeat):
                print('\n************************************************\nExecuting data conversion loop ' + str(i+1))
#               print 'DATA options: ' + str(DATA.options)
                
                # Convert input data
                (errorCount,lineCount) = convertData(errorCount)
                totalLineCount += lineCount
                
                # Update parameter (except for last time through)
                if i < (DATA.options.repeat-1): DATAFCN.initData()
        # Done
        print('\nFinished data conversion.  ' + str(totalLineCount) + ' lines processed.')
        print("Total Time elapsed = ", GENERIC.calc_sec(start_time), " seconds")
        print("=========================================\n")
        
        # Execute if supposed to
        if DATA.config['Program']['executeFiles']:
                # Execute scripts
                executeData(errorCount)
                
                # Validate (or not, depending on per-object configuration)
                resultsFile = 'output/ValidationResults'
                VALIDATE.validatePostBulkImport(resultsFile)
        else:
                print('Bulk execution not enabled')
        
        # Remove offer list if we generated it
        if removeOfferListFileName: 
                cmd = 'rm -f ' + offerListFileName + ' 2>/dev/null'
                GENERIC.runCmd(cmd)
        
        # All done!
        print('\n\nAll Done!!\n\n')
        
        #print 'ObjectReferencedValues: = ' + str(DATA.ObjectReferencedValues)
        
if __name__ == '__main__':
        main()

