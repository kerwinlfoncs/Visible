# File that defines bulk import parameters

#[KARL]

[Rest]
hostname : localhost
hostport : 8080

[Program]
release         : 4523
stopEarlyRecordCount  : 10000000
inputValidation       : True
postImportQuery  : True
preImportQuery   : False
batchSize             : 50000
progressCount         : 2000
optionalOfferNoExpire : True
requiredOfferNoExpire : True
executeFiles          : True
convertFiles          : True
executeFileDelay      : 0
pauseForHumanInput    : False
outputValidationFilter : egrep "ExternalId|Status" 
inputSeparator        : ,
#karl			: 345

# OK - the one that matters!!
# See bulk import document for specific parameter names supported.
input : operation,GroupExternalId,SubscriberExternalId,DeviceImsi,DeviceMsisdn,SubscriberNewExternalId,OfferExtId,OfferStartTime,OfferEndTime

[Operations]

# Device operations
DeviceCreate          : True
DeviceAddToSubscriber : True
DeviceRequiredOffers  : False
DeviceOptionalOffers  : False
DeviceInputOffers     : False
DeviceModify          : False

# Subscriber operations
SubscriberCreate          : True
SubscriberAddToGroup      : True
SubscriberRequiredOffers  : True
SubscriberOptionalOffers  : True
SubscriberInputOffers     : True
SubscriberModify          : True

# Group operations
GroupCreate          : True
GroupRequiredOffers  : True
GroupOptionalOffers  : True
GroupInputOffers     : False
GroupModify          : False

[Subscriber]
RequiredOffers : MTX Subscriber Rating Setup
OptionalOffers : GPRS WAP Red Essential 1 Month Bundle
BillCycleId    : 1000
BillCycleDay   : 13
SharingEnabled : 1
Status		: 1
Verify		: False

[Group]
RequiredOffers : MTX Group Rating Setup
OptionalOffers : GPRS WAP Black 1 Month Bundle,GPRS WAP 100MB top up Bundle
BillCycleId    : 1000
BillCycleDay   : 13

[Device]

[Offer]
Owner          : Karl

