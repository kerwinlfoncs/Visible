#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-12-03T09:30:33
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-12-03T09:30:33
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-12-03T09:30:33
from __future__ import print_function
from __future__ import absolute_import
# from builtins import input
# from builtins import str
# from builtins import range
from future import standard_library
standard_library.install_aliases()
# from builtins import input
# from builtins import str
# from builtins import range
import subprocess
import sys, os
import xml.etree.ElementTree as ET
from . import parseRecord as REC

from queue import Queue
import threading

NUM_THREADS=30
HOST1=''
HOST2=''

import http.client
 
#===============================================================================
def getAndVerifyHttpRequest(conn, url):
        # Assume success
        result = True
        
        # We'll try the query several times
        retryCount = 0
        
        # Need something here in case we get non-XML response
        x = None
        
        # Limit retries
        while retryCount < 5:
                # Bump retry counter
                retryCount += 1
                
                # Issue the command and get the response
                conn.request("GET", url)
                response=conn.getresponse()
                responseData = response.read()
                
                # Seeing that timeouts don't always return XML data...
                try:
                        x=ET.fromstring(responseData)
                except:
                        print('ERROR:  returned data is not in XML format')
                        #print responseData
                        continue
                        
                # Make sure we passed.  
                # Were seeing that not all responses returned a Result value...
                try:
                        # Exit loop if successful
                        if x.find('Result').text.strip() == '0': break
                except:
                        print('WARNING:  received a response back that didn\'t contain a Result')
                        print('URL: ' + url)
                        print(str(responseData))
                        continue
                
                        
                # If not at limit, then continue
                if retryCount < 5: continue
                
                # Report each error
                result = False
                print('ERROR: Failed 5 query commands to url: ' + url)
                print('Last Result Code = ' + x.find('Result').text.strip())
                try:
                        print('Last Result Text = ' + x.find('ResultText').text.strip())
                except:
                        print('No result text returned')
                
#                sys.exit('Exiting due to errors')
        
        # Return data
        return (result, x)
        
#===============================================================================
# Setup thread for processing the request
class processingThread(threading.Thread):
    def __init__(self,threadNum,queue,groupList,subList,devList):
        threading.Thread.__init__(self)
        self.threadNum=threadNum
        self.input_queue=queue
        self.groupList=groupList
        self.subList=subList
        self.devList=devList
        
        # Create a Rest connection, reuse for every query
        PORT=8080
        
        # Open both connections
        print('opening connection to host/port: ' + HOST1 + '/' + str(PORT))
        self.conn1=http.client.HTTPConnection(HOST1,PORT)
        
        #Host2=HOST2
        #self.conn2=httplib.HTTPConnection(Host2,PORT)
        
        # Not working.  Set second connection object equal to the first one.
        self.conn2=self.conn1
        
        # Define common portion of URL
        self.urlStart = '/rsgateway/data/v3/'
        
    def run(self):
        count = 0
        currentObj = None
        
        # Loop
        while True:
 
          # Get a request from the queue
          item=self.input_queue.get(block=True)
#          print 'Thread %d retrieved from queue %s'%(self.threadNum,str(item))

          # If None, then there will be nothing more and we should exit
          if item is None:
            print('Thread ' + str(self.threadNum) + ' exiting after processing ' + str(count) + ' records')
            return

          # Otherwise, do something based on the object field
          # Extract the items that were put
          i,obj=item
          
          # Print if switching object types
          if currentObj != obj:
                print('\n\nSwitching from current object ' + str(currentObj) + ' to new object ' + str(obj))
                currentObj = obj
          
          # Increment local counter
          count += 1
          
          # Setup base url
          url = self.urlStart + i[:-1]
          
          # If a group, then set the maximum size for returned subs
          if obj=='group': url += '?querySize=250'
          
          # Debug output
#         print 'querying URL: ' + url
          
          # Run the query.  Load balance across the two servers
#         if count % 1: (result, x) = getAndVerifyHttpRequest(self.conn1, url)
#         else:         (result, x) = getAndVerifyHttpRequest(self.conn2, url)
          (result, x) = getAndVerifyHttpRequest(self.conn1, url)
          
          # If not success, then skip
          if not result: continue
          
          # Additional query for group
          if obj=='group':
                # Need the OID to query the wallet
                oid = x.find('ObjectId').text.strip()
                
                # Only need the first field of the old variale part of the URL, since OID queries are the default.
                urlParam = i.split('/')[0]
                url = self.urlStart + urlParam + '/' + oid + '/wallet'
#               print 'querying URL: ' + url
                
                # Run the query.  Load balance across the two servers
                # HACK:  cut out wallet query (for performance)
                if count % 1:   (result, xw) = getAndVerifyHttpRequest(self.conn1, url)
                else:           (result, xw) = getAndVerifyHttpRequest(self.conn2, url)
#               xw = None
                                
                # If not success, then skip
                if not result: continue
          else: xw = None
          
          # OK; now do per-object processing
          if obj=='group':        processQueries2(x, xw, self.groupList, obj)
          elif obj=='subscriber': processQueries2(x, xw, self.subList, obj)
          elif obj=='device':     processQueries2(x, xw, self.devList, obj)
          
          # Print every fixed number of queries
          if not (count % 1000): print('Thread ' + str(self.threadNum) + ' has processed ' + str(count) + ' records')
                   
#===============================================================================
def processQueries(q,f,object):
        # Open input file
        fd = open(f, 'r')
        
        # Add each line of the file to the queue
        for i in fd:
                # Don't process here, but just add a request to the queue
        #       print 'putting line ' + i + ' in queue'
                q.put((i,object))
        
        # Close the file
        fd.close()

#==========================================================
def processQueries2(q, qw, list, object):
        # Want one function to do queries.  Slight differences in group/subscriber/device.  Addres those here.
        if object == 'group':
                child = 'subOid'
                childXmlObjectName = 'SubscriberMemberIdArray'
                parentXmlObjectName = None
        elif object == 'subscriber':
                child = 'devOid'
                childXmlObjectName = 'DeviceIdArray'
                parentXmlObjectName = 'ParentGroupIdArray'
        else:   
                child = None
                parentXmlObjectName = 'SubscriberId'
                
        # Get the OID and external ID
        oid = q.find('ObjectId').text.strip()
        if child: extId = q.find('ExternalId').text.strip()
        else:     extId = 'N/A'
                
        # Sanity check:  shouldn't have encountered this group previously
        if oid in list: sys.exit('Error: encountered ' + object + ' OID ' + oid + ' external ID ' + extId + ' a second time')
                
        # Add to the list
        list[oid] = {}
        list[oid]['extId'] = extId
                
        # Other work is only valid for objects that have children
        if child and qw:
                # Setup array for children
                list[oid][child] = []
                        
                # Get children OIDs
                for children in q.findall('./' + childXmlObjectName + '/value'):
                        # Copy value to local
                        childOid = children.text.strip()
#                       print object + ' ' + child + ' OID: ' + childOid
                        list[oid][child].append(childOid)
                        
                # Process wallet data
                # Process bill cycle data.
                # Not sure how to grab a single value within other structures...
                # NOTE: seeing error here in high volume querying.  Add try/except to see what's going on
                try:
                        for x in qw.findall('./BillingCycle/MtxBillingCycleInfo'):
                                list[oid]['currentBillCycle'] =  x.find('CurrentPeriodEndTime').text.strip().split('T')[0].translate(None, '-')
                except:
                        print(object + ' oid ' + oid + ' did not return a bill cycle')
                        ET.dump(qw) 
                
                for x in qw.findall('./NextBillingCycle/MtxBillingCycleInfo'):
                        list[oid]['futureBillCycle']  =  x.find('CurrentPeriodEndTime').text.strip().split('T')[0].translate(None, '-')
                
                # If no current bill cycle, then an error
                if ('currentBillCycle' not in list[oid]) or not list[oid]['currentBillCycle']: 
                        sys.exit('ERROR:  ' + object +  ' ' + extId + ' does not have a bill cycle defined')
                
                # If no future bill cycle, then set entry to month after current bill cycle
                if ('futureBillCycle' not in list[oid]): 
                        list[oid]['futureBillCycle']  = list[oid]['currentBillCycle'][0:5] + str(int(list[oid]['currentBillCycle'][5]) + 1) + list[oid]['currentBillCycle'][6:]
        else:
                # Add NULL values for bill cycle
                list[oid]['currentBillCycle'] = ''
                list[oid]['futureBillCycle']  = ''
                
        # OK; need object-specific code.  
        if object == 'device':
                # The string is customer specific :-(.  Eventually will parameterize this.
                for extension in q.findall('./Attr/Advantage_SDDeviceObjectExtension'):
                        # IMSI at this level
                        list[oid]['imsi'] = extension.find('Imsi').text.strip()
                                
                        # Access number below here
                        list[oid]['accessNumber'] = []
                        for value in extension.findall('./AccessNumberArray/value'): list[oid]['accessNumber'].append(value.text.strip())
                
                # Get parent if one is expected
                list[oid]['parent'] = q.find(parentXmlObjectName).text.strip()
        elif object == 'subscriber':
                # Parent is within a structure
                for value in q.findall('./ParentGroupIdArray/value'): list[oid]['parent'] = value.text.strip()
                        
                # Want to get offers
                list[oid]['offers'] = []
                for offers in q.findall('./PurchasedOfferArray/MtxPurchasedOfferInfo'): 
                        # Get External ID.
                        # Seeing validation errors here.  Add try/except to figure them out.
                        try:
                                idString = 'ProductOfferExternalId'
                                #idString = 'ProductOfferId'
                                offerExtId = offers.find(idString).text.strip()
                        except:
                                print('ERROR: subscriber OID ' + oid + ' has no offers returned.')
                                ET.dump(q) 
                                sys.exit()
                        
                        # Start time not always present
                        try:
                                 offerPurchaseTime = offers.find('StartTime').text.strip()
                        except:
                                # If no start time, then default to purchase time
                                offerPurchaseTime = offers.find('PurchaseTime').text.strip()
                                
                        # End time is optional
                        try:
                                offerEndTime = offers.find('EndTime').text.strip()
                        except:
                                offerEndTime = ''
                                
                        # Append tuple to the list
                        list[oid]['offers'].append((offerExtId, offerPurchaseTime, offerEndTime))
                                
        else: list[oid]['parent'] = None
                
        # Debug output
#       print 'Processed ' + object + ' ' + oid + '/' + extId + '.  Data: ' + str(list[oid])
                        
        # Return the list
        #print 'List: ' + str(list)
        return list
        
#==========================================================
def processRecord(device, subscriber, group):
        # Define output file seperator character
        sepChar = ','

        # The following defines the old offer name : new offer name.  This facilitates offer remapping.
        # NOTE:  the index/value combination is reversed here, so we can use the "in" construct.
        offerRemap = {}
        offerRemap['GPRS WAP 1GB Data Bonus add on Bundle'] = 'GPRS/WAP 1GB data bonus Bundle'
        
        # Need to also skip some offers
        offerSkip = {}
        offerSkip['MTX Subscriber Rating Setup'] = 1
        
        # Return structure
        retLines = []
                
        # Debug output
#       print 'Device ' + devOid + ' parent = ' + parentOid + ', grand parent = ' + grandParentOid
                
        # Input file format: group Ext ID,MSISDN,IMSI,current DOM,future DOM,Offer Ext ID,offer start time (YYYYMMDD), offer end time,0.
        # Status doesn't matter, as we create everything as active.  Will need to remove that column before we actually validate.
        # Fields that are None should write a blank.
        #
        # Also, offer names may have been translated as part of import.  Really need to translate back so things verify...  Need to maintain this with the 
        # conversion code.
                
        # Get data into local variables (just easier to read)
        groupExtId = group['extId']
        msisdn = device['accessNumber'][0]
        imsi = device['imsi']
                        
        # Hard-code the rest of the values
        status = 'Active'
        finalVal = '0'
                
        # Now need one line per offer
        for i in range(len(subscriber['offers'])):
                # Get external ID
                offerExtId = subscriber['offers'][i][0]
                        
                # If this is in the skip list, then skip
                if offerExtId in offerSkip: continue
                        
                # If in the remap list, then remap
                if offerExtId in offerRemap: offerExtId = offerRemap[offerExtId]
                        
                # Get offer times
                offerPurchaseTime = subscriber['offers'][i][1]
                offerEndTime = subscriber['offers'][i][2]
                #print 'Offer start/end time: ' + offerPurchaseTime + '/' + offerEndTime
                        
                # Need to convert offer times to input file format.  Ideally I'd just use [0:4,5:7,8:10] to get the desired fields.  Doesn;t seem to work...
                offerPurchaseYear  = offerPurchaseTime.split('-')[0]
                offerPurchaseMonth = offerPurchaseTime.split('-')[1]
                offerPurchaseDay   = offerPurchaseTime.split('-')[2].split('T')[0]
                offerPurchaseComposite = offerPurchaseYear + offerPurchaseMonth + offerPurchaseDay
                        
                if offerEndTime != '':
                        offerEndYear  = offerEndTime.split('-')[0]
                        offerEndMonth = offerEndTime.split('-')[1]
                        offerEndDay   = offerEndTime.split('-')[2].split('T')[0]
                        offerEndComposite = offerEndYear + offerEndMonth + offerEndDay
                else:   offerEndComposite = ''
                        
                # Write the line to the validation file
                line =  groupExtId                + sepChar + msisdn                      + sepChar + imsi              + sepChar + \
                        group['currentBillCycle'] + sepChar + group['futureBillCycle']    + sepChar + \
                        offerExtId                + sepChar + offerPurchaseComposite      + sepChar + offerEndComposite + sepChar + \
                        finalVal + '\n'
                
                # Append to return structure.
                # NOTE:  probabaly could use yeild here (if I really knew how it all works)
                retLines.append(line)
        
        # return lines
        return retLines
        
#==========================================================
def validateInput(inputFiles):
        # Track what we've already encountered
        groupList = {}
        subList = {}
        devList = {}
 
        # local meters
        recordNumber = 0
 
        # Set up a queue
        q=Queue()        

        ##### PROCESS Group DATA #####
        # Create threads and start them
        pool=[]
        for i in range(NUM_THREADS):
          t=processingThread(i,q,groupList,subList,devList)
          pool.append(t)
          t.daemon = True
          t.start()
        
        # Process queries.  Allow for faster individual checking by skipping an object if the value is 'None'.
        if inputFiles[2] != 'None': processQueries(q, inputFiles[2], object='group')
        
        # Put as many None's in the queue as there are threads, so that each thread gets one
        for t in pool:
          q.put(None)

        # Wait for all threads to exit
        for t in pool:
          t.join()
        
        # Prompt the user before going on
        eval(input(['Press enter to resume processing subscriber and device data: ']))
        
        ##### PROCESS Non-Group DATA #####
        # Create threads and start them
        pool=[]
        for i in range(NUM_THREADS):
          t=processingThread(i,q,groupList,subList,devList)
          pool.append(t)
          t.daemon = True
          t.start()
        
        # Process queries.  Allow for faster individual checking by skipping an object if the value is 'None'.
        if inputFiles[0] != 'None': processQueries(q, inputFiles[0], object='device')
        if inputFiles[1] != 'None': processQueries(q, inputFiles[1], object='subscriber')
        
        # Put as many None's in the queue as there are threads, so that each thread gets one
        for t in pool:
          q.put(None)

        # Wait for all threads to exit
        for t in pool:
          t.join()
        
#       print '\n\nGroup data: ' + str(groupList)
#       print '\n\nSub   data: ' + str(subList)
#       print '\n\nDev   data: ' + str(devList)
#       sys.exit('Exit Early')
        
        # OK, now re-create the input file :-).
        # Open validation file
        f = open('validation_file', 'w')
        
        # Start by grabbing each device and build up from there.
        for devOid in devList:
                # Get the key fields required to create the input file line
                try:
                        parentOid = devList[devOid]['parent']
                except:
                        print('ERROR:  device OID ' + devOid + ' does not have a parent')
                        continue
                
                try:
                        grandParentOid = subList[parentOid]['parent']
                except:
                        print('ERROR:  subscriber OID ' + parentOid + ' does not have a parent')
                        continue
                
                # Process this record, appending the results to the overall array
                retLines = processRecord(devList[devOid], subList[parentOid], groupList[grandParentOid])
                
                # Process each returned line
                for line in retLines: f.write(line)

        # Close the validation file
        f.close()
                
#===============================================================================
#this fnction used to run bash scripts.
def runCurlCmd(cmd, validate=True):
        curlRsp=runCmd(cmd)
        #print 'curlRsp = ' + curlRsp
                
        # Put into XML structure
        x=ET.fromstring(curlRsp)
                
        # Make sure we passed
        if validate and x.find('Result').text.strip() != '0': 
                result = False
                print('Failed query command: ' + cmd)
                print('Result Code = ' + x.find('Result').text.strip())
                try:
                        print('Result Text = ' + x.find('ResultText').text.strip())
                except:
                        print('No result text returned')
                
                # Don't exit now...
                #sys.exit('Exiting due to errors')
        else:   result = True
        
        return (result, x)
        
#===============================================================================
def main():
        global HOST1
        
        # Sanity  check input
        if len(sys.argv) != 3: sys.exit('ERROR:  need to input two parameters:  files and IP address.  "' + str(sys.argv) + '" were passed in')
        
        # Input file is from parameter
        inputFiles = sys.argv[1]
        if inputFiles != '-':
                # Input files passed in.  Use them. Assume dev,sub,grp order
                inputFiles = inputFiles.split(',')
        else:
                # Use default names
                inputFiles = (('output/devVal', 'output/subVal', 'output/grpVal'))
        
        # IP address is parameter #2
        HOST1 = sys.argv[2]
        
        print('Input files: ' + str(inputFiles))
        print('IP Address: ' + HOST1)
        
        # May be run right after a system restart.  Need to run a query or two so Rest G/W is in sync
        runCurlCmd('curl -s http://' + HOST1 + ':8080/rsgateway/data/v3/group/query/ExternalId/000000138', validate=False)
        runCurlCmd('curl -s http://' + HOST1 + ':8080/rsgateway/data/v3/group/query/ExternalId/000000138', validate=False)
        
        # Convert input file into output file
        validateInput(inputFiles)
        
#----------------------------------------------------------------
if __name__ == '__main__':
    main()

        
