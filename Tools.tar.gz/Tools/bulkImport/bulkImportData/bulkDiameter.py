#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-12-03T09:30:23
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-12-03T09:30:23
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-12-03T09:30:23

# Python imports
from __future__ import print_function
from __future__ import absolute_import
# from builtins import str
# from builtins import range
from future import standard_library
standard_library.install_aliases()
# from builtins import str
# from builtins import range
import random, time, datetime, sys, copy, pprint
from queue import Queue
import threading

# Local program imports
from . import prim as PRIM
from bulkImportData import data2 as DATA
from . import diameter_utils_base as PKTBASE

# Product imports
import diameter as DIAM

# Service imports
from primitives import  parseDiamDict as PARSEDIAM

# Define session ID
SessionIdNumber = 0

# Setup for a random number (no parameter means to use system time as
# the seed value)
random.seed()

# Define special AVPs (handled outside the normal generic AVP processing)
specialAvps = ['Imsi', 'Msisdn']

# global to store q data
diameterQueue = None
diameterThreadPool = []

# Flag signaling whether diameter threadiong has been invoked
diameterThreadingFlag = False

#===============================================================================
# Function to establish threads
def diameterStartThreads(customData, attr, config, options, object):
        global diameterQueue
        global diameterThreadPool
        global diameterThreadingFlag
        
        # Sanity check that we don't think threads are already started
        if diameterThreadingFlag:
                print('ERROR:  Trrying to start Diameter threads when they\'re already started')
                sys.exit('Exiting Early')
        
        # *** Queue and thread setup ***
        # Set up a queue
        diameterQueue = Queue()

        # Create threads and start them
        for i in range(int(DATA.config['Program']['threadCount'])):
          t = processingThread(i, diameterQueue, customData, attr, config, options, object)
          diameterThreadPool.append(t)
          t.daemon = True
          t.start()
        
        # Set flag signaling threading has started
        diameterThreadingFlag = True
        
#===============================================================================
# Function to wait for threads to end
def diameterStopThreads():
        global diameterQueue
        global diameterThreadPool
        global diameterThreadingFlag
        
        # Sanity check that we don't think threads are already stopped
        if not diameterThreadingFlag:
                print('ERROR:  Trrying to stop Diameter threads when they\'re already stopped')
                sys.exit('Exiting Early')
        
        # Put as many None's in the queue as there are threads, so that each thread gets one
        for t in diameterThreadPool: diameterQueue.put(None)

        # Wait for all threads to exit
        for t in diameterThreadPool: t.join()
        
        # Set flag signaling threading has stoped
        diameterThreadingFlag = False
        
#===============================================================================
# Setup thread for processing the request
class processingThread(threading.Thread):
    def __init__(self, threadNum, queue, customData, attr, config, options, object):
        threading.Thread.__init__(self)
        self.threadNum=threadNum
        self.input_queue=queue

        # Open Diameter connection
        self.diamConnection = diameterGetConnection(customData, attr, config, options, object)

        # Send a CER command
        diameterSendCER(customData, attr, config, self.diamConnection, options, object)
        
    def run(self):
        count = 0
        currentObj = None

        # Open the results file
#        f = open(self.resultsFile+'_'+str(self.threadNum), 'w')

        # Loop
        while True:
                # Get a request from the queue
                item = self.input_queue.get(block=True)
#               print 'Thread %d retrieved from queue %s'%(self.threadNum,str(item))

                # If None, then there will be nothing more and we should exit
                if item is None:
                        print('Thread ' + str(self.threadNum) + ' exiting after processing ' + str(count) + ' records')

                        # Flush/close the output file
#                        f.flush()
#                        f.close()
                        return

                # Bump the count
                count += 1

                # Print progress marker
                if not (count % int(DATA.config['Program']['progressCount'])): print('Thread ' + str(self.threadNum) + ' has processed ' + str(count) + ' records')
                
                # Extract the items that were put
                #print 'item = ' + str(item)
                customData, attr, config, options, object = item
                
                # Grab the area
                area = object['object']

                # Get the command and interface to send
                for field in ['Command', 'Interface']:
                        cmd = field + ' = PRIM.getPrioritizedFieldValue(customData, attr, field, "' + area + '", config, options)'
                        #print 'cmd: ' + str(cmd)
                        exec(cmd)
                
                #print 'Thread ' + str(self.threadNum) + ' received command ' + Command + ' for interface ' + Interface
                
                # Send to appropriate function
                if Interface.lower() == 'gy':
                        if Command.lower() == 'creditcontrol': diameterSendCCR(customData, attr, config, self.diamConnection, options, object)
                        else:
                                print('ERROR:  Unsupported ' + Interface + ' command: ' + Command)
                                sys.exit('Exiting Early')
                else:
                        print('ERROR:  Unsupported interface: ' + Interface)
                        sys.exit('Exiting Early')
                
####################################################################
def getVariableNameFromAvp(avp):
        # Rules:
        #       1) Remove dashes
        #       2) Any leading "3" becomes a "T"
        #       That's all :-)
        lclName = avp.replace('-', '')
        if lclName.startswith('3'): lclName = lclName.replace('3', 'Three')
        #print 'lclName = "' + lclName + '"'
        
        return lclName
        
####################################################################
def initDiameterData():
        # Initialize Diameter data
        PARSEDIAM.main()
        
#       pprint.pprint(PARSEDIAM.avpDict)
        
        # Now push Diameter data into overall tool data, so all diameter AVPs are tool parameters.
        for app in PARSEDIAM.avpDict:
                if PARSEDIAM.avpDict[app]['type'] != 'application': continue
                for command in PARSEDIAM.avpDict[app]['commands']:
                        for message in PARSEDIAM.avpDict[app]['commands'][command]['msgType']:
                                for category in PARSEDIAM.avpDict[app]['commands'][command]['msgType'][message]:
                                        for (avpName,parent) in PARSEDIAM.avpDict[app]['commands'][command]['msgType'][message][category]['avp']:
#                                               print 'Looking at AVP name: ' + avpName
                                                lclVarName = getVariableNameFromAvp(avpName)
#                                               print 'Looking at local variable: ' + lclVarName
                                                if lclVarName not in DATA.CONFIGDATA['Diameter']: DATA.CONFIGDATA['Diameter'][lclVarName] = 'string'

####################################################################
def massageDateFormats(strTime):
        # Time always comes after character 11
        separator = strTime[10]
        dateValue = strTime.split(separator)[0]
        timeValue = strTime.split(separator)[1]
        #print 'Date_Time = ' + dateValue + '_' + timeValue
                                        
        # For now, assume HH:MM:SS
        separator = strTime[13]
        hour = timeValue.split(separator)[0]
        min  = timeValue.split(separator)[1]
        sec  = timeValue.split(separator)[2]
                                        
        # Split apart the input data
        if DATA.config['Program']['dateFormat'].lower()[0] == 'd':
                # First item is the day
                separator = dateValue[2]
                day = dateValue.split(separator)[0]
                                                
                # Do the rest within each case...
                if DATA.config['Program']['dateFormat'].lower()[3] == 'm':
                        month = dateValue.split(separator)[1]
                        year  = dateValue.split(separator)[2]
                else:
                        month = dateValue.split(separator)[2]
                        year  = dateValue.split(separator)[1]
        elif DATA.config['Program']['dateFormat'].lower()[0] == 'm':
                # First item is the month
                separator = dateValue[2]
                month = dateValue.split(separator)[0]
                                                
                # Do the rest within each case...
                if DATA.config['Program']['dateFormat'].lower()[3] == 'd':
                        day   = dateValue.split(separator)[1]
                        year  = dateValue.split(separator)[2]
                else:
                        day   = dateValue.split(separator)[2]
                        year  = dateValue.split(separator)[1]
        else:
                # First item is the year
                separator = strTime[4]
                year = dateValue.split(separator)[0]
                                        
                # Do the rest within each case...
                if DATA.config['Program']['dateFormat'].lower()[5] == 'd':
                        day    = dateValue.split(separator)[1]
                        month  = dateValue.split(separator)[2]
                else:
                        day    = dateValue.split(separator)[2]
                        month  = dateValue.split(separator)[1]
                                        
        # Build time in the format required by this tool
        dateSep = "-"
        timeSep = ":"
        fieldSep = 'T'
        strTime = year + dateSep + month + dateSep + day + fieldSep + hour + timeSep + min + timeSep + sec
        
        #print 'Return new time: ' + strTime
        return strTime
                                        
####################################################################
def buildDiameterMessage(diamPacket, appName, cmdName, message, area, customData, attr, config, options):
        global SessionIdNumber
        groupsCreated = []
        topLevelGroups = []
        listsCreated = {}
        
        if options.debug: print('cmdName: ' + cmdName)
        
        # Create locals for all parameters
        for field in list(DATA.CONFIGDATA[area].keys()):
                cmd = field + ' = PRIM.getPrioritizedFieldValue(customData, attr, field, "' + area + '", config, options)'
                if options.debug: print('cmd: ' + str(cmd))
                exec(cmd)

        # Use diameter data to see which AVPs amy be required
        for category in ['fixed', 'required', 'optional']:
                # Not all categories defined for all messages
                if category not in PARSEDIAM.avpDict[appName]['commands'][cmdName]['msgType'][message]: continue
                
                # Process avps
                if options.debug: print('Diameter dictionary for ' + cmdName + '/' + message + '/' + category + ': ' + str(PARSEDIAM.avpDict[appName]['commands'][cmdName]['msgType'][message][category]['avp']))
                for (avpName,parent) in PARSEDIAM.avpDict[appName]['commands'][cmdName]['msgType'][message][category]['avp']:
                        # Skip some AVPs that require special processing
                        if avpName in specialAvps: continue
                        
                        # Get local variable that's tied to this AVP
                        lclVarName = getVariableNameFromAvp(avpName)
                        if options.debug:
                                print('AVP ' + avpName + ' tied to variable ' + lclVarName + ' with value ')
                                cmd = "print str(" + lclVarName + ")"
                                exec(cmd)
                                                
                        # If not defined, then clear x
                        x = 1
                        cmd = 'if not ' + lclVarName + ': x = 0'
                        exec(cmd)
                        
                        # If fixed or required, then the variable better exist.
                        if category in ['fixed', 'required'] and not x:
                                print('ERROR:  variable ' + lclVarName + ' is in category ' + category + ' but is not set')
                                sys.exit('Exiting early')
                        
                        # If AVP not defined, then nothing more to do
                        if not x: continue
                        
                        # Set the current level we're processing (each group in the hierasrchy is a new level)
                        level = 0
                        
                        # Always some special processing required...
                        if avpName == 'Session-Id':
                                # Define complete session ID always needed
                                SessionId = SessionIdPrefix + ';' + str(random.randint(1,1073741824)) + ';' + str(SessionIdNumber)
                                SessionIdNumber += 1
        
                        if avpName == 'Event-Timestamp':
                                # Use now if event time not input
                                if not EventTimestamp:
                                        nowTime = time.time()
                                        newTime = datetime.datetime.fromtimestamp(nowTime)
                                        strTime = newTime.strftime('%Y-%m-%dT%H:%M:%S')
                                        if options.debug: print('Using now as the time stamp: ' + strTime)
                                else:
                                        strTime = massageDateFormats(EventTimestamp.strip())
                                        if options.debug: print('Using input as the time stamp: ' + EventTimestamp)
                                
                                # Convert value to proper format
                                EventTimestamp = DIAM.convertStringTimeToDiameterTime(strTime)
        
                        # ** If type is OctetString, then need to convert value ***
                        if PARSEDIAM.avpDict[avpName]['type_name'] == 'OctetString':
                                cmd = lclVarName + ' = DIAM.convertStringToHexStr(' + lclVarName + ')'
                                exec(cmd)
                        
                        # If the AVP is lowest level, then add to the packet
                        if not parent: 
                                cmd = 'diamPacket.appendAvp("' + avpName + '", ' + lclVarName + ')'
                                if options.debug: print('cmd = ' + cmd)
                                exec(cmd)
                                
                                # Continue to next item
                                continue
                        
                        # If here, then processing an AVP that is part of a group
                        child = avpName
                        
                        while parent:
                                # Get local variable that's tied to this AVP
                                childVarName = getVariableNameFromAvp(child)
                        
                                # Get local variable that's tied to this AVP
                                parentVarName = getVariableNameFromAvp(parent)
                        
                                # See if parent list has been started
                                if parent not in groupsCreated:
                                        # Create parent list
                                        cmd = parentVarName + 'List = []'
                                        if options.debug: print('cmd = ' + cmd)
                                        exec(cmd)
                                        
                                        # Add to created group list
                                        groupsCreated.append(parent)
                                        cmd = 'listsCreated["' + parentVarName + 'List"] = None'
                                        exec(cmd)
                                
                                # Add child to parent list
                                cmd = 'if "' + child + '" not in ' + parentVarName + 'List' + ': ' + parentVarName + 'List.append("' + child + '")'
                                if options.debug: print('cmd = ' + cmd)
                                exec(cmd)
                                
                                # Go through all possible groups and build the group lists to the top
                                x = 0
                                for (avpName,newParent) in PARSEDIAM.avpDict[appName]['commands'][cmdName]['msgType'][message][category]['group']:
#                                       print 'Looking at ' + cmdName + ', ' + message + ', ' + category + ', group data (' + str(avpName) + ', ' + str(newParent) + ') for parent ' + parent
                                        # Skip if this is not the one we're processing
                                        if parent == avpName:
                                                # Swap parent/child
                                                child = parent
                                                parent = newParent
                                                x = 1
                                                break
                                        
                        # Store last child as top-level group
                        topLevelGroups.append(child)
        
        # Last order of business is to add the lists to their AVPs and then add the top most lists to the diam packet
        for list in listsCreated:
                cmd = 'listsCreated[list] = ' + list
                if options.debug: print('cmd = ' + cmd)
                exec(cmd)
                
        groupsProcessed = []
        for parent in topLevelGroups:
                # If we already processed this group, then skip it
                if parent in groupsProcessed: continue
                groupsProcessed.append(parent)
                
                # Get local variable that's tied to avp
                parentVarName = getVariableNameFromAvp(parent)
                
                # Get parent structure
                cmd = parentVarName + 'Data = getAvpGroupings(parent, listsCreated, customData, attr, config, options, area)'
                if options.debug: print('cmd = ' + cmd)
                exec(cmd)
                
                # Add to diameter packet
                cmd = 'diamPacket.appendAvpObj(' + parentVarName + 'Data)'
                if options.debug: print('cmd = ' + cmd)
                exec(cmd)
                
        return
        
####################################################################
def getAvpGroupings(parent, listsCreated, customData, attr, config, options, area):
        # Get local variable that's tied to avp
        parentVarName = getVariableNameFromAvp(parent)
                
        # Define structures to store data
        cmd = parentVarName + 'DataList = []'
        if options.debug: print('cmd = ' + cmd)
        exec(cmd)
        
        # Go through each child
        cmd = 'lclList = listsCreated["' + parentVarName + 'List"]'
        if options.debug: print('cmd = ' + cmd)
        exec(cmd)
        
        # Process every child in the list
        for child in lclList:
                # Get local variable that's tied to avp
                childVarName = getVariableNameFromAvp(child)
                
                # If this is the lowest level, then get the data
                if PARSEDIAM.avpDict[child]['type_name'] != 'Grouped':
                        # Create local for this AVP
                        cmd = childVarName + ' = PRIM.getPrioritizedFieldValue(customData, attr, childVarName, "' + area + '", config, options)'
#                       print 'cmd: ' + str(cmd)
                        exec(cmd)
                        
                        # Store into diameter structure
                        cmd = childVarName + 'Data = DIAM.Avp("' + child + '", ' + childVarName + ')'
                        if options.debug: print('cmd = ' + cmd)
                        exec(cmd)
                else:
                        # This is another group.  Iterate to get structures
                        # Get parent structure
                        cmd = childVarName + 'Data = getAvpGroupings(child, listsCreated, customData, attr, config, options, area)'
                        if options.debug: print('cmd = ' + cmd)
                        exec(cmd)
                        
                # Add to data list
                cmd = parentVarName + 'DataList.append(' + childVarName + 'Data)'
                if options.debug: print('cmd = ' + cmd)
                exec(cmd)
        
        # Now build the parent Data from the Data list that was just constructucted
        cmd = parentVarName + 'Data = DIAM.Avp("' + parent + '",' + parentVarName + 'DataList)'
        if options.debug: print('cmd = ' + cmd)
        exec(cmd)
        
        # Not sure one can issue a return from inside an exec, so copy data to a local and return the local     
        cmd = 'returnData = copy.deepcopy( ' + parentVarName + 'Data)'
        if options.debug: print('cmd = ' + cmd)
        exec(cmd)
        
        return returnData
        
####################################################################
def buildFixedDiameterCcrMessage(appName, cmdName, message, area, customData, attr, config, options):
        
        # Default message contents
        diamInput={'Application': 'RCF','Auth-Application-Id': '4', 'Service-Information|PS-Information|3GPP-MS-TimeZone': '0000', 'Multiple-Services-Credit-Control|Rating-Group': '1', 'CC-Request-Type': '3', 'Event-Timestamp': 3681056149, 'Subscription-Id|Subscription-Id-Type': '1', 'CC-Request-Number': '1', 'Destination-Realm': 'destrealm.net', 'Session-Id': 'MATRIXX-QA-TESTING.;1;983453419', 'User-Name': '10', 'Subscription-Id|Subscription-Id-Data': '10', 'Service-Information|PS-Information|Called-Station-Id': '12345678901', 'Service-Information|PS-Information|Start-Time': 3681056149, 'Multiple-Services-Indicator': '1', 'Origin-Realm': 'MATRXIX-INFINITY-REALM', 'Service-Context-Id': 'version1.clci.ipc@vodafone.com', 'Origin-Host': 'MATRIXX-INFINITY-HOST', 'Multiple-Services-Credit-Control|Used-Service-Unit|CC-Total-Octets': '1', 'Multiple-Services-Credit-Control|Requested-Service-Unit|CC-Total-Octets': '1', '3GPP-SGSN-MCC-MNC': '99999'}

        # Create locals for all parameters
        for field in list(DATA.CONFIGDATA[area].keys()):
                cmd = field + ' = PRIM.getPrioritizedFieldValue(customData, attr, field, "' + area + '", config, options)'
                if options.debug: print('cmd: ' + str(cmd))
                exec(cmd)
        
        # Override with data from input file
        for pair in [(AuthApplicationId, 'Auth-Application-Id'), (DestinationRealm, 'Destination-Realm'), (RatingGroup, 'Multiple-Services-Credit-Control|Rating-Group'), (CCTotalOctets, 'Multiple-Services-Credit-Control|Requested-Service-Unit|CC-Total-Octets'), (CCTotalOctets, 'Multiple-Services-Credit-Control|Used-Service-Unit|CC-Total-Octets'), (ThreeGPPSGSNMCCMNC, '3GPP-SGSN-MCC-MNC')]:
                # Separate values
                (variable, key) = pair
                
                # If variable defined, use it
                if variable: diamInput[key] = variable
        
        # Handle IMSI vs MSISDN for sub ID
        if Imsi:
                diamInput['Subscription-Id|Subscription-Id-Type'] = '1'
                diamInput['Subscription-Id|Subscription-Id-Data'] = Imsi
                diamInput['User-Name'] = Imsi
        else:
                diamInput['Subscription-Id|Subscription-Id-Type'] = '0'
                diamInput['Subscription-Id|Subscription-Id-Data'] = Msisdn
        
        # Timestamp
        # Use now if event time not input
        if not EventTimestamp:
                nowTime = time.time()
                newTime = datetime.datetime.fromtimestamp(nowTime)
                strTime = newTime.strftime('%Y-%m-%dT%H:%M:%S')
                if options.debug: print('Using now as the time stamp: ' + strTime)
        else:
                strTime = massageDateFormats(EventTimestamp.strip())
                if options.debug: print('Using input as the time stamp: ' + EventTimestamp)
        
        # Convert value to proper format
        EventTimestamp = DIAM.convertStringTimeToDiameterTime(strTime)
        diamInput['Event-Timestamp'] = EventTimestamp
        diamInput['Service-Information|PS-Information|Start-Time'] = EventTimestamp
        
        return diamInput
        
####################################################################
def diameterSendCCR(customData, attr, config, diamConnection, options, object):
        global SessionIdNumber
        
        # Grab the area
        area = object['object']

        # Setup data items specific to this message
        cmdName = 'Credit-Control'
        appName = 'Credit-Control'
        message='request'
        
        # Setup basic diameer packet
        tree = None
        tree = PKTBASE.diamPacket(False, msgId=272, hopByHopId=1001, endToEndId=2001, appId=4, answerFlag=False)
        
        # Build the packet
        diamPacket ={}
        diamPacket = buildFixedDiameterCcrMessage(appName, cmdName, message, area, customData, attr, config, options)
        if options.debug: pprint.pprint(diamPacket)
        
        # Move data from dictionary to diameter structure
        tree.createTree(diamPacket)
        
        # Build the Diameter packet
        diamPacket = tree.createDiamTree()
        
        # Debug output
        if options.debug: 
                print('\nSending CCR Message')
                print("="*50)
                print(diamPacket)
        
        # Send it out.  Don't validate response.
        diamResp = diamConnection.send(diamPacket)
        
        return
        
        # ***************************** OLD CODE ********************************************************
        #diamPacket = DIAM.createPacket(int(PARSEDIAM.avpDict[appName]['code']), int(PARSEDIAM.avpDict[appName]['commands'][cmdName]['code']) + DIAM.CmdFlagRequest, 1001, 2001)
        # Now build the message
        #buildDiameterMessage(diamPacket, appName, cmdName, message, area, customData, attr, config, options)
        
        # Create locals for special parameters
        for field in specialAvps:
                cmd = field + ' = PRIM.getPrioritizedFieldValue(customData, attr, field, "' + area + '", config, options)'
#               print 'cmd: ' + str(cmd)
                exec(cmd)

#               cmd = 'print field + " = " + str(' + field + ')'
                exec(cmd)
        
        # Some data set based on IMSI vs MSISDN
        if Imsi:
                diamPacket.appendAvp('User-Name', Imsi)
                diamPacket.appendAvpObj(DIAM.Avp('Subscription-Id',
                        [
                            DIAM.Avp('Subscription-Id-Type', '1'),
                            DIAM.Avp('Subscription-Id-Data', Imsi),
                        ]))
        else:
                diamPacket.appendAvp('User-Name', Msisdn)
                diamPacket.appendAvpObj(DIAM.Avp('Subscription-Id',
                        [
                            DIAM.Avp('Subscription-Id-Type', '0'),
                            DIAM.Avp('Subscription-Id-Data', Msisdn),
                        ]))
        
#       print '\nSending CCR Message'
        
        # Send it out.  Don't validate response.
        diamResp = diamConnection.send(diamPacket)
        
        return 
        
####################################################################
def diameterSendCER(customData, attr, config, diamConnection, options, object):
        area = object['object']

        # Setup data items specific to this message
        cmdName = 'Capabilities-Exchange'
        appName = 'Common'
        message = 'request'
        
        # Create the input data
        diamPacket = DIAM.createPacket(int(PARSEDIAM.avpDict[appName]['code']), int(PARSEDIAM.avpDict[appName]['commands'][cmdName]['code']) + DIAM.CmdFlagRequest, 1001, 2001)
        
        # Now build the message
        buildDiameterMessage(diamPacket, appName, cmdName, message, area, customData, attr, config, options)
        
#       print '\nSending CER Message'
        
        # Send it out.  Don't validate response.
        diamResp = diamConnection.send(diamPacket)
        
####################################################################
def diameterGetConnection(customData, attr, config, options, object):
        area = object['object']

        # Create locals for onl;y few required by this function (versus all possible parameters)
        for field in ['IpAddress', 'Port']:
                cmd = field + ' = PRIM.getPrioritizedFieldValue(customData, attr, field, "' + area + '", config, options)'
                exec(cmd)

        diamConnection = DIAM.DiameterClientConnection(IpAddress, int(Port), tracePackets = False)
        
        # Check for errors
        if not diamConnection:
                print('ERROR:  Failed in diameter client connection call')
                sys.exit('Exiting Early')
        
        # Open the connection
        diamConnection.open()
        
        return diamConnection

# ------------------------------------------------------------------------------
#  MAIN
# ------------------------------------------------------------------------------
def main():

        print('Hello')

if __name__ == '__main__':
        main()

