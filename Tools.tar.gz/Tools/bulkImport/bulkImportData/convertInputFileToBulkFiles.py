#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-12-03T09:30:24
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-12-03T09:30:24
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-12-03T09:30:24

# Product imports
from __future__ import print_function
from __future__ import absolute_import
# from builtins import str
from future import standard_library
standard_library.install_aliases()
# from builtins import str
import subscriber_mgmt_v3 as subman
import data_container_defs as MDCDEFS

# Python imports
from datetime import datetime
import time, sys, os, subprocess, traceback, pprint
try:
    import configparser
except:
    from six.moves import configparser

# Local program imports
from . import parseRecord       as REC
from . import data2             as DATA
from . import mdcPrim           as MDC
from . import logic             as LOGIC
from . import bulkDiameter as BULKDIAM

# Offer list (global so we only read it once)
offerList = {}

import time
import functools

# Define decorator
def clock2(func):
        # Get name of caller
        @functools.wraps(func)
        def clocked(*args, **kwargs):
                t0 = time.time()
                result = func(*args, **kwargs)
                elapsed = time.time() - t0
                print('Elapsed time for function = ' + func.__name__ + ': ' + str(elapsed))
                return result
        return clocked

# ------------------------------------------------------------------------------
#@clock2
def processOperation(operation, object, customData, attr, config, submanBuilder, options, getResourceIds, inputFile=None):
#       print 'processing operation ' + str(operation) + ' with input data: ' + str(attr)
        
        # Slight hack here.,  If doing resource IDs then only want to do for the object type in attr
        if operation.count('GetResourceIds'):
                # See if match 
                for key in list(attr.keys()):
                        if (operation.startswith('Subscriber')  and key.startswith('Subscriber')) or \
                           (operation.startswith('User')        and key.startswith('User'))       or \
                           (operation.startswith('Group')       and key.startswith('Group')):
                                break
                else: return True, True
         
        # Put stuff in locals (for ease of understanding)
        area = object['object']
        
        # See if we're not supposed to do the operation 
        if not config['Operations'][operation]:
                #print 'Skipping operation due to config file Operations section set to False'
                return True, True
        
        # If here, then we have data to process (or the input data isn't valid)
        if 'queryValue' not in object or 'queryType' not in object:
                # If we're getting resource IDs, then may have some empty structures
                if getResourceIds: return True, True
                
                # Not all objects have an external ID...
                object['queryValue'] = object['queryType'] = 'None'
                '''
                # If here, then data is wrong...
                print 'ERROR:  input data not setup properly.  object = ' + str(object)
                print 'Operation: ' + operation + ', config for this operation: ' + str(config['Operations'][operation])
                traceback.print_stack()
                return False, False
                '''
        
        #----------------- Run Logic            ---------------
        if not LOGIC.runLogic(config, REC.attr, object):
                print('Skipping operation due to logic condition evaluating to False')
                return True, True
                
        # Debug output
        if options.verbose_flag: print(operation + ' with ' + object['queryType'] + ': ' + object['queryValue'])
#       else:                    print operation + ' with ' + object['queryType'] + ': ' + object['queryValue']
                
        # If a diameter event
        if   operation.lower() == 'diameter': op = 'Diameter'
        elif operation.lower() == 'cb'      : op = 'CB'
        else:                                 op = operation[len(area):]
        
        # Setup command
        cmd = 'retCode = MDC.' + op + '(customData, attr, config, submanBuilder, options, object'
        
        # Add extra parameter for some calls
        if operation.lower() == 'cb': cmd += ', inputFile=inputFile'
        
        # Close command
        cmd += ')'
        
        # Execute the command
        #print 'cmd = ' + cmd
        exec(cmd)
                
        return True, False
        
# ------------------------------------------------------------------------------
def getObjectData(operation, attr, config):
        '''
        print 'getObjectData: operation ' + str(operation)
        pprint.pprint(attr)
        '''
        
        # Define order of precedence of input fields
        diameterPriorityFields = ['DiameterImsi', 'DiameterMsisdn']
        devicePriorityFields = ['DeviceExternalId', 'DeviceImsi', 'DeviceMsisdn', 'ObjectId']
        subscriberPriorityFields = ['SubscriberExternalId', 'SubscriberObjectId', 'DeviceImsi', 'DeviceMsisdn']
        subscriberParentPriorityFields = ['SubscriberExternalId', 'SubscriberObjectId']
        groupPriorityFields = ['GroupExternalId', 'GroupObjectId']
        groupSubPriorityFields = ['GroupSubExternalId', 'GroupSubObjectId']
        userPriorityFields = ['UserExternalId', 'UserObjectId']
        
        retData = {}
        
        # What object is this
        name = 'CB'
        if operation.startswith(name):
                if name in DATA.config:
                        for key in list(DATA.config.keys()):
                                if DATA.config[key]: retData[key] = DATA.config[key]
                
                # Just need dummy data to get through sanity checks
                retData['object'] = name
                retData['queryValue'] = retData['queryType'] = None
                
        name = 'Diameter'
        if operation.startswith(name):
                retData['object'] = name
                
                # Need key field data.  Check in priority order
                retData['queryValue'] = None
                for keyField in diameterPriorityFields:
                        if keyField in attr:
                                retData['keyField'] = keyField
                                retData['queryValue'] = attr[keyField]
                                
                                # Get query type value
                                if   keyField.count('Imsi'):    retData['queryType'] = 'PhoneNumber'
                                else:                           retData['queryType'] = 'AccessNumber'
                                break
        
        name = 'Device'
        if operation.startswith(name):
                retData['object'] = name
                
                # Need key field data.  Check in priority order
                retData['queryValue'] = None
                for keyField in devicePriorityFields:
                        if keyField in attr:
                                retData['keyField'] = keyField
                                retData['queryValue'] = attr[keyField]
                                
                                # Get query type value
                                if   keyField.count('Imsi'):    retData['queryType'] = 'PhoneNumber'
                                elif keyField.count('Msisdn'):  retData['queryType'] = 'AccessNumber'
                                elif keyField.count('ObjectId'):retData['queryType'] = 'ObjectId'
                                else:                           retData['queryType'] = 'ExternalId'
                                break
        
                # May need subscriber parent data.  Check in priority order
                retData['SubscriberQueryValue'] = None
                for keyField in subscriberParentPriorityFields:
                        if keyField in attr:
                                retData['SubscriberKeyField'] = keyField
                                retData['SubscriberQueryValue'] = attr[keyField]
                                
                                # Get query type value
                                if   keyField.count('ObjectId'):retData['SubscriberQueryType'] = 'ObjectId'
                                else:                           retData['SubscriberQueryType'] = 'ExternalId'
                                break
        
        name = 'User'
        if operation.startswith(name):
                retData['object'] = name
                
                # Need key field data.  Check in priority order
                retData['queryValue'] = None
                for keyField in userPriorityFields:
                        if keyField in attr:
                                retData['keyField'] = keyField
                                retData['queryValue'] = attr[keyField]
                                
                                # Get query type value
                                if keyField.count('ObjectId'):  retData['queryType'] = 'ObjectId'
                                else:                           retData['queryType'] = 'ExternalId'
                                break
                
                # May need group parent field data.  Check in priority order
                retData['GroupQueryValue'] = None
                for keyField in groupPriorityFields:
                        if keyField in attr:
                                retData['GroupKeyField'] = keyField
                                retData['GroupQueryValue'] = attr[keyField]
                                
                                # Get query type value
                                if   keyField.count('ObjectId'):retData['GroupQueryType'] = 'ObjectId'
                                else:                           retData['GroupQueryType'] = 'ExternalId'
                                break
        
        name = 'Subscriber'
        if operation.startswith(name):
                '''
                # Copy fixed parameters to attr so commands can use them
                if name+name in DATA.config:
                        for key in DATA.config[name+name].keys():
                                if DATA.config[name+name][key]: attr[name+key] = DATA.config[name+name][key]
                '''
                
                retData['object'] = name
                
                # Need key field data.  Check in priority order
                retData['queryValue'] = None
                for keyField in subscriberPriorityFields:
                        if keyField in attr:
                                retData['keyField'] = keyField
                                retData['queryValue'] = attr[keyField]
                                
                                # Get query type value
                                if   keyField.count('Imsi'):    retData['queryType'] = 'PhoneNumber'
                                elif keyField.count('Msisdn'):  retData['queryType'] = 'AccessNumber'
                                elif keyField.count('ObjectId'):retData['queryType'] = 'ObjectId'
                                else:                           retData['queryType'] = 'ExternalId'
                                break
                
                # If a balance command, then set some object fields
                if operation.count('Balance'):
                        '''
                        print 'config[' + name + ']:'
                        pprint.pprint(config[name])
                        '''
                        # Copy additional fields if passed in or statically defined
                        for key in ['ResourceIds', 'TemplateId', 'Reason', 'Info', 'AdjustType', 'EndTime', 'EndTimeExtensionOffsetUnit', 'EndTimeExtensionOffset']:
                                lclData = None
                                try:    lclData = config[name][key]
                                except: pass
                                try:
                                        if not lclData and attr[name+key]: lclData = attr[name+key]
                                except: pass
                                                
                                #print 'Setting key ' + key + ' to ' + str(lclData)
                                retData[key] = lclData
                        
                        # If neither template ID or resource ID passed in, then error
                        if not retData['TemplateId'] and not retData['ResourceIds']: sys.exit('ERROR: A balance command needs to specify either the template or the resource ID (or both)')
                
                # If import, then set some values
                if operation.count('ImportBalance'):
                        if name+'OnDemand' in attr:
                                retData['OnDemand'] = attr[name+'OnDemand']
                        else:   retData['OnDemand'] = False
                
                # May need group parent field data.  Check in priority order
                retData['GroupQueryValue'] = None
                for keyField in groupPriorityFields:
                        if keyField in attr:
                                retData['GroupKeyField'] = keyField
                                retData['GroupQueryValue'] = attr[keyField]
                                
                                # Get query type value
                                if   keyField.count('ObjectId'):retData['GroupQueryType'] = 'ObjectId'
                                else:                           retData['GroupQueryType'] = 'ExternalId'
                                break
        
                # May need user parent field data.  Check in priority order
                retData['UserQueryValue'] = None
                for keyField in userPriorityFields:
                        if keyField in attr:
                                retData['UserKeyField'] = keyField
                                retData['UserQueryValue'] = attr[keyField]
                                
                                # Get query type value
                                if   keyField.count('ObjectId'):retData['UserQueryType'] = 'ObjectId'
                                else:                           retData['UserQueryType'] = 'ExternalId'
                                break
        name = 'Group'
        if operation.startswith(name):
                retData['object'] = name
                
                # Need key field data.  Check in priority order
                retData['queryValue'] = None
                for keyField in groupPriorityFields:
                        if keyField in attr:
                                retData['keyField'] = keyField
                                retData['queryValue'] = attr[keyField]
                                
                                # Get query type value
                                if   keyField.count('ObjectId'):retData['queryType'] = 'ObjectId'
                                else:                           retData['queryType'] = 'ExternalId'
                                break
        
                # May need sub group child field data.  Check in priority order
                retData['GroupQueryValue'] = None
                for keyField in groupSubPriorityFields:
                        if keyField in attr:
                                retData['GroupKeyField'] = keyField
                                retData['GroupQueryValue'] = attr[keyField]
                                
                                # Get query type value
                                if   keyField.count('ObjectId'):retData['GroupQueryType'] = 'ObjectId'
                                else:                           retData['GroupQueryType'] = 'ExternalId'
                                break
        
                # If a balance stop, then set threshold value.
                # Why set threshold ID??  Code change to look at template ID.  Really should be that...
                if operation.count('StopBalance') and name+'TemplateId' in attr:
                        retData['ThresholdId'] = retData['TemplateId'] = attr[name+'TemplateId']
                
                # If import, then get OnDemand value
                if operation.count('ImportBalance'):
                        if name+'OnDemand' in attr:
                                retData['OnDemand'] = attr[name+'OnDemand']
                        else:   retData['OnDemand'] = False
                
        # Return data here
        '''
        print 'getObject return data:'
        pprint.pprint(retData)
        '''
        return retData
                        
# ------------------------------------------------------------------------------
#  MAIN
# ------------------------------------------------------------------------------
def convertInputFileToBulkFiles(inputFile, config, operations, getResourceIds=False):
        global offerList
        
        release = int(config['Program']['release'][0:2])
        
        # Setup resource ID list
        resourceOperations = ['SubscriberGetResourceIds', 'GroupGetResourceIds']
        
        # Start time for statistical reasons
        start_time = datetime.now()
        start_time_str = start_time.strftime('%d-%b-%YT%H-%M-%S')

        batchRecordCount = 0        # Number of Record processed
        
        # Open the Output MDC and Error files
        files = DATA.open_files(start_time_str)
        
        # If offers file was input, then read the records
        if DATA.options.offers and not len(offerList):
                # Open the file
                f = open(DATA.options.offers, 'r')
                
                # Add enries to the dictionary (as using "in" is faster than using "count").
                # Remove trailing newline character from line read.
                for line in f: offerList[line[:-1]] = 1
                
                # Debug output
                print('Number of offers found: ' + str(len(offerList)))
                
                # Close the file
                f.close()
        
        # Open the input CSV file
        in_file = open(inputFile, 'r')
        allLines = in_file.readlines()
        in_file.close()
        print('Read ' + str(len(allLines)) + ' lines from file ' + inputFile)
        #sys.exit('Exiting early')
        
        if DATA.options.verbose_flag:
                print("CSV input file opened:")
                print(in_file)

        # Process the input file
        lineCount = 0
        rawLineCount = 0
        for line in allLines:
                #print 'Processing record #' + str(lineCount) + ": time: " + datetime.now().strftime("%S.%f")
                
                # Remove white space around the line
                line = line.strip()
                
                # Update raw line count
                rawLineCount += 1
                
                # if empty or comment line or a short line, then skip.  [Short line comes from migration pasting o ffiles with blank lines - then only th epast separator there.]
                if (line == '') or (line[0] == '#') or (len(line) < 3): continue
                
                # Increment line count
                lineCount += 1
                
                # Debug progress
                #print 'Processing record # ' + str(lineCount)
                if not (lineCount % int(config['Program']['progressCount'])):
                        print('Processing record #' + str(lineCount) + ": Current date and time: " + datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"))
                
                # Metrics
                DATA.recordNumber += 1
                batchRecordCount +=1
                
                # For test purposes, stop at low number
                if DATA.recordNumber > int(config['Program']['stopEarlyRecordCount']):
                        print('Exiting due to ' + config['Program']['stopEarlyRecordCount'] + ' records reached')
                        break
                
                # Parse the input line
                (retCode, retText) = REC.parseRecord(offerList, line, DATA.offerRemap, validateFlag = config['Program']['inputValidation'], inputList = config['Program']['input'].split(',')) 
                if not retCode:
                        # Record line we're going to skip
                        print('# Input file line: ' + str(rawLineCount), file=DATA.skip_file)
                        print('# ' + retText, file=DATA.skip_file)
                        print(line + '\n', file=DATA.skip_file)
                        
                        # Skip if validation fails
                        print('Skipped record number ' + str(DATA.recordNumber) + ' due to: ' + retText)
                        continue
                
                ######################## Got a new line to process #####################################
                
                #----------------- Determine operations ---------------
                # User could have added operations to the line.  Honor that.
                #print "Step A: time: " + datetime.now().strftime("%S.%f")
                if ('operation' in REC.attr and REC.attr['operation']) or getResourceIds:
                        # Resource Ids are higher priority than input command line (as it's a global setting)
                        if getResourceIds: operationList = resourceOperations
                        else:              operationList = REC.attr['operation'].split(config['Program']['inputListSeparator'])
                        
                        # Save the operations and set to True
                        savedOperStatus = True
                        savedOperValue = []
                        for operation in operationList:
                                savedOperValue.append((operation, config['Operations'][operation]))
                                config['Operations'][operation] = True
                else:
                        operationList = operations
                        savedOperStatus = False
                
                #----------------- Process the record ---------------
                #print "Step B: time: " + datetime.now().strftime("%S.%f")
                for operation in operationList:
                        #print 'Checking operation: ' + operation
                        # Skip the "Logic" operation itself.  This is a flag for checking logic; not a command to execute.
                        # Add elif as this is what processOperation() checks and returns if not.  
                        if operation.count('Logic'): continue
                        elif (not config['Operations'][operation]) and (not operation.count('GetResourceIds')): continue
                        
                        # Get object data
                        #print 'REC.attr:'
                        #pprint.pprint(REC.attr)
                        
                        # Get data for this command
                        object = getObjectData(operation, REC.attr, config)
                        
                        # Debug output
                        #print 'Processing operation ' + operation + ' with object data: ' + str(object)
                        
                        # Process the item
                        (retCode, skipFlag) = processOperation(operation, object, DATA.customData, REC.attr, config, DATA.submanBuilder, DATA.options, getResourceIds, inputFile=inputFile)
                        if not retCode:
                                print('ERROR:  processOperation returned failure.  Aborting conversion.')
                                return False,lineCount
                        
                        # If doing CB work, then we only want to ever look at the first line
                        if operation.lower() == 'cb' and not skipFlag: return True,lineCount
                
                # Restore operational status if changed
                #print "Step C: time: " + datetime.now().strftime("%S.%f")
                if savedOperStatus:
                        for (operation, value) in savedOperValue: config['Operations'][operation] = value
                        savedOperStatus = False
                
        # Write the last batch to files
        for operation in DATA.MDCLIST: DATA.writeSingleFile(operation)

        # Close file handlers
        DATA.close_files(files)
        
        # If Diameter threading was started, then close that 
        if BULKDIAM.diameterThreadingFlag: BULKDIAM.diameterStopThreads()
        
        # Done
        return True,lineCount
        
# ------------------------------------------------------------------------------
#  MAIN
# ------------------------------------------------------------------------------
def main():
        print('hello')

if __name__ == '__main__':
        main()

