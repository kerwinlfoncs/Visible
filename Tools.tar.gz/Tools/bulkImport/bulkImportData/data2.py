#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-12-03T09:30:25
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-12-03T09:30:25
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-12-03T09:30:25
from __future__ import print_function
# from builtins import str
import subscriber_mgmt_v3 as subman
from primitives import primGeneric as GENERIC

# Structure to hold config data
config = None

# MDC list.  Details of whether or not the specific action occurs will be configured in the config.ini file
MDCLIST = []

# Move from fileIo (circular references)
# Define output directory + base file name
outputFileDirAndName = ''

# File counter (so each file is unique)
FileCounter = 0

# Misc variables
recordNumber =  0       # Total lines processed
options = None          # Input options
args = None             # Input arguments
mdcList={}              # Structure that holds the accumulated MDC data
objectList = {}         # Lists of identified devices/subscribers/groups
submanBuilder = subman.SubscriberManagementV3Client(mode='BuildMessage')
error_file = None       # Error_file
skip_file = None        # list of lines that were skipped file
outputFileDir = 'output'# directory where output files are stored
StatusMap = {}          # MTX device status mapping
customData = None       # Stores dictionary of per-object custom fields
dataAlreadyInit = 0     # FLag to address repeat option (so we don't read input more than once)
diameterProcessed = False # Flag to signal if Diameter already processed
        
# The following defines the old offer name = new offer name.  This facilitates offer remapping.
offerRemap = {}
# Example entry
#offerRemap['GPRS/WAP 1GB data bonus Bundle'] = 'GPRS WAP 1GB Data Bonus add on Bundle'

# Values for last referenced object external IDs
#ObjectReferencedValues = {}
#ObjectReferencedValues['Subscriber'] = {'First':0, 'Last':0}
#ObjectReferencedValues['Group'] = {'First':0, 'Last':0}
#ObjectReferencedValues['DeviceImsi'] = {'First':0, 'Last':0}
#ObjectReferencedValues['DeviceMsisdn'] = {'First':0, 'Last':0}

sections = ['Subscriber', 'Group', 'Device', 'Offer', 'Diameter', 'CB', 'User']

# Non-API parameters common for all objects
defaultObjectEntries = { 
                        'Verify':'binary',
                       }
'''
                        'RequiredOffers':'string',
                        'OptionalOffers':'string',
                        'InputOffers':'string',
                        'ModifyOffers':'string',
                        'CancelOffers':'string',
                        'ResourceIds':'string',
                        'NewExternalId':'string',
                        'VerifyBalance':'string',
                        'Logic':'string',
                        'TemplateId':'string',
                       }
'''
defaultObjects = ['Subscriber', 'Group', 'Device', 'User']
      
# Here's the structure that defines what should be verified
VerifyObject = {}
for area in defaultObjects: VerifyObject[area] = {}

# Define allowed sections and each parameter in the section.
# Also identify the parameter type (for validation purposes).
# Code will add in custom paramerters and types when doing the overall validation.
#
# NOTE: These are common parameters across all releases as well as per-release deltas.
#       The code won't call an API with a wrong parameter, but the framework will allow one to set a parameter 
#       that's not applicable to the release value set in the config file. 
CONFIGDATA = {}
CONFIGDATA['Range']    = {'SubscriberExternalId':'integer',
                          'SubscriberExternalIdDelta':'integer',
                          'GroupExternalId':'integer',
                          'GroupExternalIdDelta':'integer',
                          'DeviceImsi':'integer',
                          'DeviceImsiDelta':'integer',
                          'DeviceMsisdn':'integer',
                          'DeviceMsisdnDelta':'integer',
                          'UserExternalId':'integer',
                          'UserExternalIdDelta':'integer',
                         }
CONFIGDATA['Rest']     = {'hostname':'string',
                          'hostport':'integer',
                         }
CONFIGDATA['Program']  = {'stopEarlyRecordCount':'string',
                          'inputValidation':'binary',
                          'postImportQuery':'binary',
                          'preImportQuery':'binary',
                          'skipDelete':'binary',
                          'batchSize':'integer',
                          'progressCount':'integer',
                          'optionalOfferNoExpire':'binary',
                          'requiredOfferNoExpire':'binary',
                          'executeFiles':'binary',
                          'convertFiles':'binary',
                          'executeFileDelay':'integer',
                          'pauseForHumanInput':'binary',
                          'pauseOnErrors':'binary',
                          'outputValidationFilter':'string',
                          'input':'string',
                          'release':'integer',
                          'inputSeparator':'string',
                          'inputListSeparator':'string',
                          'threadCount':'integer',
                          'dateFormat':'string',
                         }

# Every command supported.  Really should build dynamically...
CONFIGDATA['Operations'] = {'DeviceCreate':'binary',
                            'DeviceAddToSubscriber':'binary',
                            'DeviceRequiredOffers':'binary',
                            'DeviceOptionalOffers':'binary',
                            'DeviceInputOffers':'binary',
                            'DeviceModify':'binary',
                            'DeviceModifyOffers':'binary',
                            'DeviceCancelOffers':'binary',
                            'DeviceQueryPre':'binary',
                            'DeviceQueryPost':'binary',
                            'DeviceLogic':'binary',
                            'SubscriberCreate':'binary',
                            'SubscriberAddToGroup':'binary',
                            'SubscriberRemoveFromGroup':'binary',
                            'SubscriberRequiredOffers':'binary',
                            'SubscriberOptionalOffers':'binary',
                            'SubscriberInputOffers':'binary',
                            'SubscriberModify':'binary',
                            'SubscriberStopBalance':'binary',
                            'SubscriberAdjustBalance':'binary',
                            'SubscriberModifyOffers':'binary',
                            'SubscriberCancelOffers':'binary',
                            'SubscriberQueryPre':'binary',
                            'SubscriberQueryPost':'binary',
                            'SubscriberModifyThreshold':'binary',
                            'SubscriberGetResourceIds':'binary',
                            'SubscriberLogic':'binary',
                            'GroupGetResourceIds':'binary',
                            'GroupModifyThreshold':'binary',
                            'GroupCreate':'binary',
                            'GroupAddToGroup':'binary',
                            'GroupRequiredOffers':'binary',
                            'GroupOptionalOffers':'binary',
                            'GroupInputOffers':'binary',
                            'GroupQueryPre':'binary',
                            'GroupQueryPost':'binary',
                            'GroupModify':'binary',
                            'GroupStopBalance':'binary',
                            'GroupAdjustBalance':'binary',
                            'GroupModifyOffers':'binary',
                            'GroupCancelOffers':'binary',
                            'GroupLogic':'binary',
                            'Diameter':'binary',
                            'DiameterLogic':'binary',
                            'CB':'binary',
                            'CBLogic':'binary',
                            'SubscriberImportBalance':'binary',
                            'GroupImportBalance':'binary',
                            'UserLogic':'binary',
                            'UserCreate':'binary',
                            'UserModify':'binary',
                            'UserQueryPre':'binary',
                            'UserQueryPost':'binary',
                            'SubscriberAddToUser':'binary',
                            'GroupDelete':'binary',
                            'SubscriberDelete':'binary',
                            'DeviceDelete':'binary',
                            'UserDelete':'binary',
                            'UserQuery':'binary',
                            'SubscriberQuery':'binary',
                            'DeviceQuery':'binary',
                           }

# Per-object special parameters.  There shouldn;t be many of these.  Code below adds all parameters for the various subman calls that the tool may make.
CONFIGDATA['Group'] = {
                        'BillCycleId':'integer',
                        'BillCycleDay':'integer',
                        'ModifyOffers':'integer',
                        }

CONFIGDATA['User'] = {}

CONFIGDATA['Subscriber'] = {
                        'BillCycleId':'integer',
                        'BillCycleDay':'integer',
                        'ModifyOffers':'integer',
                        }
                          
CONFIGDATA['Device'] = {
                        'Imsi':'integer',
                        'Msisdn':'integer',
                        'ModifyOffers':'integer',
                       }

CONFIGDATA['Offer'] = { 'ExtId':'string',
                        'Verify':'binary',
                        'StartTime':'string',
                        'EndTime':'string',
                        'CycleEndTime':'string',
                        'ImmediateChange':'binary',
                       }

CONFIGDATA['Seagull'] = {'Amount':'integer',
                         'ServiceId':'string',
                       }

CONFIGDATA['Logic'] = { 'Cond1':'string',
                        'Cond2':'string',
                        'Cond3':'string',
                        'Cond4':'string',
                        'Cond5':'string',
                        'Cond6':'string',
                        'Cond7':'string',
                        'Cond8':'string',
                        'Cond9':'string',
                        'Cond10':'string',
                        'Logic1':'string',
                        'Logic2':'string',
                        'Logic3':'string',
                        'Logic4':'string',
                        'Logic5':'string',
                        'Logic6':'string',
                        'Logic7':'string',
                        'Logic8':'string',
                        'Logic9':'string',
                        'Logic10':'string',
                       }

CONFIGDATA['Diameter'] = {
                          'SessionIdPrefix':'string',
                          'Imsi':'integer',
                          'Msisdn':'integer',
                          'IpAddress':'string',
                          'Port':'integer',
                          'Timezone':'string',
                          'CCTotalOctets':'integer',
                          'Command':'string',
                          'Interface':'string',
                       }

CONFIGDATA['CB'] =     {
                         'NormalizerId':'integer',
                         'configIniFile':'string',
                         'date':'string',
                         'value':'string',
                         'result':'string',
                         'exact':'string',
                         'description':'string',
                         'Action':'string',
                         'ResultRetainCount':'string',
                         'ValueRetainCount':'string',
                         'AllowNewValues':'string',
                         'Header':'string',
                         'ResultModifyFlag':'string',
                         'algorithm':'string',
                         'datatype':'string',
                         'formatNumber':'string',
                         'default':'string',
                         'type':'string',
                         'no_field_normalization_value':'string',
                         'name':'string',
                       }

# Add default fields to each main section
for area in sections: CONFIGDATA[area].update(defaultObjectEntries)

#===============================================================================
def updateMdcInfo(requestMdc, operation, config, area, submanBuilder, queryValue, queryType, preQueryValue=None, preQueryType=None):
        global mdcList
        
        # Add the request to the list to process
        mdcList[operation].append(requestMdc.printCompact())
        #print 'Wrote entry to file'

        # See if we need to write this data
        if len(mdcList[operation]) >= int(config['Program']['batchSize']): writeSingleFile(operation)

        # See if this object should be added to the query output
        queryAddCheck(area, submanBuilder, queryValue, queryType, config, preQueryValue=preQueryValue, preQueryType=preQueryType)

# ------------------------------------------------------------------------------
def queryAddCheck(area, submanBuilder, queryValue, queryType, config, preQueryValue=None, preQueryType=None):
        global mdcList
        global objectList
        
        # See if we should add a query for this and have not already done so

        # Separate files for pre and post query
        for query in ['postImportQuery', 'preImportQuery']:
                # pre/post controls several items
                if query.startswith('post'):
                        # Set the proper operation
                        queryOp = area+'QueryPost'

                        # ALways use queryXxx values for post query
                        queryTypeUse = queryType
                        queryValueUse = queryValue
                else:
                        # Set the proper operation
                        queryOp = area+'QueryPre'

                        # If changing external IDs, then the pre-query value is different than the post query value.
                        if preQueryValue: queryValueUse = preQueryValue
                        else:             queryValueUse = queryValue
                        if preQueryType:  queryTypeUse = preQueryType
                        else:             queryTypeUse = queryType

                # After all of this, see if we should query...
                if config['Program'][query] and not (queryValueUse in objectList[area][queryOp]):
                        # Create/store query
                        requestMdc = queryObject(submanBuilder, area, queryValueUse, queryTypeUse)
                        if requestMdc:
                                # Store the query
                                mdcList[queryOp].append(requestMdc.printCompact())

                                # See if we need to write this data
                                if len(mdcList[queryOp]) >= int(config['Program']['batchSize']): writeSingleFile(queryOp)

                                # Mark this item as having been queried
                                objectList[area][queryOp][queryValueUse] = True

# ------------------------------------------------------------------------------
# Function Description: Open the output files and Read the offer files
# parameter: p_start_time_str - used as part of the output filename
# ------------------------------------------------------------------------------
def close_files(files):
        error_file.close()
        skip_file.close()
        
        #closeMdcFiles(files)

def writeSingleFile(operation):
        global outputFileDirAndName
        global FileCounter
        
        #print 'Writing operation ' + operation + '. List = ' + str(mdcList[operation])
        # If the operation buffer is empty, then nothing to do
        if not len(mdcList[operation]): return
        
        # Open a file.  Pad the counter so when sorted they'll come out in the desired order.
        fName = outputFileDirAndName + "_" + operation + "_" + str(recordNumber) + "_" + str(FileCounter).zfill(4) + ".mdc"
        f = open(fName, 'w')
        FileCounter += 1
        #f = open(outputFileDirAndName + "_" + operation + ".mdc", 'a')
        
        # Write each record on a separate line.
        # Probably could do this better with a join statement...
        for x in mdcList[operation]: f.write(x + '\n')
        
        # Flush the file
        f.flush()
        
        # Close file
        f.close()
        
        # Clear the array
        mdcList[operation] = []
        
        print("\nWrote file " + fName) 
        
def closeMdcFiles(files):
        for item in MDCLIST:
                cmd = "files['" + item + "'].close()"
                exec(cmd)

def openMdcFiles(id, lclTime):
        global outputFileDirAndName
        
        files = {}
        for item in MDCLIST:
                cmd = "files['" + item + "'] = open('" + outputFileDirAndName + "_" + item + "_" + str(id) + ".mdc', 'w')"
                exec(cmd)
        
        # Print some header information to the files to know what they are about
#       for key, value in files.iteritems(): print >> value, '#Migration ' + key +' MDC, generated: ' + lclTime
        
        return files
        
def open_files(p_start_time_str):
        global outputFileDirAndName
        global error_file
        global skip_file
        
        # Always put output data in here
        out_folder = outputFileDir + '/'
        
        # Use file name without extension as part of the output MDC file names.
        # Also, grab just the file name (in case the test file is in another directory).
        basename   = p_start_time_str+'_'+args[0].split('.')[0].split('/')[-1]
        
        # Store output file dir and base name
        if not outputFileDirAndName: outputFileDirAndName = out_folder+basename
        
        # File where we write erronous record information
        cmd = 'rm ' + out_folder + '/*.err 2>/dev/null'
        GENERIC.runCmd(cmd)
        error_file = open(out_folder+basename+'.err', 'w')
        
        # File where skipped records are recorded
        cmd = 'rm ' + out_folder + '/*.skip 2>/dev/null'
        GENERIC.runCmd(cmd)
        skip_file = open(out_folder+basename+'.skip', 'w')
        
        # Open the mdc files
        files = None
#       files = openMdcFiles(recordNumber, p_start_time_str)
        
        ####  Black list offer processing
        #open the list of offers not yet configured; should be empty in real migration scenario
        #black_file = open(options.blacklist, 'r')
        
        # Read the offer blacklist and add the values to a list
        #for line in black_file:
        #        blackList.append(line.strip())
        #black_file.close()

        return files

# ------------------------------------------------------------------------------
# Function Description: write the MDC records to the corresponding out files
# parameter: hash table with the file handles
# ------------------------------------------------------------------------------
def writeToFiles(files, p_start_time, rotate=False):
        global mdcList
        
        # Process each of the MDC items
        for item in MDCLIST:
                for x in mdcList[item]: files[item],write(x)
                files[item].flush()
                mdcList[item] = []
        
        # Rotate if asked to
        if rotate:
                # Close MDC files
                closeMdcFiles(files)

                start_time_str = p_start_time.strftime('%d_%b_%YT%H_%M_%S')
                newFiles = openMdcFiles(recordNumber, start_time_str)
        
        else: newFiles = files
        
        # Debug output
        duration = GENERIC.calc_sec(p_start_time)
        print(("=> Total ", recordNumber, "lines processed"))
        print(("\nTotal Time elapsed = ", duration, " sec.")) 
        print('------------------------------------------------------------------------------------------------------------------------------------')

        return newFiles
        
# ------------------------------------------------------------------------------
# Function Description: prints the MDC in different formats to stdoput
# Parameter: p_dsc - description; prefixed before the MDC
#            p_mdc - the mdc to be printed
# ------------------------------------------------------------------------------
def logMDC(p_dsc,p_mdc):
        if   options.log_mdc == 'x': print(p_mdc)
        elif options.log_mdc == 'c': print(p_dsc+": " + p_mdc.printCompact())

# ------------------------------------------------------------------------------
# Query object
# ------------------------------------------------------------------------------
def queryObject(submanBuilder, area, queryValue, queryType):
        # Need to build with first letter small.
        mdcName = area[0].lower() + area[1:]

        # query the object
        cmd = 'requestMdc = submanBuilder.' + mdcName + 'Query(queryType=queryType, queryValue=queryValue)'
        exec(cmd)

        # Log the requests
#       if options.verbose_flag: logMDC("query",requestMdc)

        # Return MDC structure
        return requestMdc

# ------------------------------------------------------------------------------
#  MAIN
# ------------------------------------------------------------------------------
def main():

        print('Hello')

if __name__ == '__main__':
        main()

# ------------------------------------------------------------------------------
#  MAIN
# ------------------------------------------------------------------------------
def main():
        print('hello')

if __name__ == '__main__':
        main()

