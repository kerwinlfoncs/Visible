#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-12-03T09:30:36
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-12-03T09:30:36
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-12-03T09:30:36

# Product imports

# Python imports
from __future__ import print_function
from __future__ import absolute_import
# from builtins import str
# from builtins import range
from future import standard_library
standard_library.install_aliases()
# from builtins import str
# from builtins import range
import subprocess
import sys, os, copy
import xml.etree.ElementTree as ET
from . import parseRecord as REC
import http.client

from queue import Queue
import threading

# Local program imports
from . import data2 as DATA
from . import prim as PRIM

from primitives import primHTTP as HTTP
from primitives import primXML as XML
from primitives import primGeneric as GENERIC
from primitives import processObject as OBJECT

# Dictionary of offer details aready read from the engine
offerReadDetails = {}

#===============================================================================
# Setup thread for processing the request
class processingThread(threading.Thread):
    def __init__(self,threadNum,queue, resultsFile):
        threading.Thread.__init__(self)
        self.threadNum=threadNum
        self.input_queue=queue
        self.resultsFile = resultsFile

        # Open both connections
#        print 'opening connection to host/port: ' + DATA.config['Rest']['hostname'] + '/' + DATA.config['Rest']['hostport']
        #self.conn1=httplib.HTTPConnection(DATA.config['Rest']['hostname'], DATA.config['Rest']['hostport'])
        self.conn1=HTTP.setupHttpConnection(DATA.config['Rest'])

        #Host2=HOST2
        #self.conn2=httplib.HTTPConnection(Host2,PORT)

        # Not working.  Set second connection object equal to the first one.
        self.conn2=self.conn1

    def run(self):
        count = 0
        currentObj = None

        # Open the results file
        f = open(self.resultsFile+'_'+str(self.threadNum), 'w')
        
        # Loop
        while True:
                # Get a request from the queue
                item=self.input_queue.get(block=True)
#               print 'Thread %d retrieved from queue %s'%(self.threadNum,str(item))

                # If None, then there will be nothing more and we should exit
                if item is None:
                        print('Thread ' + str(self.threadNum) + ' exiting after processing ' + str(count) + ' records')
                        
                        # Flush/close the output file
                        f.flush()
                        f.close()
                        return
          
                # Bump the count
                count += 1
                  
                # Print progress marker
                if not (count % int(DATA.config['Program']['progressCount'])): print('Thread ' + str(self.threadNum) + ' has processed ' + str(count) + ' records')
                
                # Extract the items that were put
                #print 'item = ' + str(item)
                object,key = item
                #print 'thread ' + str(self.threadNum) + 'processing ' + object + ' ' + key
                
                # Split the key into components
                queryType = key.split('$')[0]
                queryValue = key.split('$')[1]
                
                # Get the data returned in an ET structure
                etStruct = HTTP.getObjectQuery(object, queryValue, queryType, self.conn1)
                
                # Nothing to do if empty structure returned
                if not etStruct: continue
                
                # Jump to the file that processes this request
                retString = validateRestData(object, key, etStruct, self.conn1)
                
                # Write the data to the thread file
                f.write(retString+'\n')
        
# ------------------------------------------------------------------------------
def validateModifyParameters(object, key, operation, dctRcv):
        retString = ""
        
        # Loop through each field and make sure it's set to what it should be
        for (param,value) in DATA.VerifyObject[object][key][operation]:
                # Make sure the parameter was returned
                if param not in dctRcv:
                        lclStr = 'ERROR: parameter ' + param + ' not in returned dictionary'
                        if DATA.options.verbose_flag: print(lclStr)
                        retString += lclStr + ', '
                        continue
                
                # Check the parameter value
                if dctRcv[param] != value:
                        lclStr = 'ERROR: parameter ' + param + ' value is ' + str(dctRcv[param]) + ' but was expecting ' + str(value)
                        if DATA.options.verbose_flag: print(lclStr)
                        retString += lclStr + ', '
                        continue

                # If here, then the parameter matched
                lclStr = 'SUCCESS: parameter ' + param + ' value is ' + str(dctRcv[param])
                if DATA.options.verbose_flag: print(lclStr)
                retString += lclStr + ', '
                
        return retString
        
# ------------------------------------------------------------------------------
def validatePurchasedOffers(object, key, operation, dctRcv, conn):
        global offerReadDetails
        
        # Init return variable
        retString = ''
        
        # Loop through each field and make sure it's set to what it should be
        for offerList in DATA.VerifyObject[object][key][operation]:
                #print 'offerList: ' + str(offerList)
                for offer in offerList:
                        # Go through each offer in the returned dictionary
                        found = False
                        for objOffer in dctRcv['offers']:
                                if offer == objOffer['ProductOfferExternalId']:
                                        found = True
                                        lclStr = 'SUCCESS: offer ' + offer + ' found in the wallet'
                                        if DATA.options.verbose_flag: print(lclStr)
                                        retString += lclStr + ', '
                                        break
                                        
                        # If found, then can continue
                        if found: continue
                                        
                        # If here, then we need to see if this is a one-time offer (so not expected in the wallet).
                        # See if we already read this offer (save time and only read each offer once)
                        if offer in offerReadDetails: q = offerReadDetails[offer]
                        else:
                                url = '/rsgateway/data/v3/pricing/offers/query/' + offer
                                (result,q) = HTTP.getAndVerifyHttpRequest(conn, url, exitOnFailure = False)
                                if not result:
                                        lclStr = 'ERROR: offer ' + offer + ' not in pricing'
                                        if DATA.options.verbose_flag: print(lclStr)
                                        retString += lclStr + ', '
                                        continue
                                else:   offerReadDetails[offer] = copy.deepcopy(q)
                                
                        # Get offer details
                        offerDetails = {}
                        details = q.find('./OfferInfo/MtxPricingOfferDetailInfo')
                        offerDetails = XML.getObjectBaseFields(details, offerDetails)
                        if 'IsOneTime' in offerDetails and offerDetails['IsOneTime'].lower() == 'true':
                                # This is a one-time offer, so not expected to be in the wallet
                                lclStr = 'SUCCESS: offer ' + offer + ' is a one-time offer and shouldn\'t be in the wallet'
                                if DATA.options.verbose_flag: print(lclStr)
                                retString += lclStr + ', '
                        else:
                                lclStr = 'ERROR: offer ' + offer + ' not in returned dictionary and it\'s not a one-time offer'
                                if DATA.options.verbose_flag: print(lclStr)
                                retString += lclStr + ', '
                                continue
        
        return retString
        
# ------------------------------------------------------------------------------
def validateBalances(object, key, dctRcv):
        # Init return variable
        retString = ''
        
        # Look for every balance in the list
        for balance in DATA.config[object]['VerifyBalance'].split(','):
                # Go through each balance in the returned dictionary
                found = False
                for objItem in dctRcv['balances']:
                          if balance == objItem['TemplateId']:
                                found = True
                                lclStr = 'SUCCESS: balance ' + balance + ' found in the wallet'
                                if DATA.options.verbose_flag: print(lclStr)
                                retString += lclStr + ', '
                                break
                                        
                # If found, then can continue
                if found: continue
                                        
                lclStr = 'ERROR: balance ' + balance + ' not in wallet'
                if DATA.options.verbose_flag: print(lclStr)
                retString += lclStr + ', '
        
        return retString
        
# ------------------------------------------------------------------------------
def validateRestData(object, key, q, conn):
        retString = ''

        # Process the object.
        # Reuse viewObject functions.
        # Need minor structure creation so API is matched
        configDct = {}
        configDct[object.lower()+'CustomName'] = DATA.customData[object]['customName'].split('/')[0]
        configDct['offerCustomName'] = DATA.customData['Offer']['customName'].split('/')[0]
        dctRcv = {}

        # Now invoke viewObject processing function
        if   object == 'Subscriber': dctRcv = OBJECT.processSubDctData(dctRcv, q, configDct, None, None, conn)
        elif object == 'Device':     dctRcv = OBJECT.processDevDctData(dctRcv, q, configDct, None, None, conn)
        elif object == 'Group':      dctRcv = OBJECT.processGroupDctData(dctRcv, q, configDct, None, None, conn)
        else:
                lclStr =  'ERROR:  invalid object input: ' + object
                if DATA.options.verbose_flag: print(lclStr)
                return lclStr

        # See what we have
#        print 'Returned dictionary:'
#        for _key in dctRcv.keys(): print _key + ': ' + str(dctRcv[_key])

        # Build return string
        retString += object + ' ' + key + ': '
        if DATA.options.verbose_flag: print(retString)

        # Now we can validate stuff.
        # Different data and hence different validation for each operation
        #print 'operation keys: ' + str(DATA.VerifyObject[object][key].keys())
        for operation in list(DATA.VerifyObject[object][key].keys()):
                # Debug output
                if DATA.options.verbose_flag: print('Processing operation ' + operation)

                # Object Modifications
                if operation.count('Modify'):   retString += validateModifyParameters(object, key, operation, dctRcv)

                # Purchased offers
                elif operation.count('Offer'):  retString += validatePurchasedOffers(object, key, operation, dctRcv, conn)
        
        # If object has VerifyBalance set, then need to do that once.
        if 'VerifyBalance' in DATA.config[object] and DATA.config[object]['VerifyBalance']: retString += validateBalances(object, key, dctRcv)
        
        # Return string minus the last comma + space
        return retString[:-2]
        
# ------------------------------------------------------------------------------
def validateBulkImportResults(outputFile, rmvFlag=False):
        successFlag = False
        
        # First make sure we got some results back
        cmd = 'wc -l ' + outputFile + ' | cut -f1 -d" "'
        failCount = GENERIC.runCmd(cmd)
        if int(failCount) == 0:
                print('ERROR: No results received.  Please review the debug log file and look for errors.')
                if DATA.config['Program']['pauseOnErrors']: PRIM.pauseCheck(True)
                else: print("Not pausing on errors due to config['Program']['pauseOnErrors'] set to False")
        else:
                # Check for MDC result failures (first line validation)
                cmd = "grep \"'Result'\" " + outputFile + "| grep -v \"value='0'\" | wc -l"
                failCount = GENERIC.runCmd(cmd)
                if int(failCount):
                        print('ERROR: ' + failCount + ' commands failed.  Please review file ' + outputFile + ' for lines where "Result" value is not 0.')
                        if DATA.config['Program']['pauseOnErrors']: PRIM.pauseCheck(True)
                        else: print("Not pausing on errors due to config['Program']['pauseOnErrors'] set to False")
                else:   
                        print('Success.  All commands succeeded')
                        successFlag = True
        
        # Remove this file if success and remove flag is set.  Can take up A LOT of space!
        if successFlag and rmvFlag:
                cmd = "rm -f " + outputFile
                GENERIC.runCmd(cmd)
                
# ------------------------------------------------------------------------------
def validatePostBulkImport(resultsFile):
        # If no REST data entered, then can't validate anything
        if not (DATA.config['Rest']['hostname'] and DATA.config['Rest']['hostport']):
                print('WARNING: Rest information not full configured in config file.  Can\'t verify if one can\'t access the REST gateway.')
                return
        
        # Remove old files in output directory
        cmd = 'rm ' + resultsFile + '* 2>/dev/null'
        GENERIC.runCmd(cmd)
        
        # See if anything to do at all
        validation = False
        for object in ['Subscriber', 'Device', 'Group']:
                # See if config data says to verify this object
                if not DATA.config[object]['Verify']: continue
                
                # Set flag and break
                validation = True
                break
        
        # Exit if not validating anything
        if not validation:
                print('\n\nNo "Verify" items set to True, so no post query verifications performed.\n')
                return
        
        # *** Queue and thread setup ***
        # Set up a queue
        q=Queue()

        # Create threads and start them
        pool=[]
        for i in range(int(DATA.config['Program']['threadCount'])):
          t=processingThread(i,q, resultsFile)
          pool.append(t)
          t.daemon = True
          t.start()
        
        # Check for each object
        for object in ['Subscriber', 'Device', 'Group']:
                # See if config data says to verify this object
                if not DATA.config[object]['Verify']: continue
                
                # Process everything that requires verification
                for key in list(DATA.VerifyObject[object].keys()): q.put((object, key))
                
        # Done adding stuff that needs processing.  
        # Put as many None's in the queue as there are threads, so that each thread gets one
        for t in pool:
          q.put(None)

        # Wait for all threads to exit
        for t in pool:
          t.join()
        
        # Cat together all files from all the threads.
        # Remove the individual files.
        cmd =  'cat ' + resultsFile + '_* > ' + resultsFile
        cmd += ';rm ' + resultsFile + '_* 2>/dev/null'
        GENERIC.runCmd(cmd)
        
        # Check if any errors in the results file
        cmd = 'grep ERROR ' + resultsFile + ' | wc -l'
        errorCount = GENERIC.runCmd(cmd)
        if int(errorCount):
                print('\n\nWARNING: there were ' + errorCount + ' errors in file ' + resultsFile + ' - Users should investigate each error.')
                PRIM.pauseCheck(True)
        else:
                # All was successful.  Report number of successful verifications (if any were done...)
                cmd = 'grep SUCCESS ' + resultsFile + ' | wc -l'
                errorCount = GENERIC.runCmd(cmd)
                if int(errorCount): print('Verification succeeded.  Verified ' + errorCount + ' items.  See file ' + resultsFile + ' for details.')
                else:               print('WARNING:  Verification did not run.  Please double check config file to see if Verify was set to True in any section.')
        
        return
                
# ------------------------------------------------------------------------------
def validateQueryResults(outputFile, f):
        tmpFile = '_x'
        
        finalRetCode = True

        # Check for each object
        for object in ['Subscriber', 'Device', 'Group']:
                # Skip if outputfile not the target object
                if not outputFile.count(object): continue

                # See if config data says to verify this object
                if not DATA.config[object]['Verify']: return True

                # Get common string that starts every record
                newRecordString = 'MtxResponse' + object

                # Extract the response structures from the output file.  Makes for a MUCH smaller output file :-)!
                cmd = 'sed -n "/<struct name=\'MtxResponseSubscriber\'/,/<\/struct/p" ' + outputFile + ' > ' + tmpFile
#               print 'validateQueryResults, cmd = ' + cmd
                GENERIC.runCmd(cmd)
                
                # Go through all keys on the verify object dictionary
                for operation in list(DATA.VerifyObject[object].keys()):
                        # Get parameters for each item to verify
                        for (queryValue, queryType, parameter, value, verifyFlag) in DATA.VerifyObject[object][operation]:
#                               print 'queryValue, queryType, parameter, value, verifyFlag = ' + queryValue + ',' + queryType + ',' + parameter + ',' + str(value) + ',' + str(verifyFlag)
                                # Build egrep line.  Get start of each record, desired object, and all parameter values.
                                cmd = 'egrep "' + newRecordString + '|\'' + queryType + '\'.*value=\'' + queryValue + '\'|\'' + parameter + '\'" ' + tmpFile
                                keyData = GENERIC.runCmd(cmd).split("\n")
                                
                                # Add final null entry to returned data, to cover the case where the last line is the external ID (and nothing more to cover)
                                keyData.append('Empty Line')
#                               print 'validateQueryResults, data: ' + str(keyData)

                                # OK, not sure this is the best approach, but do the following:
                                #       a) search for first occurence of queryType
                                #       b) then see if first occurence of parameter occurs before the start of a new record string
                                #               * If parameter is 'None' (external ID change), then assume success when finding the object itself.
                                #               * If found, then the parameter exists and we can verify it's value.
                                #               * If new record found, then parameter wasn't set so it's an error.
                                # Assume per check success
                                lclRetCode = True
                        
                                foundObject = foundParameter = False
                                for line in keyData:
                                        # What to check for depends on whether start of target object found
                                        if not foundObject:
                                                # Skip if not a query type line
                                                if not line.count(queryType): continue

                                                # Skip if query value not in this line
                                                checkString = 'value=\'' + queryValue + '\''
#                                                print 'Checking line "' + line + '" for string "' + checkString + '"'
                                                if not line.count(checkString): continue

                                                # Found the object in question
#                                               print ' Found object'
                                                foundObject = True
                                                continue
                                        else:
                                                # If we're not looking for a parameter (e.g. change of external ID), then we can assume succes here...
                                                if parameter == 'None':
                                                        foundParameter = True
                                                        break
                                                
                                                # Look for parameter.  Trouble if we find the new record string first...
                                                if line.count(newRecordString): break

                                                # Skip if not our parameter
                                                if not line.count(parameter): continue

                                                # Found the parameter
                                                foundParameter = True

                                                # Check for the proper value
                                                if line.count('value=\'' + value + '\''):
                                                        # No more work needed for this parameter
                                                        break

                                                # If here, then we have a bad value
                                                msg = 'ERROR: file ' + outputFile + ', object = ' + queryValue + '(' + queryType + ')' + \
                                                        'parameter ' + parameter + ' expected value is ' + value + '.  Found line: ' + line + '.\n'
                                                if DATA.options.verbose_flag: print(msg)
                                                f.write(msg)
                                                lclRetCode = False
                                                break

                                # See if we didn't found the object and/or the parameter
                                if not foundObject:
                                        msg = 'ERROR: file ' + outputFile + ', object = ' + queryValue + '(' + queryType + ') not found\n'
                                        if DATA.options.verbose_flag: print(msg)
                                        f.write(msg)
                                        lclRetCode = False

                                elif not foundParameter:
                                        msg = 'ERROR: file ' + outputFile + ', object = ' + queryValue + '(' + queryType + ') parameter ' + parameter + ' not found\n'
                                        if DATA.options.verbose_flag: print(msg)
                                        f.write(msg)
                                        lclRetCode = False
                                elif lclRetCode:
                                        # Highlight the success
                                        msg = 'SUCCESS: file ' + outputFile + ', object = ' + queryValue + '(' + queryType + ')' + \
                                              'parameter ' + parameter + ' expected value of ' + str(value) + ' found\n'
                                        if DATA.options.verbose_flag: print(msg)
                                        f.write(msg)
                                        lclRetCode = True
                
                                # Update final return code if not already signalling an error
                                if not finalRetCode: finalRetCode = lclRetCode
        
        # Remove temp file
        cmd = 'rm -f ' + tmpFile + ' 2>/dev/null'
        GENERIC.runCmd(cmd)

        # Return indication of any errors found
        return finalRetCode

# ------------------------------------------------------------------------------
#  MAIN
# ------------------------------------------------------------------------------
def main():

        print('Hello')

if __name__ == '__main__':
        main()

