#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-12-03T09:30:32
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-12-03T09:30:32
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-12-03T09:30:32

# Product imports
from __future__ import print_function
from __future__ import absolute_import
# from builtins import str
# from builtins import range
# from builtins import str
# from builtins import range
import data_container_defs as MDCDEFS
from . import data2 as DATA
from . import prim as PRIM
from . import getResourceIds as RESOURCE
from primitives import timeToMDCtime  as MDCTIME

# Python imports
import copy, sys, pprint

#============================================================
# offerId is either offer id or externalId.  Different data required for each.
# dupAttr is set when we want to purchase multiple offers and all have the same attr.
#============================================================
def prepOfferAttr(offerId, offerIsExternal=False, offerStartTime=None, offerEndTime=None,
                 attr=None, offerId2=None, dupAttr=True, catalogItemId=None, offerCycleType=None, offerCycleResourceId=None):
    # Release matters here
    release = int(DATA.config['Program']['release'])
    
    i = 0
    #Check if off is not a list and convert it to a list
    if type(offerId) is not list:
        offerL = [offerId]
    else:
        offerL = offerId

    #check if we have attr or need to duplicate one
    attrArr = attr
    if attr:
        if type(attr) is not list and dupAttr:  #dont dup in case we forgot to unset dupAttr
            attrArr = []
            while i < len(offerL):
                attrArr.append(attr)
                i += 1
    
    # Decide if CI or product ID
    if release > 5000:
        purchaseType = 'CatalogItemId'
    else:
        purchaseType = 'ProductOfferId'

    # Remove any ticks from times
    if offerEndTime: offerEndTime = offerEndTime.strip("'")
    if offerStartTime: offerStartTime = offerStartTime.strip("'")
    
    i = 0
    #Create offer list
    attVal = attrArr
    retList = []
    for offer in offerL:
        if type(attrArr) is list:
            if i >= len(attrArr):  attVal = None  #maybe we did not input all Attr for all offers
            else : attVal = attrArr[i]

        if release > 5000:
                if offerIsExternal and offerId2!= None:
                    retList.append({purchaseType:offerId2, 'ExternalId':offer,
                               'StartTime':offerStartTime,'EndTime':offerEndTime, 'Attr':attVal, 'OfferCycleType':offerCycleType, 'OfferCycleResourceId':offerCycleResourceId})
                elif offerIsExternal:
                    retList.append({'ExternalId':offer, 'StartTime':offerStartTime, 'EndTime':offerEndTime, 'Attr':attVal, 'OfferCycleType':offerCycleType, 'OfferCycleResourceId':offerCycleResourceId})
                else:
                    retList.append({purchaseType:offer, 'StartTime':offerStartTime, 'EndTime':offerEndTime, 'Attr':attVal, 'OfferCycleType':offerCycleType, 'OfferCycleResourceId':offerCycleResourceId})
        else:
                if offerIsExternal and offerId2!= None:
                    retList.append({purchaseType:offerId2, 'ExternalId':offer,
                               'StartTime':offerStartTime,'EndTime':offerEndTime, 'Attr':attVal})
                elif offerIsExternal:
                    retList.append({'ExternalId':offer, 'StartTime':offerStartTime, 'EndTime':offerEndTime, 'Attr':attVal})
                else:
                    retList.append({purchaseType:offer, 'StartTime':offerStartTime, 'EndTime':offerEndTime, 'Attr':attVal})
        
        i += 1

    return retList

# ------------------------------------------------------------------------------
def processOffer(submanBuilder, object, offerList, attr=None, offerEndTime=None, offerType='Optional', offerStartTime=None, options=None, operationType='purchase', resourceIdFlag=False, cycleData=None):
        # Release matters here
        release = int(DATA.config['Program']['release'])
        
        area = object['object']
        operation = area + offerType + 'Offers'
        
        # Prepare the offer
        offerListSave = copy.deepcopy(offerList)
        offerList = prepOfferAttr(offerList, offerIsExternal=True, catalogItemId=True, offerEndTime=offerEndTime, attr=attr, dupAttr=True, offerStartTime=offerStartTime)
        
        # Warning for no offers for a subscriber
        if len(offerList) == 0:
                print("WARNING: Record #"+str(DATA.recordNumber)+" - No offer found for object: " + str(object) + "!")
                print('#'+str(DATA.recordNumber)+' No Offer '+line, file=error_file)
                return

        # Debug output
        if options and options.verbose_flag: print(area + ': '+ offerType +' offerList: ' + str(offerList))
        
        # Type is constant
        queryType  = object['queryType']
        
        # Can create a range of objects
        objRange = PRIM.getRangeValues(object['queryValue'], area, operation)
        
        # Process the range
        for queryValue in objRange:
                # Want this as a string
                queryValue = str(queryValue)

                # See if we've already done this operation already for the specified object
                # Support multiple operations
#               if queryValue in DATA.objectList[area][operation]: continue

                # Add to the list iff not Input or Modify, as we may have several lines with these.
                if not offerType in ['Input', 'Modify']: DATA.objectList[area][operation][queryValue] = True
                
                # Take offer actions based on the operation type
                if operationType == 'purchase':
                        # Purchase the offers.  Official product MDC calls are all lower case
                        cmd = 'requestMdc = submanBuilder.' + area.lower() + 'PurchaseOffer(queryType="' + queryType + '", queryValue="' + queryValue + '", offerList=offerList)'
                        '''
                        print 'cmd = ' + cmd
                        print 'offerList = ' + str(offerList)
                        '''
                        exec(cmd)
                        
                        if requestMdc: DATA.updateMdcInfo(requestMdc, operation, DATA.config, area, submanBuilder, queryValue, queryType)
                        # Store group/subscriber/device, optional/required, purchase list
                        #DATA.mdcList[operation].append(requestMdc.printCompact())
                        
                elif operationType in ['cancel'] and resourceIdFlag:
                        # Check if off is not a list and convert it to a list
                        if type(offerListSave) is not list:
                                resourceId = [offerListSave]
                        else:
                                resourceId = offerListSave
                        #print 'resourceId = ' + str(resourceId)
                        
                        # Cancelling via resource IDs.  Can do this in one command versus per offer
                        cmd = 'requestMdc = submanBuilder.' + area.lower() + 'CancelOffer(queryType="' + queryType + '", queryValue="' + queryValue + '", resourceIdList=resourceId)'
                        
                        # Execute the command
                        #print 'cmd = ' + cmd
                        exec(cmd)
                        
                        # Store group/subscriber/device, optional/required, purchase list
                        if requestMdc: DATA.updateMdcInfo(requestMdc, operation, DATA.config, area, submanBuilder, queryValue, queryType)
                                
                elif operationType in ['modify', 'cancel']:
                        # Could be working on a list of offers
                        #for i in range(1):
                        for i in range(len(offerList)):
                                # Clear list of resource IDs
                                resourceIds = []
                                
                                # May have passed in resource IDs, or may need to go find them.
                                # Resource IDs are always numbers, so will fall into the OfferId entry.
                                if not resourceIdFlag:
                                        # Retrieve the resource ID for this offer from this sub
                                        if (queryValue not in RESOURCE.objectResourceIds) or \
                                           RESOURCE.objectResourceIds[queryValue]['type']   != queryType or \
                                           RESOURCE.objectResourceIds[queryValue]['object'] != area:
                                                print('ERROR: ' + area + ' ' + queryType + ' ' + queryValue + ' did not have their resources read in.')
                                                sys.exit('Exiting due to errors')
                                        
                                        # Look for the offer external ID - ALL OF THEM!!
                                        '''
                                        print 'processOffer:  RESOURCE.objectResourceIds[' + queryValue + ']:'
                                        pprint.pprint(RESOURCE.objectResourceIds[queryValue])
                                        print 'offerList[' + str(i) + ']:'
                                        pprint.pprint(offerList[i])
                                        '''
                                        if 'offer' in RESOURCE.objectResourceIds[queryValue]:
                                            for offer in RESOURCE.objectResourceIds[queryValue]['offer']:
                                                #print 'Existing offer data: ' + str(RESOURCE.objectResourceIds[queryValue]['offer'][offer])
                                                # See if we can skip (doing this way to avoid deeper indentations)
                                                if not  (('ExternalId' in offerList[i]  and 'CatalogItemExternalId' in RESOURCE.objectResourceIds[queryValue]['offer'][offer]  and \
                                                          RESOURCE.objectResourceIds[queryValue]['offer'][offer]['CatalogItemExternalId'] == offerList[i]['ExternalId']) or \
                                                         ('ProductOfferId' in offerList[i] and 'CatalogItemId' in RESOURCE.objectResourceIds[queryValue]['offer'][offer] and \
                                                          RESOURCE.objectResourceIds[queryValue]['offer'][offer]['CatalogItemId']         == offerList[i]['ProductOfferId']   )): continue
                                                
                                                # If here, then we found one
                                                #print 'Adding resource ID: ' + str(RESOURCE.objectResourceIds[queryValue]['offer'][offer]['ResourceId'])
                                                resourceIds.append((RESOURCE.objectResourceIds[queryValue]['offer'][offer]['ResourceId'], offer))
                                                #break
                                
                                        # See if not found
                                        if not len(resourceIds):
                                                print('ERROR: ' + area + ' ' + queryType + ' ' + queryValue + ' does not have a resource id for offer ' + str(offerList[i]))
                                                sys.exit('Exiting due to errors')
                                        
                                # Command to send varies per operation
                                #print 'resourceIds = ' + str(offerListSave)
                                for j in range(len(offerListSave)):
                                 if operationType == 'modify':
                                        # Only ever modify a single offer
                                        resourceId = offerListSave[j]
                                        #print 'In Modify: resourceID = ' + resourceId
                                        offer = None
                                        
                                        # Start command
                                        cmd = 'requestMdc = submanBuilder.' + area.lower() + 'ModifyOffer(queryValue="' + queryValue + '", queryType="' + queryType + '"'
                                        
                                        # Add the resource ID
                                        cmd += ', resourceId=' + resourceId
                                        
                                        #print 'Attr: ' + str(attr)
                                        # Add optional parameters
                                        if offerList[i]['Attr']:      cmd += ", attr=offerList[i]['Attr']"
                                        if offerList[i]['StartTime']: cmd += ", startTime=offerList[i]['StartTime']"
                                        if offerList[i]['EndTime']:
                                                # Need to have both values in this logic
                                                (resourceId,offer) = offerListSave[j]
                                                
                                                # Prioritize end times
                                                endTime = None
                                                for time in ['EndTime', 'CancelEndTime', 'CancelTime']:
                                                        if time in RESOURCE.objectResourceIds[queryValue]['offer'][offer]:
                                                                endTime = RESOURCE.objectResourceIds[queryValue]['offer'][offer][time]
                                                                break
                                                
                                                # Need to support "current" as the end date (to touch an offer)
                                                if offerList[i]['EndTime'].lower() == 'current':
                                                        if not endTime: 
                                                                print('ERROR: ' + area + ' ' + queryType + ' ' + queryValue + ' offer ' + offer + ' does not have an end date set')
                                                                print(str(RESOURCE.objectResourceIds[queryValue]['offer'][offer]))
                                                                sys.exit('Exiting due to errors')
                                                elif offerList[i]['EndTime'].count('-'):
                                                        if not endTime: 
                                                                print('ERROR: ' + area + ' ' + queryType + ' ' + queryValue + ' offer ' + offer + ' does not have an end date set')
                                                                print(str(RESOURCE.objectResourceIds[queryValue]['offer'][offer]))
                                                                sys.exit('Exiting due to errors')
                                                        # Want to extend the current end dte by the input amount
                                                        (delta, timeUnit) = offerList[i]['EndTime'].split('-')
                                                        endTime = MDCTIME.getTime(delta, timeUnit, endTime)
                                                        print('Offer modify: relative end time is: ' + endTime)
                                                else:   endTime = offerList[i]['EndTime']
                                                
                                                # Store end time
                                                cmd += ", endTime=endTime"
                                        
                                        # Grab other items that can be modified.
                                        # Code added in 5210 release.
                                        if release >= 5210:
                                         if cycleData:
                                          for item in ['cycleType', 'cycleResourceId', 'cycleOffset', 'cycleAlignmentDisabled', 'cycleStartTime', 'cycleEndTime', 'immediateChange']:
                                                # Command pulls in non-None parameters into paramString
                                                try:
                                                        # Add to the string iff defined
                                                        cmd2 = 'if cycleData["offer' + item[0].capitalize() + item[1:] + '"] != None: cmd += ", ' + item + '=cycleData[\'offer' + item[0].capitalize() + item[1:] + '\']"'
                                                        #print cmd2
                                                        exec(cmd2)
                                                except: pass
                                          for item in ['apiEventData', 'status', 'statusValue', 'parameterList']:
                                                # Command pulls in non-None parameters into paramString
                                                try:
                                                        # Add to the string iff defined
                                                        cmd2 = 'if offer' + item[0].capitalize() + item[1:] + ' != None: cmd += ", ' + item + '=offer' + item[0].capitalize() + item[1:] + '"'
                                                        #print cmd2
                                                        exec(cmd2)
                                                except: pass
                                 else:
                                        # Expect both here
                                        (resourceId,offer) = offerListSave[j]
                                        
                                        # Cancel command
                                        cmd = 'requestMdc = submanBuilder.' + area.lower() + 'CancelOffer(queryType="' + queryType + '", queryValue="' + queryValue + '"'
                                        
                                        # Add the resource ID as a list
                                        cmd += ', resourceIdList=[resourceId]'
                        
                                 # Close the command
                                 cmd += ')'
                                        
                                 # Execute the command
                                 #print 'cmd = ' + cmd
                                 exec(cmd)
                                
                                 # Store group/subscriber/device, optional/required, purchase list
                                 if requestMdc: DATA.updateMdcInfo(requestMdc, operation, DATA.config, area, submanBuilder, queryValue, queryType)
                                
                else:
                        print('Hmmm.  offerProcess encountered operation type ' + str(operationType) + ' which is not supported')
                        sys.exit('Exiting due to errors')
                
                # Log the requests
#               if options and options.verbose_flag: logMDC(operationType+"_offers",requestMdc)
                
                # Add validation data
                if DATA.config[area]['Verify']:
                        # Build verification data
                        key = queryType + '$' + queryValue
                        if not key in DATA.VerifyObject[area]: DATA.VerifyObject[area][key] = {}
                        if not operation in DATA.VerifyObject[area][key]: DATA.VerifyObject[area][key][operation] = []
                
                        # Add to global data
                        DATA.VerifyObject[area][key][operation].append((offerListSave))
                        if options and options.verbose_flag: print('Added ' + area + ' ' + key + ' ' + operation + ' offerList: ' + str(offerListSave))
                
        # If here, then all went well
        return True
        
# ------------------------------------------------------------------------------
#  MAIN
# ------------------------------------------------------------------------------
def main():
        print('hello')

if __name__ == '__main__':
        main()

