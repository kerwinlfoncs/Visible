#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-12-03T09:30:34
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-12-03T09:30:34
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-12-03T09:30:34

from __future__ import print_function
from __future__ import absolute_import
# from builtins import str
# from builtins import range
# from builtins import str
# from builtins import range
from datetime import datetime
import time, json, sys
from . import data2 as DATA
from . import prim as PRIM

attr={}

# Define decorator
import time
import functools
def clock2(func):
        # Get name of caller
        @functools.wraps(func)
        def clocked(*args, **kwargs):
                t0 = time.time()
                result = func(*args, **kwargs)
                elapsed = time.time() - t0
                print('Elapsed time for function = ' + func.__name__ + ': ' + str(elapsed))
                return result
        return clocked

def validateDateAndTime(item, data):
#               print 'validating field ' + item + ', value: ' + data
                
                # assume valid
                validation = True
                offerStartValid = True
                retText = ''
                
                # If the date is "current', then it'll be replaced by what's read from the system.  Allow this through.
                if data.lower() in ['current', 'none']: return validation,retText
                
                # Length check
                length = 19
                if len(data) != length:
                        print(' ERROR: ' + item + ' length not ' + str(length) + ' (' + str(len(data)) + '): ' + data)
                        validation = False
                        retText += ', ' + item + ' length not ' + str(length)
#                       sys.exit('Exiting due to errors')

                else:
                        # Separate into components
                        inputYear  = data.split('T')[0].split('-')[0]
                        inputMonth = data.split('T')[0].split('-')[1]
                        inputDay   = data.split('T')[0].split('-')[2]
                        inputHour  = data.split('T')[1].split(':')[0]
                        inputMin   = data.split('T')[1].split(':')[1]
                        inputSec   = data.split('T')[1].split(':')[2]
                
                        # MSISDN must be all integers
                        for data in [inputYear, inputMonth, inputDay, inputHour, inputMin, inputSec]:
                                if not data.isdigit():
                                        print(' ERROR:  ' + item + ' must be integers: ' + data)
                                        validation = False
                                        retText += ', ' + item + ' must be integers: ' + data
#                                       sys.exit('Exiting due to errors')
                        
                        # Get today's date components
                        start_time = datetime.now()
                        todayYear  = start_time.strftime('%Y')
                        todayMonth = start_time.strftime('%m')
                        todayDay   = start_time.strftime('%d')

                        # Check fields for being in range
                        minValue = 1
                        maxValue = 12
                        data = int(inputMonth)
                        comp = 'Month'
                        if data < minValue or data > maxValue:
                                print(' ERROR: ' + comp + ' not in range ' + str(minValue) + '/' + str(maxValue))
                                validation = False
                                retText += ', ' + comp + ' not in range ' + str(minValue) + '/' + str(maxValue)
#                               sys.exit('Exiting due to errors')
                
                        minValue = 1
                        maxValue = 31
                        data = int(inputDay)
                        comp = 'Day'
                        if data < minValue or data > maxValue:
                                print(' ERROR: ' + comp + ' not in range ' + str(minValue) + '/' + str(maxValue))
                                validation = False
                                retText += ', ' + comp + ' not in range ' + str(minValue) + '/' + str(maxValue)
#                               sys.exit('Exiting due to errors')
                
                        minValue = 0
                        maxValue = 23
                        data = int(inputHour)
                        comp = 'Hour'
                        if data < minValue or data > maxValue:
                                print(' ERROR: ' + comp + ' not in range ' + str(minValue) + '/' + str(maxValue))
                                validation = False
                                retText += ', ' + comp + ' not in range ' + str(minValue) + '/' + str(maxValue)
#                               sys.exit('Exiting due to errors')
                
                        minValue = 0
                        maxValue = 59
                        data = int(inputMin)
                        comp = 'Minute'
                        if data < minValue or data > maxValue:
                                print(' ERROR: ' + comp + ' not in range ' + str(minValue) + '/' + str(maxValue))
                                validation = False
                                retText += ', ' + comp + ' not in range ' + str(minValue) + '/' + str(maxValue)
#                               sys.exit('Exiting due to errors')
                
                        minValue = 0
                        maxValue = 59
                        data = int(inputSec)
                        comp = 'Second'
                        if data < minValue or data > maxValue:
                                print(' ERROR: ' + comp + ' not in range ' + str(minValue) + '/' + str(maxValue))
                                validation = False
                                retText += ', ' + comp + ' not in range ' + str(minValue) + '/' + str(maxValue)
#                               sys.exit('Exiting due to errors')
                
                        # Don't validate End dates;  will separately check that the end date is not earlier than the start date
                        if item.count('End'): return validation,retText
                        
                        # Validate year
                        comp = 'year'
                        if inputYear > todayYear:
                                print(' ERROR: ' + item + ' ' + comp + ' greater than this ' + comp)
                                validation = False
                                retText += ', ' + item + ' ' + comp + ' greater than this ' + comp
#                               sys.exit('Exiting due to errors')
                
                        # Validate month iff the years are equal
                        comp = 'month'
                        if inputYear == todayYear and inputMonth > todayMonth:
                                print(' ERROR: ' + item + ' ' + comp + ' greater than this ' + comp)
                                validation = False
                                retText += ', ' + item + ' ' + comp + ' greater than this ' + comp
#                               sys.exit('Exiting due to errors')
                
                        # Validate day iff the year/months are equal
                        comp = 'day'
                        if inputYear == todayYear and inputMonth == todayMonth and inputDay > todayDay:
                                print(' ERROR: ' + item + ' ' + comp + ' greater than this ' + comp)
                                validation = False
                                retText += ', ' + item + ' ' + comp + ' greater than this ' + comp
#                               sys.exit('Exiting due to errors')
                
                return validation,retText
                
def validateMsisdn(item, data):
        # assume valid
        validation = True
        retText = ''
                
        # IMSI must be all integers
        if not data.isdigit():
                outStr = ' ERROR:  ' + item + ' must be integers.'
                validation = False
                retText += outStr
        
        # MSISDN length must be 8 < x < 15
        maxLength = 15
        minLength = 8
        if len(data) > maxLength or len(data) < minLength:
                outStr = ' ERROR: ' + item + ' length not in range (' + str(minLength) + ',' + str(maxLength) + '): ' + data + '.'
                validation = False
                retText += outStr
        
        return validation,retText
        
def validateStatus(item, data, area):
        # assume valid
        validation = True
        retText = ''
                
        # Need to translate properly or else an unexpected state
        if not data.isdigit() and not data.lower() in DATA.StatusMap[area]:
                retText = ' ERROR: area ' + area.capitalize() + ' ' + item + ' value ' + data + ' is not in the ' + area.capitalize() + ' status map.'
                #pprint.pprint(DATA.StatusMap[area])
                #print retText
                validation = False
                
        return validation,retText
        
def validateObjectId(item, data, area):
        # assume valid
        validation = True
        retText = ''
                
        # Need either a ":" or "-" separator character and a length of 4.
        for separator in [':', '-']:
                if data.count(separator):
                        # Get split
                        dataSplit = data.split(separator)
                        
                        # Make sure there are four fields
                        if len(dataSplit) != 4:
                                outStr = ' ERROR: area ' + area + ' ' + item + ' needs to have four fields: ' + data
                                validation = False
                                retText += outStr
                                break
                        
                        # Each field needs to be an integer
                        for index in range(len(dataSplit)):
                                if not dataSplit[index].isdigit():
                                        outStr = ' ERROR: area ' + area + ' ' + item + ' data ' + data + ' field ' + str(index) + '(' + dataSplit[index] + ') must be an integer'
                                        print(outStr)
                                        validation = False
                                        retText += ', ' + outStr
                                        break
        
        return validation,retText
        
def validateImsi(item, data):
        # assume valid
        validation = True
        retText = ''
                
        # IMSI must be all integers
        if not data.isdigit():
                outStr = ' ERROR:  ' + item + ' must be integers'
                validation = False
                retText += outStr
        
        # IMSI length 
        length = 15
        if len(data) != length:
                outStr = ' ERROR: ' + item + ' length not ' + str(length) + ' (' + str(len(data)) + '): ' + data
                validation = False
                retText += outStr
        
        return validation,retText
        
def validateOfferExtId(item, attr, offerList):
        # assume valid
        validation = True
        retText = ''
                
        # May list multiple offers
        data = attr[item]
        offerList = data.split(DATA.config['Program']['inputListSeparator'])
        for data in offerList:
                # If offer input, we were provided an offer list, and the input offer is not in the list:
                if data and offerList and len(offerList) and (not data in offerList):
                        # Remap if remapping defined, else error
                        if offerRemap and (data in offerRemap): attr[item] = offerRemap[data]
                        else:
                                print(' ERROR:  Input offer not in offer array or in remap array: "' + data + '"')
                                print('OfferList:\n' + str(offerList))
                                validation = False
                                retText += ', Input offer not in offer array or in remap array'
#                               sys.exit('Exiting due to errors')
                
        return validation,retText
        
#@clock2
def parseRecord(offerList, p_line, offerRemap={}, validateFlag=True, inputList = None):
        global attr
        
        # Get input file value seperator
        fieldSeparator = DATA.config['Program']['inputSeparator']

        # Add validation of the input fields
        validation = True
        retText = ''
        
        # Clear the global structure for storing data
        attr.clear()
        
        # If fields are json, then need to treat as a dictionary, else as a CSV entry
        if fieldSeparator.lower() == 'json':
                #print 'JSON dictionary.  Input line: ' + p_line
                attr = json.loads(p_line)
        else:
         # Sanity check that we received input
         if not inputList:
                print('parseRecord  ERROR:  input list can\'t be None')
                sys.exit('Exiting early due to errors')
        
         # Separate input line into fields
         split_line=p_line.split(fieldSeparator)
        
         # Separate input fields
         index = 0
#        print 'parseRecord: inputList  = ' + str(inputList)
#        print 'parseRecord: split_line = ' + str(split_line)
         for index in range(max(len(inputList), len(split_line))):
                # See if we have an input list item for this
                try:
                        element = inputList[index]
                except:
                        element = None
                
                # See if we have an input file item for this parameter
                try:
                        # Item could be in A=B format, or just B
                        values = split_line[index].strip().split('=')
                except:
                        values = [None]
                
                # Get field name and value (depends on format)
                if len(values) > 1:
                        # Use field from input file
                        field = values[0]
                        value = values[1]
                        
                        # *** NOTE: This parameter is most likely not in the config file input list.
                        # *** Need to add this to the set of parameters that will be processed.
                        # Don't know which object this is so check for that.
                        for section in DATA.sections:
                                # Skip if not the right section
                                if not field.startswith(section): continue
                                
                                # Add to global data if not already present
                                variable = field[len(section):]
                                if variable not in DATA.CONFIGDATA[section]:
                                        #print('Adding input parameter ' + variable + ' to object ' + section)
                                        DATA.CONFIGDATA[section][variable] = 'string'
                                
                                # No more to do here
                                break
                        else:
                                # Surprising we didn't find the variable in any section...
                                print("\nWARNING: input field and value " + str(values) + ' not in any defined sections.  This may cause issues later (e.g. dropped)')
                else:
                        # Use default field from input list
                        field = element
                        value = values[0]
                
                # If field is None, then we have input errors
                if not field: continue
                '''
                        # Set flag so caller knows this line is bad
                        validation = False
                        retText = ' ERROR: input line "' + p_line + '" field ' + str(index) + ' doesn\'t map to a field'
                        
                        # Nothing else to do...
                        return (validation, retText)
                '''
                        
                
                # Store value
                attr[field] = value
        
        # Check validation status
        if not validateFlag: return (True, "")
        
        #**************************** Validation Checks ***********************
        operation = 'Imsi'
        # *** IMSI ***
        for area in ['Device', 'Diameter']:
         item = area + operation
         if item in attr and attr[item] != '':
                #print 'Validating ' + item
                # Can add a range 
                objRange = PRIM.getRangeValues(attr[item], area, item)
                for object in objRange:
                        (deltaValidation, deltaString) = validateImsi(item, str(object))
                        retText += deltaString
                        if validation: validation = deltaValidation
         '''
         elif area == 'Device':
                outStr = ' ERROR: IMSI missing from device create operation'
                retText += outStr
                #print outStr
                validation = False
         '''
                
        # *** MSISDN ***
        operation = 'Msisdn'
        for area in ['Device', 'Diameter']:
         item = area + operation
         if item in attr and attr[item] != '':
                # Can add a range 
                objRange = PRIM.getRangeValues(attr[item], area, item)
                for object in objRange:
                        (deltaValidation, deltaString) = validateMsisdn(item, str(object))
                        retText += deltaString
                        if validation: validation = deltaValidation
         '''
         elif area == 'Device':
                retText += ' ERROR: MSISDN missing from device create operation'
                validation = False
         '''
                
        # *** Object IDs
        for area in DATA.defaultObjects:
                item = area + 'ObjectId'
                if item in attr and attr[item]:
                        (deltaValidation, deltaString) = validateObjectId(item, attr[item], area)
                        retText += deltaString
                        if validation: validation = deltaValidation
                
        # *** Status (all objects)
        for area in DATA.defaultObjects:
                item = area + 'Status'
                if item in attr and attr[item]:
                        (deltaValidation, deltaString) = validateStatus(item, attr[item], area)
                        retText += deltaString
                        if validation: validation = deltaValidation
                
        # *** Offer External ID
        item = 'OfferExtId'
        if item in attr and attr[item]:
                (deltaValidation, deltaString) = validateOfferExtId(item, attr, offerList)
                retText += deltaString
                if validation: validation = deltaValidation
                
        # *** Offer start Date
        item = 'OfferStartTime'
        if item in attr and attr[item]:
                (deltaValidation, deltaString) = validateDateAndTime(item, attr[item])
                retText += deltaString
                if validation: validation = deltaValidation
                
        # *** Offer end Date.  Adding support for relative times (e.g. 3,day) so don't validate that here.
        item = 'OfferEndTime'
        if item in attr and attr[item] and not attr[item].count('-'):
                (deltaValidation, deltaString) = validateDateAndTime(item, attr[item])
                retText += deltaString
                if validation: validation = deltaValidation
        
                # Make sure end date is greater than start date (or today if not specified)
                if 'OfferStartTime' not in attr:
                        start_time = datetime.now()
                        startTime  = start_time.strftime('%Y-%m-%dT%H:%M:%S')
                else:   startTime  = attr['OfferStartTime']
                
                if startTime >= attr[item]:
                        print(' ERROR: offer end date is <= start date:  end date: ' + attr[item] + ', start date: ' + startTime)
                        validation = False
                        retText = ', offer end date is <= start date:  end date: ' + attr[item] + ', start date: ' + startTime
                
        # **** Need to add more validation here ****
        # If no errors, then need to pad retText
        if not retText: retText = "   "
        return (validation, retText)
        
        #*** LEGACY CODE ***
        
        # *** DOM ***
        # All must be digits
        if not attr['currentBillCycleDate'].isdigit() or not attr['futureBillCycleDate'].isdigit():
                print(' ERROR:  All DOM values must be integers')
                validation = False
                retText += ', All DOM values must be integers'
#               sys.exit('Exiting due to errors')
                
        # All must be 8 characters in length
        if (len(attr['currentBillCycleDate'])) != 8 or (len(attr['futureBillCycleDate']) != 8):
                print(' ERROR:  All DOM values must be 8 characters in length')
                validation = False
                retText += ', All DOM values must be 8 characters in length'
#               sys.exit('Exiting due to errors')
                
        else:
         # Validate the rest of the DOM
         currentDay = int(attr['currentBillCycleDate'][6:])
         futureDay  = int(attr['futureBillCycleDate'][6:])
         
         currentMonth = int(attr['currentBillCycleDate'][4:6])
         futureMonth  = int(attr['futureBillCycleDate'][4:6])
         
         currentYear = int(attr['currentBillCycleDate'][0:4])
         futureYear  = int(attr['futureBillCycleDate'][0:4])
         
         # PULLED THIS LOGIC (late) - comment out in case it gets added back in.
         # NOTE: Need to add one day to every DOM, as the current system DOM ends at 23:59:59 and MTX DOM starts at 00:00:00.
         #       Separate out month/day/year components.
#        currentDay += 1
#        futureDay  += 1
        
         # For now, assume the month is May (otherwise need more logic to check if we need to go to a new month or year).
         # Future month could be the current month (DOM change) or the month after the current month end.
         testCurrentMonthStart = 5
         testCurrentMonthEnd   = testCurrentMonthStart + 1
         testFutureMonthStart  = testCurrentMonthStart
         testFutureMonthEnd    = testCurrentMonthEnd + 1
         
         # Note that June has only 30 days and customer only allows billing dates up to the 29th, so no issues here...
         # Check to be safe: Only check if day 31 went to day 32, as other errors (e.g. day was set to 50) we want to flag as invalid.
#        if currentDay == 32:
#               currentDay = 1
#               currentMonth += 1
         
#        if futureDay == 32:
#               futureDay = 1
#               futuremonth += 1
         
         # June only has 30 days, so again there shouldn't be any issues with a new date on the 31 (so not hit with max DOM of 29), but check to be safe.
#        if futureDay == 31: futureDay = 30
         
         # DOMs must be a valid day of the month
         if (currentDay > 31) or (currentDay < 1):
                print(' ERROR:  Invalid current DOM day of the month: ' + attr['currentBillCycleDate'])
                validation = False
                retText += ', Invalid current DOM day of the month'
#               sys.exit('Exiting due to errors')
        
         if (futureDay > 31) or (futureDay < 1):
                print(' ERROR:  Invalid future DOM day of the month: ' + attr['futureBillCycleDate'])
                validation = False
                retText += ', Invalid future DOM day of the month'
#               sys.exit('Exiting due to errors')
        
         # DOMs must be a current or next  month
         if (currentMonth != testCurrentMonthStart) and (currentMonth != testCurrentMonthEnd):
                print(' ERROR:  Invalid current DOM month: ' + attr['currentBillCycleDate']  + '.  Must be between ' + str(testCurrentMonthStart) + ' and ' + str(testCurrentMonthEnd) + '.')
                validation = False
                retText += ', Invalid current DOM month'
#               sys.exit('Exiting due to errors')
        
         if (futureMonth < testFutureMonthStart) or (futureMonth > testFutureMonthEnd):
                print(' ERROR:  Invalid future DOM month: ' + attr['futureBillCycleDate'] + '.  Must be between ' + str(testFutureMonthStart) + ' and ' + str(testFutureMonthEnd) + '.')
                validation = False
                retText += ', Invalid future DOM month'
#               sys.exit('Exiting due to errors')
        
         # DOMs must be a this year
         year = 2014
         if currentYear != year:
                print(' ERROR:  Invalid current DOM year: ' + attr['currentBillCycleDate'])
                validation = False
                retText += ', Invalid current DOM year'
#               sys.exit('Exiting due to errors')
        
         if futureYear != year:
                print(' ERROR:  Invalid future DOM year: ' + attr['futureBillCycleDate'])
                validation = False
                retText += ', Invalid future DOM year'
#               sys.exit('Exiting due to errors')
        
         # Build the new DOM values
         attr['currentBillCycleDate'] = str(str(currentYear) + str(currentMonth).zfill(2) + str(currentDay).zfill(2))
         attr['futureBillCycleDate']  = str(str(futureYear)  + str(futureMonth).zfill(2)  + str(futureDay).zfill(2))
         #print 'Current/future DOM: ' + attr['currentBillCycleDate'] + '/' + attr['futureBillCycleDate']
        
        # If no errors, then need to pad retText
        if not retText: retText = "   "
        return (validation, retText)

#==========================================================
def main():
    x = 1

if __name__ == '__main__':
    main()

