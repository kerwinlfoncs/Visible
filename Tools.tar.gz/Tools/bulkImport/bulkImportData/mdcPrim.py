#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-12-03T09:30:31
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-12-03T09:30:31
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-12-03T09:30:30

# Python imports
from __future__ import print_function
from __future__ import absolute_import
from __future__ import division
# from builtins import zip
# from builtins import hex
# from builtins import str
# from builtins import range
# from builtins import zip
# from builtins import hex
# from builtins import str
# from builtins import range
from past.utils import old_div
import sys, copy, time, pprint, os, inspect
#from primitives import clock

# Product imports
import data_container_defs as MDCDEFS
from   dateutil.relativedelta import relativedelta
from   dateutil.parser import parse
from   datetime import date, datetime
from   dateutil.tz import *
from . import offerOperations as Offer
from . import data2 as DATA
from . import prim as PRIM
import subscriber_mgmt_v3 as subman
from . import getResourceIds as RESOURCE
from . import bulkDiameter as BULKDIAM
from . import bulkCB as BULKCB

diamConnection = None

import time
import functools

# Define decorator
def clock2(func):
        # Get name of caller
        @functools.wraps(func)
        def clocked(*args, **kwargs):
                t0 = time.time()
                result = func(*args, **kwargs)
                elapsed = time.time() - t0
                print('Elapsed time for function = ' + func.__name__ + ': ' + str(elapsed))
                return result
        return clocked

#===============================================================================
# Add device to a subscriber
# Supports ranges for devices.
# Can add devies 1:1 to range of subscribers, all devices to one sub, or multiple device across multiple subs *if dev count is a multiple of sub count)
#@clock2
def AddToSubscriber(customData, attr, config, submanBuilder, options, object):
        area = object['object']
        operation = area + 'AddToSubscriber'
        queryValue = object['queryValue']
        queryType = object['queryType']
        subscriberQueryType = object['SubscriberQueryType']
        subscriberQueryValue = object['SubscriberQueryValue']
        
        # Debug output
        if options and options.verbose_flag: print('AddToSubscriber: object = ' + str(object))
        
        # Validate device data here.  Really should validate everything...
        if area == 'Device':
                # Check if IMSI defined.  Initial validation doesn;t check command + parameter; only checks if parmeter is supplied it's correct.
                if str(queryValue) in ['', 'None']: 
                        print('ERROR: Device to add missing from record. Skipping this device')
                        return True
        
        # Can add a range of devices to a sub
        devRange = PRIM.getRangeValues(queryValue, area, operation, options=options)
        numDevices = len(devRange)
                
        # Can add to a range of subscribers
        subRange = PRIM.getRangeValues(subscriberQueryValue, 'Subscriber', operation, options=options)
        numSubs = len(subRange)
        
        # Debug output
        if options and options.verbose_flag:
                print('AddToSubscriber: subRange = ' + str(subRange))
                print('AddToSubscriber: numSubs = ' + str(numSubs))
        
        # Get number of devices per sub
        numDevicesPerSub = int(old_div(numDevices, numSubs))
        
        # Setup list of subs.
        # Can add eveything to one subscriber (no sub range), or add 1:1 (if a sub range was input).
        subList = []
        if len(subRange) == 1: subList.extend([subRange[0]] * numDevices)
        else:                  subList = subRange
        
        # Sanity check.  dev list should be a multiple of subList (so can add multiple devices to a sub)
        if float(old_div(numDevices, numSubs)) != float(numDevicesPerSub):
                print(operation + ' device list is not a multiple of sublist subList(' + str(numSubs) + ': ' + str(subList) + ', device(' + str(numDevices) + ' range from ' + str(itemRangeStart) + ' to ' + str(itemRangeEnd))
                sys.exit('Exiting due to errors')
        
        # Process each device
        subIdx = -1
        for devIdx,i in zip(devRange, list(range(len(devRange)))):
                # See if it's time to increment the sub index
                if not (i % numDevicesPerSub): subIdx += 1
                
                # See if we've already done this operation already for the specified object
                if str(devIdx) in DATA.objectList[area][operation]: continue
                
                # Add to the list
                DATA.objectList[area][operation][str(devIdx)] = True
                
                # Debug output
                if options and options.verbose_flag:
                        print('Adding ' + area + ' ' + str(devIdx) + '(' + queryType + ')' + \
                                ' to subscriber ID: ' + str(subList[subIdx]) + '(' + subscriberQueryType + ')')

                # Add device MDC
                requestMdc = submanBuilder.subscriberAddDevice(subQueryType=subscriberQueryType, subQueryValue=subList[subIdx], \
                                                              devQueryType=queryType, devQueryValue=str(devIdx))
        
                # Store the MDC container in the corresponding operation list
                if requestMdc: DATA.updateMdcInfo(requestMdc, operation, config, area, submanBuilder, str(devIdx), queryType)
        
        return True
        
#===============================================================================
# Add subscriber to user 
# Supports ranges for the subs or groups to be added.
#@clock2
def AddToUser(customData, attr, config, submanBuilder, options, object):
        area = object['object']
        operation = area + 'AddToUser'
        queryValue = object['queryValue']
        queryType = object['queryType']
        userQueryType = object['UserQueryType']
        userQueryValue = object['UserQueryValue']

        # Can add a range of subs to a user, or one sub to one user across a range...
        subRange = PRIM.getRangeValues(queryValue, area, operation, options=options)
        userRange = PRIM.getRangeValues(userQueryValue, 'User', operation, options=options)
        
        # Plow through subs to add
        for i,sub in enumerate(subRange):
                # See if we've already done this operation already for the specified object
                if str(sub) in DATA.objectList[area][operation]: continue
        
                # Add to the list
                DATA.objectList[area][operation][str(sub)] = True
        
                # Debug output
                if options.verbose_flag: print('Adding ' + area + ' ' + str(sub) + '(' + queryType + ')' + ' to user ' + userQueryValue + '(' + userQueryType + ')')
                
                # Hard-code role
                roles = [{'ExternalId': 'Owner'}]
                
                # Get user to add to.  If sub exceeds user array length, then add to the last user
                try:    userValue = userRange[i]
                except: userValue = userRange[-1]
                
                # Execute operation
                requestMdc = submanBuilder.userAddSubscription(userQueryType=userQueryType, userQueryValue=userValue, subQueryValue=sub, subQueryType=queryType, roles=roles)
                
                # Store the MDC container in the corresponding operation list
                if requestMdc: DATA.updateMdcInfo(requestMdc, operation, config, area, submanBuilder, str(sub), queryType)
                
        return True
        
#===============================================================================
# Remive subscriber/group to a group
# Supports ranges for the subs or groups to be added.
#@clock2
def RemoveFromGroup(customData, attr, config, submanBuilder, options, object):
        area = object['object']
        operation = area + 'RemoveFromGroup'
        queryValue = object['queryValue']
        queryType = object['queryType']
        groupQueryType = object['GroupQueryType']
        groupQueryValue = object['GroupQueryValue']

        # Can add a subscriber or a group
        if area.lower() == 'subscriber':
                # Can add a range of subs to a group
                subRange = PRIM.getRangeValues(queryValue, area, operation, options=options)
                
                # Need to get single value for parent group. Always use starting value. 
                groupRange = PRIM.getRangeValues(groupQueryValue, 'Group', operation, options=options)
                groupQueryValue = str(groupRange[0])
                
                # Want to add in batches, so one command per file here
                saveCount = int(config['Program']['batchSize'])
                config['Program']['batchSize'] = 1
                
                # Plow through subs to add
                i = 0
                end = 10000
                batchSize = 100
                print('Removing ' + str(len(subRange)) + ' subscribers')
                while end >= batchSize:
                        # Edge case - if adding exactly a multiple of the batch size then break here
                        if not len(subRange[i:]): break
                        
                        # Get end of range
                        if len(subRange[i:]) >= batchSize:
                                end = batchSize
                        else:   end = len(subRange[i:])
                        
                        # Get range to add
                        subs = subRange[i:i+end]
                
                        # Debug output
                        if options.verbose_flag: print('Adding ' + area + ' ' + str(subs) + '(' + queryType + ')' + ' to group ' + groupQueryValue + '(' + groupQueryType + ')')
                        #print 'Adding ' + area + ' ' + str(subs) + '(' + queryType + ')' + ' to group ' + groupQueryValue + '(' + groupQueryType + ')'
                        
                        # Define search data for each subscriber
                        subscriberSearchArray = []
                        for sub in subs:
                                # Define search data
                                subscriberSearch = subman.newSubscriberSearch(queryType, str(sub))
                                
                                # Add to array
                                subscriberSearchArray.append((subscriberSearch))
                                
                        # Build the request
                        requestMdc = submanBuilder.groupRemoveMembership(queryType=groupQueryType, queryValue=groupQueryValue, subscriberSearchArray=subscriberSearchArray)
                        
                        # Store the MDC container in the corresponding operation list
                        if requestMdc: DATA.updateMdcInfo(requestMdc, operation, config, area, submanBuilder, str(sub), queryType)
                        
                        # Bump index
                        i += end
                
                # Restore batch value
                config['Program']['batchSize'] = saveCount
        else:
                # Can add a range of groups to a group
                groupRange = PRIM.getRangeValues(groupQueryValue, area, operation, options=options)
                
                # Need to get single value for parent group. Always use starting value. 
                groupParentRange = PRIM.getRangeValues(queryValue, area, operation, options=options)
                queryValue = str(groupParentRange[0])
                
                # Plow through sub groups to add
                for group in groupRange:
                        # See if we've already done this operation already for the specified object
                        if str(group) in DATA.objectList[area][operation]: continue
                
                        # Add to the list
                        DATA.objectList[area][operation][str(group)] = True
                
                        # Debug output
                        if options.verbose_flag: print('Adding ' + area + ' ' + str(group) + '(' + queryType + ')' + ' to group ' + groupQueryValue + '(' + groupQueryType + ')')
        
                        # Define search data
                        groupSearch = subman.newGroupSearch(groupQueryType, str(group))
                        requestMdc = submanBuilder.groupAddMembership(queryType=queryType, queryValue=queryValue, subGroupSearchArray=[groupSearch])
        
                        # Store the MDC container in the corresponding operation list
                        if requestMdc: DATA.updateMdcInfo(requestMdc, operation, config, area, submanBuilder, str(group), queryType)
                
        return True
        
#===============================================================================
# Add subscriber/group to a group
# Supports ranges for the subs or groups to be added.
#@clock2
def AddToGroup(customData, attr, config, submanBuilder, options, object):
        area = object['object']
        operation = area + 'AddToGroup'
        queryValue = object['queryValue']
        queryType = object['queryType']
        groupQueryType = object['GroupQueryType']
        groupQueryValue = object['GroupQueryValue']

        # Can add a subscriber or a group
        if area.lower() == 'subscriber':
                # Can add a range of subs to a group
                subRange = PRIM.getRangeValues(queryValue, area, operation, options=options)
                
                # Need to get single value for parent group. Always use starting value. 
                groupRange = PRIM.getRangeValues(groupQueryValue, 'Group', operation, options=options)
                groupQueryValue = str(groupRange[0])
                
                # Want to add in batches, so one command per file here
                saveCount = int(config['Program']['batchSize'])
                config['Program']['batchSize'] = 1
                
                # Plow through subs to add
                i = 0
                end = 10000
                batchSize = 100
                print('Adding ' + str(len(subRange)) + ' subscribers')
                while end >= batchSize:
                        # Edge case - if adding exactly a multiple of the batch size then break here
                        if not len(subRange[i:]): break
                        
                        # Get end of range
                        if len(subRange[i:]) >= batchSize:
                                end = batchSize
                        else:   end = len(subRange[i:])
                        
                        # Get range to add
                        subs = subRange[i:i+end]
                
                        # Debug output
                        if options.verbose_flag: print('Adding ' + area + ' ' + str(subs) + '(' + queryType + ')' + ' to group ' + groupQueryValue + '(' + groupQueryType + ')')
                        #print 'Adding ' + area + ' ' + str(subs) + '(' + queryType + ')' + ' to group ' + groupQueryValue + '(' + groupQueryType + ')'
                        
                        # Define search data for each subscriber
                        subscriberSearchArray = []
                        for sub in subs:
                                # Add sub information
                                subscriberSearch = subman.newSubscriberSearch(queryType, str(sub))
                                subscriberSearchArray.append((subscriberSearch))
                        
                        # Build request
                        requestMdc = submanBuilder.groupAddMembership(queryType=groupQueryType, queryValue=groupQueryValue, subscriberSearchArray=subscriberSearchArray)
                        
                        # Store the MDC container in the corresponding operation list
                        if requestMdc: DATA.updateMdcInfo(requestMdc, operation, config, area, submanBuilder, str(sub), queryType)
                        
                        # Bump index
                        i += end
                
                # Restore batch value
                config['Program']['batchSize'] = saveCount
        else:
                # Can add a range of groups to a group
                groupRange = PRIM.getRangeValues(groupQueryValue, area, operation, options=options)
                
                # Need to get single value for parent group. Always use starting value. 
                groupParentRange = PRIM.getRangeValues(queryValue, area, operation, options=options)
                queryValue = str(groupParentRange[0])
                
                # Plow through sub groups to add
                for group in groupRange:
                        # See if we've already done this operation already for the specified object
                        if str(group) in DATA.objectList[area][operation]: continue
                
                        # Add to the list
                        DATA.objectList[area][operation][str(group)] = True
                
                        # Debug output
                        if options.verbose_flag: print('Adding ' + area + ' ' + str(group) + '(' + queryType + ')' + ' to group ' + groupQueryValue + '(' + groupQueryType + ')')
        
                        # Define search data
                        groupSearch = subman.newGroupSearch(groupQueryType, str(group))
                        requestMdc = submanBuilder.groupAddMembership(queryType=queryType, queryValue=queryValue, subGroupSearchArray=[groupSearch])
        
                        # Store the MDC container in the corresponding operation list
                        if requestMdc: DATA.updateMdcInfo(requestMdc, operation, config, area, submanBuilder, str(group), queryType)
                
        return True
        
#===============================================================================
def InputOffers(customData, attr, config, submanBuilder, options, object):
        retCode = processOffers(customData, attr, config, submanBuilder, 'Input', options, object, operationType='purchase')
        
        return retCode
        
#===============================================================================
def RequiredOffers(customData, attr, config, submanBuilder, options, object):
        retCode = processOffers(customData, attr, config, submanBuilder, 'Required', options, object, operationType='purchase')
        
        return retCode
        
#===============================================================================
def OptionalOffers(customData, attr, config, submanBuilder, options, object):
        retCode = processOffers(customData, attr, config, submanBuilder, 'Optional', options, object, operationType='purchase')
        
        return retCode
        
#===============================================================================
def ModifyOffers(customData, attr, config, submanBuilder, options, object):
        retCode = processOffers(customData, attr, config, submanBuilder, 'Modify', options, object, operationType='modify')
        
        return retCode
        
#===============================================================================
def CancelOffers(customData, attr, config, submanBuilder, options, object):
        retCode = processOffers(customData, attr, config, submanBuilder, 'Cancel', options, object, operationType='cancel')
                
        return retCode
        
#===============================================================================
#@clock2
def GetResourceIds(customData, attr, config, submanBuilder, options, object):
        area = object['object']
        queryType = object['queryType']
        queryValue = object['queryValue']
        
        # Invoke the resource retrieval
        param = area + '_' + queryType + '_' + queryValue
        #print 'invoking resource function with parameter ' + param
        return RESOURCE.resourceIdFunction.send(param)
        
#===============================================================================
#@clock2
def getBalanceResourceId(queryValue, templateId, resourceId):
        #print 'getBalanceResourceId: queryValue/templateId/resourceId = ' + str(queryValue) + '/' + str(templateId) + '/' + str(resourceId)
        if str(resourceId) != 'None': return resourceId
        
        found = None
        # Walk the balance resources
        for key in RESOURCE.objectResourceIds[queryValue]['balance']:
                # Find a match.  Input may specify either or both template ID and resource ID
                if templateId and resourceId and templateId == RESOURCE.objectResourceIds[queryValue]['balance'][key]['TemplateId'] and resourceId == RESOURCE.objectResourceIds[queryValue]['balance'][key]['ResourceId']:
                        # Found a match
                        found = key
                        break
                
                if templateId and not resourceId and templateId == RESOURCE.objectResourceIds[queryValue]['balance'][key]['TemplateId']:
                        # Found a match
                        # Check if we already found one (error if so).
                        if found: sys.exit('ERROR. Operation ' + operation + ': template ID' + str(templateId) + ' has more than one instance.  Must specify the resource ID in this case.')
                        found = key
                        
                        # No break here since we may find another instance of this
                        continue

                if not templateId and resourceId and resourceId == RESOURCE.objectResourceIds[queryValue]['balance'][key]['ResourceId']:
                        # Found a match
                        found = key
                        break
        
        # Check if nothing found (can't use else since we check past first found if only template ID specified)
        if not found:
                print('ERROR: template ID ' + str(templateId) + ' respurce ID ' + str(resourceId) + ' not found in ID ' + queryValue)
                sys.exit('Exiting due to errors')
        
        # Copy resource ID in case it wasn't speceified
        return RESOURCE.objectResourceIds[queryValue]['balance'][found]['ResourceId']
        
#===============================================================================
#@clock2
def AdjustBalance(customData, attr, config, submanBuilder, options, object):
        '''
        print 'AdjustBalance: object = ' + str(object)
        print 'attr = ' + str(attr)
        '''
        area = object['object']
        action = 'AdjustBalance'
        operation = area + action
        
        # Create locals for all possible parameters
        allParams = attr.copy()
        allParams.update(object)
        lclDCT = {}
        for field in list(DATA.CONFIGDATA[area].keys()) + list(attr.keys()) + list(object.keys()):
                # Don't overwrite the object...
                if field == 'object': continue
                
                # Build and execute command
                #cmd = field + ' = PRIM.getPrioritizedFieldValue(customData, allParams, field, "' + area + '", config, options)'
                #print(cmd)
#                exec(cmd)
                lclDCT[field] = PRIM.getPrioritizedFieldValue(customData, allParams, field, area, config, options)
        
        queryType = object['queryType']
        queryValue = object['queryValue']
        resourceId = object['ResourceIds']
        
        # Get input template ID
        templateId = object['TemplateId']
        
        # Walk the resource balance data to find the entry that matches to the template ID
        balanceResourceId = getBalanceResourceId(queryValue, templateId, resourceId)
        
        # Get local time accountng for timezone
        startTime = datetime.now(tzlocal())
        timeZone = startTime.tzinfo  #save the timezone
        startTime = startTime.strftime('%Y-%m-%dT%H:%M:%S%z')
        #print 'Setting startTime = ' + startTime
        # See if we've already done this operation already for the specified object.
        # Allow multiple operations of this type.
#              if queryValue in DATA.objectList[area][operation]: continue
        
        # Add to the list
        DATA.objectList[area][operation][queryValue] = True
        
        # If supposed to verify, then update that data
        if DATA.config[area]['Verify']:
                operation = area + action
                key = queryType + '$' + queryValue
                if not key in DATA.VerifyObject[area]: DATA.VerifyObject[area][key] = {}
                if not operation in DATA.VerifyObject[area][key]: DATA.VerifyObject[area][key][operation] = []
                for param in list(DATA.CONFIGDATA[area].keys()):
                        # Skip if offer parameter (handled in the offers section) or a verify parameter (not part of any update).
                        # Also skip if external ID, as this will be the key for validation in the query response.
                        if param.count('Offer') or param.count('Verify') or param in ['ExternalId']: continue
                        
                        # Build command to exec
                        cmd = 'if ' + param + ': DATA.VerifyObject[area][key][operation].append(("' + str(queryValue) + '", "' + str(queryType) + '", "' + str(param) + '",' + str(param) + ', False))'
#                       print operation + ' command: ' + cmd
                        exec(cmd)
                                
#               print 'DATA.VerifyObject for ' + area + ' ' + operation + ': ' + str(DATA.VerifyObject[area][operation])

        # Make the actual calls to the MDC APIs per-release
        # Get the MDC structure for this operation
        if area == 'Subscriber': requestMdc = submanBuilder.subscriberAdjustBalance( \
                queryType=queryType, queryValue=queryValue, balanceResourceId=balanceResourceId, \
                adjustType=lclDCT['AdjustType'], amount=lclDCT['Amount'], reason=lclDCT['Reason'], info=lclDCT['Info'], endTime=lclDCT['EndTime'], \
                endTimeExtensionOffsetUnit=lclDCT['EndTimeExtensionOffsetUnit'], endTimeExtensionOffset=lclDCT['EndTimeExtensionOffset'])
        
        if area == 'Group': requestMdc = submanBuilder.groupAdjustBalance( \
                queryType=queryType, queryValue=queryValue, balanceResourceId=balanceResourceId, \
                adjustType=lclDCT['AdjustType'], amount=lclDCT['Amount'], reason=lclDCT['Reason'], info=lclDCT['Info'], endTime=lclDCT['EndTime'], \
                endTimeExtensionOffsetUnit=lclDCT['EndTimeExtensionOffsetUnit'], endTimeExtensionOffset=lclDCT['EndTimeExtensionOffset'])
                
        # Store the MDC container in the corresponding operation list
        if requestMdc: DATA.updateMdcInfo(requestMdc, operation, config, area, submanBuilder, queryValue, queryType)
                
        return True
        
#===============================================================================
#@clock2
def ImportBalance(customData, attr, config, submanBuilder, options, object):
        area = object['object']
        action = 'StopBalance'
        operation = area + action
        queryType = object['queryType']
        queryValue = object['queryValue']
        resourceId = object['ResourceId']
        
        # Get input template ID
        templateId = object['TemplateId']
        
        # Walk the resource balance data to find the entry that matches to the template ID
        balanceResourceId = getBalanceResourceId(queryValue, templateId, resourceId)
        
        # Create locals for all possible parameters
        for field in list(DATA.CONFIGDATA[area].keys()):
                cmd = field + ' = PRIM.getPrioritizedFieldValue(customData, attr, field, "' + area + '", config, options)'
                #print cmd
                exec(cmd)
        
        # Get local time accountng for timezone
        startTime = datetime.now(tzlocal())
        timeZone = startTime.tzinfo  #save the timezone
        startTime = startTime.strftime('%Y-%m-%dT%H:%M:%S%z')
        print('Setting startTime = ' + startTime)
        # See if we've already done this operation already for the specified object.
        # Allow multiple operations of this type.
#              if queryValue in DATA.objectList[area][operation]: continue
        
        # Add to the list
        DATA.objectList[area][operation][queryValue] = True
        
        # If supposed to verify, then update that data
        if DATA.config[area]['Verify']:
                operation = area + action
                key = queryType + '$' + queryValue
                if not key in DATA.VerifyObject[area]: DATA.VerifyObject[area][key] = {}
                if not operation in DATA.VerifyObject[area][key]: DATA.VerifyObject[area][key][operation] = []
                for param in list(DATA.CONFIGDATA[area].keys()):
                        # Skip if offer parameter (handled in the offers section) or a verify parameter (not part of any update).
                        # Also skip if external ID, as this will be the key for validation in the query response.
                        if param.count('Offer') or param.count('Verify') or param in ['ExternalId']: continue
                        
                        # Build command to exec
                        cmd = 'if ' + param + ': DATA.VerifyObject[area][key][operation].append(("' + str(queryValue) + '", "' + str(queryType) + '", "' + str(param) + '",' + str(param) + ', False))'
#                       print operation + ' command: ' + cmd
                        exec(cmd)
                                
#               print 'DATA.VerifyObject for ' + area + ' ' + operation + ': ' + str(DATA.VerifyObject[area][operation])

        # Make the actual calls to the MDC APIs per-release
        # Get the MDC structure for this operation
        if area == 'Subscriber': requestMdc = submanBuilder.subscriberImportBalanceValue( \
                queryType=queryType, queryValue=queryValue, balanceResourceId=balanceResourceId, \
                amount=Amount, createOnDemand=OnDemand, startTime=startTime)
        
        if area == 'Group': requestMdc = submanBuilder.groupImportBalanceValue( \
                queryType=queryType, queryValue=queryValue, balanceResourceId=balanceResourceId, \
                amount=Amount, createOnDemand=OnDemand, startTime=startTime)
                
        # Store the MDC container in the corresponding operation list
        if requestMdc: DATA.updateMdcInfo(requestMdc, operation, config, area, submanBuilder, queryValue, queryType)
                
        return True
        
#===============================================================================
#@clock2
def StopBalance(customData, attr, config, submanBuilder, options, object):
        area = object['object']
        action = 'StopBalance'
        operation = area + action
        queryType = object['queryType']
        queryValue = object['queryValue']
        resourceId = object['ResourceId']
        
        # Get input template ID
        templateId = object['TemplateId']
        
        # Walk the resource balance data to find the entry that matches to the template ID
        balanceResourceId = getBalanceResourceId(queryValue, templateId, resourceId)
        
        # Get local time accountng for timezone
        endTime = datetime.now(tzlocal())
        timeZone = endTime.tzinfo  #save the timezone
        endTime = endTime.strftime('%Y-%m-%dT%H:%M:%S%z')
        endTime = parse(endTime)
        endTime += relativedelta(seconds=60)
        endTime = endTime.strftime("%Y-%m-%dT%H:%M:%S%z")
        print('Setting endTime = ' + endTime)
#       time.tzset()
#       endTime = time.strftime("%Y-%m-%dT%H:%M:%S%z")
        #endTime = '2016-10-07T08:23:34+08:00'

        # Create locals for all possible parameters
        for field in list(DATA.CONFIGDATA[area].keys()):
                cmd = field + ' = PRIM.getPrioritizedFieldValue(customData, attr, field, "' + area + '", config, options)'
                exec(cmd)
        
        # See if we've already done this operation already for the specified object.
        # Allow multiple operations of this type.
#              if queryValue in DATA.objectList[area][operation]: continue
        
        # Add to the list
        DATA.objectList[area][operation][queryValue] = True
        
        # If supposed to verify, then update that data
        if DATA.config[area]['Verify']:
                operation = area + action
                key = queryType + '$' + queryValue
                if not key in DATA.VerifyObject[area]: DATA.VerifyObject[area][key] = {}
                if not operation in DATA.VerifyObject[area][key]: DATA.VerifyObject[area][key][operation] = []
                for param in list(DATA.CONFIGDATA[area].keys()):
                        # Skip if offer parameter (handled in the offers section) or a verify parameter (not part of any update).
                        # Also skip if external ID, as this will be the key for validation in the query response.
                        if param.count('Offer') or param.count('Verify') or param in ['ExternalId']: continue
                        
                        # Build command to exec
                        cmd = 'if ' + param + ': DATA.VerifyObject[area][key][operation].append(("' + str(queryValue) + '", "' + str(queryType) + '", "' + str(param) + '",' + str(param) + ', False))'
#                       print operation + ' command: ' + cmd
                        exec(cmd)
                                
#               print 'DATA.VerifyObject for ' + area + ' ' + operation + ': ' + str(DATA.VerifyObject[area][operation])

        # Make the actual calls to the MDC APIs per-release
        # Get the MDC structure for this operation
        if area == 'Subscriber': requestMdc = submanBuilder.subscriberAdjustBalance( \
                queryValue=queryValue, balanceResourceId=balanceResourceId, queryType=queryType, endTime=endTime, \
                reason='bulkImport', adjustType='1', amount='0')
#info=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None,
#now=None, creditLimitPolicy=None, startTime=None, eventPass=True)              
        
        if area == 'Group': requestMdc = submanBuilder.groupAdjustBalance( \
                queryValue=queryValue, balanceResourceId=balanceResourceId, queryType=queryType, endTime=endTime, \
                reason='bulkImport', adjustType='1', amount='0')
#info=None, endTimeExtensionOffsetUnit=None, endTimeExtensionOffset=None,
#now=None, creditLimitPolicy=None, startTime=None, eventPass=True)              
                
        # Store the MDC container in the corresponding operation list
        if requestMdc: DATA.updateMdcInfo(requestMdc, operation, config, area, submanBuilder, queryValue, queryType)
                
        return True
        
#===============================================================================
#@clock2
def ModifyThreshold(customData, attr, config, submanBuilder, options, object):
        area = object['object']
        action = 'ModifyThreshold'
        operation = area + action
        queryType = object['queryType']
        queryValue = object['queryValue']
        
        # Create locals for all possible parameters
        for field in list(DATA.CONFIGDATA[area].keys()):
                cmd = field + ' = PRIM.getPrioritizedFieldValue(customData, attr, field, "' + area + '", config, options)'
                exec(cmd)
        
        # Can create a range of objects
        objRange = PRIM.getRangeValues(queryValue, area, operation, options=options)
        
        # Process the range
        for queryValue in objRange:
                # Want this as a string
                queryValue = str(queryValue)
                
                # See if we've already done this operation already for the specified object.
                # Allow multiple operations of this type.
#               if queryValue in DATA.objectList[area][operation]: continue
                
                # Add to the list
                DATA.objectList[area][operation][queryValue] = True
                
                # If supposed to verify, then update that data
                if DATA.config[area]['Verify']:
                        operation = area + action
                        key = queryType + '$' + queryValue
                        if not key in DATA.VerifyObject[area]: DATA.VerifyObject[area][key] = {}
                        if not operation in DATA.VerifyObject[area][key]: DATA.VerifyObject[area][key][operation] = []
                        for param in list(DATA.CONFIGDATA[area].keys()):
                                # Skip if offer parameter (handled in the offers section) or a verify parameter (not part of any update).
                                # Also skip if external ID, as this will be the key for validation in the query response.
                                if param.count('Offer') or param.count('Verify') or param in ['ExternalId']: continue
                                
                                # Build command to exec
                                cmd = 'if ' + param + ': DATA.VerifyObject[area][key][operation].append(("' + str(queryValue) + '", "' + str(queryType) + '", "' + str(param) + '",' + str(param) + ', False))'
#                               print operation + ' command: ' + cmd
                                exec(cmd)
                                
#                      print 'DATA.VerifyObject for ' + area + ' ' + operation + ': ' + str(DATA.VerifyObject[area][operation])

                # Make the actual calls to the MDC APIs per-release
                # Get the MDC structure for this operation
                if area == 'Subscriber': requestMdc = submanBuilder.subscriberAddThreshold( \
                        queryType=queryType, queryValue=queryValue, thresholdId=ThresholdId, \
                        resourceId=ResourceId, thresholdAmount=ThresholdValue, thresholdName=ThresholdName, \
                        recurringStart = ThresholdRecurringStart, recurringStop = ThresholdRecurringStop)
                        
                if area == 'Group': requestMdc = submanBuilder.groupAddThreshold( \
                        queryType=queryType, queryValue=queryValue, thresholdId=ThresholdId, \
                        resourceId=ResourceId, thresholdAmount=ThresholdValue, thresholdName=ThresholdName, \
                        recurringStart = ThresholdRecurringStart, recurringStop = ThresholdRecurringStop)
                        
                # Store the MDC container in the corresponding operation list
                if requestMdc: DATA.updateMdcInfo(requestMdc, operation, config, area, submanBuilder, queryValue, queryType)
                
        return True
        
#===============================================================================
# Does support ranges
#@clock2
def Delete(customData, attr, config, submanBuilder, options, object):
        area = object['object']
        action = 'Delete'
        operation = area + action
        
        '''
        print 'In Delete() 1, area = ' + str(area)
        for section in ['User', 'Subscriber']:
                print 'Section ' + section + ' data:'
                pprint.pprint(DATA.CONFIGDATA[section])
        '''
        
        # Process custom object extension
        Attr = processCustomExtension(customData, attr, config, area)

        # Create locals for all input parameters
        #print 'Keys for area ' + str(area) +': ' + str(DATA.CONFIGDATA[area].keys())
        for field in list(DATA.CONFIGDATA[area].keys()):
                cmd = field + ' = PRIM.getPrioritizedFieldValue(customData, attr, field, "' + area + '", config, options)'
                exec(cmd)
        
        # Validate device data here.  Really should validate everything...
        if area == 'Device':
                # Check if IMSI defined.  Initial validation doesn;t check command + parameter; only checks if parmeter is supplied it's correct.
                if str(Imsi) in ['', 'None']: 
                        print('ERROR: Imsi missing from record. Skipping this device')
                        return True
                
                if str(Msisdn) in ['', 'None']: 
                        print('ERROR: MSISDN missing from record. Skipping this device')
                        return True
                
        # Keys for deletion vary depending on the object
        if area == 'Device':
                # Check if neither IMSI nor MSISDN defined
                if str(Imsi) in ['', 'None'] and str(Msisdn) in ['', 'None']: 
                        print('ERROR: Imsi  and MSISDN missing from record. Skipping deleting this device')
                        return True
                
                queryValue = Imsi
                queryType  = 'PhoneNumber'
                
                # Can also define a range of MSISDN; for now this must be a 1:1 with IMSI.  Future will be NxM IMSI and MSISDN.
                queryValueMsisdn = Msisdn
                msisdnRange = PRIM.getRangeValues(queryValueMsisdn, area, operation, 'Msisdn', options=options)
                Msisdn = str(msisdnRange[0])
                
                # Extra operation string
                extraAction = 'Mobile'
        else:
                queryValue = ExternalId
                queryType  = 'ExternalId'
                extraAction = ''
        
        # Can create a range of objects
        objRange = PRIM.getRangeValues(queryValue, area, operation, options=options)
        #print 'Delete: object ' + area + ': ' + str(objRange)
        
        # Get release
        release = int(config['Program']['release'][0:2])
        
        # Process the range
        for queryValue in objRange:
                # Want this as a string
                queryValue = str(queryValue)
                
                # Put in command variables
                QueryType  = queryType
                QueryValue = queryValue
                
                # See if we've already done this operation already for the specified object
                if QueryValue in DATA.objectList[area][operation]: return True
                        
                # Add to the list
                DATA.objectList[area][operation][QueryValue] = True
                        
                # Add validation data.  Not easy to make a separate function, as it relies on locals set above in an exec command.
                if DATA.config[area]['Verify']:
                        # Build verification data
                        key = QueryType + '$' + QueryValue
                        if not key in DATA.VerifyObject[area]: DATA.VerifyObject[area][key] = {}
                        if not operation in DATA.VerifyObject[area][key]: DATA.VerifyObject[area][key][operation] = []
        
                        for param in list(DATA.CONFIGDATA[area].keys()):
                                # Skip if offer parameter (handled in the offers section) or if a verify parameter (not part of modify operations).
                                # Also skip if external ID, as this will be the key for validation in the query response.
                                if param.count('Offer') or param.count('Verify') or param in ['ExternalId']: continue
                                
                                # Translate NewExternalId to ExernalId
                                if param == 'NewExternalId':    paramName = 'ExternalId'
                                else:                           paramName = param
                                
                                # Build command to exec
                                cmd = 'if ' + param + ': DATA.VerifyObject[area][key][operation].append(("' + paramName + '",' + str(param) + '))'
#                               print operation + ' command: ' + cmd
                                exec(cmd)
                                
#                              print 'DATA.VerifyObject for ' + area + ' ' + operation + ': ' + str(DATA.VerifyObject[area][operation])
                
                # Get release
                release = int(config['Program']['release'][0:2])
                
                # Make the actual calls to the MDC APIs per-release
                # Get the MDC strcuture for this operation
                if release >= 50 and area == 'Subscriber':
                        areaToUse = 'subscription'
                else:   areaToUse = area
                
                # Build the command of additional parameters.
                submanCommand = "submanBuilder." + areaToUse.lower() + action
                cmd = "localArgs = inspect.getargspec(" + submanCommand + ").args"
                exec(cmd)
                paramString = ''
                for item in localArgs:
                        # Skip "self"
                        if item == 'self': continue
                        
                        # Command pulls in non-None parameters into paramString
                        toolParam = item[0].upper() + item[1:]
                        cmd = 'if str(' + toolParam + ') != "None": paramString += \', ' + item + '=' + toolParam + '\''
                        try: exec(cmd)
                        except: pass
                
                cmd = 'requestMdc = ' + submanCommand + "(" + paramString[1:] + ')'
                #print cmd
                exec(cmd)
                
                # Store the MDC container in the corresponding operation list
                if requestMdc: DATA.updateMdcInfo(requestMdc, operation, config, area, submanBuilder, QueryValue, QueryType)
                        
        return True
        
#===============================================================================
# Does NOT support ranges
#@clock2
def Modify(customData, attr, config, submanBuilder, options, object):
        '''
        print 'In Modify, object:'
        pprint.pprint(object)
        '''
        
        area = object['object']
        action = 'Modify'
        operation = area + action
        
        # Create locals for all possible subscriber create parameters
        for field in list(DATA.CONFIGDATA[area].keys()):
                cmd = field + ' = PRIM.getPrioritizedFieldValue(customData, attr, field, "' + area + '", config, options)'
                exec(cmd)

        # Validate device data here.  Really should validate everything...
        if area == 'Device':
                # Check if IMSI defined.  Initial validation doesn;t check command + parameter; only checks if parmeter is supplied it's correct.
                if str(Imsi) in ['', 'None']: 
                        print('ERROR: Imsi missing from record. Skipping this device')
                        return True
                
                if str(Msisdn) in ['', 'None']: 
                        print('ERROR: MSISDN missing from record. Skipping this device')
                        return True
                
        # Process custom object extension
        Attr = processCustomExtension(customData, attr, config, area)
        #print 'In Modify ' + area + ', Attr = ' + str(Attr)

        # If bill cycle data input, then create that structure
        try:
                if BillCycleId: BillingCycle = subman.newBillingCycleData(templateId=BillCycleId, dateOffset=BillCycleDay)
                else:           BillingCycle = None
        except:
                BillingCycle = None

        # Translate status if provided, not a digit, and in the translation table
        try:
                if Status and not Status.isdigit() and Status.lower() in DATA.StatusMap[area]: Status = DATA.StatusMap[area][Status.lower()]
        except: pass
        
        # Ranges not supported, but relative values are.  Call range function so we translate anything relative to absolute.
        #print 'Input to Modify value: ' + object['queryValue']
        objRange = PRIM.getRangeValues(object['queryValue'], area, operation, options=options)
        object['queryValue'] = str(objRange[0])
        #print 'Output from Modify value: ' + object['queryValue']
        
        # If we're changing the external ID, then we need to query using that value versus the old external ID.
        # Also change input data, as that signals what to query (and we'll want to query using the new external ID).
        try:
         if NewExternalId:
                cmdQueryValue = object['queryValue']
                cmdQueryType = object['queryType']
                object['queryType']  = QueryType = 'ExternalId'
                object['queryValue'] = QueryValue = NewExternalId
        except:
                # Stick to existing values
                QueryType  = object['queryType']
                QueryValue = object['queryValue']
                cmdQueryValue = cmdQueryType = None
        
        # See if we've already done this operation already for the specified object
        # ** SKIP this check, as we may want to do multiple modifies.
        #if QueryValue in DATA.objectList[area][operation]: return True
                
        # Add to the list
        DATA.objectList[area][operation][QueryValue] = True
                
        # Add validation data.  Not easy to make a separate function, as it relies on locals set above in an exec command.
        if DATA.config[area]['Verify']:
                # Build verification data
                key = QueryType + '$' + QueryValue
                if not key in DATA.VerifyObject[area]: DATA.VerifyObject[area][key] = {}
                if not operation in DATA.VerifyObject[area][key]: DATA.VerifyObject[area][key][operation] = []

                for param in list(DATA.CONFIGDATA[area].keys()):
                        # Skip if offer parameter (handled in the offers section) or if a verify parameter (not part of modify operations).
                        # Also skip if external ID, as this will be the key for validation in the query response.
                        if param.count('Offer') or param.count('Verify') or param in ['ExternalId']: continue

                        # Translate NewExternalId to ExernalId
                        if param == 'NewExternalId':    paramName = 'ExternalId'
                        else:                           paramName = param

                        # Build command to exec
                        cmd = 'if ' + param + ': DATA.VerifyObject[area][key][operation].append(("' + paramName + '",' + str(param) + '))'
                        #print operation + ' command: ' + cmd
                        exec(cmd)

                        #print 'DATA.VerifyObject for ' + area + ' ' + operation + ': ' + str(DATA.VerifyObject[area][operation])
        
        # Get release
        release = int(config['Program']['release'][0:2])
        
        # Make the actual calls to the MDC APIs per-release.
        # Get the MDC strcuture for this operation.
        if release >= 50 and area == 'Subscriber':
                areaToUse = 'subscription'
        else:   areaToUse = area
        
        # Interworking items:
        # 1. If LastActivityUpdateTime is set, then don't udpate the Status
        #if LastActivityUpdateTime: Status = None
        
        # Build the command of additional parameters.
        submanCommand = "submanBuilder." + areaToUse.lower() + action
        cmd = "localArgs = inspect.getargspec(" + submanCommand + ").args"
        exec(cmd)
        '''
        print 'In ' + area + ' Modify.  localArgs:'
        pprint.pprint(localArgs)
        '''
        paramString = ''
        for item in localArgs:
                # Skip "self"
                if item == 'self': continue
                
                # Command pulls in non-None parameters into paramString
                toolParam = item[0].upper() + item[1:]
                
                # Parameter may not exist (skinnied down things so only essential ones are present)
                try:
                        # HACK ALERT!!  Email strings contain the "@" character, which this tool treats as a list character.  Undo that here.
                        if toolParam == 'NotificationEmail' and NotificationEmail: NotificationEmail = NotificationEmail.replace(",", "@")
                        if toolParam == 'ContactEmail' and ContactEmail: ContactEmail = ContactEmail.replace(",", "@")
                        
                        cmd = 'if str(' + toolParam + ') != "None": paramString += \', ' + item + '=' + toolParam + '\''
                        #print 'In ' + area + ' Modify.  cmd: ' + cmd
                        exec(cmd)
                except: pass
        
        cmd = 'requestMdc = ' + submanCommand + "(" + paramString[1:] + ')'
        #print cmd
        exec(cmd)
        
        # Store the MDC container in the corresponding operation list
        if requestMdc: DATA.updateMdcInfo(requestMdc, operation, config, area, submanBuilder, QueryValue, QueryType, preQueryValue=cmdQueryValue, preQueryType=cmdQueryType)
                
        return True
        
#===============================================================================
# Diameter events
#@clock2
def Diameter(customData, attr, config, submanBuilder, options, object):
        # Init Diameter code for threadhing if not already done so
        if not BULKDIAM.diameterThreadingFlag: BULKDIAM.diameterStartThreads(customData, attr, config, options, object) 
                
        # Push command onto the queue
        BULKDIAM.diameterQueue.put((customData, copy.deepcopy(attr), config, options, copy.deepcopy(object)))
        
        return True
        
#===============================================================================
# CB events
#@clock2
def CB(customData, attr, config, submanBuilder, options, object, inputFile=None):
        
        BULKCB.main(customData, attr, config, submanBuilder, options, object, inputFile=inputFile)
        
        return True
        
#===============================================================================
# Dummy operation to cause Pre-Post query data to be created
#@clock2
def Query(customData, attr, config, submanBuilder, options, object):
        area = object['object']

        # Create locals for all parameters
        for field in list(DATA.CONFIGDATA[area].keys()):
                cmd = field + ' = PRIM.getPrioritizedFieldValue(customData, attr, field, "' + area + '", config, options)'
                #print 'cmd: ' + str(cmd)
                exec(cmd)
        
        # Right now query only by external ID
        queryValue = ExternalId
        queryType  = 'ExternalId'
        
        # See if this object should be added to the query output
        DATA.queryAddCheck(area, submanBuilder, queryValue, queryType, config)

#===============================================================================
# Create comething
#@clock2
def Create(customData, attr, config, submanBuilder, options, object):
        area = object['object']

        # Create locals for all parameters
        #print "Step A: time: " + datetime.now().strftime("%S.%f")
        for field in list(DATA.CONFIGDATA[area].keys()):
                cmd = field + ' = PRIM.getPrioritizedFieldValue(customData, attr, field, "' + area + '", config, options)'
                #print 'cmd: ' + str(cmd)
                exec(cmd)

        #print "Step B: time: " + datetime.now().strftime("%S.%f")
        # If bill cycle data input, then create that structure
        try:
                if BillCycleId: BillingCycle = subman.newBillingCycleData(templateId=BillCycleId, dateOffset=BillCycleDay)
                else:           BillingCycle = None
        except:
                BillingCycle = None

        # Translate status if provided, not a digit, and in the translation table
        try:
                if Status and not Status.isdigit() and Status.lower() in DATA.StatusMap[area]: Status = DATA.StatusMap[area][Status.lower()]
        except: pass
        
        # Process custom object extension
        Attr = processCustomExtension(customData, attr, config, area)
        #print 'In Create ' + area + ', Attr = ' + str(Attr)
        
        # Add validation data.  Not easy to make a separate function, as it relies on locals set above in an exec command.
        action = 'Create'
        
        # Define the operation
        operation = area + 'Create'
        
        # Keys for creation vary depending on the object
        if area == 'Device':
                # Check if IMSI defined.  Initial validation doesn;t check command + parameter; only checks if parmeter is supplied it's correct.
                if str(Imsi) in ['', 'None']: 
                        print('ERROR: Imsi missing from record. Skipping this device')
                        return True
                
                if str(Msisdn) in ['', 'None']: 
                        print('ERROR: MSISDN missing from record. Skipping this device')
                        return True
                
                queryValue = Imsi
                queryType  = 'PhoneNumber'
                
                # Can also define a range of MSISDN; for now this must be a 1:1 with IMSI.  Future will be NxM IMSI and MSISDN.
                queryValueMsisdn = Msisdn
                msisdnRange = PRIM.getRangeValues(queryValueMsisdn, area, operation, 'Msisdn', options=options)
                Msisdn = str(msisdnRange[0])
                
                # Extra operation string
                extraAction = 'Mobile'
        else:
                queryValue = ExternalId
                queryType  = 'ExternalId'
                extraAction = ''
        
        # Can create a range of objects
        objRange = PRIM.getRangeValues(queryValue, area, operation, options=options)
        #print 'Create: object ' + area + ': ' + str(objRange)
        
        # Get release
        release = int(config['Program']['release'][0:2])
        
        # Process the range
        for queryValue in objRange:
                #print "Step D: time: " + datetime.now().strftime("%S.%f")
                # Want this as a string
                queryValue = str(queryValue)
                
                # If query value specified, then other stuff to possibly do
                if queryValue != 'None':
                        # See if we've already done this operation already for the specified object
                        if queryValue in DATA.objectList[area][operation]: continue
                        
                        # Add to the list
                        DATA.objectList[area][operation][queryValue] = True
                        
                        # If supposed to verify, then update that data
                        if DATA.config[area]['Verify']:
                                operation = area + action
                                key = queryType + '$' + queryValue
                                if not key in DATA.VerifyObject[area]: DATA.VerifyObject[area][key] = {}
                                if not operation in DATA.VerifyObject[area][key]: DATA.VerifyObject[area][key][operation] = []
                                for param in list(DATA.CONFIGDATA[area].keys()):
                                        # Skip if offer parameter (handled in the offers section) or a verify parameter (not part of any update).
                                        # Also skip if external ID, as this will be the key for validation in the query response.
                                        if param.count('Offer') or param.count('Verify') or param in ['ExternalId']: continue
                                        
                                        # Build command to exec
                                        cmd = 'if ' + param + ': DATA.VerifyObject[area][key][operation].append(("' + str(queryValue) + '", "' + str(queryType) + '", "' + str(param) + '",' + str(param) + ', False))'
                                        #print operation + ' command: ' + cmd
                                        exec(cmd)
                                        
                               #print 'DATA.VerifyObject for ' + area + ' ' + operation + ': ' + str(DATA.VerifyObject[area][operation])
                else:   queryValue = None
                
                # Setup locals for API calls
                QueryType = queryType
                QueryValue = queryValue
                
                # Make the actual calls to the MDC APIs per-release
                # Get the MDC strcuture for this operation
                if release >= 50 and area == 'Subscriber':
                        areaToUse = 'subscription'
                else:   areaToUse = area
                
                # Here's where we hack since the APIs are not perfectly symmetrical
                if area == 'Device':
                        Imsi = QueryValue
                        AccessNumbers = [Msisdn]
                
                        # Bump MSISDN, so we can add a range of devices
                        Msisdn = str(int(Msisdn)+1)
                        
                elif area.startswith('Sub') or area == 'User':
                        # ExternalID needs to be unique
                        ExternalId = QueryValue
                
                # Build the command of additional parameters
                submanCommand = "submanBuilder." + areaToUse.lower() + action + extraAction
                cmd = "localArgs = inspect.getargspec(" + submanCommand + ").args"
                exec(cmd)
                
                paramString = ''
                '''
                print 'In ' + area + ' Create.  localArgs:'
                pprint.pprint(localArgs)
                '''
                #print "Step L: time: " + datetime.now().strftime("%S.%f")
                for item in localArgs:
                        # Skip "self"
                        if item == 'self': continue
                        
                        # Command pulls in non-None parameters into paramString
                        toolParam = item[0].upper() + item[1:]
                        
                        # HACK ALERT!!  Email strings contain the "@" character, which this tool treats as a list character.  Undo that here.
                        if toolParam == 'NotificationEmail' and NotificationEmail: NotificationEmail = NotificationEmail.replace(",", "@")
                        if toolParam == 'ContactEmail' and ContactEmail: ContactEmail = ContactEmail.replace(",", "@")
                        
                        # Build/execute command
                        cmd = 'if str(' + toolParam + ') != "None": paramString += \', ' + item + '=' + toolParam + '\''
                        #print cmd
                        try:    exec(cmd)
                        except: pass
                
                cmd = 'requestMdc = ' + submanCommand + "(" + paramString[1:] + ')'
                #print cmd
                #print "Step M: time: " + datetime.now().strftime("%S.%f")
                exec(cmd)
                
                # Store the MDC container in the corresponding operation list
                #print "Step N: time: " + datetime.now().strftime("%S.%f")
                if requestMdc: DATA.updateMdcInfo(requestMdc, operation, config, area, submanBuilder, queryValue, queryType)
                
        return True
#===============================================================================
#@clock2
def processCustomExtension(customData, attr, config, area):
        # Put data into local
        customName = customData[area]['customName'].split('/')[0]
        #print 'In processCustomExtension, area = ' + area + ', customName = ' + str(customName)
        
        # Exit if no custom container defined
        if not customName: return None

        # Someone (who shall not be named Avi) created lots of custom containers.  These are not supported by the engine.
        # Need to get around these.  [Really should remove them from create_config.info...]
        eventsToRemove = os.getenv("eventsToRemove", None)
        if eventsToRemove:
                #print 'looking to remove events: ' + eventsToRemove
                # Turn into list
                eventsToRemove = eventsToRemove.split(',')
                
                # Check each event to remove
                for event in eventsToRemove:
                        # See if input custom name is part of events to remove
                        if customName.count(event):
                                print('Skipping custom container ' + customName)
                                return None
        
        # Create the extension name if defined
        extension = None
        if customName.count('User'):
                cmd = 'extension = MDCDEFS.k' + customName + 'MdcDesc.create()'
        else:   cmd = 'extension = MDCDEFS.k' + customName + 'ExtensionMdcDesc.create()'
        exec(cmd)

        # Walk the custom fields
        fieldToPrint = 'KEF'
        #pprint.pprint(customData[area])
        for i in range(len(customData[area]['customFields'])):
                field = customData[area]['customFields'][i]
                
                # Get prioritized value
                fieldValue = PRIM.getPrioritizedFieldValue(customData, attr, field, area, config, DATA.options)

                # If field value set, then add to the structure.  Check for 0 so this is added (important for migrations)
                if fieldValue or fieldValue == 0:
                        '''
                        if field == fieldToPrint: print field + ': ' + str(fieldValue)
                        
                        # Need to properly escape strings that we may have read from pricing (as that comes back in a format cMDC doesn't work with
                        #if field == 'FriendlyName': print field + ' type: ' + str(type(fieldValue))
                        if type(fieldValue) in [str, unicode]:
                                savedFieldValue = fieldValue
                                
                                # Check for this
                                if fieldValue.count('&#'): print 'Encountered a Unicode string in the string'
                                
                                # Check for non-ASCII
                                # Following line causes exec errors (called in sub-function).
                                #if not all(ord(c) < 128 for c in fieldValue):
                                # KEF FIX:
                                if True:
                                        #print field + ' has non-ASCII characters: ' + fieldValue
                                        xlateRecord = ""
                                        for char in fieldValue:
                                                if field == fieldToPrint: print 'Looking at byte ' + str(hex(ord(char)))
                                                if ord(char) >= 128:
                                                        #print 'Looking to decode ' + repr(char)
                                                        #print 'Looking to decode ' + str(hex(ord(char)))
                                                        i=2
                                                        _x = str(hex(ord(char)))
                                                        while i < len(_x):
                                                                xlateRecord += '\\' + _x[i:i+2]
                                                                i += 2
                                                else:   xlateRecord += char
                                        #print 'Decoded string: ' + repr(xlateRecord.decode("utf-8"))
                                
                                        # Put translated value back into local variable used below
                                        fieldValue = xlateRecord
                                        #if fieldValue != savedFieldValue: print 'Translated record: ' + fieldValue
                        if field == fieldToPrint: print fieldValue
                        '''
                                
                        # If field a list and value is not already a list then need to convert to a list
                        if customData[area]['customFieldlist'][i] == 'y' and type(fieldValue) is not list: fieldValue = fieldValue.split(',')
                        
                        # If a number then need to remove any quotes.  Don;t typecast to flot/int, as thi scauses the code to generate a value that's too large for the engine (float case).
                        if type(fieldValue) == str:
                                if   customData[area]['customFieldTypes'][i] == 'integer': fieldValue = fieldValue.strip("'")
                                elif customData[area]['customFieldTypes'][i] == 'decimal': fieldValue = fieldValue.strip("'")
                        
                        # Different key values for new objects
                        if customName.count('User'):
                                cmd = 'extension.setUsingKey(MDCDEFS.k' + customName + field + 'FldKey, fieldValue)'
                        else:   cmd = 'extension.setUsingKey(MDCDEFS.k' + customName + 'Extension' + field + 'FldKey, fieldValue)'
                        if field == fieldToPrint: print('processCustomExtension, cmd = ' + cmd + ', fieldValue = ' + str(fieldValue))
                        try:
                                exec(cmd)
                                if field == fieldToPrint: print(extension)
                        except:
                                print('ERRORS processing ' + field + '.  Probably due to key having non-ASCII characters: ' + fieldValue)
                                _temp = ''
                                for char in fieldValue: _temp += str(hex(ord(char)))
                                print(_temp)

        # Return the structure
        return extension

#===============================================================================
#@clock2
def processOffers(customData, attr, config, submanBuilder, offerType, options, object, operationType='purchase'):
        # Save in local (makes copying code easier)
        lclObject = 'Offer'

        # Get offer attributes
        offerAttr = processCustomExtension(customData, attr, config, lclObject)
        
        # Create locals for all offer parameters
        lclList = list(DATA.CONFIGDATA[lclObject].keys())
        for field in lclList:
                fieldName = field
                cmd = field + ' = PRIM.getPrioritizedFieldValue(customData, attr, field, "'+ lclObject + '", config, options)'
                #print 'cmd: ' + cmd
                exec(cmd)
                #if fieldName == 'CycleEndTime' and CycleEndTime: print fieldName + " = " + str(CycleEndTime)
        #print 'StartTime/End Time = ' + str(StartTime) + '/' + str(EndTime)
        
        '''
        # Create locals for all object parameters
        lclObject = object['object']
        lclList = DATA.CONFIGDATA[lclObject].keys()
        for field in lclList:
                cmd = field + ' = PRIM.getPrioritizedFieldValue(customData, attr, field, "'+ lclObject + '", config, options)'
                #print 'cmd: ' + cmd
                exec(cmd)
                #cmd = 'print "' + field + '" + " = " + str(' + field + ')'
                #print 'cmd: ' + cmd
                #exec(cmd)
        print 'StartTime/End Time = ' + str(StartTime) + '/' + str(EndTime)
        '''

        # Get proper offers
        resourceIdFlag = False
        offers = None
        #print 'processOffers: offerType = ' + offerType
        if   offerType == 'Required':
                cmd = 'offers = config["' + object['object'] + '"]["RequiredOffers"].split(",")'
                #print cmd
                exec(cmd)
                
                # Check if required offers are not supposed to expire
                if config['Program']['requiredOfferNoExpire']: StartTime = EndTime = None
        
        elif offerType == 'Optional':
                offers = config[object['object']][offerType+"Offers"].split(',')
                #offers = OptionalOffers.split(',')
                
                # Check if optional offers are not supposed to expire
                if config['Program']['optionalOfferNoExpire']: StartTime = EndTime = None
                
        elif offerType == 'Modify':
                if   config[object['object']][offerType+"Offers"]:      offers = config[object['object']][offerType+"Offers"].split(',')
                elif ExtId:             offers = ExtId.split(',')
                elif ResourceIds:
                        offers = ResourceIds.split(',')
                        resourceIdFlag = True
                
        elif offerType == 'Cancel':
                if   config[object['object']][offerType+"Offers"]:      offers = config[object['object']][offerType+"Offers"].split(',')
                elif ResourceIds:
                        offers = ResourceIds.split(',')
                        resourceIdFlag = True
                
        else:
                # Input offers.  May not exist or may be a single/list of offers
                if ExtId:       offers = ExtId.split(',')
                else:           offers = None
        
        #print 'Offers: ' + str(offers)

        # If offers defined, then do the work
        if offers:
                # Debug output
                if options and options.verbose_flag: print(operationType + ' offers to ' + lclObject + ' ' + object['queryValue'] + ' (' + object['queryType'] + ')' + ': ' + str(offers))
                
                # Build cycleData
                cycleData = {}
                for item in ['cycleType', 'cycleResourceId', 'cycleOffset', 'cycleAlignmentDisabled', 'cycleStartTime', 'cycleEndTime', 'immediateChange']:
                        try:
                                cmd = "cycleData['offer" + item[0].upper() + item[1:] + "'] = " + item[0].upper() + item[1:]
                                exec(cmd)
                        except: pass
                        
                # Do the operation
                #if CycleEndTime: print 'Calling Offer.processOffer with cycle data: ' + str(cycleData)
                Offer.processOffer(submanBuilder, object, offers, attr=offerAttr, offerType=offerType, offerEndTime=EndTime, offerStartTime=StartTime, operationType=operationType, resourceIdFlag=resourceIdFlag, cycleData=cycleData)
        else:
                # No offers found
                sys.exit('ERROR: in processOffers but no offers identified')
        
        # Always return True
        return True
        
# ------------------------------------------------------------------------------
#  MAIN
# ------------------------------------------------------------------------------
def main():
        print('hello')

if __name__ == '__main__':
        main()

