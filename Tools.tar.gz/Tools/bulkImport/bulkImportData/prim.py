#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-12-03T09:30:35
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-12-03T09:30:35
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-12-03T09:30:35

# Python imports
from __future__ import print_function
from __future__ import absolute_import
# from builtins import input
# from builtins import str
# from builtins import range
# from builtins import input
# from builtins import str
# from builtins import range
import xml.etree.ElementTree as ET
import subprocess, sys, os
import data_container_defs as MDCDEFS
from datetime import date, datetime
from dateutil.tz import *

# Matrixx imports
from primitives import primGeneric as PRIM

# Program imports
from . import data2 as DATA

#==========================================================
# Get all parameters from an input "xxxFields" structure.
# Return a list of items, consisting of (field name, field value).
def getRecordFields(item, recFields):
        # Init return structure
        record = []

        # Look for each variable
        for variable in recFields:
                # If element exists get text, else set to NotPresentString
                cmd = 'for x in item.findall(\''+ variable + '\'): record.append((\'' + variable + '\', x.text))'
                #print 'cmd: ' + cmd
                exec(cmd)

        # Return record
#       yield '|'.join(record)
        return record
        
#==========================================================
# Return a list of items, consisting of (field name, field value)
def flattenRecord(rec, reqType):
     # Balance fields that show up on a subscriber query.  Note that there are other balance fields that show up on a wallet query (e.g. is on demand)
     simpleFields = ['Name', 'CreditLimit', 'TemplateId', 'IsPeriodic', 'QuantityUnit', 'Category', 'IsAggregate', 'IsPrepaid', 'IsVirtual', 'Amount', 'ReservedAmount', 'AvailableAmount', 'StartTime', 'EndTime', 'ThresholdLimit', 'ClassName', 'ResourceId', 'IsOnDemand', 'IsRenewable']
     simpleXmlString = './BalanceArray/MtxBalanceInfoSimple'

     periodicFields = ['Name', 'CreditLimit', 'TemplateId', 'IsPeriodic', 'QuantityUnit', 'Category', 'IsAggregate', 'IsPrepaid', 'IsVirtual', 'Amount', 'ReservedAmount', 'AvailableAmount', 'StartTime', 'EndTime', 'ThresholdLimit', 'ClassName', 'ResourceId', 'IsOnDemand', 'IsRenewable']
     periodicXmlString = './BalanceArray/MtxBalanceInfoPeriodic'

     balanceFields = ['Name', 'CreditLimit', 'TemplateId', 'IsPeriodic', 'QuantityUnit', 'Category', 'IsAggregate', 'IsPrepaid', 'IsVirtual', 'Amount', 'ReservedAmount', 'AvailableAmount', 'StartTime', 'EndTime', 'ThresholdLimit', 'ClassName', 'ResourceId', 'IsOnDemand', 'IsRenewable']
     balanceXmlString = './BalanceArray/MtxBalanceInfo'
     
     # Only want catalog items (won't be bulk importing any older releases)
     offerFields = ['CatalogItemId', 'PurchaseTime', 'ResourceId', 'StartTime', 'Status', 'EndTime', 'CancelTime', 'CancelEndTime', 'PrimaryBalanceResourceId', 'ProductOfferVersion', 'CatalogItemExternalId']
     offerXmlString = './PurchasedOfferArray/MtxPurchasedOfferInfo'

     pricingofferFields = ['OfferId']
     pricingofferXmlString = './OfferInfo/MtxPricingOfferDetailInfo'

     # Get desired data (use indirection)
     cmd = 'params = ' + reqType.lower() + 'Fields\n'
     cmd += 'paramString = ' + reqType.lower() + 'XmlString'
     #print 'cmd: ' + cmd
     exec(cmd)

     # If looking at top level, then can't seem to use "findall" option directly...
     if paramString == '.': yield getRecordFields(rec, params)
     else:
      # Process each child record
      for item in rec.findall(paramString): yield getRecordFields(item, params)

# ------------------------------------------------------------------------------
def getResourceIds(q, area):
        timeFormatz = '%Y-%m-%dT%H:%M:%S%z'
        startTime = datetime.now(tzlocal())
        #startTime = datetime.now()
        startTime = startTime.strftime(timeFormatz)
        
        # Process items
        objectDict = {}
        found = []
        for dataSet in [area]:
                # Get parameters associated with data set
                for i,r in enumerate(flattenRecord(q,dataSet)):
                        # Put results into a dictionary
                        objectDict[str(i)] = {}
                        for j in range(len(r)): objectDict[str(i)][r[j][0]] = r[j][1]
                        #print 'Checking ' + dataSet + ': ' + str(objectDict[str(i)])
                        
                        # What to check depends on input area           
                        if area == 'offer':
                                # If it matches what we're looking for, then add to the list.
                                # Criteria is:  offer ID matches
                                #               the object is valid at the current tool time.
                                #               Only care that one of the two times is > now, as we need to support delayed cancellation.
                                #print 'Offer - comparing time ' + startTime + ' against dict ' + str(objectDict[str(i)])
                                if 'CatalogItemExternalId' in objectDict[str(i)] and \
                                   (('EndTime' in objectDict[str(i)] and PRIM.checkIfTime2GreaterOrEqualTime1(startTime, objectDict[str(i)]['EndTime'])) or \
                                    ('CancelEndTime' in objectDict[str(i)] and PRIM.checkIfTime2GreaterOrEqualTime1(startTime, objectDict[str(i)]['CancelEndTime'])) or \
                                    ('EndTime' not in objectDict[str(i)] and 'CancelEndTime' not in objectDict[str(i)]) \
                                   ):
                                        # Store dictionary entry that matches
                                        found.append(i)
                                        #print 'Offer matches: ' + str(objectDict[str(i)])
                                else:   del objectDict[str(i)]
                        elif area == 'balance':
                                if ('EndTime' not in objectDict[str(i)] or PRIM.checkIfTime2GreaterOrEqualTime1(startTime, objectDict[str(i)]['EndTime'])):
                                        # Store dictionary entry that matches
                                        found.append(i)
                                        #print 'Offer matches: ' + str(objectDict[str(i)])
                                else:   del objectDict[str(i)]
                        else:
                                print('ERROR: unknown area passed to getResourceIds: ' + str(area))
                                sys.exit('Exiting due to errors')
        
        return objectDict
        
#===============================================================================
# This reads from a traditional LDAP-style init file:
'''
[Operations]
# Only performing Diameter operations with this config
Diameter        : True

[Diameter]
# Unique host/realm, so obvious where these came from
OriginHost              : MATRIXX-INFINITY-HOST
OriginRealm             : MATRXIX-INFINITY-REALM
'''
# The result is put into a standard dictionary.
def getConfig(configIniFile):
        # Promoted to common function so all tools can use
        return PRIM.getConfig(configIniFile)

#===============================================================================
def getRangeValues(field, area, operation, devType = 'Imsi', options=None):
        # There may not be an ID for creates.
        if str(field) == 'None': return [field]
        
        # Field may or may not be in range format.
        itemRange = str(field).split('-')
        
        # OID may come with dash as a separator...  Address here.  Colon separator handled fine below.
        if len(itemRange) > 2: return [field]

        # Debug output
        if options and options.verbose_flag:
                print('getRangeValues: itemRange = ' + str(itemRange))
        
        # Always have index 0 :-).
        itemRangeStart = itemRange[0]
        
        # Support the single word "range" that will create a range
        if itemRangeStart.lower() == 'range':
                # Set start to "start"
                itemRangeStart = 'start'
                
                # Add second entry to itemRange with "delta" as the value
                itemRange.append('delta')
        
        # Index may be a number, start with a "+" to signal relative to defaulted init value, or be the word "start" to signal the first value.
        if itemRangeStart.lower() == 'start': itemRangeStart = '+0'
        if itemRangeStart[0] == '+':
                if area.lower() == 'device':
                        # Use indirection to get proper global ID
                        cmd = 'itemRangeStart = str(int(itemRangeStart[1:]) + int(DATA.options.' + area + devType.capitalize() + '))'
                        exec(cmd)
                else:
                        # Use indirection to get proper global ID
                        cmd = 'itemRangeStart = str(int(itemRangeStart[1:]) + int(DATA.options.' + area + 'ExternalId))'
                        exec(cmd)
        
        # If start is not digits at this point, then return it to it's full value (so any '-' character is restored).
        if not itemRangeStart.isdigit(): itemRangeStart = field
        
        # See if second item was input.
        # Make sure to allow a single string that starts with text and ends with numbers to be treated as a single entity.
        # Thus make sure the start was digits.
        if len(itemRange) > 1 and itemRangeStart.isdigit():
                # Get ending range
                itemRangeEnd = itemRange[1]
                
                # Make start an integer
                itemRangeStart = int(itemRangeStart)
                
                # Index may be delta, a number, or start with a "+" to signal relative to Starting range value
                if itemRangeEnd.lower() == 'delta':
                        # Want to add the delta to the start
                        if area.lower() == 'device':
                                cmd = 'itemRangeEnd = itemRangeStart + DATA.options.' + area + devType.capitalize() + 'Delta'
                                exec(cmd)
                        else:
                                cmd = 'itemRangeEnd = itemRangeStart + DATA.options.' + area + 'ExternalIdDelta'
                                exec(cmd)
                
                elif itemRangeEnd[0] == '+': itemRangeEnd = int(itemRangeEnd[1:]) + itemRangeStart
                else:                        itemRangeEnd = int(itemRangeEnd) + 1
        
        else:   itemRangeEnd = itemRangeStart
        
        # If start == end, then only one item
        if itemRangeEnd == itemRangeStart: return [itemRangeStart]
        
        # If here, then we have a range
        else: return list(range(itemRangeStart, itemRangeEnd))
        
#===============================================================================
def getPrioritizedFieldValue(custom, attr, field, area, config, options):
        fieldValue = None
        
        # Top priority is input file
        key = area + field
        if field == 'kef': print('Checking key ' + key + ', attr = ' + str(attr))
        if key in attr:
                # Set to the value
                fieldValue = attr[key]
                
                # If an empty string, then set to "none", which is caught below
                try: 
                        if str(fieldValue) == '': fieldValue = 'none'
                except: pass
                
        # Next is command line input.  Many parameters not exported to command line, so use "try" here.
        else:
                try:    fieldValue = options.key
                except: pass
        
        # Last priority is config file.  Only check if field value not yet defined.
        if fieldValue == None:
                key = field
                id = area
                
                #print 'Found field ' + str(key) + ' in ' + str(id) + ' config data, value = ' + str(fieldValue)
                try: fieldValue = config[id][key]
                except: pass
        
        # Replace input list separator with comma (normalize for code to process lists)
        if config['Program']['inputListSeparator'].lower() != 'json' and str(fieldValue).count(config['Program']['inputListSeparator']): fieldValue = fieldValue.replace(config['Program']['inputListSeparator'], ',')
        
        # Set to None if null, or has been set to None in config file
        if fieldValue and (type(fieldValue) == type(str())) and fieldValue.lower() in ['', 'null', 'none']: fieldValue = None
        
        # Return calculated value
        return fieldValue

#==========================================================
def pauseCheck(check=False):
        # See if pause is disabled and we're not supposed to unconditionally check
        data = DATA.config['Program']['pauseForHumanInput']
        if not (check or data):
                print('Skipping pause as configuration parameter Program/pauseForHumanInput is ' + str(data))
                return
        
        # Prompt the user
        print(' ')
        foo=input('Press enter to continue: ')
        print(' ')

#===============================================================================
# ------------------------------------------------------------------------------
#  MAIN
# ------------------------------------------------------------------------------
def main():
        print('hello')

if __name__ == '__main__':
        main()

