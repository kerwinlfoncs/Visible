#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-12-03T09:30:26
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-12-03T09:30:26
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-12-03T09:30:26

# Product imports
from __future__ import print_function
from __future__ import absolute_import
# from builtins import str
# from builtins import range
# from builtins import str
# from builtins import range
import subscriber_mgmt_v3 as subman
from . import prim as PRIM

# Python imports
from optparse import OptionParser
import sys, copy, pprint, inspect

# Matrixx services
from primitives import primGeneric as GENERIC
from primitives import primGET     as GET
from primitives import primHTTP    as HTTP
from primitives import primXML     as XML

# Local service imports
from . import bulkDiameter as BULKDIAM
from . import data2 as DATA

# ------------------------------------------------------------------------------
def addCustomDataToInputOptions(parser, customData):
        # Add custom fields to list of acceptable parameters
        for obj in ['Subscriber', 'Device', 'Group', 'Offer']:
                # Skip if nothing custom defined
                if obj not in customData: continue
                
                # Process each custom parameter
                for i in range(len(customData[obj]['customFields'])):
                        # Get data inpt locals (for readability)
                        parmName = obj + customData[obj]['customFields'][i]
                        parmType = customData[obj]['customFieldTypes'][i]
                        
                        # Add to input parser
                        cmd = 'parser.add_option("", "--' + parmName + '", action="store", help="' + parmName + '", type="' + parmType + '", default=None)'
                
                        CONFIGDATA[obj][customData[obj]['customFields'][i]] = customData[obj]['customFieldTypes'][i]
                
        # Return updated parset
        return parser

# ------------------------------------------------------------------------------
# Define input
def commandInput(customData=None):
        # -----------------------------------------------------------------------------
        # Program Usage and Options
        # -----------------------------------------------------------------------------
        #define the options and parameter
        parser = OptionParser(usage="usage: %prog [options] filename",
                      version="%prog 0.1")
        
        parser.add_option("", "--rmvFlag",
                      action="store_true",
                      dest="rmvFlag",
                      default=False,
                      help="Remove successful output (can take up a lot of space)")

        parser.add_option("-d", "--debug",
                      action="store",
                      default=None,
                      type="str",
                      dest="debug",
                      help="Debug flag",)
        
        parser.add_option("-v", "--verbose",
                      action="store_true",
                      dest="verbose_flag",
                      default=False,
                      help="Additional logging.")

        parser.add_option("-m", "--mdclog",
                      action="store",
                      default='c',
                      dest="log_mdc",
                      type='str',
                      help="Logs MDC. c - compact, x - xml format")

        parser.add_option("-o", "--offers",
                      action="store",
                      default=None,
                      type="str",
                      dest="offers",
                      help="List of offer external IDs.",)
        
        parser.add_option("-c", "--config",
                      action="store",
                      default="/opt/mtx/services/config/config_bulkImport.ini",
                      type="str",
                      dest="config",
                      help="Configuration file",)
        
        parser.add_option("", "--getResourceIds",
                      action="store_true",
                      default=False,
                      dest="getResourceIds",
                      help="signals if the script shoudl retrieve resource IDs before generating bulk commands",)
        
        parser.add_option("", "--repeat",
                      action="store",
                      default=1,
                      type="int",
                      dest="repeat",
                      help="repeat parameter",)
        
        parser.add_option("", "--DeviceImsi",
                      action="store",
                      default=None,
                      type="int",
                      dest="DeviceImsi",
                      help="DeviceImsi parameter",)
        
        parser.add_option("", "--DeviceImsiDelta",
                      action="store",
                      default=0,
                      type="int",
                      dest="DeviceImsiDelta",
                      help="DeviceImsiDelta parameter",)
        
        parser.add_option("", "--DeviceMsisdn",
                      action="store",
                      default=None,
                      type="int",
                      dest="DeviceMsisdn",
                      help="DeviceMsisdn parameter",)
        
        parser.add_option("", "--DeviceMsisdnDelta",
                      action="store",
                      default=0,
                      type="int",
                      dest="DeviceMsisdnDelta",
                      help="DeviceMsisdnDelta parameter",)
        
        parser.add_option("", "--UserExternalId",
                      action="store",
                      default=None,
                      type="int",
                      dest="UserExternalId",
                      help="UserExternalId parameter",)
        
        parser.add_option("", "--UserExternalIdDelta",
                      action="store",
                      default=0,
                      type="int",
                      dest="UserExternalIdDelta",
                      help="UserExternalIdDelta parameter",)
        
        parser.add_option("", "--SubscriberExternalId",
                      action="store",
                      default=None,
                      type="int",
                      dest="SubscriberExternalId",
                      help="SubscriberExternalId parameter",)
        
        parser.add_option("", "--SubscriberExternalIdDelta",
                      action="store",
                      default=0,
                      type="int",
                      dest="SubscriberExternalIdDelta",
                      help="SubscriberExternalIdDelta parameter",)
        
        parser.add_option("", "--GroupExternalId",
                      action="store",
                      default=None,
                      type="int",
                      dest="GroupExternalId",
                      help="GroupExternalId parameter",)
        
        parser.add_option("", "--GroupExternalIdDelta",
                      action="store",
                      default=0,
                      type="int",
                      dest="GroupExternalIdDelta",
                      help="GroupExternalIdDelta parameter",)
        
        parser.add_option("", "--GroupSubExternalId",
                      action="store",
                      default=None,
                      type="int",
                      dest="GroupSubExternalId",
                      help="GroupSubExternalId parameter",)
        
        parser.add_option("", "--GroupSubExternalIdDelta",
                      action="store",
                      default=0,
                      type="int",
                      dest="GroupSubExternalIdDelta",
                      help="GroupSubExternalIdDelta parameter",)
        
        parser.add_option("", "--GroupGrpExternalId",
                      action="store",
                      default=None,
                      type="int",
                      dest="GroupGrpExternalId",
                      help="GroupGrpExternalId parameter",)
        
        parser.add_option("", "--GroupGrpExternalIdDelta",
                      action="store",
                      default=0,
                      type="int",
                      dest="GroupGrpExternalIdDelta",
                      help="GroupGrpExternalIdDelta parameter",)
        
        parser.add_option("", "--RestHost",
                      action="store",
                      default=None,
                      type="string",
                      dest="RestHost",
                      help="REST gateway IP address",)
        
        parser.add_option("", "--RestPort",
                      action="store",
                      default=None,
                      type="string",
                      dest="RestPort",
                      help="REST gateway port",)
        
        parser.add_option("", "--engine",
                      action="store",
                      default='1',
                      type="string",
                      dest="engine",
                      help="Engine to route commands to",)
        
        parser.add_option("", "--cluster",
                      action="store",
                      default='1',
                      type="string",
                      dest="cluster",
                      help="Cluster to route commands to",)
        
        parser.add_option("", "--blade",
                      action="store",
                      default='1',
                      type="string",
                      dest="blade",
                      help="Blade to route commands to",)
        
        parser.add_option("-H", "--host",
                      action="store",
                      default=None,
                      type="string",
                      dest="host",
                      help="Host IP:Port to route commands to",)
        
        parser.add_option("", "--output",
                      action="store",
                      default=None,
                      type="string",
                      dest="output",
                      help="Output directory",)
        
        parser.add_option("-P", "--print_format",
                      action="store",
                      default="xml",
                      type="string",
                      dest="print_format",
                      help='The output format. The possible options are:           ' +
                        'none ------------ no output                            ' +
                        'compact --------- compact (csv)                        ' +
                        'xml ------------- xml (default)                        ' +
                        'exml ------------ element xml                          ' +
                        'verbose --------- verbose                              ' +
                        'verbose_present - verbose - only present fields')
        
        # If first time through, then do stuff
        if not DATA.dataAlreadyInit:
                # Set the subman mode of operation
                (options, args) = parser.parse_args()
                
                # Set flag so we don't come through here again
                DATA.dataAlreadyInit += 1
                
        else:
                # Want start/end values for each range, then update the start/end of new range to be beyond these.
                if options.UserExternalId:       options.UserExternalId += options.UserExternalIdDelta
                if options.SubscriberExternalId: options.SubscriberExternalId += options.SubscriberExternalIdDelta
                if options.GroupExternalId:      options.GroupExternalId += options.GroupExternalIdDelta
                if options.GroupGrpExternalId:   options.GroupGrpExternalId += options.GroupGrpExternalIdDelta
                if options.GroupSubExternalId:   options.GroupSubExternalId += options.GroupSubExternalIdDelta
                if options.DeviceImsi:           options.DeviceImsi +=  options.DeviceImsiDelta
                if options.DeviceMsisdn:         options.DeviceMsisdn += options.DeviceMsisdnDelta
                                
        # Map input external IDs to others that may still be defaulted
        if options.SubscriberExternalId and not options.GroupSubExternalId: options.GroupSubExternalId = options.SubscriberExternalId
        if options.GroupExternalId      and not options.GroupGrpExternalId: options.GroupGrpExternalId = options.GroupExternalId
        
        # Set output directory
        if options.output: DATA.outputFileDir = options.output
        
        # Warn user if no offer list input
#       if not options.offers: print 'WARNING:  no offer list input, so no validation done to ensure offer external IDs are valid'
        
        # Copy data to data2 items
        DATA.options = copy.deepcopy(options)
        DATA.args    = copy.deepcopy(args)
        
# ------------------------------------------------------------------------------
def validateConfig(config, customData):
        global diameterProcessed
        global sections
        
        # Assume success
        retCode = True
        
        # Init Diameter data if not already done
        if not DATA.diameterProcessed: 
                # Set flag
                DATA.diameterProcessed = True
                        
                # Invoke diameter init code
                BULKDIAM.initDiameterData()
                        
#       print 'Custom Data: ' + str(customData)
#       print 'Config Data: ' + str(config)
        
        # *** Check that every section/option in the config is in the allowed values.
        # *** This covers both the primary values (defined above) and any custom fields (in customData)
        for section in list(config.keys()): 
                if section not in list(DATA.CONFIGDATA.keys()):
                        print('ERROR:  config file has section ' + section + ', but that\'s not in the supported set (' + str(list(CONFIGDATA.keys())) + ')')
                        retCode = False
                        continue
        
                # Verify that each option is defined.
                # Valid values are what's defined in global data and what's specified in the custom data for the section.
                validOptions = copy.deepcopy(DATA.CONFIGDATA[section])
                
                # Need to appended custom fields in lower case...
                if section in customData: 
                        for field in customData[section]['customFields']:
                                # Get index into this list.  Type list has same entries
                                index = customData[section]['customFields'].index(field)
                                
                                # Assume all custom fields are strings (would need to parse that from create_config - later...)
                                validOptions[field] = customData[section]['customFieldTypes'][index]
                
                for option in config[section]:
                        if option not in validOptions:
                                '''
                                print 'ERROR: config file has section ' + section + ' option ' + option + ', but that\'s not in the supported set:'
                                pprint.pprint(DATA.CONFIGDATA[section])
                                retCode = False
                                '''
                                
                                # Add parameter
                                #print('Adding input parameter ' + option + ' to object ' + section)
                                DATA.CONFIGDATA[section][option] = 'string'
                                continue
                
        # *** Check that every defined section and custom field are in the config (and default if not)
        for section in DATA.CONFIGDATA:
                # See if it's in the config file data
                if section not in list(config.keys()):
                        if DATA.options.verbose_flag: print('WARNING: config file should define section ' + section) 
                        
                        # Add this to the data
                        config[section] = {}
                
                # Verify that each option is defined.
                # Valid values are what's defined in global data and what's specified in the custom data for the section.
                validOptions = copy.deepcopy(DATA.CONFIGDATA[section])
                
                # Need to appended custom fields in lower case...
                if section in customData: 
                        for field in customData[section]['customFields']:
                                # Get index into this list.  Type list has same entries
                                index = customData[section]['customFields'].index(field)
                                
                                # Assume all custom fields are strings (would need to parse that from create_config - later...)
                                validOptions[field] = customData[section]['customFieldTypes'][index]
                
                for option in validOptions:
                        if option not in config[section]:
                                if DATA.options.verbose_flag: print('WARNING: config file should define section ' + section  + ' option ' + option)
                                
                                # Add this to the data
                                config[section][option] = None
                        
                        # Validate the input is valid for the right type (string, int, binary)
                        if config[section][option]:
                                if validOptions[option] == 'binary':
                                        # Translate 'true'/'false' to binary
                                        if   config[section][option].lower() == 'true': config[section][option] = True
                                        elif config[section][option].lower() == 'false': config[section][option] = False
                                        else:
                                                print('ERROR: config file has section ' + section + ' option ' + option + ' that\'s supposed to be binary, but the value is ' + str(config[section][option]))
                                                retCode = False
                                                continue
                                
                                if   validOptions[option] == 'integer' and not config[section][option].isdigit():
                                                print('ERROR: config file has section ' + section + ' option ' + option + ' that\'s supposed to be an integer, but the value is ' + str(config[section][option]))
                                                retCode = False
                                                continue
                                
                                # Nothing to validate if a string
        
        # Validate input parameter contains valid parameters
        for param in config['Program']['input'].split(','):
                # If parameter is one without a section, then skip
                if param in ['operation']: continue
                
                # If set to "skip", then allow
                if param.lower() == 'skip': continue
                
                # Set flag signaling section not found
                sectionFound = False
                
                # Look in each object
                for object in DATA.sections:
                        # See if parameter starts with a section
                        if not param.startswith(object): continue
                        
                        # Now see if in allowed parameters for that section
                        if not param[len(object):] in list(DATA.CONFIGDATA[object].keys()):
                                '''
                                # Param not found
                                retCode = False
                                print 'ERROR: input parameter ' + param + ' not in valid parameters for object ' + object + '.'
                                print 'Valid parameters are: ' + str(DATA.CONFIGDATA[object].keys())
                                '''
                                
                                # Add parameter
                                #print('Adding input parameter ' + param + ' to object ' + object)
                                DATA.CONFIGDATA[object][param[len(object):]] = 'string'
                                config[object][param[len(object):]] = None
                        break
                else:
                        # Section not found
                        retCode = False
                        print('ERROR: input parameter ' + param + ' not in valid list of sections.')
                        print('Valid sections are: ' + str(sections))
                                
                
        # Debug output
        '''
        print 'Post validation - config data: '
        pprint.pprint(config)
        '''
        
        # Debug output
        if not retCode: print('validateConfig failed validation')
        
        # Return true/false
        return retCode
        
# ------------------------------------------------------------------------------
def getAllPossibleParameters():
        for obj in ['Subscriber', 'Device', 'Group', 'User']:
                for command in ['Create', 'Modify', 'Query', 'Delete', 'AddThreshold', 'AdjustBalance', 'PurchaseOffer', 'CancelOffer', 'ModifyOffer', 'CreateMobile']:
                        # Get the arguments
                        cmd = 'cmdargs = inspect.getargspec(submanBuilder.' + obj.lower() + command +').args'
                        #print cmd
                        
                        # Not all commands apply to every object.  Continue if this fails.
                        try: exec(cmd)
                        except: continue
                        
                        # Add capitalized params to object-specific config data
                        if obj == 'Subscriber': print(obj + ' adding parameters from command ' + command + ': ' + str(cmdargs))
                        for x in cmdargs: DATA.CONFIGDATA[obj][x[0].upper() + x[1:]] = 'string'
        
# ------------------------------------------------------------------------------
def initData():
        # Get custom object info
        dctRcv = GENERIC.getServiceConfig()
        customData = GENERIC.getCustomData(dctRcv, False)
        
        '''
        # KEF: Skip for now
        # Process all possible commands, get their input, and add to possible per-object parameters
        getAllPossibleParameters()
        
        # Add custom fields to list of acceptable parameters.
        for obj in ['Subscriber', 'Device', 'Group', 'Offer', 'User']:
                # Skip if nothing custom defined
                if obj not in customData: continue
                
                # Add each custom field to CONFIGDATA
                for i in range(len(customData[obj]['customFields'])): DATA.CONFIGDATA[obj][customData[obj]['customFields'][i]] = customData[obj]['customFieldTypes'][i]
        '''
                
        # Process input arguments
        commandInput(customData)
        
        # Debug output
        if DATA.options.verbose_flag:
                print("Options passed in: " + str(DATA.options))
                print("Arguments passed in: " + str(DATA.args))
        
        # Init MDCLIST with all possible operations
        MDCLIST = list(DATA.CONFIGDATA['Operations'].keys())
        
        # Create MDC list
        for item in MDCLIST:
                cmd='DATA.mdcList[\'' + item + '\'] = []'
                exec(cmd)
        
        # Get config from file
        config = PRIM.getConfig(DATA.options.config)
        
        # Prioritize certain data between command input and input file
        section = 'Range'
        if section in config:
                for option in list(CONFIGDATA[section].keys()):
                        # Update input 
                        cmd = 'if (not DATA.options.' + option + ') and "' + option + '" in config[section] and config[section][option]: DATA.options.' + option + ' = int(config[section][option])'
                        #print 'cmd: ' + cmd
                        exec(cmd)
        
        # Validate config data
        retCode = validateConfig(config, customData)
        if not retCode: sys.exit('Exiting due to errors in configuration data')
        
        # Make sure inputSeparator and inputListSeparator are defaulted if not input
        if not config['Program']['inputSeparator']:     config['Program']['inputSeparator'] = ','
        if not config['Program']['inputListSeparator']:
                if config['Program']['inputSeparator'].lower() == 'json': 
                        config['Program']['inputListSeparator'] = 'json'
                else:   config['Program']['inputListSeparator'] = '@'
        
        # Sanity check that the two separators are not the same (can't distinguish between a list element and a new field if so).
        # OK if doing JSON entry inputting.
        if config['Program']['inputSeparator'] == config['Program']['inputListSeparator'] and config['Program']['inputSeparator'].lower() != 'json':
                print("ERROR:  config['Program']['inputSeparator'] can't equal config['Program']['inputListSeparator']")
                sys.exit('Exiting early due to errors')
        
        # If either separate string is more than 1 character, then an error
        for field in ['inputSeparator', 'inputListSeparator']:
                if len(config['Program'][field]) > 1 and config['Program'][field].lower() != 'json':
                        print("ERROR:  config['Program']['" + field + "'] can only be 1 character: " + str(config['Program'][field]))
                        sys.exit('Exiting early due to errors')
        
        # Default all pause items to true if not set in the config file
        for operation in ['pauseOnErrors', 'pauseForHumanInput']:
                if config['Program'][operation] == None: config['Program'][operation] = True
        
        # If REST data input, then prioritize over config file.
        # Make sure both are the same value, so code can use either.
        if DATA.options.RestHost: config['Rest']['hostname'] = DATA.options.RestHost
        else:                DATA.options.RestHost = config['Rest']['hostname']
        if DATA.options.RestPort: config['Rest']['hostport'] = DATA.options.RestPort
        else:                DATA.options.RestPort = config['Rest']['hostport']
        
        # Get release
        release = int(config['Program']['release'][0:2])
        print("Release = " + str(release))
        
        # Objects to check depend on the release
        if release >= 50: objList = ['Subscriber', 'Device', 'Group', 'User']
        else:             objList = ['Subscriber', 'Device', 'Group']
        
        # Init object list information
        for obj in objList: DATA.objectList[obj] = {}
        
        # Process each operation, setting up a list for each
        for operation in MDCLIST:
                for obj in objList:
                        if operation.startswith(obj):
                                DATA.objectList[obj][operation] = {}
                                break
        
        # Thread count must be > 0.  Really should build in non-None default values to init sequence...
        if (not config['Program']['threadCount']) or (int(config['Program']['threadCount']) == 0): config['Program']['threadCount'] = '10'
        
        # Init "Status" conversion data
        # Get a connection
        program = HTTP.setupHttpConnection(config['Rest'])
        
        # Get data for all objects that have a lifecycle.
        if release >= 46:
                for obj in objList:
                        # Retrieve data
                        q = GET.getObjectLifecycle(program, obj)
                        
                        # Convert key fields to dictionary
                        DATA.StatusMap[obj] = XML.getObjectLifecycleFields(q)
                        
                        # Debug output
                        #print 'Status lifecycle for ' + obj + ': ' + str(DATA.StatusMap[obj])
        else:
                for obj in objList: DATA.StatusMap[obj] = {}
        
        '''
        for section in ['User', 'Subscriber']:
                print 'Section ' + section + ' data:'
                pprint.pprint(CONFIGDATA[section])
        '''
        
        # Save data in DATA variables
        DATA.config = copy.deepcopy(config)
        DATA.customData = copy.deepcopy(customData)
        DATA.MDCLIST = copy.deepcopy(MDCLIST)
# ------------------------------------------------------------------------------
#  MAIN
# ------------------------------------------------------------------------------
def main():
        print('hello')

if __name__ == '__main__':
        main()

