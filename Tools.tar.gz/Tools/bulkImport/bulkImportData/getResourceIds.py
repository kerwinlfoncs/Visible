#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-12-03T09:30:28
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-12-03T09:30:28
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-12-03T09:30:28

# Product imports

# Python imports
from __future__ import print_function
from __future__ import absolute_import
# from builtins import str
# from builtins import range
from future import standard_library
standard_library.install_aliases()
# from builtins import str
# from builtins import range
import subprocess
import sys, os, copy
import xml.etree.ElementTree as ET
import http.client

from queue import Queue
import threading

# Local program imports
from . import data2 as DATA
from . import prim as PRIM

from primitives import primHTTP as HTTP
from primitives import primXML as XML
from primitives import primGET as GET
from primitives import processObject as OBJECT

# Dictionary of offer details aready read from the engine
objectResourceIds = {}

# Variable so we can init and call the generator function from anywhere
resourceIdFunction = None

#===============================================================================
# Setup thread for processing the request
class processingThread(threading.Thread):
    def __init__(self,threadNum,queue):
        threading.Thread.__init__(self)
        self.threadNum=threadNum
        self.input_queue=queue

        # Open both connections
#        print 'opening connection to host/port: ' + DATA.config['Rest']['hostname'] + '/' + DATA.config['Rest']['hostport']
        #self.conn1=httplib.HTTPConnection(DATA.config['Rest']['hostname'], DATA.config['Rest']['hostport'])
        self.conn1=HTTP.setupHttpConnection(DATA.config['Rest'])

        #Host2=HOST2
        #self.conn2=httplib.HTTPConnection(Host2,PORT)

        # Not working.  Set second connection object equal to the first one.
        self.conn2=self.conn1

    def run(self):
        global objectResourceIds
        
        # Loop counter
        count = 0

        # Loop
        while True:
                # Get a request from the queue
                item=self.input_queue.get(block=True)
#               print 'Thread %d retrieved from queue %s'%(self.threadNum,str(item))

                # If None, then there will be nothing more and we should exit
                if item is None:
#                       print 'Thread ' + str(self.threadNum) + ' exiting after processing ' + str(count) + ' records'
                        
                        # Only way out of here...               
                        return
          
                # Bump the count
                count += 1
                  
                # Print progress marker
                if not (count % int(DATA.config['Program']['progressCount'])): print('Thread ' + str(self.threadNum) + ' has processed ' + str(count) + ' records')
                
                # Extract the items that were put
                #print 'item = ' + str(item)
                object,queryType,queryValue = item
#               print 'thread ' + str(self.threadNum) + ' processing ' + object + ' ' + queryType + ' ' + queryValue
                
                # Only read data once
                if queryValue in objectResourceIds and objectResourceIds[queryValue]['type'] == queryType and objectResourceIds[queryValue]['object'] == object:
#                       print 'Already read data for ' + object + ' ' + queryType + ' ' + queryValue
                        continue
                
                # Setup global data
                if queryValue not in objectResourceIds: objectResourceIds[queryValue] = {}
                objectResourceIds[queryValue]['type'] = queryType
                objectResourceIds[queryValue]['object'] = object
                
                # Get the data returned in an ET structure
                q = HTTP.getObjectQuery(object, queryValue, queryType, self.conn1)
                
                # Nothing to do if empty structure returned
                if q is None:
                        print('WARNING: Didn\'t find ' + object + ' ' + queryType + ' ' + queryValue + '.  Command creation will fail (subsequent step).')
                        continue
                
                #print 'Returned data:'
                #ET.dump(etStruct)
                
                # Get resource ID data
                for key in ['offer', 'balance']:
                        objectResourceIds[queryValue][key] = PRIM.getResourceIds(q, key)
                        if not objectResourceIds[queryValue][key]:
                                print('WARNING: Didn\'t find ' + key + ' for ' + object + ' ' + queryType + ' ' + queryValue + '.  Command creation may fail (subsequent step).')
#                       else:   print key + ' data for ' + object + ' ' + queryType + ' ' + queryValue + ': ' + str(objectResourceIds[queryValue][key])
                
# ------------------------------------------------------------------------------
def GetObjectResourceIds(item):
#       print 'At start of GetObjectResourceIds'
        
        # If no REST data entered, then can't validate anything
        if not (DATA.config['Rest']['hostname'] and DATA.config['Rest']['hostport']):
                print('WARNING: Rest information not full configured in config file.  Can\'t verify if one can\'t access the REST gateway.')
                sys.exit('Exiting due to errors')
        
        # *** Queue and thread setup ***
        # Set up a queue
        q=Queue()

        # Create threads and start them
        pool=[]
        for i in range(int(DATA.config['Program']['threadCount'])):
          t=processingThread(i,q)
          pool.append(t)
          t.daemon = True
          t.start()
        
#       print 'Pre first yield'
        
        # Yield from inital send(None) call
        item = yield 
        
#       print 'Post first yield, item = ' + str(item)
        
        # Loop until we're told nothing left to do
        while item:
                # Extract values from within item
                data = item.split('_')
                object = data[0]
                queryType = data[1]
                queryValue = data[2]
                
                # Can create a range of objects
                lclRange = PRIM.getRangeValues(queryValue, object, None)
                
                # Process each item in the range
                for queryItem in lclRange:
                        # Queue the item
                        q.put((object, queryType, str(queryItem)))
                
#               print 'Posted to thread, item = ' + str(item)
                item = yield True
        
        # Done adding stuff that needs processing.  
        # Put as many None's in the queue as there are threads, so that each thread gets one
        for t in pool: q.put(None)

        # Wait for all threads to exit
        for t in pool: t.join()
        
        # Yield here.  Caller knows that this is now done, but can't return or get an iteration error
        yield True
        
# ------------------------------------------------------------------------------
#  MAIN
# ------------------------------------------------------------------------------
def main():

        print('Hello')

if __name__ == '__main__':
        main()

