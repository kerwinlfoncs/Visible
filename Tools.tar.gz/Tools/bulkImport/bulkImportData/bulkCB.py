#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-12-03T09:30:22
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-12-03T09:30:22
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-12-03T09:30:22

# Python imports
from __future__ import print_function
from __future__ import absolute_import
# from builtins import str
# from builtins import range
from future import standard_library
standard_library.install_aliases()
# from builtins import str
# from builtins import range
import random, time, datetime, sys, copy
from queue import Queue
import threading

# Pull in service primitives
from primitives import primGeneric as GENERIC

# Local program imports
from . import prim as PRIM
from . import data2 as DATA

# ------------------------------------------------------------------------------
#  MAIN
# ------------------------------------------------------------------------------
def main(customData, attr, config, submanBuilder, options, object, inputFile=None):
        print('Processing bulk CB command.  Data file is ' + str(inputFile))
        
        # Build dictionary to write config file for normalizer service
        dctRcv = {}
        dctRcv['Params'] = {}
        dctRcv['Params']['delimiter'] = config['Program']['inputSeparator']
        
        # Get the input parameter list, removing the leading object characters
        inputData = config['Program']['input'].translate(None, 'CB')
        inputDataList = inputData.split(',')
        print('Input parameters: ' + str(inputDataList))
        
        # Copy input parameter list to normalizer INI file, with their value being the index in the input list
        for i in range(len(inputDataList)):
                # Don't write parameters to skip
                if inputDataList[i].lower() == 'skip': continue
                
                # Store the parameter and the index
                dctRcv['Params'][inputDataList[i]] = str(i)
                
        # Store CB data
        for key in list(config['CB'].keys()):
                if config['CB'][key]: dctRcv['Params'][key] = config['CB'][key]
        
        # Now write the config file
        GENERIC.setConfig(dctRcv, config['CB']['configIniFile'])
        
        # Now execute the opeartion
        cmd = 'normalizerImport.py'
        if inputFile: cmd += ' --inputFile ' + inputFile
        print(GENERIC.runCmd(cmd))
        
if __name__ == '__main__':
        main()


