#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-12-03T09:30:30
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-12-03T09:30:30
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-12-03T09:30:29

# Product imports
from __future__ import print_function
from __future__ import absolute_import
# from builtins import str
# from builtins import range
# from builtins import str
# from builtins import range
from primitives import primGeneric as PRIM
from primitives import primHTTP as HTTP
from primitives import primXML as XML
from primitives import primGeneric as GENERIC
from primitives import processObject as OBJECT

# Python imports
import sys, re
from datetime    import date, datetime
from dateutil.tz import *

# Local program imports
from . import prim             as PRIM
from . import data2            as DATA

# HTTP connection variable
HttpConn = None

# ------------------------------------------------------------------------------
def evaluateFieldCondition(config, object, id, cond, dctRcv):
        target = 'field'
        
        #print 'dctRcv = ' + str(dctRcv)
        
        # ID may have double quotes around it.  Ugh...
        if cond[1].startswith('"'):
                # Find closing double quote in the list
                for i in range(1,len(cond)):
                        if cond[i].strip()[-1] == '"': break
                
                # Join these into a single entitiy
                id = " ".join(cond[1:i+1])
                
                # Put index to next parameter
                i += 1
        else:
                # Use data as-is
                id = cond[1].strip()
                        
                # Put index to next parameter
                i = 2
        
        # See if negation in effect
        if cond[i].strip().lower() == 'not':
                # Set negation flag
                negationFlag = True
                
                # Get condition
                condition = cond[i+1].strip().lower()
                
                # Set index for the next parameter
                i += 2
        else:
                # Clear negation flag
                negationFlag = False
                
                # Get condition
                condition = cond[i].strip().lower()
                
                # Set index for the next parameter
                i += 1 
        
        if len(cond) > i: data1 = cond[i].strip()
        else:             data1 = None
        i += 1
        if len(cond) > i: data2 = cond[i].strip()
        else:             data2 = None
        i += 1
        
        print('Field condition:  ID = ' + id + ', condition = ' + condition + ', negation is ' + str(negationFlag))
                
        # Sanity check this
        if len(cond) > i:
                print('ERROR: only ' + str(i) + ' condition parts are supported.  Input condition: ' + str(cond))
                sys.exit('Exiting due to errors')
                
        # See if the field isdefined
        if id not in dctRcv:
                print('ERROR: Field ' + id + ' not in the object')
                sys.exit('Exiting due to errors')
        
        # Condition is something line "<", or ">=" and can be used as part of an exec command (x <condition> data1).
        # Data and amount may be numbers or strings.  Account fo0r both.
        try:
                amount = float(dctRcv[id])
                data1  = flost(data1)
                cmd = 'if amount ' + condition + ' ' + data1 + ': result = True\n'
                cmd += 'else: result = False'
                exec(cmd)
        except:
                amount = dctRcv[id]
                cmd = 'if amount ' + condition + ' "' + data1 + '": result = True\n'
                cmd += 'else: result = False'
                exec(cmd)
                        
        # See if we should negate the result
        if negationFlag: result = not result
        
        return result
        
# ------------------------------------------------------------------------------
def evaluateOfferCondition(config, object, id, cond, dctRcv):
        target = 'offer'
        
        # ID may have double quotes around it.  Ugh...
        if cond[1].startswith('"'):
                # Find closing double quote in the list
                for i in range(1,len(cond)):
                        if cond[i].strip()[-1] == '"': break
                
                # Join these into a single entitiy
                id = " ".join(cond[1:i+1])
                
                # Put index to next parameter
                i += 1
        else:
                # Use data as-is
                id = cond[1].strip()
                        
                # Put index to next parameter
                i = 2
        
        # See if negation in effect
        if cond[i].strip().lower() == 'not':
                # Set negation flag
                negationFlag = True
                
                # Get condition
                condition = cond[i+1].strip().lower()
                
                # Set index for the next parameter
                i += 2
        else:
                # Clear negation flag
                negationFlag = False
                
                # Get condition
                condition = cond[i].strip().lower()
                
                # Set index for the next parameter
                i += 1 
        
        print('Offer condition:  ID = ' + id + ', condition = ' + condition + ', negation is ' + str(negationFlag))
                
        # Sanity check this
        if len(cond) > i:
                print('ERROR: only ' + str(i) + ' condition parts are supported.  Input condition: ' + str(cond))
                sys.exit('Exiting due to errors')
                
        # See what condition is being checked
        if condition == 'exists':
                # Only want to know if the offer is in the wallet at least once.
                for i in range(len(dctRcv['offers'])):
                        # Put into local for readability
                        offer = dctRcv['offers'][i]
                        
                        # See if we match
                        if offer['ProductOfferExternalId'] == id: break
                
                # If we broke out early, then we found something
                if i < len(dctRcv['offers']):   result = True
                else:                           result = False
                
        elif condition == 'expired':
                # Only want to know if the offer is in the wallet
                for i in range(len(dctRcv['offers'])):
                        # Put into local fo rreadability
                        offer = dctRcv['offers'][i]
                        
                        # Skip if we don't match the ID
                        if offer['ProductOfferExternalId'] != id: continue
                
                        # Need to see if there's an end time
                        # Sometimes there isn't a time.
                        for timeVar in ['EndTime', 'CancelEndTime']:
                                if timeVar in offer:
                                        cmd = timeVar + ' = offer[timeVar]'
                                        exec(cmd)
                                else:
                                        cmd = timeVar + " = None"
                                        exec(cmd)
                                        
                        # Break if neither is set, as there's an instance that's not expired
                        if not EndTime and not CancelEndTime: break
                        
                        # Prioritize end time over cancel end time
                        if EndTime: timeToUse = EndTime
                        else:       timeToUse = CancelEndTime
                        
                        # See if not expired 
                        if GENERIC.checkIfTime2GreaterOrEqualTime1(timeToUse, currentTime): break
                        
                        # Offer is expired.  Keep checking to make sure all instances are expired.
                
                # If we broke out early, then we found something not expired
                if i < len(dctRcv['offers']):   result = False
                else:                           result = True
        
        # See if we should negate the result
        if negationFlag: result = not result
        
        return result
                        
# ------------------------------------------------------------------------------
def evaluateBalanceCondition(config, object, id, cond, dctRcv):
        target = 'balance'
        
        # Balanbce ID is always second parameter
        id = cond[1].strip()
        
        # Check for negation
        # See if negation in effect
        if cond[2].strip().lower() == 'not':
                # Set negation flag
                negationFlag = True
                
                # Get condition
                condition = cond[3].strip().lower()
                
                # Set index for the next parameter
                i = 4
        else:
                # Clear negation flag
                negationFlag = False
                
                # Get condition
                condition = cond[2].strip().lower()
                
                # Set index for the next parameter
                i = 3
        
        if len(cond) > i: data1 = cond[i].strip()
        else:             data1 = None
        i += 1
        if len(cond) > i: data2 = cond[i].strip()
        else:             data2 = None
        i += 1
        
        print('Balance condition:  ID = ' + id + ', condition = ' + condition + ', data1/2 = ' + str(data1) + '/' + str(data2) + ', negation is ' + str(negationFlag))
                
        # Sanity check this
        if len(cond) > i:
                print('ERROR: only ' + str(i) + ' condition parts are supported.  Input condition: ' + str(cond))
                sys.exit('Exiting due to errors')
                
        # Find balance.  Stops at first instance of the balance.
        # If one wants to sum up multiple instances or find one that's not expired, then need additional work...
        for i in range(len(dctRcv['balances'])):
                # Put into local for readability
                balance = dctRcv['balances'][i]
                
                # If we find it, then break
                if (balance['TemplateId'] == id) and ('Amount' in balance) and (balance['Amount']): break
        
        # If we broke early, then we found the balance
        if i < len(dctRcv['balances']): result = True
        else:                           result = False
        
        # See what condition is being checked
        if condition == 'exists': 
                # Nothing else to check
                x = 1
        else:
                # If balance not found, then an error
                if not result:
                        print('ERROR: ' + condId + ' specified condition balance ' + str(id) + '" but that wasn\'t found in the wallet.')
                        sys.exit('Exiting due to errors')
                
                # Sanity check that data was provided
                if not data1:
                        print('ERROR: ' + condId + ' specified condition "' + condition + '" and that requires data, but no data provided.')
                        sys.exit('Exiting due to errors')
                
                elif condition == 'between':
                        # Sanity check that both data were provided
                        if not data1 or not data2:
                                print('ERROR: ' + condId + ' specified condition "' + condition + '" and that requires two data items, but two were not provided.')
                                sys.exit('Exiting due to errors')
                
                        # Condition is data1 <= x < data2
                        amount = float(balance['Amount'])
                        cmd = 'if amount >= float(' + data1 + ') and amount < float(' + data2 + '): result = True\n'
                        cmd += 'else: result = False'
                        #print 'between case: amount = ' + str(amount) + ', cmd: ' + cmd
                        exec(cmd)
                        
                else:
                        # Condition is something line "<", or ">=" and can be used as part of an exec command (x <condition> data1).
                        amount = float(balance['Amount'])
                        cmd = 'if amount ' + condition + 'float(' + data1 + '): result = True\n'
                        cmd += 'else: result = False'
                        exec(cmd)
                        
        # See if we should negate the result
        if negationFlag: result = not result
        
        return result
                
# ------------------------------------------------------------------------------
def evaluateCondition(config, object, id):
        result = False
        
        # Get current time (may be used below)
        timeFormatz = '%Y-%m-%dT%H:%M:%S%z'
        currentTime = datetime.now(tzlocal())
        #currentTime = datetime.now()
        currentTime = currentTime.strftime(timeFormatz)

        # Get condition number into local (for readability)
        condId = 'Cond'+str(id)
        
        # Sanity check that the string exists
        if condId not in config['Logic']:
                print('ERROR: only 10 conditions are supported.  script referenced condition ' + condId)
                sys.exit('Exiting due to errors')
        
        # Sanity check that the condition has been defined.
        if not config['Logic'][condId]:
                print('ERROR: ' + condId + ' specified but it\'t not defined in the config file')
                sys.exit('Exiting due to errors')
        
        # Get the string into a local (for readability)
        cond = config['Logic'][condId].strip().split(' ')
        
        # Separate input object structure into components
        obj = object['object']
        queryType = object['queryType']
        queryValue = object['queryValue']
        
        # Get the object data for the command in question
        dctRcv = getObjectDataFromEngine(config, obj, queryType, queryValue)
        
        # Separate condition data
        target  = cond[0].strip().lower()
        if   target == 'balance':       result = evaluateBalanceCondition(config, object, id, cond, dctRcv)
        elif target == 'offer':         result = evaluateOfferCondition(config, object, id, cond, dctRcv)
        elif target == 'field':         result = evaluateFieldCondition(config, object, id, cond, dctRcv)
        
        print('Condition ' + str(id) + ' ' + str(cond) + ': ' + str(result))
        
        return result
        
# ------------------------------------------------------------------------------
def getObjectDataFromEngine(config, obj, queryType, queryValue):
        global HttpConn
        
        # If no HTTP connection exists, then create one
        if not HttpConn: HttpConn = HTTP.setupHttpConnection(config['Rest'])
        
        # Get the data returned in an ET structure
        q = HTTP.getObjectQuery(obj, queryValue, queryType, HttpConn)
        
        # Process the object.
        # Reuse viewObject functions.
        # Need minor structure creation so API is matched.
        configDct = {}
        configDct[obj.lower()+'CustomName'] = DATA.customData[obj]['customName'].split('/')[0]
        configDct['offerCustomName'] = DATA.customData['Offer']['customName'].split('/')[0]
        dctRcv = {}

        # Now invoke viewObject processing function
        if   obj == 'Subscriber': dctRcv = OBJECT.processSubDctData(dctRcv, q, configDct, None, None, HttpConn)
        elif obj == 'Device':     dctRcv = OBJECT.processDevDctData(dctRcv, q, configDct, None, None, HttpConn)
        elif obj == 'Group':      dctRcv = OBJECT.processGroupDctData(dctRcv, q, configDct, None, None, HttpConn)
        else:
                print('ERROR: unknown object type passed in: "' + obj + '".')
                sys.exit('Exiting due to errors')

        # See what we have
        #print 'Returned dictionary:'
        #for _key in dctRcv.keys(): print _key + ': ' + str(dctRcv[_key])
        
        return dctRcv

# ------------------------------------------------------------------------------
def evaluateLogic(config, object, id, conditionList, CondIndex = 0, skipLevel = False):
        print('Entering evaluateLogic with conditionList: ' + str(conditionList[CondIndex:]))
        
        overallResult = True
        
        # Extra (for readability)
        obj = object['object']
        
        # Get logic number into local (for readability)
        logicId = 'Logic'+str(id)
        
        # Parse the string
        negationFlag = False
        expectCondition = True
        nextOperation = None
        skipToNextConjunctionFlag = False
        while CondIndex < len(conditionList):
                # Get value in lower case
                fieldValue = conditionList[CondIndex].lower().strip()
                
                # Bump counter
                CondIndex += 1
                
                # Skip if field is empty
                if not fieldValue: continue
                
                # See if we're closing the current level
                if fieldValue[0] == ')': 
                        # We're done with this level
                        print('Exiting evaluateLogic with result: ' + str(overallResult) + ' and conditionList: ' + str(conditionList[CondIndex:]))
                        return overallResult, CondIndex
                
                # See if we're going to the next level
                if fieldValue[0] == '(': 
                        changedLevel = True
                        
                        # Iterate
                        (result, CondIndex) = evaluateLogic(config, object, id, conditionList, CondIndex = CondIndex, skipLevel = skipToNextConjunctionFlag)
                else:   changedLevel = False
                
                # If skipping to next condition, and this is not a condition, then continue
                if skipToNextConjunctionFlag:
                        # Always cleasr level cahnge flag if in here, as we don't want to use any previous level's value.
                        changedLevel = False
                        
                        # Skip over non-conjunctions in the same level
                        if fieldValue not in ['and', 'or']: continue
                        
                        # If here, then we're done skipping
                        skipToNextConjunctionFlag = False
                        expectCondition = False
                
                # If supposed to skip this level, then do so
                if skipLevel: continue
                
                # See if negation specified
                if fieldValue == 'not':
                        # Check for double negation
                        if negationFlag:
                                print('ERROR: double "not" found in ' + logicId)
                                sys.exit('Exiting due to errors')
                                
                        # Set flag and go to next item
                        negationFlag = True
                        continue
                
                # Check if expecting a condition 
                if expectCondition:
                        # Evaluate the condition or use the previous level's result
                        if not changedLevel:
                                # Better find the expected value
                                if not fieldValue.count('cond'):
                                        print('ERROR: expecting a Cond statement in field ' + str(CondIndex) + ' of condition "' + str(conditionList) + '"')
                                        sys.exit('Exiting due to errors')
                                
                                # Calculate the condition
                                result = evaluateCondition(config, object, fieldValue[4:])
                        
                        # Always clear changed level flag at this point
                        changedLevel = False
                        
                        # Negate if specified
                        if negationFlag:
                                result = not result
                                negationFlag = False
                                print('evaluateLogic: specific condition was negated, so value = ' + str(result))
                        
                        # Update overall result
                        if not nextOperation:           overallResult = result
                        elif nextOperation == 'and':    overallResult &= result
                        else:                           overallResult |= result
                        
                        # Clear next operation flag
                        nextOperation = None
                        
                        # Not expecting a condition now
                        expectCondition = False
                else:
                        # Make sure field value is known
                        if fieldValue not in ['and', 'or']:
                                print('ERROR: condition must be "and" or "or".  Field ' + str(i) + ' of condition ' + str(conditionList) + ' is "' + fieldValue + '".')
                                sys.exit('Exiting due to errors')
                        
                        # Skip to next condition if always true or always false
                        if (fieldValue.count('and') and not overallResult) or \
                           (fieldValue.count('or')  and     overallResult):
                                skipToNextConjunctionFlag = True
                        else:
                                nextOperation = fieldValue
                                expectCondition = True
                
        print(logicId + ' result: ' + str(overallResult))
        
        # Return result and condition index (next entry to look at)
        print('Exiting evaluateLogic with result: ' + str(overallResult) + ' and conditionList: ' + str(conditionList[CondIndex:]))
        return overallResult, CondIndex
        
# ------------------------------------------------------------------------------
def runLogic(config, record, object):
        overallResult = True
        
        # Extra (for readability)
        obj = object['object']
        
        # Most likely the run doesn't involve logic...
        if not config['Operations'][obj+'Logic']: return overallResult
        
        # Skip if not defined
        if not config[obj]['Logic']: return overallResult
        
        # See what conditions are defined.
        # Remove extra spaces in the middle of the string.  Doesn't address non-space white-space (e.g. tabs)
        logicList = re.sub(' +',' ',config[obj]['Logic'].strip()).split(' ')
        
        # Setup to loop through data
        i = 0
        operation = None
        skipToOperationType = None
        while i < len(logicList):
                # If i is odd, then the data is the operation
                if i % 2:
                        # Get the operation
                        operation = logicList[i].lower()
                        
                        # Bump the index
                        i += 1
                        
                # Get ID
                logicId = logicList[i].lower().capitalize()
                
                # Check if "not" entered
                if logicId == 'Not':
                        # Set the flag
                        negationFlag = True
                
                        # Bump the index
                        i += 1
                        
                        # Get the condition
                        logicId = logicList[i].lower().capitalize()
                        
                else:   negationFlag = False
                
                # Make sure the ID starts with the word "Logic"
                if not logicId.startswith('Logic'):
                        print('ERROR: Incorrectly specified logic ID: ' + logicId)
                        sys.exit('Exiting due to errors')
                
                # Bump the index
                i += 1
                
                # Check skipping logic
                if skipToOperationType and (skipToOperationType != operation): continue
                
                # Skip to next condition if always true or always false
                if (operation == 'and') and (not overallResult):
                        skipToOperationType = 'or'
                        continue
                elif (operation == 'or') and overallResult:
                        skipToOperationType = 'and'
                        continue
                else: skipToOperationType = None
                
                # Get ID number into local (for readability)
                id = logicId[len('Logic'):]
                
                # Sanity check that the string exists
                if logicId not in config['Logic']:
                        print('ERROR: Undefined logic ID: ' + logicId)
                        sys.exit('Exiting due to errors')
                
                # Sanity check that the condition has been defined.
                if not config['Logic'][logicId]:
                        print('ERROR: ' + logicId + ' specified but it\'t not defined in the config file "Logic" section.')
                        sys.exit('Exiting due to errors')
                
                # Get the string into a local (for readability).
                # Remove extra spaces in the middle of the string.  Doesn't address non-space white-space (e.g. tabs), which are handled above.
                conditionList = re.sub(' +',' ',config['Logic'][logicId].strip()).split(' ')
                
                # Evaluate the logic.
                (result, j) = evaluateLogic(config, object, id, conditionList)
                
                # Negate if entered
                if negationFlag:
                        result = not result
                        negationFlag = False
                        print('runLogic: specific condition was negated, so value = ' + str(result))
                
                # Address OR/AND constructs
                if operation:
                        # Convert text to python character for assignment
                        if operation == 'and':  operation = '&'
                        else:                   operation = '|'
                
                        cmd = 'overallResult ' + operation + '= result'
                        exec(cmd)
                else:   overallResult = result
                
                print('runLogic: intermediate result = ' + str(overallResult))
        
        print('runLogic final result: ' + str(overallResult))
        return overallResult
        
# ------------------------------------------------------------------------------
#  MAIN
# ------------------------------------------------------------------------------
def main():

        print('Hello')

if __name__ == '__main__':
        main()

