from distutils.core import setup
setup(name='mtx-services-bulkImport',
	version='4710.0',
	packages=['bulkImportData'],
	scripts=['bulkImport.py'],
	description='MATRIXX Services Provisioning Bulk Import Tool',
	author='Karl Freter',
	author_email='karl.freter@matrixxsw.com',
	url='www.matrixx.com',
      )

