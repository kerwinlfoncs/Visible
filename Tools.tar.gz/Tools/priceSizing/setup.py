from distutils.core import setup
setup(name='mtx-services-priceSizing',
	version='4710.0',
	scripts=['priceSizing.py'],
	description='MATRIXX query size of matrices in a compiled price file',
	author='Karl Freter',
	author_email='karl.freter@matrixxsw.com',
	url='www.matrixx.com',
      )

