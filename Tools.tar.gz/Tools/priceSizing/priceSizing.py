#!/usr/bin/python
# -*- coding: utf-8 -*-

from __future__ import print_function
# from builtins import str
import os, sys
from primitives import primGeneric as GENERIC
import xml.etree.ElementTree as ET
from optparse import OptionParser

#===============================================================================
#
# Copyright 2010,2011,2012,2013,2014,2015,2016 Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

#===============================================================================
# Define input
def commandInput():
    # -----------------------------------------------------------------------------
    # Program Usage and Options
    # -----------------------------------------------------------------------------
    #define the options and parameter
    parser = OptionParser(usage="usage: %prog [options]", version="%prog 1.0")

    parser.add_option("-s", "--size", action='store', type='int', default=1000, help='Size of tables to report (defaults to 1000)')

    # Parse input
    (options, args) = parser.parse_args()
    
    # Return what was read
    return options, args

#===============================================================================
def main():
	# Process inputs
	(options, args) = commandInput()
	
	# Get input file name
	fName = args[0]
	
	# If file name doesn't contain mtx_, then assume it's the domain name and make the full file name
	if not fName.count("mtx_"): fName = "mtx_pricing_" + fName + ".xml"
	
	# See if file is not local
        if not os.path.exists(fName):
		# Save for output
		oldfName = fName
		
		# Go look in the official directory
		fName = "/opt/mtx/custom/" + fName
		if not os.path.exists(fName): sys.exit("ERROR: did not find file '" + oldfName + "' locally or in /opt/mtx/custom")
	
	# Create header for file
	cmd = "echo '<kef>' > _x"
	GENERIC.runCmd(cmd)
	
	# Process the pricing file
	cmd = "awk '/<MtxMatrix/,/<\/MtxMatrix/' " + fName + " >> _x"
	GENERIC.runCmd(cmd)
	
	# Create footer for file
	cmd = "echo '</kef>' >> _x"
	GENERIC.runCmd(cmd)
	
	# Read in the file
	q = GENERIC.fileToET('_x')
	#ET.dump(q)
	
	# Loop through response
        xmlDctName = './MtxMatrix'
	
	'''
	doc = etree.parse("_x")
	root = doc.getroot()
	
	# Get number of these elements
	result = len(root.xpath(xmlDctName))
	print 'There are ' + str(result) + ' MyMatrixx entries'
	'''
	
	# Loop through these
	for matrixx in q.findall(xmlDctName):
		# Get the matrixx ID
		try:
			Id = matrixx.find('./Id').text.strip()
			#print 'Matrixx ID: ' + Id
		except: 
			print('Matrixx missing an ID')
			ET.dump(matrixx)
			continue
		
		# Count values in the normalizer.  There must be a better way to do this....
		count = 0
		for array in matrixx.findall('./PriceLoaderMatrixDataStringArray'):
			for value in array.findall('./value'):
				count += 1
		if count >= options.size: print('Matrixx ID ' + Id + ' has ' + str(count) + ' rows')
		

if __name__ == '__main__':
    main()

#===============================================================================
#
# Copyright 2010,2011,2012,2013,2014,2015,2016 Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

