#!/bin/bash
export PYTHONPATH=$PYTHONPATH:$QADIR/Tools
sudo /etc/init.d/tomcat6 stop
stop_proxy.py

sudo su - -c  "rm /var/log/tomcat6/*.log;rm /var/log/tomcat6/*.out"

pricingWarning=`check_domains_for_open_work | grep WARNING`

#there is uncheckin pricing in workspaces, don't delete the worksapce yet.
if [ ${#pricingWarning} -ne 0 ] 
then
    echo $pricingWarning 
    exit 0
fi 

#delete the temp workpsace
sudo su -  -c "rm -rf /var/cache/tomcat6/temp/mtx_workspaces"

#delete the old war files
sudo su -  -c "rm -rf /var/lib/tomcat6/webapps/*"

#copy the new war files
cp /opt/mtx/bin/*.war /var/lib/tomcat6/webapps

#restart proxy and tomcat
start_proxy.py
sudo /etc/init.d/tomcat6 start
