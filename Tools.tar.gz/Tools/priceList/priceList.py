#!/usr/bin/python

# System imports
from __future__ import print_function
import os, glob, time, sys, pprint
from datetime import datetime
from optparse import OptionParser

# MTX Service imports
from primitives	    import cbRestPrim  as CB
from primitives     import primGeneric as GENERIC

# ------------------------------------------------------------------------------
# Define input
def commandInput():
        # -----------------------------------------------------------------------------
        # Program Usage and Options
        # -----------------------------------------------------------------------------
        #define the options and parameter
        parser = OptionParser(usage="usage: %prog [options] filename",
                      version="%prog 0.1")

        parser.add_option("-o", "--offer",
                      action="store",
                      default=None,
                      type="str",
                      dest="offerId",
                      help="Offer ID",)

        parser.add_option("-d", "--debug",
                      action="store",
                      default=None,
                      type="str",
                      dest="debug",
                      help="Debug flag",)

        parser.add_option("-v", "--verbose",
                      action="store_true",
                      dest="verbose_flag",
                      default=False,
                      help="Additional logging.")

        parser.add_option("", "--config",
                      action="store",
                      default="/opt/mtx/services/config/config_primitives.ini",
                      type="str",
                      dest="config",
                      help="Configuration file",)

        # Set the subman mode of operation
        (options, args) = parser.parse_args()

        # Return what was read
        return options, args

# ------------------------------------------------------------------------------
#  MAIN
# ------------------------------------------------------------------------------
def main():
        # Start time for statistical reasons
        start_time = datetime.now()
        start_time_str = start_time.strftime('%d-%b-%YT%H-%M-%S')
        print('Listing at time: ' + start_time_str)
	
        # Get command line data
        (options, args) = commandInput()

        # Init global data
        (customData, config) = GENERIC.initData(options.config)
        #print 'Config = ' + str(config)
	
	# Get CB data
	CB.getAllCbData(config, -1)
#	pprint.pprint(CB.retOfferDct)
	
	# Print one or all offers
	if options.offerId: 
		# Print single offer data
		CB.walkOfferData(options.offerId, config)
	else:
		# Process every offer
		for entry in CB.retOfferDct['OfferList']['Offer']:
			# Get ID entry
			value = entry['ID']['value']
	
			# Print single offer data
			CB.walkOfferData(value, config)
	
    	############## Logout from CB #################
	CB.cbLogout()
    	
if __name__ == '__main__':
        main()

