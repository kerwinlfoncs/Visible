#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Thu 2021-11-11T22:02:52
# @futurize --stage2 --no-diffs -n -w  : Thu 2021-11-11T22:02:52
#
# @futurize --stage1 --no-diffs -n -w  : Thu 2021-11-11T22:02:51

# Import system primitives
from __future__ import print_function
# from builtins import str
# from builtins import range
from future import standard_library
standard_library.install_aliases()
# from builtins import str
# from builtins import range
import sys, pprint, traceback
import os
import copy
import optparse
import time
import xml.etree.ElementTree as ET
from subprocess import call
try:
    import configparser
except:
    from six.moves import configparser

# Import MTX package
from primitives import primHTTP         as HTTP
from primitives import primXML          as XML
from primitives import primGeneric      as GENERIC
from primitives import primData         as PRIMDATA

#================== Global Data  ================================================
global urlObjectStart
urlObjectStart = '/rsgateway/data/v3/'

# Globals that store the REST host and port values
global RestHost
global RestPort

# Define a global to store per-command time.  Saves a lot of changes ot pass in to every function
# Needed so we avoid querying without a time when processing past history (causes time to move forward and the test to fail...)
global commandTime
commandTime = None

# Get from /etc/hosts and from "always used" value
RestHost = GENERIC.runCmd('grep restgw /etc/hosts | cut -f1 -d" "')
RestPort = '8080'

#==========================================================
def processPricingLoaded():
    # Read pricing
    (result, q) = getPricingStatus(None, None)

    # Make sure domain is specified
    field = 'Domain'
    try: domain = q.find('./'+field).text.strip()
    except:
        print('ERROR: query of pricing did not return a domain.  Engine is most likely down or pricing not loaded or authentication values are wrong.')
        sys.exit('Exiting due to errors')

    field = 'CreateLoginId'
    try: login = q.find('./'+field).text.strip()
    except:
        print('ERROR: query of pricing did not return a login.  Engine is most likely down or pricing not loaded or authentication values are wrong.')
        sys.exit('Exiting due to errors')

    #print 'Currently loaded domain: ' + domain + ', workspace: ' + login

    # Check time pricing loaded.  Perhaps could/should use ModifiedTime, as ActivateTime accounts for engine starts, but not worth changing now in case there's an unexpected side effect...
    field = 'ActivateTime'
    try: activateTime = q.find('./'+field).text.strip()
    except:
        print('ERROR: query of pricing did not return ActivateTime.  Engine is most likely down or pricing not loaded or authentication values are wrong.')
        sys.exit('Exiting due to errors')

    # Look to see if we should save or restore key TF data.
    # Assume save
    PRIMDATA.regressionRun = 'save'
    
    # Check if custSpecific.py has changed - should re-save to be sure
    try: modTime =  time.strftime('%Y-%m-%dT%H:%M:%S', time.localtime(os.path.getmtime(os.path.expandvars(os.getenv('COMMON', '.')) + '/custSpecific.py')))
    except:
    # Not running TF.  Not sure what to do here...
        print('Hmmm. custSpecific.py not present in $COMMON.  Will save data.')
        outFile = PRIMDATA.savedEngineData + 'priceLoadTime'
        modTime = None
    
    # More work if we found the above time
    if modTime:
     #print 'custSpecific.py modTime = ' + modTime
     # Get last TF saved time
     outFile = PRIMDATA.savedEngineData + 'priceLoadTime'
     if not os.path.isfile(outFile):
        print('Price load file ' + outFile + ' doesn\'t exist.  Will save MyMatrixx data.')
     else:
        # Read the file
        f = open(outFile)
        savedTime = f.read()
        if savedTime[:19] < activateTime[:19]:
                # Can't reuse saved data
                print('Pricing changed since the last run.\n\tSaved time: ' + savedTime + '\n\tLoad  time: ' + activateTime + '\n\tWill re-read pricing information')
        elif modTime[:19] > savedTime[:19]:
                # Can't reuse saved data
                print('custSpecific.py changed since the last run.\n\tModified time: ' + modTime + '\n\tLoad time:     ' + activateTime + '.\n\tWill re-read pricing information.')
        
        # Change activation time so it reflects latest time
                activateTime = modTime[:19]
        else:
                # Can reuse saved data
                print('Neither pricing nor custSpecific.py has changed since the last run.  Will reuse pricing information.')
                PRIMDATA.regressionRun = 'restore'
        f.close()

    # If saving, then save activate time
    if PRIMDATA.regressionRun == 'save':
        f = open(outFile, 'w')
        f.write(activateTime)
        f.close()

#===============================================================================
# *** Process offer list (all of them; not just globals)
def getPricingOffers(program, options, globalOnly=False):
    dctRcv = {}
    
    # Restore data if we're supposed to
    if PRIMDATA.regressionRun.lower() == 'restore':
        try:    dctRcv['globalOffers']  = copy.deepcopy(PRIMDATA.EngineData['globalOffers'])
        except: dctRcv['globalOffers'] = []
        try:    dctRcv['onetimeOffers'] = copy.deepcopy(PRIMDATA.EngineData['onetimeOffers'])
        except: dctRcv['onetimeOffers'] = []
        try:    dctRcv['subscriptionOffers'] = copy.deepcopy(PRIMDATA.EngineData['subscriptionOffers'])
        except: dctRcv['subscriptionOffers'] = []
        return dctRcv
    
    # Get offers
    q = getOfferListDctData(program, options, globalOnly=globalOnly)
    
    # Read individual offers
    dctRcv['globalOffers'] = []
    dctRcv['onetimeOffers'] = []
    dctRcv['subscriptionOffers'] = []
    xmlDctName = './OfferList/MtxPricingOfferInfo'
    for offer in q.findall(xmlDctName):
        lclRcv = {}
        item = XML.getObjectBaseFields(offer, lclRcv)
        w = getOfferDctData(program, item['OfferId'], options)
        xmlDctName2 = './OfferInfo/MtxPricingOfferDetailInfo'
        w = w.find(xmlDctName2)
        lclRcv = {}
        item = XML.getObjectBaseFields(w, lclRcv)
        if 'IsGlobal' in item and item['IsGlobal'].lower() == 'true':
#           print 'Offer ' + item['OfferId'] + ' is a global offer'
            dctRcv['globalOffers'].append(item)
        elif 'IsOneTime' in item and item['IsOneTime'].lower() == 'true':
#           print 'Offer ' + item['OfferId'] + ' is a one-time offer'
            dctRcv['onetimeOffers'].append(item)
        else:
#           print 'Offer ' + item['OfferId'] + ' is a subscription offer'
            dctRcv['subscriptionOffers'].append(item)
    # Save data if we're supposed to
    if PRIMDATA.regressionRun.lower() == 'save':
        PRIMDATA.EngineData['globalOffers'] = copy.deepcopy(dctRcv['globalOffers'])
        PRIMDATA.EngineData['onetimeOffers'] = copy.deepcopy(dctRcv['onetimeOffers'])
        PRIMDATA.EngineData['subscriptionOffers'] = copy.deepcopy(dctRcv['subscriptionOffers'])
    
    return dctRcv

#===============================================================================
def getExtraGroupData(oid, itemToQuery, cursor, program):
    global urlObjectStart
        
    # Get variable URL
    url = "group/" + oid + "/" + itemToQuery + '?queryCursor=' + cursor

    # Prefix  URL
    url = urlObjectStart + url
    
    # Parse the response into a dictionary
    (result, x) = HTTP.getAndVerifyHttpRequest(program, url)

    #print 'GET extra group object ' + oid + '(' + itemToQuery + ') succeeded'

    return x
    
#===============================================================================
# This function reads group data
def getGroupDctData(program, options, queryFd):
    global urlObjectStart
    
    # Different strings depending on input type
    if options.groupId:
        url = "group/query/ExternalId/" + options.groupId + GENERIC.getTimeStampStr(options.date)
        id = options.groupId
        type = 'ExternalId' 
    elif options.goid:
        url = "group/" + options.goid + GENERIC.getTimeStampStr(options.date)
        #url = "group/" + options.goid + '?querySize=1'
        id = options.goid
        type = 'oid'    
    else:
        sys.exit('getGroupDctData: Exiting due to no group ID parameter input: ' + str(options))
    
    # Prefix  URL
    url = urlObjectStart + url
    
    # Parse the response into a dictionary
    (result, x) = HTTP.getAndVerifyHttpRequest(program, url)

    #print 'GET of object ' + Id + '(' + type + ') succeeded'

    # Save data to file, if file specified
    if queryFd: 
        tree = ET.ElementTree(x)
        tree.write(queryFd)
    
    return x, id, type
    
#===============================================================================
# This function reads pricing status
def getPricingStatus(program, id):
    global urlObjectStart
    
    # Never save pricing, as we need to know if it changed
    '''
    # Restore data if we're supposed to
    if PRIMDATA.regressionRun.lower() == 'restore':
        try:
            x  = copy.deepcopy(PRIMDATA.EngineData['pricingStatus'])
            return x
        except:
            # Failed to restore.  Treat as a save.
            print 'NOTE: getPricingStatus() failed to restore.  Treating as a save.'
            PRIMDATA.regressionRun = 'save'
    '''
    
    # Set url
    url='pricing/status'
    
    # Prefix  URL
    url = urlObjectStart + url
#   print 'Pricing Status GET URL: ' + url
        
    # Parse the response into a dictionary
    (result, x) = HTTP.getAndVerifyHttpRequest(program, url)
    
    # Save data if we're supposed to
    #if PRIMDATA.regressionRun.lower() == 'save': PRIMDATA.EngineData['pricingStatus']  = copy.deepcopy(x)
  
    return (result, x)
    
#===============================================================================
# This function reads service type data
def getServiceTypeInfo(program, id):
    global urlObjectStart
    
    # Restore data if we're supposed to
    if PRIMDATA.regressionRun.lower() == 'restore':
        try:
            x  = copy.deepcopy(PRIMDATA.EngineData['serviceType'])
            return x
        except:
            # Failed to restore.  Treat as a save.
            print('NOTE: getServiceTypeInfo() failed to restore.  Treating as a save.')
            PRIMDATA.regressionRun = 'save'
    
    # Set url
    url='pricing/service_type/' + id
    
    # Prefix  URL
    url = urlObjectStart + url
#   print 'Service type GET URL: ' + url
        
    # Parse the response into a dictionary
    (result, x) = HTTP.getAndVerifyHttpRequest(program, url)
    
    # Save data if we're supposed to
    if PRIMDATA.regressionRun.lower() == 'save': PRIMDATA.EngineData['serviceType']  = copy.deepcopy(x)
    
    return (result, x)
    
#===============================================================================
# This function reads device aggregation ata
def getDevAggregation(program, oid):
    global urlObjectStart
    
    # Set url
    url='device/' + oid + '/aggregation'
    
    # Prefix  URL
    url = urlObjectStart + url
#   print 'Device Aggregation GET URL: ' + url
    
    # Parse the response into a dictionary
    (result, x) = HTTP.getAndVerifyHttpRequest(program, url)
    
    return (result, x)
    
#===============================================================================
# This function reads device policy ata
def getDevSyPolicy(program, oid):
        global urlObjectStart
    
        # Set url
        url='device/' + oid + '/policycounter'
    
        # Prefix  URL
        url = urlObjectStart + url
        #print 'Device Sy policy GET URL: ' + url
    
        # Parse the response into a dictionary
        (result, x) = HTTP.getAndVerifyHttpRequest(program, url)
    
        return (result, x)
    
#===============================================================================
# This function reads device data
def getDevSessionData(program, oid):
    global urlObjectStart
    
    # Get URL
    url = "device/" + oid + '/session'
    
    # Prefix  URL
    url = urlObjectStart + url
#   print 'Device GET URL: ' + url
    
    # Parse the response into a dictionary
    (result, x) = HTTP.getAndVerifyHttpRequest(program, url)
    
    return (result, x)
    
#===============================================================================
# This function reads user data
def getUserDctData(program, queryId, queryType, options, queryFd=None):
    global urlObjectStart
    obj = 'user'
    
    # Prefix  URL
    url = urlObjectStart + obj + '/'
    
    # Different strings depending on input type
    if queryType: url += queryType + '+'
    else: sys.exit('getUserDctData: Exiting due to no queryType parameter input')
    
    # Suffix URL
    url += queryId + GENERIC.getTimeStampStr(options.date)
#    print 'User GET URL: ' + url
    
    # Parse the response into a dictionary
    (result, x) = HTTP.getAndVerifyHttpRequest(program, url)
    
    # Save data to file, if file specified
    if queryFd: 
        tree = ET.ElementTree(x)
        tree.write(queryFd)
    
    return (result, x)
    
#===============================================================================
# This function reads user authentication data
def getUserAuthDctData(program, queryId, queryType, options, queryFd=None):
    global urlObjectStart
    obj = 'user'
    
    # Prefix  URL
    url = urlObjectStart + obj + '/'
    
    # Different strings depending on input type
    if queryType: url += queryType + '+'
    else: sys.exit('getUserAuthDctData: Exiting due to no queryType parameter input')
    
    # Add authentication part of the URL
    url += queryId + '/authentication'
    
    # Add time stamp
    url += GENERIC.getTimeStampStr(options.date)
#    print 'User authentication GET URL: ' + url
    
    # Parse the response into a dictionary
    (result, x) = HTTP.getAndVerifyHttpRequest(program, url)
    
    # Save data to file, if file specified
    if queryFd: 
        tree = ET.ElementTree(x)
        tree.write(queryFd)
    
    return (result, x)
    
#===============================================================================
# This function reads user data
def getSubscriptionDctData(program, queryId, queryType, options, queryFd=None):
    global urlObjectStart
    obj = 'subscription'
    
    # Prefix  URL
    url = urlObjectStart + obj + '/'
    
    # Different strings depending on input type
    if queryType: url += queryType + '+'
    else: sys.exit('getDeviceQueryDct: Exiting due to no queryType parameter input')
    
    # Add time stamp
    url += queryId + GENERIC.getTimeStampStr(options.date)
#    print 'Subscription GET URL: ' + url
    
    # Parse the response into a dictionary
    (result, x) = HTTP.getAndVerifyHttpRequest(program, url)
    
    # Save data to file, if file specified
    if queryFd: 
        tree = ET.ElementTree(x)
        tree.write(queryFd)
    
    return (result, x)
    
#===============================================================================
# This function reads device data
def getDevDctData(program, queryId, queryType, options, queryFd=None):
    global urlObjectStart
    obj = 'device'
    
    # Prefix  URL
    url = urlObjectStart + obj + '/'
    
    # Different strings depending on input type
    if   queryType.lower() == 'imsi':   url += "Imsi+"
    elif queryType.lower() == 'msisdn': url += "AccessNumber+"
    elif queryType:         url += queryType + '+'
    else: sys.exit('getDeviceDctData: Exiting due to queryType parameter not set')
    
    # Suffix  URL
    url += queryId + GENERIC.getTimeStampStr(options.date)
#    print 'Device GET URL: ' + url
    
    # Parse the response into a dictionary
    (result, x) = HTTP.getAndVerifyHttpRequest(program, url)
    
    # Save data to file, if file specified
    if queryFd: 
        tree = ET.ElementTree(x)
        tree.write(queryFd)
    
    return (result, x)
    
#===============================================================================
# This function gets all balances
def getBalancesDctData(program):
    # Restore data if we're supposed to
    if PRIMDATA.regressionRun.lower() == 'restore':
     try:
        x  = copy.deepcopy(PRIMDATA.EngineData['balances'])
        return x
     except:
        # Failed to restore.  Treat as a save.
        print('NOTE: getBalancesDctData() failed to restore.  Treating as a save.')
        PRIMDATA.regressionRun = 'save'
    
    url = "pricing/balances" 
    
    # Prefix  URL
    url = urlObjectStart + url
        
    # Put the response into an Element Tree variable
    (result, x) = HTTP.getAndVerifyHttpRequest(program, url)
    
    # Save data if we're supposed to
    if PRIMDATA.regressionRun.lower() == 'save': PRIMDATA.EngineData['balances']  = copy.deepcopy(x)
    
    return x
    
#===============================================================================
# This function gets a balance template
def getBalanceTemplateDctData(program, templateId):
    # Restore data if we're supposed to
    if PRIMDATA.regressionRun.lower() == 'restore':
     try:
        x  = copy.deepcopy(PRIMDATA.EngineData['balance_' + templateId])
        return x
     except:
        # Failed to restore.  Treat as a save.
        print('NOTE: getBalanceTemplateDctData() failed to restore.  Treating as a save.')
        PRIMDATA.regressionRun = 'save'
    
    url = "pricing/balance/" 
        
    # Prefix  URL
    url = urlObjectStart + url + templateId
        
    # Put the response into an Element Tree variable
    (result, x) = HTTP.getAndVerifyHttpRequest(program, url)

    # Save data if we're supposed to
    if PRIMDATA.regressionRun.lower() == 'save': PRIMDATA.EngineData['balance_' + templateId]  = copy.deepcopy(x)
    
    return x
    
#===============================================================================
# This function reads lifecycle data for an object
def getObjectLifecycle(program, object):
    # Restore data if we're supposed to
    if PRIMDATA.regressionRun.lower() == 'restore':
     try:
        x  = copy.deepcopy(PRIMDATA.EngineData['lifecycle' + object.lower()])
        return x
     except:
        # Failed to restore.  Treat as a save.
        print('NOTE: getObjectLifecycle() failed to restore.  Treating as a save.')
        PRIMDATA.regressionRun = 'save'
    
    url = "pricing/lifecycle/" + object.lower()
        
    # Prefix  URL
    url = urlObjectStart + url
        
    # Put the response into an Element Tree variable
    (result, x) = HTTP.getAndVerifyHttpRequest(program, url)

    # Save data if we're supposed to
    if PRIMDATA.regressionRun.lower() == 'save': PRIMDATA.EngineData['lifecycle' + object.lower()]  = copy.deepcopy(x)
    
    return x
    
#===============================================================================
# This function reads all the offer
def getOfferListDctData(program, options, globalOnly=False):
    # Restore data if we're supposed to
    if PRIMDATA.regressionRun.lower() == 'restore':
     try:
        x  = copy.deepcopy(PRIMDATA.EngineData['offers'])
        return x
     except:
        # Failed to restore.  Treat as a save.
        print('NOTE: getOfferListDctData() failed to restore.  Treating as a save.')
        PRIMDATA.regressionRun = 'save'
    
    url = "pricing/offers/" 
        
    # Prefix  URL
    url = urlObjectStart + url
        
    # Add global only flag if input
    if globalOnly: url += '?globalOffersOnly=true'
        
    # Put the response into an Element Tree variable
    (result, x) = HTTP.getAndVerifyHttpRequest(program, url)
    
    # Save data if we're supposed to
    if PRIMDATA.regressionRun.lower() == 'save': PRIMDATA.EngineData['offers']  = copy.deepcopy(x)
    
    return x
    
#===============================================================================
# This function reads a specific catalog item
def getCatalogDctData(program, templateId, options):
    # Restore data if we're supposed to
    if PRIMDATA.regressionRun.lower() == 'restore':
     try:
        x  = copy.deepcopy(PRIMDATA.EngineData['ci_' + templateId])
        return x
     except:
        # Failed to restore.  Treat as a save.
        print('NOTE: getCatalogDctData() failed to restore.  Treating as a save.')
        PRIMDATA.regressionRun = 'save'
    
    url = "pricing/CatalogItem/" + templateId + GENERIC.getTimeStampStr(options.date)
        
    # Prefix  URL
    url = urlObjectStart + url
        
    # Put the response into an Element Tree variable
    (result, x) = HTTP.getAndVerifyHttpRequest(program, url)

    # Save data if we're supposed to
    if PRIMDATA.regressionRun.lower() == 'save': PRIMDATA.EngineData['ci_' + templateId]  = copy.deepcopy(x)
    
    return x
    
#===============================================================================
# This function reads a specific offer
def getOfferDctData(program, templateId, options):
    # Restore data if we're supposed to
    if PRIMDATA.regressionRun.lower() == 'restore':
     try:
        x  = copy.deepcopy(PRIMDATA.EngineData['offer_' + templateId])
        return x
     except:
        # Failed to restore.  Treat as a save.
        print('NOTE: getOfferDctData() failed to restore.  Treating as a save.')
        PRIMDATA.regressionRun = 'save'
    
    url = "pricing/offers/" + templateId + GENERIC.getTimeStampStr(options.date)
        
    # Prefix  URL
    url = urlObjectStart + url
        
    # Put the response into an Element Tree variable
    (result, x) = HTTP.getAndVerifyHttpRequest(program, url)

    # Save data if we're supposed to
    if PRIMDATA.regressionRun.lower() == 'save': PRIMDATA.EngineData['offer_' + templateId] = copy.deepcopy(x)
    
    return x
    
#===============================================================================
# This function reads subscriber data
def getSubDctData(program, options, queryFd): 

    # Different strings depending on input type
    if options.subscriber:
        url = "subscriber/query/ExternalId/" + options.subscriber + GENERIC.getTimeStampStr(options.date)
        id = options.subscriber
        type = 'ExternalId' 
    elif options.oid:
        url = "subscriber/" + options.oid + GENERIC.getTimeStampStr(options.date)
        id = options.oid
        type = 'oid'    
    elif options.soid:
        url = "subscriber/" + options.soid + GENERIC.getTimeStampStr(options.date)
        id = options.soid
        type = 'oid'    
    elif options.deviceId:
        url = "subscriber/query/imsi/" + options.deviceId + GENERIC.getTimeStampStr(options.date)
        id = options.deviceId
        type = 'IMSI'   
    elif options.accessNumbers:
        url = "subscriber/query/AccessNumber/" + options.accessNumbers + GENERIC.getTimeStampStr(options.date)
        id = options.accessNumbers
        type = 'MSISDN' 
    elif options.LoginId:
        url = "subscriber/query/LoginId/" + options.LoginId + GENERIC.getTimeStampStr(options.date)
        id = options.accessNumbers
        type = 'LoginId'    
    else:
        sys.exit('Exiting due to invalid queryType parameter input: ' + queryType + GENERIC.getTimeStampStr(options.date))

    # Prefix  URL
    url = urlObjectStart + url
    
    # Parse the response into a dictionary
    (result, x) = HTTP.getAndVerifyHttpRequest(program, url)
    
    # Debug data
    #print 'Returned XML: ' 
    
    # Save data to file, if file specified
    if queryFd: 
        tree = ET.ElementTree(x)
        tree.write(queryFd)
    
    return x, id, type
    
#===============================================================================
# Get catalog item data
def getCatalogDctExplicitFields(program, dict, options):
    # Get ID
    id = dict['CatalogItemId']
    #print 'Reading offer ' + str(id)
    
    # Read offer
    q = getCatalogDctData(program, id, options)
    #ET.dump(q)
    
    # Get XML base name.  Could be one of several
    for dctName in ['./CatalogItemInfo/MtxPricingCatalogItemDetailInfo']:
        # Point to this data
        qData = q.find(dctName)
        
        # If we found something, then break
        if qData is not None: break
    
    # Sanity check that we found something
    if qData is None:
        print('ERROR: did not find offer data for catalog ID ' + str(id))
        print('Looked for structures: "./CatalogItemInfo/MtxPricingCatalogItemDetailInfo"')
        ET.dump(q)
        sys.exit('Exiting due to errors')
    
    #ET.dump(qData)
    # get the fields
    dctRet = {}
    dctRet = XML.getObjectBaseFields(qData, dctRet)
    #pprint.pprint(dctRet)
        
    # Extra data for Offer data
    attrDict = {}
    if dctName == './CatalogItemInfo/MtxPricingCatalogItemDetailInfo':
        # Get attributes
        dctName='./CatalogItemInfo/MtxPricingCatalogItemDetailInfo/TemplateAttr/MtxTemplateAttr'
        attrName = []
        attrValue = []
        for children in q.findall(dctName + 'Name'):  attrName.append(children.text)
        for children in q.findall(dctName + 'Value'): attrValue.append(children.text)
        
        # Copy into dictionary (so we return one structure)
        for i in range(len(attrName)): attrDict[attrName[i]] = attrValue[i]
        
    # Return name and priority
    #print 'Results of Catalog ID: ' + str(id) + ': '
    #pprint.pprint(dctRet)
    return dctRet, attrDict
    
#===============================================================================
# Get offer external ID and priority.  Not returned as part of subscriber query (but desired to display)
def getOfferDctExplicitFields(program, dict, options):
    # Get ID
    id = dict['ProductOfferId']
    #print 'Reading offer ' + str(id)
    
    # Read offer
    q = getOfferDctData(program, id, options)
    #ET.dump(q)
    
    # Get XML base name.  Could be one of several
    for dctName in ['./OfferInfo/MtxPricingOfferDetailInfo', './BundleInfo/MtxPricingBundleDetailInfo']:
        # Point to this data
        qData = q.find(dctName)
        
        # If we found something, then break
        if qData is not None: break
    
    # Sanity check that we found something
    if qData is None:
        print('ERROR: did not find offer data for offer ID ' + str(id))
        print('Looked for structures: "./OfferInfo/MtxPricingOfferDetailInfo/", "./BundleInfo/MtxPricingBundleDetailInfo/"')
        ET.dump(q)
        sys.exit('Exiting due to errors')
    
    #ET.dump(qData)
    # Get the fields
    dctRet = {}
    dctRet = XML.getObjectBaseFields(qData, dctRet)
    #pprint.pprint(dctRet)
        
    # Extra data for Offer data
    attrDict = {}
    if dctName == './OfferInfo/MtxPricingOfferDetailInfo':
        # Get attributes
        dctName='./OfferInfo/MtxPricingOfferDetailInfo/AttrList/MtxPricingAttrInfo'
        attrName = []
        attrValue = []
        for children in q.findall(dctName + 'Name'):  attrName.append(children.text)
        for children in q.findall(dctName + 'Value'): attrValue.append(children.text)
        
        # Copy into dictionary (so we return one structure)
        for i in range(len(attrName)): attrDict[attrName[i]] = attrValue[i]
        
    # Return name and priority
    #pprint.pprint(attrDict)
    return dctRet, attrDict
    
#===============================================================================
def getDeviceObjectEvents(queryValue, queryType='ObjectId', hostname=RestHost, hostport=RestPort, querySize=None, queryCursor=None, eventTimeLowerBound=None, eventTimeUpperBound=None):
    # Need to get device OID here
    if queryType != 'ObjectId':
        queryValue = getDeviceOid(queryValue, queryType=queryType, hostname=hostname, hostport=hostport)
        queryType  = 'ObjectId'
    
    # Always need to get subscriber OID
    subOid = getDeviceParent(queryValue, queryType=queryType, hostname=hostname, hostport=hostport)
    
    return getObjectEvents(subOid, queryType=queryType, hostname=hostname, hostport=hostport, objType='subscriber', addlOid=queryValue, querySize=querySize, queryCursor=queryCursor, eventTimeLowerBound=eventTimeLowerBound, eventTimeUpperBound=eventTimeUpperBound)
   
#===============================================================================
#===============================================================================
def getSubscriberObjectEvents(queryValue, queryType='ObjectId', hostname=RestHost, hostport=RestPort, addlOid=None, querySize=None, queryCursor=None, eventTimeLowerBound=None, eventTimeUpperBound=None):
    return getObjectEvents(queryValue, queryType='ObjectId', hostname=hostname, hostport=hostport, objType='subscriber', addlOid=None, querySize=querySize, queryCursor=queryCursor, eventTimeLowerBound=eventTimeLowerBound, eventTimeUpperBound=eventTimeUpperBound)
    
#===============================================================================
def getObjectEvents(queryValue, queryType='ObjectId', hostname=RestHost, hostport=RestPort, objType='subscriber', addlOid=None, querySize=None, queryCursor=None, eventTimeLowerBound=None, eventTimeUpperBound=None):
    # Get URL common part
    url = urlObjectStart + objType + '/'
    
    # Build the rest of the URL
    #if queryType in ['PhoneNumber', 'ExternalId', 'AccessNumber', 'imsi']: url += 'query/' + queryType + '/'
    if queryType: url += queryType + '+'
    
    # Always put ID at the end.  Replace any colon with dash (in case in OID format)
    url += replace(queryValue, ':', "-")
    
    # Add events string
    url += '/events'
    
    # Add additional OID if specified
    if addlOid: url += '/' + replace(addlOid, ":", "-")
    
    # Now build optional part of URL
    optional = ''
    if querySize: optional += '&querySize=' + querySize
    if queryCursor: optional += '&queryCursor=' + queryCursor
    if eventTimeLowerBound: optional += '&eventTimeLowerBound=' + replace(eventTimeLowerBound, ":", "%3A")
    if eventTimeUpperBound: optional += '&eventTimeUpperBound=' + replace(eventTimeUpperBound, ":", "%3A")
    if optional: url += '?' + optional[1:]
    
    return curlToETFormat(url)

#===============================================================================
def getObject(queryValue, queryType='ObjectId', hostname=RestHost, hostport=RestPort, objType='subscriber', querySize=None):
    # Get URL common part
    url = urlObjectStart + objType + '/'
    
    # Build the rest of the URL
    #if queryType in ['UserId', 'PhoneNumber', 'ExternalId', 'AccessNumber', 'Imsi', 'AccesId', 'LoginId']: url += queryType + '+'
    if queryType: url += queryType + '+'
    
    # Always put ID at the end
    url += queryValue
    
    # Add query size
    if querySize: url += "?querySize=" + str(querySize)
    
    #print 'getObject ' + objType + ' read URL: ' + url
    #traceback.print_stack()
    return curlToETFormat(url)

#===============================================================================
def getObjectWallet(queryValue, queryType='ObjectId', hostname=RestHost, hostport=RestPort, objType='subscriber'):
    # Get the OID
    if objType != 'group':  oid = getSubscriberOid(queryValue, queryType, hostname, hostport)
    else:           oid = getGroupOid(queryValue, queryType, hostname, hostport)
    
    # If nothing returned, then return None
    if not oid: return None
    
    # Get URL
    url = urlObjectStart + objType + '/' + oid + '/wallet'
    #print objType + ' wallet read URL: ' + url
    
    return curlToETFormat(url)

#===============================================================================
def curlToETFormat(url, operation='GET', output='ET'):
    # Run the command
    #print 'URL: ' + url
    (_result, q) = HTTP.getAndVerifyHttpRequest(None, url, exitOnFailure = False, operation=operation, output=output)
    
    return q
    
#===============================================================================
def getObjectField(q, field='ExternalId'):
    # Read in XML data
    try:
        retVal = q.find('./'+field).text.strip()
    except:
        retVal = None

    return retVal

#===============================================================================
def getField(target, queryValue, queryType, lclStartTime, field='ExternalId'):
    # Query data
    url = '/rsgateway/data/v3/' + target.lower()

    # If not Object ID then add query details
    if queryType != 'ObjectId': url += '/query/' + queryType

    # Add value and time stamp
    url += '/' + queryValue + GENERIC.getTimeStampStr(lclStartTime)

    # Query data
    q = curlToETFormat(url)
    
    # Read in XML data
    try:
        retVal = q.find('./'+field).text.strip()
    except:
        retVal = None

    return retVal

#===============================================================================
def getDeviceParent(queryValue, queryType='ObjectId', hostname=RestHost, hostport=RestPort):
    objType = 'device'
    objField = 'SubscriberId'
    
    # Get data
    q = getObject(queryValue, queryType=queryType, hostname=hostname, hostport=hostport, objType=objType)
    return getObjectField(q, objField)

#===============================================================================
def getDeviceOid(queryValue, queryType='ObjectId', hostname=RestHost, hostport=RestPort):
    objType = 'device'
    objField = 'ObjectId'
    
    # Get data
    q = getObject(queryValue, queryType=queryType, hostname=hostname, hostport=hostport, objType=objType)
    return getObjectField(q, objField)

#===============================================================================
def getDeviceExternalId(queryValue, queryType='ExternalId', hostname=RestHost, hostport=RestPort):
    objType = 'device'
    objField = 'ExternalId'
    
    # Get data
    q = getObject(queryValue, queryType=queryType, hostname=hostname, hostport=hostport, objType=objType)
    return getObjectField(q, objField)

#===============================================================================
def getSubscriberOid(queryValue, queryType='ObjectId', hostname=RestHost, hostport=RestPort):
    objType = 'subscriber'
    objField = 'ObjectId'
    
    # Get data
    q = getObject(queryValue, queryType=queryType, hostname=hostname, hostport=hostport, objType=objType)
    #ET.dump(q)
    return getObjectField(q, objField)

#===============================================================================
def getSubscriberExternalId(queryValue, queryType='ExternalId', hostname=RestHost, hostport=RestPort):
    objType = 'subscriber'
    objField = 'ExternalId'
    
    # Get data
    q = getObject(queryValue, queryType=queryType, hostname=hostname, hostport=hostport, objType=objType)
    return getObjectField(q, objField)

#===============================================================================
def getGroupOid(queryValue, queryType='ObjectId', hostname=RestHost, hostport=RestPort):
    objType = 'group'
    objField = 'ObjectId'
    
    # Get data
    q = getObject(queryValue, queryType=queryType, hostname=hostname, hostport=hostport, objType=objType)
    #ET.dump(q)
    return getObjectField(q, objField)

#===============================================================================
def getGroupExternalId(queryValue, queryType='ExternalId', hostname=RestHost, hostport=RestPort):
    objType = 'group'
    objField = 'ExternalId'
    
    # Get data
    q = getObject(queryValue, queryType=queryType, hostname=hostname, hostport=hostport, objType=objType)
    return getObjectField(q, objField)

#===============================================================================
def getBalanceClassAndTemplateNames(templateId, hostname=RestHost, hostport=RestPort):
        url = urlObjectStart + 'pricing/balance/' + templateId + GENERIC.getTimeStampStr(commandTime)   
        q = curlToETFormat(url)
    
        #print 'curlOut: '+ curlOut

        # Read in XML data
        try:
                #q=ET.fromstring(curlOut)
                classId    = q.find('./BalanceInfo/MtxPricingBalanceDetailInfo/ClassName').text.strip()
                templateId = q.find('./BalanceInfo/MtxPricingBalanceDetailInfo/Name').text.strip()
                QuantityUnit = q.find('./BalanceInfo/MtxPricingBalanceDetailInfo/QuantityUnit').text.strip()
        except:
                print('WARN: Could not read balance template ' + templateId + ' data from server ' + hostname + ':' + hostport)
                #print 'curlOut: '+ curlOut
                classId = QuantityUnit = 'Unknown'

        return (classId, templateId, QuantityUnit)

#===============================================================================
# Find the type of object (Subscriber, Deice, Group)
def getObjectType(objectOID, hostname=RestHost, hostport=RestPort):
    foundFlag = False
    for oidType in ['subscriber', 'group', 'device']:
        url = urlObjectStart + oidType + '/' + objectOID + GENERIC.getTimeStampStr(commandTime)
        q = curlToETFormat(url)
        
        if q.find('./Result').text.strip() == '0':
                foundFlag = True
                break

    # See if we didn't find anything
    if not foundFlag:
            print('WARNING: failed to find OID ' + objectOID)
            oidType = None

    # If here, then we know what object type is impacted by the recurring processing (oidType)
    return oidType

#===============================================================================
# Process priceing that's loaded
processPricingLoaded()

#================== Main function  ================================================
def main():
    print('hello')

if __name__ ==  '__main__':
    main()

