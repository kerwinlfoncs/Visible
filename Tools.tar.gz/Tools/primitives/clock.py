#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Thu 2021-11-11T22:02:46
# @futurize --stage2 --no-diffs -n -w  : Thu 2021-11-11T22:02:46
#
# @futurize --stage1 --no-diffs -n -w  : Thu 2021-11-11T22:02:46
from __future__ import print_function
# from builtins import str
# from builtins import str
import time
import functools

# Define decorator
def clock2(func):
    # Get name of caller
    @functools.wraps(func)
    def clocked(*args, **kwargs):
                t0 = time.time()
                result = func(*args, **kwargs)
                elapsed = time.time() - t0
                print('Elapsed time for function = ' + func.__name__ + ': ' + str(elapsed))
                return result
    return clocked


