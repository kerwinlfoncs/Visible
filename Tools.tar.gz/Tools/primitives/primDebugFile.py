#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Thu 2021-11-11T22:02:51
# @futurize --stage2 --no-diffs -n -w  : Thu 2021-11-11T22:02:51
#
# @futurize --stage1 --no-diffs -n -w  : Thu 2021-11-11T22:02:50
#===============================================================================
#
# Copyright 2015 Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

from __future__ import print_function
# from builtins import zip
# from builtins import str
# from builtins import range
# from builtins import zip
# from builtins import str
# from builtins import range
import sys, os, re, copy
from primitives import primGeneric as GENERIC

# Variable that holds the file that contained the current event
FileLineCount = {}

#===============================================================================
def gatherAllConfigFiles(options):
    # If a directory was entered, then get those files
    if options.dirName:
        # Directory entered.  Process all files in that directory.
        # Specifically do NOT include any lower level directories.
        for dirName, subDirList, fileList in os.walk(options.dirName):
                # Debug output
                print('Processing directory: ' + dirName + ', files: ' + str(fileList))

                # Add all the files, with full path
                for fileName in fileList:
                        # Debug output
                        #print 'Adding directory ' + dirName + ', file ' + fileName

                        # Add full path of file to the list
                        options.inputFile.append(dirName+'/'+fileName)

                # break from the loop, as we only care about the top level directory
                break

        # Debug output
        print('File list to process from directory ' + options.dirName + ': ' + str(options.inputFile))

        # Done here
        return options

    # May need to copy files from a target machine.
    if options.ip:
        # Save this address, in case we need it at the bottom...
        savedIpAddress = options.ip

        # If running locally, then grab local.  Otherwise need to grab from the specified address
        if options.ip in options.localIpAddresses:
                # Point to local config file.  Already have ditionary file fully qualified...
                configFile = '/opt/mtx/custom/create_config.info'
        else:
                # Want to split string and grab first element
                targetHost = options.ip.split(',')[0]

                # Debug output
                print('Retrieving key daya from IP address: ' + targetHost)

                # Copy dictionary from the target to local directory
#                GENERIC.runCmd("scp mtx@" + targetHost + ":" + options.dict + " . ")

                # Set options to point to local copy
#                options.dict = options.dict.split('/')[-1]

                # File will be local
                configFile = 'create_config.info'

                # Copy file from the target to local directory
                GENERIC.runCmd("scp mtx@" + targetHost + ":" + "/opt/mtx/custom/create_config.info . ")

        # Now get the site from the engine/cluster/blade designation
        cmdStr = 'grep "Engine ' + str(options.engine) + ':Cluster ' + str(options.cluster) + ':What is the fully-qualified blade enclosure ID for this cluster" ' + configFile
        cmdStr += ' | cut -f2 -d? | cut -f1 -d:'
        site = GENERIC.runCmd(cmdStr)

        # If no site specified, then use first one
        if not site:
                print('ERROR: no site found for engine/cluster/blade ' + str(options.engine) + '/' + str(options.cluster) + '/' + str(options.blade))
                sys.exit('Exit due to error')

        # Debug output
        print('Note: Site to use will be ' + site)

        # Get the blades for this site.
        # First the logical blade IDs (not necessarily sequential or starting at 1.
        physicalBladeIds = GENERIC.runCmd('grep "' + site + ':.*:What are your physical blade IDs" ' + configFile + ' | cut -f2 -d?')
        physicalBladeIds = physicalBladeIds.split(';')
        
        # Now the actual IPs. 
        # Release 50xx added lines that add 0.0.0.0 to this query, so remove those.
        # Pre-5050: FIXME: really should read release variable and use that to distinguish which line to run...
        # physicalBladeIPs = GENERIC.runCmd('grep ' + site + '.*Physical ' + configFile + ' | cut -f2 -d? | grep -v "0.0.0.0" | tr "\n" ","')
        physicalBladeIPs = GENERIC.runCmd('grep "' + site + '.*Physical.*transaction" ' + configFile + ' | cut -f2 -d? | grep -v "0.0.0.0" | tr "\n" ","')
        physicalBladeIPs = physicalBladeIPs[:-1].split(',')
        
        # Make a dictionary using the ID as the key and the IP as the value.  This addresses scenarios where the 
        # logical mapping is not sequential.  
        physicalBladeMapping = dict(list(zip(physicalBladeIds, physicalBladeIPs)))
    
        # Debug output
        print('Physical blades for site ' + site + ': ' + str(physicalBladeMapping))
        
        # OK, now get the engine/cluster/blade data
        cmdStr = 'grep "Engine ' + str(options.engine)+ ':Cluster ' + str(options.cluster) + ':LogicalBlade '
        if      options.blade:  cmdStr += str(options.blade) + ':What is the physical blade ID" '
        else:                   cmdStr += '.*:What is the physical blade ID" '
        cmdStr += configFile + ' | cut -f2 -d"?" |  tr "\n" ","'
    
        # Issue the command
        #print 'cmdStr = ' + cmdStr
        logicalBladeIPs = GENERIC.runCmd(cmdStr)
        logicalBladeIPs = logicalBladeIPs[:-1].split(',')
    
        # Check for errors:
        if not logicalBladeIPs[0]:
                    # Debug output
                    print('ERROR: NO Logical blades defined for site ' + site + ' engine/cluster/blade ' + str(options.engine) + '/' + str(options.cluster) + '/' + str(options.blade))
                    sys.exit('exit due to error')
        else:
                    # Debug output
                    print('Logical blades for site ' + site + ' engine/cluster/blade ' + str(options.engine) + '/' + str(options.cluster) + '/' + str(options.blade) + ': ' + str(logicalBladeIPs))
    
        # Now create an IP list, with the index being the logical IP address and the data being the physical IP address
        options.ip = []
        options.inputFile = []
        allBlades = ''
        for index in range(len(logicalBladeIPs)):
                    # Get physical address of logical blade.  Usually they match, but just in case...
                    # Note:  logical blades stat at 1, but they're stored starting at array entry 0 (Python).  Need to adjust for this (i.e. subtract 1)
                    bladeId = physicalBladeMapping[logicalBladeIPs[index]]
    
                    # Add to the balde list
                    allBlades += bladeId + ','
    
                    # Add this file to the file to process list
                    options.inputFile.append('mtx_debug.log.' + bladeId)
    
        # Convert list to array.  Want to do this so the entries match.  Using "append" doesn't seem to ensure a proper list...
        options.ip = allBlades[:-1].split(',')
    
        # Debug output
        print('IP addresses for engine: ' + str(options.ip))

    # Debug output
    print('File list to process from input IP/Engine data: ' + str(options.inputFile))

    return options

#===============================================================================
def getDebugLogFiles(options):
    # If IP address input, then gather files
    if options.ip:
        # Loop through each IP address
        for index in range(len(options.ip)):
            # If local host, copy official file to local directory; else scp official file from remote server
            if options.ip[index] in options.localIpAddresses:
                  GENERIC.runCmd('cp /var/log/mtx/mtx_debug.log mtx_debug.log.' + options.ip[index])
            else: GENERIC.runCmd("scp mtx@" + options.ip[index] + ":/var/log/mtx/mtx_debug.log mtx_debug.log." + options.ip[index])

#===============================================================================
def processInputFiles(options):
    global FileLineCount

    # Get files to process
    filenames = options.inputFile

    index = 0

    # Debug output
    #print 'Processing files: = ' + str(filenames)

    # Translate all files to array of messages
    for index,file in enumerate(filenames):
        # Sometimes commands leave a blank in the array...
        if not file: continue

        # Get current line count of the file
        lineCount = GENERIC.runCmd('wc -l ' + file + ' | cut -f1 -d" "')

        # Debug output
        #print 'Current line count for file ' + file + ' = ' + str(lineCount)

        # If we have an entry for this file, then we may need to skip lines
        if str(index) in FileLineCount:
                # Delete lines from the file that were already processed
                GENERIC.runCmd('sed -i "1,' + FileLineCount[str(index)] + 'd" ' + file)

                # Debug output
                #print 'Removed previous ' + FileLineCount[str(index)] + ' from file ' + file

        # Update new line count
        FileLineCount[str(index)] = str(lineCount)

#==========================================================
if __name__ ==  '__main__':
    main()


#==========================================================

def main():
    x = 1


if __name__ == '__main__':
    main()

#===============================================================================
#
# Copyright 2011,2012,2013,2014,2015 Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


