#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Thu 2021-11-11T22:02:48
# @futurize --stage2 --no-diffs -n -w  : Thu 2021-11-11T22:02:48
#
# @futurize --stage1 --no-diffs -n -w  : Thu 2021-11-11T22:02:47

# Import system primitives
from __future__ import print_function
# from builtins import str
# from builtins import str
import xml.etree.ElementTree as ET
import sys, copy
import optparse

# Import services
from primitives import primXML as XML

# Dictionary of AVPs
avpDict = {}

# Set list of attributes to look for
avpAttrNames = ['code', 'type_name', 'vendor_name']
avpGroupAttrNames = ['code', 'vendor_name']
avpInGroupAttrNames = []
tab='   '

#===============================================================================
#def cmdLineInput():
#    ########### Do command line processing ###################
#    parser = optparse.OptionParser()
#    parser.add_option("-f", "--file", action='store', type='string', default='/opt/mtx/conf/diameter_dictionary.xml', help='Diameter dictionary XML file')
#
#    # Process command line params
#    (options, args) = parser.parse_args()
#
#    return options, args

#===============================================================================
def processGroupedAvp(item, groupName):
    global avpDict
    
    # Having trouble trying to find all items named "avp".
    # "iter" should work, but it generates errors.  Do old fashioned
    # way and go level by level
    for elem in item :
            # Get name and value of this element
        elementName = getElementName(elem)
        
        # Need to loop within group as we don't care (yet) about required/optional AVP differentiation.
        if elementName in ['required', 'optional', 'fixed']:
            processGroupedAvp(elem, groupName)
            continue
        
        # Get attribute type_name
        typeName = elem.get('type_name')
        
        # Get attribute name
        name = elem.get('name')
        
        # Debug output
#       print 'Processing: ' + str(elementName) + '/' + str(name) + '/' + str(typeName)
        
        # Only expect AVP indication within a group
        if elementName != 'avp':
            print('ERROR: expected only AVPs within a group.  Group ' + groupName + ' has element ' + str(name) + ' that is type ' + str(elementName))
            sys.exit('Exiting Early')
        
        # If here, then we have an AVP.
        # AVP better already exist!
        if name not in avpDict:
            print('ERROR: AVP "' + name + '" referenced in group ' + groupName + ', but not in avpDict.')
            sys.exit('Exiting Early')
        
        # Add the AVP to the group
#       print 'Stored AVP ' + name + ' with parent ' + groupName
        avpDict[name]['parent'].append(groupName)
        
#===============================================================================
def getElementName(elem):
    #ET.dump(elem)
    name = elem.tag
    
    # Split off name space if it's been added here
    if name.count('}'): name = name.split('}')[1]
    
    return name
    
#===============================================================================
def storeAvpData(avpType, elem):
    global avpDict
    
    # Every AVP better have a name attribute...
    name = elem.get('name')
    if not name:
        print('ERROR: AVP found without a name attribute')
        ET.dump(elem)
        sys.exit('Exiting Early')
    
    # See if we already have processed this AVP
    if name in avpDict:
        # Grouped AVPs can be seen more than once - when defined and when referenced (and may be referenced multiple times).
        # Only an error when not grouped.
        if avpType != 'grouped_avp':
            print('ERROR: AVP "' + name + '" already in avpDict.')
            sys.exit('Exiting Early')
        else:   return
    
    # Create entry
    avpDict[name] = {}
    avpDict[name]['type'] = avpType
    avpDict[name]['parent'] = []
    
    # Get data structure to use for additional attributes
    if   avpType == 'avp':      extraAttributes = copy.deepcopy(avpAttrNames)
    elif avpType == 'grouped_avp':  extraAttributes = copy.deepcopy(avpGroupAttrNames)
    else:               extraAttributes = copy.deepcopy(avpInGroupAttrNames)
    
    # Now copy extra attributes into the global dictionary
    for attr in extraAttributes: avpDict[name][attr] = elem.get(attr)
    
#===============================================================================
def processApplicationData(elem):
    # Get data into global
    appName = elem.get('name')
    avpDict[appName] = {}
    avpDict[appName]['code'] = elem.get('code')
    avpDict[appName]['type'] = 'application'
    avpDict[appName]['commands'] = {}
    
    #print '\n\n** Processing app ' + appName
    
    # Process each command in the application
    for command in elem:
            # Get name and value of this element
        name = getElementName(command)
        
        # Make sure this is a command (else we don't know where we are int the file)
        if name.lower() != 'command':
            print("ERROR: expecting command below application but found: " + name)
            ET.dump(command)
            sys.exit('Exiting Early')
        
        # Get attributes into global
        cmdName = command.get('name')
        avpDict[appName]['commands'][cmdName] = {}
        avpDict[appName]['commands'][cmdName]['code'] = command.get('code')
        avpDict[appName]['commands'][cmdName]['name'] = cmdName
        avpDict[appName]['commands'][cmdName]['msgType'] = {}
        
        #print '\n*  Processing cmd ' + cmdName
        
        # Process next layer (request/answer)
        for msgType in command:
            # Get name of this element
            msgTypeName = getElementName(msgType)
            
            # Skip some items
            if msgTypeName.lower()== 'answer': continue
        
            #print tab*1 + 'Processing type ' + msgTypeName
        
            # Set global
            avpDict[appName]['commands'][cmdName]['msgType'][msgTypeName] = {}
        
            # Now process next level (fixed/required/optional)
            for category in msgType:
                # Get name and value of this element
                categoryName = getElementName(category)
            
                # Skip some items
                if categoryName.lower().startswith('copy') or \
                   categoryName.lower().startswith('set')  or \
                   categoryName.lower().startswith('condition'): continue
            
                # Make sure this is a command (else we don't know where we are in the file)
                if categoryName.lower() not in ['fixed', 'required', 'optional']:
                    print("ERROR: expecting type of AVP below command to be fixed/required/optional but found: " + categoryName)
                    ET.dump(command)
                    sys.exit('Exiting Early')
            
                #print tab*2 + 'Processing category ' + categoryName
        
                # Setup global data
                avpDict[appName]['commands'][cmdName]['msgType'][msgTypeName][categoryName] = {}
                avpDict[appName]['commands'][cmdName]['msgType'][msgTypeName][categoryName]['avp'] = []
                avpDict[appName]['commands'][cmdName]['msgType'][msgTypeName][categoryName]['group'] = []
            
                # Now recursively process AVPs in this list
                for avp in category: processAppAvp(avp, None, 3, avpDict[appName]['commands'][cmdName]['msgType'][msgTypeName][categoryName])
    
    # Print the data
    #printApplication(appName)
    
def processAppAvp(avp, parent, depth, dict):
    # Get name and value of this element
    avpName = getElementName(avp)
                
    # Make sure this is a command (else we don't know where we are in the file)
    if avpName.lower() not in ['avp']:
        print("ERROR: expecting AVP below fixed/required/optional but found: " + avpName)
        ET.dump(avp)
        sys.exit('Exiting Early')
                
    # Get attributes
    avpName = avp.get('name')
    mdcMapping = avp.get('mdc_field_name')
                
    # If no MDC mapping, then never a need to send in the AVP
    #if not mdcMapping: return
                
    #print tab*depth + 'Processing AVP ' + avpName
        
    # If lowest level AVP, store in global data
    if avpDict[avpName]['type_name'] != 'Grouped': dict['avp'].append((avpName,parent))
    else:
        # Store in group list
        dict['group'].append((avpName, parent))
        
        # This is a group.  Need to recursively process this.  Remember which parent we came from
        for lowerAvp in avp: processAppAvp(lowerAvp, avpName, depth+1, dict)
                
    return

#================== Main function  ================================================
def main():
    debug = False
    
    # Get command line ata
    #(options, args) = cmdLineInput()
    
    # Get file in XML ETree format
    dictFile = '/opt/mtx/conf/diameter_dictionary.xml'
    q = XML.parseXmlResponse(dictFile)
    
    # Walk the tree
    # Get every item at this level
    for elem in q:
        # Get name and value of this element
        elementName = getElementName(elem)
        
        # Only care about certain element types
        if elementName == 'application': processApplicationData(elem)
        if elementName not in ['avp', 'grouped_avp']: continue
        
        # Get attribute type_name
        typeName = elem.get('type_name')
        
        # Get attribute name
        name = elem.get('name')
        
        #print 'Processing: ' + str(elementName) + '/' + str(name) + '/' + str(typeName)
        
        # Store the AVP data
        storeAvpData(elementName, elem)
        
        # Get attributes
#       attrib = elem.items()
            
        # Process Group AVPs
        if elementName == 'grouped_avp':
#           print 'Processing Group AVP ' + name
            processGroupedAvp(elem, name)
#       else:   print 'Processed AVP ' + name
    
    
    # Print the final dictionary
#   debug = True
    debug = False
    if debug:
      for avp in avpDict:
        if avpDict[avp]['type'] == 'application': printApplication(avp)
        else:                                     printAvp(avp)

def printApplication(app):
    print('\n************************************************************')
    print('Application: ' + app + ', code = ' + avpDict[app]['code']) 
    for command in avpDict[app]['commands']:
        print('Command: ' + avpDict[app]['commands'][command]['name'] + ', code = ' +  avpDict[app]['commands'][command]['code'])
        for msgType in avpDict[app]['commands'][command]['msgType']:
            print('Command Type: ' + msgType)
            for category in avpDict[app]['commands'][command]['msgType'][msgType]:
                print('AVP Type: ' + category)
                for avp in avpDict[app]['commands'][command]['msgType'][msgType][category]:
                    print(avp + ': ' + str(avpDict[app]['commands'][command]['msgType'][msgType][category][avp]))
            
    print('\n************************************************************')

def printAvp(avp):
    print('\n************************************************************')
    print('AVP: ' + avp)
    for attr in avpDict[avp]: print(attr + ': ' + str(avpDict[avp][attr]))
    print('\n************************************************************')
    
if __name__ ==  '__main__':
    main()

