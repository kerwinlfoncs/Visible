#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Thu 2021-11-11T22:02:43
# @futurize --stage2 --no-diffs -n -w  : Thu 2021-11-11T22:02:42
#
# @futurize --stage1 --no-diffs -n -w  : Thu 2021-11-11T22:02:42
from __future__ import print_function
# from builtins import zip
# from builtins import str
# from builtins import range
from future import standard_library
standard_library.install_aliases()
# from builtins import zip
# from builtins import str
# from builtins import range
import sys, os, copy, pprint, json
from subprocess import call
try:
    import configparser
except:
    from six.moves import configparser

from primitives import primXML as XML
from primitives import primHTTP  as HTTP
from primitives import primGeneric  as GENERIC
from primitives import primGET as GET
from primitives import timeToMDCtime  as MDCTIME
import xml.etree.ElementTree as ET

from primitives import primData as DATA
# Generic event store curl command prefix
curlQueryCmd = 'curl ' + DATA.curlAdditionalParams

if DATA.simpleAuthUserName: curlQueryCmd += '-u ' + DATA.simpleAuthUserName + ':' + DATA.simpleAuthPassword + ' '
curlQueryCmd += '-s ' + DATA.httpString + '://restgw:' + DATA.httpPort + '/rsgateway/data/json/'
#print 'curlQueryCmd = ' + curlQueryCmd

#==========================================================
# Get all parameters from an input "xxxFields" structure.
# Return a list of items, consisting of (field name, field value).
def getRecordFields(item, recFields):
        # Init return structure
        record = []
    
        # Look for each variable
        for variable in recFields:
                # If element exists get text, else set to NotPresentString
                cmd = 'for x in item.findall(\''+ variable + '\'): record.append((\'' + variable + '\', x.text))'
                #print('cmd: ' + cmd)
                exec(cmd)
    
        # Return record
        #print('getRecordFields: returning: ' + str(record))
        return record
    
#==========================================================
# Return a list of items, consisting of (field name, field value)
def flattenRecord(rec, reqType):
     retRecord = []
     
     # Balance fields that show up on a subscriber query.  Note that there are other balance fields that show up on a wallet query (e.g. is on demand)
     simpleFields = ['Name', 'CreditLimit', 'TemplateId', 'IsPeriodic', 'QuantityUnit', 'Category', 'IsAggregate', 'IsPrepaid', 'IsVirtual', 'Amount', 'ReservedAmount', 'AvailableAmount', 'StartTime', 'EndTime', 'ThresholdLimit', 'ClassName', 'ResourceId', 'IsOnDemand', 'IsRenewable']
     simpleXmlString = './BalanceArray/MtxBalanceInfoSimple'

     periodicFields = ['Name', 'CreditLimit', 'TemplateId', 'IsPeriodic', 'QuantityUnit', 'Category', 'IsAggregate', 'IsPrepaid', 'IsVirtual', 'Amount', 'ReservedAmount', 'AvailableAmount', 'StartTime', 'EndTime', 'ThresholdLimit', 'ClassName', 'ResourceId', 'IsOnDemand', 'IsRenewable']
     periodicXmlString = './BalanceArray/MtxBalanceInfoPeriodic'

     balanceFields = ['Name', 'CreditLimit', 'TemplateId', 'IsPeriodic', 'QuantityUnit', 'Category', 'IsAggregate', 'IsPrepaid', 'IsVirtual', 'Amount', 'ReservedAmount', 'AvailableAmount', 'StartTime', 'EndTime', 'ThresholdLimit', 'ClassName', 'ResourceId', 'IsOnDemand', 'IsRenewable']
     balanceXmlString = './BalanceArray/MtxBalanceInfo'

     offerFields = ['ProductOfferId', 'PurchaseTime', 'ResourceId', 'StartTime', 'Status', 'EndTime', 'CancelTime', 'CancelEndTime', 'PrimaryBalanceResourceId', 'ProductOfferVersion', 'ProductOfferExternalId', 'CatalogItemId', 'CatalogItemExternalId']
     offerXmlString = './PurchasedOfferArray/MtxPurchasedOfferInfo'

     pricingofferFields = ['OfferId']
     pricingofferXmlString = './OfferInfo/MtxPricingOfferDetailInfo'

     # Get desired data (use indirection)
     cmd = '_a = ' + reqType.lower() + 'Fields\n'
     exec(cmd)
     params = locals()['_a']
     
     cmd = '_a = ' + reqType.lower() + 'XmlString'
     exec(cmd)
     paramString = locals()['_a']

     # If looking at top level, then can't seem to use "findall" option directly...
     if paramString == '.': retRecord.append(getRecordFields(rec, params))
     else:
      # Process each child record
      for item in rec.findall(paramString): retRecord.append(getRecordFields(item, params))
     
     #print('flattenRecord: returning:')
     #pprint.pprint(retRecord)
     return retRecord
     
#==========================================================
def getParentOIDs(obj, search, options, value, subObjList = [], groupObjList = [], devObjList = [], userObjList = []):
        global objectsSub
        global objectsGroup

        #print 'In getParentOIDs for ' + obj + ' ' + value

        # URL is pretty straight-forward
        getCmd = curlQueryCmd + obj.lower() + '/' + search + '+' + value

        # Run the command
        print('Command: ' + getCmd)
        response = GENERIC.runCmd(getCmd)
        #print response

        # Import to Python dictionary
        j = json.loads(response)
        #pprint.pprint(j)

        # See if parent group list exists
        try:
                for parent in j['ParentGroupIdArray']:
                        # Insert at the front, as we're going upstream
                        groupObjList.insert(0,('Group', 'ObjectId', parent))

                        # Keep going until done
                        getParentOIDs('Group', 'ObjectId', options, parent, subObjList, groupObjList, devObjList)
        except: pass
    
        # See if subscriber parent exists (if a device)
        try:
                parent = j['SubscriberId']

                # Insert anywhere
                subObjList.append(('Subscriber', 'ObjectId', parent))

                # Keep going until done
                getParentOIDs('Subscriber', 'ObjectId', options, parent, subObjList, groupObjList, devObjList, userObjList)
        except: pass
    
        try:
          for parent in j['RelatedUserArray']:
            objectId = parent['ObjectId']
            
            # Insert at the front, as we're going upstream
            groupObjList.insert(0,('User', 'ObjectId', objectId))

            # Keep going until done
            getParentOIDs('User', 'ObjectId', options, objectId, subObjList, groupObjList, devObjList, userObjList)
        except: pass
    
        return

#==========================================================
def getChildOIDs(obj, search, options, value, subObjectList=[], groupObjList = [], devObjList = [], userObjList = [], includeDevice=False):
        global objectsSub
        global objectsGroup

        #print 'In getChildOIDs for ' + obj + ' ' + value

        # URL is pretty straight-forward
        getCmd = curlQueryCmd + obj.lower() + '/' + search + '+' + value

        # Run the command
        print('Command: ' + getCmd)
        response = GENERIC.runCmd(getCmd)
        #print response

        # Import to Python dictionary
        j = json.loads(response)
        #pprint.pprint(j)

        # Process group children
        if obj.lower() == 'group':
         # See if child subscriber list exists
         try:
                for child in j['SubscriberMemberIdArray']:
                        # Add to end of list since it doesn't matter
                        subObjectList.append(('Subscriber', 'ObjectId', child))
            
                        # Get device information iff we want device data
                        if includeDevice: getChildOIDs('Subscriber', 'ObjectId', options, child, subObjectList, groupObjList, devObjList, userObjList, includeDevice)
         except: pass
    
         # See if child group list exists
         try:
                for child in j['GroupMemberIdArray']:
                        # Add to end of list since lower in hierarchy
                        groupObjList.append(('Group', 'ObjectId', child))
            
                        # Keep going until done
                        getChildOIDs('Group', 'ObjectId', options, child, subObjectList, groupObjList, devObjList, userObjList, includeDevice)
         except: pass
    
         # See if user group list exists
         try:
                for child in j['UserMemberIdArray']:
                        # Add to end of list since lower in hierarchy
                        groupObjList.append(('User', 'ObjectId', child))
            
                        # Keep going until done
                        getChildOIDs('User', 'ObjectId', options, child, subObjectList, groupObjList, devObjList, userObjList, includeDevice)
         except: pass
    
        # See if subscription list exists
        try:
            for entry in j['RelatedSubscriptionArray']:
                objType = 'Subscription'
                child = entry['ObjectId']
            
                # Add to end of list since lower in hierarchy
                groupObjList.append((objType, 'ObjectId', child))
            
                # Keep going until done
                getChildOIDs(objType, 'ObjectId', options, child, subObjectList, groupObjList, devObjList, userObjList, includeDevice)
        except: pass
    
        # Process subscriber children
        if obj.lower() in ['subscriber', 'subscription']:
          # See if child device list exists
          if includeDevice and 'DeviceIdArray' in j:
                for child in j['DeviceIdArray']:
                        # Add to end of list since it doesn't matter
                        devObjList.append(('Device', 'ObjectId', child))

                # Nothing lower than devices, so no need to process anything else

#============================================================
def convertTimeToUrlFormat(timeData):
        #print 'timeData: ' + timeData
        usec = '.000000'

        # Input may not contain usec, which this function expects
        if not timeData.count('.'):
                # Add before timezone information
                for key in ['+', '-']:
                        if timeData[-6] == key: timeData = timeData[:-6] + usec + timeData[-6:]
                if timeData[-1].lower() == 'z': timeData = timeData[:-1] + usec + timeData[-1]

        # Change colon to URL equivalent characters and split time from remainder (msec + tzone)
        timeData = timeData.replace(":", "%3A").split(".")

        # Get time part
        timeString = timeData[0]

        # Add time zone if included (looking at remainder of input).
        # URL encode the +/- character.
        tzone = timeData[1].split('+')
        if len(tzone) > 1: timeString += '%2B' + tzone[1]
        tzone = timeData[1].split('-')
        if len(tzone) > 1: timeString += '%2D' + tzone[1]

        #print 'timeString: ' + timeString
        return timeString

#==========================================================
# Return Catalog Item information
def getCatalogItemTemplateParameterByExternalId(externalId, customName, variable):
    # Query data
    url = '/rsgateway/data/v3/pricing/CatalogItem/ExternalId+' + externalId
    q = GET.curlToETFormat(url)

    # Get proper etree path to look at
    path = './CatalogItemInfo/MtxPricingCatalogItemDetailInfo/TemplateAttr/' + customName + 'Template/' + variable
    #print 'Path: ' + path
    
    # Return the one item (full path specified)
    for item in q.findall(path): return item.text
    
    print('Hmmmm.  Did not find variable "' + variable + '" in response for path "' + path + "'")
    ET.dump(q)
    
    return None
    
#==========================================================
# Return List of Catalog Items
def getOfferList(offerIsExternal=True, offersToBlock=None, startTime=None):
    # Query data
    url = '/rsgateway/data/v3/pricing/CatalogItem' + GENERIC.getTimeStampStr(startTime)
    q = GET.curlToETFormat(url)
    
    # Get proper etree path to look at
    path = './CatalogItemList/MtxPricingCatalogItemInfo/'
    if offerIsExternal: 
        path += 'ExternalId'
        index = 0
    else:
        path = 'CatalogItemId'
        index = 1
    
    # Get the dimension we want to check
    offerList = []
    if offersToBlock: offerList = NP.array(offersToBlock)[:,index]
    
    # Look at each offer
    retData = []
    print('Offers to Block: ' + str(offerList))
    for item in q.findall(path):
#       print 'Looking at element ' + id.text
        if item.text not in offerList: retData.append(item.text)
    
    # return list
#   print 'Offer list: ' + str(retData)
    return retData
    
#==========================================================
# Return balance data from REST query
def getOfferData(target, value, offerId, offerExternalId, lclStartTime, command, queryType='ExternalId', offerIsCatalog=False, resourceId=None):
    # Resource ID may be overloaded
    if (not isinstance(resourceId, bool)) and (not str(resourceId).isdigit()):
        if   resourceId.lower() == 'first':
            duplicateIndex = 0
        else:   duplicateIndex = -1
        resourceId = 0
    else:   duplicateIndex = None
    
    # Define what we're looking for
    if offerIsCatalog:
        # Different values for catalog items
        if offerExternalId:
            # Catalog external ID 
            fieldName = 'CatalogItemExternalId'
            fieldValue = offerExternalId
        else:
            # Catalog ID
            fieldName = 'CatalogItemId'
            fieldValue = offerId
    elif offerExternalId:
        # Offer external ID
        fieldName = 'ProductOfferExternalId|CatalogItemExternalId'
        fieldValue = offerExternalId
    else:
        # Offer ID
        fieldName = 'ProductOfferId'
        fieldValue = offerId
    
    # Now need to query the target to get the resource ID associated with the offer ID.
    # Query data
    url = '/rsgateway/data/v3/' + target + '/query/' + queryType + '/' + value + GENERIC.getTimeStampStr(lclStartTime)
    mtxEventRecord = GET.curlToETFormat(url)
    
    # Process items
    objectDict = {}
    found = []
    foundIdx = []
    for dataSet in ['offer']:
        # Get parameters associated with data set
        retRecord = flattenRecord(mtxEventRecord,dataSet)
        for i in range(len(retRecord)):
            # Get the record
            r = retRecord[i]
            
            # Put results into a dictionary
            objectDict[str(i)] = {}
            for j in range(len(r)): objectDict[str(i)][r[j][0]] = r[j][1]
            #print 'Checking ' + dataSet + ': ' + str(objectDict[str(i)])
            
            # If already cancelled or ended, then skip
            if objectDict[str(i)]['Status'].lower() in ['2', 'in_cancellation', '3', 'inactive']: continue
            
            # See if the desired field is in the offer.  Could be one of several fields.
            for fieldItem in fieldName.split('|'):
                if (fieldItem in objectDict[str(i)] and objectDict[str(i)][fieldItem] == fieldValue): break
            else:   continue
            
            # If it matches what we're looking for, then add to the list.
            # Criteria is:  the object is valid at the current tool time
            if ('EndTime' not in objectDict[str(i)] or MDCTIME.checkIfTime2GreaterTime1(lclStartTime, objectDict[str(i)]['EndTime'])) and \
               ('CancelEndTime' not in objectDict[str(i)] or MDCTIME.checkIfTime2GreaterTime1(lclStartTime, objectDict[str(i)]['CancelEndTime'])):
                # Store dictionary entry that matches
                    found.append(objectDict[str(i)]['ResourceId'])
                    foundIdx.append(i)
                    #print 'Offer matches: ' + str(objectDict[str(i)])

    # See if we didn't find anything
    if len(found) == 0:
        print('ERROR: did not find ' + fieldName + ' "' + str(fieldValue) + '" valid at the tool time (' + str(lclStartTime) + ')')
        #cause(a, stack, dump)
        sys.exit('Error on command: ' + command)

    # If here, then we at least found one.  See if we found more than one and not expecting to.
    elif duplicateIndex == None and len(found) > 1:
        print('ERROR: found more than one active instance of "' + fieldName + '" "'  + str(fieldValue) + '"')
        print('Resource IDs: ' + str(found))
        #cause(a, stack, dump)
        sys.exit('Error on command: ' + command)

    # Want final index to use.  If duplicateIndex == None, then set to 0
    if duplicateIndex == None: duplicateIndex = 0
     
    # OK, seems we have a winner!
    #print 'Found ' + fieldName + ' '  + str(fieldValue)

    # Return found item
    print('Resource IDs: ' + str(found))
    return objectDict[str(foundIdx[duplicateIndex])]

#==========================================================
# Return All offer data from REST query
def getOffers(release='5100', regressionRun='None'):
    # *** Starting in 5050 everything purchased is a Catalog Item.  Upgraders created 1:1 mappings between old offers and catalog items.
    if int(release) >= 5050: return getCatalogItemId(regressionRun)
    
    # **** Pre-5050 code ****
    
    # Default array
    dctNameToExtId = []
    dctExtIdToId = []
    
    # Query data
    url = '/rsgateway/data/v3/pricing/offers' + GENERIC.getTimeStampStr(GET.commandTime)
    q = GET.curlToETFormat(url)
    
    # Process each offer and bundle
    for offerType in ['OfferList', 'BundleList']:
      for item in q.findall('./' + offerType + '/MtxPricingOfferInfo'):
#       ET.dump(item)
        
        # Force key fields to be None, so old data doesn't get mapped to a new item
        Name = None
        ExternalId = None
        
        # Get base level fields
        for elem in item:
            if item.find(elem.tag).text: 
                value = item.find(elem.tag).text.strip()
                if   elem.tag == 'Name':    Name = value
                elif elem.tag == 'ExternalId':  ExternalId = value
                elif elem.tag == 'CatalogItemId': CatalogItemId = value
        
        # Now put key items into the return dictionary
        if Name and ExternalId:
            # Map name with external Id iff different (as we don't want to translate the external ID
            # since it's used directly).  There's no mapping to ID - users will need to specify the ID if they want 
            # to buy that way.  [No reason to, so no need to support.]
            if Name != ExternalId: dctNameToExtId.append((Name, ExternalId))
            
            # Name to Catalog item ID is also potentially desirable (some customers always buy by ID)
            dctExtIdToId.append((ExternalId, CatalogItemId))
            
        else:
            print('Hmmm.  Offer missing key data (Name or ExternalId)')
            ET.dump(item)
    
    # Return both structures
#   print 'Returning CI name to external ID data: ' + str(dctNameToExtId)
#   print 'Returning CI external ID to catalog item ID data: ' + str(dctExtIdToId)
    return dctNameToExtId,dctExtIdToId
    
#==========================================================
# Return All catalog item data from REST query
def getCatalogItemId(regressionRun='None'):
    # Restore data if requested
    if regressionRun.lower() == 'restore':
        print('Restoring catalog item data')
        dctNameToExtId   = GENERIC.restoreDictionary(DATA.savedEngineData + "CatalogItemNameToExtIdFile")
        dctExtIdToId     = GENERIC.restoreDictionary(DATA.savedEngineData + "CatalogItemExtIdToIdFile")
        
        # Exit as all data is complete
        return dctNameToExtId,dctExtIdToId
    
    # Default array
    dctNameToExtId = []
    dctExtIdToId = []
    
    # Query data
    url =  '/rsgateway/data/v3/pricing/CatalogItem' + GENERIC.getTimeStampStr(GET.commandTime)
    try:
        q = GET.curlToETFormat(url)
        #ET.dump(q)
    except:
        # Return empty list
        return dctNameToExtId
    
    # Process each offer and bundle
    for offerType in ['CatalogItemList']:
      for item in q.findall('./' + offerType + '/MtxPricingCatalogItemInfo'):
        #ET.dump(item)
        
        # Force key fields to be None, so old data doesn't get mapped to a new item
        Name = None
        ExternalId = None
        
        # Get base level fields
        for elem in item:
             if item.find(elem.tag).text: 
                value = item.find(elem.tag).text.strip()
                if   elem.tag == 'Name':    Name = value
                elif elem.tag == 'ExternalId':  ExternalId = value
                elif elem.tag == 'CatalogItemId': CatalogItemId = value
                #elif elem.tag == 'TemplateName':   TemplateName = value
                #elif elem.tag == 'TemplateExternalId': TemplateExternalId = value
                #elif elem.tag == 'TemplateVersionName':    TemplateVersionName = value
        
        # Now put key items into the return dictionary
        if Name and ExternalId:
            # Map name with external Id iff different (as we don't want to translate the external ID
            # since it's used directly).  There's no mapping to the ID - users will need to specify the ID if they want 
            # to buy that way.  [No reason to, so no need to support.]
            if Name != ExternalId: dctNameToExtId.append((Name, ExternalId))
            
            # External ID to Catalog item ID is also potentially desirable (some customers always buy by ID)
            dctExtIdToId.append((ExternalId, CatalogItemId))
            
            # DO NOT map all names to the catalog ID.  Users should only use the Catalog external ID or the Catalog Name.
#           dctNameToExtId.append((ExternalId, CatalogItemId))
#           dctNameToExtId.append((TemplateExternalId, CatalogItemId))
#           dctNameToExtId.append((TemplateName, CatalogItemId))
#           dctNameToExtId.append((TemplateVersionName, CatalogItemId))
            
        else:
            print('Hmmm.  Catalog Item doesn\'t have ExternalId and/or Name:')
            ET.dump(item)
    
    # Someone, who shall not be named Gopal, has pricing where a CI name is the same as a different CI external ID...
    # Check for this.
    # In rare cases we're seeing this fail.  No idea why...  For now, add try/except as this is here to catch one very bad pricing item (name = External ID between offers) and shouldn't really impact 99.99% of users.
    try:
       if len(dctNameToExtId):
        unzipList = list(zip(*dctNameToExtId)) 
        if set(unzipList[0]) and set(unzipList[1]):
            print('WARNING: there is a case where the CI name matches a different CI external ID')
            
            # Search for external ID in each element
            for externalId in [x[1] for x in dctNameToExtId]:
                # Loop through array in reverse and remove if a match.
                # Loop idx starts at first number, ends at last number + 1.
                for idx in range(len(dctNameToExtId)-1,-1,-1):
                    if externalId == dctNameToExtId[idx][0]:
                        print('Deleting name = ' + externalId)
                        del dctNameToExtId[idx]
    except: pass
    
    # In this case the name needs to be removed as the external ID has the 
    # Save data if requested
    if regressionRun.lower() == 'save':
        print('Save catalog item data')
        GENERIC.saveDictionary(dctNameToExtId, DATA.savedEngineData + "CatalogItemNameToExtIdFile")
        GENERIC.saveDictionary(dctExtIdToId, DATA.savedEngineData + "CatalogItemExtIdToIdFile")
        
    # Return both structures
#   print 'Returning CI name to external ID data: ' + str(dctNameToExtId)
#   print 'Returning CI external ID to catalog item ID data: ' + str(dctExtIdToId)
    return dctNameToExtId,dctExtIdToId
    
#==========================================================
# Return user roles to pricing ID mappings
def getuserRoles(regressionRun='None'):
    # Default array
    dctRcvUserRole = {}
    
    # Query data
    url =  '/rsgateway/data/v3/pricing/user_role'
    q = GET.curlToETFormat(url)
    
    # Process each item
    for tag in q.findall('./RoleList/MtxPricingRoleInfo'):
        # Get base level fields
        for elem in tag:
         if tag.find(elem.tag).text: 
            value = tag.find(elem.tag).text.strip().lower()
            if   elem.tag == 'Name':    Name = value
            elif elem.tag == 'ExternalId':  ExternalId = value
            elif elem.tag == 'PricingId':   PricingId = value
        
        # Now put key items into the return dictionary
        try:
            dctRcvUserRole[Name] = PricingId
        except:
            print('Hmmm.  User Role missing key data (Pricing ID, Name, ExternalId)')
            ET.dump(tag)
    
    # Return both structures
    '''
    print 'Returning User Role data: '
    pprint.pprint(dctRcvUserRole)
    '''
    
    return dctRcvUserRole
    
#==========================================================
# Return all rate tags
def getRateTags():
    # Default array
    dctRcvRateTagsId = {}
    dctRcvRateTagsExtId = {}
    
    # Query data
    url =  '/rsgateway/data/v3/pricing/rate_tags'
    q = GET.curlToETFormat(url)
    
    # Process each item
    for tag in q.findall('./RateTagList/MtxPricingRateTagInfo'):
#       ET.dump(threshold)
        # Get base level fields
        for elem in tag:
         if tag.find(elem.tag).text: 
            value = tag.find(elem.tag).text.strip().lower()
            if   elem.tag == 'Tag':     Tag = value
            elif elem.tag == 'ExternalId':  ExternalId = value
            elif elem.tag == 'Id':      Id = value
        
        # Now put key items into the return dictionary
        try:
            dctRcvRateTagsId[Id] = ((Tag, ExternalId))
            dctRcvRateTagsExtId[Id] = ((Tag, Id))
        except:
            print('Hmmm.  Rate Tag missing some key data (ID, tag, externalId)')
            ET.dump(tag)
    
    # Return both structures
    '''
    print 'Returning rate tag ID data: '
    pprint.pprint(dctRcvRateTagsId)
    print 'Returning rate tag ExternalID data: '
    pprint.pprint(dctRcvRateTagsExtId)
    '''
    
    return dctRcvRateTagsId, dctRcvRateTagsExtId
    
#==========================================================
# Return All balance threshold data from REST query
def getBalanceThresholds(balanceId):
    # Default array
    dctRcvThreshold = []
    
    # Query data
    url =  '/rsgateway/data/v3/pricing/balance/' + str(balanceId) + '/thresholds'
    q = GET.curlToETFormat(url)
    
    # Process each balance
    for threshold in q.findall('./ThresholdInfoList/MtxPricingThresholdInfo'):
#       ET.dump(threshold)
        # Get base level fields
        for elem in threshold:
         if threshold.find(elem.tag).text: 
            value = threshold.find(elem.tag).text.strip().lower()
            if   elem.tag == 'Name':    Name = value
            elif elem.tag == 'Id':      Id = value
            elif elem.tag == 'Amount':  Amount = value
            elif elem.tag == 'IsPct':   IsPct = value
        
        # Now put key items into the return dictionary
        try:
            dctRcvThreshold.append((Name, Id, Amount, IsPct))
        except:
            print('Hmmm.  Balance ' + str(balanceId) + ' thresholds missing some key data (name or ID)')
            ET.dump(balanceId)
    
    # Return both structures
#   print 'Returning balance threshold data: ' + str(dctRcvThreshold)
    return dctRcvThreshold
    
#==========================================================
def getThresholdId(balanceId, thresholdId):
    saveThreshold = thresholdId
    
    # Read thresholds for this balance
    thresholdArray = getBalanceThresholds(balanceId)
#   pprint.pprint(thresholdArray)
    
    # Loop through each threshold and look for the name
    for elem in thresholdArray:
        # Split into components
        (name, Id, amount, isPct) = elem
        
        # Check if a match.  Allow threshold passed in to be a name or ID.
        # Assumes the name is not all digits...
        if (not thresholdId.isdigit() and name == thresholdId.lower()) or \
           (thresholdId.isdigit() and Id == thresholdId):
            thresholdId = Id
            thresholdAmount = amount
            percentFlag = isPct
            break

        # Sanity check that we have an ID now
        if not thresholdId.isdigit():
            print('ERROR: balance ID ' + balanceId + ' threshold ID "' + thresholdId + '" is not defined.  Exiting')
            pprint.pprint(thresholdArray)
            sys.exit('Error on getThresholdId')
    
    # Debug output
    print('Balance ID ' + balanceId + ' threshold "' + saveThreshold + '" translated to ID ' + thresholdId)
    
    return thresholdId, thresholdAmount, percentFlag

#==========================================================
# Return All life cycle data.
# Need two pieces of data: (1) simple mapping of name to number for test commands
#              (2) state map so we can remove an object (so traverse until we arrive at a state that can be deleted from)
def getLifeCycles(target, dctRcv = {}, regressionRun='None'):
    custStateData = {}
    
    # Restore data if requested
    if regressionRun.lower() == 'restore':
        print('Restoring life cycle data for target: ' + target)
        dctRcv   = GENERIC.restoreDictionary(DATA.savedEngineData + target + "LifeCyclesDctFile")
        stateMap = GENERIC.restoreDictionary(DATA.savedEngineData + target + "LifeCyclesStateMapFile")
        
        # Exit as all data is complete
        return dctRcv, stateMap
    
    # Query data
    url =   '/rsgateway/data/v3/pricing/lifecycle/' + target + GENERIC.getTimeStampStr(GET.commandTime)
    q = GET.curlToETFormat(url)
    
    # Process each state
    for item in q.findall('./StatusInfoArray/MtxPricingStatusInfo'):
#       ET.dump(item)
        # Get base level fields
        for elem in item:
           if item.find(elem.tag).text: 
                value = item.find(elem.tag).text.strip().lower()
                if   elem.tag == 'Status':  Status = value
                elif elem.tag == 'Description': Description = value
                elif elem.tag == 'DeleteAllowed':   DeleteAllowed = value
        
        # Now put key items into the return dictionary
        try:
            dctRcv[Description] = Status
        except:
            print('Hmmm.  Status life cycle missing some key data (Status)')
            ET.dump(item)
    
        # NOW want to build state transition logic and put in CUST data
        _description = Description
        custStateData[Description] = {}
        custStateData[Description]['DeleteAllowed'] = DeleteAllowed
        custStateData[Description]['transitions'] = []
        for transition in item.findall("./StatusTransitionInfoArray/MtxPricingStatusTransitionInfo"):
            for elem in transition:
                if transition.find(elem.tag).text: 
                    value = transition.find(elem.tag).text.strip().lower()
                    if elem.tag == 'Description':   Description = value
                
            custStateData[_description]['transitions'].append((Description))
    '''
    print target + ':'
    pprint.pprint(custStateData)
    '''
    
    # OK.  Have the full state transition and which states one can delete from.
    stateMap = {}
    statesToCheck = []
    _custStateData = copy.deepcopy(custStateData)
    for state in _custStateData:
        if custStateData[state]['DeleteAllowed'].lower() == 'true':
            stateMap[state] = 'Remove'
            del custStateData[state]
            
            # Add to states to check from for the next step
            statesToCheck.append((state))
    
    # OK, Now loop until nothing mapped.
    # Could check if custStateData is empty
    for idx in range(10):
      if not len(custStateData): break
      nextStateToCheck = []
      _custStateData = copy.deepcopy(custStateData)
      for state in _custStateData:
        for nextState in custStateData[state]['transitions']:
            if nextState in statesToCheck:
                stateMap[state] = nextState
                nextStateToCheck.append((state))
                del custStateData[state]
                break
      statesToCheck = copy.deepcopy(nextStateToCheck)
     
    # Save data if requested
    if regressionRun.lower() == 'save':
        print('Saving life cycle data for target: ' + target)
        GENERIC.saveDictionary(dctRcv, DATA.savedEngineData + target + "LifeCyclesDctFile")
        GENERIC.saveDictionary(stateMap, DATA.savedEngineData + target + "LifeCyclesStateMapFile")

    # Return data
    #print 'Returning ' + target + ' lifecycle data: ' + str(dctRcv)
    return dctRcv, stateMap
    
#==========================================================
# Return All event type data from REST query
def getEventTypeMappings(regressionRun='None'):
    #print 'In getEventTypeMappings'
    
    dctRcv = {}
    
    # Restore data if requested
    if regressionRun.lower() == 'restore':
        print('Restoring event Type data')
        dctRcv = GENERIC.restoreDictionary(DATA.savedEngineData + "geteventTypeMappingFile")
        
        # Return restored data
        return dctRcv
    
    # Query data
    url = '/rsgateway/data/v3/pricing/event_types' + GENERIC.getTimeStampStr(GET.commandTime)
    q = GET.curlToETFormat(url)
    #ET.dump(q)
    
    # Process each balance
    for item in q.findall('./EventTypeList/MtxPricingEventTypeInfo'):
        #ET.dump(item)
        
        # Process each field
        for elem in item:
            # If field has a value...
            if item.find(elem.tag).text: 
                # Store in a local variable
                value = item.find(elem.tag).text.strip().lower()
                if   elem.tag == 'Name':        Name = value
                elif elem.tag == 'EventTypeIdPath': EventTypeIdPath = value
        
        # Now put key items into the return dictionary (keyed both from name and ID)
        try:
            # Map name to ID
            dctRcv[Name] = EventTypeIdPath
        except:
            print('Hmmm.  getEventTypeMappings entry missing some key data (Name or EventTypeIdPath)')
            ET.dump(item)
    '''
    print 'At end of getEventTypeMappings:'
    pprint.pprint(dctRcv)
    '''
    
    # Save data if requested
    if regressionRun.lower() == 'save':
        print('Saving event type data')
        GENERIC.saveDictionary(dctRcv, DATA.savedEngineData + "geteventTypeMappingFile")
    
    return dctRcv
    
#==========================================================
# Return All balance data from REST query
def getBalances(regressionRun='None', dctRcvBal = {}, dctRcvClass = {}, dctRcvBalName = {}, dctRcvClassName = {}):
    # Restore data if requested
    if regressionRun.lower() == 'restore':
        print('Restoring balance data')
        dctRcvBal = GENERIC.restoreDictionary(DATA.savedEngineData + "getBalancesdctRcvBalFile")
        dctRcvClass = GENERIC.restoreDictionary(DATA.savedEngineData + "getBalancesdctRcvClassFile")
        dctRcvBalName = GENERIC.restoreDictionary(DATA.savedEngineData + "getBalancesdctRcvBalNameFile")
        dctRcvClassName = GENERIC.restoreDictionary(DATA.savedEngineData + "getBalancesdctRcvClassNameFile")
        
        # Return restored data
        return dctRcvBal, dctRcvClass, dctRcvBalName, dctRcvClassName
        
    # Query data
    url = '/rsgateway/data/v3/pricing/balances' + GENERIC.getTimeStampStr(GET.commandTime)
    q = GET.curlToETFormat(url)
    
    # Process each balance
    for balance in q.findall('./BalanceList/MtxPricingBalanceInfo'):
        #ET.dump(balance)
        # Get base level fields
        for elem in balance:
            if balance.find(elem.tag).text: 
                # Store in a local variable
                value = balance.find(elem.tag).text.strip().lower()
                if   elem.tag == 'BalanceId':   BalanceId = value
                elif elem.tag == 'ClassId': ClassId = value
                elif elem.tag == 'ClassName':   ClassName = value
                elif elem.tag == 'Name':    Name = value
        
        # Now put key items into the return dictionary (keyed both from name and ID)
        try:
           # Map name to ID
           dctRcvBal[Name] = BalanceId
           dctRcvClass[ClassName] = ClassId

           # Map ID to name
           dctRcvBalName[BalanceId] = Name
           dctRcvClassName[ClassId] = ClassName
        except:
            print('Hmmm.  Balance missing some key data (ID or class)')
            ET.dump(balance)
    
    # Save data if requested
    if regressionRun.lower() == 'save':
        print('Saving balance data')
        GENERIC.saveDictionary(dctRcvBal, DATA.savedEngineData + "getBalancesdctRcvBalFile")
        GENERIC.saveDictionary(dctRcvClass, DATA.savedEngineData + "getBalancesdctRcvClassFile")
        GENERIC.saveDictionary(dctRcvBalName, DATA.savedEngineData + "getBalancesdctRcvBalNameFile")
        GENERIC.saveDictionary(dctRcvClassName, DATA.savedEngineData + "getBalancesdctRcvClassNameFile")

    # Return both structures
#   print 'Returning balance templ data: ' + str(dctRcvBal)
#   print 'Returning balance class data: ' + str(dctRcvClass)
    return dctRcvBal, dctRcvClass, dctRcvBalName, dctRcvClassName
    
#==========================================================
# Return payment data from REST query
def getPaymentData(target, value, paymentToken, lclStartTime, command, queryType='ExternalId', haltOnError=True):
    # Need OId for the real query
    if queryType != 'ObjectId':
        # Get object ID
        url = '/rsgateway/data/v3/' + target + '/query/' + queryType + '/' + value  + GENERIC.getTimeStampStr(lclStartTime)
        q = GET.curlToETFormat(url)
        value = q.find('./ObjectId').text.strip()
    
    # Query data
    url = '/rsgateway/data/v3/' + target + '/' + value + '/payment' + GENERIC.getTimeStampStr(lclStartTime)
    q = GET.curlToETFormat(url)
    
    return q
    
#==========================================================
# Rollover processing
def getBalanceRolloverData(target, value, balanceId, resourceId, queryType='ExternalId', lclStartTime=None):
    retDict = {}
    
    # Query data
    url = '/rsgateway/data/v3/' + target + '/' + queryType 
    
    # Add value and time stamp
    url += '+' + value + '/wallet'
    if lclStartTime: url += GENERIC.getTimeStampStr(lclStartTime)
    
    # Get the data
    q = GET.curlToETFormat(url)
    '''
    print url
    ET.dump(q)
    print 'Looking for balanceId = ' + str(balanceId) + ', resourceId = ' + str(resourceId)
    '''
    
    # Walk the wallet to get periodic balances with a rollover indication
    xml = './BalanceArray/MtxBalanceInfoPeriodic'
    for balance in q.findall(xml):
        # If not desired template and resource ID, then skip
        if balance.find('TemplateId').text.strip() != str(balanceId): continue
        if balance.find('ResourceId').text.strip() != str(resourceId): continue
        
        '''
        print 'Found balance instance I\'m looking for'
        ET.dump(balance)
        '''
        
        # Walk the periods of this balance
        xml2 = './BalancePeriodArray/MtxBalancePeriodInfo'
        for period in balance.findall(xml2):
            '''
            print 'looking at period:'
            ET.dump(period)
            '''
            
            # Skip if no rollover component
            if period.find('RemainingRolloverCounter') is None: continue
            cntr = period.find('RemainingRolloverCounter').text.strip()
            
            # Ignore current (or older) periods.  Only want active rollover periods
            if cntr == '0': continue
            
            #print 'Found counter remaining ' + cntr
        
            # Get the fields
            dctRcv = {}
            dctRcv = XML.getObjectBaseFields(period, dctRcv)
            if cntr not in retDict: retDict[cntr] = copy.deepcopy(dctRcv)
            
        # Only one of these per wallet, so can break
        break
    
    return retDict
    
#==========================================================
# Return balance data from REST query
def getBalanceData(target, value, balanceId, resourceId, lclStartTime, command, queryType='ExternalId', haltOnError=True, returnExpiredOk=False):
     # Resource ID may be overloaded
     if (not isinstance(resourceId, bool)) and (not str(resourceId).isdigit()):
        if   resourceId.lower() == 'first':
            duplicateIndex = 0
        elif resourceId.lower() == 'second':
            duplicateIndex = 1
        elif resourceId.lower() == 'third':
            duplicateIndex = 2
        else:   duplicateIndex = -1
        resourceId = 0
     else:  duplicateIndex = None
    
     # Query data
     url = '/rsgateway/data/v3/' + target
     
     # If no Object ID then add query details
     if queryType != 'ObjectId': url += '/query/' + queryType
     
     # Add value and time stamp
     url += '/' + value + GENERIC.getTimeStampStr(lclStartTime)
     
     # Get the data
     mtxEventRecord = GET.curlToETFormat(url)
    
     # Process balances
     objectDict = {}
     found = []
     for dataSet in ['balance']:
            # Get parameters associated with data set
            retRecord = flattenRecord(mtxEventRecord,dataSet)
            for i in range(len(retRecord)):
                # Get the record
                r = retRecord[i]
                    
                # Put results into a dictionary
                objectDict[str(i)] = {}
                for j in range(len(r)): objectDict[str(i)][r[j][0]] = r[j][1]
            
                # I think we can/should ignore virtual instances...
                #field = 'IsVirtual'
                #if field in objectDict[str(i)] and str(objectDict[str(i)][field]).lower() == 'true': continue
                
                #print('Checking time ' + str(lclStartTime) + ' using ' + dataSet + ': ' + str(objectDict[str(i)]))
    
                # If it matches what we're looking for, then add to the list.
                # Criteria is:  template ID matches
                #               there is a balance amount to compare against
                #               the balance is valid at the current tool time
                #               the resource ID matches (if we asked for one)
                # NOTE: some commands can create instances and extend expired instances.  returnExpiredOk
                #   signals if it's OK if the amount is not present or the the balance is already expired.
                if ('TemplateId' in objectDict[str(i)] and objectDict[str(i)]['TemplateId'] == balanceId) and \
                   (returnExpiredOk or 'Amount' in objectDict[str(i)]) and \
                   (returnExpiredOk or ('EndTime' not in objectDict[str(i)] or MDCTIME.checkIfTime2GreaterTime1(lclStartTime, objectDict[str(i)]['EndTime']))) and \
                   (resourceId == 0 or ('ResourceId' in objectDict[str(i)] and int(objectDict[str(i)]['ResourceId']) == int(resourceId))):
                                # Store dictionary entry that matches
                                found.append(i)
                                #print 'Balance matches: ' + str(objectDict[str(i)])
     
     # See if we didn't find anything
     if len(found) == 0 and haltOnError:
        string = 'ERROR: did not find balance template ID ' + str(balanceId) + ' with a defined amount that\'s valid at tool time ' + str(lclStartTime)
        if resourceId != 0: string += ' and matches resource ID ' + str(resourceId)
        print(string)
        #cause(StackTrace)
        kef
        sys.exit('Error on command: ' + command)

     # If here, then we at least found one.  See if we found more than one and there wasn't a resource ID input
     if len(found) > 1 and resourceId == 0:
        # OK, maybe some are virtual and some are G/L.  If only one G/L then use it.  If more than one G/L then we have a problem.
        glFound = -1
        for i in found:
            # See if G/L (not virtual)
            if str(objectDict[str(i)]['IsVirtual']).lower() == 'false': 
                # Found a G/L instance.  See if first one,
                if glFound == -1: glFound = i
                else:
                    # Found multiple G/L instances
                    glFound = -1
                    break
        # Check if G/L found
        if glFound != -1: found = [glFound]
        elif duplicateIndex == None:
            # More than one G/L; this is a problem...
            print('ERROR: found more than one instance of balance template ID ' + str(balanceId) + ', but no resource ID was passed in')
            #cause(a, stack, dump)
            sys.exit('Error on command: ' + command)
    
     # Want final index to use.  If duplicateIndex == None, then set to 0
     if duplicateIndex == None: duplicateIndex = 0
         # OK, seems we have a winner!
         #if len(found) > 0: print 'Found balance template ' + str(balanceId) + ' in  ' + cmd + ' ' + str(value) + ' with a defined amount of ' + balanceDict[str(found[duplicateIndex])]['Amount']

     # Return found item
     if len(found) == 0: return None
     elif (len(found)-1) < duplicateIndex:
        print('Hmmm.  getBalanceData() returnd an index of ' + str(duplicateIndex) + ' which is beyond the array: ' + str(found))
        return None
     else:  return objectDict[str(found[duplicateIndex])]

#==========================================================
# Return All billing profile data
def getBillingProfiles(regressionRun='None', dctRcv = {}):
    # Restore data if requested
    if regressionRun.lower() == 'restore':
        print('Restoring Billing Profiles')
        dctRcv = GENERIC.restoreDictionary(DATA.savedEngineData + "BillingProfilesDctFile")
        
        # Exit as all data is complete
        return dctRcv
    
    # Query data
    url = '/rsgateway/data/v3/pricing/billing_cycles' + GENERIC.getTimeStampStr(GET.commandTime)
    q = GET.curlToETFormat(url)
    
    # Process each balance
    for item in q.findall('./BillingCycleList/MtxPricingBillingCycleInfo'):
#       ET.dump(item)
        # Get base level fields
        for elem in item:
            if item.find(elem.tag).text:
                # Store in a local variable
                value = item.find(elem.tag).text.strip().lower()
                if   elem.tag == 'Id':   Id = value
                elif elem.tag == 'Name': Name = value

        # Now put key items into the return dictionary
        try:
            dctRcv[Name] = Id
        except:
            print('Hmmm.  Billing profile missing some key data (Name)')
            ET.dump(item)
    
    # Save data if requested
    if regressionRun.lower() == 'save':
        print('Saving BillingProfiles')
        GENERIC.saveDictionary(dctRcv, DATA.savedEngineData + "BillingProfilesDctFile")
        
        # Return data
        #print 'Returning billing profile data: ' + str(dctRcv)
        return dctRcv

