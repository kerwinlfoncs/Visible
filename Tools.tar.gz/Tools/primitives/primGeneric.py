#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Thu 2021-11-11T22:02:54
# @futurize --stage2 --no-diffs -n -w  : Thu 2021-11-11T22:02:54
#
# @futurize --stage1 --no-diffs -n -w  : Thu 2021-11-11T22:02:53

from __future__ import print_function
from __future__ import absolute_import
# from builtins import input
# from builtins import next
# from builtins import zip
# from builtins import str
# from builtins import range
from future import standard_library
standard_library.install_aliases()
# from builtins import input
# from builtins import next
# from builtins import zip
# from builtins import str
# from builtins import range
import subprocess, os, copy, urllib.request, urllib.parse, urllib.error, sys, pprint, time, traceback, pytz, json, random
from datetime import datetime
from dateutil.parser import parse
from dateutil.tz import *
import pickle as pickle
import xml.etree.cElementTree as ET
from . import primData as PRIMDATA
try:
    import configparser
except:
    from six.moves import configparser

# Global to hold starting time
startTime = ''

# Holds data from create_config.info
CustomData = {}
CustomDataZip = {}

# Hold AVP data from the diameter dictionary
AvpData = {}

# Holds data for items to remove from create_config.info (HACK alert)
rmvThese = []

customItemsToCheckFor = []
customItemsToCheckFor.extend(['Subscriber', 'Group', 'Device', 'Offer', 'DiamRoMsg', 'DiamGxCCMsg', 'MultiServiceData', 'User', 'Login', '5GChargingDataRequest', 'ApiEventData', 'MultiUnitUsageData'])

#===============================================================================
def primGetCurlUrlStart(options):
    curlCmd = 'curl -s ' + PRIMDATA.curlAdditionalParams + ' '
    if options.httpAuthUsername:
        if not options.httpAuthPassword: sys.exit('ERROR: input specified httpAuthUsername but not httpAuthPassword')
        curlCmd += ' -u ' + options.httpAuthUsername + ':' + options.httpAuthPassword
        PRIMDATA.simpleAuthUserName = options.httpAuthUsername
        PRIMDATA.simpleAuthPassword = options.httpAuthPassword
    elif os.getenv("httpAuthUsername"):
        if not os.getenv("httpAuthPassword"): sys.exit('ERROR: environment variable httpAuthUsername set but  but not httpAuthPassword')
        curlCmd += ' -u ' + os.getenv("httpAuthUsername") + ':' + os.getenv("httpAuthPassword")
        PRIMDATA.simpleAuthUserName = os.getenv("httpAuthUsername")
        PRIMDATA.simpleAuthPassword = os.getenv("httpAuthPassword")
    elif PRIMDATA.simpleAuthUserName:
        if not PRIMDATA.simpleAuthPassword: sys.exit('ERROR: file primitives/primData.py specifies a non-None value for simpleAuthUserName but not simpleAuthPassword')
        curlCmd += ' -u ' + PRIMDATA.simpleAuthUserName + ':' + PRIMDATA.simpleAuthPassword

    if options.ssl or os.getenv("ssl"):
        httpStr = 'https'
        httpPort = '8443'
        PRIMDATA.httpString = 'https'
    else:
        httpStr = PRIMDATA.httpString
        httpPort = PRIMDATA.httpPort

    cmd = curlCmd + ' ' + httpStr + '://restgw:' + httpPort

    return cmd
    
#===============================================================================
def getServiceConfig(options=None):
        dctRcv = {}

        # Get the directory where these files are stored
        if options and options.dir: dir=options.dir
        else:           dir = '/opt/mtx/services/config'
        #else:          dir=os.path.expandvars(os.getenv('TOOLS', '.'))
        #print 'Using directory ' + dir + ' for config file reading'

        # Get file to read
        if options and options.cf: file = options.cf
        else:          file = dir + '/config_primitives.ini'
        #else:         file = dir + '/config_' + os.getenv('customer', 'Training') + '.ini'
        print('reading services config file: ' + file)

        # Read config file
        Config = configparser.ConfigParser()
        Config.read(file)
        #print 'Done reading config file: ' + file

        # Always get REST data from the config file
        try:
                dctRcv['hostname'] = ConfigSectionMap(Config, 'Rest')['hostname']
        except:
                print('WARNING: No Rest section "hostname" value configured.  Defaulting to localhost')
                dctRcv['hostname'] = 'localhost'
        try:
                dctRcv['hostport'] = ConfigSectionMap(Config, 'Rest')['hostport']
        except:
                print('WARNING: No Rest section "hostport" value configured.  Defaulting to 8080')
                dctRcv['hostport'] = '8080'

        # Get Device data
        try:
                dctRcv['sessions'] = ConfigSectionMap(Config, 'Device')['sessions']
                if dctRcv['sessions'].lower() == 'true': dctRcv['sessions'] = True
                else:                                    dctRcv['sessions'] = False
        except: dctRcv['sessions'] = False
    
        # Get non-object data
        try:
                dctRcv['offerOutput'] = ConfigSectionMap(Config, 'Misc-Access')['offeroutput']
        except: x=1
        try:
                dctRcv['priceFile'] = ConfigSectionMap(Config, 'Misc-Access')['pricefile']
        except: x = 1
        try:
                dctRcv['release'] = ConfigSectionMap(Config, 'Misc-Access')['release']
        except: dctRcv['release'] = '4751'
        try:
                dctRcv['bpw'] = int(ConfigSectionMap(Config, 'Misc-Access')['bpw'])
        except: dctRcv['bpw'] = 58
        try:
                dctRcv['bcpw'] = int(ConfigSectionMap(Config, 'Misc-Access')['bcpw'])
        except: dctRcv['bcpw'] = 20
        try:
                dctRcv['opw'] = int(ConfigSectionMap(Config, 'Misc-Access')['opw'])
        except: dctRcv['opw'] = 30
        try:
                dctRcv['readSyPolicy'] = ConfigSectionMap(Config, 'Misc-Access')['readsypolicy']
                if dctRcv['readSyPolicy'].lower() in ['yes', 'true', 'ok']: dctRcv['readSyPolicy'] = True
                else:                                                       dctRcv['readSyPolicy'] = False
        except: dctRcv['readSyPolicy'] = False
        try:
                dctRcv['viewGlobals'] = ConfigSectionMap(Config, 'Misc-Access')['viewglobals']
                if dctRcv['viewGlobals'].lower() == 'true': dctRcv['viewGlobals'] = True
                else:                                       dctRcv['viewGlobals'] = False
        except: dctRcv['viewGlobals'] = False
    
        # Read time zone data
        try:
                dctRcv['timezone'] = ConfigSectionMap(Config, 'Misc-Access')['timezone']
        except: dctRcv['timezone'] = None
    
        # If not found, then read from create_config.info
        if not dctRcv['timezone']:
            print('NOTE: timezone not set in "Misc-Access" section of file ' + file + '. Geting from /opt/mtx/custom/create_config.info and using Etc/UTC if not in that file.')
            try:
                cmd = 'grep "What is the system time zone" /opt/mtx/custom/create_config.info 2>/dev/null | head -1 | cut -f2 -d"?"'
                dctRcv['timezone'] = runCmd(cmd)
            except: dctRcv['timezone'] = 'Etc/UTC'
    
        # Get SSL + authentication data
        key = 'ssl'
        try:
                dctRcv[key] = ConfigSectionMap(Config, 'Auth')[key]
                if dctRcv[key].lower() in ['yes', 'true', 'ok']: dctRcv[key] = True
                else:                        dctRcv[key] = False
        except: dctRcv[key] = False
    
        for key in ['authusername', 'authpassword']:
            try:
                    dctRcv[key] = ConfigSectionMap(Config, 'Auth')[key]
            except: dctRcv[key] = None
    
        # events to remove
        key = 'eventstoremove'
        index = 'eventsToRemove'
        try:
                dctRcv[index] = ConfigSectionMap(Config, 'Misc-Access')[key]
                if dctRcv[index].lower() in ['none']: dctRcv[index] = []
                else:                               dctRcv[index] = dctRcv[index].split(',')
        except: dctRcv[index] = []
    
        '''
        print 'config parameters: '
        pprint.pprint(dctRcv)
        '''
    
        return dctRcv

#===============================================================================
#return True for time2 > time1 , otherwise false
def checkIfTime2GreaterTime1(time1, time2):
    import datetime
    t1 = parse(time1)
    t2 = parse(time2)
    delta= (t2 - t1)
    zeroSeconds = datetime.timedelta(seconds=0)
    #print ''
    #print 't1 = ', str(t1)
    #print 't2 = ', str(t2)
    #print 'Delta = ', str(delta)
    #print 'zeroSeconds = ', str(zeroSeconds)
    return delta > zeroSeconds


# ------------------------------------------------------------------------------
def initData(configFile, warnFlag = True):
    # Get config from file
    config = getConfig(configFile)
    
    # Get custom object info
    customData = getCustomData(config, warnFlag)
    
    # Return everything we read
    return (customData, config)
    
#===============================================================================
def setConfig(dctRcv, configIniFile):
    print('Writing configuration file ' + str(configIniFile))
    configG = configparser.ConfigParser()

    # Setup so option name case is preserved (default is to change to lower case)
    # This may only be a read-thing, but be safe...
    configG.optionxform=str

    # Create the file
    for section in list(dctRcv.keys()):
        # Create the section
        configG.add_section(section)
        
        # Add each element in the section
        for entry in list(dctRcv[section].keys()): configG.set(section, entry, dctRcv[section][entry])
    
    # Write the file
    f = open(configIniFile, 'w')
    configG.write(f)
    f.close()

    return

#===============================================================================
# This reads from a traditional LDAP-style init file:
'''
[Operations]
# Only performing Diameter operations with this config
Diameter        : True

[Diameter]
# Unique host/realm, so obvious where these came from
OriginHost              : MATRIXX-INFINITY-HOST
OriginRealm             : MATRXIX-INFINITY-REALM
'''
# The results are stored in a standards Python dictionary

def getConfig(configIniFile):
        if not os.path.exists(configIniFile):
                print('cannot find file ' + configIniFile + ' in the current directory')
                sys.exit(1)

        print('reading configuration data from ' + str(configIniFile))
        configG = configparser.ConfigParser()

        # Setup so option name case is preserved (default is to change to lower case)
        configG.optionxform=str

        # Read the file
        configG.read(configIniFile)

        # Play with this.  See if we can get every section and every field within every section
        sections = configG.sections()

        retData = {}
        for section in sections:
                retData[section] = {}
                for (option,value) in configG.items(section): retData[section][option] = value
#               for option in configG.options(section): retData[section][option] = configG.get(section, option)

#   print 'config dictionary: '
#   pprint.pprint(retData)

        return (retData)

#===============================================================================
def saveDictionary(dict, file):
        # Open the file
        f = open( file, "wb" )
    
        # Write the records dictionary
        pickle.dump(dict, f, -1)
    
        # Close the file
        f.close()
    
#===============================================================================
def restoreDictionary(file):
    # Verify the file exists
    if not os.path.isfile(file):
        print('Warning: trying to open file "' + file + '" but it doesn\'t exist.  Think about cleaning up this directory.')
        return None
    
    # Open the file
    f = open( file, "rb" )
    
    # Read the records dictionary
    retData = pickle.load(f)
    
    # Close the file
    f.close()
    
    return retData
    
#===============================================================================
# Function returns path to executable file
def which(program):
    import os
    def is_exe(fpath):
        return os.path.isfile(fpath) and os.access(fpath, os.X_OK)

    fpath, fname = os.path.split(program)
    if fpath:
        if is_exe(program):
            return program
    else:
        for path in os.environ["PATH"].split(os.pathsep):
            path = path.strip('"')
            exe_file = os.path.join(path, program)
            if is_exe(exe_file):
                return exe_file

    return None
#===============================================================================
# Function returns path to executable file
def whichDir(program):
    import os
    def is_exe(fpath):
        return os.path.isfile(fpath) and os.access(fpath, os.X_OK)

    fpath, fname = os.path.split(program)
    if fpath:
        if is_exe(program):
            return fpath
    else:
        for path in os.environ["PATH"].split(os.pathsep):
            path = path.strip('"')
            exe_file = os.path.join(path, program)
            if is_exe(exe_file):
                return path

    return None
#===============================================================================
# Fucntion to save time
def captureTime():
    global startTime
    
    # Get current time
    startTime = datetime.now()
    
#===============================================================================
# Fucntion to get delta in seconds from saved time
def deltaTimeInSeconds():
    global startTime
    
    # Get current time
    endTime = datetime.now()
    
    # Get the delta
    delta = endTime - startTime
    
    # Return the seconds
    return delta.seconds
    
#===============================================================================
# This function is used to run bash scripts.
def runCmd(cmd):
#    try:
#   x = 5 / 0
#    except:
#   print '-'*60
#   traceback.print_stack(limit=2)
#   print '-'*60
    
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    out = p.stdout.read().strip().decode('utf-8')
    return out  #This is the stdout from the shell command
#    return call(cmd, shell=True)

#==========================================================
def getTimeNow(systemTimeZone='Etc/UTC'):

    # From https://stackoverflow.com/questions/1398674/python-display-the-time-in-a-different-time-zone
    localTimeZone = pytz.timezone(systemTimeZone)
    startTime = datetime.now(localTimeZone)
    startTime = startTime.strftime("%Y-%m-%dT%H:%M:%S%z")
    
    # If timezone offet is all digits, then add separator
    if startTime[-4:].isdigit(): startTime = startTime[:-2] + ':' + startTime[-2:]
    
    #print 'getTimeNow: startTime = ' + str(startTime) + ', system time zone = ' + systemTimeZone
    return startTime
    
    # *** Legacy code - always seems to return UTC... ***
    
    ### Set time to be now in the target timezone
    # Set environment variable used by pytz libraries to local timezone
    os.environ['TZ'] = datetime.now(tzlocal()).tzname()

    # Get local time accountng for timezone
    time.tzset()
    startTime = time.strftime("%Y-%m-%dT%H:%M:%S%z")

    # Convert to desired timezone
    #startTime = MDCTIME.getTime(startTime=startTime, tz=MDCTIME.systemTimeZone)

    return startTime

#=============================================================
def getTimeStampStr(time = None):
    #print 'time = ' + str(time)
    if time is None: time = getTimeNow()
    else:
        time = urllib.parse.quote(time,':')
        #print 'timestamp for query is: ' + str(time)
    
    #print 'time = ' + str(time)
    # Need to remove usec as this causes REST command issues
    timeSplit = time.split(".")
    if len(timeSplit) > 1: time = timeSplit[0] + timeSplit[1][6:]
    
    # If timezone offet is all digits, then add separator
    if time[-4:].isdigit(): time = time[:-2] + ':' + time[-2:]
    #print 'time = ' + str(time)
    return '?timestamp=' + str(time)

#===============================================================================
def getDiameterAVPs(diameterGroupMappings):
    global AvpData
    
    # Define ptocol search strings in the diameter dictionary
    searchString = {}
    searchString['Gx'] = 'command name="CC" code="272" proxiable="true"'
    searchString['Gy'] = 'command name="Credit-Control" code="272" proxiable="true"'
    searchString['Sy'] = 'command name="Spending-Limit" code'
    
    print('Reading in Diameter dictionary AVP to type data')

    # Get command to retrieve diameter dictionary data
    cmd = 'grep "avp name=.*code=" ' + PRIMDATA.diamFile + ' | grep -v Grouped | cut -f2,6 -d\'"\''
    retData = runCmd(cmd)
    
        # Process each line (quote separated name/type pairs
    for line in retData.split("\n"): 
        (name,paramType) = line.split('"')
        AvpData[name] = paramType
    
    # Now process each of the desired messages.
    # Assume Gy if any entries (since this is what we normally do)
    if len(diameterGroupMappings):
        # Get mappings for each of the specified entries
        for entry in diameterGroupMappings:
            # Separate fields in array
            protocol = entry[0].capitalize()
            avp = entry[1]
            
            # Parent may not exist
            try:    parent = entry[2]
            except: parent = ''
            
            # Only support some protocols
            supportedProtocols = ['Gy', 'Gx', 'Sy']
            if protocol not in supportedProtocols:
                print('WARNING: TF only supports diameter struture mappings to ' + str(supportedProtocols) + '.  Entry "' + entry + '" will be ignored.')
                continue
            
            # Get protocol data if not yet processed
            if 'AVP_AVP_'+protocol not in AvpData:
                # Go get the data
                AvpData['AVP_AVP_'+protocol] = []
                AvpData['AVP_MDC_'+protocol] = []
                
                # Go get the data
                cmd='sed -n \'/' + searchString[protocol] + '/,/<\/request/p\' ' + PRIMDATA.diamFile
                dictData = runCmd(cmd).split('\n')
                #pprint.pprint(dictData)
                
                # Process array of data into a dictionary
                print('Processing Diameter structure mapping requests')
                dictionary = {}
                processDiameterStruct(0, dictionary, dictData)
                #pprint.pprint(dictionary)
                
                # Copy to struture so we can reuse in this loop
                if   protocol == 'Gy': GyData = copy.deepcopy(dictionary)
                elif protocol == 'Gx': GxData = copy.deepcopy(dictionary)
                elif protocol == 'Sy': SyData = copy.deepcopy(dictionary)
            
            # Point to proper dictionary
            if   protocol == 'Gy': dictionary = GyData
            elif protocol == 'Gx': dictionary = GxData
            elif protocol == 'Sy': dictionary = SyData
            
            # See if the key exists in the dictionary
            #print 'Looking at avp ' + avp
            for (entry,path) in gen_dict_extract(avp,dictionary, ""):
                # Skip if not the desired parent
                if parent and parent != path: continue
                
                # Report each key
                if type(entry) == dict: processDictEntry(  entry, AvpData, path+'|'+avp, protocol)
                else:           processSingleEntry(entry, AvpData, path+'|'+avp, protocol)
    
    # Return the global (not sure it's used...)
    return copy.deepcopy(AvpData)

#===============================================================================
def processDictEntry(entry, AvpData, path, protocol):
    # User wants a full dictionary
    for key in entry:
        # Skip list for parameter mapping (future)
        if key == 'listIndication': continue
        
        if type(entry[key]) == dict:    processDictEntry(  entry[key], AvpData, path+'|'+key, protocol)
        else:               processSingleEntry(entry[key], AvpData, path+'|'+key, protocol)

#===============================================================================
def processSingleEntry(entry, AvpData, path, protocol):
    # Strip leading characters that are bad
    path = path.strip('|')
    
    # Map single key
    print('Going to add protocol ' + protocol + ' AVP/MDC combination ' + path + '/' + entry)
    
    # Path may have a leading '|'.  Need to skip that.
    AvpData['AVP_AVP_'+protocol].append((path))
    AvpData['AVP_MDC_'+protocol].append((entry))
    
#===============================================================================
# From the web - finds all instances of a key in a dictionary and return the value.  
def gen_dict_extract(key, var,path):
    # Save input path so it can be reset inside loop
    savePath = path
    
    # See if the input variable can be iterated against (so not a simple value)
    if hasattr(var,'iteritems'):
    # iterate through the values
      for k, v in list(var.items()):
        # KEF - restore input path
        path = savePath
        
        # See if current dictionary key matches input
        if k == key:
            yield v,path
        
        # If processing a dictionary then iterate
        if isinstance(v, dict):
            # KEF part - build path
            if path:    path = path + '|' + k
            else:       path = k
        
            # Recursive call with pdated path and variable
            for (result,path) in gen_dict_extract(key, v, path):
                    yield result,path
        
        # If processing a list then go through list (in case list of dictionaries)
        elif isinstance(v, list):
            # KEF part - build path
            if path:    path = path + '|' + k
            else:       path = k
            
            # Process each element of the list
            for d in v:
                # Recursive call with pdated path and variable
                for (result,path) in gen_dict_extract(key, d, path):
                        yield result,path

#===============================================================================
def processDiameterStruct(index, dictionary, gyData):
        singleAvpOpen = False
        inComment = False
        while index < len(gyData): 
            # Get the entry
            entry = gyData[index]
            #print 'Processing entry "' + entry
            
            # Bump the index here (to facilitate continue statements)
            index += 1
            
            # Check if start of a comment
            if entry.count('<!--'):
                # See if closing comment not in the same line
                if not entry.count('-->'):
                    inComment = True
                '''
                    print "Entering comment"
                else:   print "Single line comment"
                '''
                
                # Nothing more to do with a comment
                continue
            
            # Check if close of a comment
            if entry.count('-->'):
                inComment = False
                #print "Exiting comment"
                continue
            
            # Skip if still in a comment
            if inComment: continue
            
            # See if closing an open AVP
            if singleAvpOpen:
                if entry.count('</avp>'):
                    singleAvpOpen = False
                    #print "Closed single AVP"
                
                # Skip remainder of line if in an AVP but not closed, or just closed it
                continue
            
            # See if the end of a struct
            if not entry.count('avp name=') and entry.count('</avp>'):
                # Drop last entry
                #print "Closed struct "
                
                # Return the next index
                return index
            
            # If not an AVP line then skip
            if not entry.count('avp name='):
                #print "Skipping line as it's not an AVP line"
                continue
            
            # Get AVP name
            avp = entry.split('"')[1]
            
            #print 'Processing entry "' + entry + '" with AVP "' + avp + '"'
            
            # See if a struct.  RSU and USU in outside don't follow conventions so add as a special case here...
            if entry.count('mdc_struct_name') or entry.count("Requested-Service-Unit") or entry.count("Used-Service-Unit"): 
                #print "Opening struct " + avp
                
                # Add new dictionary entry
                dictionary[avp] = {}
                
                # Iterate
                index = processDiameterStruct(index, dictionary[avp], gyData)
                
                '''
                # Add to entry
                try:
                    if hierarchyString != avp: gyDict[avp].append((hierarchyString))
                except:
                    print 'Failed to add avp ' + avp
                    pprint.pprint(gyDict)
                    kef
                '''
            else:
                # A single AVP. Get MDC name
                try:    dictionary[avp] = entry.split('"')[3]
                except: dictionary[avp] = avp + '_MISSING'
            
                # Want to find the end of this AVP
                if not entry.count('/>'):
                    singleAvpOpen = True
                    #print "Opening avp " + avp
                else:   
                    #print "Fully processed avp " + avp
                    singleAvpOpen = False
        return index
            
#===============================================================================
# The point of this function is to retrieve custom container names and fields.  
# This is trickier than I thought.  Plus the code below is pretty bad...
# This would be a good function to re-write, plus change all references to it.
def getCustomData(servicesConfig=None, WarnFlag = True):
    global CustomData
    global CustomDataZip
    global rmvThese
    global customItemsToCheckFor
    
    #print 'Starting getCustomData'
    
    retData = {}
    
    # Stuff in create_config.info to check for
    listOfStuffToCheckFor = []
    extraStuff= []
    
    # Add custom items that TF will want to reference.
    # TF code expects these entries, so need to include explicitly.  
    listOfStuffToCheckFor.extend(customItemsToCheckFor)
    
    # Point to create_config.info file (lots of references so use local and set from global)
    fileCreateConfig = PRIMDATA.createConfigFile
    
    # Get copy of this file
    tmpFile = '/tmp/_create_config' + str(random.randint(1,1000000))
    cmd = 'cp ' + fileCreateConfig + ' ' + tmpFile
    runCmd(cmd)
    
    # HACK alert: having too much trouble addressing custom event containers that start with <prefix>Subscriber.
    # Remove them in a very ungraceful manner here.
    # These are added to rmvThese from customer speciric code.
    itemsRemoved = []
    
    # FIXME: Taking too long to do these grep commands.  Need to remove these in a smarter way...
    # Need this so tools can capture custom fields properly.
    if servicesConfig and ('eventsToRemove' in servicesConfig) and (len(servicesConfig['eventsToRemove'])):
        # Build egrep -v string
        egrepStr = '|'.join(servicesConfig['eventsToRemove'])
        
        # Command to get rid of these items.
        # Also pull in only what is checked for below.
        randomFile='/tmp/xxx' + str(random.randint(1,1000000))
        cmd = 'egrep -v "' + egrepStr + '" ' + tmpFile + ' |  egrep "^Added MDC|^New " > ' + randomFile + ';mv ' + randomFile + ' ' + tmpFile
        #print cmd
        runCmd(cmd)
    
    # Read hacked create_config.info file and then remove the file
    with open(tmpFile, 'r') as content_file:
        contents = content_file.read().split('\n')
    os.remove(tmpFile)
    
    # Get added and new items into separate dictionaries
    addedStuff = {}
    valueToAddedStuffIndex = {}
    newStuff = {}
    customNames = {}
    for line in contents:
        # See if added
        if line.startswith("Added MDC"):
            # Get into line fields
            lineFields = line.split(':')
            
            # Get index
            index = lineFields[1].strip().lstrip('0')
            
            # Skip if an extension
            if index.count('Extension'): continue
            
            # See if index already exists
            if index not in addedStuff: addedStuff[index] = {}
            
            # Add to index
            endParts = lineFields[2].strip().split('?')
            
            # Get value (for ease of understanding)
            (question, value) = endParts
            question = question.strip()
            value = value.strip()
            
            # Add to index
            addedStuff[index][question] = value
            
            # Add container to list of stuff to check for
            if question == "What is the container's name":
                
                # OK; need to know if this is already part of the list of stuff to check for.
                # If not then need to know, as below there's a different string to check for this.
                for x in listOfStuffToCheckFor:
                    if value.lower().count(x.lower()): break
                else:
                    # If not in original list then add to extra list
                    extraStuff.append(value)
                    valueToAddedStuffIndex[value] = index
                
                # Add to list to check for
                #print 'getCustomData: added element ' + value
                listOfStuffToCheckFor.append(value)
            
            # Add events to list of stuff to check for (optimized code following old design...)
            if question == 'What is the name of the base container (if any)' and value.count('Event'):
#               print 'Adding to list: ' + value
                listOfStuffToCheckFor.append(value)
                retData[value] = {}
            
        # See if New
        elif line.startswith("New "):
            # Get into line fields
            lineFields = line.split(':')
            
            # Skip the object count line
            if len(lineFields) < 3: continue
            
            # Get index
            index = lineFields[1].strip().lstrip('0')
            
            # Get object type
            firstParts = lineFields[0].strip().split(' ')
            newObject = firstParts[1].strip()
            
            # See if object exists
            if newObject not in newStuff: newStuff[newObject] = {}
            
            # See if index already exists
            if index not in newStuff[newObject]: newStuff[newObject][index] = {}
            
            # Add to index
            endParts = lineFields[2].strip().split('?')
            newStuff[newObject][index][endParts[0].strip()] = endParts[1].strip()
            
    # With some items being removed, there's a chance the name will be gone but the other fields present.
    # address that here. Always delete rom highest to lowest as the array index changes if you delete in the middle and try to go up.
    itemToDelete = []
    for item in addedStuff:
        if "What is the container's name" not in addedStuff[item]: itemToDelete.insert(0, item)
    for index in itemToDelete: del addedStuff[index]
    
    '''
    print "Added stuff:"
    pprint.pprint(addedStuff)
    print "New stuff:"
    pprint.pprint(newStuff)
    print "List of stuff:"
    pprint.pprint(listOfStuffToCheckFor)
    '''
    
    # Also want to build custom name mappings
    for item in listOfStuffToCheckFor:
        debugString = 'kef'
        if item.startswith(debugString):debugFlag = True
        else:               debugFlag = False
        
        if debugFlag: print('Looking at item: ' + item)
        
        # Define item if needed
        if item not in retData: retData[item] = {}
        
        # Init stuff
        retData[item]['customFields'] = []
        retData[item]['customFieldTypes'] = []
        retData[item]['customFieldStruct'] = []
        retData[item]['customFieldSchema'] = []
        retData[item]['customFieldlist'] = []
        retData[item]['customFieldarray'] = []
        retData[item]['deletedSchemaList'] = []
        retData[item]['baseContainer'] = []
        
        # Hack for offers (really should fix this...)
        itemToCheck = item
        if item == 'Offer': itemToCheck = 'PurchasedOffer'
        '''
        elif item in customItemsToCheckFor: entryToCheck = "What is the container's name"
        elif item in extraStuff:entryToCheck = "What is the container's name"
        '''
        
        # Loop through all entries (probably a better way to do this as well...)
        for entry in addedStuff:
            # First question to look at
            entryToCheck = 'What is the name of the base container (if any)'
            
            if debugFlag: print('entry = ' + entryToCheck + ': ' + str(addedStuff[entry]))
            
            # May not have a mapping if there's no container this is based off of
            if entryToCheck not in addedStuff[entry]: continue
            
            # See if this is a base container of something
            if addedStuff[entry][entryToCheck].count(itemToCheck):
                # See what this is the base for
                customName = addedStuff[entry]["What is the container's name"]
                
                # Code is too convoluted...  Make sure item and custom name are not the same
                # Only do for Mtx items, as the rest are really new
                if item == customName and item.startswith('Mtx'): continue
                
                # Store mapping here
                retData[item]['customName'] = customName
                #print 'Item ' + item + ' has custom name: ' + customName
            
            # Not a base for something.  See if it is new.
            else:
                entryToCheck = "What is the container's name"
                if addedStuff[entry][entryToCheck].count(itemToCheck) and not item.startswith('Mtx'):
                    # A new custom field.  Map to itself and set local so we add parameter.
                    customName = addedStuff[entry][entryToCheck]
                    
                    # Store mapping here
                    retData[item]['customName'] = customName
                    #print 'Item ' + item + ' has custom name: ' + customName
                    break
                    
        # Check if custom name
        if 'customName' not in retData[item]:
            retData[item]['customName'] = ''
            
            # Set custom name to the item in question
            customName = item
#           continue
        
        # If no custom fields specified then skip
        if customName not in newStuff:
            continue
        
        # Build the NEW mappings
        for field in newStuff[customName]:
#           if field in newStuff[customName]: pprint.pprint(newStuff[customName][field])
            for entry in [  ('customFields',    "What is the field's name",     "ERROR"), \
                    ('customFieldTypes',    "What is the field's type",     "ERROR"), \
                    ('customFieldSchema',   'What is the created schema version',     "2"), \
                    ('customFieldStruct',   "What is the field's struct name",     "None"), \
                    ('customFieldlist', 'Is this field a list (y/n)',     "n"), \
                    ('customFieldarray',    'Is this field an array (y/n)',   "n"), \
                    ('baseContainer',   "What is the name of the base container (if any)",  "None"), \
                    ('deletedSchemaList',   'What is the deleted schema version', "0")]:
                (index, keyString, defaultValue) = entry
                if keyString in newStuff[customName][field]:
                    retData[item][index].append(newStuff[customName][field][keyString])
                elif defaultValue == "ERROR":
                    print('ERROR: Create config custom object ' + customName + ' field ' + field + ' missing entry ' + keyString + ' and no default configured')
                    sys.exit('Exiting due to errors')
                else:   retData[item][index].append(defaultValue)
    '''
    print 'retData:'
    pprint.pprint(retData)
    '''
    
    # Build list of stuff that can be customized and/or reported externally
#   stringToFind = []
#   stringToFind.append(('\'container id="MtxPurchase\''))
#   stringToFind.append(('\'container id="Mtx.*Notification">\''))
#   stringToFind.append(('\'container id="Mtx.*Object">\''))
#   stringToFind.append(('\'container id="MtxDiam.*Msg">\''))
#   stringToFind.append(('\'container id="Mtx.*Event">\''))
#   stringToFind.append(('\'container id="Mtx.*Extension">\''))
#   stringToFind.append(('\'container id="MtxBalanceTrackingData">\''))
    
    # Go check if there are any custom items defined.
    # *** Actually, no need to check for everything (as there's a lot of stuff now).
    # *** Only need the specific strings below for test framework.  
    # *** If one ever needs everything, the logic below will work.
        # Point to mtx_config.xml file
#   fileMtxConfig = os.path.expandvars(os.getenv('MTX_CONF_DIR', '/opt/mtx/conf')) + '/mtx_config.xml'
    
#####   for item in stringToFind:
#####       cmd = 'grep ' + item + ' ' + fileMtxConfig + ' | cut -f2 -d\'"\''
#####       listOfStuffToCheckFor.extend(runCmd(cmd).strip().split('\n'))
    
    # Add event structures
#   cmd = 'grep "What is the name of the base container" ' + fileCreateConfig + ' | grep Mtx.*Event | cut -f2 -d"?"'
#   listOfStuffToCheckFor.extend(runCmd(cmd).strip().split('\n'))
    
    # Get unique values
    retData['setOfStuffToCheckFor'] = set(listOfStuffToCheckFor)
    
        # Check for sub, group, device, offer.
    # Also check for custom event types
    customCount = 0
    for object in retData['setOfStuffToCheckFor']:
        # Can get a null string in here, so check for that
        if not object: continue
        
        # Get cutom name
        customName = retData[object]['customName']

        # If anything returned, then go look for fields
        if customName:
            # **** OK - now need to remove list entries that have been deleted.
            deletedSchemaList = retData[object]['deletedSchemaList']
#           for i in range(len(deletedSchemaList)): deletedSchemaList[i] = deletedSchemaList[i].strip()
            
            # Loop and look for objects that have been deleted.
            # Start at the end and work backwards, as pop operations change the impacted list so would need to keep track of that (messy).
            idx = len(deletedSchemaList) - 1
            while idx >= 0:
                # Check if need to delete this item
                if deletedSchemaList[idx].strip().lower() != '0':
#                   print 'Deleting index ' + str(idx)
                    # Need to go through all above created lists and remove the item.
                    for lists in ['customFields', 'customFieldTypes', 'customFieldlist', 'customFieldarray', 'customFieldSchema']: retData[object][lists].pop(idx)
                
                # Decrement list index
                idx -= 1
            
            # If there's a list, then add to custom name.  Kind of kludgy way this was done, but it works...
            for idx in range(len(retData[object]['customFieldlist'])):
                if retData[object]['customFieldlist'][idx].lower() == 'y': customName += '/' + retData[object]['customFields'][idx]
            
        else:
            # Need to set device custom as there are base-level custom device fields
            if object == 'Device':
                retData[object]['customName'] = 'MtxMobileDevice'
                retData[object]['customFields'] = []
                retData[object]['customFieldTypes'] = []
                retData[object]['customFieldSchema'] = []
                retData[object]['customFields'].append(('Imsi'))
                retData[object]['customFieldTypes'].append(('int'))
                retData[object]['customFieldSchema'].append(('2'))
            
            elif object == 'Login': 
                # Hard-code login data
                retData[object]['customName'] = 'MtxLoginDevice'
                retData[object]['customFields'] = []
                retData[object]['customFieldTypes'] = []
                retData[object]['customFieldSchema'] = []
                '''
                retData[object]['customFields'].append(('LoginId'))
                retData[object]['customFieldTypes'].append(('string'))
                retData[object]['customFieldSchema'].append(('2'))
                '''
            else:
                # Default other stuff to null
                retData[object]['customFields'] = retData[object]['customFieldTypes'] = retData[object]['customFieldSchema'] = []

                # Convert custom types to basic types (for validation)
                for index in range(len(retData[object]['customFieldTypes'])):
                        if   retData[object]['customFieldTypes'][index].count('int'):     retData[object]['customFieldTypes'][index] = 'integer'
                        elif retData[object]['customFieldTypes'][index].count('phone number'):  retData[object]['customFieldTypes'][index] = 'string'
                        elif retData[object]['customFieldTypes'][index].count('number'):  retData[object]['customFieldTypes'][index] = 'integer'
                        elif retData[object]['customFieldTypes'][index].count('decimal'): retData[object]['customFieldTypes'][index] = 'decimal'
                        elif retData[object]['customFieldTypes'][index].count('struct'):  retData[object]['customFieldTypes'][index] = 'struct'
                        elif retData[object]['customFieldTypes'][index].count('bool'):    retData[object]['customFieldTypes'][index] = 'binary'
                        else:                                                             retData[object]['customFieldTypes'][index] = 'string'
    
    # Add space if any custom names were printed
    if customCount: print()
    
    # OK, slight hiccup.  If no custom fields, then will have one entry that's NULL.  Want to get rid of that one...
    for object in retData:
        for key in ['customFields', 'customFieldTypes', 'customFieldSchema', 'customFieldStruct']:
            # May not have the key for all entries
            if key not in retData[object]: continue
            if len(retData[object][key]) == 1 and retData[object][key][0] == '': retData[object][key] = []
    
    #pprint.pprint(retData['Device'])
    
    # Get mappings between AVPs and MDC fields.  Need per-message data.  Only care about request items (what we send).
    # Limit to Gx/Gy/Sy and then only the key messages.  Add more later if needed.
    for protocol in ['Gy', 'Gx', 'Sy']:
        retData['AVP_MDC_' + protocol] = []
        retData['AVP_AVP_' + protocol] = []
        
    # Minor hack here.  Config read two different ways.  So may be at top level or at second level.
    # Also, not all callers have the service config so need to account for this.  
    # Really should fix this...
    if not servicesConfig:          release = 5000
    elif 'Misc-Access' in servicesConfig:   release = int(servicesConfig['Misc-Access']['release'])
    elif 'release'     in servicesConfig:   release = int(servicesConfig['release'])
    else:                   release = 5000
    if release < 5000:
        print('In pre-5000 release')
        # Using pre-500x Diameter ditionary
        # Get mappings between AVPs and MDC fields
        name = 'AVP_MDC_Gy'
        cmd = 'grep "^Diameter:New Credit-Control Request AVP.* MDC\'s field name" ' + fileCreateConfig + ' | cut -f2 -d"?"'
#        print cmd
        retData[name] = runCmd(cmd).split('\n')
        for i in range(len(retData[name])): retData[name][i] = retData[name][i].strip()
        
        name = 'AVP_AVP_Gy'
        cmd = 'grep "^Diameter:New Credit-Control Request AVP.* AVP\'s name" ' + fileCreateConfig + ' | cut -f2 -d"?"'
#        print cmd
        retData[name] = runCmd(cmd).split('\n')
        for i in range(len(retData[name])): retData[name][i] = retData[name][i].strip()     
    else:
      # Get lines from config file.  TF only adds logic for requests, since one can;t specify inputs to a response.
      cmd = 'grep "^Diameter:New.*application.*Request.*AVP:.*\'s.*name" ' + fileCreateConfig
      #print cmd
      respData = runCmd(cmd)
      respData = respData.split('\n')
      #pprint.pprint(respData)
      
      # Define structs to hold intermediate data
      retMdcData = []
      retAvpData = []
      
      # ** Need to look at this in sets of two lines (assumes they're always defined next to each other in the config file...)
      # Split into AVP and MDC arrays
      for item in respData:
        # See if AVP or MDC item
        str1 = 'AVP\'s name'
        if item.count(str1):    retAvpData.append((item.strip()))
        else:           retMdcData.append((item.strip()))
      #pprint.pprint(retAvpData)
      #pprint.pprint(retMdcData)
      
      for item in [(('Credit-Control', 'Gy')), (('Re-Auth', 'Gy')), (('CC', 'Gx')), (('RA', 'Gx')), (('Spending-Limit', 'Sy')), (('Session-Terminate', 'Sy'))]:
        # Split the entry to components
        (message,protocol) = item
        #print 'Message = ' + message + ', protocol = ' + protocol
        
        # Get array entry (will be used to setup custom data)
        name = 'AVP_MDC_' + protocol
        
        # Process grep data
        for i in range(len(retMdcData)):
            # See if this message is not in this entry
            if not retMdcData[i].count(message): continue
            
            # See if both fields are not defined
            avpData = retAvpData[i].split('?')[1].strip()
            mdcData = retMdcData[i].split('?')[1].strip()
            
            # If both fields not defined then can't use
            if not avpData or not mdcData:
                if WarnFlag: print('WARNING: AVP ' + avpData + ' for ' + str(item) + ' not mapped to a MDC field.  Not assigning any as TF parameters.')
            else:
                name = 'AVP_MDC_' + protocol
                retData[name].append((mdcData))
                name = 'AVP_AVP_' + protocol
                retData[name].append((avpData))
                #print 'AVP data for ' + name + ':'
                #pprint.pprint(retData[name])
        
        ''' 
        cmd = 'grep "^Diameter:New.*' + message + ' Request.*AVP.* MDC\'s field name" ' + fileCreateConfig + ' | cut -f2 -d"?"'
#       print cmd
        response = runCmd(cmd)
                retMdcData = []
                if len(response) > 1: retMdcData = response.split('\n')
                #print 'Protocol ' + name + ': ' + str(retMdcData)
                for i in range(len(retMdcData)): retMdcData[i] = retMdcData[i].strip()
        
        name = 'AVP_AVP_' + protocol
        cmd = 'grep "^Diameter:New.*' + message + ' Request.*AVP.* AVP\'s name" ' + fileCreateConfig + ' | cut -f2 -d"?"'
#       print cmd
        response = runCmd(cmd)
        retAvpData = []
        if len(response) > 1: retAvpData = response.split('\n')
        #print 'Protocol ' + name + ': ' + str(retAvpData)
        for i in range(len(retAvpData)): retAvpData[i] = retAvpData[i].strip()
 
        # If the two parts are not equal, then can't add this item.  Will happen when an AVP is added without a matching MDC.
        if len(retAvpData) != len(retMdcData):
                print 'WARNING: AVPs for ' + str(item) + ' not all mapped to MDC fields.  Not assigning any as TF parameters.'
        else:
                name = 'AVP_MDC_' + protocol
                retData[name] += retMdcData
                name = 'AVP_AVP_' + protocol
                retData[name] += retAvpData
        '''
      
    # For good measure get the MEF file record format (needed to know if we need to convert records to XML)
    cmd = 'grep "^What is the data format to use for the MATRIXX Event Files" ' + fileCreateConfig + ' | cut -f2 -d"?"'
    #print cmd
    retData['mefFileFormat'] = runCmd(cmd)
    
    # Save custom data (can be used globally by anyone else)
    CustomData = copy.deepcopy(retData)
    
    # ZIP data so it's much (much) clearer
    for item in retData:
        # Skip if not one of the field items
        if 'customFields' not in retData[item]: continue
        
        # Zip the data
        CustomDataZip[item] = list(zip( retData[item]['customFields'],
                        retData[item]['customFieldTypes'],
                        retData[item]['customFieldStruct'],
                        retData[item]['customFieldlist'],
                        retData[item]['baseContainer'],
                        retData[item]['customFieldarray'],
                        retData[item]['customFieldSchema'],
                        retData[item]['deletedSchemaList']))
    
    #pprint.pprint(CustomDataZip)
    
    # Return dictionary
    #print 'Custom DiamRoMsg Data: '
    #pprint.pprint(CustomData['DiamRoMsg'])
    #pprint.pprint(CustomData['5GChargingDataRequest'])
    return retData
    
#===============================================================================
#return True for time2 > time1 , otherwise false
def checkIfTime2GreaterOrEqualTime1(time1, time2):
    import datetime
    
    '''
    print ''
    print 'Time1/2 = ' + str(time1) + '/' + str(time2)
    '''
    
    t1 = parse(time1)
    t2 = parse(time2)
    
    '''
    print 't1 = ', str(t1)
    print 't2 = ', str(t2)
    '''
    
    delta= (t2 - t1)
    zeroSeconds = datetime.timedelta(seconds=0)
    
    '''
    print ''
    print 'Time1/2 = ' + str(time1) + '/' + str(time2)
    print 't1 = ', str(t1)
    print 't2 = ', str(t2)
    print 'Delta = ', str(delta)
    print 'zeroSeconds = ', str(zeroSeconds)
    '''
    
    return delta >= zeroSeconds
    
#===============================================================================
# Calculate delta time in seconds
def calc_sec(p_start_time):
        deltatime = datetime.now() - p_start_time
        duration = deltatime.seconds + float(deltatime.microseconds)/ 100000
        return duration

#==========================================================
def pauseCheck(check=False):
        # See if pause is disabled and we're not supposed to unconditionally check
        if not check:
                print('Skipping pause as configuration parameter Program/pauseForHumanInput is ' + str(data))
                return

        # Prompt the user
        print(' ')
        foo=input('Press enter to continue: ')
        print(' ')

#==========================================================
def checkDebugLogForErrors(currentErrorCount, file):
        # Get error count in the debug log
        cmd = 'grep ERROR ' + file + ' | wc -l'
        newErrorCount = runCmd(cmd)

        # If greater than current count, then tell user to go check
        if int(newErrorCount) > int(currentErrorCount):
                print('WARNING:  file ' + file + ' has ' + newErrorCount + ' errors, when it had ' + currentErrorCount + ' at the start.')
                print('Please verify errors and decide whether to continue.')
                pauseCheck(check=True)

        return newErrorCount
    
#===============================================================================
# This function executes a curl command
'''
def runCurlCmd(cmd, validate=True):
        curlRsp=runCmd(cmd)
        #print 'curlRsp = ' + curlRsp

        # Put into XML structure
        x=ET.fromstring(curlRsp)

        # Make sure we passed
        if validate and x.find('Result').text.strip() != '0':
                result = False
                print 'Failed REST command: ' + cmd
                print 'Result Code = ' + x.find('Result').text.strip()
                try:
                        print 'Result Text = ' + x.find('ResultText').text.strip()
                except:
                        print 'No result text returned'
        else:   result = True
    
    return (result, x)
''' 

#================== Read CSV file  ================================================
def decomment(csvfile):
    for row in csvfile:
        raw = row.split('#')[0].strip()
        if raw:
            #print 'Yeilding row: ' + raw
            yield raw

def readCsvFile(fileName, name='Entry'):
    import csv
    from collections  import namedtuple
    #from recordtype import recordtype
        
    # ******* Process input file
    row = []
    with open(fileName, 'rt') as f:
            # Establish this as a CSV file with comments removed
            f_csv = csv.reader(decomment(f))

            # Get headings (always first line)
            headings = next(f_csv)

            # Setup so we can use heading names to reference fields
            Row = namedtuple(name, headings)
            for entry in f_csv:
                # Blank lines at the end of files cause this issues.  
                # I should check for blank above...
                try:
                    row.append(Row(*entry))
                    #print('Added row: ' + str(row[-1]))
                except: pass
    
    print('Read in ' + str(len(row)) + ' rows from file ' + fileName)        
    return row,headings

#===============================================================================
# A slick way to read a parameter within a section of a config file
def ConfigSectionMap(Config, section):
    dict1 = {}
    options = Config.options(section)
    for option in options:
        try:
            dict1[option] = Config.get(section, option)
            if dict1[option] == -1:
                DebugPrint("skip: %s" % option)
        except:
            print("exception on %s!" % option)
            dict1[option] = None
    #print 'dict1 = ' + str(dict1)
    return dict1

#===============================================================================
# Check if a file exists
def checkFileExists(inputFile):
    # Make sure file exists and can be opened
    try:
        with open(inputFile) as f:  retVal = True
    except IOError as e:        retVal = False
        
    return  retVal

#===============================================================================
# Read file and return in ET object
def fileToET(inputFile):
    # Read hacked create_config.info file
    with open(inputFile, 'r') as content_file:
        contents = content_file.read()
    
    # Convert to ET format
    response = ET.fromstring(contents)
    
    return response
    
#================== Main function  ================================================
def main():
    # 
    print('Hello')

if __name__ ==  '__main__':
    main()

