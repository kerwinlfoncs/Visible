from distutils.core import setup
setup(name='mtx-services-primitives',
	version='4710.0',
        package_dir={'primitives': ''},
        packages=['primitives'],
        data_files=[('config', ['config_primitives.ini'])],
	description='MATRIXX Services Primitives',
	author='Karl Freter',
	author_email='karl.freter@matrixxsw.com',
	url='www.matrixxsw.com',
      )

