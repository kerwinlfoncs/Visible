#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Thu 2021-11-11T22:03:01
# @futurize --stage2 --no-diffs -n -w  : Thu 2021-11-11T22:03:01
#
# @futurize --stage1 --no-diffs -n -w  : Thu 2021-11-11T22:03:00

# Import system primitives
from __future__ import print_function
# from builtins import str
# from builtins import range
from future import standard_library
standard_library.install_aliases()
# from builtins import str
# from builtins import range
import sys, os, re, pprint, time
import copy
import optparse
import time
import xml.etree.ElementTree as ET
from subprocess import call
try:
    import configparser
except:
    from six.moves import configparser

# Import MTX primitives
from primitives import primGeneric as GENERIC

#================== Global Data  ================================================
# Define max items of one type in a wallet
global maxCount
maxCount = 50

#================== Vaidation Primitives ================================================
#===============================================================================
def process4300PriceFile(inputFile):
    # Define statr/end of message characters
    msgStartString = 'cancel_proration_type'
    msgLineSkipChar = ''
    msgEndString = '/product_offer_revision'
    externalIdString = 'external_id'
    balanceString = 'required_balance'

    # Initialize return structure
    retData = {}
    retData['offerList'] = []

    # Initialize local message holder
    localRetMsg = ''

    # Init local variables
    msgCount = 0
    skipRestOfRevision = False
    msgStartFlag = False
    endFlag = False

    # Define filtered data file
    filterFile = '_FilterData'

    # Debug output
    #print 'Pre-processing file: ' + inputFile

    # verify the file exists
    if not os.path.isfile(inputFile):
        print('\n\nValidation Error: input file ' + inputFile + ' does not exist\n\n')

        # Exit
        return None, 0

    # Get key data as per the price file format
    GENERIC.runCmd("awk '/product_offer_revision/,/\/product_offer_revision/' " + inputFile + ' | grep -v metadata | grep -v component_ref | grep -v "/required_balance" > ' + filterFile)
    # Open the filter file
    f = open(filterFile)

    # Go through each line in the file
    for line in f:
        # Remove leading/trailing white space
        line = line.strip()

        # If an empty line, skip
        if not line: continue

        # Debug output
        #print 'Processing line: ' + line

        # Skip until we get to the header line
        if not msgStartFlag:
                # See if at start of new message
                if re.search(msgStartString, line):
                        # If here, then found the start of the message
                        msgStartFlag = True

                        # What we want is the external ID value.
                        # Split line into components
                        lclLine = line.split('=')

                        # Check each component
                        for idx in range(len(lclLine)):
                                # See if this is not the external ID
                                if not re.search(externalIdString, lclLine[idx]): continue

                                # Found the external ID.  Want the value (in the subsequent entry, between the tick marks)
                                offerName = lclLine[idx+1].split("'")[1]

                                # This could be an older revision, so check if so
                                if offerName in retData:
                                        # Only want latest rev of any offer
                                        skipRestOfRevision = True

                                        # Debug output
                                        #print 'Detected revision of new offer: ' + offerName

                                else:
                                        # Add this key, making it a list
                                        retData[offerName] = []
                                        retData['offerList'].append(offerName)

                                        # Debug output
                                        #print 'Detected start of new offer: ' + offerName

                                # No matter what, we can break from the loop here
                                break

                # No need to further process this line
                continue

        # If here, then past start of the message.  Go until the end of the message is found.
        # Skip the one line that starts with a skip character.
##        if line[0] == msgLineSkipChar: continue

        # Check if end found.
        if re.search(msgEndString, line): endFlag = True
        else:
                # Not at the end
                endFlag = False

                # If we're supposed to skip this revision, then skip
                if skipRestOfRevision: continue

                # Sanity check that the line contains the key string
                if not re.search(balanceString, line): continue

                # If here, then we need to get the balance class and ID values
                lclLine = line.split("'")

                # Class is the first data and ID is the second, both in the A=B format
                balClass = lclLine[3]
                balId = lclLine[1]

                # Debug output
                #print ('Adding class/ID ' + balClass + '/' + balId + ' to offer ' + offerName)

                # Add this to the retData
                retData[offerName].append((balClass,balId))

        # Act if end found
        if endFlag:
                # Clear start flag
                msgStartFlag = False

                # Bump message counter
                msgCount += 1

                # Clear flags
                skipRestOfRevision = False
                endFlag = False
                msgStartFlag = False

                # No more processing of this line needed
                continue

    # Remove temp files
    f.close()
    GENERIC.runCmd('rm ' + filterFile)

    # Debug output
    #print ('returning price data: ' + str(retData))

    return retData, msgCount

#===============================================================================
def processTrunkPriceFile(inputFile):
    # Define statr/end of message characters
    msgStartString = 'ExternalId'
    #msgLineSkipChar = ''
    #msgEndString = 'ExternalId'
    #externalIdString = 'ExternalId'
    balanceString = 'BalanceId'

    # Initialize return structure
    retData = {}
    retData['offerList'] = []

    # Initialize local message holder
    localRetMsg = ''

    # Init local variables
    msgCount = 0
    skipRestOfRevision = False
    #msgStartFlag = False
    #endFlag = False

    # Define filtered data file
    filterFile = '_FilterData'

    # Debug output
    #print 'Pre-processing file: ' + inputFile

    # verify the file exists
    if not os.path.isfile(inputFile):
        print('\n\nValidation Error: input file ' + inputFile + ' does not exist\n\n')

        # Exit
        return None, 0
    # Get key data as per the price file format.
    # Get offers and bundles.
    GENERIC.runCmd("awk '/<MtxProductOfferRev>/,/<\/MtxProductOfferRev>/' " + inputFile + " | egrep 'ExternalId|<BalanceId>' | tac > " + filterFile)
    GENERIC.runCmd("awk '/<MtxBundleRev>/,/<\/MtxBundleRev>/' " + inputFile + " | egrep 'ExternalId|<BalanceId>' | tac >> " + filterFile)

    # Open the filter file
    f = open(filterFile)

    # Go through each line in the file
    for line in f:
        # Remove leading/trailing white space
        line = line.strip()

        # If an empty line, skip
        if not line: continue

        # Debug output
        #print 'Processing line: ' + line

        # See if at start of new offer
        if re.search(msgStartString, line):
                # Want the external ID value.
                # Split line into components to get this value
                offerName = line.split('>')[1].split('<')[0]

                # This could be an older revision, so check if so
                if offerName in retData:
                        # Only want latest rev of any offer
                        skipRestOfRevision = True

                        # Debug output
                        #print 'Detected revision of new offer: ' + offerName

                else:
                        # Add this key, making it a list
                        retData[offerName] = []
                        retData['offerList'].append(offerName)

                        # Debug output
                        #print 'Detected start of new offer: ' + offerName

                        # want all balances here
                        skipRestOfRevision = False

                        # Bump message counter
                        msgCount += 1

                # No more to do here
                continue

        # If we're supposed to skip this revision, then skip
        if skipRestOfRevision: continue

        # Sanity check that the line contains the key string
        if not re.search(balanceString, line):
            print('Hmmm.  Line missing "' + balanceString + '": ' + str(line))
            continue

        # Balance template ID is in the same spot
        balId = line.split('>')[1].split('<')[0]

        # Debug output
        #print('Adding ID '+ balId + ' to offer ' + offerName)

        # Add this to the retData
        if offerName in retData: retData[offerName].append((None,balId))
    else: print('Hmmm.  Didn\'t find offername in retData for line ' + line)

    # Remove temp files
    GENERIC.runCmd('rm ' + filterFile)

    # Debug output
    #print('returning price data: ' + str(retData))

    return retData, msgCount

# This function does the actual validation
def validateData(obj, objDct, priceData, options):
    print('Starting wallet validation')
#   print 'priceData: ' + str(priceData)
    
    # Initialize error counters
    missingBalanceCount = 0
    missingBalancId = ''
    extraBlanceCount = 0
    extraBlanceIds = ''
    
    # Get local time accountng for timezone
    time.tzset()
    nowTime = time.strftime("%Y-%m-%dT%H:%M:%S%z")
    
        ######## First step:  make sure object wallet has all the balances it requires based on the offers purchased

    # Debug output
    print('\n\nStarting Offer to Balance Validation\n\n')
    
    # Loop through every offer in the object
    for i in range(len(objDct['offers'])):
        # Get offer into local (used a lot)
        offerData = objDct['offers'][i]
        
        # Get offer name into local (used a lot)
        if 'ProductOfferExternalId' in objDct['offers'][i]: offerName = offerData['ProductOfferExternalId']
        else:
            print('ERROR: No external ID found for offer ' + str(i) + ': ' + str(offerData))
            sys.exit('Error')
        
        # Error if pricing data doesn't have this key
        if offerName not in priceData:
             print('ERROR:  object has offer ' + offerName + ', but it\'s not in the price data')
             sys.exit('Error')
        
        # Debug output
        #print 'Checking offer ' + offerName + ' with pricing data: '
        #pprint.pprint(offerData)
        
        # See if offer is valid at this time
        if ('EndTime' in offerData       and GENERIC.checkIfTime2GreaterTime1(nowTime, offerData['EndTime']))      or \
           ('CancelEndTime' in offerData and GENERIC.checkIfTime2GreaterTime1(nowTime, offerData['CancelEndTime']))  :
            # Offer expired - ignore
            print('NOTE: Offer ' + offerName + ' has expired.  Not including it in offer to balance verification.')
            continue
        
        # Make sure object has all the balances required by the offer
        for j in range(len(priceData[offerName])):
            foundFlag = False

            # Get components of this balance
            NOTclassId = priceData[offerName][j][0]
            balanceId  = priceData[offerName][j][1]
            
            # TEST: Force an error (for internal testing purposes)
            if options.forceError: balanceId = '1' + balanceId

            # Debug output
#           print 'Checking class/tmpl ID ' + str(NOTclassId) + '/' + str(balanceId)

            # Loop through every balance in the object
            for k in range(len(objDct['balances'])):
                    # Make sure the object has these balances
                    if objDct['balances'][k]['TemplateId'] == balanceId:
                            # Found the item
                            foundFlag = True
                    
                    # Get the balance name
                    balanceName = ' (' + objDct['balances'][k]['Name'] + ')'
                    
                    print('Offer "' + offerName + '" found balance template ' + str(balanceId) + balanceName)
                    # Nothing else to search for
                    break

            # If found flag is false, then we didn't finds what we're looking for
            if not foundFlag:
                # Oops...
                print('ERROR:  offer ' + str(offerName) + ' expects balance ID ' + str(balanceId))
                missingBalanceCount += 1
                missingBlanceIds += templateId + ' '

        ######## Second step:  make sure object wallet has all the offers it requires based on the balances in the wallet

    # Debug output
    print('\n\nStarting Balance to Offer Validation\n\n')
    
    # Loop through every balance in the object
    for i in range(len(objDct['balances'])):
        # Get balance data into local (used a lot)
        balanceData = objDct['balances'][i]
        
        # Start with not found
        foundFlag = False

        # Get the template ID
        templateId = balanceData['TemplateId']
        
        # Get the balance name
        if 'Name' in balanceData: balanceName = ' (' + balanceData['Name'] + ')'
        else:             balanceName = ' (No Name Specified)'
        
        # Debug output
        #print 'Checking balance ' + balanceName + ' with pricing data: '
        #pprint.pprint(balanceData)
        
        # If virtual, then don't validate
        if balanceData['IsVirtual'] == 'true':
                print('Not validating virtual balance template ' + templateId + balanceName)
                continue
        
        # Add lines if auditing
        if options.audit:
            print('*** Checking balance template ' + templateId + balanceName)
            auditIndent = '     '
        else:   auditIndent = ''
        
        # TEST: Force an error (for internal testing purposes)
        if options.forceError: templateId = '1' + templateId

        # Find the offer this should be in.
        # Loop through every offer in the wallet
        for j in range(len(objDct['offers'])):
            # Get offer into local (used a lot)
            offerData = objDct['offers'][j]
            
            # Get object offer name
            offerName = offerData['ProductOfferExternalId']
            
            # See if offer is valid at this time
            if ('EndTime'       in offerData and GENERIC.checkIfTime2GreaterTime1(nowTime, offerData['EndTime']))      or \
               ('CancelEndTime' in offerData and GENERIC.checkIfTime2GreaterTime1(nowTime, offerData['CancelEndTime']))  :
                # Offer expired - ignore
                print('NOTE: Offer ' + offerName + ' has expired.  Not including it in balance to offer verification.')
                continue
        
            # Look through each balance in this offer
            for k in range(len(priceData[offerName])):
                # Get components of this balance
                balanceId = priceData[offerName][k][1]
                
#               print 'Comparing offer ' + str(offerName) + ' balance ID = ' + str(balanceId) + ' looking for ID ' + str(templateId)

                # Check if object has this balance
                if templateId == balanceId:
                    if options.audit: print(auditIndent + 'Balance found in offer "' + offerName + '"')
                    else:             print(auditIndent + 'Balance template ' + str(balanceId) + balanceName + ' found in offer "' + offerName + '"')
                    foundFlag = True
                    
                    # Nothing more to do
                    break

            # If we found the item and not auditing, then nothing more to check
            if foundFlag and not options.audit: break

        # See if we didn't find the offer
        if not foundFlag:
            print('ERROR: no offer found that requires balance template ' + templateId)
            extraBlanceCount += 1
            extraBlanceIds += templateId + ' '

    # Debug output.
    if extraBlanceCount or missingBalanceCount: print('\n\nITEMS TO INVESTIGATE\n')
    
    # Check for errors.
    if extraBlanceCount    > 0: print('WARNING: found ' + str(extraBlanceCount)    + ' balances with no parent offer: ' + extraBlanceIds)
    if missingBalanceCount > 0: print('WARNING: found ' + str(missingBalanceCount) + ' balances missing from the wallet: ' + missingBlanceIds)

    print('\n\nCompleted Data Validation\n\n')
    
#================== Main function  ================================================
def main():
    print('hello')

if __name__ ==  '__main__':
    main()

