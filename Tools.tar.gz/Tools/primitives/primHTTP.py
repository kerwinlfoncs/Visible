#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Thu 2021-11-11T22:02:56
# @futurize --stage2 --no-diffs -n -w  : Thu 2021-11-11T22:02:55
#
# @futurize --stage1 --no-diffs -n -w  : Thu 2021-11-11T22:02:55

# Import system primitives
from __future__ import print_function
# from builtins import str
# from builtins import range
# from builtins import object
from future import standard_library
standard_library.install_aliases()
# from builtins import str
# from builtins import range
# from builtins import object
import sys, time, pprint
import http.client, requests
import xml.etree.ElementTree as ET
from primitives import primData as PRIMDATA
from primitives import primGeneric as GENERIC

# Get from /etc/hosts and from "always used" value
RestHost = GENERIC.runCmd('grep restgw /etc/hosts | cut -f1 -d" "')
RestPort = '8080'

# Open session ID (so we reuse the same session for queries)
requestSession = None

#===============================================================================
class mtxConnect(object):
  def __init__(self):
    self.httpConn = None
    self.RouteId = ""
    return
  def connect(self, hostname, hostport, timeout=120):
    self.httpConn = http.client.HTTPConnection(hostname, hostport, timeout)
    return

def setupHttpConnection(dctRcv, baseString='/matrixx/data/objects'):
    # Initialize objects and HTTP connection.  Wait for 60 seconds (default of none seems to occasionally timeout too fast)
    program = mtxConnect()
    program.connect(dctRcv['hostname'], dctRcv['hostport'], timeout=120)

    # Return connection value
    return program

#===============================================================================
def printDictionaryLevel(doc, level=0, listItem = 0):
#   if level == 0: print 'In printDictionaryLevel'
    
    # Build print indentation
    indent = " " * level * 4
    
    # Input is a dictionary, so go through every key
#   print 'printDictionaryLevel: input doc = ' + str(doc)
    for key in doc:
#       print 'Looking at key: ' + str(key)
        # Iterate if a dictionary
        if type(doc[key]) == type(dict()):
            print(indent + key + '(dict):')
            printDictionaryLevel(doc[key], level+1)
        elif type(doc[key]) == type(list()):
            # Can separate lists to print better
            # Process each list item
            print(indent + key + '(list):')
            for i in range(len(doc[key])): 
                # List item may itself be a dictionary
                if type(doc[key][i]) == type(dict()):
                    # Print heading
                    print(indent + '    ' + key + '(' + str(i) + ' dict):')
                    
                    # Iterate, but go +2 since we indented the parent already
                    printDictionaryLevel(doc[key][i], level+2)
                else: print(indent + '    ' + key + ' index ' + str(i) + ': ' + str(doc[key][i]))
        else:   print(indent + key + ' = ' + str(doc[key]))
        
        # *** Skip the rest of this loop ***
        continue
                
        # Skip #text
        if key == '#text': continue
            
        print('doc[' + key + '] type = ' + str(type(doc[key])))
        
        # Loop if a dictionary
        if 'OrderedDict' in str(type(doc[key])): printDictionaryLevel(doc[key], level+1)
        else: print('level: = ' + str(level) + ', key ' + key + ' = ' + str(doc[key]))
        
#===============================================================================
def getObjectQuery(object, queryValue, queryType, conn):
    # Define starting portion of URL
    url = '/rsgateway/data/v3/' + object.lower() + '/'
    
    # Build middle of the url (type dependent)
    if queryType: url += queryType + '+'
    '''
    if   queryType == 'ExternalId': url += 'query/ExternalId/' 
    elif queryType == 'PhoneNumber': url += 'query/imsi/'
    elif queryType == 'AccessNumber': url += 'query/AccessNumber/'
    '''
    
    # Always add the actual value at the end
    url += queryValue
    
    # Get the data
    #print 'url = ' + url
    (result,x) = getAndVerifyHttpRequest(conn, url, exitOnFailure = False)
    
    if not result:
        print('ERROR: failed in query of ' + object + ' ' + queryValue + ' (' + queryType + ')')
        return None
    
    #print 'ET data: '
    #ET.dump(x)
    
    # Return the ET structure
    return x
#===============================================================================
def getAndVerifyHttpRequest(program, _url, exitOnFailure = True, operation='GET', output='ET'):
    global requestSession
    
    # Set global
    if not requestSession: requestSession = requests.Session()
    
    # Assume success
    result = True
    
    # Set retry count (from days gone by when a read would randomly fail...)
    retryMax = 2
    
    # Add HTTP prefix if not present
    if not _url.count('http'):
        # PRIMDATA has the actual string to use - detect http versus https
        if PRIMDATA.httpString == 'http': _url = 'http://'  + RestHost + ':8080' + _url
        else:                             _url = 'https://' + RestHost + ':8443' + _url
    
    # Check if URL matches httpString. Warn if not
    if not _url.count(PRIMDATA.httpString): print('Warning: url doesn\'t match PRIMDATA.httpString.  URL: ' + _url + ', PRIMDATA.httpString: ' + PRIMDATA.httpString)
    
    # Translate spaces in url to +
    #print('_url: ' + _url)
    url = _url.replace(' ', '+')
    #print('url: ' + url)
    
    params = {}
    # Add TrafficRouteData to URI if needed
    if 'rsgateway' in url and program and program.RouteId != '':
        params['TrafficRouteData'] = 'RTID' + str(program.RouteId)
    
    # ALWAYS setup for no default filters
    params["applyDefaultFilter"] = "false"
    
    # We'll try the query several times
    retryCount = 0

    # Need something here in case we get non-XML response
    x = None

    # Limit retries
    #print 'issuing GET for url: ' + url
    #if PRIMDATA.simpleAuthUserName: print 'Username/password: ' + PRIMDATA.simpleAuthUserName + '/' + PRIMDATA.simpleAuthPassword
    while retryCount < retryMax:
                # Bump retry counter
                retryCount += 1

                # Issue the command and get the response
                '''
                conn.request("GET", url)
                response=conn.getresponse()
                responseData = response.read()
                print('URL: ' + url)
                pprint.pprint(params)
                '''
                #print PRIMDATA.simpleAuthUserName, PRIMDATA.simpleAuthPassword
                if   operation.lower() == 'get':
                    if PRIMDATA.simpleAuthUserName: r = requestSession.get(url, params=params, auth=(PRIMDATA.simpleAuthUserName, PRIMDATA.simpleAuthPassword))
                    else:               r = requestSession.get(url, params=params)
                elif operation.lower() == 'put':
                    if PRIMDATA.simpleAuthUserName: r = requestSession.put(url, params=params, auth=(PRIMDATA.simpleAuthUserName, PRIMDATA.simpleAuthPassword))
                    else:                           r = requestSession.get(url, params=params)
                else:
                    if PRIMDATA.simpleAuthUserName: r = requestSession.post(url, params=params, auth=(PRIMDATA.simpleAuthUserName, PRIMDATA.simpleAuthPassword))
                    else:               r = requestSession.post(url, params=params)
                responseData = r.text.strip()
        
                #print responseData

                # If raw data desired, then exit here
                if output.lower() != 'et': return (True, responseData)
        
        #       # For fun: translate to a dictionary
        #       doc = xmltodict.parse(responseData)
        #       print 'XML to Dictionary: for type' + str(type(doc)) + ', dictionary type is ' + str(type(dict()))
        #       level = 0
        #       if 'OrderedDict' in str(type(doc)): printDictionaryLevel(doc, level)
        
                # Seeing that timeouts don't always return XML data...
                try:
                        x=ET.fromstring(responseData)
                except:
                        print('ERROR:  URL "' + url + '" returned data is not in XML format')
                        print(responseData)
                        kef
                        continue

                # Make sure we passed.
                # Were seeing that not all responses returned a Result value...
                try:
                        # Exit loop if successful
                        if x.find('Result').text.strip() == '0': break
                except:
                        print('WARNING:  received a response back that didn\'t contain a Result')
                        print('URL: ' + url)
                        print(str(responseData))
                        continue


                # If not at limit, then continue
                if retryCount < retryMax:
                    # Sleep for a second - this usually means system is overloaded...
                    time.sleep(1)
                    continue

                # Report each error
                result = False
                print('ERROR: Failed ' + str(retryMax) + ' query commands to url: ' + url)
                print('Last Result Code = ' + x.find('Result').text.strip())
                try:
                        print('Last Result Text = ' + x.find('ResultText').text.strip())
                except:
                        print('No result text returned')
        
    # For now, exit on failure
    if exitOnFailure and not result: sys.exit('Exiting due to errors')
    
    #print 'ET data: '
    #ET.dump(x)
    
    # Return data
    return (result, x)

#================== Main function  ================================================
def main():
    # 
    print('Hello')

if __name__ ==  '__main__':
    main()

