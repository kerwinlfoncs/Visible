#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Thu 2021-11-11T22:02:57
# @futurize --stage2 --no-diffs -n -w  : Thu 2021-11-11T22:02:57
#
# @futurize --stage1 --no-diffs -n -w  : Thu 2021-11-11T22:02:56

# Import system primitives
from __future__ import print_function
# from builtins import str
# from builtins import range
# from builtins import str
# from builtins import range
import xml.etree.ElementTree as ET
import sys, copy, pprint

#================== Set of XML Processing functions  ================================================
# *** NOTE: really should return lists all the time.  Need to check why I sometimes return a single entry...
def walkXmlData(q, retDct = None, addListEntry = False):
    if not retDct: retDct = {}
#   print 'retDct at start: ' + str(retDct)
    
    # Clear local dictionary
    lcl = {}
    
    # Get name and value of this element
    name = q.tag
    value = q.text
        
    # Get attributes
    attrib = list(q.items())
        
    # Store what we found
    if len(attrib):
        lcl['attrib'] = copy.deepcopy(attrib)
#       print 'Found element ' + name + ' with attributes ' + str(lcl['attrib'])
        
    # Sometimes get NONE here and other times a empty string.  Can't strip NONE, so check first.
    if value: value = value.strip()
        
    # If the item has a value, then it doesn't have children.  [Is that true??]
    if value:
        # Need to account for unicode here.  Since I use print extensively and that requires ASCII, encode the value to ASCII.
        # Hopefully we won't need to use the unicode sring (e.g. it's not in the external ID).
        #lcl['value'] = value.encode('utf-8')
        lcl['value'] = value
        #print('Element ' + name + ' = ' +  lcl['value'])
    
    # If name not in the local dictionary, then add to it as a standalone item
    if name not in retDct:
#       print 'Adding dictionary entry ' + name
        retDct[name] = copy.deepcopy(lcl)
#       print 'retDct at end of Adding dictionary entry: ' + str(retDct)
    else:
        # If not a list, then make it one
        if type(retDct[name]) is not type(list()):
#           print 'Found name ' + name + ' in the dictionary. Type is ' + str(type(retDct[name]))
            retDctCopy = copy.deepcopy(retDct[name])
            retDct[name] = []
            retDct[name].append((copy.deepcopy(retDctCopy)))
#           print 'retDct at end of converting dictionary entry to list: ' + str(retDct)
        
        # Append latest entry here.
        # NOTE: this is really needed to fetch arrays.  Unfortunately 
        # other code was writtena long time ago and doesn't expect this.  
        # This will be a pain to fix properly...
#       print 'Appending to dictionary list ' + name
        if addListEntry: retDct[name].append((copy.deepcopy(lcl)))
#       print 'retDct at end of Appending to list: ' + str(retDct)
    
    # No need to dive deeper if a value is assigned
    if value:
#       print 'Returning single element ' + name
        return retDct 
    
    # If here, then we need to walk more
#   print 'Started walking down elem ' + name
    lclDct = copy.deepcopy(lcl)
    for elem in q: lclDct = walkXmlData(elem, lclDct, addListEntry=addListEntry)
    
    # If already a list, then need to create new list item
    if type(retDct[name]) is list:  retDct[name].append((lclDct))
    else:               retDct[name] = lclDct
#   print 'Ended walking down group ' + name
    
#   print 'retDct at end: ' + str(retDct)
    return  retDct
    
#===============================================================================
# This function reads an XML file and runs through the elementTree library
def parseXmlResponse(fileName=None, fileData = None):
    # Read from file if passed in
    if fileName:
        # Open the file for reading
        f = open(fileName, "r")

        # Get the data
        fileData = f.read()
    
        # Close the file
        f.close()
    
    # Read in XML data
    try:
                q=ET.fromstring(fileData)
    except:
        if fileName:    print('ERROR:  file ' +  fileName + ' is not in XML format')
        else:           print('ERROR: input data not in XML format')
        print(fileData)
        sys.exit('Exiting due to errors')

    return q

#===============================================================================
# Get lifecycle fields
def getObjectLifecycleFields(q):
    dctRcv = {}
    retData = {}
    
    # Get base level fields
    xmlName = './StatusInfoArray/MtxPricingStatusInfo'
    for child in q.findall(xmlName):
        dctRcv = getObjectBaseFields(child, dctRcv)
     
        # Put into return structure.  Always use lower case.
        retData[dctRcv['Description'].lower()] = dctRcv['Status']
    
    #print 'getObjectLifecycleFields: ' + str(retData)  
    return retData

#===============================================================================
# Get all object fields
def getAllObjectFields(q, dctRcv = None):
    if dctRcv == None: dctRcv = {}
    print('\n\nEntered getAllObjectFields with q:')
    ET.dump(q)
    print('\n\n')
    # Get base level fields
    for elem in q: 
        try:
            # Force error if not a field
            if len(q.find(elem.tag).text.strip()): dctRcv[elem.tag] = q.find(elem.tag).text.strip()
            else: kef
        except:
            print('Recursively calling getAllObjectFields with element ' + str(elem.tag))
            # Setup dictiovary entry
            dctRcv[elem.tag] = {}
            
            # Recursive call
            getAllObjectFields(q.find('./'+elem.tag), dctRcv[elem.tag])
    
    print('getObjectBaseFields: ')
    pprint.pprint(dctRcv)   
    
    return dctRcv

#===============================================================================
# Get object base fields
def getObjectBaseFields(q, dctRcv):
    # Get base level fields
    for elem in q: 
        if q.find(elem.tag).text: dctRcv[elem.tag] = q.find(elem.tag).text.strip()
    #print 'getObjectBaseFields: ' + str(dctRcv)    
    return dctRcv

#===============================================================================
# Get object custom fields
def getObjectCustomFields(q, dctRcv={}, customName='None', addlStructures=None, add=False, addExtension=True):
#   ET.dump(q)
    # May have several possible custom names
    customNameList = customName.split(',')
    for item in customNameList:
        # "item" could be a list themselves.  Config file identifies this.
        items = item.split('/')
#       print 'items: ' + str(items)
        
        # Get XML name
        name = items[0]
        
        # Set custom container field name
        xmlName = './Attr/' + name
        if addExtension: xmlName += 'Extension'
#       print 'Searching for XML tag: ' + xmlName

        # Get Subscriber custom fields
#       print 'In getObjectCustomFields, addlStructures = ' + str(addlStructures)
        #ET.dump(q)
        #print 'Checking for xmlName ' + xmlName
        for child in q.findall(xmlName):
#           ET.dump(child)
            dctRcv = getObjectBaseFields(child, dctRcv)
#           print 'dctRcv = ' + str(dctRcv)
            
            # Values of None mean we need to go down a level
            for key in list(dctRcv.keys()):
                if dctRcv[key] == '':
                    # Add to list of stuff to check
#                   print 'Adding  key: ' + key
                    items.append(key)
                    
                    # Remove the entry (as it's not valid at this time)
                    del dctRcv[key]
            
            # If there's additional info, then need to process it
            if addlStructures and len(addlStructures): dctRcv = getAdditionalData(child, addlStructures, dctRcv)
            
            # If the item tells us it's type, then we need to process that additional data.
            # For now, assume it's always a list, or multiple lists.
            for x in range(1,len(items)):
                    itemName = items[x]
                    dctRcv[itemName] = []
                    for value in q.findall(xmlName+'/' + itemName + '/value'): dctRcv[itemName].append(value.text)

    return dctRcv

#===============================================================================
def getAdditionalData(q, addlStructures, dctRcv={}):
    # May have multiple sub-structures
    for i in range(len(addlStructures)):
        #pprint.pprint(addlStructures[i])
        
        # First parameter is the name of the dictionary to use
        dctName = addlStructures[i][0]
            
        # Second parameter is the XML string relative to the child
        xmlSubName = addlStructures[i][1]
        #print 'Will be looking for XML sub structure: ' + xmlSubName
                
        # Third parameter is the type of structure we have
        strType = addlStructures[i][2]
        
        # Skip children (addressed below)
        if len(addlStructures[i]) > 3 and addlStructures[i][3].lower().startswith('child'): continue
        
        # Hack: see if a child is specified in the next item.  If so, then create dummy entry.
        childStruct = []
        # See if more to process
        if len(addlStructures) > i+1:
            # Go through remaining entries
            for j in range(i+1, len(addlStructures)):
                # Stop on first non-child
                if len(addlStructures[j]) <= 3: break
                
                # If a child then add to array
                if addlStructures[j][3].lower() == 'child':
                    #print 'Adding child element:'
                    #pprint.pprint(addlStructures[j])
                    childStruct.append((addlStructures[j][0], addlStructures[j][1], addlStructures[j][2]))
                # If a child of the child, then add child option
                elif addlStructures[j][3].lower() == 'child2':
                    #print 'Adding child element:'
                    #pprint.pprint(addlStructures[j])
                    childStruct.append((addlStructures[j][0], addlStructures[j][1], addlStructures[j][2], 'child'))
        
        # Do what the type says to do
        if strType.lower() == 'array': 
            #print 'Checking for additional data in XML structure: ' + xmlSubName
            dctRcv[dctName] = []
            dctRcv[dctName].extend(getArrayData(xmlSubName, None, q, None, childStruct))
        elif strType.lower() == 'struct':
            dctRcv[dctName] = {}
            dctRcv[dctName] = getObjectStructureFields(q, dctRcv[dctName], xmlSubName, childStruct)
        elif strType.lower() == 'value':
            dctRcv[dctName] = []
            for children in q.findall(xmlSubName): dctRcv[dctName].append(children.text)
            
    
    return dctRcv

#===============================================================================
# Get object structure fields
def getObjectStructureFields(q, dctRcv={}, xmlName=None, addlStructures=None):
    # Get to the start of the structure
    for child in q.findall(xmlName): 
        #print 'Found a child of type ' + xmlName
        # Get the base fields
        dctRcv = getObjectBaseFields(child, dctRcv)
        
        # If there's additional info, then need to process it
        if addlStructures and len(addlStructures): dctRcv = getAdditionalData(child, addlStructures, dctRcv)
    
    return dctRcv

#===============================================================================
# Get object base + custom
def getArrayData(xmlDctName, customName, q, configDct, addlStructures=None):
    lclArray = []
    for child in q.findall(xmlDctName):
        # Create array entry for this child
        entry = {}

        # Get base level fields
        entry = getObjectBaseFields(child, entry)
        
        # Get optional custom fields for this object
        if customName and configDct and customName in configDct: entry = getObjectCustomFields(child, entry, configDct[customName])
        
        # If there's additional info, then need to process it
        if addlStructures and len(addlStructures):
            #ET.dump(child)
            entry = getAdditionalData(child, addlStructures, entry)
    
        # Add to array
        lclArray.append(entry)
    
    return lclArray

#================== Main function  ================================================
def main():
    print('hello')

if __name__ ==  '__main__':
    main()

