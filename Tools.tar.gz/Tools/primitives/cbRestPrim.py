#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Thu 2021-11-11T22:02:45
# @futurize --stage2 --no-diffs -n -w  : Thu 2021-11-11T22:02:45
#
# @futurize --stage1 --no-diffs -n -w  : Thu 2021-11-11T22:02:44
from __future__ import print_function
# from builtins import str
# from builtins import range
from future import standard_library
standard_library.install_aliases()
# from builtins import str
# from builtins import range
import sys, os, copy, pprint, random
from subprocess import call
try:
    import configparser
except:
    from six.moves import configparser

from primitives import primXML as XML
from primitives import primData as DATA
from primitives import primHTTP  as HTTP
from primitives import primGeneric  as GENERIC
import xml.etree.ElementTree as ET

# Get unique name for cookie file
cookieFile="cookie" + str(random.randint(1,1000000)) + "File"

# Clear global data
retParameterDct = {}
retParameterListDct = {}
retCIData = {}
retOfferData = {}
retBundleData = {}
retOfferDct = {}
retPriceDct = {}
retMatrixDct = {}
retPriorityGeneratorDct = {}
retPriorityGeneratorTableDct = {}
retFilterDct = {}
retDecisionTableDct = {}
retNormalizerDct = {}
retTaxSelectorDct = {}
retTaxSelectorTableDct = {}
retBalanceStateDct = {}
retBalanceStateTableDct = {}
retPolicyDct = {}
retPolicyTableDct = {}
retAttributeListDct = {}
retAttributeDct = {}
retPolicyProfileDct = {}
retRolloverDct = {}
retRolloverTableDct = {}
retRepositoryDct = {}
retRepositoryTableDct = {}
retRepositoryProfileDct = {}
retMatrixNormalizersDct = {}
retPriceComponentDct = {}
retLastUnitDct = {}
retLastUnitTableDct = {}
retLastUnitProfileDct = {}
retSubInfoDct = {}
retSubInfoActionDct = {}
retSubInfoTableDct = {}
retSubInfoProfileDct = {}
retSubInfoDataModifyDct = {}
retGlActSelectorDct = {}
retGlActSelectorTableDct = {}
retGlTxnSelectorDct = {}
retGlTxnSelectorTableDct = {}
retGlInfoDct = {}
retGlInfoTableDct = {}
retGlInfoProfileDct = {}
retGlTxnProfileData = {}
retUsageDct = {}
retUsageTableDct = {}
retAnnouncementTableDct = {}
retAnnouncementProfileDct = {}
retAnnouncementGeneratorDct = {}
retAnnouncementServerDct = {}
retAnnouncementDetailsDct = {}
retAggregationSelectorDct = {}
retAggregationSelectorTableDct = {}
retUsageTriggerDct = {}
retUsageTriggerTableDct = {}
retUsageTriggerProfileDct = {}
retNormalizerListDct = {}
retBalanceTagDct = {}
retBalanceClassDct = {}

# Build struct so functions can easily call CB to query/process data
_config = {}
_config['CB'] = {}
_config['CB']['domain']   = os.environ['pricingdomain']
_config['CB']['hostname'] = os.environ['CatalogBuilderHost']
_config['CB']['hostport'] = os.environ['CatalogBuilderPort']
_config['CB']['userName'] = os.environ['CatalogUserName']
_config['CB']['password'] = os.environ['CatalogPassword']

# Flag indicating if test is logged in already
loginFlag = False

#===============================================================================
# Run a REST command to the CB (nonj-login)
def runCbRestCmd(config, url, cmd='notLogin', operation='GET', payload=None):
    global cookieFile
    
    # If login command, then use -c option; else use -b
    if cmd.lower() == 'login':
            # Set proper option AND get a new cookie file name.  Needed to support shared work spaces
            option = '-c'
            cookieFile="cookie" + str(random.randint(1,1000000)) + "File"
    else:   option = '-b'
    
    # If payload, then need additional text
    if payload:
        # Need to write the payload to a file
        payloadFile = '_payload'
        f = open(payloadFile, 'w')
        f.write(payload)
        f.close()
    
        # Now set string
        payloadString = ' --data-urlencode xmldata@' + payloadFile
        #payloadString = ' -d @' + payloadFile
    else: payloadString = ''
    
    # Build command
    basePath = '/matrixx/data/objects/'
    curlCmd='curl -s ' + option + ' ' + cookieFile + ' ' + payloadString + DATA.curlAdditionalParams + ' -X ' + operation + ' http://' + config['CB']['hostname'] + ':' + config['CB']['hostport'] + basePath + url
    
    # Run the command
    #print('Executing command: ' + curlCmd)
    stdOut = GENERIC.runCmd(curlCmd)
    #print('Response: ' + stdOut)
    
    # Normalizer GET commands do not return a result.  Not sure why...
    if operation.lower() == 'get':
      # Can really only check that we got something back
      if not len(stdOut):
        print('Hmmmm.  Nothing received in response to the GET operation.')
        print('Executed command: ' + curlCmd)
        if payload: print('Payload: ' + payload)
        #sys.exit('Exiting due to errors')
    
    # Remove the payload file if created
    if payload:
        bashCmd = 'rm -f ' + payloadFile
        GENERIC.runCmd(bashCmd)
    
    # Return from here if not a login
    if cmd.lower() != 'login': return stdOut
    
    # Walk the returned data to check for success/fail 
    # Converty to dictionary
    try:
        q = ET.fromstring(stdOut)
    except: 
        print('Hmmmm.  Non-XML returned from CB login operation.  This is an error.')
        print('Command executed: ' + curlCmd)
        print('First 5 lines of response:\n' + "\n".join(stdOut.split("\n")[0:5]))
        sys.exit('Exiting due to errors')
    
    # Let's see what we got...
    retDct = XML.walkXmlData(q)
    #print('CB response dictionary: ' + str(retDct))
        
    # Main response name will change, but always only one
    for key in list(retDct.keys()):
      # Was result returned?
      if 'Result' not in retDct[key]:
        print('Hmmmm.  No result received from CB operation.  This is an error.')
        print('Response: ' + str(retDct))
        sys.exit('Exiting due to errors')
        
    # Was it successful?
    if retDct[key]['Result']['value'] != '0':
        print('Hmmmm.  Result indicates an error (' + retDct[key]['Result']['value'] + ' - ' + retDct[key]['ResultText']['value'] + ')')
        print('Response: ' + str(retDct))
        sys.exit('Exiting due to errors')
    
    # Return standard out
    return stdOut
    
#===============================================================================
def cbPrintNormalizer(dctRcv, indent=''):
    # Only print at top level
    if indent == '': print('\n*** Printing Dictionary ***\n')
    
    # Loop through each dictionary level
    for key in list(dctRcv.keys()):
        # If a dictionary, then iterate
        if type(dctRcv[key]) == type(dict()): 
            # Print heading
            print(indent + 'Key: ' + key + ' (dict)')
        
            cbPrintNormalizer(dctRcv[key], '    ' + indent)
        elif type(dctRcv[key]) == type(list()):
            # Print heading
            print(indent + 'Key: ' + key + ' (list)')
        
            for idx,item in enumerate(dctRcv[key]): print(indent + 'Item ' + str(idx) + ': ' + str(item))
        else:   print(indent + str(dctRcv[key]) + '\n')
    
    # Only print at top level
    if indent == '': print('\n')
    
    return
    
#===============================================================================
# This function will logout from the CB server.
# OK - just clean up so one can't use this server to access the data anymore.
def cbLogout(config=None):
    global loginFlag
    
    # Remove cookies file
    GENERIC.runCmd('rm ' + cookieFile + ' 2&>/dev/null')
    
    # Clear login flag
    loginFlag = False
    
#===============================================================================
# This function will login to the CB server
def cbLogin(config):
    global loginFlag
    
    # If already logged in, then do nothing
    if loginFlag: return
    
    # Remove old tool files
    GENERIC.runCmd('rm ' + cookieFile + ' 2&>/dev/null')
    
    # Shared workspaces introduce complexity in the domain name.  Want the name between colons (if they exist)
    domain = config['CB']['domain']
    if domain.count(':') == 2:
         # This is a shared workspace
         sharedDomain = domain
         
         # Domain is the second part
         domain = domain.split(':')[1]
    else: sharedDomain = None
    
    # Login to primary domain
    url = 'login?username='+ config['CB']['userName'] + '\&password=' + config['CB']['password'] + '\&domain=' + domain
    runCbRestCmd(config, url, cmd='login')
    
    # If a shared workspace, login to that domain
    if sharedDomain:
        url = 'login?username='+ config['CB']['userName'] + '\&password=' + config['CB']['password'] + '\&domain=' + sharedDomain
        runCbRestCmd(config, url, cmd='login')
    
    # Set login flag
    loginFlag = True
    
#===============================================================================
# This function returns already-retrieved offer data
def walkOfferData(idx, config):
    global retOfferDct
    
    listName = 'OfferList'
    objectName = 'Offer'
    
    # Debug all offers
    #pprint.pprint(retOfferDct[listName]['id'])
    
    # See if this PC has been read and read if not
    if idx not in retOfferDct[listName]['id']:
#       print 'Reading offer ' + str(idx)
        getAllOfferData(config, processAll=idx)
    
    # Print the offer data
#   print 'Offer ' + str(idx) + ' data: '
#   pprint.pprint(retOfferDct[listName]['id'][idx])
    
    # Offer may not have any PCs
    if 'priceComponents' not in retOfferDct[listName]['id'][idx]['object']['offer']:
        retOfferDct[listName]['id'][idx]['object']['offer']['priceComponents'] = {}
    if 'priceComponent' not in retOfferDct[listName]['id'][idx]['object']['offer']['priceComponents']:
        retOfferDct[listName]['id'][idx]['object']['offer']['priceComponents']['priceComponent'] = []
        
#   print 'Offer PCs: ' + str(retOfferDct[listName]['id'][idx]['object']['offer']['priceComponents']['priceComponent'])
    if type(retOfferDct[listName]['id'][idx]['object']['offer']['priceComponents']['priceComponent']) is not list:
        retOfferDct[listName]['id'][idx]['object']['offer']['priceComponents']['priceComponent'] = [retOfferDct[listName]['id'][idx]['object']['offer']['priceComponents']['priceComponent']]
    
    # Walk the price components
    retData = []
    for pc in retOfferDct[listName]['id'][idx]['object']['offer']['priceComponents']['priceComponent']:
#       print 'walkOfferData: price component:'
#       pprint.pprint(pc)
        
        # Get component number
        for element in pc['attrib']:
#           print 'Processing attribute: ' + str(element)
            (name, value) = element
#           print name + ' = ' + value
            retData.append(value)
            
    # Report the data
    retObjData = viewOfferListData(idx, config)
    print('\n*************************************************************************************************************')
    print('Offer ' + str(idx) + ' (' + retObjData['NAME'] + ')'+ ' PCs: ' + str(retData))
    
    # Walk price components
    for i in range(len(retData)): walkPcData(retData[i], config)
    
#===============================================================================
# This function returns already-retrieved offer data
def walkPcData(idx, config):
    _dict = {}
    retData = viewPriceComponentRateTable(-1, config, idx)
    retObjData = viewPriceListData(idx, config)
#   print '\n- - - - - - - - - - - - - - - - - - - - - - - - -'
#   print 'PC ' + str(idx) + ' (' + retObjData['NAME'] + ')' + ', Rate tables: ' + str(retData)
#   pprint.pprint(retObjData)
    
    # Print PC type
    for entry in retPriceDct['PriceComponentList']['id'][idx]['object']['price']['attrib']:
        (name,value) = entry
        _dict[name]  = str(value).replace('"','\'')
    
    print('Application: ' + _dict['application'] + '-' + _dict['type'])
    
    # Walk the rate tables
    for i in range(len(retData)): walkMatrixData(retData[i], config)
    
#===============================================================================
# This function returns already-retrieved offer data
def walkMatrixData(idx, config):
    retData =  viewMatrixNormalizers(idx, config)
    retObjData = viewMatrixListData(idx, config)
    
    # Print all but the leading comma
    print('\nRate Table ' + str(idx) + ' (' + retObjData['NAME']+ ')')
    
    # Debug output
#   pprint.pprint(retMatrixDct['MatrixList']['id'][idx]['object']['RateTable'])
    
    # Get normalizer names
    outStr = []
    normString = 'Normalizers: '
    if retData:
        for i in range(len(retData)):
            retAddlObjData = viewNormalizerListData(retData[i], config, None)
            outStr.append((normString, retData[i], retAddlObjData['NAME']))
            
            # Only want the heading the first line
            normString = ''
    else: outStr.append((normString, '0','None'))
    
    # Output format for normalizers
    format = "%13s %4d (%s)\n"

    # Output normalizer names
    for entry in outStr:
        # Get elements
        (field1,field2,field3) = entry
        sys.stdout.write(format % (field1,int(field2),field3))
    
    # Get scale basis
    scaleBasis = scale_field = None
    for entry in retMatrixDct['MatrixList']['id'][idx]['object']['RateTable']['attrib']:
        # Separate entry data
        name,value = entry
        
        # Assign locals
        if   name == 'scaleBasis':  scaleBasis = value
        elif name == 'scale_field': scale_field = value
        
    # Sanity check that we got required data
    if not scaleBasis:
        print('ERROR: Rate Table ' + str(idx) + ' attributes did not specify a scale basis')
        pprint.pprint(retMatrixDct['MatrixList']['id'][idx]['object']['RateTable'])
        sys.exit('Exiting due to errors')
    
    # Output data
    outStr = 'Scale Basis: ' + scaleBasis
    if scale_field: outStr += ', field = ' + scale_field
    print(outStr)
    
    # Force data to be in a list
    if type(retMatrixDct['MatrixList']['id'][idx]['object']['RateTable']['rows']['row']) is not list:
        retMatrixDct['MatrixList']['id'][idx]['object']['RateTable']['rows']['row'] = [retMatrixDct['MatrixList']['id'][idx]['object']['RateTable']['rows']['row']]
    
#   pprint.pprint(retMatrixDct['MatrixList']['id'][idx]['object']['RateTable'])
    
    # Get the impacted balance
    balanceClass = balanceId = None
    for entry in retMatrixDct['MatrixList']['id'][idx]['object']['RateTable']['balance']['attrib']:
        # Separate entry data
        name,value = entry
        
        # Assign to locals
        if   name == 'class':       balanceClass = value
        elif name == 'id':      balanceId = value
        elif name == 'balance_units':   balance_units = value
        
    # Sanity check that we got required data
    if not balanceClass and not balanceId:
        print('ERROR: Rate Table ' + str(idx) + ' did not specify a balance class or balance id')
        pprint.pprint(retMatrixDct['MatrixList']['id'][idx]['object']['RateTable'])
        sys.exit('Exiting due to errors')
    
    # Create/output data
    outStr = 'Balance Class: ' + str(balanceClass)
    if balanceId:           outStr += ', balance ID: ' + str(balanceId)
    if balance_units != 'none': outStr += ', ' + balance_units
    print(outStr)
    
    # Output format for formula
    format = "%-50s %s\n"

    # Now print formula
    for (i,entry) in enumerate(retMatrixDct['MatrixList']['id'][idx]['object']['RateTable']['rows']['row']):
        formulaString = normString = ''
        # Get entries (formula and normalzier data)
        for key in entry:
            if key == 'formula':
                # Build locals with attribute names and values
                for attrib in entry[key]['attrib']:
                    (name, value) = attrib
                    
                    # Set locals
                    if   name == 'units':       units = value
                    elif name == 'balanceClass':    balanceClass = value
                    elif name == 'balance_units':   balance_units = value
                    elif name == 'slope':       slope = value
                    elif name == 'multiple':    multiple = value
                    elif name == 'intercept':   intercept = value
                    elif name == 'beat':        beat = value
                    
                # Print the formula
                strStart = 'Formula: y = '
                outStr = ''
                
                # Change units from none to $$ if balance class is < 1000
                if units == 'none' or not units:
                    if   int(balanceClass) < 1000:  units = '$$'
                    elif balance_units:     units = balance_units
                    else:               units = ''
                
                # Add slope data if non-zero
                if float(slope) != 0: outStr += slope.rstrip('0').rstrip('.') + '/' + multiple.rstrip('0').rstrip('.') + ' ' + units + ' + '
                
                # Add intercept data if non-zero, else remove trailing plus sign if slope defined.
                if   float(intercept) != 0: outStr += intercept.rstrip('0').rstrip('.')
                elif float(slope)     != 0: outStr = outStr[:-2]
                
                # If nothing added, then set to 0
                if not outStr: outStr = '0'
                
                # Add the beat if defined
                try:
                    # Remove word "message if present (not helpful)
                    if beat.count('message'): beat = beat[:-len('message')]
                    outStr += ' beat = ' + beat + ' '
                except:
                    kef = 1
                
                # Output data
                formulaString = strStart + outStr
                
            elif key == 'skip': formulaString = 'Formula: skip'
            
            elif key == 'error':
                # Get entry
                entry = entry[key]['attrib'][0]
                (name, value) = entry
                formulaString = 'Formula: deny with code ' + value
            
            elif key == 'normalizer_value':
                # Ensure it's a list
                if type(entry[key]) is not list: entry[key] = [entry[key]]
                
                # Loop through array
                normString = ''
                for normIndex in range(len(entry[key])):
                    # Get name/value pairs
                    for attrib in entry[key][normIndex]['attrib']:
                        (name, value) = attrib
                        
                        # Set locals
                        if   name == 'value_index': value_index = str(value).replace('"','\'')
                        
                    # Now get the normalzier human readable data
                    retData = viewNormalizerListData(id, config, normValue=value_index)
                    normString += '  [' + retData['NAME'] + ':' + retData['normValueName'] + ']'
            
            else: fullOutput += 'Hmmmm.  Processing unknown key "' + key + '", value : ' + str(entry[key]) 
        
        # If no formula then it's a skip
        if not formulaString: formulaString = 'Formula = skip'
        
        # Output data for this line
        sys.stdout.write(format % (formulaString, normString[2:]))
#       outStr = formulaString
#       if normString: outStr += normString
#       print outStr
        
    #print 'Rate table data:'
    #HTTP.printDictionaryLevel(retMatrixDct['MatrixList']['id'][idx]['object']['RateTable']['rows'])
    
#===============================================================================
# This function returns already-retrieved offer data
def viewOfferListData(idx, config):
    global retOfferDct
    
    listName = 'OfferList'
    objectName = 'Offer'
    
    # See if this PC has been read and read if not
    if idx not in retOfferDct[listName]['id']: getAllOfferData(config, processAll=idx)
    
    # Get the already-retrieved data
    retDct = viewObjectListData(idx, config, retOfferDct, listName, objectName)
    
    return retDct

#===============================================================================
# This function returns already-retrieved price component data
def viewPriceComponentRateTable(idx, config, priceComponentIdx):
    global retPriceDct
    global retPriceComponentDct
    
    # If data already read, then return it
    if priceComponentIdx in retPriceComponentDct and int(idx) != -1:
        # I am always wary of returning global data for fear it'll be corrupted...
        retData = copy.deepcopy(retPriceComponentDct[priceComponentIdx])
        #print sys._getframe().f_code.co_name + ' PC index ' + str(priceComponentIdx) + ', rate table index ' + str(idx) + ', retData = ' + str(retData)
        
        # I always have to do this.  Something is getting messed up along the way...
        if int(idx) >= len(retData): idx = 0
        
        # Return data
        return retData[int(idx)]
    
    retData = []
    listName = 'PriceComponentList'
    objectName = 'PriceComponent'
    
    # See if this object has been read and read if not
    if priceComponentIdx not in retPriceDct[listName]['id']: getAllPriceData(config, processAll=priceComponentIdx)
    
    # Get item
    if type(retPriceDct[listName]['id']) is not list:
        item = retPriceDct[listName]['id']
    else:
        link = retPriceDct[listName]['id'][priceComponentIdx]['link']
        item = retPriceDct[listName][link]
#        print 'PC item list = ' + str(item)
    
    # Get to rate tables array
    rateTables = item[priceComponentIdx]['object']['price']['rateTables']['rateTable']
    if type(rateTables) is not list: rateTables = [rateTables]
    index = 0
    for rateTable in rateTables:
        if type(rateTable) is not list: rateTable = [rateTable]
        for rt in rateTable:
            #print 'rt = ' + str(rt)
            (name, value) = rt['attrib'][0]
            retData.append(value)
            index += 1
    
    # Save data in global if specific index requested
    if int(idx) != -1: retPriceComponentDct[priceComponentIdx] = copy.deepcopy(retData)
    
#   print 'viewPriceComponentRateTable, retData = ' + str(retData)
    if int(idx) != -1: return retData[int(idx)]
    else: return retData
    
#===============================================================================
# This function returns already-retrieved matrix data
def viewMatrixNormalizers(idx, config):
    global retMatrixDct
    global retMatrixNormalizersDct
    
    # If data already retrieved, then return it
    if idx in retMatrixNormalizersDct:
        # I am always wary of returning global data for fear it'll be corrupted...
        retData = copy.deepcopy(retMatrixNormalizersDct[idx])
        return retData
    
    retData = []
    listName = 'MatrixList'
    objectName = 'Matrix'
    
    # See if this object has been read and read if not
    if idx not in retMatrixDct[listName]['id']: getAllMatrixData(config, processAll=idx)
    
    # Get item
    if type(retMatrixDct[listName]['id']) is not list:
        item = retMatrixDct[listName]['id']
    else:
        link = retMatrixDct[listName]['id'][priceComponentIdx]['link']
        item = retMatrixDct[listName][link]
#        print 'Matrix item list = ' + str(item)
    
    # May not have any normalizers in the matrix
    if 'normalizer' not in item[idx]['object']['RateTable']['normalizers']: return retData
    
    # Get to normalizers array
    normalizers = item[idx]['object']['RateTable']['normalizers']['normalizer']
    if type(normalizers) is not list: normalizers = [normalizers]
    for normalizer in normalizers:
#       print 'normalizer(A) = ' + str(normalizer)
        for attrib in normalizer['attrib']:
#           print 'attrib = ' + str(attrib)
            (name, value) = attrib
            
            # Only want the ID here
            if name != 'id': continue
            
            # Store the ID
            retData.append(value)
            
            break
    
    # Save data so we don't read again
    retMatrixNormalizersDct[idx] = copy.deepcopy(retData)
    
#   print 'viewMatrixNormalizers, retData = ' + str(retData)
    return retData
    
#===============================================================================
def viewGlObjectData(idx, config, globalData, objectName, index1, index2, index3):
    retDct = {}
    
    # See if this object has been read and read if not
    if idx not in globalData:
#       print 'Reading GL pricing data for object ' + objectName + ', index1/index2/index3 = ' + str(index1) + '/' + str(index2) + '/' + str(index3)
        
        # Get CB data
        retDct = getCbData(config, idx, objectName, retFormat='DICT')
        
        # If error received, then exit here
        if 'ErrorResponse' in retDct:
            print(objectName + ' ' + str(idx) + ' Received an error reading data back.  Might be OK if the component doesn\'t exist')
            pprint.pprint(retDct)
            return None
        
        # Define entry
        globalData[idx] = {}
        
        # Save data
        globalData[idx] = copy.deepcopy(retDct)
        #pprint.pprint(retDct)
        
        # Get the name
        (key, globalData[idx]['name']) = retDct['object'][index1]['attrib'][1]
        
        # Get account and TX table data
        # Force to be a list
        for tbl in ['1', '2']:
         # Make a list
         if type(retDct['object'][index1]['GLAccount' + tbl + 'Tables']['gl_account_' + tbl + '_table']) is not list:
            retDct['object'][index1]['GLAccount' + tbl + 'Tables']['gl_account_' + tbl + '_table'] = [retDct['object'][index1]['GLAccount' + tbl + 'Tables']['gl_account_' + tbl + '_table']]
        
         # Process each table
         globalData[idx]['GLAccount' + tbl] = []
         for table in retDct['object'][index1]['GLAccount' + tbl + 'Tables']['gl_account_' + tbl + '_table']:
            (name,tableId) = table['attrib'][0]
            
            # Read the account table
#           print 'Reading account ' + tbl + ' table ' + tableId + ':'
            retAccountData = getCbData(config, tableId, 'GLAccountTable', retFormat='DICT')
            globalData[idx]['GLAccount' + tbl].append(copy.deepcopy(retAccountData))
            #pprint.pprint(retAccount1Data)
        
        '''
        # Now read in TX table
        # Make a list
        if type(retDct['object'][index1]['GLAccount' + tbl + 'Tables']['gl_account_' + tbl + '_table']) is not list:
            retDct['object'][index1]['GLAccount' + tbl + 'Tables']['gl_account_' + tbl + '_table'] = [retDct['object'][index1]['GLAccount' + tbl + 'Tables']['gl_account_' + tbl + '_table']]
        '''
        
        # Process each table
        globalData[idx]['GLTransTypeTable'] = []
        
        # Force to be a list
        if type(retDct['object'][index1]['GLTransTypeTables']['gl_transaction_type_table']) is not list:
            retDct['object'][index1]['GLTransTypeTables']['gl_transaction_type_table'] = [retDct['object'][index1]['GLTransTypeTables']['gl_transaction_type_table']]
        
        for table in retDct['object'][index1]['GLTransTypeTables']['gl_transaction_type_table']:
            #pprint.pprint(retDct['object'][index1])
            (name,tableId) = table['attrib'][0]
            
            # Read the account table
#           print 'Reading Transaction table ' + tableId + ':'
            retAccountData = getCbData(config, tableId, 'GLTransTypeTable', retFormat='DICT')
            globalData[idx]['GLTransTypeTable'].append(copy.deepcopy(retAccountData))
            #pprint.pprint(retAccount1Data)
        
    else:
#       print 'Reusing globalData data for item ' + idx
        retDct = copy.deepcopy(globalData[idx])
    
    # Set the return structure
    retDct['NAME'] = globalData[idx]['name']
    retDct['ID'] = idx
    retDct['info'] = copy.deepcopy(globalData[idx])
        
    # Debug output
#   print objectName + ' component data for ' + str(idx) + ': '
#   pprint.pprint(retDct)
    
    return retDct
    
#===============================================================================
def viewObjectData(idx, config, globalData, objectName, index1, index2, index3):
    retDct = {}
    
    # See if this object has been read and read if not
    if idx not in globalData:
        # Get CB data
        retDct = getCbData(config, idx, objectName, retFormat='DICT')
        
        # If error received, then exit here
        if 'ErrorResponse' in retDct:
            print(objectName + ' ' + str(idx) + ' Received an error reading data back.  Might be OK if the component doesn\'t exist')
            pprint.pprint(retDct)
            return None
        
        # Define entry
        globalData[idx] = {}
        
        # Save data
        globalData[idx] = copy.deepcopy(retDct)
        #pprint.pprint(retDct)
        
        # Read raw XML file fo this object.  Need to create key data
        # Process attributes that have the name
        for attrib in retDct['object'][index1]['attrib']:
            # Get item components
            (attrName,attrValue) = attrib
            
            # Set locals
            if   attrName == 'name':    name = str(attrValue).replace('"','\'')
            
        # Set global data
        globalData[idx]['name'] = name
        
        # Now get the tables
        globalData[idx]['tables'] = []
        
        # Make a list so common processing
        #pprint.pprint(retDct['object'][index1])
        if type(retDct['object'][index1][index2][index3]) is not list: 
            retDct['object'][index1][index2][index3] = [retDct['object'][index1][index2][index3]]
        
        for attrib in retDct['object'][index1][index2][index3]:
#         print 'attrib = ' + str(attrib)
          for table in attrib['attrib']:
            # Split into parts
            (name,value) = table
            
            # Append value to table list
            globalData[idx]['tables'].append(value)
    else:
#       print 'Reusing globalData data for item ' + idx
        retDct = copy.deepcopy(globalData[idx])
    
    # Set the retrun structure
    retDct['NAME'] = globalData[idx]['name']
    retDct['ID'] = idx
    retDct['tables'] = copy.deepcopy(globalData[idx]['tables'])
        
    # Debug output
#   print objectName + ' component data for ' + str(idx) + ': '
#   pprint.pprint(retDct)
    
    return retDct
    
#===============================================================================
def viewGlObjectTableData(idx, config, globalData, objectName, index):
    retDct = {}
    
    # Read raw XML file fo this object.  Need to create key data
    # Process attributes that have the name
    for attrib in globalData[idx]['object'][index]['attrib']:
        # Get item components
        (attrName,attrValue) = attrib
        
        # Set locals
        if   attrName == 'name':    name = str(attrValue).replace('"','\'')
        
    # Set global data
    globalData[idx]['name'] = name
    
    # Get the decision table
    (name, value) = globalData[idx]['object'][index]['decision_table_ref']['attrib'][0]
    globalData[idx]['DecisionTable'] = value
        
    # Get decision table
    retDct['DecisionTable'] = globalData[idx]['DecisionTable']
    
    # Set the name
    retDct['NAME'] = globalData[idx]['name']
    
    # ID was passed in
    retDct['ID'] = str(idx)
    
    # Debug output
#   print objectName + ' table data for ' + str(idx) + ': '
#   pprint.pprint(retDct)
    
    return retDct
    
#===============================================================================
def viewObjectProfileData(idx, config, globalData, objectName, index):
    retDct = {}
    
    # See if this object has been read and read if not
    if idx not in globalData:
        retDct = getCbData(config, idx, objectName, retFormat='DICT')
    else:
#       print 'Reusing ' + objectName + ' globalData data for item ' + idx
                retDct = copy.deepcopy(globalData[idx])
        
    # Debug output
#   print objectName + ' table data for ' + str(idx) + ': '
#   pprint.pprint(retDct)
    
    return retDct
        
#===============================================================================
def viewObjectTableData(idx, config, globalData, objectName, index):
    retDct = {}
    
    # See if this object has been read and read if not
    if idx not in globalData:
        retDct = getCbData(config, idx, objectName, retFormat='DICT')
        
        # If error received, then exit here
        if 'ErrorResponse' in retDct:
            print(objectName + ' ' + str(idx) + ' Received an error reading data back.  Might be OK if the component doesn\'t exist')
            pprint.pprint(retDct)
            return None
        
        globalData[idx] = {}
        
        globalData[idx] = copy.deepcopy(retDct)
        
        # View of table data
        #pprint.pprint(retDct)
        
        # Read raw XML file fo this object.  Need to create key data
        # Process attributes that have the name
        for attrib in retDct['object'][index]['attrib']:
            # Get item components
            (attrName,attrValue) = attrib
            
            # Set locals
            if   attrName == 'name':    name = str(attrValue).replace('"','\'')
            
        # Set global data
        globalData[idx]['name'] = name
    
        # Get the decision table
        (name, value) = retDct['object'][index]['decision_table_ref']['attrib'][0]
        globalData[idx]['DecisionTable'] = value
    else:
#       print 'Reusing ' + objectName + ' globalData data for item ' + idx
                retDct = copy.deepcopy(globalData[idx])
        
    # Get decision table
    retDct['DecisionTable'] = globalData[idx]['DecisionTable']
    
    # Set the name
    retDct['NAME'] = globalData[idx]['name']
    
    # ID was passed in
    retDct['ID'] = idx
    
    # Debug output
#   print objectName + ' table data for ' + str(idx) + ': '
#   pprint.pprint(retDct)
    
    return retDct
    
#===============================================================================
def viewObjectProfileData(idx, config, globalData, objectName, index3):
    retDct = {}
    
    # See if this object has been read and read if not
    if idx not in globalData:
        retDct = getCbData(config, idx, objectName, retFormat='DICT')
        
        # If error received, then exit here
        if 'ErrorResponse' in retDct:
            print(objectName + ' ' + str(idx) + ' Received an error reading data back.  Might be OK if the component doesn;t exist')
            pprint.pprint(retDct)
            return None
        
        globalData[idx] = {}
        
        globalData[idx] = copy.deepcopy(retDct)
        #pprint.pprint(retDct)
        
        # Read raw XML file fo this object.  Need to create key data
        # Process attributes that have the name
        for attrib in retDct['object'][index3]['attrib']:
            # Get item components
            (attrName,attrValue) = attrib
            
            # Set locals
            if   attrName == 'name':    name = str(attrValue).replace('"','\'')
            
        # Set global data
        globalData[idx]['name'] = name
    
    else:
#       print 'Reusing ' + objectName + ' globalData data for item ' + idx
                retDct = copy.deepcopy(globalData[idx])
    
    # Set the name
    retDct['NAME'] = globalData[idx]['name']
    
    # ID was passed in
    retDct['ID'] = idx
    
    # Debug output
#   print objectName + ' table data for ' + str(idx) + ': '
#   pprint.pprint(retDct)
    
    return retDct
    
#===============================================================================
def viewObjectAttributeData(idx, config, globalData, objectName, index3):
    retDct = {}
    
    # See if this object has been read and read if not
    if idx not in globalData:
        retDct = getCbData(config, idx, objectName, retFormat='DICT')
        
        # If error received, then exit here
        if 'ErrorResponse' in retDct:
            print(objectName + ' ' + str(idx) + ' Received an error reading data back.  Might be OK if the component doesn;t exist')
            pprint.pprint(retDct)
            return None
        
        globalData[idx] = {}
        
        globalData[idx] = copy.deepcopy(retDct)
#       pprint.pprint(retDct)
        
        # Process attribute information.  Only ever one per file so no list stuff needed.
        for attrib in retDct['object'][objectName][index3]['attrib']:
            # Split into parts
            (attrName,attrValue) = attrib
            
            # Set locals
            if   attrName == 'name':    name = str(attrValue).replace('"','\'')
            
        # Set global data
        globalData[idx]['name'] = name
    
    else:
#       print 'Reusing ' + objectName + ' globalData data for item ' + idx
                retDct = copy.deepcopy(globalData[idx])
        
    # Set the name
    retDct['NAME'] = globalData[idx]['name']
    
    # ID was passed in
    retDct['ID'] = idx
    
    # Debug output
#   print objectName + ' table data for ' + str(idx) + ': '
#   pprint.pprint(retDct)
    
    return retDct
    
# This function returns balance class data
def viewBalanceClassData(idx, config):
        global retBalanceClassDct
        retDct = {}
        objectName = 'BalanceClass'

        # Check if data already present
        if idx not in retBalanceTagDct:
          retBalanceClassDct[idx] = {}
          
          # Balance class 0 (meters) doesn't read
          if int(idx) == 0:
                name = 'meter'
          else:
                retDct = getCbData(config, idx, objectName, retFormat='DICT')

                # If error received, then exit here
                if 'ErrorResponse' in retDct:
                        print(objectName + ' ' + str(idx) + ' Received an error reading data back.  Might be OK if the component doesn;t exist')
                        pprint.pprint(retDct)
                        return None

                retBalanceClassDct[idx] = copy.deepcopy(retDct)
                #print('Balance class ' + str(idx) + ':')
                #pprint.pprint(retDct)

                # Process attribute information.  Only ever one per file so no list stuff needed.
                objectName = 'balance_class'
                for attrib in retDct['object'][objectName]['attrib']:
                        # Split into parts
                        (attrName,attrValue) = attrib

                        # Set locals
                        if   attrName == 'name':        name = str(attrValue).replace('"','\'')

          # Set global data
          retBalanceClassDct[idx]['name'] = name

        else:
#               print 'Reusing ' + objectName + ' globalData data for item ' + idx
                retDct = copy.deepcopy(retBalanceClassDct[idx])

        # Set the name
        retDct['NAME'] = retBalanceClassDct[idx]['name']

        # ID was passed in
        retDct['ID'] = idx

        # Debug output
#       print objectName + ' data for ' + str(idx) + ': '
#       pprint.pprint(retDct)

        return retDct


#===============================================================================
# This function returns balance tag data
def viewBalanceTagData(idx, config):
        global retBalanceTagDct
        retDct = {}
        objectName = 'BalanceTag'

        # Check if data already present
        if idx not in retBalanceTagDct:
                retDct = getCbData(config, idx, objectName, retFormat='DICT')

                # If error received, then exit here
                if 'ErrorResponse' in retDct:
                        print(objectName + ' ' + str(idx) + ' Received an error reading data back.  Might be OK if the component doesn;t exist')
                        pprint.pprint(retDct)
                        return None

                retBalanceTagDct[idx] = {}

                retBalanceTagDct[idx] = copy.deepcopy(retDct)
                #print('Balance tag ' + str(idx) + ':')
                #pprint.pprint(retDct)

                # Process attribute information.  Only ever one per file so no list stuff needed.
                objectName = 'balance_tag'
                for attrib in retDct['object'][objectName]['attrib']:
                        # Split into parts
                        (attrName,attrValue) = attrib

                        # Set locals
                        if   attrName == 'name':        name = str(attrValue).replace('"','\'')

                # Set global data
                retBalanceTagDct[idx]['name'] = name

        else:
#               print 'Reusing ' + objectName + ' globalData data for item ' + idx
                retDct = copy.deepcopy(retBalanceTagDct[idx])

        # Set the name
        retDct['NAME'] = retBalanceTagDct[idx]['name']

        # ID was passed in
        retDct['ID'] = idx

        # Debug output
#       print objectName + ' data for ' + str(idx) + ': '
#       pprint.pprint(retDct)

        return retDct

#===============================================================================
# This function returns Usage Trigger component data
def viewUsageTriggerData(idx, config):
       global retUsageTriggerDct

       return viewObjectData(idx, config, retUsageTriggerDct, 'UsageTriggerComponent', 'usage_trigger_component', 'UsageTriggerTables', 'UsageTriggerTable')

#===============================================================================
# This function returns Usage Trigger table data
def viewUsageTriggerTableData(idx, config):
       global retUsageTriggerTableDct

       return viewObjectTableData(idx, config, retUsageTriggerTableDct, 'UsageTriggerTable', 'usage_trigger_table')

#===============================================================================
# This function returns usage trigger profile data
def viewUsageTriggerProfileData(idx, config):
    global retUsageTriggerProfileDct
    
    return viewObjectProfileData(idx, config, retUsageTriggerProfileDct, 'UsageTriggerProfile', 'usage_trigger_profile')

#===============================================================================
# This function returns GL Transaction Profile data
def viewGlTxnProfileData(idx, config):
       global retGlTxnProfileData

       return viewObjectProfileData(idx, config, retGlTxnProfileData, 'GLTransactionProfile', 'gl_transaction_profile')

#===============================================================================
# This function returns aggregate selector component data
def viewAggregationSelectorData(idx, config):
    global retAggregationSelectorDct
    
    return viewObjectData(idx, config, retAggregationSelectorDct, 'AggregationSelector', 'aggregation_selector', 'AggregationSelectorTables', 'aggregation_selector_table')

#===============================================================================
# This function returns announcement table component data
def viewAggregationSelectorTableData(idx, config):
    global retAggregationSelectorTableDct
    
    return viewObjectTableData(idx, config, retAggregationSelectorTableDct, 'AggregationSelectorTable', 'aggregation_selector_table')

#===============================================================================
# This function returns announcement generator component data
def viewAnnouncementGeneratorData(idx, config):
    global retAnnouncementGeneratorDct
    
    return viewObjectData(idx, config, retAnnouncementGeneratorDct, 'AnnouncementGenerator', 'announcement_generator', 'AnnouncementTables', 'announcement_table')

#===============================================================================
# This function returns announcement profile data
def viewAnnouncementProfileData(idx, config):
    global retAnnouncementProfileDct
    
    return viewObjectProfileData(idx, config, retAnnouncementProfileDct, 'AnnouncementProfile', 'announcement_profile')

#===============================================================================
# This function returns announcement table component data
def viewAnnouncementTableData(idx, config):
    global retAnnouncementTableDct
    
    return viewObjectTableData(idx, config, retAnnouncementTableDct, 'AnnouncementTable', 'announcement_table')

#===============================================================================
# This function returns announcement detail component data
def viewAnnouncementDetailData(idx, config):
    global retAnnouncementDetailsDct
    
    return viewObjectProfileData(idx, config, retAnnouncementDetailsDct, 'AnnouncementDetail', 'announcement_detail')

#===============================================================================
# This function returns announcement server component data
def viewAnnouncementServerData(idx, config):
    global retAnnouncementServerDct
    
    return viewObjectProfileData(idx, config, retAnnouncementServerDct, 'AnnouncementServer', 'announcement_server')

#===============================================================================
# This function returns priority generator component data
def viewPriorityGeneratorData(idx, config):
    global retPriorityGeneratorDct
    
    return viewObjectData(idx, config, retPriorityGeneratorDct, 'PriorityGenerator', 'priority_generator', 'PriorityTables', 'priority_table')

#===============================================================================
# This function returns priority generator table data
def viewPriorityGeneratorTableData(idx, config):
    global retPriorityGeneratorTableDct
    
    return viewObjectTableData(idx, config, retPriorityGeneratorTableDct, 'PriorityTable', 'priority_table')

#===============================================================================
# This function returns priority generator component data
def viewTaxSelectorData(idx, config):
    global retTaxSelectorDct
    
    return viewObjectData(idx, config, retTaxSelectorDct, 'TaxSelector', 'tax_selector', 'TaxSelectorTables', 'tax_selector_table')

#===============================================================================
# This function returns priority generator table data
def viewTaxSelectorTableData(idx, config):
    global retTaxSelectorTableDct
    
    return viewObjectTableData(idx, config, retTaxSelectorTableDct, 'TaxSelectorTable', 'tax_selector_table')
    
#===============================================================================
# This function returns balance state component data
def viewBalanceStateData(idx, config):
    global retBalanceStateDct
    
    return viewObjectData(idx, config, retBalanceStateDct, 'BalanceStateUpdateComponent', 'balance_state_update_component', 'BalanceStateUpdateTables', 'balance_state_update_table')

#===============================================================================
# This function returns balance state table data
def viewBalanceStateTableData(idx, config):
    global retBalanceStateTableDct
    
    return viewObjectTableData(idx, config, retBalanceStateTableDct, 'BalanceStateUpdateTable', 'balance_state_update_table')
    
#===============================================================================
# This function returns GL Account Selector component data
def viewGlAccountSelectorData(idx, config):
       global retGlActSelectorDct

       return viewObjectData(idx, config, retGlActSelectorDct, 'GLAccountSelector', 'gl_account_selector', 'GLAccountSelectorTables', 'gl_account_selector_table')

#===============================================================================
# This function returns GL Account Selector table data
def viewGlAccountSelectorTableData(idx, config):
       global retGlActSelectorTableDct

       return viewObjectTableData(idx, config, retGlActSelectorTableDct, 'GLAccountSelectorTable', 'gl_account_selector_table')

#===============================================================================
# This function returns GL Txn Selector component data
def viewGlTxnProfileSelectorData(idx, config):
       global retGlTxnSelectorDct

       return viewObjectData(idx, config, retGlTxnSelectorDct, 'GLTxnProfileSelector', 'gl_transaction_profile_selector', 'GLTxnProfileSelectorTables', 'gl_transaction_profile_selector_table')

#===============================================================================
# This function returns GL Txn Selector table component data
def viewGlTxnProfileSelectorTableData(idx, config):
       global retGlTxnSelectorTableDct

       return viewObjectTableData(idx, config, retGlTxnSelectorTableDct, 'GLTxnProfileSelectorTable', 'gl_transaction_profile_selector_table')

#===============================================================================
# This function returns GL Generator component data
def viewGlInfoData(idx, config):
       global retGlInfoDct

       return viewGlObjectData(idx, config, retGlInfoDct, 'GLInfoGenerator', 'gl_info_generator', None, None)

#===============================================================================
# This function returns GL Transaction Profile data
def viewGlTxnProfileData(idx, config):
       global retGlTxnProfileData

       return viewObjectProfileData(idx, config, retGlTxnProfileData, 'GLTransactionProfile', 'gl_transaction_profile')

#===============================================================================
# This function returns FUI component data
def viewLastUnitData(idx, config):
       global retLastUnitDct

       return viewObjectData(idx, config, retLastUnitDct, 'FUIGenerator', 'fui_generator', 'FUITables', 'fui_table')

#===============================================================================
# This function returns FUI table data
def viewLastUnitTableData(idx, config):
       global retLastUnitTableDct

       return viewObjectTableData(idx, config, retLastUnitTableDct, 'FUITable', 'fui_table')

#===============================================================================
# This function returns last unit profile
def viewLastUnitProfileData(idx, config):
       global retLastUnitProfileDct

       return viewObjectProfileData(idx, config, retLastUnitProfileDct, 'FUIProfile', 'fui_profile')

#===============================================================================
# This function returns policy component data
def viewPolicyData(idx, config):
    global retPolicyDct
    
    return viewObjectData(idx, config, retPolicyDct, 'PolicyComponent', 'policy_component', 'policyTables', 'policyTable')

#===============================================================================
# This function returns balance state table data
def viewPolicyTableData(idx, config):
    global retPolicyTableDct
    
    return viewObjectTableData(idx, config, retPolicyTableDct, 'PolicyTable', 'policy_table')
    
#===============================================================================
# This function returns policy profile
def viewPolicyProfileData(idx, config):
    global retPolicyProfileDct
    
    return viewObjectProfileData(idx, config, retPolicyProfileDct, 'PolicyProfile', 'policy_profile')
    
#===============================================================================
# This function returns attribute data
def viewAttributeData(idx, config):
    global retAttributeDct
    
    return viewObjectAttributeData(idx, config, retAttributeDct, 'AttributeDefinition', 'attribute')
    
#===============================================================================
# This function returns subscriberInfo component data
def viewSubInfoData(idx, config):
    global retSubInfoDct
    
    return viewObjectData(idx, config, retSubInfoDct, 'SubscriberInfoQueryGenerator', 'subscriber_info_query_generator', 'SubscriberInfoQueryTables', 'subscriber_info_query_table')

#===============================================================================
# This function returns policy profile
def viewSubInfoProfileData(idx, config):
    global retSubInfoProfileDct
    
    return viewObjectProfileData(idx, config, retSubInfoProfileDct, 'SubscriberInfoQueryProfile', 'subscriber_info_query_profile')
    
#===============================================================================
# This function returns subscriber query profile data (PreRating component)
def viewSubInfoDataModifyActionData(idx, config):
    global retSubInfoDataModifyDct
    
    return viewObjectProfileData(idx, config, retSubInfoDataModifyDct, 'DataModifyAction', 'data_modify_action')
    
#===============================================================================
# This function returns subscriber query profile data (PreRating component)
def viewSubInfoActionData(idx, config):
    global retSubInfoActionDct
    
    return viewObjectProfileData(idx, config, retSubInfoActionDct, 'SubscriberInfoQueryAction', 'subscriber_info_query_action')
    
#===============================================================================
# This function returns subscriber query info table data
def viewSubInfoTableData(idx, config):
    global retSubInfoTableDct
    
    return viewObjectTableData(idx, config, retSubInfoTableDct, 'SubscriberInfoQueryTable', 'subscriber_info_query_table')
    
#===============================================================================
# This function returns usage quota component data
def viewUsageComponentData(idx, config):
    global retUsageDct
    
    return viewObjectData(idx, config, retUsageDct, 'UsageQuotaComponent', 'usage_quota_component', 'UsageQuotaTables', 'usage_quota_table')

#===============================================================================
# This function returns rollover table data
def viewUsageTableData(idx, config):
    global retUsageTableDct
    
    return viewObjectTableData(idx, config, retUsageTableDct, 'UsageQuotaTable', 'usage_quota_table')
    
#===============================================================================
# This function returns rollover component data
def viewRolloverData(idx, config):
    global retRolloverDct
    
    return viewObjectData(idx, config, retRolloverDct, 'RolloverComponent', 'rollover_component', 'RolloverTables', 'rollover_table')

#===============================================================================
# This function returns rollover table data
def viewRolloverTableData(idx, config):
    global retRolloverTableDct
    
    return viewObjectTableData(idx, config, retRolloverTableDct, 'RolloverTable', 'rollover_table')
    
#===============================================================================
# This function returns Sh profile component data
def viewRepositoryData(idx, config):
    global retRepositoryDct
    
    return viewObjectData(idx, config, retRepositoryDct, 'RepositoryDataComponent', 'repository_data_component', 'RepositoryDataTables', 'repository_data_table')

#===============================================================================
# This function returns rollover table data
def viewRepositoryTableData(idx, config):
    global retRepositoryTableDct
    
    return viewObjectTableData(idx, config, retRepositoryTableDct, 'RepositoryDataTable', 'repository_data_table')
    
#===============================================================================
# This function returns repository table data
def viewRepositoryProfileData(idx, config):
    global retRepositoryProfileDct
    
    return viewObjectProfileData(idx, config, retRepositoryProfileDct, 'RepositoryDataProfile', 'repository_data_profile')
    
#===============================================================================
# This function returns decision table data
def getGlTransType(idx, config):
    retDct = getCbData(config, idx, 'GLTransactionType', retFormat='DICT')
    
    return retDct
    
#===============================================================================
# This function returns decision table data
def viewDecisionTableData(idx, config):
    global retDecisionTableDct
    
    retDct = {}
    objectName = 'DecisionTable'
    
    # See if this object has been read and read if not
    if idx not in retDecisionTableDct:
        # Define entry
        retDecisionTableDct[idx] = {}
        
        # Get data from CB
        retDct = getCbData(config, idx, objectName, retFormat='DICT')
        retDecisionTableDct[idx] = copy.deepcopy(retDct)
#       print 'Decision Table ' + idx + ': '
#       pprint.pprint(retDct)
        
        # Read raw XML file fo this object.  Need to create key data
        # Process attributes that have the name
        for attrib in retDct['object']['DecisionTable']['attrib']:
            # Get item components
            (attrName,attrValue) = attrib
            
            # Set locals
            if   attrName == 'name':    name = str(attrValue).replace('"','\'')
            
        # Set global data
        retDecisionTableDct[idx]['name'] = name
    
        # Get the normalizers if not already retrieved
        if 'Normalizers' not in retDecisionTableDct[idx]:
            retDecisionTableDct[idx]['Normalizers'] = []
            
            # Make sure not an empty decision table
            if 'normalizer' in retDct['object']['DecisionTable']['normalizers']:
                # Make this a list so common processing
                if type(retDct['object']['DecisionTable']['normalizers']['normalizer']) is not list:
                    retDct['object']['DecisionTable']['normalizers']['normalizer'] = [retDct['object']['DecisionTable']['normalizers']['normalizer']]
#               print 'Normalizer list: ' + str(retDct['object']['DecisionTable']['normalizers']['normalizer'])
            
                # Process normalizer list
                for attrib in retDct['object']['DecisionTable']['normalizers']['normalizer']:
#                   print 'Normalizer analysis: attrib = ' + str(attrib)
                    for normalizer in attrib['attrib']:
                        (attrName, attrValue) = normalizer
                        
                        # Set locals
                        if   attrName == 'id':  id = str(attrValue).replace('"','\'')
                    
                    # Add to dictionary
                    retDecisionTableDct[idx]['Normalizers'].append(id)
        
    else:
#       print 'Reusing retDecisionTableDct data for item ' + idx
                retDct = copy.deepcopy(retDecisionTableDct[idx])
    
    # Copy normalizers to returned structure
    retDct['Normalizers'] = copy.deepcopy(retDecisionTableDct[idx]['Normalizers'])
    
    # Set the name
    retDct['NAME'] = retDecisionTableDct[idx]['name']
    
    # ID was passed in
    retDct['ID'] = idx
    
    # Debug output
#   print 'Decision table data for ' + str(idx) + ': '
#   pprint.pprint(retDct)
    
    return retDct
    
#===============================================================================
# This function returns normalizer data
# *** NOT NEEDED ***
'''
def viewNormalizerData(idx, config):
    global retNormalizerDct
    
    retDct = {}
    objectName = 'Normalizer'
    
    # See if this object has been read and read if not
    if idx not in retNormalizerDct:
        # Define entry
        retNormalizerDct[idx] = {}
        
        # Get data from CB
        retDct = getNormalizer(config, idx)
        retNormalizerDct[idx] = copy.deepcopy(retDct)
#       print 'Normalizer ' + idx + ':'
#       pprint.pprint(retDct)
        
        # Process attributes that have the name
        for attrib in retDct['object']['normalizer']['attrib']:
            # Get item components
            (attrName,attrValue) = attrib
            
            # Set locals
            if   attrName == 'name':    name = str(attrValue).replace('"','\'')
            
        # Set global data
        retNormalizerDct[idx]['name'] = name
    
        # Now get the normalizer values
        retNormalizerDct[idx]['results'] = {}
        
        for attrib in retDct['object']['normalizer']['results']['result']:
#         print 'attrib = ' + str(attrib)
          for entry in attrib['attrib']:
            # Split into parts
            (attrName,attrValue) = entry
            
            # Set locals
            if   attrName == 'index':   index = str(attrValue).replace('"','\'')
            elif attrName == 'value':   value = str(attrValue).replace('"','\'')
            
          # Append value to table list
          retNormalizerDct[idx]['results'][index] = value
    else:
#       print 'Reusing retNormalizerDct data for item ' + idx
        retDct = copy.deepcopy(retNormalizerDct[idx])
    
    # Copy normalizers to returned structure
    retDct['results'] = copy.deepcopy(retNormalizerDct[idx]['results'])
    
    # Set the name
    retDct['NAME'] = retNormalizerDct[idx]['name']
    
    # ID was passed in
    retDct['ID'] = idx
    
    # Debug output
#   print 'Normalizer data for ' + str(idx) + ': '
#   pprint.pprint(retDct)
    
    return retDct
'''
    
#===============================================================================
# This function returns already-retrieved price component data
def viewAggregationSelectorListData(idx, config):
    global retPriceDct
    
    listName = 'AggregationSelectorList'
    objectName = 'AggregationSelector'
    
    # See if this object has been read and read if not
    if listName not in retAggregationSelectorDct: retAggregationSelectorDct[listName] = {}
    if 'id' not in retAggregationSelectorDct[listName]: retAggregationSelectorDct[listName]['id'] = {}
    if idx not in retAggregationSelectorDct[listName]['id']: getAllAggregationSelectorData(config, processAll=idx)
    
    # Get the already-retrieved data
    retDct = viewObjectListData(idx, config, retAggregationSelectorDct, listName, objectName)
    
    return retDct
    
#===============================================================================
# This function returns already-retrieved price component data
def viewPriceListData(idx, config):
    global retPriceDct
    
    listName = 'PriceComponentList'
    objectName = 'PriceComponent'
    
    # See if this object has been read and read if not
    if idx not in retPriceDct[listName]['id']: getAllPriceData(config, processAll=idx)
    
    # Get the already-retrieved data
    retDct = viewObjectListData(idx, config, retPriceDct, listName, objectName)
    
    return retDct
    
#===============================================================================
# This function returns already-retrieved matrix data
def viewMatrixListData(idx, config):
    global retMatrixDct
    
    listName = 'MatrixList'
    objectName = 'Matrix'
    
    # See if this object has been read and read if not
    if idx not in retMatrixDct[listName]['id']: getAllMatrixData(config, processAll=idx)
    
    # Get the already-retrieved data
    retDct = viewObjectListData(idx, config, retMatrixDct, listName, objectName)
    
    return retDct

#===============================================================================
# This function returns already-retrieved normalizer data
def viewNormalizerData(idx, config, normValue=None):
    global retNormalizerDct
    
    listName = 'NormalizerList'
    objectName = 'Normalizer'
    
    # See if this PC has been read and read if not
    if idx not in retNormalizerDct[listName]['id']: getAllNormalizerData(config, processAll=idx)
    
    # Get the already-retrieved data
    retDct = viewObjectListData(idx, config, retNormalizerDct, listName, objectName)
    
    # To get name we need to go to the list data
    if type(retNormalizerDct[listName]['id']) is not list:
        item = retNormalizerDct[listName]['id']
    else:
        link = retNormalizerDct[listName]['id'][priceComponentIdx]['link']
        item = retNormalizerDct[listName][link]
#        print 'Normalizer item list = ' + str(item)
    
    # Need to loop through attributes for the name
    normList = 0
    attributes = item[idx]['object']['normalizer']['attrib']
    for attribute in attributes:
        # See if this is the name
        (paramName, paramValue) = attribute
        
        # Want name in separate value
        if paramName == 'name': retDct['NAME'] = paramValue.strip()
        
        # Don't change Python key word
        if paramName == 'type': continue
        
        # Set locals
        if paramName == 'normValue': normValue = paramValue.replace('"','\'')
    
        # Track if normalizer List in use
        if paramName == 'normalizer_value_list_id': normList = int(paramValue)
        
    # if no value desired, then exit
    if not normValue: return retDct
    
    # If a normalizer list in play, then exit here (not yet implemented)
    if normList:
          retData = viewNormalizerListData(normList, config)
          #pprint.pprint()
          values = retData['values']
          if normValue not in values:
               # Report that we'll assume default entry
               print('WARNING: didn\'t find normalizer list ' + str(normList) + ' value ' + normValue  + '.  Will use default entry of ' + str(default))
               retDct['normValueName'] = str(default)
          else:retDct['normValueName'] = values[normValue]
            
          return retDct
    
    # Not a normalizer list.  Need to process normalizer data
    values = item[idx]['object']['normalizer']['values']['value']

    # Want a list (since item lists are not a list when read)
    if type(values) is not list: values = [values]
    
    # Read normalizer into tmp structure
    tmpData = {}
    for value in values:
#       print 'viewNormalizerListData, value = ' + str(value)
        lclData = {}
        for attribute in value['attrib']:
            (name, value) = attribute
            lclData[name] = value.strip()
        
        # Update temp structure.
        # Rating outputs the normalizer id parameter
        tmpData[lclData['index']] = copy.deepcopy(lclData)
        #tmpData[lclData['id']] = copy.deepcopy(lclData)
    
    # Now have all the normalizer attributes in the tmp structure.
    # Want the name of the normalizer entry (instead of just the value).
    if normValue not in tmpData:
        # Report that we'll assume default entry
        print('WARNING: didn\'t find normalizer ' + str(idx) + ' value ' + normValue  + '.  Will use default entry of ' + str(default))
        normValue = str(default)
    
    # Get name
    retDct['normValueName'] = tmpData[normValue]['name']
            
    return retDct

#===============================================================================
def viewObjectListData(idx, config, objectDct, listName, object):
    retDct = {}
    
    # KEF - debug lines
    if idx == 'kef':
        print('viewObjectListData: objectDct =')
        pprint.pprint(objectDct)
    
    # Use the indexs to get a link to the list data (more concise)
    link = objectDct[listName]['id'][idx]['link']
    objectLink = objectDct[listName][object][link]
    
    # KEF
#   print 'PC link idx = ' + str(link)
#   pprint.pprint(objectLink)
    
    # Get individual fields
    for key in list(objectLink.keys()):
        # Not all keys have data defined...
        if 'value' in objectLink[key]:  retDct[key] = objectLink[key]['value']
        else:               retDct[key] = None
#   print 'retDct = ' + str(retDct)
    
    return retDct
    
#===============================================================================
# This function will read all CB data
def getAllCbData(config, idx=-1):
    # Login
    print('\nLogging In\n')
    cbLogin(config)
    
    # Get CI list (not all releases support CIs)
    print('\nGetting Catalog Items\n')
    try:    getAllCIData(config, idx)
    except: pass

    # Get offer list (assume at least one so no try/except)
    print('\nGetting offers\n')
    getAllOfferData(config, idx)

    # Get Price Component list (assume at least one so no try/except)
    print('\nGetting price components\n')
    getAllPriceData(config, idx)

    # Get Normalizer list (assume at least one so no try/except)
    print('\nGetting Normalizers\n')
    getAllNormalizerData(config, idx)

    # Get Matrix list (assume at least one so no try/except)
    print('\nGetting Matrices\n')
    getAllMatrixData(config, idx)
    
    # Get Attribute list (optional)
    print('\nGetting Attributes\n')
    try:    getAllAttributeListData(config, idx)
    except: pass
    #pprint.pprint(retAttributeListDct)
    
    # Get all parameters
    print('\nGetting Parameters\n')
    try:    getAllParameterData(config, idx)
    except: pass
    
#===============================================================================
# This function will read all CIs.
# NOTE: reading from engine, not MyMatrixx.
def getAllCIData(config, processAll=0):
    global retCIData
    
    # Add additional curl control strings
    addlCurl = ' -H "Cache-Control: no-cache" '
    
    # Get data
    cmd = 'curl -s ' + addlCurl + ' ' + DATA.httpString + '://restgw:' + DATA.httpPort + '/rsgateway/data/v3/pricing/CatalogItem'
    xmlData = GENERIC.runCmd(cmd)
    #print xmlData
    
    # Walk the returned data and 
    # Converty to dictionary
    q = ET.fromstring(xmlData)
    
    # Let's see what we got...
    retDct = XML.walkXmlData(q)
    #pprint.pprint(retDct)
    
    # Get list elements
    for item in retDct['MtxResponsePricingCatalogItemList']['CatalogItemList']['MtxPricingCatalogItemInfo']:
        retCIData[item['CatalogItemId']['value']] = item['Name']['value']
    
    return retCIData

#===============================================================================
# This function will read all Offers.
# NOTE: reading from engine, not MyMatrixx.
def getAllOfferData(config, processAll=0):
    global retOfferDct
    global retOfferData
    global retBundleData
    
    retOfferDct = getCbListData(config, 'Offer', processAll, retOfferDct)
    
    # Add additional curl control strings
    addlCurl = ' -H "Cache-Control: no-cache" '

    curlCmd = 'curl -s ' + addlCurl
    if DATA.simpleAuthUserName:
            if not DATA.simpleAuthPassword: sys.exit('ERROR: file primitives/primData.py specifies a non-None value for simpleAuthUserName but not simpleAuthPassword')
            curlCmd += ' -u ' + DATA.simpleAuthUserName + ':' + DATA.simpleAuthPassword
    
    # Get data
    curlCmd += ' ' + DATA.httpString + '://restgw:' + DATA.httpPort + '/rsgateway/data/v3/pricing/offers'
    xmlData = GENERIC.runCmd(curlCmd)
    
    # Walk the returned data and 
    # Converty to dictionary
    q = ET.fromstring(xmlData)
    
    # Let's see what we got...
    retDct = XML.walkXmlData(q)
    '''
    print 'Return from getAllOfferData:'
    pprint.pprint(retDct)
    '''
    
    # Get list elements
    # Bundles are NOT required...
    if 'BundleList' in retDct['MtxResponsePricingOfferList']:
        for item in retDct['MtxResponsePricingOfferList']['BundleList']['MtxPricingOfferInfo']:
            retBundleData[item['OfferId']['value']] = item['Name']['value']
    
    # Offers should be present, but check to be a good camper
    if 'OfferList' in retDct['MtxResponsePricingOfferList']:
        for item in retDct['MtxResponsePricingOfferList']['OfferList']['MtxPricingOfferInfo']:
            retOfferData[item['OfferId']['value']] = item['Name']['value']
    
    return retOfferDct

#===============================================================================
# This function will read all parameters
def getAllParameterData(config, processAll=0):
    global retParameterListDct
    global retParameterDct
    
    retDct = getCbListData(config, 'ParameterDefn', -1, retParameterListDct)
    '''
    print 'Return from getCbListData ParameterDefn:'
    pprint.pprint(retDct)
    '''
    
    # If errors, then return query response
    if 'ParameterDefnList' not in retDct or 'ErrorResponse' in retDct['ParameterDefnList']: return retDct
    
    # Extract per-parameter data 
    retParameterDct = {}
    if 'ParameterDefnList' in retDct and 'ParameterDefn' in retDct['ParameterDefnList']:
        # Make a list if not a list
        if type(retDct['ParameterDefnList']['ParameterDefn']) is not list: retDct['ParameterDefnList']['ParameterDefn'] = [retDct['ParameterDefnList']['ParameterDefn']]
        
        # Process each entry
        for entry in retDct['ParameterDefnList']['ParameterDefn']:
            # Get id and set to name
            idx = entry['ID']['value']
            retParameterListDct[idx] = entry['NAME']['value']
    
    #print 'Parameter list:'
    #pprint.pprint(retParameterListDct)
    
    # Now need to read each parameter
    for idx in retParameterListDct:
        retParameterDct[idx] = getCbData(config, idx, 'ParameterDefn')
    
    #print 'Parameter Details:'
    #pprint.pprint(retParameterDct)
    
    return retParameterDct
    
#===============================================================================
# This function will read all attributes
def getAllAttributeListData(config, processAll=0):
    global retAttributeListDct
    retDct = getCbListData(config, 'AttributeDefinition', processAll, retAttributeListDct)
    
    # Extract per-attribute data 
    retAttributeListDct = {}
    if 'AttributeDefinitionList' in retDct and 'AttributeDefinition' in retDct['AttributeDefinitionList']:
        # Process each entry
        for entry in retDct['AttributeDefinitionList']['AttributeDefinition']:
            # Get subtype
            subtype = entry['SUBTYPE']['value']
            if subtype not in retAttributeListDct: retAttributeListDct[subtype] = {}
            
            # Get id and set to name
            idx = entry['ID']['value']
            retAttributeListDct[subtype][idx] = entry['NAME']['value']
        
    return retAttributeListDct
    
#===============================================================================
# This function will read all aggregation selector components
def getAllAggregationSelectorData(config, processAll=0):
    global retAggregationSelectorDct
    retPriceDct = getCbListData(config, 'AggregationSelector', processAll, retAggregationSelectorDct)
    return retAggregationSelectorDct
    
#===============================================================================
# This function will read all price components
def getAllPriceData(config, processAll=0):
    global retPriceDct
    retPriceDct = getCbListData(config, 'Price', processAll, retPriceDct)
    return retPriceDct
    
#===============================================================================
# This function will read all Normalizers
def getAllNormalizerData(config, processAll=0):
    global retNormalizerDct
    retNormalizerDct =  getCbListData(config, 'Normalizer', processAll, retNormalizerDct)
    return retNormalizerDct

#===============================================================================
# This function will read all Matrix
def getAllMatrixData(config, processAll=0):
    global retMatrixDct
    retMatrixDct = getCbListData(config, 'Matrix', processAll, retMatrixDct)
    #print 'getAllMatrixData: data = ' 
    #HTTP.printDictionaryLevel(retMatrixDct)
    return retMatrixDct

#===============================================================================
# This function will read all list items and return detailed data for each item (as well as the overall list)
def getCbListData(config, objectName, processIdx=0, retDct=None):
    # Get list name
    listName = objectName + "List"
    
    # *** Minor Hack:  price component queries don't follow the same convention as offer queries
    if objectName == 'Price':   objectRet = 'PriceComponent'
    else:               objectRet = objectName
    # *** End of Hack
    
    # Only need to read list data if no dictionary passed in
    if retDct == {}:
        # Parse the response into a dictionary
        url = listName + "/default/"
        #print 'Reading url ' + url
            
        xmlData = runCbRestCmd(config, url)
        #print 'getCbListData read return: "' + str(xmlData) + '"'
        
        # Get list name
        listName = objectRet + "List"
    
        # Walk the returned data and 
        # Converty to dictionary
        if xmlData:
            q = ET.fromstring(xmlData)
            
            # Let's see what we got...
            retDct = XML.walkXmlData(q)
        else: 
            # Init dictionary to minimum required
            retDct[listName] = {}
            
        # Now want to go through each offer individually
        try:    retDct[listName]['id'] = {}
        except: pass
    
    else:   listName = objectRet + "List"
    
    # May want to process all or just one item
    if int(processIdx) >= 0:
        # Process all data
        #print 'listName = ' + listName + ', objectRet = ' + objectRet
        #pprint.pprint(retDct)
        #print 'Entry type is ' + str(type(retDct[listName][objectRet]))
        
        # Make sure this is a list
        if type(retDct[listName][objectRet]) is not list:
            retDct[listName][objectRet] = [retDct[listName][objectRet]]
            #pprint.pprint(retDct)
        
        # Process each element in the list
        for i,item in enumerate(retDct[listName][objectRet]):
            # Get the ID
#           print 'index ' + str(i ) + ', item = ' + str(item)
            value = item['ID']['value']
            
            # Won't get revision data in debug logs, so need to account for that
#           id = value.split('-')[0]
#           rev = value.split('-')[1:]
            id = value
                        
            # Skip if not what we're looking for
            if processIdx and id != processIdx:
#               print 'Skipping reading since processIdx = ' + processIdx + ' and id = ' + id
                continue
            
            # Now read individual item.  Use original object value here.
#           print 'Reading in ' + objectName + ' id = ' + id
            retDct[listName]['id'][id] = copy.deepcopy(getCbData(config, id, objectName))
            
            # Add enumerated item (in case we need to refer back)
            retDct[listName]['id'][id]['link'] = i
#           print 'Read in ' + object + ' ID ' + str(id) + ' details: ' + str(retDct[listName]['id'][id])
            
            # If we found the one we're looking for then we can break out
            if processIdx: break
    
        # Print final dictionary
#        print 'Final dictionary: '
#   pprint.pprint(retDct)
    
    return retDct

#===============================================================================
# This function will read CB offer data and convert it into a Python dictionary
def getOffer(config, id, retFormat='DICT'):
    return getCbData(config, id, 'Offer')

#===============================================================================
# This function will read CB price component data and convert it into a Python dictionary
def getPrice(config, id, retFormat='DICT'):
    return getCbData(config, id, 'Price')

#===============================================================================
# This function will read a Normalizer.
def getNormalizer(config, id, retFormat='DICT'):
    return getCbData(config, id, 'Normalizer', retFormat)

#===============================================================================
# This function will read a Normalizer list.
def getNormalizerList(config, id, retFormat='DICT'):
    return getCbData(config, id, 'NormalizerValueList', retFormat)

#===============================================================================
# This function will read a matrix.
def getMatrix(config, id, retFormat='DICT'):
    return getCbData(config, id, 'Matrix')

#===============================================================================
# This function will read CB data and convert it into a Python dictionary
def getCbData(config, id, object, retFormat='DICT'):
    # Parse the response into a dictionary
    if object == 'Normalizer': extension = 'Ccd'
    else:              extension = 'default'
    extension = 'default'
    url = object + "/" + extension + "/" + str(id)
    #print 'getCbData: URL = ' + url
        
    xmlData = runCbRestCmd(config, url)
    #print 'getCbData: XML return data = ' + str(xmlData)
    
    # Return XML if desired
    if retFormat.lower() == 'xml': return xmlData
    
    # Walk the returned data and 
    # Converty to dictionary
    try: q = ET.fromstring(xmlData)
    except:
        print('ERROR in getCbData.  url = ' + url + ', ET output = ')
        ET.dump(q)
        sys.exit("Exiting due to errors")
    
    # Let's see what we got...
    retDct = XML.walkXmlData(q)
    
    # KEF
#   if object == 'Price':
#       print object + ' Component ' + str(id) + ' returned ' + object + ':'
#       pprint.pprint(retDct)
    
    return retDct
    
#===============================================================================
# This function will retrieve data services information
#def getCurrentDataServicesDct(program, debugFd=None, warnFd=None):
#    global DataServicesDct
#
#    # This is the data services ID
#    serviceId = '2'
#
#    # Query the normalizer.  Use "default" in the path so we get the descriptions included in the response.  [Using "Ccd" only returns the name...]
#    program.props = {}
#    rsp = program.get("/ServiceType/beats/" + serviceId)
#    #print "GET of service ID " + serviceId + " succeeded"
#
#    # Parse the response into a dictionary
#    program.parse(rsp)
#    print str(program.props)
#
#    sys.exit()
    
    # Go through the entire list.  Want something that's per APN
    #for i in range(10000):

#===============================================================================
# This function returns normalizer list data
def viewNormalizerListData(idx, config):
    global retNormalizerListDct
    
    retDct = {}
    objectName = 'NormalizerValueList'
    
    # See if this object has been read and read if not
    if idx not in retNormalizerListDct:
        # Define entry
        retNormalizerListDct[idx] = {}
        
        # Get data from CB
        retDct = getNormalizerList(config, idx)
        retNormalizerListDct[idx] = copy.deepcopy(retDct)
        '''
        print('Normalizer list ' + str(idx) + ':')
        pprint.pprint(retDct)
        '''
        
        # Process attributes that have the name
        for attrib in retDct['object']['normalizer_value_list']['attrib']:
            # Get item components
            (attrName,attrValue) = attrib
            
            # Set locals
            if   attrName == 'name':    name = str(attrValue).replace('"','\'')
            
        # Set global data
        retNormalizerListDct[idx]['name'] = name
    
        # Now get the normalizer values
        retNormalizerListDct[idx]['values'] = {}
        
        # Get the values, as there are no results in a normalizer list
        for attrib in retDct['object']['normalizer_value_list']['values']['value']:
#         print 'attrib = ' + str(attrib)
          for entry in attrib['attrib']:
            # Split into parts
            (attrName,attrValue) = entry
            
            # Set locals
            if   attrName == 'index':   index = str(attrValue).replace('"','\'')
            elif attrName == 'name':    value = str(attrValue).replace('"','\'')
            
          # Append value to table list
          retNormalizerListDct[idx]['values'][index] = value
    else:
#       print 'Reusing retNormalizerListDct data for item ' + idx
        retDct = copy.deepcopy(retNormalizerListDct[idx])
    
    # Copy normalizers to returned structure
    retDct['values'] = copy.deepcopy(retNormalizerListDct[idx]['values'])
    
    # Set the name
    retDct['NAME'] = retNormalizerListDct[idx]['name']
    
    # ID was passed in
    retDct['ID'] = idx
    
    # Debug output
#   print 'Normalizer data for ' + str(idx) + ': '
#   pprint.pprint(retDct)
    
    return retDct
    
#===============================================================================
if __name__ ==  '__main__':
    main()

