#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Thu 2021-11-11T22:06:08
# @futurize --stage2 --no-diffs -n -w  : Thu 2021-11-11T22:06:08
#
# @futurize --stage1 --no-diffs -n -w  : Thu 2021-11-11T22:06:07
# -*- coding: utf-8 -*-
import os, subprocess, re

#===============================================================================
#
# Copyright 2010,2011,2012,2013,2014,2015,2016 Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

# Define special character XML encoding dictionary.
# https://en.wikipedia.org/wiki/List_of_XML_and_HTML_character_entity_references.
# Add only the special ones, as the basic ones don't need it.
# How to use this: from xml.sax.saxutils import escape; escape(string, specialEncodes).
specialEncodes = {}

# re search string (and example how to use) for OCS time stamps
timestamp = re.compile(r'(?P<year>[0-9][0-9][0-9][0-9])-'
        r'(?P<mon>[0-9][0-9])-'
    r'(?P<day>[0-9][0-9])T'
        r'(?P<hour>[0-9][0-9]):'
        r'(?P<min>[0-9][0-9]):'
        r'(?P<sec>[0-9][0-9])\.'
        r'(?P<msec>[0-9]+)'
        r'(?P<zonen>[-+])(?P<zoneh>[0-9][0-9]):(?P<zonem>[0-9][0-9])')
'''
m = timestamp.search('2020-10-29T12:13:14.120000+07:00')
print str(m.groupdict())
print str(m.group('year'))
'''

# Add customer-specific prefix here.  Makes life a lot easier...
customer = os.path.expandvars(os.getenv('customer', 'Mtx'))

# Define test directory - get from environment variables
testDir = os.path.expandvars(os.getenv('TESTS', '/home/mtx/workspace/trunk/MTXQA/Baseline/Tests')) + '/'

# Specify diameter dictionary details
confDir = os.path.abspath(os.path.expandvars(os.getenv('MTX_CONF_DIR', '/opt/mtx/conf')))
diamDictName = 'diameter_dictionary.xml'
diamFile = confDir + '/' + diamDictName

# Specify create_config.info details
custDir = os.path.expandvars(os.getenv('MTX_CUSTOM_DIR', '/opt/mtx/custom'))
createConfigName = 'create_config.info'
createConfigFile = custDir + '/' + createConfigName

# Get regression run value
regressionRun = os.path.expandvars('$regressionRun')
if regressionRun == '$regressionRun': regressionRun = 'restore'

# Get skipMyMatrixx run value
skipMyMatrixx = os.path.expandvars('$skipMyMatrixx')
if skipMyMatrixx == '$skipMyMatrixx': skipMyMatrixx = 'None'

# Define data that will save/restore (for speed)
EngineData = {}
savedEngineData = testDir + 'savedEngineData/'

# Make sure directory exists
if not os.path.exists(savedEngineData): os.makedirs(savedEngineData)

# Container Data
containerData = {}
containerDefFile = '/opt/mtx/conf/mdc_config_custom.xml'

# Defines HTTP string (http or https)
httpString = 'http'

# Get the port from the service config file
cmd="grep -A1 restgw /opt/mtx/services/config/config_primitives.ini | tail -1 | cut -f2 -d:"
p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
httpPort = p.stdout.read().strip().decode('utf-8')
#httpPort = '8080'

# Define username and passowerd for simple auth
simpleAuthUserName = None
simpleAuthPassword = None

# Define curl additional parameters to include
curlAdditionalParams = ' -H "Cache-Control: no-cache" -L -k '

# Payment gateway values (ID to name)
paymentGatewayIdMapping = {}
paymentGatewayIdMapping['0'] = 'braintree'
paymentGatewayIdMapping['2'] = 'recharge'
paymentGatewayIdMapping['3'] = 'cybersource'
paymentGatewayIdMapping['4'] = 'foomasterpass'
paymentGatewayIdMapping['5'] = 'payfort'
paymentGatewayIdMapping['6'] = 'romcard'
paymentGatewayIdMapping['10'] = 'other'

# Used to map update type numbers to names
UpdateTypeMapping = {}
UpdateTypeMapping['1'] = 'Charge'
UpdateTypeMapping['2'] = 'Discount'
UpdateTypeMapping['3'] = 'Grant'
UpdateTypeMapping['4'] = 'Adjustment'
UpdateTypeMapping['5'] = 'Cancel refund'
UpdateTypeMapping['6'] = 'Cancel forfeiture'
UpdateTypeMapping['7'] = 'Forfeiture'
UpdateTypeMapping['8'] = 'Usage refund'
UpdateTypeMapping['9'] = 'Transfer to'
UpdateTypeMapping['10'] = 'Transfer from'
UpdateTypeMapping['11'] = 'Rollover to'
UpdateTypeMapping['12'] = 'Rollover from'
UpdateTypeMapping['13'] = 'Payment'
UpdateTypeMapping['14'] = 'Tax'
UpdateTypeMapping['15'] = 'Cancellation Tax Refund'
UpdateTypeMapping['16'] = 'Usage Tax Refund'
# Why did I add a space before and after the next entry?  Removing for now...
UpdateTypeMapping['17'] = 'Recharge'
UpdateTypeMapping['18'] = 'Payment Refund'
UpdateTypeMapping['19'] = 'Late Charge'
UpdateTypeMapping['20'] = 'Early Termination_Charge'
UpdateTypeMapping['21'] = 'Write Off'
UpdateTypeMapping['22'] = 'Finance'
UpdateTypeMapping['23'] = 'Debt Payment'

# Used map revenue recognition numbers to names
RevenueRecognitionTypeMapping = {}
RevenueRecognitionTypeMapping['1'] = 'immediate'
RevenueRecognitionTypeMapping['2'] = 'specific date (not used)'
RevenueRecognitionTypeMapping['3'] = 'daily'
RevenueRecognitionTypeMapping['4'] = 'consumption'

# Diameter request type mappings.  NOTE: We use Radius values (we started a long time ago...)
diameterRequestTypeMapping = {}
diameterRequestTypeMapping['1'] = 'Event'
diameterRequestTypeMapping['2'] = 'Init'
diameterRequestTypeMapping['3'] = 'Update'
diameterRequestTypeMapping['4'] = 'Term'

