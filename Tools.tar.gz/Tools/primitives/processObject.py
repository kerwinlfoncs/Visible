#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Thu 2021-11-11T22:02:58
# @futurize --stage2 --no-diffs -n -w  : Thu 2021-11-11T22:02:58
#
# @futurize --stage1 --no-diffs -n -w  : Thu 2021-11-11T22:02:57
from __future__ import print_function
from __future__ import absolute_import
# from builtins import range
# from builtins import range
import sys, copy, pprint
from . import primHTTP as HTTP
from . import primGeneric as GENERIC
from . import primXML as XML
from . import primGET as GET
import xml.etree.ElementTree as ET

#================== Per-Object Processing functions  ================================================

#===============================================================================
def groupAdditionalItems(dctRcv, itemToQuery, cursor, program):
    # Loop while the cursor is non-zero
    while int(cursor) != 0:
        # Get the next set of data
        x = GET.getExtraGroupData(dctRcv['ObjectId'], itemToQuery, cursor, program)
        
            # Get top-level fields
        dict = {}
        dict = XML.getObjectBaseFields(x, dict)
    
        # Add objects to the existing  
        xmlDctName = './ObjectIdArray/value'
        for children in x.findall(xmlDctName): dctRcv[itemToQuery].append(children.text)
        
        # Get the cursor
        cursor = dict['QueryCursor']
    
#===============================================================================
#===============================================================================
def getGroupAdministrators(dctRcv, q, program):
    lclDctName = 'administrators'
    xmlDctName = './AdminIdArray/value'
    dctRcv[lclDctName] = []
    for children in q.findall(xmlDctName): dctRcv[lclDctName].append(children.text)
    if dctRcv['AdminCursor'] != '0': groupAdditionalItems(dctRcv, 'administrators', dctRcv['AdminCursor'], program)

#===============================================================================
def getGroupChildGroups(dctRcv, q, program):
    lclDctName = 'subgroups'
    xmlDctName = './GroupMemberIdArray/value'
    dctRcv[lclDctName] = []
    for children in q.findall(xmlDctName): dctRcv[lclDctName].append(children.text)
    if dctRcv['GroupMemberCursor'] != '0': groupAdditionalItems(dctRcv, 'subgroups', dctRcv['GroupMemberCursor'], program)

#===============================================================================
def getGroupChildSubs(dctRcv, q, program):
    lclDctName = 'subscribers'
    xmlDctName = './SubscriberMemberIdArray/value'
    dctRcv[lclDctName] = []
    for children in q.findall(xmlDctName): dctRcv[lclDctName].append(children.text)
    if dctRcv['SubscriberMemberCursor'] != '0': groupAdditionalItems(dctRcv, 'subscribers', dctRcv['SubscriberMemberCursor'], program)

#===============================================================================
def getGroupParent(dctRcv, q, program):
    lclDctName = 'groups'
    xmlDctName = './ParentGroupId'
    dctRcv[lclDctName] = []
    for children in q.findall(xmlDctName): dctRcv[lclDctName].append(children.text)

#===============================================================================
# Process group data
def processGroupDctData(dctRcv, q, configDct, options, queryFd, program):
    #XML.walkXmlData(q)
    
    # Get top-level fields
    dctRcv = XML.getObjectBaseFields(q, dctRcv)

    if 'RouteId' in list(dctRcv.keys()):
       program.RouteId = dctRcv['RouteId']
    
    # Get optional custom fields
    customName = 'groupCustomName'
    if customName in configDct: dctRcv = XML.getObjectCustomFields(q, dctRcv, configDct[customName])
    
    # *** Process admin list
    getGroupAdministrators(dctRcv, q, program)
    
    # *** Process Child Group list ***
    getGroupChildGroups(dctRcv, q, program)
    
    # *** Process subscriber list
    getGroupChildSubs(dctRcv, q, program)
    
    # *** Process Parent Group (no longer a list) ***
    getGroupParent(dctRcv, q, program)
    
    # *** Process offer array ***
    lclDctName = 'offers'
    xmlDctName = './PurchasedOfferArray/MtxPurchasedOfferInfo'
    customName = 'offerCustomName'
    dctRcv[lclDctName] = []
    dctRcv[lclDctName].extend(XML.getArrayData(xmlDctName, customName, q, configDct))
    
    # Offer queries do not return all the desired data, so need to add some here
    if options:
      for i in range(len(dctRcv[lclDctName])):
        offerDct = {}
        attrDct = {}
        (offerDct, attrDct) = GET.getOfferDctExplicitFields(program, dctRcv[lclDctName][i], options)
        dctRcv[lclDctName][i]['MtxPricingOfferDetailInfo'] = copy.deepcopy(offerDct)
        dctRcv[lclDctName][i]['attrDict'] = copy.deepcopy(attrDct)
#       (x, dctRcv[lclDctName][i]['Priority'], dctRcv[lclDctName][i]['Name'], dctRcv[lclDctName][i]['attrDict']) = GET.getOfferDctExplicitFields(program, dctRcv[lclDctName][i]['ProductOfferId'], options)
        
        # If part of a catalog item, then get catalog data
        if 'CatalogItemId' in dctRcv[lclDctName][i]:
            offerDct = {}
            attrDct = {}
            (offerDct, attrDct) = GET.getCatalogDctExplicitFields(program, dctRcv[lclDctName][i], options)
            dctRcv[lclDctName][i]['MtxPricingCatalogItemDetailInfo'] = copy.deepcopy(offerDct)
            dctRcv[lclDctName][i]['templateAttrDict'] = copy.deepcopy(attrDct)
        
    # *** Process balance array ***
    lclDctName = 'balances'
    xmlDctName = './BalanceArray/MtxBalanceInfo'
    customName = None
    dctRcv[lclDctName] = []
    dctRcv[lclDctName].extend(XML.getArrayData(xmlDctName, customName, q, configDct))

    # *** Process tier array ***
    lclDctName = 'tierBalances'
    xmlDctName = './TierBalancePurchasedOfferInfoArray/MtxTierBalancePurchasedOfferInfo'
    dctRcv[lclDctName] = []
    dctRcv[lclDctName].extend(XML.getArrayData(xmlDctName, customName, q, configDct))

    # If no options provided, then exit here
    if not options: return dctRcv
    
    # ***** Process group wallet
    # Read the wallet
    url = GET.urlObjectStart + 'group/' + dctRcv['ObjectId'] + '/wallet' + GENERIC.getTimeStampStr(options.date)
    (result, x) = HTTP.getAndVerifyHttpRequest(program, url)

    # Get bill cycle data
    lclDctName = 'billCycle'
    xmlDctName = './BillingCycle/MtxBillingCycleInfo'
    dctRcv[lclDctName] = {}
    dctRcv[lclDctName] = XML.getObjectStructureFields(x, dctRcv[lclDctName], xmlDctName)

    # Get next bill cycle data
    lclDctName = 'nextbillCycle'
    xmlDctName = './NextBillingCycle/MtxBillingCycleInfo'
    dctRcv[lclDctName] = {}
    dctRcv[lclDctName] = XML.getObjectStructureFields(x, dctRcv[lclDctName], xmlDctName)

    # Get additional data for each of the balances
    # Simple Balance array
    lclDctName = 'simpleBalanceInfo'
    xmlDctName = './BalanceArray/MtxBalanceInfoSimple'
    customName = None
    addlStructures = []
    addlStructures.append(('thresholds', './ThresholdArray/MtxThresholdInfo', 'array'))
    addlStructures.append(('recharge',   './RechargeInfo/MtxRechargeInfo', 'array', 'child'))
    dctRcv[lclDctName] = {}
    dctRcv[lclDctName] = XML.getArrayData(xmlDctName, customName, x, None, addlStructures)
    
    # Periodic Balance array
    lclDctName = 'periodicBalanceInfo'
    xmlDctName = './BalanceArray/MtxBalanceInfoPeriodic'
    customName = None
    addlStructures = []
    addlStructures.append(('thresholds', './ThresholdArray/MtxThresholdInfo', 'array'))
    addlStructures.append(('periods', './BalancePeriodArray/MtxBalancePeriodInfo', 'array'))
    addlStructures.append(('components', './ComponentMeterList/MtxComponentMeterInfo', 'array', 'child'))
    addlStructures.append(('fields', './FieldNameValueList/MtxFieldNameValueInfo', 'array', 'child2'))
    addlStructures.append(('subPeriod', './SubPeriodComponentList/MtxSubPeriodComponentInfo', 'array', 'child2'))
    dctRcv[lclDctName] = {}
    dctRcv[lclDctName] = XML.getArrayData(xmlDctName, customName, x, None, addlStructures)
    
    # Payment URLs added in 5080
    if int(options.release) >= 5080:
     # ***** Process payment data
     # Read data
     url = GET.urlObjectStart + 'group/' + dctRcv['ObjectId'] + '/payment_method' + GENERIC.getTimeStampStr(options.date)
     (result, x) = HTTP.getAndVerifyHttpRequest(program, url)
     
     lclDctName = 'PaymentMethod'
     xmlDctName = './PaymentMethodInfoList/MtxPaymentMethodInfo'
     dctRcv[lclDctName] = []
     for child in x.findall(xmlDctName):
        lclDCT = {}
        XML.getObjectBaseFields(child, lclDCT)
        dctRcv[lclDctName].append(copy.deepcopy(lclDCT))
    
    #pprint.pprint(dctRcv)
       
    return dctRcv
    
#===============================================================================
def processUserData(dctRcv, program, deviceId, queryType, configDct, options, queryFd):
        
    # Get main device data
    (result, q) = GET.getUserDctData(program, deviceId, queryType, options, queryFd)
    #ET.dump(q)
    
    # Process main data
    processUserDctData(dctRcv, q, configDct, options, queryFd, program)
    #pprint.pprint(dctRcv)
    
    # Get user auth data
    (result, q) = GET.getUserAuthDctData(program, deviceId, queryType, options, queryFd)
    
    # *** Process top-level info ***
    # Get top-level fields
    XML.getObjectBaseFields(q, dctRcv)
    #pprint.pprint(dctRcv)
    
    # Update route ID
    if 'RouteId' in list(dctRcv.keys()): program.RouteId = dctRcv['RouteId']
    
    # Return the dictionary
    return dctRcv
    
#===============================================================================
def processSubscriptionData(dctRcv, program, deviceId, queryType, configDct, options, queryFd):
        
    # Get main device data
    (result, q) = GET.getSubscriptionDctData(program, deviceId, queryType, options, queryFd)
    #ET.dump(q)
    
    # Process main data
    processSubscriptionDctData(dctRcv, q, configDct, options, queryFd, program)
    #pprint.pprint(dctRcv)
    
    # Update route ID
    if 'RouteId' in list(dctRcv.keys()): program.RouteId = dctRcv['RouteId']
    
    # Return the dictionary
    return dctRcv
    
#===============================================================================
def processDevData(dctRcv, program, deviceId, queryType, configDct, options, queryFd):
        
    # Get main device data
    (result, q) = GET.getDevDctData(program, deviceId, queryType, options, queryFd)
    #ET.dump(q)
    
    # Process main data
    processDevDctData(dctRcv, q, configDct, options, queryFd, program)
    #pprint.pprint(dctRcv)

    # Update route ID
    if 'RouteId' in list(dctRcv.keys()): program.RouteId = dctRcv['RouteId']
    
    # Policy added after 45xx
    # Also, don't read policy if not attached to a sub (error).
    if configDct['readSyPolicy'] and 'SubscriberId' in dctRcv:
        # Get policy data
        (result, q) = GET.getDevSyPolicy(program, dctRcv['ObjectId'])
        #ET.dump(q)
        
        # Process policay data
        dctRcv['SyPolicy'] = {}
        processDevPolicyData(dctRcv['SyPolicy'], q, configDct, options, queryFd, program)
        
    # If session data desired, get it
    if options.sessions: 
        # Get device session data
        (result, q) = GET.getDevSessionData(program, dctRcv['ObjectId'])
        #ET.dump(q)
    
        # Process session data
        dctRcv['sessions'] = {}
        processDevSessionData(dctRcv['sessions'], q, configDct, options, queryFd, program)
    
    # Return the dictionary
    return dctRcv
    
#===============================================================================
def processDevSessionData(dctRcv, q, configDct, options, queryFd, program):
    #XML.walkXmlData(q)
    
    # *** Process device-level info ***
    # Get top-level fields
    dctRcv = XML.getObjectBaseFields(q, dctRcv)
    
    # *** Process policy session array ***
    lclDctName = 'policySession'
    xmlDctName = './PolicySessionArray/MtxPolicySessionInfo'
    customName = None
    addlStructures = []
    addlStructures.append(('policy', './PolicyProfileNameArray/value', 'value'))
    dctRcv[lclDctName] = []
    dctRcv[lclDctName].extend(XML.getArrayData(xmlDctName, customName, q, configDct, addlStructures))
    #pprint.pprint(dctRcv[lclDctName])

    # *** Process charging session array ***
    lclDctName = 'chargingSession'
    xmlDctName = './ChargingSessionArray/MtxChargingSessionInfo'
    customName = None
    dctRcv[lclDctName] = []
    dctRcv[lclDctName].extend(XML.getArrayData(xmlDctName, customName, q, configDct))
    #pprint.pprint(dctRcv[lclDctName])

    # *** Process application session array ***
    lclDctName = 'applicationSession'
    xmlDctName = './ApplicationSessionArray/MtxApplicationSessionInfo'
    customName = None
    dctRcv[lclDctName] = []
    dctRcv[lclDctName].extend(XML.getArrayData(xmlDctName, customName, q, configDct))
    #pprint.pprint(dctRcv[lclDctName])

#===============================================================================
def processDevPolicyData(dctRcv, q, configDct, options, queryFd, program):
    #XML.walkXmlData(q)
    
    # *** Process device-level info ***
    # Get top-level fields
    dctRcv = XML.getObjectBaseFields(q, dctRcv)
    
    # *** Process policy array ***
    lclDctName = 'policy'
    xmlDctName = './PolicyCounterArray/MtxPolicyCounterInfo'
    customName = None
    dctRcv[lclDctName] = []
    dctRcv[lclDctName].extend(XML.getArrayData(xmlDctName, customName, q, configDct))
    #print 'processDevPolicyData: dctRcv[\'policy\'] = ' + str(dctRcv[lclDctName])

#===============================================================================
def processUserDctData(dctRcv, q, configDct, options, queryFd, program):
    #XML.walkXmlData(q)
    
    # *** Process top-level info ***
    # Get top-level fields
    dctRcv = XML.getObjectBaseFields(q, dctRcv)
    
    # Get optional custom fields
    customName = 'userCustomName'
    if customName in configDct: dctRcv = XML.getObjectCustomFields(q, dctRcv, configDct[customName].strip(), addExtension=False)
    
    # Get subscription data
    lclDctName = 'subscriptions'
    xmlDctName = './RelatedSubscriptionArray/MtxRelatedSubscriptionObject'
    addlStructures = []
    addlStructures.append(('accessNumbers', './AccessNumberArray/value', 'value'))
    addlStructures.append(('imsi', './ImsiArray/value', 'value'))
    addlStructures.append(('role', './RoleInfoArray/MtxPricingRoleInfo', 'array'))
    dctRcv[lclDctName] = []
    dctRcv[lclDctName].extend(XML.getArrayData(xmlDctName, None, q, configDct, addlStructures))
    
    # Get group data
    lclDctName = 'groups'
    xmlDctName = './RelatedGroupArray/MtxRelatedGroupObject'
    addlStructures = []
    addlStructures.append(('role', './RoleInfoArray/MtxPricingRoleInfo', 'array'))
    dctRcv[lclDctName] = []
    dctRcv[lclDctName].extend(XML.getArrayData(xmlDctName, None, q, configDct, addlStructures))
    
    '''
    print 'User Data:'
    pprint.pprint(dctRcv)
    '''
    
    return dctRcv
    
#===============================================================================
def processDevDctData(dctRcv, q, configDct, options, queryFd, program):
    #XML.walkXmlData(q)
    
    # *** Process device-level info ***
    # Get top-level fields
    dctRcv = XML.getObjectBaseFields(q, dctRcv)
    '''
    print 'processDevDctData, config dict:'
    pprint.pprint(configDct)
    '''
    
    # Get optional custom fields
    customName = 'deviceCustomName'
    addlStructures = []
    addlStructures.append(('accessNumbers', './AccessNumberArray/value', 'value'))
    if customName in configDct: dctRcv = XML.getObjectCustomFields(q, dctRcv, configDct[customName].strip(), addlStructures)
    
    # Get optional custom fields
    customName = 'loginCustomName'
    addlStructures = []
    addlStructures.append(('accessIdNumbers', './AccessIdArray/value', 'value'))
    if customName in configDct:
        dctRcv = XML.getObjectCustomFields(q, dctRcv, configDct[customName].strip(), addlStructures)
        '''
        ET.dump(q)
        pprint.pprint(dctRcv)
        '''
    
    # *** Process offer array ***
    lclDctName = 'offers'
    xmlDctName = './PurchasedOfferArray/MtxPurchasedOfferInfo'
    customName = 'offerCustomName'
    dctRcv[lclDctName] = []
    dctRcv[lclDctName].extend(XML.getArrayData(xmlDctName, customName, q, configDct))

    # Offer queries do not return all the desired data, so need to add some here
    for i in range(len(dctRcv[lclDctName])):
        offerDct = {}
        attrDct = {}
        #(x, dctRcv[lclDctName][i]['Priority'], dctRcv[lclDctName][i]['Name'], dctRcv[lclDctName][i]['attrDict']) = GET.getOfferDctExplicitFields(program, dctRcv[lclDctName][i]['ProductOfferId'], options)
        (offerDct, attrDct) = GET.getOfferDctExplicitFields(program, dctRcv[lclDctName][i], options)
        dctRcv[lclDctName][i]['MtxPricingOfferDetailInfo'] = copy.deepcopy(offerDct)
        dctRcv[lclDctName][i]['attrDict'] = copy.deepcopy(attrDct)
    
        # If part of a catalog item, then get catalog data
        if 'CatalogItemId' in dctRcv[lclDctName][i]:
            offerDct = {}
            attrDct = {}
            (offerDct, attrDct) = GET.getCatalogDctExplicitFields(program, dctRcv[lclDctName][i], options)
            dctRcv[lclDctName][i]['MtxPricingCatalogItemDetailInfo'] = copy.deepcopy(offerDct)
            dctRcv[lclDctName][i]['templateAttrDict'] = copy.deepcopy(attrDct)
        
    # *** Process tier array ***
    lclDctName = 'tierBalances'
    xmlDctName = './TierBalancePurchasedOfferInfoArray/MtxTierBalancePurchasedOfferInfo'
    dctRcv[lclDctName] = []
    dctRcv[lclDctName].extend(XML.getArrayData(xmlDctName, customName, q, configDct))

    #print 'Device Data: ' + str(dctRcv)
    return dctRcv
    
#===============================================================================
def getLevelFields(q, dctRcv, dataList):
        # Loop through entries
        for combo in dataList:
                # Get key fields
                field1 = combo[0]
                field2 = combo[1]

                # Look for top level items
                for item in q.findall(field1):
                        # Assume only one top level item (for now)
                        dctRcv[field1] = []

                        # Look for second level items
                        for itemDetails in item.findall(field2):
                                # Clear entry
                                tmpdctRcv = {}

                                # Get fields associated with this structure
                                XML.getObjectBaseFields(itemDetails, tmpdctRcv)

                                # Append to overall field array
                                dctRcv[field1].append(tmpdctRcv)

#===============================================================================
# This function will process the XML file associated with the APN Normalizer.
def processDevAggregation(dctRcv, oid, program, configDct):
        
    # Get device data
    (result, q) = GET.getDevAggregation(program, oid)
    
    # *** Process device-level info ***
    # Get top-level fields
    dctRcv = XML.getObjectBaseFields(q, dctRcv)
    
    # Process Primary event data
    # Get to the usage event
    if 'usageEventName' in configDct: 
      name = configDct['usageEventName']
    else: name = 'MtxDataEvent'
    
    # Build XML section name
    xmlDctName = './AggregationList/' + name
    
    dctRcv['Primary'] = {}
    for event in q.findall(xmlDctName):
        # Get top-level fields
        XML.getObjectBaseFields(event, dctRcv['Primary'])
    
        # Grab additional structure fields
        dataList = (('AppliedOfferArray',  'MtxEventAppliedOffer'),
                    ('BalanceUpdateArray', 'MtxBalanceUpdate'),
                    ('UsageQuantityList',  'MtxEventUsageQuantity'),
                    ('ChargeList',  'MtxEventCharge'),
                   )

        getLevelFields(event, dctRcv['Primary'], dataList)
    
        # Process Secondary event list
        lclDctName = 'SecondaryEventIdList'
        xmlDctName = './SecondaryEventIdList/value'
        dctRcv['Primary'][lclDctName] = []
        for children in event.findall(xmlDctName): dctRcv['Primary'][lclDctName].append(children.text)
    
    # Process Secondary event data
    # Build XML section name
    xmlDctName = './AggregationList/MtxSecondaryEvent'
    
    dctRcv['Secondary'] = {}
    for event in q.findall(xmlDctName):
        # Get top-level fields
        XML.getObjectBaseFields(event, dctRcv['Secondary'])
    
        # Grab additional structure fields
        dataList = (('AppliedOfferArray',  'MtxEventAppliedOffer'),
                    ('BalanceUpdateArray', 'MtxBalanceUpdate'),
                    ('UsageQuantityList',  'MtxEventUsageQuantity'),
                    ('ChargeList',  'MtxEventCharge'),
                   )
    
        getLevelFields(event, dctRcv['Secondary'], dataList)
    
    # *** Process service type, to get aggregation specifics ***
    # *** Really should do two additional steps:
    #   a) Input service type we care abouta  (2 is data...)
    #   b) Check if the rating group is reported and if so check if that has a context-specific aggregation specified
    (result, q) = GET.getServiceTypeInfo(program, '2')
    
    xmlDctName = './ServiceTypeInfo/MtxPricingServiceTypeDetailInfo'
    dctRcv['ServiceType'] = {}
    for children in q.findall(xmlDctName): XML.getObjectBaseFields(children, dctRcv['ServiceType'])
    
    return dctRcv
    
#===============================================================================
# This function will process Subscription XML data
def processSubscriptionDctData(dctRcv, q, configDct, options, queryFd, program):
    # For now this is a subscriber + related user
    dctRcv = processSubDctData(dctRcv, q, configDct, options, queryFd, program)
    
    return dctRcv
    
#===============================================================================
# This function will process Subscriber XML data
def processSubDctData(dctRcv, q, configDct, options, queryFd, program):
    #XML.walkXmlData(q)

    # Get top-level fields
    dctRcv = XML.getObjectBaseFields(q, dctRcv)
    if 'RouteId' in list(dctRcv.keys()):
       program.RouteId = dctRcv['RouteId']

    # Get optional custom fields
    customName = 'subscriberCustomName'
    if customName in configDct: dctRcv = XML.getObjectCustomFields(q, dctRcv, configDct[customName])
    
    # *** Process subscriber list
    #ET.dump(q)
    lclDctName = 'devices'
    xmlDctName = './DeviceIdArray/value'
    dctRcv[lclDctName] = []
    for children in q.findall(xmlDctName): dctRcv[lclDctName].append(children.text)
    #print 'Post device reading, devices are: ' + str(dctRcv[lclDctName])
    
    # *** Process Parent Group list ***
    lclDctName = 'groups'
    xmlDctName = './ParentGroupIdArray/value'
    dctRcv[lclDctName] = []
    for children in q.findall(xmlDctName): dctRcv[lclDctName].append(children.text)

    # *** Process admin list
    lclDctName = 'administrators'
    xmlDctName = './AdminGroupIdArray/value'
    dctRcv[lclDctName] = []
    for children in q.findall(xmlDctName): dctRcv[lclDctName].append(children.text)

    # *** Process offer array ***
    lclDctName = 'offers'
    xmlDctName = './PurchasedOfferArray/MtxPurchasedOfferInfo'
    customName = 'offerCustomName'
    addlStructures = []
    addlStructures.append(('cycleData', './CycleInfo/MtxPurchasedItemCycleInfo', 'struct'))
    addlStructures.append(('parameterData', './CatalogItemParameterArray/MtxPurchasedOfferParameterInfo', 'array'))
    for element in ['MtxParameterBoolValue', 'MtxParameterDateTimeValue', 'MtxParameterDecimalValue', 'MtxParameterInt32Value', 'MtxParameterInt64Value', 'MtxParameterStringValue', 'MtxParameterUnsignedInt32Value', 'MtxParameterUnsignedInt64Value']:
       # Set the field name to after the common prefix
       name = element[len('MtxParameter'):]
       addlStructures.append((name, './Value/' + element + '/Value', 'value', 'child'))
    addlStructures.append(('serviceContractData', './ContractStateInfo/MtxServiceContractStateInfo', 'struct'))
    addlStructures.append(('financeContractData', './ContractStateInfo/MtxFinanceContractStateInfo', 'struct'))
    dctRcv[lclDctName] = []
    dctRcv[lclDctName].extend(XML.getArrayData(xmlDctName, customName, q, configDct, addlStructures))
    #pprint.pprint(dctRcv[lclDctName])
    
    # Offer queries do not return all the desired data, so need to add some here
    if options:
      for i in range(len(dctRcv[lclDctName])):
        offerDct = {}
        attrDct = {}
        #(x, dctRcv[lclDctName][i]['Priority'], dctRcv[lclDctName][i]['Name'], dctRcv[lclDctName][i]['attrDict']) = GET.getOfferDctExplicitFields(program, dctRcv[lclDctName][i]['ProductOfferId'], options)
        (offerDct, attrDct) = GET.getOfferDctExplicitFields(program, dctRcv[lclDctName][i], options)
        dctRcv[lclDctName][i]['MtxPricingOfferDetailInfo'] = copy.deepcopy(offerDct)
        dctRcv[lclDctName][i]['attrDict'] = copy.deepcopy(attrDct)
        
        # If part of a catalog item, then get catalog data
        if 'CatalogItemId' in dctRcv[lclDctName][i]:
            offerDct = {}
            attrDct = {}
            (offerDct, attrDct) = GET.getCatalogDctExplicitFields(program, dctRcv[lclDctName][i], options)
            dctRcv[lclDctName][i]['MtxPricingCatalogItemDetailInfo'] = copy.deepcopy(offerDct)
            dctRcv[lclDctName][i]['templateAttrDict'] = copy.deepcopy(attrDct)
        
        #print 'Offer details: ' + str(dctRcv[lclDctName][i]['MtxPricingOfferDetailInfo'])
    
    # *** Process balance array ***
    lclDctName = 'balances'
    xmlDctName = './BalanceArray/MtxBalanceInfo'
    customName = None
    dctRcv[lclDctName] = []
    dctRcv[lclDctName].extend(XML.getArrayData(xmlDctName, customName, q, configDct))
    
    # *** Process tier array ***
    lclDctName = 'tierBalances'
    xmlDctName = './TierBalancePurchasedOfferInfoArray/MtxTierBalancePurchasedOfferInfo'
    dctRcv[lclDctName] = []
    dctRcv[lclDctName].extend(XML.getArrayData(xmlDctName, customName, q, configDct))

    # If no options provided, then exit here
    if not options: return dctRcv
    
    # ***** Process wallet
    # Read the wallet
    url = GET.urlObjectStart + 'subscriber/' + dctRcv['ObjectId'] + '/wallet' + GENERIC.getTimeStampStr(options.date)
    (result, x) = HTTP.getAndVerifyHttpRequest(program, url)

    #XML.walkXmlData(x)
    
    # Get bill cycle data
    lclDctName = 'billCycle'
    xmlDctName = './BillingCycle/MtxBillingCycleInfo'
    dctRcv[lclDctName] = XML.getObjectStructureFields(x, {}, xmlDctName)

    # Get next bill cycle data
    lclDctName = 'nextbillCycle'
    xmlDctName = './NextBillingCycle/MtxBillingCycleInfo'
    dctRcv[lclDctName] = XML.getObjectStructureFields(x, {}, xmlDctName)

    # Get additional data for each of the balances
    # Simple Balance array
    lclDctName = 'simpleBalanceInfo'
    xmlDctName = './BalanceArray/MtxBalanceInfoSimple'
    customName = None
    addlStructures = []
    addlStructures.append(('thresholds', './ThresholdArray/MtxThresholdInfo', 'array'))
    addlStructures.append(('recharge',   './RechargeInfo/MtxRechargeInfo', 'array', 'child'))
    dctRcv[lclDctName] = XML.getArrayData(xmlDctName, customName, x, None, addlStructures)
    #pprint.pprint(dctRcv[lclDctName])
    
    # Periodic Balance array
    lclDctName = 'periodicBalanceInfo'
    xmlDctName = './BalanceArray/MtxBalanceInfoPeriodic'
    customName = None
    addlStructures = []
    addlStructures.append(('thresholds', './ThresholdArray/MtxThresholdInfo', 'array'))
    addlStructures.append(('periods', './BalancePeriodArray/MtxBalancePeriodInfo', 'array'))
    addlStructures.append(('components', './ComponentMeterList/MtxComponentMeterInfo', 'array', 'child'))
    addlStructures.append(('fields', './FieldNameValueList/MtxFieldNameValueInfo', 'array', 'child2'))
    addlStructures.append(('subPeriod', './SubPeriodComponentList/MtxSubPeriodComponentInfo', 'array', 'child2'))
    dctRcv[lclDctName] = XML.getArrayData(xmlDctName, customName, x, None, addlStructures)
    
    # Want to grab data for every device, as we capture the key device items in the subscriber output
    for i in range(len(dctRcv['devices'])):
#       print 'read sub devices: ' + str(dctRcv['devices'])
        entry = {}
        entry = processDevData(entry, program, dctRcv['devices'][i], 'ObjectId', configDct, options, queryFd)
        dctRcv['devices'][i] = copy.deepcopy(entry)
        #print 'Post device read, devices are: ' + str(dctRcv['devices'])
    
    # Payment URLs added in 5080
    if int(options.release) >= 5080:
     # ***** Process payment method
     # Read data
     url = GET.urlObjectStart + 'subscriber/' + dctRcv['ObjectId'] + '/payment_method' + GENERIC.getTimeStampStr(options.date)
     (result, x) = HTTP.getAndVerifyHttpRequest(program, url)
     
     # Payment method array
     lclDctName = 'PaymentMethod'
     xmlDctName = './PaymentMethodInfoList/MtxPaymentMethodInfo'
     customName = None
     addlStructures = []
     dctRcv[lclDctName] = XML.getArrayData(xmlDctName, customName, x, None, addlStructures)
     
     # Get related user data
     lclDctName = 'users'
     xmlDctName = './RelatedUserArray/MtxRelatedUserObject'
     customName = None
     addlStructures = []
     addlStructures.append(('role', './RoleInfoArray/MtxPricingRoleInfo', 'array'))
     dctRcv[lclDctName] = []
     dctRcv[lclDctName].extend(XML.getArrayData(xmlDctName, customName, q, configDct, addlStructures))
    
    #pprint.pprint(dctRcv)
    
    # Return dictionary
    return dctRcv

#================== Main function  ================================================
def main():
    print('hello')

if __name__ ==  '__main__':
    main()

