#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Wed 2021-08-25T17:03:33
# @futurize --stage2 --no-diffs -n -w  : Wed 2021-06-23T15:27:35
#
# @futurize --stage1 --no-diffs -n -w  : Wed 2021-06-23T15:27:32
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================


import os,sys,re
import subprocess

def main():

    if len(sys.argv) > 1 :
        snmpAddr = sys.argv[1].strip()
        print("============  Querying ", snmpAddr)
    else:
        #set snmp address to the default localhost:4700
        snmpAddr = '127.0.0.1:14700'
            
    ntCmd='snmpwalk -Os -v 2c -c public -OQ '+snmpAddr+ ' MATRIXX-MIB::chrgMIBScalars'
    #print ntCmd
    #ntCmd = 'print_blade_stats.py -N | grep "Notifications Stats" -A 6'
    p = subprocess.Popen(ntCmd, shell=True, stdout=subprocess.PIPE)
    out = p.stdout.read().strip()
    vals={}
    if isinstance(out, bytes):
        out = out.decode('utf-8') #fix for python3

    for s in out.split('\n') :
        pair = s.split('=')
        vals[pair[0].strip()]=pair[1].strip()

    msgSent=vals['chrgNotificationOut.0']
    msgRcvd=vals['chrgNotificationProcessed.0']
    maxFail=vals['chrgNotificationMaxRetryFailures.0']
    notifySrvFailed=vals['chrgNotificationNotificationServerFailed.0']
    notifySrvFiltered=vals['chrgNotificationNotificationServerFiltered.0']  

    # print out stats
    print('Notifications Stats')
    print('-------------------')
    print('   Unique     ACKed                Notify    Notify')
    print(' Messages   Messages   MaxRetry    Server    Server')
    print('     Sent   Received   Failures  Failures  Filtered')
    print('=====================================================')
    print(' %9s %9s %9s %9s %9s' % (msgSent, msgRcvd, maxFail, notifySrvFailed, notifySrvFiltered ) )
    print() 


if __name__ == '__main__':
   main()
#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

     
