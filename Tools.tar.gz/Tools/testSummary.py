#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Wed 2021-08-25T17:03:58
# @futurize --stage2 --no-diffs -n -w  : Wed 2021-06-23T15:28:12
#
# @futurize --stage1 --no-diffs -n -w  : Wed 2021-06-23T15:28:09

# from builtins import str
import sys, os, re
import optparse
import qa_utils as QAUTILS
import csv

qaDir = os.path.abspath(os.path.expandvars(os.getenv('QADIR', '.')))
#print qaDir
suiteDirRoot = qaDir +'/QA/Tests/main_tests_driver/QA/'
#print suiteDirRoot
testSummaryFile = suiteDirRoot+'testSummary.csv'
featuresSummaryFile = suiteDirRoot+'featuresSummary.csv'
featuresSummaryDict = {}
ratingList = ['mtx_tests_TimeToChange','mtx_tests_all_prorations','mtx_tests_balances','mtx_tests_beat_group',
             'mtx_tests_billing','mtx_tests_cancel','mtx_tests_cycle_grant_amt','mtx_tests_deny_usage','mtx_tests_fair_share_proration','mtx_tests_interim','mtx_tests_meters',
             'mtx_tests_misc','mtx_tests_normalizers','mtx_tests_offer_priority','mtx_tests_offers','mtx_tests_price_components','mtx_tests_quota_management',
             'mtx_tests_rate_tables','mtx_tests_threshold','mtx_tests_timezone_change','mtx_tests_pricing_revision','mtx_tests_limited_charge','mtx_tests_task_man',
              'mtx_test_immediate_events_charging','mtx_tests_bal_validity_extension','mtx_tests_autorenew','mtx_tests_balance_overdraft','mtx_tests_balance_rollover',
             'mtx_tests_balance_tracking','mtx_tests_bundles','mtx_tests_execute_mode','mtx_tests_expose_bal_enddate','mtx_tests_fui','mtx_tests_global_offers','mtx_tests_jira',
              'mtx_tests_modify_bal_start_time','mtx_tests_non_mobile_device','mtx_tests_offer_cost','mtx_tests_purchased_item_cycle', 'mtx_tests_autorecharge',
              'mtx_tests_session_tools','mtx_tests_system_attributes']


submanList = ['mtx_tests_status_lifecycle','mtx_tests_subman','mtx_tests_status','mtx_tests_offer_startenddate_type','mtx_tests_quarantined_object',
              'mtx_tests_event_types','mtx_tests_groups','mtx_tests_large_groups_mgmt']

aqmList = ['mtx_tests_AQM']
edrList = ['mtx_tests_EDRs']
rarList = ['mtx_tests_RAR']
policyList = ['mtx_tests_gx','mtx_tests_pcrf']
priceLoaderList = ['mtx_tests_cb_priceloader']
diameterList = ['mtx_tests_mscc','mtx_tests_diameter','mtx_tests_selective_update']

notificationList = ['mtx_tests_notifications','mtx_tests_offer_expiration_notifications','mtx_tests_notifications_allowed_delay', 'mtx_tests_multiple_notifications'] 
rehomeList = ['mtx_tests_group_rehome', 'mtx_tests_device_rehome', 'mtx_tests_subscriber_rehome']
camelNotifierList = ['mtx_tests_notifier_camel']
paynowList = ['mtx_tests_paynow']
rsgatewayList = ['mtx_tests_pricing_cache','mtx_tests_rsgateway_misc','mtx_tests_rsgateway_rating','mtx_tests_rsgateway_security']
taxList = ['mtx_tests_taxation', 'mtx_tests_tax']


def getInputOption():
    ########### Do command line processing ###################
    parser = optparse.OptionParser()
    parser.add_option("-b", "--buildNo", action='store', type='int', default=None, help='931')
    parser.add_option("-s", "--suiteDir", action='store', type='string', default=None, help='"base_results;vtime_results"')
    parser.add_option("-a", "--add", action='store', type='string', default=None, help="custom.csv")
    #parser.add_option("-m", "--html", action='store', type='string', default=None)

    # Process command line params
    (options, args) = parser.parse_args()

    # If no input directory or filename specified, then error
    #if not options.suiteDir and not options.buildNo:
    #    sys.exit('ERROR - no suite directory or buildNo specified')

    return options

def featureTestCount(baseDict,featureList):
    #map test suites to rating feature
    passCnt = failCnt = 0
    for test in featureList:
        if test in baseDict:
           tempArr = baseDict[test].split(',')
           passCnt = passCnt + int(tempArr[0])
           failCnt = failCnt + int(tempArr[1])

    if featureList is ratingList:
       featureName = 'Charging Server'
    
    if featureList is submanList:
       featureName = 'Subscriber Management'

    if featureList is notificationList:
       featureName = 'Charging Notification'

    if featureList is diameterList:
       featureName = 'Diameter Return Code'

    if featureList is aqmList:
       featureName = 'Adaptive Quota Management'

    if featureList is rarList:
       featureName = 'Offer Purchased/Cancelled/Gy RAR'

    if featureList is edrList:
       featureName = 'Event Data Record'    

    if featureList is priceLoaderList:
       featureName = 'Load_Pricing Tool'

    if featureList is paynowList:
       featureName = 'PayNow'

    if featureList is policyList:
       featureName = 'Charging Policy'

    if featureList is rehomeList:
       featureName = 'Charging Rehome'

    if featureList is camelNotifierList:
       featureName = 'Notification Server'

    if featureList is rsgatewayList:
       featureName = 'Rsgateway Operation'

    if featureList is taxList:
       featureName = 'Charging Taxation'

    featuresSummaryDict[featureName] = str(passCnt)+','+str(failCnt)
 
def mapSuitesToFeatures(baseDict):
    if not os.path.exists(testSummaryFile):
       sys.exit('testSummary.csv file not exists')

    #map test suites to rating feature
    featureTestCount(baseDict,ratingList) 
    #map test suites to subman feature 
    featureTestCount(baseDict,submanList)

    #map test suites to notification feature
    featureTestCount(baseDict,notificationList)

    #map test suites to diameter feature
    featureTestCount(baseDict,diameterList)

    #map test suites to aqm feature
    featureTestCount(baseDict,aqmList)

    #map test suites to rar feature

    featureTestCount(baseDict,rarList)

    #map test suites to edr feature
    featureTestCount(baseDict,edrList)
    
    #map test suites to priceloader feature
    featureTestCount(baseDict,priceLoaderList)

    #map test suites to paynow feature
    featureTestCount(baseDict,paynowList)

    #map test suites to Gx and Sy feature
    featureTestCount(baseDict,policyList)

    #map test suites to charing rehome feature
    featureTestCount(baseDict,rehomeList)

    #map test suites to camel notifer  feature
    featureTestCount(baseDict,camelNotifierList)

    #map test suites to camel Rsgateway Operation  feature
    featureTestCount(baseDict,rsgatewayList)

    #map test suites to camel charging Taxation  feature
    featureTestCount(baseDict,taxList)

 

    printFinalSummaryCsv('feature',featuresSummaryDict)


def printFinalSummaryCsv(fileType, suiteDict):

    #fileName = suiteDirRoot+'testSummary.csv' 
    #print 'final filename=' , fileName
    if fileType == 'suite':
       fileName = testSummaryFile
    elif fileType == 'feature':
       fileName = featuresSummaryFile
    else :
       sys.exit('file not supported')

    #if not os.path.exists(fileName):
    #   sys.exit(fileName +' not exists')
    passCnt = failCnt = 0
    f  = open(fileName, "w")
    for test in sorted(suiteDict):
        testsNo = 0
        tempArr = suiteDict[test].split(',')
        passCnt = passCnt + int(tempArr[0])
        failCnt = failCnt + int(tempArr[1])
        testsNo = int(tempArr[0]) + int(tempArr[1]) 
        line = test+','+suiteDict[test]+','+str(testsNo)+'\n'
        #print line
        f.write(line)
    testsNo = passCnt + failCnt
    totalLine = 'Total,'+str(passCnt)+','+str(failCnt)+','+str(testsNo)+'\n'
    #print totalLine
    f.write(totalLine)
    f.close() 

def addCustCsvFile(custCsvFile):
    if os.path.exists(custCsvFile) and os.path.exists(featuresSummaryFile):
       #append custom csv entries to featureSummayr file
       cmd="sed \'/Total/d\' "+ " " + featuresSummaryFile + " > tmp.csv ; cat tmp.csv " +  custCsvFile + " > " + featuresSummaryFile
       #print cmd
       QAUTILS.runCmd(cmd)         
       #re-count the total # of test cases
       passCnt = failCnt = 0
       f  = open(featuresSummaryFile, "r+")
       lines = f.readlines() 
       for line in lines:
          testsNo = 0
          tempArr = line.split(',')
          passCnt = passCnt + int(tempArr[1])
          failCnt = failCnt + int(tempArr[2])
          testsNo = int(tempArr[1]) + int(tempArr[2])
       testsNo = passCnt + failCnt
       totalLine = 'Total,'+str(passCnt)+','+str(failCnt)+','+str(testsNo)+'\n'
       #print totalLine
       f.write(totalLine)
       f.close()
       sys.exit('custom csv files added successfully')
    else:
        sys.exit('not able to find featureSummary csv file or custom csv file')

#=====================================================================================
def mergeSummaryCsv(suiteList):

    #initialize suite
    baseDict = vtimeDict = notifDict = {}
    for suite in suiteList:
      #read the testSummary of suite and save to suiteList
      fileName = suiteDirRoot+suite+'/'+suite+'_testSummary.csv'
      #print "filename=", fileName
      nSuite = re.findall(r'.*_results',suite)
      if os.path.exists(fileName) :
         f  = open(fileName, "rb")
         content = f.readlines()
         tmpDict = {}
         for row in content:
            row = row.strip()
            tempArr = row.split(',')
            tmpDict[tempArr[0]] = tempArr[1]+','+tempArr[2]
        
         f.close()
         #print 'suite =',suite
         if nSuite[0] == 'base_results':
            baseDict = tmpDict
           #print 'baseDict=',baseDict
         if nSuite[0] == 'vtime_results':
            vtimeDict = tmpDict
            #print 'vtimeDict =', vtimeDict
         if nSuite[0] == 'notification_results' :
            notifDict = tmpDict
            #print 'notifDict =', notifDict

    #merge vtime pass & fail number  to  base suite
    if baseDict and vtimeDict:
       for test in vtimeDict:
           if test in baseDict: 
           #find the same est in two suites, add the pass and fail no from each other
              baseArr = baseDict[test].split(',') 
              vtimeArr = vtimeDict[test].split(',')
              passCnt = int(baseArr[0]) + int(vtimeArr[0])
              failCnt = int(baseArr[1]) + int(vtimeArr[1])
              newCtn = str(passCnt)+','+str(failCnt)
              #update new pass & fail cnt to base suite
              baseDict[test] = newCtn
           else:
           #add test case not in base suite to baseDict
              baseDict[test] = vtimeDict[test]
       #print 'new base dict = ', baseDict
       #print len(baseDict)

    if baseDict and notifDict:
       for test in notifDict:
          #add offer expiration notification to base dict
          baseDict[test] = notifDict[test] 
       #print 'new base dict with notification= ', baseDict
       #print len(baseDict)
    
    printFinalSummaryCsv('suite',baseDict) 
    mapSuitesToFeatures(baseDict)
   
#===============================================================================
def createSummaryCsv(buildNo,suiteList):
    #check if buildNo is valid
    passFile = 'build'+str(buildNo)+'_Passed_tests'
    failFile = 'build'+str(buildNo)+'_Failed_tests'

    #chck suite name, allow multiple suites 
    for suite in suiteList:
       dir =  suiteDirRoot+suite
      # print 'dir=',dir
       if not os.path.exists(dir) :
           sys.exit('suite directory not found\n')
       passFile1 = QAUTILS.runCmd('ls '+dir+' | grep '+passFile)
       #print passFile1
       failFile1 = QAUTILS.runCmd('ls '+dir+' | grep '+failFile)     
       #print failFile1 
       if passFile1 and failFile1:
          QAUTILS.runCmd('cd '+dir +';cut -f 2 -d\'/\' '+ passFile1+' | sort | uniq -c > my.pass')
          QAUTILS.runCmd('cd '+dir +';cut -f 2 -d\'/\' '+  failFile1+'| sort | grep -v TRACE | grep -v == |  grep -v _test_ | uniq -c > my.fail')
          QAUTILS.runCmd('cd '+dir +';join -a1 -a2 -1 2 -2 2 -o 0 1.1 2.1 -e "0" my.pass my.fail | sed "s/ /,/g" > '+ suite+'_testSummary.csv')     
 
def main():

    # Path is always the current directory
    options = getInputOption()

    #optional argument
    if options.add:
       custCsvFile = options.add
       #print custCsvFile
       addCustCsvFile(custCsvFile)

    # Input file required for this service
    if not options.buildNo:
        print('ERROR:  must provide an buildNo.')
        sys.exit('Exiting due to errors')

    if not options.suiteDir:
        print('ERROR:  must provide suiteDir, can be one or multiple dirs: e.g. : base_result;vtime_results')
        sys.exit('Exiting due to errors')

    
    # process CBObject csv file
    #print "buildNo = " + str(options.buildNo)
    #print "suitelist =" , options.suiteDir    
    suiteList = options.suiteDir.split(';')
   # print suiteList

    createSummaryCsv(options.buildNo,suiteList)
    #no need to merge if only one suite
    if len(suiteList) == 1:
       sys.exit(0)
    # merge the suites summary tests only for base, vtime and notification suites
    for suite in suiteList:
       nSuite = re.findall(r'.*_results',suite) 
       if nSuite[0] != 'base_results' and nSuite[0] != 'vtime_results' and nSuite[0] != 'notification_results':
          print('suite not able to be merged')
          sys.exit(0)

    mergeSummaryCsv(suiteList)
    

if __name__ ==  '__main__':
    main()

