#/bin/bash

if [ $# -ne 4 ]
then
   echo 'usage: wgetrpm <release> <buildid> <rpms> <os>'
   exit 0
fi

release=$1
buildId=$2
rpms=$3
os=$4

if [ $os == "rh7" ]
then
   osId=$2.el7
fi

if [ $os == "rh6" ]
then
   osId=$2.el6
fi

echo $osId

relpre=${release:0:3}
echo $release
echo $relpre

#echo $relpre
siteip_b2="10.10.86.51"
siteip_b3="10.10.116.245"
siteip_b4="10.10.86.53"
siteip_b6="10.10.86.55"
branch=""

case $relpre in
         "475")
             echo 475x release
             siteip=$siteip_b3
             echo $siteip
             branch="MTX3-B4750"
             ;;
          "506")
             echo 506x release
             if [ $os == "rh7" ]
             then
                siteip=$siteip_b4
                echo $siteip
                branch="MTX4-R506X"
             fi
	     ;;
         "505")
             echo 505x release
             if [ $os == "rh7" ]
             then
                siteip=$siteip_b4
                echo $siteip
                branch="MTX4-B505X"
             else
                siteip=$siteip_b3
                echo $siteip
                branch="MTX3-B505X"
             fi
             ;;
          "507")
             echo 507x release
             if [ $os == "rh7" ]
             then
                siteip=$siteip_b4
                echo $siteip
                branch="MTX4-R507X"
             fi
             ;;
         "471")
             echo 471x release
             siteip=$siteip_b3
             echo $siteip
             branch="MTX3-REL"
             ;;
         "462")
             echo 46XX release
             siteip=$siteip_b3
             echo $siteip
             branch="MTX3-B46XXNIGHTLY"
             ;;
         "508")
             echo 508X release
             siteip=$siteip_b6
             echo $siteip
             branch="MTX6-R508X"
             ;;
         "510")
             echo 5100 release
             siteip=$siteip_b6
             echo $siteip
             branch="MTX6-TRUNK"
             ;;
         "461")
             echo 461X release
             siteip=$siteip_b3
             echo $siteip
             branch="MTX3-B461XNIGHTLY"
             ;;
         *)
             echo not a valid release
             exit
             ;;
esac

echo $release
job="job-"$branch
echo $job

cd /tmp

if [ $buildId == "latest" ]
then
     wget http://$siteip:8085/browse/$branch/latestSuccessful
     if [ -f ./latestSuccessful ]
     then
        buildId=`grep $job latestSuccessful | cut -d'=' -f2 | cut -d'-' -f 5 | cut -d' ' -f1 | sed 's/\"//'`
        echo $buildId
        rm ./latestSuccessful
     else
        echo wget get latest build failed
        exit 0
     fi

fi

if [ $rpms == "all" ]
then
   for rpm in activemq-connector engine proxy-server network-enabler traffic-routing-agent notifier
   do
      wget http://$siteip:8085/artifact/$branch/JOB1/build-$buildId/Packages/RPMS/x86_64/matrixxsw-$rpm-$release-$osId.x86_64.rpm
   done
else
   wget http://$siteip:8085/artifact/$branch/JOB1/build-$buildId/Packages/RPMS/x86_64/matrixxsw-$rpms-$release-$osId.x86_64.rpm
fi


