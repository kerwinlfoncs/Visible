#!/bin/bash
#Prerequisites: mtx user needs to have privilege to /bin/su 

usage()
{
cat << EOF
usage: $0 options

This script allow to start activemq , activeConnector , notifier and notifier client
also allow to configure activemaConnector to be configured as activemq ack queue mode. 
aka 2 phase management notification

OPTIONS:
   -h      Show this message
   -m      configure activemq ack queue mode, 1 is to turn on 2 phase management notification, 0 is off
   -p      optional path for amq, default is  /opt/ActiveMQ
   -d      optional argument for diameter address of activemq ack queue mode 1
EOF
}

while getopts ":m:p:d:" OPTION;
do
     case $OPTION in
         m)
             ackQueueMode=$OPTARG
             echo $ackQueueMode
             ;;
         p)
             ackPath=$OPTARG
             echo $ackPath
             ;;
         d)
             diamAddr=$OPTARG
             echo $diamAddr
             ;;
         *)
             usage
             exit
             ;;
     esac
done

if [ -z $ackPath ]
then
   echo 'use default activemq root path, /opt/ActiveMQ'
   ackPath='/opt/ActiveMQ'
fi

if [ -z $ackQueueMode ]
then
   echo 'use default 2 phahses management mode'
   ackQueueMode=1
fi

echo $diamAddr
if [ -z $diamAddr ]
then
   echo 'use 127.0.0.1 as default diameter address'
   diamAddr='127.0.0.1'
fi

$ackPath/apache-activemq-5.*.0/bin/activemq start

sleep 5
#wait for amq to start
netout=`netstat -an | grep 61616 | grep LISTEN`
echo $netout
if [ ${#netout} -eq 0 ]
then
    echo activemq is not started, port 61616 not established
    exit 0
fi

echo $diamAddr

#cp create_config.infi from /opt/mtx/custom to /opt/mtx_activemq/custom
sudo su - mtx_activemq -c "cp /opt/mtx/custom/create_config.info /opt/mtx_activemq_connector/custom"
#configure connector to be 2 phahses management notificaiton as default 
#set use_activemq_ack_queue to be 1
if [ $ackQueueMode -eq 1 ]
then 
   echo 'enable use 2 phahses management  notification configuration '
   sudo su - mtx_activemq -c "cd /opt/mtx_activemq_connector/custom; sed -i \"s/ActiveMQConnector:Do you want to configure acknowledgement queue (y\/n)?.*/ActiveMQConnector:Do you want to configure acknowledgement queue (y\/n)?y/\" create_config.info"
   sudo su - mtx_activemq -c "cd /opt/mtx_activemq_connector/custom;sed -i \"s/ActiveMQConnector:Engine 1:Cluster 1:What is the IP address and port number of the diameter gateway?.*/ActiveMQConnector:Engine 1:Cluster 1:What is the IP address and port number of the diameter gateway?$diamAddr:3868/\" create_config.info"
elif [ $ackQueueMode -eq 0 ]
then
   echo 'set value <use_activemq_ack_queue> to be 0, disable 2 phase management notification'
  sudo su - mtx_activemq -c "cd /opt/mtx_activemq_connector/custom; sed -i \"s/ActiveMQConnector:Do you want to configure acknowledgement queue (y\/n)?.*/ActiveMQConnector:Do you want to configure acknowledgement queue (y\/n)?n/\" create_config.info"
else
   echo 'not a valid mode , use 0 or 1' 
   usage
   exit
fi

#update timeout=1
#sudo su - mtx_activemq -c "cd /opt/mtx_activemq_connector/custom; sed -i \"s/timeout=1000/timeout=1/\" create_config.info"
#start activemq connector
sudo su - mtx_activemq -c "cd /opt/mtx_activemq_connector/custom; create_config.py;/opt/mtx_activemq_connector/bin/start_activemq_connector.py"

#wait for amq connector to be started
sleep 1
/opt/mtx/bin/mtx_notifier.sh start

#sleep 3
exit 0
#don't start notifier client for now
#remove notification.tx file, start the notifier client
logDir=${QADIR}/QA/Tests/main_tests_driver/QA/log
if [ ! -d $logDir ]
then
    mkdir -p $logDir 
fi

ntoutfile=$logDir/notification.txt
dateStr="`date '+%Y_%m_%d_%H_%M_%S'`"
if [ -f $ntoutfile ]
then
   mv $logDir/notification.txt $logDir/notification_$dateStr.txt
fi

cd /opt/mtx/bin
/usr/bin/java -jar mtx_notification_client.jar -address:tcp://127.0.0.1:61616 matrixx.all >> $logDir/notification.txt 2>&1 &
sleep 1
pid=""
pid=`ps -ef | grep  mtx_notification_client.jar | grep -v grep | awk {'print $2'}`
echo starting notifier client...pid=$pid
