#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Thu 2021-11-11T22:33:26
# @futurize --stage2 --no-diffs -n -w  : Thu 2021-11-11T22:33:26
#
# @futurize --stage1 --no-diffs -n -w  : Thu 2021-11-11T22:33:26

# import system primitives
from __future__ import print_function
# from builtins import str
# from builtins import range
from future import standard_library
standard_library.install_aliases()
# from builtins import str
# from builtins import range
import sys, os, re, copy, pprint
try:
    import configparser
except:
    from six.moves import configparser
import optparse
import time
#pylint: disable=import-error,multiple-imports
#pylint: disable=import-error,multiple-imports
#pylint: disable=import-error,multiple-imports
#pylint: disable=import-error,multiple-imports
import urllib.request, urllib.parse, urllib.error
import http.client
import xml.etree.ElementTree as ET
from subprocess import call

# Import MTX primitives
from primitives import validateData     as VAL
from primitives import primHTTP         as HTTP
from primitives import primXML          as XML
from primitives import primGET          as GET
from primitives import primGeneric      as GENERIC
from primitives import processObject    as PROCESS
from primitives import primData         as PRIMDATA

# Import tool-specific primitives
from viewObjectData import printObject  as PRT
from viewObjectData import inputObject  as INPUT
from viewObjectData import configObject as CONFIG

#================== Global Data  ================================================

#================== Set of control functions for each supported object ================================================

#===============================================================================
# View User details
def viewUser(objDct, options, program, configDct, queryFd, priceData):
        # List of IDs to process
        ids = []

        # Get ID and type to use
        if options.userId:
                ids.append(options.userId)
                queryType = 'UserId'
        elif options.uxid:
                ids.append(options.uxid)
                queryType = 'ExternalId'
        elif options.uoid:
                ids.append(options.uoid)
                queryType = 'ObjectId'
        else:   sys.exit("ERROR: Invalid USer Object option specified")

        # Process each of the IDs
        for id in ids:
                ############## Process user data #################
                objDct = PROCESS.processUserData(objDct, program, id, queryType, configDct, options, queryFd)

                ############## Output object data in nice format #################
                PRT.outputUserData(objDct, configDct, id, queryType, options, program=program)

                # May need to process wider scope
                if options.scope and options.scope.lower().count('down') and 'subscriptions' in objDct and len(objDct['subscriptions']):
                        for subscription in objDct['subscriptions']:
                                # Always have an OID
                                options.suboid = subscription['ObjectId']
                                viewSubscription(objDct, options, program, configDct, queryFd, priceData)

#===============================================================================
# View Subscription details
def viewSubscription(objDct, options, program, configDct, queryFd, priceData):
        # List of IDs to process
        ids = []

        # Get ID and type to use
        if options.subxid:
                ids.append(options.subxid)
                queryType = 'ExternalId'
        elif options.suboid:
                ids.append(options.suboid)
                queryType = 'ObjectId'
        else:   sys.exit("ERROR: Invalid Subscription Object option specified")

        # Process each of the IDs
        for id in ids:
                ############## Process object data #################
                objDct = PROCESS.processSubscriptionData(objDct, program, id, queryType, configDct, options, queryFd)
                #pprint.pprint(objDct)

                # If any parent groups, then more work to do
                if len(objDct['groups']): objDct = getGroupOffers(objDct, options, program, configDct, queryFd, 'sub', priceData, id, queryType)

                ############## Output object data in nice format #################
                PRT.outputSubscriptionData(objDct, configDct, id, queryType, options, program=program)

                # Save dictionary
                objList = copy.deepcopy(objDct)

                # May need to process wider scope
                if options.scope and options.scope.lower().count('up') and 'users' in objDct and len(objDct['users']):
                        # Process each user
                        for user in objDct['users']:
                                options.uoid = user['ObjectId']

                                # Output user data
                                objDct = {}
                                viewUser(objDct, options, program, configDct, queryFd, priceData)

                        # Restore dictionary
                        objDct = copy.deepcopy(objList)

                # If scope is set to up and we have parent groups, then process each of the groups
                if options.scope and options.scope.lower().count('up') and 'groups' in objDct and len(objDct['groups']) > 0:
                        # Process each of the groups
                        #print 'Processing data = ' + str(objDct)
                        for i in range(len(objDct['groups'])):
                                # Set the options value
                                options.goid = objList['groups'][i]

                                #print 'Processing group OID = ' + options.goid

                                # View the group
                                objDct = {}
                                viewGroup(objDct, options, program, configDct, queryFd, priceData)

                        # Restore dictionary
                        objDct = copy.deepcopy(objList)

                # If scope is set to down and we have devices, then process each of the devices
                if options.scope and options.scope.lower().count('down') and 'devices' in objDct and len(objDct['devices']) > 0:
                        # Get device list
                        devices = copy.deepcopy(objDct['devices'])

                        # Loop through each device
                        for i in range(len(devices)):
                                # Get oid into input structure
                                options.doid = devices[i]['ObjectId']

                                # Run the command
                                objDct = {}
                                viewDevice(objDct, options, program, configDct, queryFd, priceData)

                        # Restore dictionary
                        objDct = copy.deepcopy(objList)

#===============================================================================
# View Device details
def viewDevice(objDct, options, program, configDct, queryFd, priceData):
    # List of IDs to process
    ids = []

    ############## Get device ID information  #################
    # Devices can be queried by subscriber processing.  At that point the
    # device ID is known, so it's passed in to the device processing function.
    # Need some up-front logic here to set the ID properly.
    if options.imsi:
        ids.append(options.imsi)
        queryType = 'imsi'
    elif options.deviceId:
        ids.append(options.deviceId)
        queryType = 'imsi'
    elif options.dx:
        ids.append(options.dx)
        queryType = 'ExternalId'
    elif options.msisdn:
        ids.append(options.msisdn)
        queryType = 'msisdn'
    elif options.doid:
        ids.append(options.doid)
        queryType = 'ObjectId'
    elif options.LoginId:
        ids.append(options.LoginId)
        queryType = 'LoginId'
    elif options.accessId:
        ids.append(options.accessId)
        queryType = 'AccessId'
    elif options.dofile:
        # Add the file contents to the array
        f = open(options.dofile, 'r')
        for line in f:
                if line.strip(): ids.append(line.strip())
        queryType = 'ObjectId'
    elif options.difile:
        # Add the file contents to the array
        f = open(options.difile, 'r')
        for line in f:
                if line.strip(): ids.append(line.strip())
        queryType = 'imsi'
    elif options.dmfile:
        # Add the file contents to the array
        f = open(options.dmfile, 'r')
        for line in f:
                if line.strip(): ids.append(line.strip())
        queryType = 'msisdn'
    else:
        # Not sure what to do here...
        print('ERROR:  No device specific input entered.  Can\'t process the request.  Input was: ' + str(options))
        sys.exit('Exit due to errors')

    # Process each of the IDs
    for id in ids:
        ############## Build current object lists #################
        objDct = PROCESS.processDevData(objDct, program, id, queryType, configDct, options, queryFd)

        ############## Output data in nice format #################
        PRT.outputDeviceData(objDct, configDct, id, queryType, options)

        # If aggregations asked for, process those
        if options.aggregation or options.allExtraData:
                oid = objDct['ObjectId']
                objDct = {}
                objDct = PROCESS.processDevAggregation(objDct, oid, program, configDct)
                #print 'Device Aggregation data:' + str(objDct)
                PRT.outputDeviceAggregation(objDct, configDct, id, queryType, options)

        # May need to process wider scope
        if options.scope and options.scope.lower().count('up'):
                # Set options subscriber OID value
                options.soid = objDct['SubscriberId']

                # Clear dictionary
                objDct = {}

                # View this object
                viewSubscriber(objDct, options, program, configDct, queryFd, priceData)

        # Clear RouteId
        program.RouteId = ''

#===============================================================================
def getGroupOffers(objDct, options, program, configDct, queryFd, obj, priceData, queryId, queryType):
                        # First thing is to save key data
                        saveObjDct = copy.deepcopy(objDct)
                        saveOptions = copy.deepcopy(options)
                        saveConfigDct = copy.deepcopy(configDct)
                        saveQueryId = queryId
                        saveQueryType = queryType

                        # Define array to store cumulative group offers
                        groupOffers = []

                        # Get working list of parent groups
                        workingList = copy.deepcopy(objDct['groups'])

                        # Define sting for parent group output
                        parentGroupOutput = 'Parent(s) of subscriber ' + queryId + ' (' + queryType + '): ' + str(workingList) + '\n'

                        # Process each of the groups
                        while len(workingList):
                                # Clear dictionary
                                objDct = {}

                                # Set the options value; remove the item
                                options.goid = workingList.pop(0)

                                #print 'Processing group OID = ' + options.goid

                                ############## Build current object lists #################
                                (q, queryId, queryType) = GET.getGroupDctData(program, options, queryFd)
                                objDct = PROCESS.processGroupDctData(objDct, q, configDct, options, queryFd, program)
                                '''
                                print 'Group offers:'
                                try: pprint.pprint(objDct['offers'])
                                except: print 'None'
                                '''

                                # See if any offers
                                if 'offers' in objDct and len(objDct['offers']):
                                        # Want to add group indication to each offer
                                        for i in range(len(objDct['offers'])): objDct['offers'][i]['groupIndication'] = True

                                        # Add offer to overall list
                                        groupOffers.extend(copy.deepcopy(objDct['offers']))

                                ############## Output group parent data #################
                                if 'ParentGroupId' in objDct:
                                        # Save string in case we need to output
                                        parentGroupOutput += 'Parent group of group '+ str(objDct['ObjectId']) + ':    ' + str(objDct['ParentGroupId']) + '\n'

                                        # Add parent group to working list.  Groups can only have one parent group (so append works fine vs extend).
                                        workingList.append(objDct['ParentGroupId'])

                        # If group hierarchy desired and the sub has a parent group, then go gather/output that data
                        if (options.groupHierarchy or options.allExtraData) and parentGroupOutput: print(parentGroupOutput)

                        # Restore key data
                        objDct = copy.deepcopy(saveObjDct)
                        options = copy.deepcopy(saveOptions)
                        configDct = copy.deepcopy(saveConfigDct)
                        queryId = saveQueryId
                        queryType = saveQueryType

                        # Add the group offers
                        if len(groupOffers):
                                #print 'Adding ' + str(len(groupOffers)) + ' offers'
                                objDct['offers'].extend(groupOffers)

                        return objDct

#===============================================================================
# View parent group data
def viewUpGroup(objDct, options, program, configDct, queryFd, obj, priceData):
        if obj.lower() == 'sub':
                ############## Build current object lists #################
                (q, queryId, queryType) = GET.getSubDctData(program, options, queryFd)
                objDct = PROCESS.processSubDctData(objDct, q, configDct, options, queryFd, program)

                # If any parent groups, then more work to do
                if len(objDct['groups']):
                        #print 'Offer length before: ' + str(len(objDct['offers']))
                        objDct = getGroupOffers(objDct, options, program, configDct, queryFd, obj, priceData, queryId, queryType)
                        #print 'Offer length after : ' + str(len(objDct['offers']))

#               print 'Subscriber offers: '
#               for offer in objDct['offers']:
#                       HTTP.printDictionaryLevel(offer)
#                       print '----------------------------------------------------------------------------------'

                ############## Output subscriber data in nice format #################
                PRT.outputSubscriberData(objDct, configDct, queryId, queryType, options, program=program)

                # Save dictionary
                objList = copy.deepcopy(objDct)

                # May need to process wider scope
                if options.scope and options.scope.lower().count('up') and 'users' in objDct and len(objDct['users']):
                        #pprint.pprint(objDct['users'])

                        # Process each user
                        options.uoid = objDct['users'][0]['ObjectId']

                        # Output user data
                        viewUser(objDct, options, program, configDct, queryFd, priceData)

                # If price Data input, then do validation
                if priceData:
#                       print 'Validating ' + obj + ' ' + queryId + ' (' + queryType + ')'
#                       print 'objDct:'
#                       HTTP.printDictionaryLevel(objDct)
#                       print '\npriceData:'
#                       HTTP.printDictionaryLevel(priceData)
                        VAL.validateData(obj.lower(), objDct, priceData, options)

        else:
                ############## Build current object lists #################
                (q, queryId, queryType) = GET.getGroupDctData(program, options, queryFd)
                objDct = PROCESS.processGroupDctData(objDct, q, configDct, options, queryFd, program)

                # Save dictionary
                objList = copy.deepcopy(objDct)

                ############## Output group data in nice format #################
                PRT.outputGroupData(objDct, configDct, queryId, queryType, options, program)

                # If price Data input, then do validation
                if priceData:
#                       print 'Validating ' + obj + ' ' + queryId + ' (' + queryType + ')'
#                       print 'objDct:'
#                       HTTP.printDictionaryLevel(objDct)
#                       print '\npriceData:'
#                       HTTP.printDictionaryLevel(priceData)
                        VAL.validateData(obj.lower(), objDct, priceData, options)

        # Restore dictionary
        objDct = copy.deepcopy(objList)

        # If scope is set to up and we have parent groups, then process each of the groups
        if options.scope and options.scope.lower().count('up') and 'groups' in objDct and len(objDct['groups']) > 0:
                #print 'Processing data = ' + str(objDct)

                # Process each of the groups
                for i in range(len(objList['groups'])):
                        # Clear dictionary
                        objDct = {}

                        # Set the options value
                        options.goid = objList['groups'][i]

                        #print 'Processing group OID = ' + options.goid

                        # View the group
                        viewGroup(objDct, options, program, configDct, queryFd, priceData)

        # Restore dictionary
        objDct = copy.deepcopy(objList)

#===============================================================================
# View subscriber details
def viewSubscriber(objDct, options, program, configDct, queryFd, priceData):
    # List of IDs to process
    ids = []

    ############## Get subscriber ID information  #################
    if options.sofile:
        # Add the file contents to the array
        f = open(options.sofile, 'r')
        for line in f:
                if line.strip(): ids.append(line.strip())
        queryType = 'ObjectId'
    elif options.sefile:
        # Add the file contents to the array
        f = open(options.sefile, 'r')
        for line in f:
                if line.strip(): ids.append(line.strip())
        queryType = 'ExternalId'

    # Process each of the IDs
    if len(ids):
        # Loop through each entry
        for id in ids:
                # Clear dictionary
                objDct = {}

                # Clear RouteId
                program.RouteId = ''

                # Set the correct options field
                if   queryType == 'ObjectId':   options.oid = id
                elif queryType == 'ExternalId': options.subscriber = id
                else:
                        # Not sure what to do here...
                        print('ERROR:  Code bug -  viewSubscriber() file processing set incorrect queryType.')
                        sys.exit('Exit due to errors')

                # Process/output object and up hierarchy
                viewUpGroup(objDct, options, program, configDct, queryFd, 'sub', priceData)
    else:       viewUpGroup(objDct, options, program, configDct, queryFd, 'sub', priceData)

    # If the scope flag is set to look down and there are devices in the subscriber, then dump all the devices
    if options.scope and options.scope.lower().count('down') and len(objDct['devices']) > 0:
        # Get device list
        objList = []
        objList = copy.deepcopy(objDct['devices'])

        # Loop through each device
        for i in range(len(objDct['devices'])):
                # Reset dictionary, as this should look like a new operation
                objDct = {}

                # Get oid into input structure
                options.doid = objList[i]['ObjectId']

                # Run the command
                viewDevice(objDct, options, program, configDct, queryFd, priceData)

#===============================================================================
# View Group details
def viewGroup(objDct, options, program, configDct, queryFd, priceData):
    # List of IDs to process
    ids = []

    ############## Get subscriber ID information  #################
    if options.gofile:
        # Add the file contents to the array
        f = open(options.gofile, 'r')
        for line in f:
                if line.strip(): ids.append(line.strip())
        queryType = 'ObjectId'
    elif options.gefile:
        # Add the file contents to the array
        f = open(options.gefile, 'r')
        for line in f:
                if line.strip(): ids.append(line.strip())
        queryType = 'ExternalId'

    # Process each of the IDs
    if len(ids):
        # Loop through each entry
        for id in ids:
                # Clear dictionary
                objDct = {}

                # Clear RouteId
                program.RouteId = ''

                # Set the correct options field
                if queryType == 'ObjectId':    options.goid = id
                elif queryType == 'ExternalId': options.groupId = id
                else:
                        # Not sure what to do here...
                        print('ERROR:  Code bug -  viewGroup() file processing set incorrect queryType.')
                        sys.exit('Exit due to errors')

                # Process/output object and up hierarchy
                viewUpGroup(objDct, options, program, configDct, queryFd, 'group', priceData)
    else:       viewUpGroup(objDct, options, program, configDct, queryFd, 'group', priceData)

    # If the scope flag is set to look down and there are subscriber in the group, then dump all the subscribers
    if options.scope and options.scope.lower().count('down') and len(objDct['subscribers']) > 0:
        # Get subscriber list
        objList = []
        objList.extend(objDct['subscribers'])
        #print 'subList = ' + str(objList)

        # Save current structure
        saveObjDct = copy.deepcopy(objDct)

        # Loop through each subscriber in the group
        for oid in objList:
                # Reset dictionary, as this should look like a new operation
                objDct = {}

                # Get oid into input structure
                options.oid = ''
                options.oid += oid

                # Run the command
                viewSubscriber(objDct, options, program, configDct, queryFd, priceData)

        # Restore current structure
        objDct = copy.deepcopy(saveObjDct)

    # If the scope flag is set to look down and there are groups in the group, then dump all the groups
    if options.scope and options.scope.lower().count('down') and len(objDct['subgroups']) > 0:
        # Get group list
        objList = []
        objList.extend(objDct['subgroups'])
        #print 'groupList = ' + str(objList)

        # Save current structure
        saveObjDct = copy.deepcopy(objDct)

        # If scope is local, then clear scope before iteration
        if options.scope and options.scope.lower().count('local'): options.scope = None

        # Loop through each subscriber in the group
        for oid in objList:
                # Reset dictionary, as this should look like a new operation
                objDct = {}

                # Get oid into input structure
                options.groupId = None
                options.goid = ''
                options.goid += oid

                # Run the command (iterative call :-)
                viewGroup(objDct, options, program, configDct, queryFd, priceData)

        # Restore current structure
        objDct = copy.deepcopy(saveObjDct)

#================== Set of I/O functions  ================================================

#===============================================================================
# This function opens files
def openFiles(options):
    ############## Open warning file #################
    # Remove old tool files
    fileToOpen = 'warnings'
    try:
        os.remove(fileToOpen)
    except:
        # Do nothing
        i = 1

    # Open desired file
    #w = open(fileToOpen, 'w')
    w = None

    ############## Open debug file if specified #################
    if options.debug:
        # Remove old tool files
        fileToOpen = options.debug
        try:
                os.remove(fileToOpen)
        except:
                # Do nothing
                i = 1

        # Open desired file
        d = open(fileToOpen, 'w')
    else: d = None

    ############## Open query output file if specified #################
    if options.file:
        # Remove old tool files
        fileToOpen = options.file
        try:
                os.remove(fileToOpen)
        except:
                # Do nothing
                i = 1

        # Open desired file
        q = open(fileToOpen, 'w')
    else: q = None

    return d, w, q

#===============================================================================
# Function to get life cycle data
def getLifeCycleValues(priceFile):
        # Disable for now
        return

        # Get key data
        data = GENERIC.runCmd("awk '/<MtxStatusDefnObject>/,/<\/MtxStatusDefnObject>/' " + priceFile)

        # Pre/post pend data (shouldn't need to do that here...)
        normData = "<kef>\n" + data + "\n</kef>"

        # Put into ET structure
        q = ET.fromstring(normData)

        # Now process each item
        for children in q.findall('./MtxStatusDefnObject'):
                # Get top-level fields
                dctRcv = {}
                dctRcv = XML.getObjectBaseFields(children, dctRcv)

                # Put key data into locals
                objType = dctRcv['ObjectType'].lower()
                status = str(dctRcv['Status'])
                description = dctRcv['Description']

                # Sanity check that we have the main key
                if objType not in PRT.lifeCycleData: sys.exit('Error:  didn\'t find ' + dctRcv['ObjectType'].lower() + ' in lifeCycleData')

                # Sanity check that we don't yet have this status
                if status in PRT.lifeCycleData[objType]:
                        print('lifeCycleData = ' + str(PRT.lifeCycleData))
                        sys.exit('Error: found status ' + status + ' already in lifeCycleData[' + objType + '].  Check file ' + priceFile)

                # Put into the global structure
                PRT.lifeCycleData[objType][status] = description
                #print 'Stored lifeCycleData ' + objType + ' Status ' + status + ' = ' + PRT.lifeCycleData[objType][status]

#================== Set of control functions for each supported object ================================================

#================== Main function  ================================================
def main():
    global options

    # Define view type to be used for this program
    view = 'VIEW'

    # Define locals
    objDct = {}
    configDct = {}
    priceData = None

    # Path is always the current directory
    path = os.getcwd()

    ########### Do command line processing ###################
    options = INPUT.cmdLineInput(view)

    # If version requested, then exit
    if options.version:
        # Print version
        version = GENERIC.runCmd('rpm -q matrixxsw-engine | cut -f3-4 -d"-" | cut -f1 -d"."')
        print('\nEngine RPM: ' + version + '\n')

        # Exit
        sys.exit()

    ############## Process Input data #################
    configDct = CONFIG.readConfigFile(options)

#    print 'options = '+ str(options)
#    print 'configDct = ' + str(configDct)

    # Update input options to reflect configuration, iff input not entered
    if not options.bpw: options.bpw = configDct['bpw']
    if not options.bcpw: options.bcpw = configDct['bcpw']
    if not options.opw: options.opw = configDct['opw']
    if not options.sessions: options.sessions = configDct['sessions']
    if not options.pf and 'priceFile' in configDct: options.pf = configDct['priceFile']
    if not options.release:
                # Need a release value
                if 'release' in configDct: options.release = configDct['release']
                else:
                        print('ERROR: neither the config file nor the input contained release information.')
                        sys.exit('Exiting due to errors')
    else: configDct['release'] = options.release

    # Get pricing data
    (result,q) = GET.getPricingStatus(None, None)

    # Restore engine data if we're supposed to
    if PRIMDATA.regressionRun.lower() == 'restore':
        try:
                PRIMDATA.EngineData = GENERIC.restoreDictionary(PRIMDATA.savedEngineData + 'EngineData')
                if PRIMDATA.EngineData == None:
                        print('Failed to restore EngineData. Switching to saving engine data.')
                        PRIMDATA.regressionRun = 'save'
                        PRIMDATA.EngineData = {}
                else:
                        print('Restored engine data')
                        #pprint.pprint(PRIMDATA.EngineData)
        except:
                print('Failed to restore EngineData. Switching to saving engine data.')
                PRIMDATA.regressionRun = 'save'
                PRIMDATA.EngineData = {}

    # Make sure domain is specified
    field = 'Domain'
    try: domain = q.find('./'+field).text.strip()
    except:
        print('ERROR: query of pricing did not return a domain.  Engine is most likely down or pricing not loaded or authentication values are wrong.')
        sys.exit('Exiting due to errors')

    field = 'ModifiedTime'
    try: modTime = q.find('./'+field).text.strip()
    except:
        print('ERROR: query of pricing did not return a modified time.  Engine is most likely down or pricing not loaded or authentication values are wrong.')
        sys.exit('Exiting due to errors')

    print('Release: ' + configDct['release'] + ', Domain: ' + domain + ', Modified Time: ' + modTime)

    # Here the default is false, so only override if no input and config says we should see this.
    if options.viewGlobals == None: options.viewGlobals = configDct['viewGlobals']

    # If REST data input, then prioritize over config file.
    # Make sure both are the same value, so code can use either.
    if options.RestHost: configDct['hostname'] = options.RestHost
    else:                options.RestHost = configDct['hostname']
    if options.RestPort: configDct['hostport'] = options.RestPort
    else:                options.RestPort = configDct['hostport']

    # If timezone not input then use from config file
    if not options.timezone: options.timezone = configDct['timezone']

    # If date not specified then get date using timezone
    if not options.date: options.date = GENERIC.getTimeNow(options.timezone)

    # If price file input, then get life cycle values
    if options.pf: getLifeCycleValues(options.pf)

    ############## Check if validation is to be done #########
    if options.val and options.pf:
        # Need to process price files per release.
        # At the moment, all field releases use the same validation.
        (priceData, offerCount) = VAL.processTrunkPriceFile(options.pf)

    ############## Open warning, debug files #################
    (d, w, q) = openFiles(options)

    ############## Setup HTTP connection #################
    program = HTTP.setupHttpConnection(configDct, '/rsgateway/data/v3')

    # Invoke object function that was specified
    if   options.gofile or options.gefile or options.groupId or options.goid:
        viewGroup(objDct, options, program, configDct, q, priceData)
    elif options.dx or options.dofile or options.difile or options.dmfile or options.doid or options.imsi or options.msisdn or options.LoginId:
        viewDevice(objDct, options, program, configDct, q, priceData)
    elif options.userId or options.uoid or options.uxid:
        viewUser(objDct, options, program, configDct, q, priceData)
    elif options.suboid or options.subxid or (options.subscriber == '10' and int(options.release) >= 5100):
        # Switch to subscription if defaulted and release is high enough
        if options.subscriber == '10' and int(options.release) >= 5100: options.subxid = '10'
        viewSubscription(objDct, options, program, configDct, q, priceData)
    else: viewSubscriber(objDct, options, program, configDct, q, priceData)

    # Want a second output if validation could not be performed
    if options.val and options.pf and not priceData:  print('\n\nValidation Error: input file ' + options.pf + ' does not exist\n\n')

    # Remove the temp file
    GENERIC.runCmd('rm -f _x >/dev/null 2>&1')

    # Save engine data if we're supposed to
    if PRIMDATA.regressionRun.lower() == 'save':
        GENERIC.saveDictionary(PRIMDATA.EngineData, PRIMDATA.savedEngineData + 'EngineData')
        print('Saved engine data')
        #pprint.pprint(PRIMDATA.EngineData)

    # Space at the bottom
    print()

if __name__ ==  '__main__':
    main()


