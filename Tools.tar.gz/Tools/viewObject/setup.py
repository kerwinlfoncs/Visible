from distutils.core import setup
setup(name='mtx-services-viewObject',
	version='4710.0',
	packages=['viewObjectData'],
	scripts=['viewObject.py'],
	description='MATRIXX Query Output Viewer',
	author='Karl Freter',
	author_email='karl.freter@matrixxsw.com',
	url='www.matrixx.com',
      )

