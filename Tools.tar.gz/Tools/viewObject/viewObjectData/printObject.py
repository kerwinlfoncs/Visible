#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Thu 2021-11-11T22:33:53
# @futurize --stage2 --no-diffs -n -w  : Thu 2021-11-11T22:33:53
#
# @futurize --stage1 --no-diffs -n -w  : Thu 2021-11-11T22:33:52
# coding: latin-1

# Import system primitives
from __future__ import print_function
# from builtins import str
# from builtins import range
# from builtins import str
# from builtins import range
import sys, time, pprint, copy, re, os
import xml.etree.ElementTree as ET
from operator import itemgetter
import xml.etree.ElementTree as ET

# Import MTX primitives
from primitives import primGeneric as PRIM
from primitives import primGET as GET
from primitives import primXML as XML
from primitives import primData as PRIMDATA

# Generic event store curl command prefix
curlQueryCmd = 'curl ' + PRIMDATA.curlAdditionalParams

# Set auth items
if PRIMDATA.simpleAuthUserName: curlQueryCmd += '-u ' + PRIMDATA.simpleAuthUserName + ':' + PRIMDATA.simpleAuthPassword + ' '

# ALWAYS use cookies file here
curlQueryCmd += '-s -b cookies.txt ' + PRIMDATA.httpString + '://restgw:' + PRIMDATA.httpPort + '/rsgateway/data/v3'
#print 'curlQueryCmd = ' + curlQueryCmd

global typeMapping
typeMapping = {}
typeMapping['4'] = 'Total Data'
    
global unitMapping
unitMapping = {}
unitMapping['200'] = 'Bytes'

# Detect non-ASCII names
OnlyAscii = lambda s: re.match('^[\x00-\x7F]+$', s) != None
    
# Define for balance width - used if balances are first output
balanceWidth = 0
balanceClassWidth = 0

#===============================================================================
# Check if filtering is on or off
def outputFilterCheck(options, key):
    if len(options.on) == 0 or options.on.count(key.lower()): printData = True
    else: printData = False

    # Only check for explicit off status
    if options.off.count(key.lower()): printData = False

    return printData

#===============================================================================
# This function prints balance thresholds
def printThresholds(dctRcv, supressHeadings=False, options=None, program=None):
    global balanceWidth
    global balanceClassWidth
    
    numberPrint = 0
    
    # Leverage previously calculated balance width (for optimal printing)
    if balanceWidth:
        options.bpw = balanceWidth
        options.bcpw = balanceClassWidth
    
    # Define output format
    format = '%-' + str(options.bpw) + "s %5s %-45s %13s %10s %20s %s\n"
    
    # Sort the list.  Need key to be an integer.
    for balance in dctRcv: balance['ResourceId'] = int(balance['ResourceId'])
    newList = sorted(dctRcv, key=itemgetter('ResourceId'))
    
    # Go through each balance
    for i,balance in enumerate(newList):
        if hiddenBalance(options, program, balance['TemplateId']): continue
        
        # Check if expired and hideExpired is set
        if options and options.hideExpired and checkIfBalanceExpired(options, balance): continue
        
        # Get the resource ID
        resourceId = str(balance['ResourceId'])
        
        # Report each threshold in a separate line
        for j,entry in enumerate(balance['thresholds']):
            #print 'Balance ' + str(i) + ' threshold ' + str(j) + ':' + str(entry)
            
            # Only outout the name the first time through
            if j == 0: name = balance['Name'] + '(' + resourceId + ')'
            else:      name = ''
            
            # Misc data is null to begin with
            misc = ''
            
            # Setup Flags value
            flags = '['
            
            # Add CL indication to the ID
            if entry['IsCreditLimit'].lower() == 'true': flags += 'C|'

            # Add recurring indication to the flag
            if entry['IsRecurring'].lower() == 'true':
                    flags += 'R|'
                    # See if recurring start/stop are defined
                    if 'RecurringStart' in entry:
                            # Remove decimal if all 0 (which most are)
                            if '.' in entry['RecurringStart']:
                                    val = entry['RecurringStart'].split('.')[1]
                                    if not any(c in val for c in "123456789"):      val = entry['RecurringStart'].split('.')[0]
                                    else:                                           val = entry['RecurringStart']
                            else:
                                    val = entry['RecurringStart']

                            # Store result
                            misc += 'Start: ' + val
                    if 'RecurringStop' in entry:
                            # Add spacing if field already populated
                            if misc: misc += ', '

                            # Remove decimal if all 0 (which most are)
                            if '.' in entry['RecurringStop']:
                                  val = entry['RecurringStop'].split('.')[1]
                                  if not any(c in val for c in "123456789"):        val = entry['RecurringStop'].split('.')[0]
                                  else:                                             val = entry['RecurringStop']
                            else:
                                  val = entry['RecurringStop']

                            # Store result
                            misc += 'Stop: ' + val
            elif 'recharge' in entry and len(entry['recharge']):
                # Data stored as an array but only one allowed, so always access index 0.
                misc += 'Recharge Amount = ' + entry['recharge'][0]['Amount'] + ' (' + entry['recharge'][0]['PaymentMethodResourceId'] + ')'
                
            # Add Absolute indication to the flag
            if entry['IsPct'].lower() == 'false':
                    flags += 'A|'
            else:   flags += 'P|'
            
            # Add Notification indication to the flag
            if entry['NotificationState'].lower() == 'true':
               flags += 'N|'
            
            # Add threshold type if present
            if 'ThresholdType' in entry:
                if   entry['ThresholdType'].lower() in ['credit_limit', '1']:       flags += 'CL|'
                elif entry['ThresholdType'].lower() in ['balance_amount', '2']:     flags += 'BA|'
                elif entry['ThresholdType'].lower() in ['consumed_amount', '3']:    flags += 'CA|'
                elif entry['ThresholdType'].lower() in ['available_amount', '4']:   flags += 'AA|'
                elif entry['ThresholdType'].lower() in ['balance_floor', '5']:      flags += 'BF|'
                else:                                   flags += entry['ThresholdType'] + '|'
            
            # If we added anything to the flags, then need to strip off last seperator character
            if len(flags) > 1:
                # Remove last character in flags and
                flags = flags[:-1]
            
            # Add closing flags bracket
            flags += ']'
            
            # The "type" value is a bit ugly.  Want to remove leading "Notify_" from each item.
            if 'Type' in entry:
                newVal = entry['Type'].replace('Notify_','')
            else:   newVal = ""
            
            # If the first time and not surpressing headers, then output header
            if not numberPrint and not supressHeadings:
                numberPrint += 1
                print('\nThresholds:')
                sys.stdout.write(format % ('Balance Name', 'Id', 'Name', 'Amount', 'Flags', 'Val', 'Misc'))
            
            # Threshold name is optional
            if 'Name' in entry:
                thresholdName = entry['Name']
                
                # If name is system default, then add that
                if thresholdName == 'bal': thresholdName += ' <default>'
            
            else:   thresholdName = '<none>'
            
            # Output periodic data
            sys.stdout.write(format % \
                (\
                name,\
                entry['ThresholdId'],\
                thresholdName,\
                entry['Amount'].rstrip('0').rstrip('.'),\
                flags,\
                newVal,\
                misc))
    print()
    if numberPrint: return True
    else:       return False
    
#===============================================================================
# This function prints balance periods
def printPeriods(dctRcv, options=None, program=None):
    global balanceWidth
    global balanceClassWidth
    
    numberPrint = 0
    
    # Leverage previously calculated balance width (for optimal printing)
    if balanceWidth:
        options.bpw = balanceWidth
        options.bcpw = balanceClassWidth
    
    # Most customers won't have rollover at the start.  Keep the output the same for now (until rollover balances occur).
    # Logic for the lines in this for loop are found below (in the original code).
    foundRollover = False
    for i in range(len(dctRcv)):
        balance = dctRcv[i]
        if balance['IsPeriodic'].lower() != 'true': continue
        if 'Amount' not in balance: continue
        for j in range(len(balance['periods'])):
            if 'RolloverAmount' in balance['periods'][j] and 'RolloverValid' in balance['periods'][j]:
                # Found a rollover item.
                foundRollover = True
                break
        if foundRollover: break
    
    # Process each balance
    for i in range(len(dctRcv)):
        # Reset period found flag
        foundCount = False
        
        # Put period into local structure for readability
        balance = dctRcv[i]
            
        # Skip if balance hidden and input ays to   
        if hiddenBalance(options, program, balance['TemplateId']): continue
        
        # Override non-ASCII names so it can print
        #if not OnlyAscii(balance['Name']): balance['Name'] = '(Non-ASCII characters)'
        
        '''
        print 'Periodic balance ' + str(i) + ':\n'
        pprint.pprint(balance)
        '''
        
        # Remove non-peridic balances
        if balance['IsPeriodic'].lower() != 'true': continue
        
        # If there's no amount, then there's no balance instance (on-demand balances)
        if 'Amount' not in balance: continue
        
        # Get end time
        if 'BalanceEndTime' in balance: balanceEndTime = balance['BalanceEndTime'][:19] +  balance['BalanceEndTime'][26:]
        else:               balanceEndTime = 'N/A'
        
        # If we're supposed to skip balances that are expired, check for this
        if balanceEndTime != 'N/A' and options and options.hideExpired:
            # Use input or local time against overall balance end time
            endTime = balanceEndTime
            if options.date: date = options.date
            else:            date = time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime()) + '.' + endTime.split('.')[1]
            
            # Skip expired balances
            if objectIsExpired(endTime, date): continue
        
        # Get start time
        if 'BalanceStartTime' in balance: balanceStartTime = balance['BalanceStartTime'][:19] +  balance['BalanceStartTime'][26:]
        else:                 balanceStartTime = 'N/A'
        
        # Report each balance in a separate line
        for j in range(len(balance['periods'])):
            # Put period into local structure for readability
            entry = balance['periods'][j]
            
            #print 'Balance ' + str(i) + ' balance ' + str(j) + ':' + str(entry)
            
            # Only outout the name the first time through
            if j == 0:
                name = balance['Name']+'('+str(balance['ResourceId'])+')'

                # While here, add something to signal on-demand and if so if renewable
                if balance['IsOnDemand'].lower() == 'true':
                    name += '(D'
                    if balance['IsRenewable'].lower() == 'true':
                          name += '/R)'
                    else: name += ')'
            else: name = ''
            
            # With rollover, the amount in the period may not be the amount usable.  If they're different, then signal that here.
            # See if valid.
            if 'RolloverValid' in entry: rollover = '*'
            else:                rollover = ''
                
            gross = entry['Amount'].rstrip('0').rstrip('.')
            if 'RolloverAmount' in entry:
                # Add the amount
                rollover += entry['RolloverAmount'].rstrip('0').rstrip('.')
            
            # No rollover.  If rollover in play and input date is greater than than period end date, then the usable amount is 0
            elif foundRollover and (options.date > entry['EndTime'][:19] + entry['EndTime'][26:]): rollover = 0
            
            # Only do this for non-virtual balances.
            elif balance['IsVirtual'].lower() != 'true': rollover += gross
            #else:  rollover = ''
            
            # If the first time, then output header
            if not numberPrint:
                numberPrint += 1

                print('\nPeriods:')
                
                # Output changes depending on rollover status
                if foundRollover:
                    format = '%-' + str(options.bpw) + "s %-25s %-25s %13s %15s %10s\n"
                    sys.stdout.write(format % ('Balance Name', 'Start Time', 'End Time', 'Usable', 'Gross', 'Limit'))
                else:
                    format = '%-' + str(options.bpw) + "s %-25s %-25s %15s %10s\n"
                    sys.stdout.write(format % ('Balance Name', 'Start Time', 'End Time', 'Gross', 'Limit'))
                
            # Skip if period is expired and hideExpired is set
            if options.hideExpired:
                # Use input or local time against balance period end time
                endTime = entry['EndTime']
                if options.date: date = options.date
                else:            date = time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime()) + '.' + endTime.split('.')[1]
                
                # Skip expired balances
                if objectIsExpired(endTime, date): continue
                
            
            # Output balance data
            if foundRollover:
               # Output overall balance start/end times (just once)
               if not foundCount:
                            foundCount = True
                            sys.stdout.write(format % \
                                (\
                                name,\
                                balanceStartTime,\
                                balanceEndTime,\
                                '', \
                                '', \
                                ''))


               sys.stdout.write(format % \
                   (\
                   '',\
                   entry['StartTime'][:19] +  entry['StartTime'][26:],\
                   entry['EndTime'][:19] +  entry['EndTime'][26:],\
                   rollover, \
                   gross, \
                   balance['CreditLimit'].rstrip('0').rstrip('.')))
            else:
               # Output overall balance start/end times (just once)
               if not foundCount:
                            foundCount = True
                            sys.stdout.write(format % \
                                (\
                                name,\
                                balanceStartTime,\
                                balanceEndTime,\
                                '', \
                                ''))

               sys.stdout.write(format % \
                   (\
                   '',\
                   entry['StartTime'][:19] +  entry['StartTime'][26:],\
                   entry['EndTime'][:19] +  entry['EndTime'][26:],\
                   gross, \
                   balance['CreditLimit'].rstrip('0').rstrip('.')))

            # See if there are any components in this period
            if 'components' in entry and len(entry['components']):
                # First see if we need to read container data
                if PRIMDATA.containerData == {} and os.path.exists(PRIMDATA.containerDefFile):
                    # Get the container names and keys.  Probabaly a better weay to do this...
                    cmd = 'grep -A1 \'<container id\' ' + PRIMDATA.containerDefFile + ' | grep "container id=" | cut -f2 -d\'"\''
                    containers = PRIM.runCmd(cmd).split('\n')
                    
                    cmd = 'grep -A1 \'<container id\' ' + PRIMDATA.containerDefFile + ' |  grep \'<key>\' | cut -f2 -d\'>\' | cut -f1 -d\'<\''
                    keys = PRIM.runCmd(cmd).split('\n')
                    
                    # Now merge together
                    for i in range(len(containers)):
                        PRIMDATA.containerData[containers[i]] = keys[i]
                        PRIMDATA.containerData[keys[i]] = containers[i]
                    
                    #print 'Container data:'
                    #pprint.pprint(PRIMDATA.containerData)
                
                # Process each component
                for component in entry['components']:
                  # See if any fields
                  fields = ''
                  if 'fields' in component and len(component['fields']):
                   # Build the field data
                   for field in component['fields']:
                       # See if a container specified
                       try: fields += PRIMDATA.containerData[field['ContainerKey']] + '/'
                       except: pass
                
                       # Should always have a name
                       fields += field['Name']
                
                       # If components not yet used, then no value will be presemt
                       if 'Value' in field: fields += ' (' + field['Value'] + ')'
                
                       # Add seperations
                       fields += ', '
                   
                   # Remove trailing characters
                   fields = fields[:-2]
                   
                   # Get the amount
                   gross = component['Amount'].rstrip('0').rstrip('.')
                   
                   # Write the fields
                   sys.stdout.write(format % \
                                    (\
                                    '*Field*',\
                                    '',\
                                    '',\
                                     gross, \
                                    fields))
               
                  # See if any sub-components
                  if 'subPeriod' in component and len(component['subPeriod']):
                   for subPeriod in component['subPeriod']:
                      # Get pieces
                      name = 'Component (' + subPeriod['ComponentId'] + ')'
                      balanceStartTime = subPeriod['StartTime'][:19] +  subPeriod['StartTime'][26:]
                      balanceEndTime   = subPeriod['EndTime'][:19] +  subPeriod['EndTime'][26:]
                      gross = subPeriod['Amount'].rstrip('0').rstrip('.')
                
                      # Write the 
                      sys.stdout.write(format % \
                                    (\
                                    name,\
                                    balanceStartTime,\
                                    balanceEndTime,\
                                    gross, \
                                    fields))
        print()  

#===============================================================================
# This function prints simple balance info
def printSimple(dctRcv, options=None, program=None):
    global balanceWidth
    global balanceClassWidth
    
    output = []
    
    # Process each balance
    for i in range(len(dctRcv)):
        # Put period into local structure for readability
        balance = dctRcv[i]
        
        # Skip if balance hidden and input ays to   
        if hiddenBalance(options, program, balance['TemplateId']): continue
        
        # Check if expired and hideExpired is set
        if options and options.hideExpired and checkIfBalanceExpired(options, balance): continue
        
        #print 'balance ' + str(i) + ':\n' + str(balance)
        
        # Remove peridic balances
#       if balance['IsPeriodic'] == 'true': continue
        
        # Get end time
        if 'EndTime' in balance:
            endTime = balance['EndTime']
        else:   endTime = 'N/A'
        
        # Debug output
                #print 'Simple balance ' + str(i) + '):' + str(balance).replace(',', '\n')

        # Start and end times are optional
        if 'StartTime' in balance: startTime = balance['StartTime']
        else:                startTime = 'N/A'
        
        # Override non-ASCII names so it can print
        #if not OnlyAscii(balance['Name']): balance['Name'] = '(Non-ASCII characters)'
        
        # Add to output
        output.append(\
                               (\
                               balance['Name']+'('+str(balance['ResourceId'])+')',\
                               startTime[:19] +  startTime[26:],\
                               endTime[:19] +  endTime[26:],\
                               balance['Amount'].rstrip('0').rstrip('.'),\
                               balance['CreditLimit'].rstrip('0').rstrip('.')))
        
    # Check if something to print
    if len(output):
     # Get widest list item
     if not balanceWidth:
        width = len(max((L[0] for L in output), key=len))
        balanceWidth = max(width, len('Balance Name'))
    
     # If the first time, then output header
     print('\nSimple:')
     format = "%-" + str(balanceWidth) + "s %-25s %-25s %15s %10s\n"
     sys.stdout.write(format % ('Balance Name', 'Start Time', 'End Time', 'Gross', 'Limit'))
                
     # Print balances
     for item in output:
        # Split the item
        ( \
                   Name,\
                   startTime,\
                   endTime,\
                   Amount,\
                   CreditLimit) = item
        
        # Output periodic data
        sys.stdout.write(format % \
                               (\
                           Name,\
                           startTime[:19] +  startTime[26:],\
                           endTime[:19] +  endTime[26:],\
                           Amount,\
                           CreditLimit))

#===============================================================================
def hiddenBalance(options, program, templateId):
    # See if we're suppoed to check for hidden and if the data required is passed in
    if options.hideHidden and program and templateId:
        # Get data for the template
        q = GET.getBalanceTemplateDctData(program, templateId)
        
        # See if there are attributes
        for attr in q.findall('./BalanceInfo/MtxPricingBalanceDetailInfo/AttrList/MtxPricingAttrInfo'):
            #ET.dump(attr)
            
            # See if attribute is MtxDisplay
            if attr.find('./Name').text.strip() != 'MtxDisplay': continue
            
            # If value is hidden/none then skip
            if attr.find('./Value').text.strip().lower() in ['hidden', 'none']:
                #print 'Skipping display of template ' + str(templateId) + ' because it\'s MtxDisplay attribute says to'
                return True
            else:   return False
                
    # If here. then didn't find attribute, so display the balance
    return False
    
#===============================================================================
def checkIfBalanceExpired(options, balance):
    retCode = False
    
    # Need to look at different locations if periodic versus simple
    if balance['IsPeriodic'].lower() == 'true':
        if 'BalanceEndTime' in balance: endTime = balance['BalanceEndTime'][:19] +  balance['BalanceEndTime'][26:]
        else:               endTime = 'N/A'
            
    elif ('EndTime' in balance or 'CancelEndTime' in balance):
        # Get end time
        try:    endTime = balance['EndTime']
        except: endTime = balance['CancelEndTime']
        
    else:   endTime = 'N/A'
    
    # Check if an end time is defined
    if endTime != 'N/A':
        # Use input or local time
        if options.date: date = options.date
        else:            date = time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime()) + '.' + endTime.split('.')[1]
        
        # Skip expired balances
        if objectIsExpired(endTime, date): retCode = True
    
    return retCode
    
#===============================================================================
# This function prints balances
def printBalances(dctRcv, options, extraBalanceInfo, tierBalances, devices=None, program=None):
    global balanceWidth
    global balanceClassWidth

    output = []
    
    # Sort based on resource ID.
    # need to be int for this to work...
    for balance in dctRcv: balance['ResourceId'] = int(balance['ResourceId'])
    for balance in extraBalanceInfo: balance['ResourceId'] = int(balance['ResourceId'])
    newlist = sorted(dctRcv, key=itemgetter('ResourceId'))
    extraInfoList = sorted(extraBalanceInfo, key=itemgetter('ResourceId'))
    '''
    print 'Extra Info List:'
    pprint.pprint(extraInfoList)
    print 'New List:'
    pprint.pprint(newlist)
    '''
    # Loop through all balances
    for (i,balance) in enumerate(newlist):
        # See if we should check for hidden balances
        if hiddenBalance(options, program, balance['TemplateId']): continue
        #pprint.pprint(balance)
        #pprint.pprint(extraInfoList[i])
        
        # Override non-ASCII names so it can print
        #if not OnlyAscii(balance['Name']): balance['Name'] = '(Non-ASCII characters)'
        
        # Start "name" creation
        name = balance['Name'] + '(' 
        
        # If associated with a device, then need to find the device number
        if 'DeviceId' in balance:
            # Loop through devices
            for j,device in enumerate(devices):
                if device['ObjectId'] == balance['DeviceId']:
                    # Add device index
                    name += 'D' + str(j) + '/'
                    break
        
        # Check if expired and hideExpired is set
        if options and options.hideExpired and checkIfBalanceExpired(options, extraInfoList[i]): continue
        
        # Change category to word
        if   balance['Category'] == '1':  category = 'currency'
        elif balance['Category'] == '2':  category = 'asset'
        else:                 category = 'meter'
        
        # Append resource ID to the balance name
        name += str(balance['ResourceId'])
        
        # Add a virtual indication
        if balance['IsVirtual'] == 'true': name += 'V'
        
        # Add a pre/post indication
        try:
            if balance['IsPrepaid'] == 'true': name += 'P'
            else:                  name += 'p'
        except: pass
        
        # Indicate if private
        try:
            if balance['IsPrivate'] == 'true': name += 'R'
        except: pass
        
        # Add a debt instance indication (not present if not a debt, so use try/except)
        try:
            if extraInfoList[i]['IsContractDebt'] == 'true': name += 'D'
        except: pass
        try:
            if extraInfoList[i]['IsMainBalance']  == 'true': name += 'M'
        except: pass
        
        # A new element.  Check for existance and value.  New field not in basic query so need wallet query data.
        # NOTE: This fails if there are multiple instances of the same template in the walllet.  Extra has one/template, but balances are all of them.
        #if 'IsMainBalance' in extraInfoList[i] and extraInfoList[i]['IsMainBalance'] == 'true': name += 'M'
        
        # See if this balance was created as part of a tier balance creation
        for entry in tierBalances:
            if entry['BalanceId'] == balance['TemplateId'] and str(balance['ResourceId'] == entry['ResourceId']):
                # Balance instance was created by a child offer purchase
                name += 'C'
                break
            
        # Close name
        name += ')'
        
        # Rollover is desired value here if specified.
        if 'TotalRolloverAmount' in balance:
            amount = balance['TotalRolloverAmount'].rstrip('0').rstrip('.')
            resvAmount = balance['TotalRolloverReserved'].rstrip('0').rstrip('.')
            availAmount = str(float(amount) + float(resvAmount)).rstrip('0').rstrip('.')
            limit = amount
            #resvAmount = balance['ReservedAmount'].rstrip('0').rstrip('.')
            #availAmount = balance['AvailableAmount'].rstrip('0').rstrip('.')
            #limit = balance['ThresholdLimit'].rstrip('0').rstrip('.')
            
        # NOTE:  on-demand balance may not have any amount.  Need to address that.
        elif 'Amount' in balance:
            # All data valid
            amount = balance['Amount'].rstrip('0').rstrip('.')
            resvAmount = balance['ReservedAmount'].rstrip('0').rstrip('.')
            availAmount = balance['AvailableAmount'].rstrip('0').rstrip('.')
            limit = balance['ThresholdLimit'].rstrip('0').rstrip('.')
            
        else:
            amount = "N/A"
            resvAmount = availAmount = limit = ''
        
        # Meters do no thave class names
        if 'ClassName' in balance: className = balance['ClassName']
        else:                className = "<meter>"
    
        # Add to output
        output.append(\
            (name,\
                        className,\
                        balance['TemplateId'],\
                        balance['QuantityUnit'],\
                        category,\
                        amount,\
                        resvAmount,\
                        availAmount,\
                        limit))
        
    # If anything to output, then output it
    if len(output):
     # Get widest list item
     Width1 = len(max((L[0] for L in output), key=len))
     Width2 = len(max((L[1] for L in output), key=len))
     balanceWidth      = max(Width1,len('Balance Name'))
     balanceClassWidth = max(Width2,len('Class Name'))
    
     # Print balance header
     print('\nBalances:')
     format = "%-" + str(balanceWidth) + "s %-" + str(balanceClassWidth) + "s %-9s %-10s %-9s %15s %15s %15s %13s\n"
     sys.stdout.write(format % ('Balance Name', 'Class Name', 'Tmpl ID', 'Unit', 'Category', 'Gross', 'Reserved', 'Available', 'Maximum'))
        
     # Print balances
     for item in output:
                # Split the item
                ( \
                        name,\
                        className,\
                        TemplateId,\
                        QuantityUnit,\
                        category,\
                        amount,\
                        resvAmount,\
                        availAmount,\
                        limit) = item
        
                # Output string
                sys.stdout.write(format % \
                        (\
                        name,\
                        className,\
                        TemplateId,\
                        QuantityUnit,\
                        category,\
                        amount,\
                        resvAmount,\
                        availAmount,\
                        limit))

#===============================================================================
# This function prints tax data
def printTax(dctRcv, line, options=None):
        # Define what we want to print
        TaxFields = ['TaxStatus', 'TaxCertificate', 'TaxLocation']

        linep2 = ''
        currentLength = 0
        for i in range(len(TaxFields)):
                # Get the item
                item = TaxFields[i]
        
        # See if defined
        if dctRcv[item] != '<N/A>':
                        # Store data in output string
                        linep2 += item + ' = ' + dctRcv[item] + ', '

                        # If the line is too long, then start a new one (with proper indentation)
                        if len(linep2) - currentLength >= 100:
                                # Save current length
                                currentLength = len(linep2)

                                # Restart on new line unless on last parameter
                                if i != len(TaxFields) - 1: linep2 += '\n                 '

        # If anything returned, then output line
        if linep2: print(line + linep2[:-2])

#===============================================================================
# This function prints bill cycle data
def printBillCycle(dctRcv, line, options=None):
    # Define what fields we want to print 
    BillCycleFields = ['BillingCycleId', 'PeriodInterval', 'CurrentPeriodEndTime', 'Period', 'DatePolicy', 'DateOffset']

    linep2 = ''
    currentLength = 0
    
    # Only print certain fields here
    for i in range(len(BillCycleFields)):
        # Get the item
        item = BillCycleFields[i]
        
        # Not all keys are present
        if item not in dctRcv: continue
        
        # Store data in output string
        linep2 += item + ' = ' + dctRcv[item] + ', '

        # If the line is too long, then start a new one (with proper indentation)
        if len(linep2) - currentLength >= 100:
                # Save current length
                currentLength = len(linep2)
            
                # Restart on new line unless on last parameter
                if i != len(BillCycleFields) - 1: linep2 += '\n                 '

    # If anything returned, then output line
    if linep2: print(line + linep2[:-2])

#===============================================================================
# This function prints payment method data
def printPaymentMethodData(detailedData, options, objType='subscriber'):
    # Start of output line
    line = 'Payment Method: '
    
    # Padding per line
    linePad = len(line)
    
    # Set output format 
    formatHeader = "%-" + str(linePad) + "s %-40s %s %s\n"
    
    # Process each entry
    for entry in detailedData:
        # Combine data
        if 'Name' not in entry: entry['Name'] = 'No Name'
        entry['Name'] += ' (' + entry['ResourceId'] + ')'
        
        # Combine payment items.  Not sure what's required so be safe.
        iD = ''
        if 'PaymentGatewayId'     in entry:
            # See if ID is a known one
            try:    iD += PRIMDATA.paymentGatewayIdMapping[entry['PaymentGatewayId']]
            except: iD += 'Unknown Vendor'
            iD += ' (' + entry['PaymentGatewayId'] + '):'
        if 'PaymentGatewayUserId' in entry: iD += entry['PaymentGatewayUserId'] + '(U):'
        if 'PaymentType'          in entry: iD += entry['PaymentType'] + '(P)'
        if iD[-1] == ':': iD = iD[:-1]
        
        # Set rest of the data
        default = '('
        if entry['IsDefault'].lower()    == 'true': default += 'D|'
        if entry['IsSysDefault'].lower() == 'true': default += 'S'
        if default[-1] == '|': default = default[:-1]
        default += ')'
        
        sys.stdout.write(formatHeader % \
                (\
            line,\
            entry['Name'],\
            iD,
            default))
        
        # New line without header
        line = ' ' * linePad

#===============================================================================
# This function prints payment token data
def printPaymentTokenData(summaryData, detailedData, options=None, objType='subscriber'):
    # If no detailed data then exit
    if len(detailedData) == 0: return
    
    # Start of output line
    line = 'Payment Token:  '
    
    # Padding per line
    linePad = len(line)
    
    formatHeader = "%-" + str(linePad) + "s %-40s %s\n"
    
    # Process each token
    for entry in detailedData:
        # See if this is the default token
        if entry['ResourceId'] == summaryData['CurrentPaymentTokenResourceId']: entry['Name'] += '(D)'
        
        # Separate the payment token to its parts
#       entry['PaymentToken'] += '(' + PRIM.runCmd('echo ' + entry['PaymentToken'] + ' | base64 -d | python -m json.tool | tr "\n" " "').replace(' ', '').replace('{','').replace('}','') + ')'
        
        sys.stdout.write(formatHeader % \
                        (\
                    line,\
                    entry['Name']+'[N]',\
                    entry['PaymentToken']+'[T]'))
        
        # Start new line
        line = ' ' * linePad
    
#===============================================================================
# This function prints custom data
def printCustomData(dctRcv, customAttr, printFlag = True, options=None, objType='subscriber'):
    # Define line length for custom data
    custLineLengthOffer = 150
    custLineLengthOther = 130
    if objType == 'offer':
        # Offer output will manage padding on the fly
        custLineLength = 50
        linePad = 0
    else:
        custLineLength = custLineLengthOther
        linePad = 17
    
    # Split these
    attr = customAttr.split(',')
#   print 'Checking custom attributes: ' + str(attr)

    # Need to remove leading/trailing white space, as that causes problems down the line...
    for i in range(len(attr)): attr[i] = attr[i].strip()
    
    # Start of output line
    if objType != 'user': line = 'Custom Data:     '
    else:                 line = 'Custom Data:  '

    # Process all parameters
    linep2 = ''
    currentLength = 0
    attr.sort()
    for i in range(len(attr)):
        # Get the attribute name
        attrName = attr[i]
        
        # May not have all the fields, or they may be null
        if (attrName not in dctRcv) or (dctRcv[attrName] == None): continue
        #print 'Found custom item ' + attrName + '.  Values: ' + str(dctRcv[attrName])
        
        # Custom objects could be lists or single items
        if type(dctRcv[attrName]) != type(list()): linep2 += attrName + '=' + dctRcv[attrName] + ', '
        elif len(dctRcv[attrName]) == 0: continue
        else:
            # Something in the list.  Go through the list and print.
            found = False
            for item in dctRcv[attrName]:
                # See if anything in here.
                if item and item.strip():
                    # First time through add the parameter name
                    if not found: 
                        linep2 += attrName + ' = '
                        found = True
                    
                    # Always add the list item
                    linep2 += item.strip() + ', '
        
        # If the line is too long, then start a new one (with proper indentation).
        # Also start unconditionally if processing offers.
        if objType == 'offer' or len(linep2) - currentLength >= custLineLength:
                        # Save current length
                        currentLength = len(linep2)

                        # Restart on new line unless on last parameter
                        if i != len(attr) - 1: linep2 += '\n' + ' ' * linePad
    
    # Get final string (dropping last comma separator) and add line spacing (readability)
    if linep2: line += linep2[:-2] + '/n'
    else:      line = ''
    
    # Output the line if any custom parameter were defined
    if printFlag and line: print(line)
    
    # Return what would (or did) print, so caller may print it along with other data.
    # Add indent to return data so it prints fine + remove trailing spaces + remove trailing comma + add new line ( a bit hacky...).
    if linep2: return ' ' * linePad + linep2.rstrip()[:-1]
    else:      return linep2
    
#===============================================================================
# This function prints lists
def printList(dctRcv, line, options=None):
        linep2 = ''
        currentLength = 0
        for i in range(len(dctRcv)):
                # Add subscriber information
                linep2 += dctRcv[i] + ', '

                # If the line is too long, then start a new one (with proper indentation)
                if len(linep2) - currentLength >= 100:
                        # Save current length
                        currentLength = len(linep2)

                        # Restart on new line
                        linep2 += '\n                 '

        # If anything returned, then output line
        if linep2: print(line + linep2[:-2])

#===============================================================================
# This function prints policy
def printPolicy(dctRcv, configDct, PolicyProfileName, options=None):
    # Start of output line
    line = 'Policy:          '

    # Process all policies
    linep2 = ''
    if PolicyProfileName: linep2 += 'Policy Profile Name = ' + PolicyProfileName + ', '
    currentLength = len(linep2)
    for policyItem in dctRcv:
        # Add to output
        linep2 += policyItem['Id'] + ' = ' + policyItem['Status'] + ', '
        
        # If the line is too long, then start a new one (with proper indentation)
        if len(linep2) - currentLength >= 100:
                        # Save current length
                        currentLength = len(linep2)

                        # Restart on new line
                        linep2 += '\n                 '
    
    # If anything returned/remaining, then output line minus trailing comma separation
    if linep2: print(line + linep2[:-2])

#===============================================================================
def objectIsExpired(endTime, date=None):
    # Debug output
    #print 'EndTime/date = ' + str(endTime) + '/' + str(date)
    
    # Use input or local time
    if not date: date = time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime()) + '.' + endTime.split('.')[1]

    # Return if expired
    if PRIM.checkIfTime2GreaterTime1(endTime, date): return True
    else: return False
        
#===============================================================================
# This function prints contracts
def printContracts(dctRcv, configDct, options=None):
    # Flag to show heading printed
    hdrFlag = False
    
    # ***** Service Contracts *****
    contract = 'serviceContractData'
    
    # Common header
    formatHeader = "%-7s %-3s %-10s %-10s %-10s %-28s %-28s\n"
    
    # List of stuff to print
    contractList = []
    contractList.append(('Type', 'ID', 'State', 'Debt', 'Late', 'Start', 'End'))
    
    # Process all the entries
    for i in range(len(dctRcv)):
        # Put into local for readability
        offer = dctRcv[i]
        
        if (contract not in offer) or (not len(offer[contract])): continue
        
        # Debug
        pprint.pprint(offer[contract])
        
        # We have a contract
        # Massage fields that need it
        try:
            startDate = offer[contract]['ContractStartTime'].split('.')
            startDate = startDate[0] + startDate[1][6:]
        except: startDate = 'N/A'
        
        try:
            endDate = offer[contract]['ContractEndTime'].split('.')
            endDate = endDate[0] + endDate[1][6:]
        except: endDate = 'N/A'
        
        # Add to list
        contractList.append((contract[:7].capitalize(), offer[contract]['ContractId'], offer[contract]['Status'].capitalize(), offer[contract]['ContractDebtBalanceAmount'].rstrip('0').rstrip('.'), offer[contract]['ContractLateChargeDebtBalanceAmount'].rstrip('0').rstrip('.'), startDate, endDate))
        
    # If something  beyond the header, then print
    if len(contractList) > 1:
        # We have data
        if not hdrFlag:
            print('\nContracts:')
            hdrFlag = True
        else:
            # Add space for readability
            print('\n')
        
        # Print all contracts
        for contract in contractList:
            # Split for printing (easier)
            (contractType, contractId, contractState, debt, late, start, end) = contract
            
            # Print
            sys.stdout.write(formatHeader % \
               (\
               contractType,\
               contractId,\
               contractState,\
               debt,\
                late,\
                start,\
                end)\
                   )
        
    # *****  Finance Contracts *****
    contract = 'financeContractData'
    
    # Common header
    formatHeader = "%-7s %-3s %-10s %-10s %-10s %-28s %-28s %-12s %-12s %-12s %-12s\n"
    
    # List of stuff to print
    contractList = []
    contractList.append(('Type', 'ID', 'State', 'Debt', 'Late', 'Start', 'End', 'Principal', 'Installment', 'Outstanding', 'Rem Pymts'))
    
    # Process all the entries
    for i in range(len(dctRcv)):
        # Put into local for readability
        offer = dctRcv[i]
        
        if (contract not in offer) or (not len(offer[contract])): continue
        
        # Debug
        #pprint.pprint(offer[contract])
        
        # We have a contract
        # Massage fields that need it
        startDate = offer[contract]['ContractStartTime'].split('.')
        startDate = startDate[0] + startDate[1][6:]
        
        endDate = offer[contract]['ContractEndTime'].split('.')
        endDate = endDate[0] + endDate[1][6:]
        
        # Add to list
        contractList.append((contract[:7].capitalize(), offer[contract]['ContractId'], offer[contract]['Status'].capitalize(), offer[contract]['ContractDebtBalanceAmount'].rstrip('0').rstrip('.'), offer[contract]['ContractLateChargeDebtBalanceAmount'].rstrip('0').rstrip('.'), startDate, endDate, offer[contract]['PrincipalAmount'].rstrip('0').rstrip('.'), offer[contract]['InstallmentAmount'].rstrip('0').rstrip('.'), offer[contract]['OutstandingPrincipalAmount'].rstrip('0').rstrip('.'), offer[contract]['OutstandingInstallment']))
        
    # If something  beyond the header, then print
    if len(contractList) > 1:
        # We have data
        if not hdrFlag:
            print('\nContracts:')
            hdrFlag = True
        else:
            # Add space for readability
            print('\n')
        
        # Print all contracts
        for contract in contractList:
            # Split for printing (easier)
            (contractType, contractId, contractState, debt, late, start, end, principle, installment, outstanding, remPymts) = contract
            
            # Print
            sys.stdout.write(formatHeader % \
             (\
                contractType,\
                contractId,\
                contractState,\
                debt,\
                late,\
                start,\
                end,
                principle,\
                installment,\
                outstanding,\
                remPymts)\
                   )
        #print '\n'

#===============================================================================
# This function prints offer parameter data
def printParameterData(parameterList):
       retData = ''

       # Loop through parameters
       for parameter in parameterList: retData += parameter['ParameterName'] + '(' + parameter['ValueType'] + ') = ' + parameter[parameter['ValueType'].capitalize() + 'Value'][0] + ', '

       # Return string minus trailing element seperater
       return retData[:-2]

#===============================================================================
# This function prints offers
def printOffers(dctRcv, configDct, options=None, globalOffers=None, devices=None):
    numberPrint = 0
    offerList = []
    
    # Save input list
    saveDctRcv = copy.deepcopy(dctRcv)
    
    # Offer format depends on cofiguration parameter
    if ('offerOutput' in configDct and configDct['offerOutput'].lower() == 'full') or (options and (options.offerDetail or options.allExtraData)):
        output = 'full'
        formatHeader = "%-7s %-" + str(options.opw) + "s %-" + str(options.opw) + "s %-11s %s\n"
        headers = ('ID', 'Name', 'External ID', 'Priority', 'Custom Data')
    else:
        output = 'condensed'
        formatHeader = "%-4s %-" + str(options.opw) + "s %-" + str(options.opw) + "s %11s %-28s %-28s %s\n"
        headers = ('ID', 'Name', 'External ID', 'Priority', 'Start/Purchase/Activate Time', 'End/Cancel/Activation Time', 'Addl Data')
        
    # Get sort priority
    try:    sortType = options.sortField
    except: sortType = 'priority'
    
    # Want to add device offers to this list (similar to adding gorup offers)
    if devices:
     for i in range(len(devices)):
        # Store device in local variable for readability
        device = devices[i]
        
        # If no offers present, then skip
        if 'offers' not in device: continue
        
        # Process every offer in the device
        for j in range(len(device['offers'])):
            # Add device indication
            offer = device['offers'][j]
            offer['deviceIndication'] = i
            
            # Add to input list
            dctRcv.append(offer)
            
    # Process all the entries
    for i in range(len(dctRcv)):
        # Put into local for readability
        offer = dctRcv[i]
        
        '''
        print 'Printing offer ' + str(i) + ':'
        pprint.pprint(offer)
        print '\n'
        '''
        
        # *** Names to use now depend on which release, as we should use catalog build IDs post 5050 ***
        if 'MtxPricingCatalogItemDetailInfo' in offer:
            detailIdx = 'MtxPricingCatalogItemDetailInfo'
            idIdx = 'CatalogItemId'
        else:
            detailIdx = 'MtxPricingOfferDetailInfo'
            idIdx = 'ProductOfferId'
        
        # Use offer name instead of external ID...
        if 'Name' in offer[detailIdx]:
              name = offer[detailIdx]['Name']
        else: name = "N/A"
        
        # Get offer ID
        id = offer[idIdx] 
        
        if 'ExternalId' in offer[detailIdx]:
              extId = offer[detailIdx]['ExternalId']
        else: extId = "N/A"
        
        # Get time data.  Want all four possible times.
        # Sometimes there isn't a time.
        StartTime = offer['StartTime'] if 'StartTime' in offer else 'N/A'
        PurchaseTime = offer['PurchaseTime'] if 'PurchaseTime' in offer else 'N/A'
        EndTime = offer['EndTime'] if 'EndTime' in offer else 'N/A'
        CancelEndTime = offer['CancelEndTime'] if 'CancelEndTime' in offer else 'N/A'
        AutoActivationTime = offer['AutoActivationTime'] if 'AutoActivationTime' in offer else 'N/A'
        ActivationTime = offer['ActivationTime'] if 'ActivationTime' in offer else 'N/A'
        
        # If we're supposed to hide objects that are expired, check for this
        if CancelEndTime != 'N/A': eTime = CancelEndTime
        elif EndTime != 'N/A':     eTime = EndTime
        else:              eTime = 'N/A'
        if eTime != 'N/A' and options and options.hideExpired and objectIsExpired(eTime, options.date): continue
        
        # Set local if a bundle (used several times)
        if 'OfferType' in offer and offer['OfferType'] != '1':  bundle = True
        else:                           bundle = False
        
        # Custom data is filled in along the way
        customData = ''
        
        # Add group and/or bundle indication if applicable
        mainBundle = False
        if ('groupIndication' in offer) or ('deviceIndication' in offer) or bundle or detailIdx == 'MtxPricingCatalogItemDetailInfo':
            # There will be additions here.
            # Open the parenthesis
            name += '('
            
            # Set catalog item indication
            if detailIdx == 'MtxPricingCatalogItemDetailInfo':
                name += 'C|'
                
                # If didn't request to avoid template data, then output here
                if not options.hideTemplateData:
                 # Go ahead and read engine to get CI template parameters.
                 # Don't fail if this fails (for now at least).
                 cmd = curlQueryCmd + '/pricing/CatalogItem/' + id
                 _data = PRIM.runCmd(cmd)
                 try: q = ET.fromstring(_data)
                 except:
                    print('ERROR.  viewObject ran command: ' + cmd)
                    print('        Result was: ' + str(_data))
                    print('        This failed ET.fromstring().  Skipping this offer.')
                    continue
                
                 doc = XML.walkXmlData(q, addListEntry=True)
                 _data = ''
                 try:
                        #pprint.pprint(doc)
                        custTemplate = list(doc['MtxResponsePricingCatalogItem']['CatalogItemInfo']['MtxPricingCatalogItemDetailInfo']['TemplateAttr'].keys())[0]
                        for key in list(sorted(doc['MtxResponsePricingCatalogItem']['CatalogItemInfo']['MtxPricingCatalogItemDetailInfo']['TemplateAttr'][custTemplate])):
                            item = doc['MtxResponsePricingCatalogItem']['CatalogItemInfo']['MtxPricingCatalogItemDetailInfo']['TemplateAttr'][custTemplate][key]['value']
                            _data += key + ' = ' 
                            if isinstance(item, list):
                                for _x in item: _data += _x['value'] + ', '
                            elif isinstance(item, dict):
                                # Obvious one is a single list item.  Check for that special case here
                                if 'value' in item: _data += str(item['value'])
                                else:           _data += str(item)
                            else:   _data += str(item)
                            _data += '\n'
                        if _data: customData += 'Offer Template Data:\n' + _data
                 except: pass
                
                # If didn't request to avoid eligibility data, then output here
                if not options.hideEligibilityData:
                 # Print eligibility rules
                 try:
                    # Define local (for ease of reading)
                    entry = doc['MtxResponsePricingCatalogItem']['CatalogItemInfo']['MtxPricingCatalogItemDetailInfo']['ProvideList']['MtxPricingEligibilityStringFeature']
                    #print 'Entry: ' + str(entry)
                    
                    # Make sure it's a list
                    if type(entry) != type(list()): entry = [entry]
                    
                    # Get each feature
                    _data = ''
                    for item in entry:
                        #print 'Item: ' + str(item)
                        # Seeing empty dictionaries come back...
                        if not len(item): continue
                        
                        # Add to output
                        _data += item['Name']['value'] + ' = ' + item['Value']['value'] + ', '
                    if _data: 
                        if customData: customData += '-'*20 + '\n'
                        customData += 'Eligibility Features: ' + _data[:-2] + '\n'
                 except: pass
            
            # Set group indication
            if 'groupIndication' in offer: name += 'G|'
            if 'deviceIndication' in offer: name += 'D' + str(offer['deviceIndication']) + '|'
            
            # Check for bundles.  If offer type is 2, then this is the bundle, else it's a child.
            if 'OfferType' in offer and offer['OfferType'] == '2':
                name += 'B' + offer['ResourceId'] + '|'
                mainBundle = True
            if 'OfferType' in offer and offer['OfferType'] == '3': name += 'b' + offer['ParentResourceId'] + '|'
            
            # Close the name, dropping the last character (trailing '|')
            name = name[:-1] + ')'
        
        # Add resource information if not a group offer
        if 'groupIndication' not in offer:
            # Start additional information
            extId += '(' 
            
            # Append resource ID
            extId += offer['ResourceId']
        
            # If primary balance assigned, then add here
            if 'PrimaryBalanceResourceId' in offer: extId += '/' + offer['PrimaryBalanceResourceId']
            
            # End additional information
            extId += ')'
        
        # Check/signal if global offer
        if 'IsGlobal' in offer['MtxPricingOfferDetailInfo'] and offer['MtxPricingOfferDetailInfo']['IsGlobal'].lower() == 'true': extId += '*'
        
        # Add offer status to external ID.
        # Vast majority of the time offer is active so no need to highlight that.
        offer['Status'] = offer['Status'].lower()
        if   offer['Status'] in ['1', 'active']:    extId += ''
        elif offer['Status'] in ['2', 'in_cancellation']:extId += '(C)'
        elif offer['Status'] in ['3', 'inactive']:  extId += '(I)'
        elif offer['Status'] in ['4', 'suspended']: extId += '(S)'
        elif offer['Status'] in ['7', 'recoverable']:   extId += '(R)'
        elif offer['Status'] in ['6', 'grace']:     extId += '(G)'
        elif offer['Status'] in ['5', 'pre_active']:    extId += '(P)'
        else:                       extId += '(' + offer['Status'] + ')'
        
        # Overload external ID with cycle information
        # Check for pending change
        try:
            if len([x for x in offer['cycleData'] if x.startswith('Pending')]): extId += '(pending)'
        except: pass
        
        # Check if cycling on another offer.  NOTE: really should check parent OID to see which object we're cycling on, but for now the resource ID will suffice.
        try: extId += '(c' + offer['cycleData']['CycleAlignmentResourceId'] + ')'
        except: pass
        
        # Check for Contracts
        strToCheck = 'serviceContractData'
        if strToCheck in offer and len(offer[strToCheck]): extId += '(SC' + offer[strToCheck]['ContractId'] + ')'
        strToCheck = 'financeContractData'
        if strToCheck in offer and len(offer[strToCheck]): extId += '(FC' + offer[strToCheck]['ContractId'] + ')'
        
        # Supplemental overrides Priority
        if 'IsSupplemental' in offer['MtxPricingOfferDetailInfo'] and offer['MtxPricingOfferDetailInfo']['IsSupplemental'].lower() == 'true':
            priority = 'S'
        elif mainBundle:                    priority = 'N/A'
        elif 'Priority' in offer['MtxPricingOfferDetailInfo']:  priority = offer['MtxPricingOfferDetailInfo']['Priority']
        else:                           priority = '?'
        
        # For sorting, need an integer for priority
        if priority.isdigit():  prioritySort = int(priority)
        else:           prioritySort = -10000
        
            # Get optional custom fields iff present and command did not request they be hidden
        key = 'offerCustomAttr'
        if key in configDct and not options.hideCustomData: 
            # Get the custom attributes
            _data = printCustomData(offer, configDct[key], printFlag = False, objType='offer')
            if _data:
                # Add spacing if template data present
                if customData: customData += '\n' + '-'*20 + '\n\n'
                try:    customData += 'Offer Custom Data:\n' + _data
                except: customData += 'Offer Custom Data:\nNon-ASCII Characters (should print...)'
                
        # Print parameters if defined and not blocked
        if 'parameterData' in offer and len(offer['parameterData']) and not options.hideParameterData:
               _data = printParameterData(offer['parameterData'])
               if _data:
                       # Add spacing if template data present
                       if customData: customData += '\n' + '-'*20 + '\n\n'
                       try:    customData += 'Offer Parameters:\n' + _data
                       except: customData += 'Offer Parameters:\nNon-ASCII Characters (should print...)'
        
        # Add OfferCategory to custom data
        if 'OfferCategory' in offer['attrDict']: customData += ' ' + offer['attrDict']['OfferCategory']
            
        # ID will also include the product version iff it's defined and greater than 0 (default)
        if offer['ProductOfferVersion'].isdigit() and int(offer['ProductOfferVersion']) > 0: id += '-' + offer['ProductOfferVersion']
        
        # Output depends on configured
        if output == 'full':
            # If the first time, then output header
            if not numberPrint:
                numberPrint += 1
                
                print('\nOffers:')
                sys.stdout.write(formatHeader % headers)
            
            # Output the data
            sys.stdout.write(formatHeader % \
                            (\
                            id,\
                            name,\
                            extId,\
                            priority,\
                customData))
            
            # Output the data
            format = "%-18s %-37s %-37s\n"
            label = 'Offer Start Times:'
            sys.stdout.write(format % (label, StartTime+'(S)', PurchaseTime+'(P)'))
            label = 'Offer End Times:'
            sys.stdout.write(format % (label, CancelEndTime+'(C)', EndTime+'(E)'))
            
            # Output description
            description = ', Description: '
            if 'Description' in offer['MtxPricingOfferDetailInfo']: description += offer['MtxPricingOfferDetailInfo']['Description']
            else:                           description += '<None>'
            
            format = "%-45s %-45s \n"
            #sys.stdout.write(format % (extId, description))
            print(description)
        else:
            # Output everything on one line
            if ActivationTime != 'N/A':    sTime = ActivationTime + '(A)'
            elif StartTime != 'N/A':       sTime = StartTime + '(S)'
            else:                  sTime = PurchaseTime + '(P)'
            if CancelEndTime != 'N/A': eTime = CancelEndTime + '(C)'
            elif offer['Status'] in ['5', 'pre_active']: eTime = AutoActivationTime + '(A)'
            else:              eTime = EndTime + '(E)'
            
            # Strip-off the usec value (no value add - always zero)
            sTime = sTime[0:19] + sTime[26:]
            eTime = eTime[0:19] + eTime[26:]
            
            # Add to the offer list
            offerList.append((id, name, extId, prioritySort, priority, sTime, eTime, customData, int(offer['ResourceId'])))
    
    # Process all global offers
    if globalOffers:
       for i in range(len(globalOffers)):
        offer = globalOffers[i]
        #print 'Offer = ' + str(offer)
        
        # See if offer still valid
        if 'EndTime' in offer and options and options.hideExpired and objectIsExpired(offer['EndTime'], options.date): continue
            
        # Get key values
        id = offer['OfferId']
        if offer['Version'] != '0': id += '-' + offer['Version']
        name = offer['Name'] + '*'
        if 'ExternalId' in offer: extId = offer['ExternalId']
        else: extId = 'N/A'
        if 'Priority' in offer: priority = offer['Priority']
        else: priority = 'S'
        if priority.isdigit():  prioritySort = int(priority)
        else:           prioritySort = -111
        if 'StartTime' in offer:   sTime = offer['StartTime'] + '(S)'
        else:              sTime = 'N/A'
        if 'EndTime' in offer:     eTime =  offer['EndTime'] + '(C)'
        else:              eTime = 'N/A'
        customData = ''
        
        # Strip-ff the usec value (no value add - always zero)
        sTime = sTime[0:19] + sTime[26:]
        eTime = eTime[0:19] + eTime[26:]
            
        # Add to the offer list
        offerList.append((id, name, extId, prioritySort, priority, sTime, eTime, customData, 0))
            
    # Split list into "N/A", "S", "?", and what's left
    offerListNA =  [x for x in offerList if x[4] == 'N/A']
    offerListQ =   [x for x in offerList if x[4] == '?']
    offerListSup = [x for x in offerList if x[4] == 'S']
    offerList = list(set(offerList) ^ set(offerListNA) ^ set(offerListQ) ^ set(offerListSup))
    
        # Sort the event list based on priority
    if sortType.lower() == 'priority':
            offerList = sorted(offerList, key=lambda priority: priority[3], reverse=True)
    else:   offerList = sorted(offerList, key=lambda priority: priority[8], reverse=True)
    
    # Sort the rest based on name (so like CIs are printed together)
    offerListNA  = sorted(offerListNA,  key=lambda name: name[1])
    offerListQ   = sorted(offerListQ,   key=lambda name: name[1])
    offerListSup = sorted(offerListSup, key=lambda name: name[1])
    
    # Add back in the other sets :-)
    offerList.extend(offerListSup)
    offerList.extend(offerListNA)
    offerList.extend(offerListQ)
    
    # If anything to process, output the data
    if len(offerList):
     # Get width
     offerWidth1 = len(max((L[1] for L in offerList), key=len))
     offerWidth2 = len(max((L[2] for L in offerList), key=len))
        
     # If here, then remainder of the output will be condensed output.  Force header to this value.     
     formatHeader = "%5s %-" + str(offerWidth1) + "s %-" + str(offerWidth2) + "s %11s %-28s %-28s %s\n"
    
     # Need to add padding to custom data, except for first line.
     # Sum the format length (lengths plus space between).
     padding = 6 + offerWidth1 + offerWidth2 + 2 + 12 + 58
     
     print('\nOffers:')
     sys.stdout.write(formatHeader % headers)
            
     # Now print in priority-sorted order
     for offer in offerList:
        # Extract fields
        (id, name, extId, sort, priority, sTime, eTime, customData, resourceId) = offer
        
        # Split custom
        customData = customData.split("\n")
        
        # Clean up first entry
        customData[0] = customData[0].strip().rstrip(',')
        
        # If more than one line, do something
        if len(customData) > 1:
            # Add padding so subsequent lines start indented.  Removing white space and trailing comma (looks silly).
            for i in range(1,len(customData)): customData[i] = ' '*padding + customData[i].strip().rstrip(',')
        
        # Rejoing custom
        customData = "\n".join(customData)
        
        # Print
        try: 
             sys.stdout.write(formatHeader % \
                       (\
                    id,\
                    name,\
                    extId,\
                        str(priority),\
            sTime,\
            eTime,\
            customData)\
               )
        except:
             sys.stdout.write(formatHeader % \
                       (\
                    id,\
                    name.encode('utf-8'),\
                    extId,\
                        str(priority),\
            sTime,\
            eTime,\
            customData.decode('utf-8').encode('utf-8'))\
               )
        
    # Restore input list
    dctRcv = copy.deepcopy(saveDctRcv)
    
    return
    
#===============================================================================
# This function outputs subscription data
def outputSubscriptionData(dctRcv, configDct, queryId, queryType, options, program=None, objType='Subscription'):
    #pprint.pprint(dctRcv)
    
    # Save dictionary (it may be overwritten by subscriber output call)
    saveDct = copy.deepcopy(dctRcv)
    
    # Output subscriber first (lots of overlap)
    outputSubscriberData(dctRcv, configDct, queryId, queryType, options, program=program, objType=objType)
    
    # Restore dictionary
    dctRcv = copy.deepcopy(saveDct)
    
#===============================================================================
# This function outputs subscriber data
def outputSubscriberData(dctRcv, configDct, queryId, queryType, options, program=None, objType='Subscriber'):
    # Use input date is specified, else use current time
    if options.date: date = options.date
    else:        date = time.strftime("%c %Z", time.localtime())
    #else:       date = time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime())
    
    # Get route ID if present (only from release 5xxx onwards)
    if 'RouteId' in dctRcv: routeId = ' route ID ' + dctRcv['RouteId']
    else:           routeId = ''
    
    # ***** Output subscriber ID *****
    print('\n**** Data For ' + objType + ' ' + str(queryId) + ' (' + queryType + ')' + routeId + ' at time ' + date + ' ****\n')
    #pprint.pprint(configDct)
    
    # ***** Output subscriber summary data *****
    # Get status string
    status = getStatusDataForOutput(dctRcv)

    # Many items are optional
    if 'TimeZone' in dctRcv:    timezone = dctRcv['TimeZone']
    else:               timezone = 'Not Set'
    
    if 'ExternalId' in dctRcv:  externalId = dctRcv['ExternalId']
    else:               externalId = 'N/A'

    # Add additional data
    if 'NotificationPreference' in dctRcv:
        if   dctRcv['NotificationPreference'] == '1': notificationPreference = 'Email'
        elif dctRcv['NotificationPreference'] == '2': notificationPreference = 'Text'
        elif dctRcv['NotificationPreference'] == '3': notificationPreference = 'Text and Email'
        elif dctRcv['NotificationPreference'] == '4': notificationPreference = 'USSD'
        elif dctRcv['NotificationPreference'] == '65536': notificationPreference = 'In-App'
        else:                         notificationPreference = 'Custom'
        notificationPreference += '(' + dctRcv['NotificationPreference'] + ')'
    else:   notificationPreference = 'N/A'
    
    outString = ''
    spacer = ', '
    if not notificationPreference.startswith('Custom'):
        if notificationPreference.count('Phone') and 'ContactPhoneNumber' in dctRcv:
            outString += 'Contact Phone: ' + dctRcv['ContactPhoneNumber'] + spacer
        if notificationPreference.count('Email') and 'ContactEmail' in dctRcv:
            outString += 'Contact Email: ' + dctRcv['ContactEmail'] + spacer
    for key in ['FirstName', 'LastName', 'GlCenter', 'Language']:
        if key in dctRcv: outString += key + ': ' + dctRcv[key] + spacer
    
    # Finally output the data
    print()
    format = "%s %s, %s\n%s, %s\n%s\n"
    # Check for output filters
    key = 'Basic'
    printData = outputFilterCheck(options, key)
    if printData:
        sys.stdout.write(format % \
                ('Basic data:     ',\
                'External ID = ' + externalId,\
                'OID = ' + dctRcv['ObjectId'],\
                ' '*17+'Timezone = ' + timezone,\
                'NotificationPreference = ' + notificationPreference,\
                ' '*17+outString[:-(len(spacer))],\
                 ))
        if objType.startswith('Subscri'): print('Status  (S):     ' + status)
    
    # ***** Output device summary data if present
    if True:
         # Check for output filters
         key = 'Device'
         printData = outputFilterCheck(options, key)
    
         linep2 = ''
         currentLength = 0
         #print('Device Data:')
         #pprint.pprint(dctRcv['devices'])
         for i in range(len(dctRcv['devices'])):
             # Store device in local variable for readability
             device = dctRcv['devices'][i]
        
             # If no IMSI present, then skip (mis-match of custom device names - usually due to create_demo.py)
             if 'Imsi' in device:
                  devStr = 'IMSI = '
                  devValue = device['Imsi']
             elif 'LoginId' in device:
                  devStr = 'LoginID = '
                  devValue = device['LoginId']
             else:
                  devStr = 'Unknown '
                  devValue = ''
        
             linep2 += 'Device   D' + str(i) + ':     '
             # Output identifier
             linep2 += devStr + devValue

             # Add in any defined access numbers
             try:
                if len(device['accessNumbers']):
                  linep2 += ', Access Numbers ='

                  # Add each one individually (looks better than dumping an array)
                  for j in range(len(device['accessNumbers'])): linep2 += ' '+ device['accessNumbers'][j]
             except: pass
             
             # If external ID defined, then report it
             key = 'ExternalId'
             if key in device: linep2 += ', ' + key + ' = ' + device[key]
        
             # Get status string
             status = getStatusDataForOutput(device)
        
             # Add OID
             linep2 += ', OID = ' + device['ObjectId']
        
             # Add status to output line
             linep2 += '\nStatus  (D' + str(i) + '):    ' + status

             # See if sessions were found
             if 'sessions' in device:
                 linep2 += '\nSessions(D' + str(i) + '):    '
                 if 'policySession' in device['sessions']: linep2 += 'Policy(' + str(len(device['sessions']['policySession'])) + ') '
                 if 'chargingSession' in device['sessions']: linep2 += 'Charging(' + str(len(device['sessions']['chargingSession'])) + ')' 
            
                 # Separate with new line and spacing
                 linep2 += '\n'
        
         # If anything returned, then output line
         if printData and linep2: print(linep2)
    
    # ***** Output parent Users
    key = 'User'
    line = 'Parent Users:   '
    if outputFilterCheck(options, key) and 'users' in dctRcv and len(dctRcv['users']): printUser(dctRcv['users'], line, options=options)
        
    # ***** Output parent group
    key = 'Parent'
    line = 'Parent Group:    '
    if outputFilterCheck(options, key) and 'groups' in dctRcv: printList(dctRcv['groups'], line, options=options)
    
    # ***** Output admin list
    key = 'Group'
    line = 'Admins:          '
    if outputFilterCheck(options, key) and len(dctRcv['administrators']): printList(dctRcv['administrators'], line, options=options)
    
    # ***** Output bill cycle data if present
    if True:
         # Check for output filters
         key = 'Bill'
         line = 'Bill cycle (C):  '
         if outputFilterCheck(options, key): printBillCycle(dctRcv['billCycle'], line, options=options)
         line = 'Bill cycle (N):  '
         if outputFilterCheck(options, key): printBillCycle(dctRcv['nextbillCycle'], line, options=options)
     
    # ***** Output custom attributes if present
    key = 'Custom'
    printData = outputFilterCheck(options, key)
    
    key = 'subscriberCustomAttr'
    if key in configDct: customAttr = configDct[key]
    else:                   customAttr = None
    if printData and customAttr: printCustomData(dctRcv, customAttr, options=options, objType='subscriber')
    
    # Exit here is not a subscriber
    #if objType != 'Subscriber': return
    
    # ***** Output payment data if present
    key = 'PaymentToken'
    if key in dctRcv: printPaymentTokenData(dctRcv[key], dctRcv[key+'Info'], options=options, objType='subscriber')
    
    key = 'PaymentMethod'
    if key in dctRcv: printPaymentMethodData(dctRcv[key], options=options, objType='subscriber')
     
    # ***** Output offers *****
    key = 'Offers'
    printData = outputFilterCheck(options, key)
    if printData:
        # Get global + one-timeoffers
        if program and configDct['viewGlobals']: globalAndOneTimeOffers = GET.getPricingOffers(program, options, configDct['viewGlobals'])
        else: 
            globalAndOneTimeOffers = {}
            globalAndOneTimeOffers['globalOffers'] = []
        
        printOffers(dctRcv['offers'], configDct, options=options, globalOffers = globalAndOneTimeOffers['globalOffers'], devices = dctRcv['devices'])
    
    # Print contracts
    key = 'Contracts'
    printData = outputFilterCheck(options, key)
    if printData:
        printContracts(dctRcv['offers'], configDct, options=options)
    
    # NOTE:  With Rollover functionality one needs to augment the queried balance amount with rollover data (so we show the total available amount)
    processRollOverData(dctRcv['balances'], dctRcv['periodicBalanceInfo'], date)
    
    # ***** Output balance summary *****
    key = 'Balances'
    printData = outputFilterCheck(options, key)
    if printData: printBalances(dctRcv['balances'], options, dctRcv['simpleBalanceInfo']+dctRcv['periodicBalanceInfo'], dctRcv['tierBalances'], dctRcv['devices'], program=program)

    # ***** Output periodic balance data *****
    key = 'Periods'
    printData = outputFilterCheck(options, key)
    if printData: printPeriods(dctRcv['periodicBalanceInfo'], options=options, program=program)

    # ***** Output simple balance data *****
    key = 'Simple'
    printData = outputFilterCheck(options, key)
    if printData: printSimple(dctRcv['simpleBalanceInfo'], options=options, program=program)

    # ***** Output balance threshold data *****
    key = 'Threshold'
    printData = outputFilterCheck(options, key)
    if printData: 
        supressHeadings = printThresholds(dctRcv['periodicBalanceInfo'], options=options, program=program)
        printThresholds(dctRcv['simpleBalanceInfo'], supressHeadings=supressHeadings, options=options, program=program)

#===============================================================================
# This function outputs group data
def outputGroupData(dctRcv, configDct, queryId, queryType, options, program):
    # Use input date is specified, else use current time
    if options.date: date = options.date
    else:        date = time.strftime("%c %Z", time.localtime())
    #else:       date = time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime())
    
    # Get route ID if present (only from release 5xxx onwards)
    if 'RouteId' in dctRcv: routeId = ' route ID ' + dctRcv['RouteId']
    else:           routeId = ''
    
    # ***** Output subscriber ID *****
    print('\n**** Data For Group ' + str(queryId) + ' (' + queryType + ')' + routeId + ' at time ' + date + ' ****\n')

    # ***** Output subscriber summary data *****
    # Check for output filters
    key = 'Basic'
    printData = outputFilterCheck(options, key)
    
    # Get status string
    status = getStatusDataForOutput(dctRcv)
        
    # Many items are optional
    if 'TimeZone' in dctRcv:    timezone = dctRcv['TimeZone']
    else:               timezone = 'Not Set'
    
    if 'ExternalId' in dctRcv:  externalId = dctRcv['ExternalId']
    else:                   externalId = 'N/A'
    
    if 'Tier' in dctRcv:    tier = dctRcv['Tier']
    else:               tier = 'N/A'
    
    if 'Name' in dctRcv:    name = dctRcv['Name']
    else:               name = 'N/A'
    
    if 'GlCenter' in dctRcv:    glCenter = dctRcv['GlCenter']
    else:               glCenter = 'N/A'

    if 'NotificationPreference' in dctRcv:
        val = dctRcv['NotificationPreference']
        if   val == '1': notificationPreference = 'Notify Admins(1)'
        elif val == '2': notificationPreference = 'Notify Memebers(2)'
        else:            notificationPreference = 'Custom(' + val + ')'
    else:   notificationPreference = 'Notify Members(default)'
    if 'GroupReAuthPreference' in dctRcv and dctRcv['GroupReAuthPreference']:
        val = dctRcv['GroupReAuthPreference']
        if   val == '0': groupReAuthPreference = 'Disable Group (0)'
        elif val == '1': groupReAuthPreference = 'Enable group purchase (1)'
        elif val == '2': groupReAuthPreference = 'Enable group cancel (2)'
        elif val == '3': groupReAuthPreference = 'Enable group purchase or cancel (3)'
        elif val == '4': groupReAuthPreference = 'Enable group status change (4)'
        elif val == '5': groupReAuthPreference = 'Enable group purchase or status change (5)'
        elif val == '6': groupReAuthPreference = 'Enable group cancel or status change (6)'
        elif val == '7': groupReAuthPreference = 'Enable group purchase, csncel, or status change (7)'
        else:        groupReAuthPreference = 'Unknown(' + str(val) + ')'
    else:   groupReAuthPreference = 'Disable Group RAR (default)'
    
    # Finally output the data
    print()
    format = "%s %s, %s\n%s, %s, %s, %s\n%s, %s\n"
    if printData:
        sys.stdout.write(format % \
                ('Basic data:     ',\
                'External ID = ' + externalId,\
                'OID = ' + dctRcv['ObjectId'],\
                ' '*17+'Timezone = ' + timezone,\
                'Tier = ' + tier,\
                'Name = ' + name,\
                'GlCenter = ' + glCenter,\
                ' '*17+'NotificationPreference = ' + notificationPreference,\
               'GroupReAuthPreference  = ' + groupReAuthPreference,\
                ))
        print('Status(G):       ' + status)

    # ***** Output tax data *****
    # Check for output filters
#   key = 'Tax'
#   line = 'Tax data:        '
#   if outputFilterCheck(options, key): printTax(dctRcv['tax'], line)

    # ***** Output parent group
    key = 'Parent'
    line = 'Parent Group:    '
    if outputFilterCheck(options, key) and 'ParentGroupId' in dctRcv: print(line + str(dctRcv['ParentGroupId']))

    # ***** Output child Subscriber
    key = 'Subscriber'
    line = 'Subscriber Child:'
    if outputFilterCheck(options, key) and len(dctRcv['subscribers']): printList(dctRcv['subscribers'], line, options=options)

    # ***** Output child Groups
    key = 'Group'
    line = 'Group Children:  '
    if outputFilterCheck(options, key) and len(dctRcv['subgroups']): printList(dctRcv['subgroups'], line, options=options)

    # ***** Output admin list
    key = 'Group'
    line = 'Admins:          '
    if outputFilterCheck(options, key) and len(dctRcv['administrators']): printList(dctRcv['administrators'], line, options=options)

    # ***** Output bill cycle data if present
    # Check for output filters
    key = 'Bill'
    line = 'Bill cycle (C):  '
    if outputFilterCheck(options, key): printBillCycle(dctRcv['billCycle'], line, options=options)
    line = 'Bill cycle (N):  '
    if outputFilterCheck(options, key): printBillCycle(dctRcv['nextbillCycle'], line, options=options)

    # ***** Output custom attributes if present
    key = 'Custom'
    printData = outputFilterCheck(options, key)

    key = 'groupCustomAttr'
    if key in configDct: customAttr = configDct[key]
    else:              customAttr = None
    if printData and customAttr: printCustomData(dctRcv, customAttr, options=options, objType='group')

    # ***** Output payment data if present
    key = 'PaymentToken'
    if key in dctRcv: printPaymentTokenData(dctRcv[key], dctRcv[key+'Info'], options=options, objType='group')
    
    key = 'PaymentMethod'
    if key in dctRcv: printPaymentMethodData(dctRcv[key], options=options, objType='group')

    # ***** Output offers *****
    key = 'Offers'
    printData = outputFilterCheck(options, key)
    if printData: printOffers(dctRcv['offers'], configDct, options=options)
    
    # Print contracts
    key = 'Contracts'
    printData = outputFilterCheck(options, key)
    if printData:
        printContracts(dctRcv['offers'], configDct, options=options)
    
    # NOTE:  With Rollover functionality one needs to augment the queried balance amount with rollover data (so we show the total available amount)
    processRollOverData(dctRcv['balances'], dctRcv['periodicBalanceInfo'], date)
    
    # ***** Output balance summary *****
    key = 'Balances'
    printData = outputFilterCheck(options, key)
    if printData: printBalances(dctRcv['balances'], options, dctRcv['simpleBalanceInfo']+dctRcv['periodicBalanceInfo'], dctRcv['tierBalances'], program=program)

    # ***** Output periodic balance data *****
    key = 'Periods'
    printData = outputFilterCheck(options, key)
    if printData: printPeriods(dctRcv['periodicBalanceInfo'], options=options, program=program)

    # ***** Output simple balance data *****
    key = 'Simple'
    printData = outputFilterCheck(options, key)
    if printData: printSimple(dctRcv['simpleBalanceInfo'], options=options, program=program)

    # ***** Output balance threshold data *****
    key = 'Threshold'
    printData = outputFilterCheck(options, key)
    if printData: 
        supressHeadings = printThresholds(dctRcv['periodicBalanceInfo'], options=options, program=program)
        printThresholds(dctRcv['simpleBalanceInfo'], supressHeadings=supressHeadings, options=options, program=program)

#===============================================================================
def processRollOverData(dctBalances, dctPeriodicBalanceInfo, date):
        # Process each balance
        for i in range(len(dctPeriodicBalanceInfo)):
            # Put period into local structure for readability
            balance = dctPeriodicBalanceInfo[i]

            #print 'balance ' + str(i) + ':\n' + str(balance)

            # Remove non-peridic balances
            if balance['IsPeriodic'].lower() != 'true': continue

            # Remove virtual balances
            if balance['IsVirtual'].lower() == 'true': continue

            # If there's no amount, then there's no balance instance (on-demand balances)
            if 'Amount' not in balance: continue

            # Report each balance in a separate line
            rolloverTotal = 0.0
            rolloverReserved = 0.0
            foundFlag = False
            currentPeriodIndex = -1
            for j in range(len(balance['periods'])):
                    # Put period into local structure for readability
                    entry = balance['periods'][j]
            
            # Want to count the current period as well as rollover periods.
            # Current period doesn't have any rollover data assigned it.
            if PRIM.checkIfTime2GreaterTime1(date, entry['EndTime'])  and \
               PRIM.checkIfTime2GreaterTime1(entry['StartTime'], date)  :
                # This is the current period.  Add to rollover total.
                rolloverTotal += float(entry['Amount'])
                
                # Get reserved (so we aggregate it up)
                rolloverReserved += float(entry['ReservedAmount'])
                
                # Set current period index
                currentPeriodIndex = j
                
                # Nothing else to do here
                continue
            
            # If this period isn't part of any rollover, then skip
            if 'RolloverAmount' not in entry: continue
            
            # If the rollover end date is later than the input time, then skip
            if PRIM.checkIfTime2GreaterTime1(entry['RolloverEndTime'], date):
                # Change rollover amount to 0, as this is an expired period
                entry['RolloverAmount'] = '0.0'
                
                continue
            
            # We found a rollover amount
            foundFlag = True
            
            # Set flag so we can show which period impacts the rollover
            entry['RolloverValid'] = True
            
            # If here, then we want to include this period in the rollover calculation
            rolloverTotal += float(entry['RolloverAmount'])
            rolloverReserved += float(entry['ReservedAmount'])
            
            # If nothing found, then can skip
            if not foundFlag or rolloverTotal == 0.0: continue
        
            # Set current period to be included in rollover, as it's always there is other periods are included.
            balance['periods'][currentPeriodIndex]['RolloverValid'] = True
            
            # If here, then we want to change the balance total amount to reflect the rollover amount.
            # Not sure that a subscriber query returns balances in the same order as a wallet query.  
            # No assumptions: find the balance using the resource ID
            foundFlag = False
            for j in range(len(dctBalances)):
                # Put in local for redability
                singleBalance = dctBalances[j]
                
                # Compare the resource IDs
                if str(singleBalance['ResourceId']) == str(balance['ResourceId']):
                    # Signal found
                    foundFlag = True
                    break
            
            # Sanity check that we found the balance
            if not foundFlag:
                print('Hmmmm: looking for balance resource ID ' + str(balance['ResourceId']) + ' in periodic balances but didn\'t find it')
                print('Peridoic balance entry:\n' + str(balance))
                print('Balances dictionary:\n'    + str(dctBalances))
            else:
                # Add total to balance array
                singleBalance['TotalRolloverAmount'] = str(rolloverTotal)
                singleBalance['TotalRolloverReserved'] = str(rolloverReserved)
                #print 'Balance ' + str(singleBalance) + ' local amount = ' + singleBalance['Amount'] + ', rollover total = ' + singleBalance['TotalRolloverAmount'] + ', rollover reserved amount = ' + singleBalance['TotalRolloverReserved']
        
        return
    
#===============================================================================
def getBalanceClassAndTemplateNames(classId, templateId, configDct):
        url = '/rsgateway/data/v3/pricing/balance/' + templateId + PRIM.getTimeStampStr(GET.commandTime)
        q = GET.curlToETFormat(url)

        # Read in XML data
        try:
                classId    = q.find('./BalanceInfo/MtxPricingBalanceDetailInfo/ClassName').text.strip()
                templateId = q.find('./BalanceInfo/MtxPricingBalanceDetailInfo/Name').text.strip()
        #if not OnlyAscii(templateId): templateId = '(Non-ASCII characters)'
                QuantityUnit = q.find('./BalanceInfo/MtxPricingBalanceDetailInfo/QuantityUnit').text.strip()
        except:
                print('WARN: Could not read balance template ' + templateId + ' data from server ' + configDct['hostname'] + ':' + configDct['hostport'])
                QuantityUnit = 'Unknown'

        return (classId, templateId, QuantityUnit)

#===============================================================================
def printUser(dctRcv, line, options):
    format = "%-14s %-25s %-25s %-16s %-s\n"
    
    # Output parent user data
    for user in dctRcv:
        # Setup local variables
        ObjectId = user['ObjectId'] if 'ObjectId' in user else 'N/A'
        ExternalId = user['ExternalId'] if 'ExternalId' in user else 'N/A'
        UserId = user['UserId'] if 'UserId' in user else 'N/A'
        RelationshipType = user['RelationshipType'] if 'RelationshipType' in user else 'N/A'
        
        # Get role if present
        try:    role = user['role'][0]['Name']
        except: role = 'Unknown' 
        
        # Output data in pieces
        sys.stdout.write(format % \
                    (line,\
                    'User ID = ' + UserId,\
                    'External ID = ' + ExternalId,\
                    'OID = ' + ObjectId,\
            'Role = ' + role,\
                    ))
        
        # Clear the heading (only output once per loop)
        line = ''
        
#===============================================================================
def printBalanceImpactInfo(dctEvent, configDct, options):
        global unitMapping
    
        # May not have any balance impacts
        key = 'BalanceUpdateArray'
        if key not in dctEvent: return

        print()
        line = ''
        items = ['ID', 'BalanceClassId', 'BalanceTemplateId', 'Amount', 'QuantityUnit']
        length = ['5', '30', '30', '17', '10']

        # Debug output
#       print 'printBalanceImpactInfo: dctEvent = ' + str(dctEvent)

        # Loop through each impacted balance
        for idx in range(len(dctEvent[key])):
            # Store ID if not already done so
            if 'ID' not in dctEvent[key][idx]: dctEvent[key][idx]['ID'] = idx
        
            # Convert balance class and template to names
            (dctEvent[key][idx]['BalanceClassId'], dctEvent[key][idx]['BalanceTemplateId'], dctEvent[key][idx]['QuantityUnit']) =  \
                    getBalanceClassAndTemplateNames(dctEvent[key][idx]['BalanceClassId'], dctEvent[key][idx]['BalanceTemplateId'], configDct)

            # Set unit amount
            if 'QuantityUnit' in dctEvent[key][idx] and \
               dctEvent[key][idx]['QuantityUnit'] in unitMapping: dctEvent[key][idx]['QuantityUnit'] = unitMapping[dctEvent[key][idx]['QuantityUnit']]
        
            # Format the data
            i = 0
        
            for item in items:
                        format = '%-' + length[i] + 's '
                        if item in dctEvent[key][idx]: line += format % dctEvent[key][idx][item]
                        else:                                line += format % ' '
                        i += 1

            # Add new line between iterations
            line += "\n"

        # Output the information if anything is present
        if line:
                # Output heading
                format = 'Balance Data:\n'
                for idx in range(len(length)): format += '%-' + length[idx] + 's '
                format += '\n'
                sys.stdout.write(format % ('Index', 'Class:', 'Template', 'Amount', 'Units'))

                # Output data
                print(line[:-2] + "\n")

        return

#===============================================================================
def printChargeListInfo(dctEvent, options):
        # Define mapping of unit to text
        global unitMapping
    
        # May not have any data
        key = 'ChargeList'
        if key not in dctEvent: return

        print()
        line = ''
        items = ['AppliedOfferIndex', 'BalanceUpdateIndex', 'UsageQuantity', 'UsageQuantityUnit', 'Amount']
        length = ['17', '17', '15', '10', '17']
    
        # Process every offer in the event
        for idx in range(len(dctEvent[key])):
         i = 0
         # Set unit amount
         lclKey = 'UsageQuantityUnit'
         if lclKey in dctEvent[key][idx] and \
           dctEvent[key][idx][lclKey] in unitMapping: dctEvent[key][idx][lclKey] = unitMapping[dctEvent[key][idx][lclKey]]
        
         for item in items:
                        format = '%-' + length[i] + 's '
                        if item in dctEvent[key][idx]: line += format % dctEvent[key][idx][item]
                        else:                          line += format % ' '
            
                        # Bump index
                        i += 1
        
         # Add new line between iterations
         line += "\n"

        # Output the information if anything is present
        if line:
                # Output heading
                format = 'Charge List Data\n'
                for idx in range(len(length)): format += '%-' + length[idx] + 's '
                format += '\n'
                sys.stdout.write(format % ('Offer Index', 'Balance Index', 'Usage', 'Units', 'Balance Update'))

                # Output data
                print(line[:-2] + "\n")

#===============================================================================
def printUsageQuantityInfo(dctEvent, options):
    # Define mapping of unit to text
    global unitMapping
    global typeMapping
    
    # May not have any  data
    key = 'UsageQuantityList'
    if key not in dctEvent: return

    print()
    line = ''
    items = ['MsgAmount', 'RatingAmount', 'QuantityType', 'QuantityUnit']
    length = ['17', '17', '15', '10']
    
    # Process every offer in the event
    for idx in range(len(dctEvent[key])):
        i = 0
        # Set unit amount
        lclKey = 'QuantityUnit'
        if lclKey in dctEvent[key][idx] and \
           dctEvent[key][idx][lclKey] in unitMapping: dctEvent[key][idx][lclKey] = unitMapping[dctEvent[key][idx][lclKey]]
        
        # Set unit type
        lclKey = 'QuantityType'
        if lclKey in dctEvent[key][idx] and \
           dctEvent[key][idx][lclKey] in unitMapping: dctEvent[key][idx][lclKey] = typeMapping[dctEvent[key][idx][lclKey]]
        
        for item in items:
                        format = '%-' + length[i] + 's '
                        if item in dctEvent[key][idx]: line += format % dctEvent[key][idx][item]
                        else:                          line += format % ' '
            
                        # Bump index
                        i += 1
        
        # Add new line between iterations
        line += "\n"

    # Output the information if anything is present
    if line:
                # Output heading
                format = ''
                for idx in range(len(length)): format += '%-' + length[idx] + 's '
                format += '\n'
                sys.stdout.write(format % ('Message Amount:', 'Rated Amount', 'Type', 'Units'))

                # Output data
                print(line[:-2] + "\n")

#===============================================================================
def printOfferSegmentInfo(dctEvent, options):
    # Define mapping of unit to text
    global unitMapping
    
    # May not have any  data
    key = 'AppliedOfferArray'
    if key not in dctEvent: return

    print()
    line = ''
    items = ['ID', 'ProductOfferExternalId', 'ProductOfferId', 'UsageQuantity', 'UsageQuantityUnit']
    length = ['5', '45', '10', '17', '10']
    
    # Process every offer in the event
    for idx in range(len(dctEvent[key])):
        # Store ID if not already done so
        if 'ID' not in dctEvent[key][idx]: dctEvent[key][idx]['ID'] = idx
        
        i = 0
        # Set unit amount
        lclKey = 'UsageQuantityUnit'
        if lclKey in dctEvent[key][idx] and \
           dctEvent[key][idx][lclKey] in unitMapping: dctEvent[key][idx][lclKey] = unitMapping[dctEvent[key][idx][lclKey]]
        
        for item in items:
                        format = '%-' + length[i] + 's '
                        if item in dctEvent[key][idx]: line += format % dctEvent[key][idx][item]
                        else:                          line += format % ' '
            
                        # Bump index
                        i += 1
        
        # Add new line between iterations
        line += "\n"

    # Output the information if anything is present
    if line:
                # Output heading
                format = 'Offer Data:\n'
                for idx in range(len(length)): format += '%-' + length[idx] + 's '
                format += '\n'
                sys.stdout.write(format % ('Index', 'External ID:', 'CB ID', 'Amount', 'Units'))

                # Output data
                print(line[:-2] + "\n")

#===============================================================================
def outputDeviceAggregationHeading(dctRcv):
        # Setup heading
        line = '\n\n*** Aggregation Summary for service ID ' + dctRcv['Id'] + '(' + dctRcv['Name']+ ') ***\n'
        
        # If time is true, then get additional values
        if dctRcv['IsAggregationByTime'].lower() == 'true':
            # Setup time string
            line += 'Time = True, interval = ' + dctRcv['AggregationPeriodType'] + '\n'
        
        # Add session status if true
        if dctRcv['IsAggregationBySession'].lower() == 'true': line += 'Session = True\n'

        # If session is true, then get additional values
        if dctRcv['HasAggregationQuantityLimit'].lower() == 'true':
            # Add size details
            line += '\nSize limit = True, limit = '+ dctRcv['AggregationUsageQuantityLimit'] + ' ' + dctRcv['AggregationUsageQuantityLimitUnit'] 
            
            # Add rated vs. raw details
            if dctRcv['IsAggregationRatingQuantityLimit'].lower() == 'true': 
                line += ' (rated)'
            else:   line += ' (raw)'
            
            # Add trailing space
            line += '\n'
        
        # Output summary data
        print(line[:-1])
        
#===============================================================================
def outputDeviceAggregationComponent(dctRcv, component, configDct, id, queryType, options):
    # If no aggregations, then exit
    if 'EventTime' not in dctRcv: 
        print('\n*** No ' + component + ' Aggregation data ***')
        return
    
        # *** Data Massaging ***
    
    # Use input date is specified, else use current time
    if options.date: date = options.date
    else:        date = time.strftime("%c %Z", time.localtime())
    #else:      date = time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime())
    
    # Update duration to remove usec component
    if 'Duration' in dctRcv: dctRcv['Duration'] = dctRcv['Duration'][:-6]

    # Shrink duration to only be seconds
    if 'ccRequestType' in dctRcv:
            if   dctRcv['ccRequestType'] == '2': dctRcv['ccRequestType'] = 'initial(2)'
            elif dctRcv['ccRequestType'] == '3': dctRcv['ccRequestType'] = 'interim(3)'
            elif dctRcv['ccRequestType'] == '4': dctRcv['ccRequestType'] = 'term(4)'

    # *** Output event data ***
    print('\n*** ' + component + ' Aggregation Data ' + dctRcv['EventTime']+ ' ***')
    #print '\n**** Data For Device ' + str(id) + ' (' + queryType + ') at time ' + date + ' ****\n'
    
    # ***** Output custom attributes if present
    key = 'Custom'
    printData = outputFilterCheck(options, key)
    
    '''
    key = 'usageEventAttr'
    if key in configDct:    customAttr = configDct[key]
    else:           customAttr = None
    if printData and customAttr: printCustomData(dctRcv, customAttr, objType='usage')
    '''
    
    # ***** Output parent data
    if 'WalletOwnerId' in dctRcv: 
        parentId = dctRcv['WalletOwnerId']
    else:   parentId = "N/A"
    if 'WalletOwnerExternalId' in dctRcv:
        parentExtId = dctRcv['WalletOwnerExternalId']
    else:   parentExtId = "N/A"
    print('Owner OID/ExtId ' + parentId + '/' + parentExtId)
    
    # Print Usage
    printUsageQuantityInfo(dctRcv, options)
    
    # Print offer data
    printOfferSegmentInfo(dctRcv, options)
        
    # Print balance data
    printBalanceImpactInfo(dctRcv, configDct, options)
    
    # Print Charge List data
    printChargeListInfo(dctRcv, options)
    
    # Print duration if present
    if 'Duration' in dctRcv: print('Duration: ' + dctRcv['Duration'])
    
#===============================================================================
def outputDeviceAggregation(dctRcv, configDct, id, queryType, options):
    # If primary aggregation present, then print summary data
    if 'EventTime' in dctRcv['Primary']: outputDeviceAggregationHeading(dctRcv['ServiceType'])

    # Process both events
    for key in ['Primary', 'Secondary']: outputDeviceAggregationComponent(dctRcv[key], key, configDct, id, queryType, options)
    
#===============================================================================
def printSessions(sessionType, dctRcv, configDct, options=None):
    # if nothing to output,  then do nothing
    if not len(dctRcv): return

    # Session format
    heading = 'Sessions(' + sessionType[0].upper()+ '): '
    length = [len(heading), '40', '25', '25', '20', '20']
    
    # Build format line
    format = ''
    for item in length: format += '%-' + str(item) + 's '
    format += '\n'
    
    # No policies for charging, so don;t print header in thi scase
    if sessionType[0].upper() == 'C': activeHeading = ''
    else:                 activeHeading = 'Active'
    # Output header     
    sys.stdout.write(format % (heading, 'SessionId', 'Last Update', 'Host', 'Realm', activeHeading))
    
    # Process every session
    for idx in range(len(dctRcv)):
        # Make sure data is present
        for field in ['SourceHost', 'SourceRealm', 'PolicyProfileName', 'SessionId', 'UpdateTime']:
            if field not in dctRcv[idx]: dctRcv[idx][field] = ' '
        if len(dctRcv[idx]['UpdateTime']) < 27: dctRcv[idx]['UpdateTime'] = 27*' '
        
        # See if any policies are present
        policyName = ''
        if 'policy' in dctRcv[idx]:
            for entry in dctRcv[idx]['policy']: policyName += entry + ','
        
        # Output the session
        sys.stdout.write(format % ( \
            ' ', \
            dctRcv[idx]['SessionId'], \
            dctRcv[idx]['UpdateTime'][0:19]+ dctRcv[idx]['UpdateTime'][26:], \
            dctRcv[idx]['SourceHost'], \
            dctRcv[idx]['SourceRealm'], \
            policyName[:-1]
            ))
    
    # Charging sessions have additoinal data
#   if sessionType == 'chargingSession':
#       print 'More data avaiable for chargng sessions'
    
#===============================================================================
# This function generates status information
def getStatusDataForOutput(dctRcv):
    # Get Generic values
    try: status = dctRcv['StatusDescription'] + '(' + dctRcv['Status'] + ')'
    except: return ''
    
    # 4750 added new fields. If present, then add here
    key = 'CurrentStatusTransitionTime'
    if key in dctRcv:
        # Open string
        status += '['
    
        # Store time stamp minus usec
        status += dctRcv[key][0:19] + dctRcv[key][26:] + '(E)'
        
        # Get last activity time (always present if current status is present)
        key = 'LastActivityTime'
        if key in dctRcv: status += '/' + dctRcv[key][0:19] + dctRcv[key][26:] + '(L)'
        
        # See if there's a next transition time (optional)
        key = 'NextStatusTransitionTimeEstimate'
        if key in dctRcv: status += '/' + dctRcv[key][0:19] + dctRcv[key][26:] + '(X)'
        
        # Close string
        status += ']'
    
    # Return status string
    return status
    
#===============================================================================
# This function outputs device data
def outputUserData(dctRcv, configDct, queryId, queryType, options, program=None):
        # Common header length
        hdrLen = 13
    
        # Use input date is specified, else use current time
        if options.date: date = options.date
        else:        date = time.strftime("%c %Z", time.localtime())
        #else:       date = time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime())

        # Get route ID if present (only from release 5xxx onwards)
        if 'RouteId' in dctRcv: routeId = ' route ID ' + dctRcv['RouteId']
        else:           routeId = ''
    
        # ***** Output subscriber ID *****
        print('\n**** Data For User ' + str(queryId) + ' (' + queryType + ')' + routeId + ' at time ' + date + ' ****\n')

        # ***** Output summary data *****
        # Check for output filters
        key = 'Basic'
        printData = outputFilterCheck(options, key)

        print()
        format = "%-" + str(hdrLen) + "s %-40s %-40s %-12s %-s\n"
        if printData:
            # Get status string
            status = getStatusDataForOutput(dctRcv)

            # Setup local variables
            ObjectId               = dctRcv['ObjectId']               if 'ObjectId' in dctRcv               else 'N/A'
            ExternalId             = dctRcv['ExternalId']             if 'ExternalId' in dctRcv             else 'N/A'
            UserId                 = dctRcv['UserId']                 if 'UserId' in dctRcv                 else 'N/A'
            FirstName              = dctRcv['FirstName']              if 'FirstName' in dctRcv              else 'N/A'
            LastName               = dctRcv['LastName']               if 'LastName' in dctRcv               else 'N/A'
            ContactEmail           = dctRcv['ContactEmail']           if 'ContactEmail' in dctRcv           else 'N/A'
            ContactPhoneNumber     = dctRcv['ContactPhoneNumber']     if 'ContactPhoneNumber' in dctRcv     else 'N/A'
            NotificationPreference = dctRcv['NotificationPreference'] if 'NotificationPreference' in dctRcv else 'N/A'
            Language               = dctRcv['Language']               if 'Language' in dctRcv               else 'N/A'
            LoginId                = dctRcv['LoginId']                if 'LoginId' in dctRcv                else 'N/A'
            Password               = dctRcv['Password']               if 'Password' in dctRcv               else 'N/A'
            TimeZone               = dctRcv['TimeZone']               if 'TimeZone' in dctRcv               else 'N/A'
        
            # Output always-reported data
            sys.stdout.write(format % \
                        ('Basic data:',\
                        'User ID = ' + UserId,\
                        'External ID = ' + ExternalId,\
                        'OID = ' + ObjectId,\
                        'Status = ' + status,\
                        ))
        
            # Output if-present data
            strOutput = []
        
            # Build command to check if not set to N/A
            if FirstName != 'N/A': strOutput.append(('First Name: ' + FirstName))
            if LastName != 'N/A': strOutput.append(('Last Name: ' + LastName))
            if Language != 'N/A': strOutput.append(('Language: ' + Language))
            if ContactEmail != 'N/A': strOutput.append(('Contact Email: ' + ContactEmail))
            if ContactPhoneNumber != 'N/A': strOutput.append(('Contact Phone Number: ' + ContactPhoneNumber))
            if LoginId != 'N/A': strOutput.append(('Login Id: ' + LoginId))
            if Password != 'N/A': strOutput.append(('Password: ' + Password))
            if TimeZone != 'N/A': strOutput.append(('TimeZone: ' + TimeZone))
            if NotificationPreference != 'N/A': strOutput.append(('Notification Preference: ' + NotificationPreference))
                
            # Report if at max parameters
            while len(strOutput) > 3:
                sys.stdout.write(format % \
                        ('',\
                    strOutput[0],\
                    strOutput[1],\
                        strOutput[2],\
                        strOutput[3],\
                        ))
            
                # Remove entries
                strOutput.pop(0)
                strOutput.pop(0)
                strOutput.pop(0)
                strOutput.pop(0)
                
            # If anything left to output, do that now
            if len(strOutput):
                # Add dummy entries to ensure we have at least 4
                strOutput.append('')
                strOutput.append('')
                strOutput.append('')
            
                # Output the data
                sys.stdout.write(format % \
                        ('',\
                    strOutput[0],\
                    strOutput[1],\
                        strOutput[2],\
                        strOutput[3],\
                        ))
            
        
        # ***** Output custom attributes
        key = 'Custom'
        printData = outputFilterCheck(options, key)
    
        customAttr = configDct['userCustomAttr']
        if printData and customAttr: printCustomData(dctRcv, customAttr, options=options, objType='user')

        # ***** Output subscriptions
        key = 'Subscription'
        line = 'Subsriptions: ' + ' ' * (hdrLen - len('Subsriptions:'))
        if outputFilterCheck(options, key) and 'subscriptions' in dctRcv and len(dctRcv['subscriptions']):
            '''
            print 'outputUserData:'
            pprint.pprint(dctRcv)
            '''
            for subscription in dctRcv['subscriptions']:
                # Always have an OID
                objectId = subscription['ObjectId']
            
                # External ID is optional
                try:    externalId = subscription['ExternalId']
                except: externalId = 'N/A'
            
                try:    role = subscription['role'][0]['Name']
                except: role = 'Unknown'
            
                # Not sure all that can be returned. Seeing device data here.  Report if present.
                xtraData = ' '
            
                # Do lists first
                for field in ['imsi', 'accessNumbers']:
                    if field in subscription and len(subscription[field]): xtraData += ', ' + field + ' = ' + str(subscription[field])
            
                # Do non-lists second
                for field in []:
                    if field in subscription: xtraData += ', ' + field + ' = ' + str(subscription[field])
            
                # Output line
                print(line + 'ObjectId = ' + objectId + ', ExternalId = ' + externalId + ', role = ' + role + xtraData.strip())
            
                # Blank line for subsequent outputs
                line = ' ' * hdrLen
            
        # ***** Output groups
        key = 'Group'
        line = 'Groups: ' + ' ' * (hdrLen - len('Groups:'))
        if outputFilterCheck(options, key) and 'subscriptions' in dctRcv and len(dctRcv['subscriptions']):
            '''
            print 'outputUserData:'
            pprint.pprint(dctRcv)
            '''
            for item in dctRcv['groups']:
                # Always have an OID
                objectId = item['ObjectId']
            
                # External ID is optional
                try:    externalId = item['ExternalId']
                except: externalId = 'N/A'
            
                try:    role = item['role'][0]['Name']
                except: role = 'Unknown'
            
                # Not sure all that can be returned. Seeing device data here.  Report if present.
                xtraData = ' '
            
                # Output line
                print(line + 'ObjectId = ' + objectId + ', ExternalId = ' + externalId + ', role = ' + role + xtraData.strip())
            
                # Blank line for subsequent outputs
                line = ' ' * hdrLen
    
#===============================================================================
# This function outputs device data
def outputDeviceData(dctRcv, configDct, queryId, queryType, options):
    # Use input date is specified, else use current time
    if options.date: date = options.date
    else:        date = time.strftime("%c %Z", time.localtime())
    #else:       date = time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime())

    # Get route ID if present (only from release 5xxx onwards)
    if 'RouteId' in dctRcv: routeId = ' route ID ' + dctRcv['RouteId']
    else:           routeId = ''
    
    # ***** Output subscriber ID *****
    print('\n**** Data For Device ' + str(queryId) + ' (' + queryType + ')' + routeId + ' at time ' + date + ' ****\n')

    if 'ExternalId' in dctRcv:  externalId = dctRcv['ExternalId']
    else:               externalId = 'N/A'

    # ***** Output subscriber summary data *****
    # Check for output filters
    key = 'Basic'
    printData = outputFilterCheck(options, key)

    # Get status string
    status = getStatusDataForOutput(dctRcv)

    print()
    format = "%s %s, %s, %s\n%s\n"
    if printData: sys.stdout.write(format % \
            ('Basic data:     ',\
            'External ID = ' + externalId,\
            'OID = ' + dctRcv['ObjectId'],\
            'DeviceType = ' + dctRcv['DeviceType'],\
            'Status(D):       ' + status,\
            ))

    # ***** Output access numbers
    key = 'Access'
    line = 'Access Numbers:  '
    if outputFilterCheck(options, key) and 'accessNumbers' in dctRcv: printList(dctRcv['accessNumbers'], line, options=options)
    
    # ***** Output access IDs
    key = 'Access'
    line = 'Access IDs:      '
    if outputFilterCheck(options, key) and 'accessIdNumbers' in dctRcv: printList(dctRcv['accessIdNumbers'], line, options=options)

    # ***** Output custom attributes
    key = 'Custom'
    printData = outputFilterCheck(options, key)

    customAttr = configDct['deviceCustomAttr']
    if printData and customAttr: printCustomData(dctRcv, customAttr, options=options, objType='device')
    
    customAttr = configDct['loginCustomAttr']
    
    # Add LoginId to login custom fields
    if customAttr:  customAttr += ',LoginId'
    else:       customAttr = 'LoginId'
    if printData and customAttr: printCustomData(dctRcv, customAttr, options=options, objType='login')

    # ***** Output subscriber data
    key = 'Subscriber'
    printData = outputFilterCheck(options, key)
    if printData:
        if 'SubscriberId' in dctRcv: print('Subscriber:      ' + dctRcv['SubscriberId'])
        else:                  print('Subscriber:      None')

    # ***** Output policy
    if 'SyPolicy' in dctRcv:
            key = 'Policy'
            printData = outputFilterCheck(options, key)
        
            if printData and not options.date and 'policy' in dctRcv['SyPolicy']:
              # May or may not get profile name data back
              try:
                PolicyProfileName = dctRcv['SyPolicy']['PolicyProfileName']
              except:
                PolicyProfileName = None
              printPolicy(dctRcv['SyPolicy']['policy'], configDct, PolicyProfileName, options=options)
    
    # ***** Output offers
    key = 'Offers'
    printData = outputFilterCheck(options, key)
    if printData: printOffers(dctRcv['offers'], configDct, options=options)
    
    # Print contracts
    key = 'Contracts'
    printData = outputFilterCheck(options, key)
    if printData:
        printContracts(dctRcv['offers'], configDct, options=options)
    
    # ***** Output sessions
    key = 'Sessions'
    printData = outputFilterCheck(options, key)
    if printData and 'sessions' in dctRcv:
      for sessionType in ['policySession', 'chargingSession', 'applicationSession']:
        #print 'Checking policy session ' + sessionType
        #pprint.pprint(dctRcv['sessions'][sessionType])
        if sessionType in dctRcv['sessions']: printSessions(sessionType, dctRcv['sessions'][sessionType], configDct, options=options)

#================== Main function  ================================================
def main():
    print('hello')
    
if __name__ ==  '__main__':
    main()

