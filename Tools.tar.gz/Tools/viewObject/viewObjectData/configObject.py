#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Thu 2021-11-11T22:33:49
# @futurize --stage2 --no-diffs -n -w  : Thu 2021-11-11T22:33:49
#
# @futurize --stage1 --no-diffs -n -w  : Thu 2021-11-11T22:33:49

# Import system primitives
from __future__ import print_function
from future import standard_library
standard_library.install_aliases()
import os, pprint
try:
    import configparser
except:
    from six.moves import configparser

# Import MTX primitives
from primitives import primGeneric as PRIM

#===============================================================================
# This function reads the config file for the view parameters
def readConfigFile(options, getCustom=True):
    dctRcv = PRIM.getServiceConfig(options)
    
    # If we don;t want custom data then exit here
    if not getCustom: return dctRcv
    
    # Really want to get the rest of the data from create_config.info but avoid warnings
    # (which are for actual TF commands, not viewing)
    customData = PRIM.getCustomData(dctRcv, False)
    
    # Now fill in the fields using the data from create_config.info
    for object in ['Subscriber', 'Group', 'Device', 'Offer', 'User', 'Login']:
        dctRcv[object.lower() + 'CustomName'] = customData[object]['customName']
        dctRcv[object.lower() + 'CustomAttr'] = ','.join(customData[object]['customFields'])
    
    '''
    # Set usage event name and attributes
    dctRcv['usageEventName'] = customData['DataEvent']['customName']
    dctRcv['usageEventAttr'] = ','.join(customData['DataEvent']['customFields'])
    '''
    
    # Either set the device custom field to the default (not in create_config), or append it (covers create_demo scenarios)
    if 'deviceCustomName' not in dctRcv: dctRcv['deviceCustomName'] = 'MtxMobileDevice'
    else:                    dctRcv['deviceCustomName'] += ',MtxMobileDevice'
    
    # Device data is stored in custom fields, but those field are not in create_config.info.  Add here.
    if 'deviceCustomAttr' in dctRcv:     dctRcv['deviceCustomAttr'] += ',Imsi'
    else:                    dctRcv['deviceCustomAttr'] = 'Imsi'
    
    #print 'Config data: ' + str(dctRcv)
    return dctRcv
    
    # *** LEGACY CODE ***
    
    # Get all config data (even if not all required by the command).
    # NOTE:  the parameter names here are all lower case.  They don't match what's in the config file.
    # Shouldn't have done that here, but for now live with it...
    try:
        dctRcv['subscriberCustomName'] = PRIM.ConfigSectionMap(Config, 'Subscriber-Access')['customname']
        #print 'subscriberCustomName = ' + str(dctRcv['subscriberCustomName'])
    except: x=1
    try:
        dctRcv['subscriberCustomAttr'] = PRIM.ConfigSectionMap(Config, 'Subscriber-Access')['customattr']
        #print 'subscriberCustomAttr = ' + str(dctRcv['subscriberCustomAttr'])
    except: x=1
    
    try:
        dctRcv['deviceCustomName'] = PRIM.ConfigSectionMap(Config, 'Device-Access')['customname']
    except: x=1
    try:
        dctRcv['deviceCustomAttr'] = PRIM.ConfigSectionMap(Config, 'Device-Access')['customattr']
    except: x=1
    
    try:
        dctRcv['groupCustomName'] = PRIM.ConfigSectionMap(Config, 'Group-Access')['customname']
    except: x=1
    try:
        dctRcv['groupCustomAttr'] = PRIM.ConfigSectionMap(Config, 'Group-Access')['customattr']
    except: x=1
    try:
        dctRcv['offerCustomName'] = PRIM.ConfigSectionMap(Config, 'Offer-Access')['customname']
    except: x=1
    try:
        dctRcv['offerCustomAttr'] = PRIM.ConfigSectionMap(Config, 'Offer-Access')['customattr']
    except: x=1
    
    try:
        dctRcv['usageEventName'] = PRIM.ConfigSectionMap(Config, 'Event-Names')['usage']
    except: x = 1
    try:
        dctRcv['usageEventAttr'] = PRIM.ConfigSectionMap(Config, 'Event-Names')['usageattr']
    except: x = 1
    #print 'Config data: ' + str(dctRcv)
    return dctRcv

#================== Main function  ================================================
def main():
    print('hello')

if __name__ ==  '__main__':
    main()

