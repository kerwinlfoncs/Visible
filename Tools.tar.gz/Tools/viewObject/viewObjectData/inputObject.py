#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Thu 2021-11-11T22:33:51
# @futurize --stage2 --no-diffs -n -w  : Thu 2021-11-11T22:33:50
#
# @futurize --stage1 --no-diffs -n -w  : Thu 2021-11-11T22:33:50

# Import system primitives
from __future__ import print_function
import sys, os
import optparse

# Import MTX primitives
from primitives import primGeneric as PRIM
from primitives import primData as PRIMDATA

#===============================================================================
# This function processes command line inputs
def cmdLineInput(usage='VIEW'):
    ########### Do command line processing ###################
    parser = optparse.OptionParser()
    parser.add_option("-x", "--externalId", action='store', type='string', default=None, help='Object external ID prefix (for compatibility to test framework)')
    
    # Subscriber items
    parser.add_option("-s", "--subscriber", action='store', type='string', default=None, help='Subscriber external ID')
    parser.add_option("",   "--soid",       action='store', type='string', default=None, help="Subscriber's OID value")
    parser.add_option("-o", "--oid",        action='store', type='string', default=None, help="Subscriber's OID value")
    parser.add_option("-d", "--deviceId",   action='store', type='string', default=None, help="One of the subscriber's device IMSI values")
    parser.add_option("-a", "--accessNumbers",  action='store', type='string', default=None, help="One of the subscriber's device MSISDN values")
    parser.add_option("",   "--sofile",     action='store', type='string', default=None, help="Subscriber OID file")
    parser.add_option("",   "--sefile",     action='store', type='string', default=None, help="Subscriber external ID file")
    
    # Device items
    parser.add_option("", "--dx",   action='store', type='string', default=None, help="Device external ID value")
    parser.add_option("", "--doid", action='store', type='string', default=None, help="Device OID value")
    parser.add_option("-i", "--imsi",   action='store', type='string', default=None, help="Device IMSI value")
    parser.add_option("-m", "--msisdn", action='store', type='string', default=None, help="Device MSISDN value")
    parser.add_option("", "--LoginId",  action='store', type='string', default=None, help="Device Login ID value")
    parser.add_option("", "--accessId", action='store', type='string', default=None, help="Device Access ID value")
    parser.add_option("", "--dofile",   action='store', type='string', default=None, help="Device OID file")
    parser.add_option("", "--difile",   action='store', type='string', default=None, help="Device IMSI file")
    parser.add_option("", "--dmfile",   action='store', type='string', default=None, help="Device MSISDN file")
    parser.add_option("", "--sessions", action='store_true',           default=False,help="Output device session information")
    
    # Group items
    parser.add_option("-g", "--groupId", action='store', type='string', default=None, help="Group external ID")
    parser.add_option("", "--goid",      action='store', type='string', default=None, help="Group OID value")
    parser.add_option("", "--gofile",    action='store', type='string', default=None, help="Group OID file")
    parser.add_option("", "--gefile",    action='store', type='string', default=None, help="Group external ID file")
    
    # User items
    parser.add_option("-u", "--userId", action='store', type='string', default=None, help="User ID")
    parser.add_option("",   "--uoid",   action='store', type='string', default=None, help="User OID value")
    parser.add_option("",   "--uxid",   action='store', type='string', default=None, help="User external ID value")
    
    # Subscription items
    parser.add_option("",   "--suboid",   action='store', type='string', default=None, help="Subscription OID value")
    parser.add_option("",   "--subxid",   action='store', type='string', default=None, help="Subscription external ID value")
    
    # Output Filter items
    parser.add_option("", "--off", action='store', type='string', default=None, help="Filter off unwanted section output")
    parser.add_option("", "--on", action='store', type='string', default=None, help="Filter on only desired section output")
    
    # Config file identification items
    parser.add_option("", "--dir", action='store', type='string', default=None, help="Directory to find config file")
    parser.add_option("", "--cf", action='store', type='string', default=None, help="Full path to config file")
    
    # Time items
    parser.add_option("", "--timezone", action='store', type='string', default=None, help="Time zone to use for query commands")
    
    # Additional data items
    parser.add_option("", "--allExtraData", action='store_true', default=False, help="Output all additional data")
    parser.add_option("", "--aggregation", action='store_true', default=False, help="Enable aggregation outputs")
    parser.add_option("", "--offerDetail", action='store_true', default=False, help="Enable additional offer outputs")
    parser.add_option("", "--groupHierarchy", action='store_true', default=False, help="Enable subscriber group hierarchy summary outputs")
    parser.add_option("", "--sortField", action='store', type='string', default='priority', help="Display data sorted by different criteria (priority, resource)")
    
    # REST gateway items
    parser.add_option("", "--RestHost",
                      action="store",
                      default=None,
                      type="string",
                      dest="RestHost",
                      help="REST gateway IP address",)

    parser.add_option("", "--RestPort",
                      action="store",
                      default=None,
                      type="string",
                      dest="RestPort",
                      help="REST gateway port",)
    
    # Misc items
    parser.add_option("", "--debug", action='store', type='string', default=None)
    parser.add_option("", "--date", action='store', type='string', default=None, help="query date, in format YYYY-MM-DDTHH:MM:SS(.000000+/-HH:MM)")
    parser.add_option("-f", "--file", action='store', type='string', default=None, help="Raw query output file name")
    parser.add_option("", "--scope", action='store', type='string', default=None, help="Signals whether to run up or down the hierarchy from the input object")
    parser.add_option("", "--pf", action='store', type='string', default=None, help="Price file - used for multiple operations")
    parser.add_option("", "--bpw", action='store', type='int', default=0, help="Print width for balance names")
    parser.add_option("", "--bcpw", action='store', type='int', default=0, help="Print width for balance class names")
    parser.add_option("", "--opw", action='store', type='int', default=0, help="Print width for offer names and extrnal IDs")
    parser.add_option("", "--val", action='store_true', default=False, help="Signals that validation should be done")
    parser.add_option("", "--audit", action='store_true', default=False, help="Signals that an audit of all balance to offer mappings be done during validation")
    parser.add_option("", "--forceError", action='store_true', default=False, help="Signals that errors should be introduced during validation")
    parser.add_option("-r", "--release", action='store', type='string', default=None, help="Release being used (e.g. 4300, 4500, trunk")
    parser.add_option("-v", "--version", action='store_true', default=False, help="Output tool version")
    parser.add_option("",   "--viewGlobals", action='store_true', default=False, help="Output global offers (cold be time consuming)")
    parser.add_option("",   "--hideExpired", action='store_true', default=False, help="Don't output expired balances or offers")
    parser.add_option("",   "--hideHidden", action='store_true', default=False, help="Don't output hidden balances")
    parser.add_option("",   "--hideTemplateData", action='store_true', default=False, help="Don't output catalog item template data")
    parser.add_option("",   "--hideCustomData", action='store_true', default=False, help="Don't output catalog item custom purchase data")
    parser.add_option("",   "--hideParameterData", action='store_true', default=False, help="Don't output catalog item parameter data")
    parser.add_option("",   "--hideEligibilityData", action='store_true', default=False, help="Don't output catalog item parameter data")
    parser.add_option("",   "--hideOfferData", action='store_true', default=False, help="Don't output catalog item extra data (template, custom, parameter, eligibility)")

    # HTTPS items
    parser.add_option("",   "--ssl", action='store_true', default=False, help="Use HTTPS instead of HTTP")
    parser.add_option("",   "--httpAuthUsername", action='store', type='string', default=None, help="HTTP basic auth Username")
    parser.add_option("",   "--httpAuthPassword", action='store', type='string', default=None, help="HTTP basic auth Password")
    
    # Process command line params
    (options, args) = parser.parse_args()
    
    # Prepare for sharing this (so different inputs will be required).
    # If version requested, then don;t validate anything.
    if not options.version:
        # Need some other input
        if  not options.groupId and \
        not options.subscriber and \
        not options.dx and \
        not options.deviceId and \
        not options.accessNumbers and \
        not options.imsi and \
        not options.msisdn and \
        not options.LoginId and \
        not options.accessId and \
        not options.oid and \
        not options.soid and \
        not options.sofile and \
        not options.sefile and \
        not options.goid and \
        not options.gofile and \
        not options.gefile and \
        not options.doid and \
        not options.dofile and \
        not options.difile and \
        not options.dmfile and \
        not options.uoid and \
        not options.uxid and \
        not options.suboid and \
        not options.subxid and \
        not options.userId and \
        not options.externalId:
            # default to ID 10
            options.subscriber = '10'
            print('NOTE: no ID entered.  Defaulting to subscriber external Id 10 (default value for RunGeneric)')

        # To be consistent with the test framework, prefix any -x option to the object ID
        if options.externalId:
                if    options.subscriber: options.subscriber = options.externalId + options.subscriber
                elif  options.groupId:    options.groupId    = options.externalId + options.groupId
                elif  options.dx:     options.dx         = options.externalId + options.dx
                elif  options.uxid:   options.uxid       = options.externalId + options.uxid
                else:             options.subscriber = options.groupId = options.externalId

        # Convert filter inputs into lists
        if options.off: 
            options.off = options.off.lower()
            options.off = options.off.split(',')
        else: options.off = []
        if options.on:  
            options.on = options.on.lower()
            options.on  = options.on.split(',')
        else: options.on = []
    
    # Remove the output file 
    if options.file: PRIM.runCmd('rm -f ' + options.file + ' >/dev/null 2>&1')
    
    # Remove the temp file
    PRIM.runCmd('rm -f _x >/dev/null 2>&1')
    
    # Sanity check the input.  Need MSISDN/IMSI numbers to be <= 15 characters
    for param in ['deviceId', 'accessNumbers', 'msisdn', 'imsi']:
        cmd = 'if options.' + param + ' and (len(options.' + param + ') > 15 or options.' + param + '.isdigit() != 1): sys.exit("ERROR: input parameter " + param + " is too long (> 15 characters) or non-numeric: " + options.' + param + ')'
        #print cmd
        exec(cmd)
    
    # If hiding all extra offer data, then set individual fields:
    if options.hideOfferData:
            options.hideTemplateData = options.hideCustomData = options.hideParameterData = options.hideEligibilityData = True
    
    # If SSL or auth inputs or environment variables specified, then update global data
    PRIM.primGetCurlUrlStart(options)
    
    return options

#================== Main function  ================================================
def main():
    # 
    print('hello')

if __name__ ==  '__main__':
    main()

