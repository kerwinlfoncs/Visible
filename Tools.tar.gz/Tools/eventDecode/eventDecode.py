#!/usr/bin/python3
#
#
# @2to3-3 --no-diffs -x input -w  : Fri 2021-11-12T00:17:42
# @futurize --stage2 --no-diffs -n -w  : Fri 2021-11-12T00:17:42
#
# @futurize --stage1 --no-diffs -n -w  : Fri 2021-11-12T00:17:40

# System imports
from __future__ import print_function
# from builtins import input
# from builtins import str
# from builtins import range
# from builtins import input
# from builtins import str
# from builtins import range
import os, glob, time, sys, pprint, copy, binascii, re
from datetime import datetime
from optparse import OptionParser

# MTX Service imports
from primitives     import primGeneric as GENERIC
from primitives     import primDebugFile as DEBUG
from primitives     import primXML as XML
from primitives     import primGET as GET
from primitives     import primHTTP as HTTP
from primitives     import primData as PRIMDATA
from primitives     import cbRestPrim  as CB
import xml.etree.ElementTree as ET

# HACK: Need global so we can get return data (caused by remal of exec() lines in Python 3)
_retData = None

# Define global of the string being searched
globalSearchString = ''

# Indentations
indent1 = ' '*8
indent1p5 = ' '*12
indent2 = ' '*16
indent3 = ' '*24
indent4 = ' '*32

# Define globals
balancesData = balanceData = {}
ReprocessFlag = True
subscriberId = None
DirOrFileInput = False

# Hack until components all have table indices reported
usageTriggerHack = {}
usageTriggerHack['tableIndex'] = -1
usageTriggerHack['id'] = -1

parameterHack = {}
parameterHack['tableIndex'] = -1
parameterHack['id'] = -1

filterHack = {}
filterHack['tableIndex'] = -1
filterHack['id'] = -1

priorityHack = {}
priorityHack['tableIndex'] = -1
priorityHack['id'] = -1

taxSelectorHack = {}
taxSelectorHack['tableIndex'] = -1
taxSelectorHack['id'] = -1

balanceStateHack = {}
balanceStateHack ['tableIndex'] = -1
balanceStateHack ['id'] = -1

policyHack = {}
policyHack['tableIndex'] = -1
policyHack['id'] = -1

rolloverHack = {}
rolloverHack['tableIndex'] = -1
rolloverHack['id'] = -1

lastUnitInfoHack = {}
lastUnitInfoHack['tableIndex'] = -1
lastUnitInfoHack['id'] = -1

subInfoHack = {}
subInfoHack['tableIndex'] = -1
subInfoHack['id'] = -1

repositoryHack = {}
repositoryHack['tableIndex'] = -1
repositoryHack['id'] = -1

glInfoHack = {}
glInfoHack['tableIndex'] = -1
glInfoHack['id'] = -1

glAcntHack = {}
glAcntHack['tableIndex'] = -1
glAcntHack['id'] = -1

glTxnHack = {}
glTxnHack['tableIndex'] = -1
glTxnHack['id'] = -1

usageHack = {}
usageHack['tableIndex'] = -1
usageHack['id'] = -1

announcementHack = {}
announcementHack['tableIndex'] = -1
announcementHack['id'] = -1

aggregationSelector = {}
aggregationSelector['tableIndex'] = -1
aggregationSelector['id'] = -1

# Detect non-ASCII names
OnlyAscii = lambda s: re.match('^[\x00-\x7F]+$', s) != None

# ------------------------------------------------------------------------------

# Define strings to look for.
# Entries are (string, next level array, function to run if string found)

searchStrings = []

# Session mapping
searchStrings.append(('Copied source field',        None,   'printLineProcessing'))

# original search strings...
searchStrings.append(('UpgradeTask::handleInput:',  None,   'analyzeChargingServerInputCommand'))
searchStrings.append(('selects profile ID=RepositoryProfile',       None,   'selectedRepositoryProfile'))
searchStrings.append(('Stack Trace',            None,   'printError'))
searchStrings.append(('ERROR',              None,   'printError'))
searchStrings.append(('skipped because no balance instance found that',     None,   'printLineProcessing'))
searchStrings.append(('OfferOperations::processOfferPurgeMaintenance: Purging purchased offer',     None,   'printUntilNextLmTraceFound'))
searchStrings.append(('Balance updates at end of',  None,   'printUntilNextLmTraceFound'))
searchStrings.append(('Notifications at end of',    None,   'printUntilNextLmTraceFound'))
searchStrings.append(('Conditions at end of',       None,   'printUntilNextLmTraceFound'))
searchStrings.append(('Events at end of',       None,   'processEventsAtEndOf'))
searchStrings.append(('ratePurchaseOrCancelOfferList',  None,   'processEventsAtEndOf'))
searchStrings.append(('Consolidated charges after', None,   'printUntilNextLmTraceFound'))
searchStrings.append(('Combining formula for price',    None,   'printUntilNextLmTraceFound'))
searchStrings.append(('After formula merging',      None,   'printUntilNextLmTraceFound'))
searchStrings.append(('cannot be satisfied',        None,   'printLineProcessing'))
searchStrings.append(('Processing purchase bundle rating op:',None,     'printUntilNextLmTraceFound'))
searchStrings.append(('successfully applied to balance',None,   'printLineProcessing'))
searchStrings.append(('before reaching limit',      None,   'printLineProcessing'))
searchStrings.append(('charges and grants NOT applied', None,   'printLineProcessing'))
searchStrings.append(('handleErrorFormula',     None,   'printLineProcessing'))
searchStrings.append(('skipped because no balance found',None,  'printLineProcessing'))
searchStrings.append(('Message is a duplicate',     None,   'printLineProcessing'))

# This must be before the policy checks (just below here) as policy logic has two items in one line (so need double call)
searchStrings.append(('Matrix lookup result',       None,   'matrixLookupResultProcessing'))

# Normalization must come before applyCommonMatrix
searchStrings.append(('Normalization results for',  None,   'normalizationResultsProcessing'))
searchStrings.append(('applyCommonMatrix',      None,   'applyCommonMatrixProcessing'))

searchStrings.append(('normalizeWithAlgorithm',     None,   None))
searchStrings.append(('balancePassesFilters',       None,   'balancePassesFilterProcessing'))
searchStrings.append(('checkFilter',            None,   'printLineProcessing'))
searchStrings.append(('Not authorizing any quota',  None,   'printLineProcessing'))
searchStrings.append(('addRarMsgToMsg',         None,   'printLineProcessing'))
searchStrings.append(('::applyFilter:',         None,   'printApplyFilter'))
searchStrings.append(('::applyAggrSelector:',       None,   'printApplyAggregationSelector'))
searchStrings.append(('message is a duplicate',     None,   'printLineProcessing'))
searchStrings.append(('calculated priority',        None,   'calculatedPriority'))
searchStrings.append(('~~~~~~',             None,   'startSquiggleProcessing'))
searchStrings.append(('Checking for formulas in offer', None,   'checkFormulasProcessing'))
searchStrings.append(('>>>>>>',             None,   'startGreaterThanProcessing'))
searchStrings.append(('formula for price comp',     None,   'combineFormulaProcessing'))
searchStrings.append(('======',             None,   'startEqualProcessing'))
searchStrings.append(('------',             None,   'DashProcessing'))
searchStrings.append(('traceNotifications',         None,   'notificationProcessing'))
searchStrings.append(('traceUsageRequest',      None,   'traceUsageProcessing'))
#searchStrings.append(('policy updates for device',     None,   'printLineProcessing'))
searchStrings.append(('Releasing reservations',     None,   'printLineProcessing'))
searchStrings.append(('usage charge components under consideration',    None,   'addingProductOfferProcessing'))
searchStrings.append(('No additional segments',     None,   'printLineProcessing'))
searchStrings.append(('calcSegmentSize',        None,   'printLineProcessing'))
searchStrings.append(('addProductOffer',        None,   'addingProductOfferProcessing'))
searchStrings.append(('addUsageProductOffer',       None,   'addingProductOfferProcessing'))
searchStrings.append(('balances for product offer',     None,   'requiredBalancesForOfferProcessing'))
searchStrings.append(('calcUsageCharges',       None,   'calculateChargesProcessing'))
searchStrings.append(('genNonUsageGrants',      None,   'calculateChargesProcessing'))
searchStrings.append(('Diameter Hdr',           None,   'diameterProcessing'))
#searchStrings.append(('setLastUnitInfo',       None,   'printLineProcessing'))
searchStrings.append(('Found LastUnitInfoProfile ID',   None,   'printLastUnitProfile'))
searchStrings.append(('Used quantity reduced by amount',None,   'printLineProcessing'))
searchStrings.append(('Authorizing usage rounding amount',None, 'printLineProcessing'))
searchStrings.append(('is less than minimum of',    None,   'printLineProcessing'))
searchStrings.append(('is not valid at',        None,   'printLineProcessing'))
searchStrings.append(('No available amount for balance',None,   'printLineProcessing'))
searchStrings.append(('addCancelRefundOrForfeiture',    None,   'printLineProcessing'))
searchStrings.append(('Generating refund',      None,   'printUntilNextLmTraceFound'))
searchStrings.append(('Created start of a Gx RAR message',None, 'printLineProcessing'))
searchStrings.append(('selects profile ID',     None,   'printPolicyProfile'))
#searchStrings.append(('\*\*\*\* ',             None,   'printLineProcessing'))

'''
# Print rollover for now.  Later will try to make it more intelligent
searchStrings.append(('selected Rollover profile',      None,   'selectedRolloverProfile'))
searchStrings.append(('genRecurringRollovers',      None,   'printLineProcessing'))
searchStrings.append(('rolloverBalance',                None,   'printLineProcessing'))
searchStrings.append(('addBalanceRolloverToEvent',      None,   'printLineProcessing'))
'''

# GL Data
searchStrings.append(('normalization during GL calculations',       None,   'printUntilNextLmTraceFound'))
searchStrings.append(('glInfoForImpact',        None,   'printUntilNextLmTraceFound'))
searchStrings.append(('buildEventChargeGLInfo',     None,   'printLineProcessing'))
searchStrings.append(('revRecTypeForAsset',     None,   'printLineProcessing'))
searchStrings.append(('genEventGlInfo',         None,   'printLineFromSearchString'))
searchStrings.append(('calcGlTxnProfile',       None,   'printGlTxnProfile'))
searchStrings.append(('calcGl',             None,   'printLineFromSearchString'))

# Print test framework lines
searchStrings.append(('TEST FRAMEWORK',                 None,   'printLineProcessing'))

# CCF items
searchStrings.append(('Sending unit data message',      None,   'printUntilNextLmTraceFound'))
searchStrings.append(('Encoded TCAP message',       None,   'printUntilNextLmTraceFound'))
searchStrings.append(('Decoded TCAP Message',       None,   'printUntilNextLmTraceFound'))
searchStrings.append((' Message for charging server',   None,   'printUntilNextLmTraceFound'))

# Callouts
#searchStrings.append(('MtxCallOut',            None,   'printLineProcessing'))
searchStrings.append(('ChargingTask::isAnyCallOutNeeded',None,   'printLineProcessing'))
searchStrings.append(('ChargingTask::performCallOutIfNecessary',None,   'printLineProcessing'))

# Policy items
# Order matter here, as the  lower strings may appear in higher row items.
searchStrings.append(('Selected policy profile',    None,   'selectedPolicyProfile'))
searchStrings.append(('Adding policy counters derived', None,   'printLineProcessing'))
searchStrings.append(('Added policy counter to msg',    None,   'printLineProcessing'))
#searchStrings.append(('getPolicyFromOffer',        None,   'printLineProcessing'))

# Offer cancel
searchStrings.append(('handleRatingOpCancelBundle',     None,   'printUntilNextLmTraceFound'))

# Various server input messages
searchStrings.append(('after all selective updates',    None,   'printUntilNextLmTraceFound'))
searchStrings.append(('handleInput',            None,   'processHandleInput'))

# Requested quota strings
searchStrings.append(('Attempting to authorize adaptive amount', None,   'printLineProcessing'))

# Auth error issue
searchStrings.append(('Not authorizing any quota',  None,   'printLineProcessing'))

# Cycle hold data
searchStrings.append(('transferAvailAmountToHoldingBalance',    None,   'printLineProcessing'))

# Balance state update
searchStrings.append(('Selected Balance State Update profile',  None,   'outputBalanceStateProfile'))
#searchStrings.append(('getBalanceStateUpdateProfile',  None,   'printLineProcessing'))
searchStrings.append(('updateBalanceState',     None,   'printLineProcessing'))
searchStrings.append(('Balance end time is not updated because',    None,   'printLineProcessing'))

# Cycle alignment items
searchStrings.append(('RatingOps::handleRatingOpTerminatePurchasedItemCyclePeriods',        None,   'printLineProcessing'))

# Eligibility
searchStrings.append(('EligibilityUtils',       None,   'printUntilNextLmTraceFound'))

# Announcement profile
searchStrings.append(('successfully loaded',        None,   'announcementProfile'))

# Grace period
searchStrings.append(('processOfferGracePeriodMaintenance',     None,   'printLineProcessing'))

# Notifications
searchStrings.append(('RatingContext::getBalThresholdEventForThresholdId',  None,   'printLineProcessing'))
searchStrings.append(('RatingContext::findActiveThresholdRange',        None,   'printLineProcessing'))
searchStrings.append(('RatingContext::checkThresholdNotificationsForBalType',   None,   'printLineProcessing'))
searchStrings.append(('RatingContext::searchThresholdNotifications:',       None,   'searchThresholdNotifications'))

# Skip persistence cache items
searchStrings.append(('PERSISTENCE CACHE',      None,   'skipUntilNextLmTraceFound'))

# Failed to find device
searchStrings.append(('Failed lookup message',      None,   'printLineProcessing'))

# Auto transition
searchStrings.append(('Checking for auto status transition',        None,   'printLineProcessing'))

# Offer activation
searchStrings.append(('tryActivatingPreActiveOffer',    None,   'clearFilterData'))

# Attribute processing
searchStrings.append(('AttributeLoader::load',      None,   'printLineProcessing'))
searchStrings.append(('addPricingAttributes:',      None,   'printLineProcessing'))

# PreRating
searchStrings.append(('MtxCallOut::',           None,   'printUntilNextLmTraceFound'))
searchStrings.append(('processPreRatingGenerator',  None,   'printLineProcessing'))
searchStrings.append(('ActionVector',           None,   'printLineProcessing'))
searchStrings.append(('Action profile ActionProfile:',  None,   'preratingActionProfile'))

# Rating transition points (before rating the event)
searchStrings.append(('StatusOperations',       None,   'printLineProcessing'))

# *** Optional search strings
# Selective Updates
selUpdSearchStrings = []
selUpdSearchStrings.append(('MdcSelectionKey::evaluateMethod',      None,   'printUntilNextLmTraceFound'))
selUpdSearchStrings.append(('MdcFunction::execute',         None,   'printUntilNextLmTraceFound'))
#selUpdSearchStrings.append(('MdcSelectiveUpdateElement::', None,   'printUntilNextLmTraceFound'))

# Taxes
taxSearchStrings = []
taxSearchStrings.append(('applyTaxesForCharges',      None,   'printUntilNextLmTraceFound'))
taxSearchStrings.append(('getCCHSelectedTaxes',      None,   'printUntilNextLmTraceFound'))
taxSearchStrings.append(('calcTotalTaxRate',      None,   'printUntilNextLmTraceFound'))
taxSearchStrings.append(('getCCHSelectedTaxes',      None,   'printUntilNextLmTraceFound'))
taxSearchStrings.append(('isTaxExempt',      None,   'printUntilNextLmTraceFound'))
taxSearchStrings.append(('isTaxEffective',      None,   'printUntilNextLmTraceFound'))
taxSearchStrings.append(('getTaxMatrixForTaxCode',      None,   'printUntilNextLmTraceFound'))
taxSearchStrings.append(('convertEventTimeToLocalDate',      None,   'printUntilNextLmTraceFound'))
taxSearchStrings.append(('RatingContext::mergeComp',      None,   'printUntilNextLmTraceFound'))

# ------------------------------------------------------------------------------
def searchThresholdNotifications(allLines, idx, config):
    global options
    global _retData
    
    # If config is setup for additional notification data, then print it
    if options.xtraNotificationData: idx =  printUntilNextLmTraceFound(allLines, idx, config)
    
    # Return last line processed
    _retData = idx
    return idx

# ------------------------------------------------------------------------------
def notificationProcessing(allLines, idx, config):
    global _retData
    
    count = 0
    outStr = ''
    
    # Get the current line
    outStr = allLines[idx]
    
    # Loop until blank line found
    while idx < len(allLines):
        # Get the next line
        idx += 1
        line = allLines[idx].strip()
        
        # If empty line or line signals no balances, then break
        if not line or line.count('none'): break
        
        # Increment number found
        count += 1
        
        # Incement output string
        outStr += line
    
    # Output data iff anything found
    if count: print(outStr)
    
    _retData = idx
    return idx
    
# ------------------------------------------------------------------------------
def printLastUnitProfile(allLines, idx, config):
    global _retData
    
    # Get the profile value
    profile = allLines[idx].split(':')[-1].strip()
    
    # Read the profile
    retProfile = CB.viewLastUnitProfileData(profile, config)
#   print indent1 + 'Policy profile data:' + str(retProfile['object']['fui_profile']['attrib'])
    
    # Process every attribute
    for attrib in retProfile['object']['fui_profile']['attrib']:
#       print 'attrib: ' + str(attrib)
        # Get item components
        (attrName,attrValue) = attrib
            
        # Assign to variables
        if   attrName == 'name':        name = str(attrValue).replace('"','\'')
        elif attrName == 'action':      action = str(attrValue).replace('"','\'')
        elif attrName == 'redirect_address_type': redirect_address_type = str(attrValue).replace('"','\'')
        elif attrName == 'redirect_address_data': redirect_address_data = str(attrValue).replace('"','\'')
        
    # Print the ones we care about
    print(indent1 + 'FUI Profile ID: ' + profile + ' (' + name + '), action = ' + action) 
    if action == 'redirect': print(indent2 + 'redirect_address_type: ' + redirect_address_type + ', redirect_address_data: ' + redirect_address_data)
            
    # Add space
    print('')
    
    _retData = idx
    return idx
    
# ------------------------------------------------------------------------------
def printPolicyProfile(allLines, idx, config):
    global _retData
    global policyHack
    global usageHack
    
    # Get the profile ID
    profile = allLines[idx].split(':')[-1].strip()
    
    # This could be a usage profile of a policy profile
    if   allLines[idx].count('UsageQuotaComponent'):    profileType = "Usage"
    elif allLines[idx].count('UsageTriggerComponent'):  profileType = "UsageTrigger"
    elif allLines[idx].count('RolloverComponent'):      profileType = "Rollover"
    else:                                               profileType = "Policy"
    print(indent1 + 'Selected ' + profileType + ' profile ' + profile + ':')
    
    # Nothing additional to print for rollover profile (done in previous code)
    if profileType == "Rollover": return idx

    # If usage profile then go elsewhere
    if profileType == "Usage":
        printUsageProfile(config,profile)
        
        # HACK code: Clear data as we can hit the same object consecutively across different offers
        clearHackData(usageHack)
    
        _retData = idx
        return idx
    
    # If usage trigger profile then go elsewhere
    if profileType == "UsageTrigger":
        printUsageTriggerProfile(config,profile)
        
        # HACK code: Clear data as we can hit the same object consecutively across different offers
        clearHackData(usageTriggerHack)
        
        _retData = idx
        return idx
    
    # if here, then doing policy profile
    
    # Read the profile
    retProfile = CB.viewPolicyProfileData(profile, config)
    #pprint.pprint(retProfile)
    
    # Process every attribute.  
    # Sy and Gx read back differently.  Don't have this so use try/except (not great, but it works)
    try:
        # Sy
        #print 'Attributes:'
        #pprint.pprint(retProfile['object']['policy_profile']['attributes']['attribute'])
        # KEF: We might get a list of lists, or just a single list.  Need to account for this (but broken in 5120...).
        for attrib in retProfile['object']['policy_profile']['attributes']['attribute']:
          # Attributes are in a list
          for item in retProfile['object']['policy_profile']['attributes']['attribute'][attrib]:
            # Get item components
            (attrName,attrValue) = item
            
            # Assign to variables
            if   attrName == 'value':   value = str(attrValue).replace('"','\'')
            elif attrName == 'display': display = str(attrValue).replace('"','\'')
            elif attrName == 'id':      id = str(attrValue).replace('"','\'')
        
        # Get attribute data
        retAttrData = CB.viewAttributeData(id, config)
        
        # Print the ones we care about
        print(indent2 + 'ID: ' + str(id) + ' (' + retAttrData['NAME'] + ') Value = ' + value + '(' + display + ')')
    except:
            # Gx
        # Print the ones we care about
        print(indent2 + 'ID: ' + retProfile['ID'] + ' (' + retProfile['NAME'] + ')')
            
    # Add space
    print('')
    
    # HACK code: Clear data as we can hit the same object consecutively across different offers
    clearHackData(policyHack)
    
    _retData = idx
    return idx
    
# ------------------------------------------------------------------------------
def applyCommonMatrixProcessing(allLines, idx, config):
    global _retData
    # This is still hit!
    object = None
    
    # Get the current line
    line = allLines[idx]
    
    if line.count('Reusing cached result'):
        print(indent1 + 'Reusing cached result')
        _retData = idx
        return idx
    
    # Get the object
    for item in [   'RolloverComponent', \
            'PriorityGenerator', \
            'Filter', \
            'GlInfoGenerator', \
            'GlTxnProfileSelector', \
            'GlAccountSelector', \
            'BalanceStateComponent', \
            'PolicyComponent', \
            'LastUnitInfoGenerator', \
            'TaxSelector', \
            'RepositoryComponent', \
            'UsageQuotaComponent', \
            'ActionProfileGenerator', \
            'AnnouncementProfileGenerator', \
            ]:
        if line.count(item):
            object = item
            break
    
    # Not good if we didn't find the object
    if not object:
        print('Hmmmm did\'t identify object in applyCommonMatrixProcessing')
        print(line)
        _retData = idx
        return idx
    
    # Get the result
    result = line.split('=')[1].split(' ')[0]
    
    # Output pass/fail
    if   object == 'Filter':
        if result == '1':       print(indent1 + object + ' passed')
        else:               print(indent1 + object + ' failed')
    elif   object == 'RepositoryComponent':
        if int(result) < 0:         print(indent1 + object + ' failed')
        else:
            print(indent1 + object + ' passed')
    elif   object == 'PriorityGenerator':
        if int(result) == -2147483647:  print(indent1 + object + ' failed')
        else:
            print(indent1 + object + ' passed - priority impact is ' + result)
    elif object in ['PolicyComponent']:
        if int(result) < 0:     print(indent1 + object + ' skipped')
        else:           print(indent1 + object + ' passed')
    elif object in ['RolloverComponent', 'BalanceStateComponent', 'LastUnitInfoGenerator', 'LastUnitInfoGeneratorRev', 'TaxSelector', 'UsageQuotaComponent']:
        print('In applyCommonMatrixProcessing: result = ' + str(result))
        if int(result) < 0:     print(indent1 + object + ' skipped')
        elif int(result) != 0:  print(indent1 + object + ' failed')
        else:
            print(indent1 + object + ' passed')
            
    elif object in ['ActionProfileGenerator', 'GlInfoGenerator', 'AnnouncementProfileGenerator', 'GlTxnProfileSelector', 'GlAccountSelector']:
        # Check if failed
        if int(result) < 0:     print(indent1 + object + ' skipped')
        else:
            print(indent1 + object + ' passed')
            
            # Passed.  next line has the data
            if object != 'AnnouncementProfileGenerator':
                idx += 1
                line = allLines[idx]
                print(line)
        
    # Return last line processed
    _retData = idx
    return idx
    
def processEventsAtEndOf(allLines, idx, config, printFlag = True):
    global _retData
    
    # Get the current line
    inLine = allLines[idx]
    
    # Always go to the next line at this point
    idx += 1
    
    # Default outputs
    outStr = ''
    stopStrings = ['======', 'LM_TRACE', 'LM_INFO', 'LM_DEBUG', '**** TEST FRAMEWORK']
    
    # Loop until we find a stop string
    exitFlag = False
    while (idx < len(allLines)) and (not exitFlag):
        # Get the current line
        line = allLines[idx]
        #print(line)
        
        # See if we start with any of the stop strings
        for item in stopStrings:
            if line.startswith(item):
                # Set outside loop exit flag and break from inner loop
                exitFlag = True
                break
        
        # Output data if exiting
        if exitFlag:
          #print('Breaking out of loop')
          # See if any data worth outputting
          if printFlag and len(outStr) > 20 and (outStr.count('none') < 15 or outStr.count('balance start time')):
            # Get to the start of the string where the key data is
            if inLine.find('Events at end of') == -1:   print(inLine)
            else:                       print(inLine[inLine.find('Events at end of'):])
            
            print(outStr)
    
        # Add to output if not at end
        else:
            # Process balance data if present
            if   line.count('class=') and line.count('id='):        line = updateClassAndTemplate(config, None, line)
            elif line.count('template ID=BalanceTemplate:'):        line = updateTemplate(line)
            elif line.count('purchased offer:') and line.count('id='):  line = updatePurchasedData('id=', line, CB.retOfferData)
            elif line.count('purchased bundle') and line.count('id='):  line = updatePurchasedData('id=', line, CB.retBundleData)
            elif line.count('purchased catalog item') and line.count('ID='): line = updatePurchasedData('ID=', line, CB.retCIData)
            
            # Store line
            outStr += line
    
            # Bump index
            idx += 1
            
            # Process this line.  Want to update values with offer/bundle/balance class, and balance name
    
    # Returned code assumes line passed in has been processed, so return previous line
    _retData = idx-1
    return idx-1
    
def balancePassesFilterProcessing(allLines, idx, config):
    global _retData
    
    # Get the current line
    line = allLines[idx]
    
    # Get to the start of the string where the key data is
#   print 'Line          : ' + str(line)
    
    # Get the resource ID
    try:
        resourceId = line.split('#')[1].split(':')[0]
    except:
        print('*** Didn\'t find a resource ID - this is a session meter ***')
        resourceId = 'Session Meter'
        
    # Get to start of line data
    lineResult = updateClassAndTemplate(config, 'Applying filters for balance', line)
    
    # Clear filter data
    clearHackData(filterHack)
    
    # Print the data
    print(lineResult)
#   print 'Class "' + retData['className'] + '" (' + retData['classId'] + ') template "' + retData['balanceIdName'] + '" (' + retData['balanceId'] + ')'
    
    # Get the next line
    idx += 1
    line = allLines[idx].strip()
    #print 'balancePassesFilterProcessing: second line: ' + line
    
    # If this says already applied, then just print the line'
    if line.count('already applied'):
        print(line)
        _retData = idx
        return idx
    
    # Get filter number
    itemIdx = line.split(' ')[-1]
    
    # Seing non-int in the index sometimes.  Need to fix later.  For now, catch and exit.
    if not itemIdx.isdigit():
        print('Hmmm.  balancePassesFilterProcessing: looking for filter "' + str(itemIdx) + '", but it\'s not digits')
        print('balancePassesFilterProcessing: second line: ' + line)
        _retData = idx
        return idx
    
    # Get the filter name
    retData = CB.viewPriceListData(itemIdx, config)
    object = 'Filter'
    print('Found ' + object + ' "' + retData['NAME'] + '" (' + retData['ID'] + ')')
    
    _retData = idx
    return idx
    
def updatePurchasedData(startString, line, gdata):
    # Get to end of start sting (where key data begins)
    if startString: startOfKeyData = line.find(startString) + len(startString)
    else: startOfKeyData = 0
    
    # Remaining line starts here
    LineRemaining = line[startOfKeyData:]
    
    # Get index past key data.  Delimiter could be a space or a comma (first one found).
    index = min(LineRemaining.find(','), LineRemaining.find(' '))
    
    # Get key data
    itemId = LineRemaining[:index]
    
    try:
        name = gdata[itemId]
        if not OnlyAscii(name): name = '[Non-ASCII characters]'
    except:
        name = 'Undefined'
    
    # Build line: start of line, offer name in parenthesis, rest of the line
    lineResult = line[:startOfKeyData] + LineRemaining[:index] + '(' + name + ')' + LineRemaining[index:]
    
    return lineResult
     
def updateClassAndTemplate(config, startString, line):
        if startString: startOfKeyData = line.find(startString)
        else: startOfKeyData = 0
        LineRemaining = line[startOfKeyData:]

        # Meters may not output class ID (since they don't have one)
        tagFlag = False
        templateString = 'id='
        if line.count('class='):
                classStart = line.find('class=')
                LineRemaining = line[classStart:]
#               print 'Line remaining: ' + str(LineRemaining)

                # Get the class and template IDs
                classIdx   = LineRemaining.split(':')[0].split('=')[1].strip()

                # Made this a generic function.  Causing some issues.  If it fails, then just exit (no harm)
                try:
                        templateId = LineRemaining.split(':')[1].split('=')[1].split(" ")[0].strip()[0:5].split('[')[0]
                except:
                        templateId = None

                # May be a tag instead of an ID...
                if line.count('tag='):
                        tagFlag = True
                        templateString = 'tag='
                        #print('Looking to read balance tag ' + str(templateId))
                        retData = CB.viewBalanceTagData(templateId, config)
                        retData['balanceIdName'] = retData['NAME']
                        classData = CB.viewBalanceClassData(classIdx, config)
                        retData['className'] = classData['NAME']
                else:
                        # Only balance class in the line
                        classData = CB.viewBalanceClassData(classIdx, config)
                        retData = {}
                        if classData: retData['className'] = classData['NAME']
                        else: return line

        else:
                # No class
                classStart = 0
                classIdx = '0'

                # Made this a generic function.  Causing some issues.  If it fails, then just exit (no harm)
                try:
                        templateId = line.split('=')[1].split(" ")[0].strip()[0:5].split('[')[0]
                except:
                        # No class and no template.  WHy did we enter this function??
                        return line

                # May be a tag instead of an ID...
                if line.count('tag='):
                        tagFlag = True
                        templateString = 'tag='
                        #print('Looking to read balance tag ' + str(templateId))
                        retData = CB.viewBalanceTagData(templateId, config)
                        retData['className'] = 'No Class'
                        retData['balanceIdName'] = retData['NAME']

        # Work to do if not a tag and ew have a template ID
        if not tagFlag and templateId:
                # Read balance data
                retData = retrieveBalanceData(templateId)

                # If name is not ASCII, then skip (having way too much trouble pricinging Arabic characters...)
                if not OnlyAscii(retData['balanceIdName']): retData['balanceIdName'] = '[Non-ASCII characters]'

        # Add class and template to line.  Always look for the tempalte ID after the class (string used multiple times in some output).
        classDataIndex = classStart + len('class=') + len(classIdx)
        lineResult =  line[startOfKeyData:classDataIndex] + '(' + retData['className'] + ')'
        if templateId:
               templateIndex = classDataIndex + line[classDataIndex:].find(templateString) + len(templateString) + len(templateId)
               lineResult += line[classDataIndex:templateIndex] + '(' + retData['balanceIdName'] + ')'
               if len(line) > templateIndex: lineResult += line[templateIndex:]
        else:  lineResult += line[classDataIndex:]

        return lineResult

def updateTemplate(line):
    # Made this a generic function.  Causing some issues.  If it fails, then just exit (no harm)
    splitChar = ':'
    try:
        templateId = line.split(splitChar)[1].split(" ")[0].strip()
    except:
        return line
        
    # Print lines
    retData = retrieveBalanceData(templateId)
    
    # Add template to line
    lineResult = line.split(splitChar)[0] + splitChar + templateId + '(' + retData['balanceIdName'] + ') ' + " ".join(line.split(splitChar)[1].split(" ")[1:])
    return lineResult
    
def processHandleInput(allLines, idx, config):
    global _retData
    
    # See where to route this
    line = allLines[idx]
    
    # See what server this is
    if line.count('charging_server'): 
        return processChargingServerInput(allLines, idx, config)
    
    if line.count('camel_gateway'): 
        return processCamelGatewayInput(allLines, idx, config)
    
    # Not processing other inputs
    _retData = idx
    return idx
    
def processCamelGatewayInput(allLines, idx, config):
    global _retData
    
    # get current line
    inputLine = allLines[idx]
    
    # Skip some lines
    for text in ['Cluster', 'service state']:
        if inputLine.count(text):
            _retData = idx
            return idx
    
    # Get the initial task
    try:
        line = inputLine[93:].split(':')
        task = line[0]
        message = line[3]
    except:
        task = '**Unknown task or message (input line: ' + inputLine + ')'
        message = ''
    
    # Output data
    print('Camel Gateway ' + task + ':' + message)
    
    _retData = idx
    return idx
    
def processChargingServerInput(allLines, idx, config):
    global _retData
    
    # get current line
    inputLine = allLines[idx]
    
#   print 'processing charging server input: ' + inputLine
    
    # Get two lines ahead
    idx += 2
    line = allLines[idx]
    
    # Saw one case where a Sy response is right here.  Cover this (but not sure this covers everything...)
    if line.count('                    {'):
        _retData = idx-2
        return idx-2
    
    # If this line is not MtxOpMsg, then exit
#   print 'Two lines ahead: ' + allLines[idx]
    if not line.count('MtxOpMsg'):
        _retData = idx
        return idx
    
    # A possibility!  Get the message being processed
    # Get six lines ahead
    idx += 6
    line = allLines[idx]
#   print 'Six lines ahead: ' + allLines[idx]
    
    # If this line is not one care about, then exit
    for field in ['Query']:
        if line.count(field):
            _retData = idx
            return idx
    
    # Get the operation
    try:
        action = line.split('=')[1].split('(')[0]
    except:
        action = None
    if not action: action = 'Unknown.  Line is: ' + line
    
    # Get the initial task
    try:
        task = inputLine[84:].split(':')[0]
    except:
        task = '**Unknown task (input line: ' + inputLine + ')'
    
    # Print the operation
    print('Charging Server ' + task + ': ' + action)
    
    _retData = idx
    return idx

def diameterProcessing(allLines, idx, config):
    global _retData
    global subscriberId
    
    lclSubscriberId = '0'
    
    # Default output string
    outStr = ''
    
    # Read until the ending
    while idx < len(allLines):
        # Get the current line
        line = allLines[idx]
        
        # Get data minus white space
        linem = line.strip()
        
        # Add to the output string
        outStr += line
        
        # See if we're at the end
        if '}' in linem: break
        
        # Bump index
        idx += 1
        
    # Found the end.  Exit if not a CCR/CCA or RAR/RAA.  Check Sy, Sh, Gx, and Gy.
    found = False
    for match in ['Cmd=C', 'Cmd=R', 'Cmd=S', 'Cmd=P', 'Cmd=A']:
        if outStr.count(match):
            found = True
            break
    
    # Exit if match not found
    if not found:
        _retData = idx
        return idx
    
    # viewObject the subscriber
    # Get the subscriber ID
    lines = outStr.split('\n')
    for i,index in enumerate(range(len(lines))):
        line = lines[index]
        if line.count('Subscription-Id-Data') or line.count('AVP: MSISDN'): break
    
    # See if ID found (CCR will have it; CCA won't)
    option = ''
    if line.count('Subscription-Id-Data'):
        # Found the ID
        lclSubscriberId = line.split('=')[6].strip()
        
        # Minor Hack: if this is a SIP URI then remove MSISDN (before @ characters)
        if lclSubscriberId.count('@'): lclSubscriberId = lclSubscriberId.split('@')[0]
        
        # Get the type - should be next or previous line
        if lines[index+1].count('Subscription-Id-Type'):
            idType = lines[index+1].split('=')[6].strip()
            if idType == '1': option = ' -i '
            else:         option = ' -m '
        elif lines[index-1].count('Subscription-Id-Type'):
            idType = lines[index-1].split('=')[6].strip()
            if idType == '1': option = ' -i '
            else:         option = ' -m '
        else:
            # Not exactly sure the data
            print('Didn\'t find AVP Subscription-Id-Type right before/after Subscription-Id-Data.  Assuming data is MSISDN.')
            option = ' -m '
            
    elif line.count('AVP: MSISDN'):
        # Found the ID
        lclSubscriberId = line.split('=')[7].split(':')[2].split(')')[0]
        lclSubscriberId = binascii.unhexlify(lclSubscriberId)
        option = ' -m '
        
    # If option defined, then view subscriber
    if option:
        # Run viewObject once per ID
        if lclSubscriberId != '0' and subscriberId != lclSubscriberId:
            # Update global
            subscriberId = lclSubscriberId
            
            # Run the command
            cmd = 'viewObject.py ' + option + subscriberId + ' --scope up'
            print(GENERIC.runCmd(cmd))
            print("\n\n")
            
    # Print message
    if outStr.count('CmdReq=1'):
        print('\n\n** Start of Diameter Event **\n\n')
        print(outStr)
    else:   
        print(outStr)
        print('\n\n** End of Diameter Event **\n\n')
    
    _retData = idx
    return idx
        
def traceUsageProcessing(allLines, idx, config):
    global _retData
    
    # Get the current line
    line = allLines[idx]
    
    # Print lines
    (idx, outstr) = UntilNextLmTraceFound(allLines, idx, config, printCurrentLine=True, printFlag=True)
    
    # Return one less, as code assumes index line was processed
    _retData = idx-1
    return idx-1
    
# Analyze charging server input commands
def analyzeChargingServerInputCommand(allLines, idx, config, printCurrentLine=False, printFlag=False):
    global _retData
    global options
    
    # If config is setup for no additional notification data, then exclude it
    if not options.xtraChrgSrvData:
        # Strings that indicate we don't want to print the whole debug item
        listOfStringToCheckFor = ["MtxRequestPricingQuery", \
                "MtxRequestSysQuery", \
                "MtxRequestSubscriberQuery", \
                "MtxRequestDeviceQuery", \
                "MtxRequestGroupQuery", \
                "MtxNotificationObject", \
                "MtxMultiTxnMsg", \
                "MtxProcessPendingMsg", \
                "MtxRequestSubscriberCheckPurchasedItemCycleAlignment", \
                "MtxRequestDeviceEvaluatePolicyCounterSet", \
                "MtxRequestStreamSessionModify", \
                "MtxSocketStatusChangeMsg", \
                "MtxTxnLogMsg", \
                "MtxTxnStreamMsg", \
                ]
    else:   listOfStringToCheckFor = []
    
    # Analyze and print is strings not found
    idx = analyzeUntilNextLmTraceStringNotFound(allLines, idx, config, printCurrentLine=False, printFlag=False, listOfStringToCheckFor=listOfStringToCheckFor)
    _retData = idx
    return idx
    
def analyzeUntilNextLmTraceStringNotFound(allLines, idx, config, printCurrentLine=False, printFlag=False, listOfStringToCheckFor=[]):
    global _retData
    
    # Get the current line
    line = allLines[idx]
    
    # Gather lines; don't print
    (idx, outstr) = UntilNextLmTraceFound(allLines, idx, config, printCurrentLine=printCurrentLine, printFlag=printFlag)
    
    # Check if we find a string that we don;t want to print
    prefix = 'descName='
    for suffix in listOfStringToCheckFor:
        if outstr.count(prefix+suffix): break
    else:
        # Didn't find the string.  Print everything
        print(line)
        print(outstr)
    
    # Return one less, as code assumes index line was processed
    _retData = idx-1
    return idx-1
    
def skipUntilNextLmTraceFound(allLines, idx, config, printCurrentLine=False, printFlag=False):
    global _retData
    
    # Get the current line
    line = allLines[idx]
    
    # Gather lines; don't print
    (idx, outstr) = UntilNextLmTraceFound(allLines, idx, config, printCurrentLine=printCurrentLine, printFlag=printFlag)
    
    # Return one less, as code assumes index line was processed
    _retData = idx-1
    return idx-1
    
def printUntilNextLmTraceFound(allLines, idx, config, printCurrentLine=False, printFlag=False):
    global _retData
    
    # Get the current line
    line = allLines[idx]
    
    # Gather lines; don't print
    (idx, outstr) = UntilNextLmTraceFound(allLines, idx, config, printCurrentLine=printCurrentLine, printFlag=printFlag)
    
    # If something was returned and it's not a None string or not all None strings, then print the whole thing
    if outstr and len(outstr) > 20 and outstr.count('none') < 11:
        print(line)
        print(outstr)
    
    # Return one less, as code assumes index line was processed
    _retData = idx-1
    return idx-1
    
def checkFormulasProcessing(allLines, idx, config):
    global _retData
    
    functionality = 'Check formula processing'
    print('Started ' + functionality)
    
    # Get the current line
    line = allLines[idx]
    
    idx = addingProductOfferProcessing(allLines, idx, config)
    
    _retData = idx
    return idx
    
def addEventAggregationProcessing(allLines, idx, config):
    global _retData
    
    #functionality = 'addEventAggregationProcessing processing'
    #print('Started ' + functionality)
    #line = ''
    
    # Read until the end of this section
    idx = printUntilNextLmTraceFound(allLines, idx, config, printCurrentLine=True, printFlag=True)
    _retData = idx
        
    #print('Completed ' + functionality)
    
    _retData = idx
    return idx
    
def firstUsageStartProcessing(allLines, idx, config):
    global _retData
    
    functionality = 'First Usage processing'
    print('Started ' + functionality)
    line = ''
    
    _retData = idx
    return idx

def firstUsageEndProcessing(allLines, idx, config):
    global _retData
    
    functionality = 'First Usage processing'
    print('Ended ' + functionality)
    line = ''
    
    _retData = idx
    return idx

def autoRenewStartProcessing(allLines, idx, config):
    global _retData
    
    functionality = 'Auto Renew processing'
    print('Started ' + functionality)
    line = ''
    
    _retData = idx
    return idx

def autoRenewEndProcessing(allLines, idx, config):
    global _retData
    
    functionality = 'Auto Renew processing'
    print('Ended ' + functionality)
    line = ''
    
    _retData = idx
    return idx

def DashProcessing(allLines, idx, config):
    global _retData
    
    functionality = 'Dash processing'
    keyWords = []
    keyWords.append(('Applying first usage pricing', 'firstUsageStartProcessing'))
    keyWords.append(('Done applying first usage pricing', 'firstUsageEndProcessing'))
    keyWords.append(('Applying auto-renew pricing', 'autoRenewStartProcessing'))
    keyWords.append(('Done applying auto-renew pricing', 'autoRenewEndProcessing'))
    
    # Get the current line
    line = allLines[idx]
    
    # See what this line is about
    for (keyWord, fcn) in keyWords:
        if line.count(keyWord): 
            cmd = fcn + '(allLines, idx, config)'
            exec(cmd)
    
    _retData = idx
    return idx
    
def startSquiggleProcessing(allLines, idx, config):
    global _retData
    
    functionality = 'Squiggle processing'
    keyWords = []
    keyWords.append(('Adding event to aggregation', 'addEventAggregationProcessing'))
    
    # Get the current line
    line = allLines[idx]
    
    # See what this line is about
    for (keyWord, fcn) in keyWords:
        if line.count(keyWord): 
            cmd = fcn + '(allLines, idx, config)'
            exec(cmd)
            idx = _retData
    _retData = idx
    return idx
    
def announcementProfile(allLines, idx, config):
    global _retData
    
    line = allLines[idx]
    
    # Get to the start of the string where the key data is
    LineRemaining = line[line.find('AnnouncementProfile'):]
    
    # Get result
    try: resultValue = int(LineRemaining.split(':')[1].split(' ')[0])
    except:
       try: resultValue = int(LineRemaining.split(':')[3].split(' ')[0])
       except:
        print('announcementProfile: Did not find the result.')
        print('Line: ' + line)
        print('LineRemaining: ' + str(LineRemaining))
        _retData = idx
        return idx
    
    #  Get to announcement profile
    retDct = CB.viewAnnouncementProfileData(resultValue, config)
    #pprint.pprint(retDct)
    
    # Print profile name and ID
    print(indent1 + 'Announcement Profile "' + str(retDct['NAME']) + '" (' + str(retDct['ID']) + ') selected')
    
    # Get announcement details ID
    try: details = retDct['object']['announcement_profile']['announcement_details']['announcement_detail']
    except:
        print(indent1 + 'NOTE: Announcement profile doesn\'t seems to have any announcements.')
        _retData = idx
        return idx
    
    # Process anouncement details
    if type(details) is not list: details = [details]
    
    # Process each detail
    for detail in details:
        attributes = detail['attrib']
        if type(attributes) is not list: attributes = [attributes]
        
        # Loop through each attribute until we find ID
        for attrib in attributes:
            (name,value) = attrib
            if name == 'id':
                detailsId = value
                break
        else: 
            print('Didn\'t find Announcement Details ID for this profile.')
            pprint.pprint(retDct)
            _retData = idx
            return idx
    
        # Now can read the details
        retDct = CB.viewAnnouncementDetailData(detailsId, config)
        #pprint.pprint(retDct)
    
        # Print Detals name and ID
        print(indent2 + 'Announcement Details "' + str(retDct['NAME']) + '" (' + str(retDct['ID']) + ') selected')
        
        # Get announcement details attributes
        attributes = retDct['object']['announcement_detail']['attrib']
        if type(attributes) is not list: attributes = [attributes]
        
        # Get announcement server ID
        for attrib in attributes:
            (name,value) = attrib
            if name == 'announcement_server':
                serverId = value
                break
        else: 
            print('Didn\'t find Announcement Server for this details.')
            pprint.pprint(retDct)
            continue
    
        # Now can read the server
        retDct = CB.viewAnnouncementServerData(serverId, config)
        #pprint.pprint(retDct)
        
        # Print name and ID
        print(indent2 + 'Announcement Server "' + str(retDct['NAME']) + '" (' + str(retDct['ID']) + ') selected\n')
        
    # Return last line processed
    _retData = idx
    return idx

#def startEqualProcessing(allLines, idx, config):
#   # Get the current line
#   line = allLines[idx]
#   
#   print line
#   
#   return idx
    
def clearFilterData(allLines, idx, config):
    global _retData
    
    # Get the current line
    line = allLines[idx]
    
    # Want to clear filter data if line contains key text
    if line.count('Applying auto-activation filters'): clearHackData(filterHack)
    
    # Always print the current line
    print(line)
    
    _retData = idx
    return idx
    
def printApplyAggregationSelector(allLines, idx, config):
    global _retData
    
    line = allLines[idx]
    
    # Get to start of beyond key string
    keyString = 'applyAggrSelector:'
    line = line[line.find(keyString)+len(keyString):].strip()
    
    # Output the line indented as needed.
    # Don't print if skipping (noise).
    if not line.count('skipped because'): print(indent2 + line)
    
    _retData = idx
    return idx
    
def printApplyFilter(allLines, idx, config):
    global _retData
    
    line = allLines[idx]
    
    # Get to start of beyond key string
    keyString = 'applyFilter:'
    line = line[line.find(keyString)+len(keyString):].strip()
    
    # Output the line indented as needed
    print(indent1 + line)
    
    _retData = idx
    return idx
    
def printGlTxnProfile(allLines, idx, config):
    global _retData
    
    global globalSearchString
    
    line = allLines[idx]
    
    # Need to not print if this line says the profil eis being skipped
    if line.count('skipped because value'):
        _retData = idx
        return idx
    
    # Remove through search string.  Also remove leading : and white space
    line = line[line.find(globalSearchString)+ len(globalSearchString):].lstrip(':').strip()
    
    # Now get the index of the Transaction profile
    itemIdx = line.split(':')[1].split(' ')[0]
    
    retData = CB.viewGlTxnProfileData(itemIdx, config)
    #pprint.pprint(retData)
    
    # Output the line.  Add some indent (probably should have global with the current indent...)
    try: print(indent3 + 'Selected ' + " ".join(line.split(" ")[0:3]) + ' ' + retData['NAME'] + ' (' + str(itemIdx) + ')')
    except: pass
    
    _retData = idx
    return idx
    
def printLineFromSearchString(allLines, idx, config):
    global _retData
    
    global globalSearchString
    
    line = allLines[idx]
    
    # Remove through search string.  Also remove leading : and white space
    line = line[line.find(globalSearchString)+ len(globalSearchString):].lstrip(':').strip()
    
    # Output the line.  Add some indent (probably should have global with the current indent...)
    print(indent3 + line)
    
    _retData = idx
    return idx
    
def printLineProcessing(allLines, idx, config):
    global _retData
    
    line = allLines[idx]
    
    # Convert class/template if in the line
    if line.count('class=') and line.count('id='): line = updateClassAndTemplate(config, None, line)
    
    #  KEF: Could add threshold ID decode here...
    # Output the line
    print(line)
    
    _retData = idx
    return idx
    
def startGreaterThanProcessing(allLines, idx, config):
    global _retData
    
    keyWords = []
    keyWords.append(('Starting charging for used quantity', 'printLineProcessing'))
    keyWords.append(('Starting authorization', 'printLineProcessing'))
    
    # Get the current line
    line = allLines[idx]
    
    # See what this line is about
    for (keyWord, fcn) in keyWords:
        if line.count(keyWord): 
            cmd = fcn + '(allLines, idx, config)'
            exec(cmd)
    
    _retData = idx
    return idx
    
def startEqualProcessing(allLines, idx, config):
    global _retData
    
    keyWords = []
    keyWords.append(('segment', 'printLineProcessing'))
    keyWords.append((' recurring', 'printLineProcessing'))
    
    # Get the current line
    line = allLines[idx]
    
    # See what this line is about
    for (keyWord, fcn) in keyWords:
        if line.count(keyWord): 
            cmd = fcn + '(allLines, idx, config)'
            exec(cmd)
    
    _retData = idx
    return idx
    
#def startSegmentProcessing(allLines, idx, config):
#   functionality = 'segment Start processing'
#   print 'Line ' + str(idx) + ': Started ' + functionality
#   
#   # Get the current line
#   line = allLines[idx]
#   
#   # Print the line
#   print line
#   
#   return idx
#   
#def startRecurringProcessing(allLines, idx, config):
#   functionality = 'recurring processing'
#   print 'Line ' + str(idx) + ': Started ' + functionality
#   line = ''
#   
#   return idx
#   
# Define functions that are called during string processing.
# They need to be above the references in the lists below
# ------------------------------------------------------------------------------
def matrixLookupResultProcessing(allLines, idx, config):
    global _retData
    
    global subInfoHack
    
    # Get the current line
    line = allLines[idx]
    #print 'matrixLookupResultProcessing: line = ' + line
    
    # Get to the start of the string where the key data is
    LineRemaining = line[line.find('Matrix lookup result='):]
    
    # Get result
    resultValue = int(LineRemaining.split('=')[1].split(' ')[0])
    if resultValue >= 0: result = True
    else:            result = False
    
    # Get to the start of the string where the key data is
    # May be a charge component or a priority generator or an aggregation selector
    '''
    if line.count('AggegationSelector'):
        LineRemaining = line[line.find('AggegationSelector:'):]
        
        # Get the items
        itemIdx = LineRemaining.split(':')[1].split(' ')[0]
        print 'matrixLookupResultProcessing: AggegationSelector: LineRemaining = "' + LineRemaining + '", itemIdx = "' + str(itemIdx) + '"'
        
        # Get already retrieved data
        retPriceData = CB.viewAggregationSelectorListData(itemIdx, config)
        print 'Found aggregation selector "' + retAggregationSelectorData['NAME'] + '" (' + retAggregationSelectorData['ID'] + ')'
        
        # Get the name of the matrix component
        itemIdx = LineRemaining.split(' ')[-1]
        
        # The above is the index into the object tables.  
        # These are stored in the price specific data
        itemIdx = CB.viewAggregationSelectorTable(itemIdx, config, retAggregationSelectorData['ID'])
        print 'itemIdx = ' + str(itemIdx)
        
        # Now get matrixx data using updated matrixx index
        retMatrixData = CB.viewMatrixListData(itemIdx, config)
        print 'Found Matrix "' + retMatrixData['NAME'] + '" (' + retMatrixData['ID'] + ')'
    '''
    if line.count('Component:'):
        LineRemaining = line[line.find('Component:'):]
        
        # Get the items
        itemIdx = LineRemaining.split(':')[1].split(',')[0]
        
        # OK, policy and other components report debug differently...
        if itemIdx.isdigit():
            # Non-policy component
            retPriceData = CB.viewPriceListData(itemIdx, config)
            #print 'Found price component "' + retPriceData['NAME'] + '" (' + retPriceData['ID'] + ')'
            
            # Get the name of the matrix component
            itemIdx = LineRemaining.split(' ')[-1]
            
            # The above is the index into the price component rate tables.  
            # These are stored in the price specific data
            itemIdx = CB.viewPriceComponentRateTable(itemIdx, config, retPriceData['ID'])
            #print 'itemIdx = ' + str(itemIdx)
            
            # Now get matrixx data using updated matrixx index
            retMatrixData = CB.viewMatrixListData(itemIdx, config)
            #print 'Found Matrix "' + retMatrixData['NAME'] + '" (' + retMatrixData['ID'] + ')'
        else:
            # Policy component.  Matrix not reported here, so just blank for now
            retMatrixData = {}
            retMatrixData['NAME'] = "<See Above>"
            retMatrixData['ID']   = ""
        
        # Print summary
        print(indent2 + 'Matrix "' + retMatrixData['NAME'] + '" (' + retMatrixData['ID'] + ') result = ' + str(result))
    else:
        # Get component
        component = LineRemaining.split(':')[0].split(' ')[-1]
        
        # Get the items
        itemIdx = LineRemaining.split(':')[1].split(' ')[0]
        
        # Default indentation
        indent = indent1
        
        # Minor hack.  Some objects return success because they find an answer.  For these simply say passed.
        if component in ['Filter']:
            if resultValue > 0: result = True
            else:           result = False
        elif component in ['ActionProfileGenerator']:
            # Go to indentation level 2
            indent = indent2
            
            # Change output string
            component = 'SubscriberInfoQueryAction'
            
            # Hack: If an action profile generator and the result is true, then need to reset the hack data as rating
            #   will restart evaluation at matrixx 0.
            if result == True: clearHackData(subInfoHack)
        
        elif component in ['GlTxnProfileSelector', 'GlAccountSelector']:
            # Go to indentation level 3
            indent = indent3
        elif component in ['AggegationSelector', 'AggregationSelector']:
            if resultValue == -127: result = "skip"
            else:           result = str(resultValue)
            
            # Go to indenttion level 2
            indent = indent2
        
        # Build result string
        result = 'result = ' + str(result)
        
        # Print summary
        print(indent + component + ' ' + '(name TBD)' + ' (' + str(itemIdx) + ') ' + result)
    
    # If a policy component then the same line needs to be processed a second time
    if line.count('PolicyComponent:'): applyCommonMatrixProcessing(allLines, idx, config)
    
    _retData = idx
    return idx
    
# ------------------------------------------------------------------------------
def selectedLastUnitProfile(allLines, idx, config):
    global _retData
    
    global lastUnitInfoHack
    
    # HACK code: Clear data as we can hit the same object consecutively across different offers
    lastUnitInfoHack['id'] = -1
    lastUitInfoHack['tableIndex'] = -1
    
    # Don't need to output anything here...
    _retData = idx
    return idx
    
    # Print until next trace line
    return printUntilNextLmTraceFound(allLines, idx, config)

# ------------------------------------------------------------------------------
def selectedRepositoryProfile(allLines, idx, config):
    global _retData
    
    global repositoryHack
    
    # HACK code: Clear data as we can hit the same object consecutively across different offers
    repositoryHack['id'] = -1
    repositoryHack['tableIndex'] = -1
    
    # Get th3yye current line
    line = allLines[idx]
    
    # Get the profile ID
    profileId = line.split(':')[-1].strip()
    #print 'Selected Profile ' + str(profileId)
    
    # Print profile data
    retDct = CB.viewRepositoryProfileData(profileId, config)
    #pprint.pprint(retDct)
    
    # May or may not be a list.  Force to be a list.
    # Also, an empty profile won't have a RepositoryDataList element (so put into a try statement)
    try:
     #print 'Type for repository_data: ' + str(type(retDct['object']['repository_data_profile']['RepositoryDataList']['repository_data']))
     #print 'Type of list is ' + str(type(list()))
     if type(retDct['object']['repository_data_profile']['RepositoryDataList']['repository_data']) != type(list()):
        retDct['object']['repository_data_profile']['RepositoryDataList']['repository_data'] = [retDct['object']['repository_data_profile']['RepositoryDataList']['repository_data']]
    except: pass        
    
    # Output key items
    print(indent1 + 'Repository Profile: ' + retDct['NAME'] + ' (' + profileId + ')')
    try:
        for service in retDct['object']['repository_data_profile']['RepositoryDataList']['repository_data']:
            # Process each element in the list
            for element in service['attrib']:
                (name,value) = element
                print(indent2 + name + ' ' + value)
        
    except:
        pprint.pprint(retDct)
        print(indent1 + 'No Data for this profile')
    
    _retData = idx
    return idx
    
# ------------------------------------------------------------------------------
def selectedUsageProfile(allLines, idx, config):
    global _retData
    
    global usageHack
    
    # HACK code: Clear data as we can hit the same object consecutively across different offers
    usageHack['id'] = -1
    usageHack['tableIndex'] = -1
    
    # Print until next trace line
    return printUntilNextLmTraceFound(allLines, idx, config)

# ------------------------------------------------------------------------------
def selectedRolloverProfile(allLines, idx, config):
    global _retData
    
    global rolloverHack
    
    # HACK code: Clear data as we can hit the same object consecutively across different offers
    rolloverHack['id'] = -1
    rolloverHack['tableIndex'] = -1
    
    # Print until next trace line
    return printUntilNextLmTraceFound(allLines, idx, config)

# ------------------------------------------------------------------------------
def selectedPolicyProfile(allLines, idx, config):
    global _retData
    
    global policyHack
    
    # HACK code: Clear data as we can hit the same object consecutively across different offers
    policyHack['id'] = -1
    policyHack['tableIndex'] = -1
    
    # Don't need to output anything here...
    _retData = idx
    return idx
    
    # Print until next trace line
    return printUntilNextLmTraceFound(allLines, idx, config)

# ------------------------------------------------------------------------------
def calculatedPriority(allLines, idx, config):
    global _retData
    
    global priorityHack
    
    # Get the line
    line = allLines[idx]
    
    # In case the line has class and ID, update here
    if line.count('id='): line = updatePurchasedData('id=', line, CB.retOfferData)
        
    # Print the line
    print(line)
    
    # HACK code: Clear priority data as we can hit the same object consecutively across different offers
    priorityHack['id'] = -1
    priorityHack['tableIndex'] = -1
    
    _retData = idx
    return idx

# ------------------------------------------------------------------------------
def clearHackData(globalData):
    # Not this object.  Clear hack data.
    globalData['id'] = -1
    globalData['tableIndex'] = -1

# ------------------------------------------------------------------------------
def updateHackData(globalData, itemIdx):
        # If index the same then bump table ID; else reset to 0
        if globalData['id'] == itemIdx: 
            globalData['tableIndex'] += 1
        else:   
            # Set Data to point to new item
            globalData['id'] = itemIdx
            globalData['tableIndex'] = 0
        
        # Set index
        return globalData['tableIndex']
            
# ------------------------------------------------------------------------------
def normalizationResultsProcessing(allLines, idx, config):
    global _retData
    
    global priorityHack
    global filterHack
    global taxSelectorHack
    global policyHack
    global balanceStateHack
    global rolloverHack
    global usageHack
    global repositoryHack
    
    matrixIndex = -1
    retNormData = None
    
    # Get the current line
    line = allLines[idx]
    
    # Get to the start of the string where the key data is.
    # Could be many different things.
    # KEF: AggregationSelector debug has a typo (AggegationSelector)...  MTX-31356.
    for objName in ['RepositoryComponent', \
            'UsageQuotaComponent', \
            'UsageTriggerComponent', \
            'PolicyComponent', \
            'RolloverComponent', \
            'BalanceStateComponent', \
            'RepositoryComponent', \
            'Component', \
            'Filter', \
            'PriorityGenerator', \
            'TaxSelector', \
            'GlInfoGenerator', \
            'GlTxnProfileSelector', \
            'GlAccountSelector', \
            'LastUnitInfoGenerator', \
            'LastUnitInfoGeneratorRev', \
            'ActionProfileGenerator', \
            'AnnouncementProfileGenerator', \
            'AggegationSelector', \
            'AggregationSelector', \
            ]:
        if   line.count(objName+':'): break
    else:
        print('Hmmmm.  No recognizable object in this line')
        print(line)
        print('Skipping it')
        _retData = idx
        return idx
    
    # Remove through component name + colon
    LineRemaining = line[line.find(objName+':'):]
    
    '''
    print 'normalizationResultsProcessing: objName: ' + objName
    print 'line: ' + line
    print 'LineRemaining; ' + LineRemaining
    '''
    
    # Get the component index
    itemIdx = LineRemaining.split(':')[1].split(' ')[0]
    
    # HACK code: Set table indices (HACK until debug log reports indies for all objects)
    if objName == 'Filter': matrixIndex = updateHackData(filterHack, itemIdx)
    else: clearHackData(filterHack)
        
    if objName == 'PriorityGenerator': matrixIndex = updateHackData(priorityHack, itemIdx)
    else: clearHackData(priorityHack)
    
    if objName == 'TaxSelector': matrixIndex = updateHackData(taxSelectorHack, itemIdx)
    else: clearHackData(taxSelectorHack)
    
    if objName == 'BalanceStateComponent': matrixIndex = updateHackData(balanceStateHack, itemIdx)
    else: clearHackData(balanceStateHack)
    
    if objName == 'PolicyComponent': matrixIndex = updateHackData(policyHack, itemIdx)
    else: clearHackData(policyHack)
    
    if objName == 'UsageQuotaComponent': matrixIndex = updateHackData(usageHack, itemIdx)
    else: clearHackData(usageHack)
    
    if objName == 'UsageTriggerComponent': matrixIndex = updateHackData(usageTriggerHack, itemIdx)
    else: clearHackData(usageTriggerHack)
    
    if objName == 'RolloverComponent': matrixIndex = updateHackData(rolloverHack, itemIdx)
    else: clearHackData(rolloverHack)
    
    if objName == 'RepositoryComponent': matrixIndex = updateHackData(repositoryHack, itemIdx)
    else: clearHackData(repositoryHack)
    
    if objName in ['LastUnitInfoGenerator', 'LastUnitInfoGeneratorRev']: matrixIndex = updateHackData(lastUnitInfoHack, itemIdx)
    else: clearHackData(lastUnitInfoHack)
    
    if objName in ['ActionProfileGenerator']: matrixIndex = updateHackData(subInfoHack, itemIdx)
    else: clearHackData(subInfoHack)
    
    if objName in ['GlInfoGenerator']: matrixIndex = updateHackData(glInfoHack, itemIdx)
    else: clearHackData(glInfoHack)
    
    if objName in ['GlTxnProfileSelector']: matrixIndex = updateHackData(glTxnHack, itemIdx)
    else: clearHackData(glTxnHack)
    
    if objName in ['GlAccountSelector']: matrixIndex = updateHackData(glAcntHack, itemIdx)
    else: clearHackData(glAcntHack)
    
    if objName in ['AnnouncementProfileGenerator']: matrixIndex = updateHackData(announcementHack, itemIdx)
    else: clearHackData(announcementHack)
    
    if objName in ['AggegationSelector', 'AggregationSelector']: matrixIndex = updateHackData(aggregationSelector, itemIdx)
    else: clearHackData(aggregationSelector)
    
    # Get the matrix index if not already set
    if matrixIndex == -1:
        try:
            matrixIndex = int(LineRemaining.split('=')[1].split(' ')[0])
        except:
            print('Didn\'t find table index.  assuming table 0')
            print('line remaining: ' + LineRemaining)
            print("Search criteria: int(LineRemaining.split('=')[1].split(' ')[0])")
            matrixIndex = 0
    
    # Debug output
#   print 'normalizationResults: looking for ' + objName + ' ' + str(itemIdx) + ' table ' + str(matrixIndex)
    
    # Process per component
    if objName in ['Component', 'Filter']:
#       print 'normalizationResults: looking for PC ' + str(itemIdx)
        retData = CB.viewPriceListData(itemIdx, config)
        if int(matrixIndex) == 0: print(indent1 + 'Found ' + objName + ' "' + retData['NAME'] + '" (' + retData['ID'] + ')')
        
        # The above is the index into the price component rate tables.  
        # These are stored in the price specific data
        tableIndex = CB.viewPriceComponentRateTable(matrixIndex, config, retData['ID'])
        retTable = CB.viewMatrixListData(tableIndex, config)
    
        # Get normalizers
#       print 'normalizationResults: looking for normalizers in matrix' + str(tableIndex)
        retNormData = CB.viewMatrixNormalizers(tableIndex, config)
    
    # *** The rest of these don't have XSLT transformation so they need to read the raw file and process that.  Common processing (so actually easier).
    elif objName == 'PriorityGenerator':
        retData = CB.viewPriorityGeneratorData(itemIdx, config)
        
        # The above is the index into the Priority Generator tables.  
        # These are stored in the price specific data
        if matrixIndex >= len(retData['tables']): matrixIndex = len(retData['tables']) - 1
        if int(matrixIndex) == 0: print(indent1 + 'Found ' + objName + ' "' + retData['NAME'] + '" (' + retData['ID'] + ')')
        tableIndex = retData['tables'][matrixIndex]
        retTable = CB.viewPriorityGeneratorTableData(tableIndex, config)
        
    elif objName == 'TaxSelector':
        retData = CB.viewTaxSelectorData(itemIdx, config)
        
        # The above is the index into the tables.  
        # These are stored in the price specific data
        if matrixIndex >= len(retData['tables']): matrixIndex = len(retData['tables']) - 1
        if int(matrixIndex) == 0: print(indent1 + 'Found ' + objName + ' "' + retData['NAME'] + '" (' + retData['ID'] + ')')
        tableIndex = retData['tables'][matrixIndex]
        retTable = CB.viewTaxSelectorTableData(tableIndex, config)
        
    elif objName == 'BalanceStateComponent':
        retData = CB.viewBalanceStateData(itemIdx, config)
        
        # The above is the index into the tables.  
        # These are stored in the price specific data
        if matrixIndex >= len(retData['tables']): matrixIndex = len(retData['tables']) - 1
        if int(matrixIndex) == 0: print(indent1 + 'Found ' + objName + ' "' + retData['NAME'] + '" (' + retData['ID'] + ')')
        tableIndex = retData['tables'][matrixIndex]
        retTable = CB.viewBalanceStateTableData(tableIndex, config)
        #pprint.pprint(retTable)
        
        # These have tables between the component and the decision table
        outputBalanceTableProfile(retTable, config)
        
    elif objName == 'PolicyComponent':
        retData = CB.viewPolicyData(itemIdx, config)
        
        # The above is the index into the tables.  
        # These are stored in the price specific data
        if matrixIndex >= len(retData['tables']): matrixIndex = len(retData['tables']) - 1
        if int(matrixIndex) == 0: print(indent1 + 'Found ' + objName + ' "' + retData['NAME'] + '" (' + retData['ID'] + ')')
        tableIndex = retData['tables'][matrixIndex]
        retTable = CB.viewPolicyTableData(tableIndex, config)
    
    elif objName == 'RepositoryComponent':
        retData = CB.viewRepositoryData(itemIdx, config)
        
        # The above is the index into the tables.  
        # These are stored in the price specific data
        if matrixIndex >= len(retData['tables']): matrixIndex = len(retData['tables']) - 1
        if int(matrixIndex) == 0: print(indent1 + 'Found ' + objName + ' "' + retData['NAME'] + '" (' + retData['ID'] + ')')
        tableIndex = retData['tables'][matrixIndex]
        retTable = CB.viewRepositoryTableData(tableIndex, config)
    
    elif objName == 'UsageTriggerComponent':
        retData = CB.viewUsageTriggerData(itemIdx, config)
        #pprint.pprint(retData)
        
        # The above is the index into the tables.  
        # These are stored in the price specific data
        if matrixIndex >= len(retData['tables']): matrixIndex = len(retData['tables']) - 1
        if int(matrixIndex) == 0: print(indent1 + 'Found ' + objName + ' "' + retData['NAME'] + '" (' + retData['ID'] + ')')
        tableIndex = retData['tables'][matrixIndex]
        retTable = CB.viewUsageTriggerTableData(tableIndex, config)
        #pprint.pprint(retTable)
    
    elif objName == 'UsageQuotaComponent':
        retData = CB.viewUsageComponentData(itemIdx, config)
        #pprint.pprint(retData)
        
        # The above is the index into the tables.  
        # These are stored in the price specific data
        if matrixIndex >= len(retData['tables']): matrixIndex = len(retData['tables']) - 1
        if int(matrixIndex) == 0: print(indent1 + 'Found ' + objName + ' "' + retData['NAME'] + '" (' + retData['ID'] + ')')
        tableIndex = retData['tables'][matrixIndex]
        retTable = CB.viewUsageTableData(tableIndex, config)
        #pprint.pprint(retTable)
    
    elif objName == 'RolloverComponent':
        retData = CB.viewRolloverData(itemIdx, config)
        
        # The above is the index into the tables.  
        # These are stored in the price specific data
        if matrixIndex >= len(retData['tables']): matrixIndex = len(retData['tables']) - 1
        if int(matrixIndex) == 0: print(indent1 + 'Found ' + objName + ' "' + retData['NAME'] + '" (' + retData['ID'] + ')')
        tableIndex = retData['tables'][matrixIndex]
        retTable = CB.viewRolloverTableData(tableIndex, config)
    
    elif objName == 'ActionProfileGenerator':
        objName2 = 'SubscriberInfoQueryAction'
        retData = CB.viewSubInfoData(itemIdx, config)
        
        # The above is the index into the tables.  
        # These are stored in the price specific data
        if matrixIndex >= len(retData['tables']): matrixIndex = len(retData['tables']) - 1
        if int(matrixIndex) == 0: print(indent1 + 'Found ' + objName2 + ' "' + retData['NAME'] + '" (' + retData['ID'] + ')')
        tableIndex = retData['tables'][matrixIndex]
        retTable = CB.viewSubInfoTableData(tableIndex, config)
    
    elif objName in ['LastUnitInfoGenerator', 'LastUnitInfoGeneratorRev']:
        retData = CB.viewLastUnitData(itemIdx, config)
        
        # The above is the index into the tables.  
        # These are stored in the price specific data
        if matrixIndex >= len(retData['tables']): matrixIndex = len(retData['tables']) - 1
        if int(matrixIndex) == 0: print(indent1 + 'Found ' + objName + ' "' + retData['NAME'] + '" (' + retData['ID'] + ')')
        tableIndex = retData['tables'][matrixIndex]
        retTable = CB.viewLastUnitTableData(tableIndex, config)
    
    elif objName in ['AggegationSelector', 'AggregationSelector']:
        retData = CB.viewAggregationSelectorData(itemIdx, config)
        
        # The above is the index into the aggregation selection tables.  
        # These are stored in the price specific data
        if matrixIndex >= len(retData['tables']): matrixIndex = len(retData['tables']) - 1
        if int(matrixIndex) == 0: print(indent1 + 'Found ' + objName + ' "' + retData['NAME'] + '" (' + retData['ID'] + ')')
        tableIndex = retData['tables'][matrixIndex]
        retTable = CB.viewAggregationSelectorTableData(tableIndex, config)
        
    elif objName == 'AnnouncementProfileGenerator':
        retData = CB.viewAnnouncementGeneratorData(itemIdx, config)
        
        # The above is the index into the announcement Generator tables.  
        # These are stored in the price specific data
        if matrixIndex >= len(retData['tables']): matrixIndex = len(retData['tables']) - 1
        if int(matrixIndex) == 0: print(indent1 + 'Found ' + objName + ' "' + retData['NAME'] + '" (' + retData['ID'] + ')')
        tableIndex = retData['tables'][matrixIndex]
        retTable = CB.viewAnnouncementTableData(tableIndex, config)
        
    elif objName == 'GlTxnProfileSelector':
        retData = CB.viewGlTxnProfileSelectorData(itemIdx, config)
        
        # The above is the index into the announcement Generator tables.  
        # These are stored in the price specific data
        if matrixIndex >= len(retData['tables']): matrixIndex = len(retData['tables']) - 1
        if int(matrixIndex) == 0: print(indent1 + 'Found ' + objName + ' "' + retData['NAME'] + '" (' + retData['ID'] + ')')
        tableIndex = retData['tables'][matrixIndex]
        retTable = CB.viewGlTxnProfileSelectorTableData(tableIndex, config)
        
    elif objName == 'GlAccountSelector':
        retData = CB.viewGlAccountSelectorData(itemIdx, config)
        
        # The above is the index into the announcement Generator tables.  
        # These are stored in the price specific data
        if matrixIndex >= len(retData['tables']): matrixIndex = len(retData['tables']) - 1
        if int(matrixIndex) == 0: print(indent1 + 'Found ' + objName + ' "' + retData['NAME'] + '" (' + retData['ID'] + ')')
        tableIndex = retData['tables'][matrixIndex]
        retTable = CB.viewGlAccountSelectorTableData(tableIndex, config)
        
    elif objName in ['GlInfoGenerator']:
        retData = CB.viewGlInfoData(itemIdx, config)
        #pprint.pprint(retData)
        
        # Get the next two lines:
        line1 = allLines[idx+1].strip()
        line2 = allLines[idx+2].strip()
        
        # Bump index into the lines
        idx += 2
        
        # See which entry we're dealing with here
        if   line2.count('transaction type'):
            index = 'GLTransTypeTable'
            index2 = 'gl_transaction_type_table'
        elif line2.count('account 1'):
            index = 'GLAccount1'
            index2 = 'gl_account_table'
        elif line2.count('account 2'):
            index = 'GLAccount2'
            index2 = 'gl_account_table'
        else:
            print(indent1 + 'Found ' + objName + ' "' + retData['NAME'] + '" (' + retData['ID'] + ')')
            print('WARNING: line + 2 in G/L info generator processing not recognized: "' + line2 + '"')
            _retData = idx
            return (idx)
        
        # Get the matrixx number
        #print 'Line2 = ' + line2
        try:
            matrixIndex = int(line2.split(',')[1].strip().split(' ')[1])
        except:
            matrixIndex = int(line2.split(':')[-2].strip().split(' ')[7])
        
        '''
        print 'Looking to decode ' + index + ' matrix ' + str(matrixIndex)
        table = retData['info'][index][matrixIndex]
        pprint.pprint(table)
        _retData = idx
        return (idx)
        '''
        
        # Output the type of G/L table
        #print 'looking for index ' + str(index) + ', matrixIndex = ' + str(matrixIndex)
        #pprint.pprint(retData['info'])
        #pprint.pprint(retData['info'][index][matrixIndex]['object'])
        if matrixIndex >= len(retData['info'][index]): matrixIndex = len(retData['info'][index]) - 1
        if int(matrixIndex) == 0: print(indent1 + 'Found ' + objName + ' "' + retData['NAME'] + '" (' + retData['ID'] + ')')
        fileId = retData['info'][index][matrixIndex]['object']['attrib'][3][1].split('/')[1].split('.')[0]
        name = retData['info'][index][matrixIndex]['object'][index2]['attrib'][-1][1]
        print(indent1p5 + 'Type: ' + index + ' "' + name + '" (' + fileId  + ')')
            
        # The above is the index into the tables.  
#       pprint.pprint(retData['info'][index][matrixIndex])
        retTable = CB.viewGlObjectTableData(matrixIndex, config, retData['info'][index], index, index2)
        #pprint.pprint(retTable)
    else:
        # Unexpected component name
        print('WARNING: eventDecode not aware of this component: ' + objName + '.  Need to add suport for this.')
        _retData = idx
        return idx
    
    # Work if a newer component that doesn't have specific xslt translations
    if retNormData == None:
        # Debug component data
#       print objName
#       pprint.pprint(retTable)
        
        # Debug table output    
#       print objName + ' retTable:'
#       pprint.pprint(retTable)
    
        # Get the decision table
        retDecisionTable = CB.viewDecisionTableData(retTable['DecisionTable'], config)
#       print objName + ' retDecisionTable ' + retTable['DecisionTable'] + ':'
#       pprint.pprint(retDecisionTable)
        
        # Put normalizer data into common element
        retNormData = copy.deepcopy(retDecisionTable['Normalizers'])
        
    # If no normalizers, then exit here
    if not len(retNormData):
        print(indent2 + 'Matrix ' + str(matrixIndex) + ' "' + retTable['NAME'] + '" (' + retTable['ID'] + ') has NO normalizers')
        
        # Print GL result (hard to decode this due to the way this data is output)
        if   objName in ['GlInfoGenerator']: glLine2Print(line2, config, index)
        elif objName in ['TaxSelector']: addlTaxSelector(config, retTable)
        elif objName in ['RolloverComponent']: addlRollover(config, retTable)
        elif objName in ['UsageQuotaComponent']: addlUsage(config, retTable)
        elif objName in ['ActionProfileGenerator']: addlPreRating(config, retTable)
        
        _retData = idx
        return idx
    
    # Print normallizers
    print(indent2 + 'Matrix ' + str(matrixIndex) + ' "' + retTable['NAME'] + '" (' + retTable['ID'] + ')' + ' has normalizers ' + str(retNormData))
    
    # Get normalizer data
    normalizerValueList = LineRemaining.split(':')[-1].strip().split(',')
#   print indent3 + 'Found Normalizer values: ' + str(normalizerValueList)
    
    # Seeing issues where too many normalizer values are reported on the debug line.  Ugh...  Catch that here.
    if len(retNormData) != len(normalizerValueList):
        print('WARNING: Debug reported ' + str(len(normalizerValueList)) + ' normalizer values but MyMatrixx says there are ' + str(len(retNormData)) + ' normalizers.  Will use the smaller of the two')
        if len(retNormData) < len(normalizerValueList):
            listCount = len(retNormData)
        else:   listCount = len(normalizerValueList)
    else:   listCount = len(normalizerValueList)
    # Loop through all reported normalizers
    for i,normalizerValue in enumerate(normalizerValueList):
        # Exit if we exceeded the smaller amount
        if i == listCount: break
        
        # Get normallizer ID
        normalizerIdx = retNormData[i].strip()
        normalizerValue = normalizerValue.strip()
        retData = CB.viewNormalizerData(normalizerIdx, config, normalizerValue)
        print(indent3 + 'Found Normalizer "' + retData['NAME'] + '" (' + retData['ID'] + ') with value ' + str(normalizerValue) + ' (' + retData['normValueName'] + ')')
    
    # Print GL result (hard to decode this due to the way this data is output)
    if   objName in ['GlInfoGenerator']: glLine2Print(line2, config, index)
    elif objName in ['TaxSelector']: addlTaxSelector(config, retTable)
    elif objName in ['RolloverComponent']: addlRollover(config, retTable)
    elif objName in ['UsageQuotaComponent']: addlUsage(config, retTable)
    elif objName in ['ActionProfileGenerator']: addlPreRating(config, retTable)
    
    # Return last processed line
    _retData = idx
    return idx
    
# ------------------------------------------------------------------------------
def outputBalanceTableProfile(retData, config):
    # Sanity check the result
    if 'object' not in retData:
        pprint.pprint(retData)
        return
    
    #  Get profile data
    for item in retData['object']['balance_state_update_table']['attrib']:
        (attrName, attrValue) = item
        if   attrName == 'name': name = str(attrValue).replace('"','\'')
        elif attrName == 'extension_amount': extension_amount = str(attrValue).replace('"','\'')
        elif attrName == 'balance_id': balance_id = str(attrValue).replace('"','\'')
    
    try:    name = name
    except: name = "N/A"
    try:    extension_amount = extension_amount
    except: extension_amount = "N/A"
    try:    retData = retrieveBalanceData(balance_id)
    except: 
        balance_id = "N/A"
        retData = {}
        retData['balanceIdName'] = "N/A"
    
    print(indent1p5 + 'Balance Update Table: "' + name + '", Balance "' + retData['balanceIdName'] + '" (' + balance_id + ')')
    

# ------------------------------------------------------------------------------
def outputNotificationProfile(allLines, idx, config):
    global _retData
    
    # ** NOT YET TESTED **
    line = allLines[idx]
    
    # Get the profile ID
    profileId = line.split(':')[-1]
    
    # Read the tax selector
    retData = CB.getCbData(config, profileId, 'NotificationProfile', retFormat='DICT')
    #pprint.pprint(retData)
    
    # Sanity check the result
    if 'object' not in retData:
        pprint.pprint(retData)
        return
    
    #  Get profile name
    name = retData['object']['notification_profile']['name']
    
    #  Get profile data
    print(indent1p5 + 'Notification Profile: "' + name + '"')
    for item in retData['object']['notification_profile']['notification_profile_data_list']: print(indent1p5 + str(item))
    
    # Return last processed line
    _retData = idx
    return idx

# ------------------------------------------------------------------------------
def outputBalanceStateProfile(allLines, idx, config):
    global _retData
    
    line = allLines[idx]
    
    # Get the profile ID
    profileId = line.split(':')[-1]
    
    # Read the tax selector
    retData = CB.getCbData(config, profileId, 'BalanceStateUpdateProfile', retFormat='DICT')
    #pprint.pprint(retData)
    
    # Sanity check the result
    if 'object' not in retData:
        pprint.pprint(retData)
        return
    
    #  Get profile data
    name = extension_amount = extension_units = extension_type = end_time_adjust_type = "N/A"
    for item in retData['object']['balance_state_update_profile']['attrib']:
        (attrName, attrValue) = item
        if   attrName == 'name': name = str(attrValue).replace('"','\'')
        elif attrName == 'extension_amount': extension_amount = str(attrValue).replace('"','\'')
        elif attrName == 'extension_units': extension_units = str(attrValue).replace('"','\'')
        elif attrName == 'extension_type': extension_type = str(attrValue).replace('"','\'')
        elif attrName == 'end_time_adjust_type': extension_type = str(attrValue).replace('"','\'')
    
    print(indent1p5 + 'Balanace State Update Profile: "' + name + '"')
    print(indent1p5 + 'Amount = ' + extension_amount + ' ' + extension_units + ', extension_type = ' + extension_type + ', end_time_adjust_type = ' + end_time_adjust_type)
    
    # Return last processed line
    _retData = idx
    return idx

# ------------------------------------------------------------------------------
def addlPreRating(config, retTable):
    # Print input
    #pprint.pprint(retTable)
    
    # Print data modify and call out action
    
    return
    
# ------------------------------------------------------------------------------
def addlUsage(config, retTable):
    # Print input
    #pprint.pprint(retTable)
    
    # Get the result.  Apparently some results come back as a list...
    try:
            result = retTable['object']['usage_quota_table']['decision_table_ref']['results']['result']['value']
    except: result = retTable['object']['usage_quota_table']['decision_table_ref']['results']['result'][0]['value']
    
    # If <= 0 then failed
    if int(result) < 0: return
    
    # Nothing really to do from this call...
    return

# ------------------------------------------------------------------------------
def printUsageTriggerProfile(config, result):
    # Read the usage quota profile
    retData = CB.getCbData(config, result, 'UsageTriggerProfile', retFormat='DICT')
    #print 'printUsageTriggerProfile:'
    #pprint.pprint(retData)
    
    # Sanity check the result
    if 'object' not in retData:
        pprint.pprint(retData)
        return
    
    #  Get profile data
    for item in retData['object']['usage_trigger_profile']['attrib']:
        (attrName, attrValue) = item
        if   attrName == 'name': name = str(attrValue).replace('"','\'')
    
    # Output heading
    print(indent2 + 'Usage Trigger Profile: "' + name)
    #pprint.pprint(retData)
    
    # Get list of profile items (5G and non-5G)
    try:
        result = ''
        i = 0
        for item in retData['object']['usage_trigger_profile']['usage_5g_trigger_list']['usage_5g_trigger']:
            #pprint.pprint(item)
            for entry in item['attrib']:
                #pprint.pprint(entry)
                (a,b) = entry
                result += b
                
                # Data is in pairs so add separator after each pair and add pair split after each entry
                i += 1
                if i % 2:   result += '/' 
                else:       result += ', '
        
        # If anything found, print it
        if result: print(indent2 + '5G triggers: ' + result[:-2])
    except: pass
    
    # Get list of profile items (5G and non-5G)
    try:
        result = ''
        i = 0
        for item in retData['object']['usage_trigger_profile']['usage_gy_trigger_list']['usage_gy_trigger']:
            #pprint.pprint(item)
            for entry in item['attrib']:
                #pprint.pprint(entry)
                (a,b) = entry
                result += b
                
                # Data is in pairs so add separator after each pair and add pair split after each entry
                i += 1
                if i % 2:   result += '/' 
                else:       result += ', '
        
        # If anything found, print it
        if result: print(indent2 + 'Gy triggers: ' + result[:-2])
    except: pass
    
    return
    
def printUsageProfile(config, result):
    # Read the usage quota profile
    retData = CB.getCbData(config, result, 'UsageQuotaProfile', retFormat='DICT')
    #pprint.pprint(retData)
    
    # Sanity check the result
    if 'object' not in retData:
        pprint.pprint(retData)
        return
    
    #  Get profile data
    name = min_auth = min_auth_unit = max_auth = max_auth_unit = reauth_auth_unit = default_auth = default_auth_unit = default_reauth = default_reauth_unit = "N/A"
    for item in retData['object']['usage_quota_profile']['attrib']:
        (attrName, attrValue) = item
        if   attrName == 'name': name = str(attrValue).replace('"','\'')
        elif attrName == 'min_auth': min_auth = str(attrValue).replace('"','\'')
        elif attrName == 'min_auth_unit': min_auth_unit = str(attrValue).replace('"','\'')
        elif attrName == 'max_auth': max_auth = str(attrValue).replace('"','\'')
        elif attrName == 'max_auth_unit': max_auth_unit = str(attrValue).replace('"','\'')
        elif attrName == 'reauth_auth_unit': min_auth = str(attrValue).replace('"','\'')
        elif attrName == 'default_auth': min_auth_unit = str(attrValue).replace('"','\'')
        elif attrName == 'default_auth_unit': max_auth = str(attrValue).replace('"','\'')
        elif attrName == 'default_reauth': max_auth_unit = str(attrValue).replace('"','\'')
        elif attrName == 'default_reauth_unit': max_auth_unit = str(attrValue).replace('"','\'')
    
    # Output heading
    print(indent2 + 'Usage Profile: "' + name + '"')
    
    # Go through listed sorted by name (1st element)
    for attrib in sorted(retData['object']['usage_quota_profile']['attrib'], key=lambda name: name[0]):
        # Put int locals
        (name,value) = attrib
        
        # Print all but useless values
        if name not in ['UUID', 'formatNumber', 'correction_number']: print(indent2 + name + ' = ' + str(value))
    
    # Separation
    print('')
    
    #pprint.pprint(retData['object']['usage_quota_profile']['attrib'])
    
# ------------------------------------------------------------------------------
def addlRollover(config, retTable):
    # Print input
    #pprint.pprint(retTable)
    
    # Get the result
    try:    result = retTable['object']['rollover_table']['decision_table_ref']['results']['result']['value']
    except: result = retTable['object']['rollover_table']['decision_table_ref']['results']['result'][0]['value']
    
    # If <= 0 then failed
    if int(result) < 0: return
    
    # Read the tax selector
    retData = CB.getCbData(config, result, 'RolloverProfile', retFormat='DICT')
    #pprint.pprint(retData)
    
    # Sanity check the result
    if 'object' not in retData:
        pprint.pprint(retData)
        return
    
    #  Get profile data
    name = rollover_percent = max_total_rollover_amount = max_rollover_amount = rollover_count = balance_id = "N/A"
    for item in retData['object']['rollover_profile']['attrib']:
        (attrName, attrValue) = item
        if   attrName == 'name': name = str(attrValue).replace('"','\'')
        elif attrName == 'rollover_percent': rollover_percent = str(attrValue).replace('"','\'')
        elif attrName == 'max_total_rollover_amount': max_total_rollover_amount = str(attrValue).replace('"','\'')
        elif attrName == 'max_rollover_amount': max_rollover_amount = str(attrValue).replace('"','\'')
        elif attrName == 'rollover_count': rollover_count = str(attrValue).replace('"','\'')
        elif attrName == 'balance_id': balance_id = str(attrValue).replace('"','\'')
    
    print(indent2 + 'Rollover Profile: "' + name + '"')
    print(indent2 + 'Balance "' + retData['balanceIdName'] + '" (' + balance_id + '), rollover percent = ' + rollover_percent + ', rollover count = ' + rollover_count)
    print(indent2 + 'max rollover amount = ' + max_rollover_amount + ', max total rollover amount = ' + max_total_rollover_amount)
    
# ------------------------------------------------------------------------------
def addlTaxSelector(config, retTable):
    # Print input
    #pprint.pprint(retTable)
    
    # NOTE: This code for this object runs before the code that sees success/failure of the object.  It's because of how the debug messages are output.
    # So the decode will show the tax class of all rate tables, not just the one that was successful.
    
    # Get the table ID.  SOme varience in returned data across releases...
    try:    idx = retTable['object']['tax_selector_table']['decision_table_ref']['results']['result']['value']
    except: idx = retTable['object']['tax_selector_table']['decision_table_ref']['results']['result'][0]['value']
        
    # If <= 0 then failed
    if int(idx) < 0: return
    
    # Read the tax selector
    retData = CB.getCbData(config, idx, 'TaxSelectionProfile', retFormat='DICT')
    #pprint.pprint(retData)
    
    # Sanity check the result
    if 'object' not in retData:
        pprint.pprint(retData)
        return
    
    # Simplify access
    retData = retData['object']['tax_selection_profile']
    
    #  Get profile data.  Use Python to create an array of 1 item based on the attribute name we care about, then index 0 to get the value.
    #pprint.pprint(retData)
    # Make sure attributes are  alist of they can be
    try:
        if retData['tax_class_id_list']['tax_class_id'] is not list: retData['tax_class_id_list']['tax_class_id'] = [retData['tax_class_id_list']['tax_class_id']]
    except: pass
    
    try:
        # Process each entry
        classId = []
        for entry in retData['tax_class_id_list']['tax_class_id']:
            #print 'entry: ' + str(entry)
            (name, value) = entry['attrib'][0]
            if name == 'value': classId.append(value)
    except:
        # Not required to have any classes in the profile
        print(indent2 + 'Did not find tax class.  Tool sometimes returns same dictionary entry twice.  retData:')
        pprint.pprint(retData)
        return
    
    # Get the name attribute
    name    = [x[1] for x in retData['attrib'] if x[0] == 'name'][0]
    print(indent2 + 'Selection Profile: "' + name + '", tax class ' + str(classId))
    
    # Read the class
    for id in classId:
        retData = CB.getCbData(config, id, 'TaxClass', retFormat='DICT')
        #pprint.pprint(retData)
        
        # Sanity check the result
        if 'object' not in retData:
            pprint.pprint(retData)
            return
        
        # Simplify access
        retData = retData['object']['TaxClasses']['MtxTaxClassObject']
        
        # Get the recognition type
        recognition = retData['TaxRecognitionType']['value']
        name        = retData['Name']['value']
        rate        = retData['Rate']['value']
        print(indent2 + 'Class ' + name + '; Recognition: ' + recognition + '; Rate = ' + rate)
    
# ------------------------------------------------------------------------------
def glLine2Print(line2, config, index):
    # Always print the line
    try:
        print(indent2 + line2[line2.find('Result'):])
    except: print(indent2 + line2[149:])
    
    # Seems we get the transaction type value, not the file name (like elsewhere...).  Skip for now.
    '''
    # More data to report for transaction type
    if index == 'GLTransTypeTable' and not line2.count('skip'):
        # Can read the transaction type
        typeId = line2.strip().split(' ')[-1]
        transactionTypeDct = CB.getGlTransType(typeId, config)
        try:
            print indent2 + transactionTypeDct['object']['transaction_type']['attrib'][3][1]
        except:
            print 'Hmmm.  Failed in reading GL Transaction type ID ' + str(typeId)
            pprint.pprint(transactionTypeDct)
    '''
    
# ------------------------------------------------------------------------------
def printError(allLines, idx, config):
    # Seeing LDAP callout failures really messing up output.  This is expected in non-PROD environments.  Skip those.
    if allLines[idx].count("empty response from"):
        _retData = idx+1
        return idx+1

    return printUntilNextLmTraceFound(allLines, idx, config, printCurrentLine=True, printFlag=True)

# ------------------------------------------------------------------------------
def UntilNextLmTraceFound(allLines, idx, config, printCurrentLine=False, printFlag=True):
    global _retData
    
    # Print current line if specified
    if printCurrentLine: print(allLines[idx])
    
    # Always go to the next line at this point
    idx += 1
    
    # Default outputs
    outStr = ''
    stopStrings = ['======', 'LM_TRACE', 'LM_INFO', 'LM_DEBUG', 'LM_ERROR', '**** TEST FRAMEWORK']
    
    # Loop until we find a stop string
    while idx < len(allLines):
        # Get the current line
        line = allLines[idx]
        
        # See if we start with any of the stop strings
        for item in stopStrings:
            if line.startswith(item):
                # Print what we have to date
                if printFlag: print(outStr)
                
                # Exit; point to previous line so we process line we stopped on
                _retData = idx
                return idx, outStr
        
        # In case the line has class and ID, update here
        if line.count('class=') and line.count('id='): line = updateClassAndTemplate(config, None, line)
        
        # Store line
        outStr += line
        
        # Bump index
        idx += 1
    
    # Output data
    if printFlag: print(outStr)
    
    _retData = idx
    return idx,outStr
        
def calculateChargesProcessing(allLines, idx, config):
    global _retData
    
    # Print trace + current line
    (idx, outStr) = UntilNextLmTraceFound(allLines, idx, config, True)
    
    _retData = idx-1
    return idx-1

def combineFormulaProcessing(allLines, idx, config):
    global _retData
    
    # Get the current line
    line = allLines[idx]
    
    # Seeing where errors result in "Undefined" output.  Check for that
    if not line.count('Component:'):
        print('Hmmm.  Expected to find the word "Component" but did not.')
        (idx, outStr) = UntilNextLmTraceFound(allLines, idx, config, True, True)
        _retData = idx
        return idx
        
    # Get to the start of the string where the key data is
    LineRemaining = line[line.find('Component:'):]
    
    # Get the item
    itemIdx = LineRemaining.split(':')[1].split(' ')[0]
    
    # Get the name of the component
    retData = CB.viewPriceListData(itemIdx, config)
    print('\n\nFound price component "' + retData['NAME'] + '" (' + retData['ID'] + ')')
    
    # Loop/print until next LM_TRACE encountered
    (idx, outStr) = UntilNextLmTraceFound(allLines, idx, config, False)
    
    _retData = idx
    return idx
    
# ------------------------------------------------------------------------------
def addingProductOfferProcessing(allLines, idx, config):
    global _retData
    
    # Get the current line
    line = allLines[idx]
    #print 'addingProductOfferProcessing: line is ' + line
    
    # Get to the start of the string where the key data is
    LineRemaining = line[line.lower().find('id='):]
    
    # Sanity check this
    if not LineRemaining.count('='):
        print('Hmmm.  Line ' + str(idx) + ' looking for an "=" and didn;t find it.  Line is: ' + line)
        #sys.exit('Exiting Early')
        _retData = idx
        return idx
        
    # Get the item.  Different output strings if offer parameters are used
    if LineRemaining.count('has parameters'):
        itemIdx = LineRemaining.split(':')[1].split(' ')[0]
    else:
        itemIdx = LineRemaining.split('=')[1].split(',')[0]
    
    # Get the name of the component
    print('addingProductOffer: looking for offer ' + str(itemIdx))
    retData = CB.viewOfferListData(itemIdx, config)
    print('\n**** Found offer "' + retData['NAME'] + '" (' + retData['ID'] + ')')
#   print 'Data: ' + str(retData)
    
    _retData = idx
    return idx

# ------------------------------------------------------------------------------
def requiredBalancesForOfferProcessing(allLines, idx, config):
    global _retData
    
    # Loop until blank line found
    while idx < len(allLines):
        # Get the next line
        idx += 1
        line = allLines[idx].strip()
        
        # If empty line or line signals no balances, then break
        if not line or line.count('none'): break
        
        # Get to the start of the string where the key data is
        #print 'Line          : ' + str(line)
        LineRemaining = line[line.find('classID='):]
        #print 'Line remaining: ' + str(LineRemaining)
        
        # Get the item 
        classIdx = LineRemaining.split('=')[1].split(' ')[0]
        templateId = LineRemaining.split(':')[1]
        
        # Get the name of the component
        print('Looking for classID ' + str(classIdx) + ', template ID ' + str(templateId))
        #print 'balancesData = ' + str(balancesData)
        retData = retrieveBalanceData(templateId)
        
        # Print the data
        print(" "*10 + 'Class "' + retData['className'] + '" (' + retData['classId'] + ') template "' + retData['balanceIdName'] + '" (' + retData['balanceId'] + ')')
        
    _retData = idx
    return idx

def retrieveBalanceData(templateId):
    retData = {}
    
    for balance in balancesData['MtxResponsePricingBalanceList']['BalanceList']['MtxPricingBalanceInfo']:
        # See if this matches the index
        if balance['BalanceId']['value'] != templateId.strip(): continue
    
        # Found it
        retData['className'] = balance['ClassName']['value']
        retData['classId']  = balance['ClassId']['value']
        retData['balanceId']  = balance['BalanceId']['value']
        retData['balanceIdName']  = balance['Name']['value']
        
        break
    
    # Sanity check we found something
    if 'className' not in retData:
        print('Hmmm. Didn\'t find balance information for template "' + templateId + '"')
        retData['className'] = retData['classId']  = retData['balanceId']  = retData['balanceIdName']  = 'Unknown'
    
    # Return data
    return retData
    
# Misc code to be used sometime...
def misc():
    # Now print the key fields of the normalizer
    for attrib in retDct['object']['attrib']:
        # Want to find the file name and then get the number
        (name, value) = attrib
        if name != 'filename': continue
        print('Found filename = ' + value.split('/')[1].split('.')[0])
    
    # Now want the normalizer name
    for attrib in retDct['object']['normalizer']['attrib']:
        # Want to find the file name and then get the number
        (name, value) = attrib
        if name != 'name': continue
        print('Found normalizer name = ' + value)
    
    # Now want the normalizer values
    retDct['ids'] = {}
    for value in retDct['object']['normalizer']['values']['value']:
      description = id = None
      for attrib in value['attrib']:
        # Want to find the file name and then get the number
        (name, value) = attrib
        if name == 'description': description = value
        elif name == 'id': id = value
        if description and id:
            retDct['ids'][id] = description 
            break
    print('Found normalizer values = ' + str(retDct['ids']))

# Report on selected PreRating profile
def preratingActionProfile(allLines, idx, config):
    global _retData
    
    line = allLines[idx]
    
    # Get profile
    searchData = 'Action profile ActionProfile:'
    index = line[line.find(searchData) + len(searchData):].split(" ")[0]
    
    # Get the data
    data = CB.viewSubInfoProfileData(index, config)
    #pprint.pprint(data)
    
    # Get values
    name = data['NAME']
    
    # Output the ID
    print(indent2 + 'Action profile ID = ' + str(index) + ' (' + name + ')')

    # Get/print the next logical state attribute
    nextLogicalState = 'Unknown'
    for attribute in data['object']['subscriber_info_query_profile']['attrib']:
       # Get action ID
       (name, value) = attribute

       # Save next logical state
       if name == 'next_logical_state':
           nextLogicalState = value
           break
    print(' '*len(indent2) + 'Next Logical State: ' + nextLogicalState)

    # Get the actions
    actions = data['object']['subscriber_info_query_profile']['actions']
    
    # Process data modify actions
    for action in ['data_modify_action', 'subscriber_info_query_action']:
      if action in actions:
        # Make sure it's a list (will not be a list if only a single item).
        if type(actions[action]) is not list: actions[action] = [actions[action]]
        
        # Loop through each action
        for item in actions[action]:
            for attribute in item['attrib']:
                # Get action ID
                (name, actionId) = attribute
                
                # Get action details
                if action == 'data_modify_action':
                    actionData = CB.viewSubInfoDataModifyActionData(actionId, config)
                else:   
                    actionData = CB.viewSubInfoActionData(actionId, config)
                    
                # Get key values
                for entry in actionData['object'][action]['attrib']:
                    (attrName, attrValue) = entry
                    if   attrName == 'name': name = str(attrValue).replace('"','\'')
                    elif attrName == 'destination_container': destination_container = str(attrValue).replace('"','\'')
                    elif attrName == 'destination_field': destination_field = str(attrValue).replace('"','\'')
                    elif attrName == 'destination_action': destination_action = str(attrValue).replace('"','\'')
                    elif attrName == 'constant_value': constant_value = str(attrValue).replace('"','\'')
                    elif attrName == 'source_container': source_container = str(attrValue).replace('"','\'')
                    elif attrName == 'source_field': source_field = str(attrValue).replace('"','\'')
                    elif attrName == 'source': source = str(attrValue).replace('"','\'')
                
                # Output is per action
                if action == 'data_modify_action':
                    # Easy enough to format cleanly
                    destination = destination_container + ':' + destination_field
                    try:
                        if destination_action == '1':
                            actionToTake = 'create if absent'
                            try:    source = constant_value + '(constant)'
                            except: source = source_container + ':' + source_field
                            
                        elif destination_action == '0':
                            actionToTake = 'delete'
                            source = ''
                        else:
                            actionToTake = 'create or update'
                            try:    source = constant_value + '(constant)'
                            except: source = source_container + ':' + source_field
                            source = ', source = ' + source
                    except:
                        actionToTake = 'TOOL EXCEPTION'
                        source = ''
                    print(indent2 + name + ': action = ' + actionToTake + ' ' + source + ', destination = ' + destination)
                else:
                    print(indent2 + name + ':')
                    
                    # Too much data to try and make pretty.  Print all the relevant information.
                    pprint.pprint(actionData['object'][action], indent=len(indent2), width=160)
                    print()
    _retData = idx
    return idx
    
# ------------------------------------------------------------------------------
# Define input
def commandInput():
        global options
        global args
        global submanBuilder
        global dataAlreadyInit
        global ObjectReferencedValues
        global ReprocessFlag
        global DirOrFileInput
    
        # -----------------------------------------------------------------------------
        # Program Usage and Options
        # -----------------------------------------------------------------------------
        #define the options and parameter
        parser = OptionParser(usage="usage: %prog [options] filename",
                      version="%prog 0.1")
    
        parser.add_option("-d", "--debug",
                      action="store",
                      default=None,
                      type="str",
                      dest="debug",
                      help="Debug flag",)
    
        parser.add_option("-v", "--verbose",
                      action="store_true",
                      dest="verbose_flag",
                      default=False,
                      help="Additional logging.")
    
        parser.add_option("", "--config",
                      action="store",
                      default="/opt/mtx/services/config/config_primitives.ini",
                      type="str",
                      dest="config",
                      help="Configuration file",)
    
        parser.add_option("", "--scope",
                      action="store",
                      default="diameter",
                      type="str",
                      dest="scope",
                      help="Decode full debug log or just diameter (default)",)
    
        parser.add_option("", "--loop",
                      action="store_true",
                      default=False,
                      help="Loop decoding",)
    
        parser.add_option("-f", "--inputFile", action='store', type='string', default=None, help='List of debug log files to process (on local server)')
        parser.add_option("",   "--dirName",   action='store', type='string', default=None, help='Directory where debug log files reside (on local server)')
    
        parser.add_option("-i", "--ip",        action='store', type='string', default=None, help='IP address of any blade in engine, to retrieve create_config.info file')
        parser.add_option("-e", "--engine",    action='store', type='int',    default=None, help='Engine designation in create_config.info (starts with 1)')
        parser.add_option("-c", "--cluster",   action='store', type='int',    default=None, help='Cluster designation in create_config.info (starts with 1)')
        parser.add_option("-b", "--blade",     action='store', type='int',    default=None, help='Blade within a cluster (starts with 1)')
        parser.add_option("",   "--fqn",       action='store', type='string', default=None, help='engine:cluster:blade nomnclature')
        parser.add_option("",   "--localIpAddresses",   action='store', type='string', default=None, help='INTERNAL USE')
        
        # Simple authentication
        parser.add_option("",   "--httpAuthUsername",   action='store', type='string', default=None, help='Simple authentication username')
        parser.add_option("",   "--httpAuthPassword",   action='store', type='string', default=None, help='Simple authentication password')
        
        # Optional data to decode
        parser.add_option("",   "--xtraAll",            action='store_true', default=False, help='Include all additional data')
        parser.add_option("",   "--xtraSelUpdData",     action='store_true', default=False, help='Include selective updates in the decode')
        parser.add_option("",   "--xtraNotificationData",       action='store_true', default=False, help='Include additional notification information')
        parser.add_option("",   "--xtraChrgSrvData",        action='store_true', default=False, help='Include additional charging server input information')
        parser.add_option("",   "--taxes",              action='store_true', default=False, help='Include tax data in decode')
    
        # Set the subman mode of operation
        (options, args) = parser.parse_args()
    
        # PRIORITIZE INPUTS
        # If directory name passed in, that's what we'll use
        if options.dirName:
            # This takes priority
            options.ip = options.engine = options.cluster = options.blade = None
        
            # Setup to be a list
            options.inputFile = []
        
            # Do not reprocess for directory files
            ReprocessFlag = False
        
            # Set flag that local data is being used
            DirOrFileInput = True
        
        elif options.inputFile:
            # This takes priority
            options.ip = options.engine = options.cluster = options.blade = None
    
            # Split multiple files into a list
            options.inputFile = options.inputFile.split(',')
        
            # Do not reprocess for input files
            ReprocessFlag = False
        
            # Debug output
            print('File list to process from input file list: ' + str(options.inputFile))
        
            # Set flag that local data is being used
            DirOrFileInput = True
        
        else:
            # If no IP specified, then use localhost
            if not options.ip:
                    print('Note: No IP address input. Will use localhost to read from.')
                    options.ip = 'localhost'
            
            # Check if fqn specified
            if options.fqn:
                    # OK, see how much of this was specified
                    items = options.fqn.split(':')
                    if len(items) > 3:
                            print('ERROR:  fqn input must be at most engine:cluster:blade.  Invalid input found: ' + options.fqn)
                            sys.exit('ERROR')
                    elif len(items) == 3:
                            # Specified all the items
                            options.engine = items[0]
                            options.cluster = items[1]
                            options.blade = items[2]
                    elif len(items) == 2:
                            # Specified engine/cluster items
                            options.engine = items[0]
                            options.cluster = items[1]
                            options.blade = None
                    elif len(items) == 1:
                            # Specified engine/cluster items
                            options.engine = items[0]
                            options.cluster = 1
                            options.blade = None
                
            # See about engine/cluster/blade designations
            elif not options.engine:
                    print('Note: No engine data specified.  Will use 1:1:all')
                    options.engine = 1
                    options.cluster = 1
                    options.blade = None
            elif not options.cluster:
                    print('Note: No cluster data specified.  Will use cluster 1, all blades.')
                    options.cluster = 1
                    options.blade = None
            elif not options.blade:
                    print('Note: No blade data specified.  Will use all blades.')
        
        # If no date specified, default to today
#       if not options.date:
#           date = datetime.now()
#           options.date = str(date.year) + '-' + str(date.month).zfill(2) + '-' + str(date.day).zfill(2) + 'T00:00:00'
#           print 'No date entered.  Using today\'s date (midnight): ' + options.date
    
        # Store all local IP addresses
        options.localIpAddresses = ['localhost']
        options.localIpAddresses.extend(GENERIC.runCmd('ifconfig | grep "inet addr" | cut -f2 -d":" | cut -f1 -d" "').split('\n'))
        print('Local IPs: ' + str(options.localIpAddresses))
    
        # If xtraAll set, then set all individual xtra items
        if options.xtraAll: options.xtraSelUpdData = options.xtraNotificationData = options.xtraChrgSrvData = True
        
        # Report skipping selective updates
        if not options.xtraSelUpdData:
            print("Skipping selective update decode")
        else:   searchStrings.extend(selUpdSearchStrings)
        
        # Report skipping of taxes
        if not options.taxes:
            print("Skipping tax decode")
        else:   searchStrings.extend(taxSearchStrings)
        
        # Return what was read
        return options, args
    
# ------------------------------------------------------------------------------
# Get Engine data
def getEngineData(config):
    global balancesData
    
    # Setup HTTP connection
    dctRcv = {}
    dctRcv['hostname'] = config['Rest']['hostname']
    dctRcv['hostport'] = config['Rest']['hostport']
    program = HTTP.setupHttpConnection(dctRcv)
    
    # Get Balances list
    print('\nGetting balances\n')
    q = GET.getBalancesDctData(program)
    
    # Let's see what we got...
    balancesData = XML.walkXmlData(q)
    #pprint.pprint(balancesData)

# ------------------------------------------------------------------------------
def findStrings(allLines, idx, stringList, config):
    global _retData
    
    global globalSearchString
    
#   print 'Input strings to search for: ' + str(stringList)
    
    # Only read to end of input
    while idx < len(allLines):
        #print('Reading line ' + str(idx))
        # Get the input line
        line = allLines[idx]
        #print('line: ' + line)
        
        # Loop through strings we're looking for
        for stringData in stringList:
            (stringToMatch, nextLevelString, fcn) = stringData
            #print('String to match: ' + stringToMatch)
                
            # See if there's a match
            if line.count(stringToMatch):
                #print('Line ' + str(idx) + ' Found string "' + stringToMatch + '"')
                # See if there's a function to run here
                if fcn:
                    globalSearchString = stringToMatch
                    cmd = fcn + '(allLines, idx, config)'
                    #print('idx = ' + str(idx) + ', cmd = ' + cmd)
                    exec(cmd)
                    idx = _retData
                
                # See if we need to iterate on this
                if nextLevelString:
                    #print('Moving down a level')
                    idx = findStrings(allLines, idx+1, nextLevelString, config)
                    
                    # Could break here, but allow for the same line to match multiple levels...
                else:
                    #print('Moving up a level')     
                    _retData = idx
                    return idx
    
        # Bump index
        idx += 1

    # If here, then we procesed all lines in the file
    print('Returning from findStrings at the end of the function')
    _retData = idx
    return idx

# ------------------------------------------------------------------------------
def processInputFiles(options, config):
    # First thing is to skinny down the log files based on what iteration we're on
    DEBUG.processInputFiles(options)
    
    # Loop through every file
    # Translate all files to array of messages
    for file in options.inputFile:
        # Sometimes commands leave a blank in the array...
        if not file: continue
        
        # Run the command to filter the debug log file.
        # Capture any Diameter hdr string (so we get RAR as well as CCR).
        if   options.scope == 'diameter':
            print('Capturing Diameter events from debug log file ' + file)
            cmd = 'sed -n "/Diameter Hdr:/,/                    }/p" ' + file + ' > _z'
        elif options.scope == 'camel':
            print('Capturing CAMEL events from debug log file ' + file)
            cmd = 'sed -n "/START CAMEL Message Processing/,/END CAMEL Message Processing/p" ' + file + ' > _z'
        elif options.scope == '5g':
            print('Capturing 5G events from debug log file ' + file)
            cmd = 'sed -n "/Starting to handle 5G Msg/,/Completed handling 5G Msg/p" ' + file + ' > _z'
        else:
            # For now, anything entered means process the whole file
            cmd = 'cp ' + file + ' _z'
    
        # Run the filter command
        GENERIC.runCmd(cmd)
        
        # Open debug log file
        inputFile = './_z'
        in_file = open(inputFile, 'r')
        allLines = in_file.readlines()
        in_file.close()
        print('Read ' + str(len(allLines)) + ' lines from file ' + inputFile)
        
        # Match a level 0 string
        print('\n\nEnd of tool setup\n\n')
        idx = 0
        while idx < len(allLines):
            idx = findStrings(allLines, idx, searchStrings, config)
            
            # Bump index, as return is last procesed line
            idx += 1
    
        # Remove the temp files
        cmd = 'rm -f _z '
        
        # If not using local data, then remove the temp debug log file
        if not DirOrFileInput: cmd += file
        
        # Execute remove command
        GENERIC.runCmd(cmd)
        
# ------------------------------------------------------------------------------
#  MAIN
# ------------------------------------------------------------------------------
def main():
    # Get command line data
    (options, args) = commandInput()
    
    # Update simple auth variables.  Input take priority, then environment variables
    if options.httpAuthUsername:
        PRIMDATA.simpleAuthUserName = options.httpAuthUsername
        PRIMDATA.simpleAuthPassword = options.httpAuthPassword
    elif os.getenv("httpAuthUsername"):
        PRIMDATA.simpleAuthUserName = os.getenv("httpAuthUsername")
        PRIMDATA.simpleAuthPassword = os.getenv("httpAuthPassword")
    
    # Init global data
    (customData, config) = GENERIC.initData(options.config)
    #print 'Config = ' + str(config)
    
    # Start time for statistical reasons
    start_time = datetime.now()
    start_time_str = start_time.strftime('%d-%b-%YT%H-%M-%S')
    print('Starting data conversion at time: ' + start_time_str)
    
    # Get CB data
    CB.getAllCbData(config, -1)
    
    '''
    pprint.pprint(CB.retOfferData)
    pprint.pprint(CB.retBundleData)
    pprint.pprint(CB.retCIData)
    '''
    
    # Get engine data
    program = getEngineData(config)
    
    # Print single offer data
    #CB.walkOfferData('29', config)
    #sys.exit('Exiting Early')
    
    ########## Gather config files ##################
    options = DEBUG.gatherAllConfigFiles(options)

    # Loop while the answer not some form of "no"...
    ans = 'y'
    while not ans.lower().startswith('n'):

            ########## Gather all required files ##################
            DEBUG.getDebugLogFiles(options)
        
            ############## Process Input Data #################
            processInputFiles(options, config)
        
            # If an IP address was specified, then we may loop to keep processing things.
        # Also, need the "loop" option to loop back (default is one shot)
            if ReprocessFlag and options.loop:
                    # prompt to continue
                    print('Press Enter key to process from last point; enter "n" to terminate: ')
                    ans = str(eval(input()))
            else: ans = 'n'

        ############## Logout from CB #################
    CB.cbLogout()
        
if __name__ == '__main__':
        main()

