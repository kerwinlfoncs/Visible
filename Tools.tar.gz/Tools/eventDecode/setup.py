from distutils.core import setup
setup(name='mtx-services-eventDecode',
	version='4710.0',
	scripts=['eventDecode.py'],
	description='MATRIXX Services Event Debug Log Decode Tool',
	author='Karl Freter',
	author_email='karl.freter@matrixxsw.com',
	url='www.matrixx.com',
      )

