from distutils.core import setup
setup(name='mtx-services-diamLogViewer',
	version='4710.0',
	scripts=['diamLogViewer.py'],
	description='MATRIXX Debug Log Diameter Log Viewer',
	author='Karl Freter',
	author_email='karl.freter@matrixxsw.com',
	url='www.matrixxsw.com',
      )

