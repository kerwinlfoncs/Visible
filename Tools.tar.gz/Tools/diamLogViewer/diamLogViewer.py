#!/usr/bin/python
#===============================================================================
#
# Copyright 2013 Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

# NOTE:  Please do not import any additional QA test-specific files here.  This file is used
#        as part of the debug log analysis script and needs to run stand-alone
#        (i.e. only using Python libraries).  The files already imported have been setup to
#        work in this mode.

from __future__ import print_function
# from builtins import input
# from builtins import str
# from builtins import range
import sys, os, re, copy, pprint, time
import optparse
import subprocess
import base64
from subprocess import call
from datetime import datetime
from primitives     import primGeneric as GENERIC
from primitives     import primDebugFile as DEBUG

# Define statr/end of message characters
msgStartString = 'Diameter Hdr'
msgLineSkipChar = '{'
msgEndChar = '}'

# Grouped AVP strings
groupStartEndString = 'grouped_avp'
vendorNameString = 'vendor_name'
diameterHeader = 'Diameter Hdr'
hierarchyString = '->'

# Subscription type values
subIdMSISDNType = '0'
subIdIMSIType = '1'

subExternalId = '1'

# Setup file globals so we can keep track of CCRs and handle them when the corresponding CCA comes in
ccrStats = {}
cerStats = {}
cerIndex = -1
slrStats = {}

# Flag signaliing whether filtering is desired
filterFlag = False

# Variable that holds the file that contained the current event
FileWhereEventCameFrom = 0
FileLineCount = {}
ReprocessFlag = True

# Define and setup various mappings (so we know what's assigned to what)
groupTracking = {}
groupTracking['groupId'] = []	# List of groups that are defined
subscriberTracking = {}
subscriberTracking['externalId'] = []	# List of subscribers that are defined
deviceTracking = {}
deviceTracking['deviceId'] = [] # List of devices that are defined
accessNumberTracking = {}
accessNumberTracking['accessNumbers'] = [] # List of accessNumbers that are defined
sessionTracking = {}
sessionTracking['sessions'] = []
diamConnection = None
diamConnectionGy = None
diamConnectionSy = None
noCheckFlag = False

# Define for saved time
saveTime = {}

# Commpn output strings
headingString  = '\n\n**************  Start of Output *******************\n'
trailingString = '\n\n**************  End of Output   *******************\n'

# Output format string
formatStr = "%-10s %-15s %-6s %-6s %-7s %-4s %-50s %27s %-s"

# No rating group string
noRatingGroup = '-1'

# Flag per iteration for outputting hear information
outputHeaderFlag = False

#==========================================================
def processDataToOutput(data, fileName):
         # See where to output the returned data
         if not fileName:
                # Send to standard Out
                #print headingString
                print(str(data))
                #print trailingString
         elif fileName != 'None':
                # Append to a file
                # Open data file
                try:
                 dataFile = open(fileName.lstrip(), 'a')
                except IOError as e:
                 print('I/O error({0}) on opening of file "' + fileName + '". Error details: {1}'.format(e.errno, e.strerror))
                 return

                # Write the input data.
                # Append newline, as writing to file doesn't do this (and print does)
                #dataFile.write(headingString)
                dataFile.write(str(data)+'\n')
                #dataFile.write(trailingString)

                # Close the file
                dataFile.close()

#==========================================================
def showDeviceTrackingData(devList, scope = 'local', verbose = 'none', outputFileName = None):
   # If no checks are on, then can;t do anything here
   if noCheckFlag:
	print('NOTE:  noChecks flag is on.  No tracking is enabled.')
	return

   #print 'showDeviceTrackingData: scope/verbose = ' + scope + '/' + verbose
   # Go through all devices in the list
   for deviceId in devList:
	# Output data
	_str= 'Device  ' + deviceId + \
		', Parent Subscriber = ' + deviceTracking[deviceId]['externalId'] + \
		', number of marks = ' + str(len(deviceTracking[deviceId]['mark'])) + \
		', number of access numbers: ' + str(len(deviceTracking[deviceId]['accessNumbers'])) + \
		', number offers: ' + str(len(deviceTracking[deviceId]['offerId'])) + \
		', number active sessions: ' + str(len(deviceTracking[deviceId]['sessions']))
	processDataToOutput(_str, outputFileName)
	_str= 'marks: ' + str(deviceTracking[deviceId]['mark']) + \
		'\nAccess Numbers: ' + str(deviceTracking[deviceId]['accessNumbers']) + \
		'\nOffers: ' + str(deviceTracking[deviceId]['offerId']) + \
		'\nSessions: ' + str(deviceTracking[deviceId]['sessions']) + \
		'\n'
	processDataToOutput(_str, outputFileName)
	 
	# If verbose is high, then show all sessions
	if verbose == 'high' and len(deviceTracking[deviceId]['sessions']):
	    for subSession in deviceTracking[deviceId]['sessions']:
		# Log session data
		processDataToOutput(str(sessionTracking[subSession]) + '\n', outputFileName)

#==========================================================
def showSubscriberTrackingData(subList, scope = 'local', verbose = 'none', outputFileName = None):
   # If no checks are on, then can;t do anything here
   if noCheckFlag:
	print('NOTE:  noChecks flag is on.  No tracking is enabled.')
	return

   #print 'showSubscriberTrackingData: scope/verbose = ' + scope + '/' + verbose
   # Go through all subs in the list
   for externalId in subList:
	 # Output data
	 _str= 'Subscriber  ' + externalId + \
		', number of marks = ' + str(len(subscriberTracking[externalId]['mark'])) + \
		', number of devices: ' + str(len(subscriberTracking[externalId]['deviceId'])) + \
		', number of parent groups: ' + str(len(subscriberTracking[externalId]['parentGroupId'])) + \
		', number offers: ' + str(len(subscriberTracking[externalId]['offerId'])) + \
		', number active sessions: ' + str(len(subscriberTracking[externalId]['sessions']))
	 processDataToOutput(_str, outputFileName)
	 _str = 'marks: ' + str(subscriberTracking[externalId]['mark']) + \
		'\nDevices: ' + str(subscriberTracking[externalId]['deviceId']) + \
		'\nParent Groups: ' + str(subscriberTracking[externalId]['parentGroupId']) + \
		'\nOffers: ' + str(subscriberTracking[externalId]['offerId']) + \
		'\nSessions: ' + str(subscriberTracking[externalId]['sessions']) + \
		'\n'
	 processDataToOutput(_str, outputFileName)
	
	 # Output device data if any exist and we're in a verbose mode
	 if subscriberTracking[externalId]['deviceId'] and verbose != 'none':
		showDeviceTrackingData(subscriberTracking[externalId]['deviceId'], scope = scope, verbose = verbose, outputFileName = outputFileName)
	 
#==========================================================
def showGroupTrackingData(groupList, level, scope = 'local', verbose = 'none', outputFileName = None):
   	# If no checks are on, then can;t do anything here
   	if noCheckFlag:
		print('NOTE:  noChecks flag is on.  No tracking is enabled.')
		return

	nextLevelList = []
	#print 'showGroupTrackingData: scope/verbose = ' + scope + '/' + verbose
	# Output level data
	_str = '\nLevel: ' + str(level) + '\n'
	processDataToOutput(_str, outputFileName)
	
	# Go through all groups in the list
	for groupId in groupList:
	 # Output data
	 _str = 'Group  ' + groupId + \
		', number of marks = ' + str(len(groupTracking[groupId]['mark'])) + \
		', number of subs: ' + str(len(groupTracking[groupId]['externalId'])) + \
		', number of sub-groups: ' + str(len(groupTracking[groupId]['groupId'])) + \
		', number of parent groups: ' + str(len(groupTracking[groupId]['parentGroupId'])) + \
		', number offers: ' + str(len(groupTracking[groupId]['offerId']))
	 processDataToOutput(_str, outputFileName)
	 _str = 'marks: ' + str(groupTracking[groupId]['mark']) + \
		'\nSubs: ' + str(groupTracking[groupId]['externalId']) + \
		'\nSub-Groups: ' + str(groupTracking[groupId]['groupId']) + \
		'\nParent Groups: ' + str(groupTracking[groupId]['parentGroupId']) + \
		'\nOffers: ' + str(groupTracking[groupId]['offerId']) + '\n'
	 processDataToOutput(_str, outputFileName)
	
	 # Output sub data if any exist and we're in a verbose mode
	 if groupTracking[groupId]['externalId'] and verbose != 'none':
		showSubscriberTrackingData(groupTracking[groupId]['externalId'], scope = scope, verbose = verbose, outputFileName = outputFileName)
	 
	 # Build next level list in case we need it
	 if groupTracking[groupId]['groupId']:
	 	nextLevelList.extend(groupTracking[groupId]['groupId'])
	
	# If we're not in local scope, then we want to iterate through the next layer
	if scope != 'local' and nextLevelList:
		# Bump level
		level = str(int(level) + 1)
		showGroupTrackingData(nextLevelList, level, scope = scope, verbose = verbose, outputFileName = outputFileName)
	
#==========================================================
def updateTrackingData(action, groupId = None, subGroupId = None, externalId = None, deviceId = None, accessNumbers = None, offerId = None, mark=None, resourceId = None):
   	# If no checks are on, then can;t do anything here
   	if noCheckFlag:
		print('NOTE:  noChecks flag is on.  No tracking is enabled.')
		return

	if action == 'createGroup': 
	 # Track this group and create a holding place for future items
	 groupTracking['groupId'].append(groupId)
	 groupTracking[groupId] = {}
	 groupTracking[groupId]['externalId'] = []
	 groupTracking[groupId]['groupId'] = []
	 groupTracking[groupId]['parentGroupId'] = []
	 groupTracking[groupId]['offerId'] = []
	 groupTracking[groupId]['mark'] = []
	 groupTracking[groupId]['sessions'] = []
	 #print 'Tracking group data for ' + groupId
	
	 # Track mark if provided
	 if mark:
		groupTracking[mark] = groupId
		groupTracking[groupId]['mark'].append(mark)
		#print 'Storing group mark = "' + mark + '" = ' + groupId
	
	elif action == 'addSubscriberToGroup': 
	 # Assume subscriber has been created
	 groupTracking[groupId]['externalId'].append(externalId)
	 subscriberTracking[externalId]['parentGroupId'].append(groupId) 
	 #print 'Adding subscriber ' + externalId + ' to group ' + groupId
		
	elif action == 'removeSubscriberFromGroup': 
	 # Assume subscriber has been created
	 groupTracking[groupId]['externalId'].remove(externalId)
	 subscriberTracking[externalId]['parentGroupId'].remove(groupId) 
	 #print 'Remove subscriber ' + externalId + ' from group ' + groupId

	elif action == 'addSubGroupToGroup': 
	 # Assume groups have been created
	 groupTracking[groupId]['groupId'].append(subGroupId)
	 groupTracking[subGroupId]['parentGroupId'].append(groupId) 
	 #print 'Adding subgroup ' + subGroupId + ' to group ' + groupId

	elif action == 'removeSubGroupFromGroup': 
	 # Assume groups have been created
	 groupTracking[groupId]['groupId'].remove(subGroupId)
	 groupTracking[subGroupId]['parentGroupId'].remove(groupId) 
	 #print 'Adding subgroup ' + subGroupId + ' to group ' + groupId

	elif action == 'groupSubscribeToOffer':
	  # track this
	  groupTracking[groupId]['offerId'].extend(offerId)
	 
	elif action == 'groupUnsubscribeFromOffer':
	  # track this
	  if len(groupTracking[groupId]['offerId']) >= resourceId:
		groupTracking[groupId]['offerId'].pop(resourceId-1)
		groupTracking[groupId]['offerId'].append('Deleted')
	 
	elif action == 'createSubscriber': 
	 # Track this subscriber and create a holding place for future items
	 subscriberTracking['externalId'].append(externalId)
	 subscriberTracking[externalId] = {}
	 subscriberTracking[externalId]['parentGroupId'] = []
	 subscriberTracking[externalId]['deviceId'] = []
	 subscriberTracking[externalId]['offerId'] = []
	 subscriberTracking[externalId]['mark'] = []
	 subscriberTracking[externalId]['sessions'] = []
	
	 # Track mark if provided
	 if mark:
		subscriberTracking[mark] = externalId
		subscriberTracking[externalId]['mark'].append(mark)
		#print 'Storing subscriber mark = "' + mark + '" = ' + externalId
	
	elif action == 'addSubscriber':
	 print('Adding external ' + externalId + ' to subscriberTracking')
	 # Create this device
	 updateTrackingData('createSubscriber', externalId = externalId, mark = mark)
			
	 # Track offers if any were defined
	 if offerId:
	 	updateTrackingData('subscribeToOffer', externalId = externalId, offerId = offerId)
	 
	 # If a device was assigned here, then need to track it as well
	 if deviceId != '0' and deviceId != None:
	 	updateTrackingData('addDeviceToSubscriber', externalId = externalId, deviceId = deviceId, accessNumbers = accessNumbers)
		
	elif action == 'subscribeToOffer':
	  # track this
	  subscriberTracking[externalId]['offerId'].extend(offerId)
	 
	elif action == 'unsubscribeFromOffer':
	  # track this
	  if len(subscriberTracking[externalId]['offerId']) >= resourceId:
		subscriberTracking[externalId]['offerId'].pop(resourceId-1)
		subscriberTracking[externalId]['offerId'].append('Deleted')
	 
	elif action == 'createDevice':
 	 # Track this
  	 deviceTracking['deviceId'].append(deviceId)
	 deviceTracking[deviceId] = {}
	 deviceTracking[deviceId]['accessNumbers'] = []
	 deviceTracking[deviceId]['mark'] = []
	 deviceTracking[deviceId]['offerId'] = []
	 deviceTracking[deviceId]['sessions'] = []
	 deviceTracking[deviceId]['externalId'] = None
		
	 # Track mark if provided
	 if mark:
		deviceTracking[mark] = deviceId
	 	deviceTracking[deviceId]['mark'].append(mark)
		#print 'Storing device mark = "' + mark + '" = ' + deviceId
	
	 # Modify this device to update all other fields
	 updateTrackingData('modifyDevice', deviceId = deviceId, accessNumbers = accessNumbers)
		
	elif action == 'deleteDevice':
	 # Clean up access number tracking data
	 for aN in deviceTracking[deviceId]['accessNumbers']:
		# Remove access number
		accessNumberTracking['accessNumbers'].remove(aN)
		
		# Delete the access number entry
		del accessNumberTracking[aN]
			
 	 # Un-track this
  	 deviceTracking['deviceId'].remove(deviceId)
  	 del deviceTracking[deviceId]

	elif action == 'modifyDevice':
	 # Update if defined
	 if accessNumbers:
		# Clean up access number tracking data
	 	for aN in deviceTracking[deviceId]['accessNumbers']:
			accessNumberTracking['accessNumbers'].remove(aN)
			accessNumberTracking[aN] = {}
			
		# Clean the device of access numbers
	 	deviceTracking[deviceId]['accessNumbers'] = []
		
		# May be a list or a single entity
		accessNumToUse = []
		if type(accessNumbers) == type(list()):
			accessNumToUse = accessNumbers
		else:
			accessNumToUse.append(accessNumbers)
		
		for aN in accessNumToUse:
			deviceTracking[deviceId]['accessNumbers'].append(aN)
			accessNumberTracking['accessNumbers'].append(aN)
			accessNumberTracking[aN] = {}
			accessNumberTracking[aN]['deviceId'] = deviceId
			accessNumberTracking[aN]['sessions'] = []
				
	 		#print 'Adding access number ' + aN + ' to device ' + deviceId
	 
	elif action == 'removeDeviceFromSubscriber':
	 deviceTracking[deviceId]['externalId'] = None
	 subscriberTracking[externalId]['deviceId'].remove(deviceId) 

	elif action == 'addDeviceToSubscriber':
	 # Device may already be created.  Check first
	 if not deviceTracking['deviceId'].count(deviceId):
		# Change mark to be device specific if one was input
		newMark = mark
		if newMark:
			# Want mark from this call to reflect the device number within the subscriber
			_ext = '_D' + str(len(subscriberTracking[externalId]['deviceId']) - 1)
			newMark = mark+_ext
			
		# Create this device
		updateTrackingData('createDevice', deviceId = deviceId, accessNumbers = accessNumbers, mark = newMark)
		
	 # This makes the association between the device and subscriber, so track that 
	 deviceTracking[deviceId]['externalId'] = externalId
	 subscriberTracking[externalId]['deviceId'].append(deviceId) 
	 #print 'Adding device ' + deviceId + ' to subscriber ' + externalId
		
	elif action == 'devicePurchaseOffer':
		# Store this
		deviceTracking[deviceId]['offerId'].extend(offerId)
	
	elif action == 'deviceCancelOffer':
	  # track this
	  if len(deviceTracking[deviceId]['offerId']) >= resourceId:
		deviceTracking[deviceId]['offerId'].pop(resourceId-1)
		deviceTracking[deviceId]['offerId'].append('Deleted')
	
	return 

#==========================================================
def updateSessionTrackingData(deviceId, accessNumber, requestType, sessionId, ratingGroup, time, reqAmount, usedAmount, grantedAmount, mark=None, interface='gy', reportingReason='999', options=None):
   # If no checks are on, then can;t do anything here
   if noCheckFlag:
	print('NOTE:  noChecks flag is on.  No tracking is enabled.')
	return

   # Assume no creation/deletion required
   deleteFlag = False
   createFlag = False
	
   # Get sub-session ID
   subSession = str(sessionId) + '_' + str(ratingGroup)
	
   # Sanity check:  if not an initial and the session doe snot exist, then need to exit right away.
   # Covers case where tool is invoked in the middle of a session
#   if requestType == 'interim' and not sessionTracking.has_key(subSession):
#	print 'WARNING:  no session exists for session ' + subSession + ' and this is an interim message.  Not tracking this.
#	return
   
   # Check if a device was passed in (prioriy over access number)
   if deviceId != '0':
	# Chck if an init 
	if requestType == 'initial':
		# Make sure the session doesn't already exist.
		if deviceTracking[deviceId]['sessions'].count(subSession):
			print('WARNING:  Device ' + deviceId + ' already has an active session_RG combination of ' + subSession)
			#sys.exit('Done')
		else:
			# Set create flag to true
			createFlag = True
	
	elif requestType == 'interim':
		# Sub-sessions can come in as part of interim messages.
		if not deviceTracking[deviceId]['sessions'].count(subSession):
			#print 'Adding sub session ' + subSession + ' as part of interim message'
			# Set create flag to true
			createFlag = True
			
	# If a term and session doesn't exist, then create one
	elif requestType == 'term':
		# Set delete flag to true
		deleteFlag = True
		
		# See if we need to create this first (for logging purposes)
		if not deviceTracking[deviceId]['sessions'].count(subSession):
			# Set create flag to true
			createFlag = True
		
	# Check if we need to create
	if createFlag:
		# Add to the list of sessions
		deviceTracking[deviceId]['sessions'].append(subSession)
		externalId = deviceTracking[deviceId]['externalId']
		subscriberTracking[externalId]['sessions'].append(subSession)
		#print 'Adding session ' + subSession + ' to device ' + deviceId
	
	# Check if need to delete
	if deleteFlag:
		# Remove data
		deviceTracking[deviceId]['sessions'].remove(subSession)
		externalId = deviceTracking[deviceId]['externalId']
		subscriberTracking[externalId]['sessions'].remove(subSession)
		#print 'Removing session ' + subSession + ' from device ' + deviceId
	
   # Check if a access number was passed in
   elif accessNumber != '0':
	if requestType == 'initial':
		# Make sure the session doesn't already exist.
		if accessNumberTracking[accessNumber]['sessions'].count(subSession):
			print('WARNING:  Access Number ' + accessNumber + ' already has an active session_RG combination of ' + subSession)
			#sys.exit('Done')
		else:
			# Set create flag to true
			createFlag = True
	
	elif requestType == 'interim':
		# Sub-sessions can come in as part of interim messages.
		if not accessNumberTracking[accessNumber]['sessions'].count(subSession):
			#print 'Adding sub session ' + subSession + ' as part of interim message'
			# Set create flag to true
			createFlag = True
			
	# If a term and session doesn't exist, then create one
	elif requestType == 'term':
		# Set delete flag to true
		deleteFlag = True
		
		# See if we need to create this first (for logging purposes)
		if not accessNumberTracking[accessNumber]['sessions'].count(subSession):
			# Set create flag to true
			createFlag = True
		
	# Check if we need to create
	if createFlag:
		# Add to the list of sessions
		accessNumberTracking[accessNumber]['sessions'].append(subSession)
		deviceId = accessNumberTracking[accessNumber]['deviceId']
		externalId = deviceTracking[deviceId]['externalId']
		subscriberTracking[externalId]['sessions'].append(subSession)
#		print 'Adding session ' + subSession + ' to accessNumber ' + accessNumber
	
	# Check if need to delete
	if deleteFlag:
		# Remove data
		accessNumberTracking[accessNumber]['sessions'].remove(subSession)
		deviceId = accessNumberTracking[accessNumber]['deviceId']
		externalId = deviceTracking[deviceId]['externalId']
		subscriberTracking[externalId]['sessions'].remove(subSession)
   
   #### Now process session data itself (independent o access number, device, or subscriber data
   # Check if we need to create
   if createFlag:
	# Create session data
	sessionTracking['sessions'].append(subSession)
	sessionTracking[subSession] = {}
	sessionTracking[subSession]['id'] = subSession
	sessionTracking[subSession]['externalId'] = externalId
	sessionTracking[subSession]['deviceId'] = deviceId
	sessionTracking[subSession]['accessNumber'] = accessNumber
	sessionTracking[subSession]['startTime'] = time
	sessionTracking[subSession]['endTime'] = None
	sessionTracking[subSession]['eventCount'] = 0
	sessionTracking[subSession]['events'] = []
	sessionTracking[subSession]['interface'] = interface.lower()
	sessionTracking[subSession]['interface'] = interface.lower()
	
	# Fields differ between interfaces
	if interface.lower() == 'gy':
		sessionTracking[subSession]['TotalUsed'] = 0
		sessionTracking[subSession]['TotalRequested'] = 0
		sessionTracking[subSession]['TotalGranted'] = 0
		sessionTracking[subSession]['lastGrant'] = 0
	
	# If mark passed in, then check for an existing mark
	if mark:
		if mark in sessionTracking: print('WARNING:  duplicate session mark specified (' + mark + ').  Ignoring duplicate.')
		else:
			# Store mark data
			sessionTracking[mark] = subSession
			sessionTracking[subSession]['mark'] = mark
			
#	print 'Adding session ' + subSession + ' data'
		
   # Update session data if key exists (cover case where tool invoked with just an event to an existing session)
   if subSession in sessionTracking:
	# Debug data
#	print 'Updating session ' + subSession + ' data'
   	sessionTracking[subSession]['eventCount'] += 1
	if interface.lower() == 'gy':
		sessionTracking[subSession]['events'].append([(int(usedAmount), int(reqAmount), int(grantedAmount))])
		sessionTracking[subSession]['lastGrant'] = grantedAmount
		sessionTracking[subSession]['TotalUsed'] += int(usedAmount)
		sessionTracking[subSession]['TotalRequested'] += int(reqAmount)
		sessionTracking[subSession]['TotalGranted'] += int(grantedAmount)
	else:
		# Need to add Sy data here.  Policy values put into the reqAmount parameter.
		# Not all calls do this yet...
		if type(reqAmount) is list: sessionTracking[subSession]['events'].extend(reqAmount)
		else: sessionTracking[subSession]['events'].append('None')

   else:
	# really shouldn't be here...
	print('WARNING:  received a session ' + requestType + ' message for deviceId/accessNumber ' + str(deviceId) + '/' + str(accessNumber) + ' but did not have anyhing recorded for it...')
	
   # Check if need to delete
   if deleteFlag:
	# Update end time
	sessionTracking[subSession]['endTime'] = time
		
	# Log session data
	if options and options.debug: sessionLogData(subSession, sessionTracking[subSession])
		
	# Remove mark if defined
	if 'mark' in sessionTracking[subSession]: del sessionTracking[sessionTracking[subSession]['mark']]
		
	# Remove session data
	sessionTracking['sessions'].remove(subSession)
	del sessionTracking[subSession]
   
   return 

#==========================================================
def sessionLogData(subSession, sessionData, outputFileName = None):
   print('\nSession ' + subSession + ' data:')
   print(str(sessionData) + '\n')
      
   return 

#===============================================================================
def initTrackingData(options):
    global filterFlag
    
    deviceId = []
    accessNumbers = []
    
    # Create tracking data for generic subscriber
    updateTrackingData('createSubscriber', externalId = subExternalId)
    
    # If entered no device and only an acess number, then we have a problem...
    if not options.deviceId and options.accessNumbers:
        print('ERROR:  Tool can not filter only on access number.  Need to associate it with a device Id.')
        sys.exit('Error')

    # If no devices entered, then done
    if not options.deviceId: return
    
    # May enter multiple device  and access numbers
    deviceId = options.deviceId.split('@')
    
    # Also may not enter any IMSI, in which case set equal to the MSISDN
    if not options.accessNumbers: accessNumbers.extend(deviceId)
    else: accessNumbers = options.accessNumbers.split('@')
    
    # Make sure the lengths are equal
    if len(deviceId) != len(accessNumbers):
	print('ERROR:  Need to enter the same number of MSISDN and IMSI')
	sys.exit('ERROR')
    
    # Process each set of MSISDN/IMSI
    for index in range(len(deviceId)):
    	# Add subscribers data
	updateTrackingData('addSubscriber', externalId = subExternalId, deviceId = deviceId[index], accessNumbers = accessNumbers[index])
    
    # Set filter flag, as input means we only want to see these items
    filterFlag = True
    
#===============================================================================
# This fnction used to run bash scripts.
def runCmd(cmd, output='delayed'):
    #print "running command: \"" + cmd + "\""
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    out = p.stdout.read().strip()
    return out  #This is the stdout from the shell command

#===============================================================================
# This function processes command line inputs
def cmdLineInput():
    global ReprocessFlag
    
    ########### Do command line processing ###################
    parser = optparse.OptionParser()
    parser.add_option("-f", "--inputFile", action='store', type='string', default=None, help='List of debug log files to process (on local server)')
    parser.add_option("",   "--dirName",   action='store', type='string', default=None, help='Directory where debug log files reside (on local server)')
    
    parser.add_option("-i", "--ip",        action='store', type='string', default=None, help='IP address of any blade in engine, to retrieve create_config.info file')
    parser.add_option("-e", "--engine",    action='store', type='int',    default=None, help='Engine designation in create_config.info (starts with 1)')
    parser.add_option("-c", "--cluster",   action='store', type='int',    default=None, help='Cluster designation in create_config.info (starts with 1)')
    parser.add_option("-b", "--blade",     action='store', type='int',    default=None, help='Blade within a cluster (starts with 1)')
    parser.add_option("",   "--fqn", 	   action='store', type='string', default=None, help='engine:cluster:blade nomnclature')
    
    parser.add_option("",   "--dict",      action='store', type='string', default='/opt/mtx/conf/diameter_dictionary.xml', help='full path to diameter dictionary (including file name)')
    parser.add_option("",   "--deviceId",  action='store', type='string', default=None, help="MSISDN to filter output on")
    parser.add_option("-a", "--accessNumbers", action='store', type='string', default=None, help="IMSI to filter output on")
    
    parser.add_option("",   "--useSystemTime", action='store_true', default=False, help="Flag signaliing whether to use system time versus event time in CCR")
    
    parser.add_option("-d", "--debug",     action='store', type='string', default=None, help='Debug level, 0-9')
    parser.add_option("-t", "--time",     action='store', type='int', default=0, help='Time between queries')
    parser.add_option("",   "--skip",      action='store', type='string', default='', help='Messages to not output')
    parser.add_option("",   "--noChecks",  action='store_true', default=False, help="Don't assume all sessions known by the tool")
    parser.add_option("",   "--localIpAddresses",   action='store', type='string', default=None, help='INTERNAL USE')
        
    #parser.add_option("", "--date", action='store', type='string', default=None)
    #parser.add_option("-s", "--site", action='store', type='string', default=None, help='Site designation in create_config.info (e.g. Primary, Secondary, Main)')

    # Process command line params
    (options, args) = parser.parse_args()

    # PRIORITIZE INPUTS
    # If directory name passed in, that's what we'll use
    if options.dirName:
	# This takes priority
	options.ip = options.engine = options.cluster = options.blade = None
	
        # Setup to be a list
        options.inputFile = []

	# Do not reprocess for directory files
	ReprocessFlag = False
	
    elif options.inputFile:
	# This takes priority
	options.ip = options.engine = options.cluster = options.blade = None
	
	# Split multiple files into a list
	options.inputFile = options.inputFile.split(',')
	
	# Do not reprocess for input files
	ReprocessFlag = False
	
        # Debug output
        print('File list to process from input file list: ' + str(options.inputFile))
	
    else:
	# If no IP specified, then use localhost
	if not options.ip:
		print('Note: No IP address input. Will use localhost.')
		options.ip = 'localhost'
	
	# Check if fqn specified
	if options.fqn:
		# OK, see how much of this was specified
		items = options.fqn.split(':')
		if len(items) > 3:
			print('ERROR:  fqn input must be at most engine:cluster:blade.  Invalid input found: ' + options.fqn)
			sys.exit('ERROR')
		elif len(items) == 3:
			# Specified all the items
			options.engine = items[0]
			options.cluster = items[1]
			options.blade = items[2]
		elif len(items) == 2:
			# Specified engine/cluster items
			options.engine = items[0]
			options.cluster = items[1]
			options.blade = None
		elif len(items) == 1:
			# Specified engine/cluster items
			options.engine = items[0]
			options.cluster = 1
			options.blade = None
	
	# See about engine/cluster/blade designations
	elif not options.engine:
		print('Note: No engine data specified.  Will use 1:1:all')
		options.engine = 1
		options.cluster = 1
		options.blade = None
	elif not options.cluster:
		print('Note: No cluster data specified.  Will use cluster 1, all blades.')
		options.cluster = 1
		options.blade = None
	elif not options.blade:
		print('Note: No blade data specified.  Will use all blades.')

    # If user wants everything, they set skip to "none"
    if options.skip.lower() == 'none': options.skip = None
    
    # Having issues with some times not stamped and other stamped (since not all diameter events report event time and
    # the debug log time stamp does;t contain any time zone information).  For now always use system time (safe as long as PROC blades are using NTP).
    print('Note: Using debug message time versus Diameter event time')
    options.useSystemTime = True
    
    # If no date specified, default to today
#    if not options.date:
#        date = datetime.now()
#        options.date = str(date.year) + '-' + str(date.month).zfill(2) + '-' + str(date.day).zfill(2) + 'T00:00:00'
#        print 'No date entered.  Using today\'s date (midnight): ' + options.date
   
    # Store all local IP addresses
    options.localIpAddresses = ['localhost']
    options.localIpAddresses.extend(GENERIC.runCmd('ifconfig | grep "inet addr" | cut -f2 -d":" | cut -f1 -d" "').split('\n'))
    print('Local IPs: ' + str(options.localIpAddresses))
    
    return options

#===============================================================================
def processInputFiles(options, groupedAVPs):
    global FileWhereEventCameFrom
    global FileLineCount
    
    # Get files to process
    filenames = options.inputFile
    
    # Debug output
    #print 'Processing files: = ' + str(filenames)
    
    # Define structure to handle messages
    diamData = {}
    dctRcvd = {}
    eventTimes = []
    fileInformation = {}
    
    # Dummy variable
    x = 0
    index = 0
	
    # Translate all files to array of messages
    for file in filenames:
	# Sometimes commands leave a blank in the array...
	if not file: continue
	
	# Define the index we need
	diamData[str(index)] = []
		
	# Get current line count of the file
	lineCount = runCmd('wc -l ' + file + ' | cut -f1 -d" "')
	
	# Debug output
	#print 'Current line count for file ' + file + ' = ' + str(lineCount)
	
	# If we have an entry for this file, then we may need to skip lines
	if str(index) in FileLineCount:
		# Delete lines from the file that were already processed
		runCmd('sed -i "1,' + FileLineCount[str(index)] + 'd" ' + file)
	
		# Debug output
		#print 'Removed previous ' + FileLineCount[str(index)] + ' from file ' + file
	
	# Update new line count
	FileLineCount[str(index)] = str(lineCount)
		
	# Debug output
	#print 'Processing file: ' + file
		
	# Convert the data
    	(diamData[str(index)], msgCount) = processDebugLogFile(file)
    
        # It's possible that nothing was returned.  In that case don't add anything to the list.
	# Only process further if something returned.
        if msgCount != 0:
		# Something found in the file...
		fileInformation[file] = str(msgCount)
		
#		print 'Processing file ' + file + ': ' + str(msgCount) + ' diameter messages found in this file.'
	
		# Get the index we'll use
		fileIndex = 'file'+str(index)
		
		# Get the dictionary for this entry
		dctRcvd[fileIndex] = getRawDiameterDct(diamData[str(index)][0], groupedAVPs)
	else:
		# Nothing found in the file...
		kef = 1
#		print 'NOTE: No diameter messages found in file ' + file
	
	# Bump the index
	index += 1
		
    # See if anything found
    if not options.time:
	    if len(fileInformation):
		# Print each file
		print('Events found per file:')
		pprint.pprint(fileInformation)
	    else:
		print('No events found in this iteration')
		return
    
    # There's an issue when retrieving files from multiple systems.  If an event doesn't include an event time we use the reported system time.
    # The system time will not show a time zone.  Thus time comparisons don't work since we don't really know the system time zone.
    # If data in more than one file then force the system time option to be true so evey event uses the debug message timestamp (which is always present).
    # The tool should probably always use this...
    if len(dctRcvd) > 1:
	print('Note: Using debug message time versus Diameter event time since processing debug files from multiple servers')
	options.useSystemTime = True
    
    # Set start time to way in the future (so any event will be below it)
    startTime = '3000-01-01T00:00:00.000000'
	
    # Loop while there are events to process
    while True:
	# Set index to an invalid value (so we can check if nothing found)
	foundIndex = -1
	
	# Get the earliest event from each file
	for idx in range(index):
		# Get the index we'll use
		fileIndex = 'file'+str(idx)
		
		# If this file is empty, then skip
		if fileIndex not in dctRcvd: continue
		
		# If we're supposed to use system time, then grab it if defined
		if options.useSystemTime: eventTime = dctRcvd[fileIndex]['Event-Timestamp'] = dctRcvd[fileIndex]['System-Time']

		# Pull time stamp from message if it exists
		elif 'Event-Timestamp' in dctRcvd[fileIndex]: 
			# Sometimes this field is output with a "not valid" string...
			if "not valid" in dctRcvd[fileIndex]['Event-Timestamp']: eventTime = dctRcvd[fileIndex]['System-Time']
                        else:
				# Seems somtimes I put the system time into the event time.  Ugh...  Use try/except to account for that.
                                try:
                                	eventTime = dctRcvd[fileIndex]['Event-Timestamp'].split('(')[1].split(')')[0]
                                except:
                                        eventTime = dctRcvd[fileIndex]['Event-Timestamp']
			
		# Pull time from system time key
		else: eventTime = dctRcvd[fileIndex]['Event-Timestamp'] = dctRcvd[fileIndex]['System-Time']
		
		# If here, we found something
		foundIndex = idx
		
		# Debug output
#		print 'File ' + str(idx) + ' has event time: ' + eventTime + ' with current start time ' + str(startTime) + ' and system time ' + str(dctRcvd[fileIndex]['System-Time'])
		
		# Debug.  If event time not found, then print th edictionary
		if not eventTime.strip(): pprint.pprint(dctRcvd['file'+str(foundIndex)])
		
		# See if the event is less than the current start time
#		if eventTime < startTime:
		if GENERIC.checkIfTime2GreaterOrEqualTime1(eventTime, startTime):
			# Record data for the earlier event
			startTime = eventTime
		elif eventTime == startTime and \
		     dctRcvd['file'+str(foundIndex)]['Cmd'] == 'Credit-Control(272)' and \
		     dctRcvd['file'+str(idx)]['Cmd'] == 'Credit-Control(272)':
			print('Found CCR events at same time.  Request numbers  are: ' + dctRcvd['file'+str(idx)]['CC-Request-Number'] + ' and ' + dctRcvd['file'+str(foundIndex)]['CC-Request-Number'])
			# Session start and interim can have the same timestamp, as they can come in the same second.
			# Want prioity to the lower numbered request number.
			if int(dctRcvd['file'+str(idx)]['CC-Request-Number']) < int(dctRcvd['file'+str(foundIndex)]['CC-Request-Number']): 
				# Record data for the earlier event
				foundIndex = idx
				startTime = eventTime
		
	# If the index is -1, then we're done processing events
	if foundIndex == -1: break
	
	# Set global
	FileWhereEventCameFrom = foundIndex
	
	# Debug output
	#print 'Taking event from file ' + str(foundIndex+1) + ', time = ' + startTime
	
	# Use the index that has the eariest event time.
	# Get file index, using index found
	fileIndex = 'file'+str(foundIndex)
	
	# Sanity check the message
	if 'Cmd' in dctRcvd[fileIndex]: 
		# Debug output
		#print 'Diameter command: ' + dctRcvd[fileIndex]['Cmd']
		x = 1
	else: 
		# Debug output
		print("WARNING:  no Cmd element found in the diameter packet:\n" + str(dctRcvd[fileIndex]))
			
		# Nothing else to do with this...
		continue
		
	# Process each diameter message separately
	# Gy messages
	if   dctRcvd[fileIndex]['Cmd'] == 'Credit-Control(272)':	processCCRandCCA(options, dctRcvd[fileIndex])
	elif dctRcvd[fileIndex]['Cmd'] == 'Device-Watchdog(280)': 	processDWRandDWA(options, dctRcvd[fileIndex])
	elif dctRcvd[fileIndex]['Cmd'] == 'MtxSocketDiamMsg(430)': 	processSock(options, dctRcvd[fileIndex])
	elif dctRcvd[fileIndex]['Cmd'] == 'Disconnect-Peer(282)': 	processDPRandDPA(options, dctRcvd[fileIndex])
	elif dctRcvd[fileIndex]['Cmd'] == 'Capabilities-Exchange(257)': processCERandCEA(options, dctRcvd[fileIndex])
	elif dctRcvd[fileIndex]['Cmd'].startswith('Re-Auth'): 		processRARandRAA(options, dctRcvd[fileIndex])
	elif dctRcvd[fileIndex]['Cmd'].startswith('Spending-Limit'): 	processSLRandSLA(options, dctRcvd[fileIndex])
	elif dctRcvd[fileIndex]['Cmd'].startswith('Session-Terminate'): processSTRandSTA(options, dctRcvd[fileIndex])
	elif dctRcvd[fileIndex]['Cmd'].startswith('Spending-Status-Notification'): processSNRandSNA(options, dctRcvd[fileIndex])
	
	# Gx messages
	elif dctRcvd[fileIndex]['Cmd'].startswith('RA'): 		processRARandRAA(options, dctRcvd[fileIndex], interface='Gx')
	elif dctRcvd[fileIndex]['Cmd'].startswith('CC'):		processCCRandCCA(options, dctRcvd[fileIndex], interface='Gx')
	
	# Hmmm.  Nothing defined to decode this
	else: print('WARNING:  no Cmd processing function found for command ' + dctRcvd[fileIndex]['Cmd'] + ', message: ' + str(dctRcvd[fileIndex]))
	
	# Remove the entry from the overall diameter data
	if len(diamData[str(foundIndex)]) > 1:
		# Remove initial entry
		diamData[str(foundIndex)] = diamData[str(foundIndex)][1:]
		
		# Get the next dictionary for this entry
		dctRcvd[fileIndex] = getRawDiameterDct(diamData[str(foundIndex)][0], groupedAVPs)
	else:
		# Empty data item
		diamData[str(foundIndex)] = []
		
		# delete dictionary entry
		del dctRcvd[fileIndex]
	
    # Debug output
#    print '\nDone Processing files\n'
    
#===============================================================================
def outputData(options, cmd='', sessionId='', deviceId='', accessNumbers='', originHost='', originRealm='', \
	       time='', diamResult='', msccResult='', reqType='', reqNum='', misc='', index=0):
	global FileWhereEventCameFrom
	global formatStr
	global outputHeaderFlag
	
	# Going to output something.
	if not outputHeaderFlag:
    		# Output headers
		outputDataHdr();
    		
		# Set flag
		outputHeaderFlag = True
		
	# Use IMSI if present, else use MSISDN
	if   deviceId:	    id = deviceId + '(M)'
	elif accessNumbers: id = accessNumbers + '(I)'
	else:		    id = ''
	
	# Don't show a mscc result of 0 (as it's N/A)
	if msccResult == '0': msccResult = ''
	
	# Use same format as for the headers
	if index == 0:
		# First message in an event.  Output everything.
		sys.stdout.write("%-10s %-20s %-6s %-6s %-7s %-4s %-50s %-27s %-s \n" % \
			(cmd+'('+str(FileWhereEventCameFrom+1)+')', id, diamResult, msccResult, reqType, reqNum, sessionId, time, misc))
	else:
		# multiple MSCC in a single event.  Don't output items that are repeated.
		sys.stdout.write("%-10s %-20s %-6s %-6s %-7s %-4s %-50s %-27s %-s \n" % \
			(' ', ' ', ' ', msccResult, ' ', ' ', sessionId, ' ', misc))
	
#===============================================================================
def outputDataHdr():
	global formatStr
	
	# Setup fixed width fields
	sys.stdout.write("\n%-10s %-20s %-6s %-6s %-7s %-4s %-50s %-27s %-s \n" % ('', '', 'Diam', 'MSCC', 'Req', 'Req', '', '', ''))
	#sys.stdout.write("\n"+formatStr+" \n" % ('Command', 'Sub ID', 'Result', 'Result', 'Type', 'Num', 'Session ID', 'Time', 'Misc'))
	sys.stdout.write("%-10s %-20s %-6s %-6s %-7s %-4s %-50s %-27s %-s \n" % ('Command', 'Sub ID', 'Result', 'Result', 'Type', 'Num', 'Session ID', 'Time', 'Misc'))
	line = '-'*145
	print(line)
    
#===============================================================================
def getDiamUnitData(dctRcvd, msccName, type):
	# Set full type name
	prefix = msccName + '->' + type + '-Service-Unit->'
	if prefix+ 'CC-Total-Octets' in dctRcvd: 
		# Set service type
		serviceType = 'D'
		units = dctRcvd[prefix+'CC-Total-Octets']
	elif prefix+'CC-Time' in dctRcvd: 
		# Set service type
		serviceType = 'V'
		units = dctRcvd[prefix+'CC-Time']
	elif prefix+'CC-Service-Specific-Units' in dctRcvd: 
		# Set service type
		serviceType = 'U'
		units = dctRcvd[prefix+'CC-Service-Specific-Units']
	elif prefix+'CC-Money' in dctRcvd: 
		# Set service type
		serviceType = '$'
		units = dctRcvd[prefix+'CC-Money']
	elif prefix+'CC-Input-Octets' in dctRcvd or prefix+'CC-Output-Octets' in dctRcvd:
		# Set service type
		serviceType = 'D'
		
		# Want to sum these values
		units = 0
		if prefix+'CC-Input-Octets' in dctRcvd: units += int(dctRcvd[prefix+'CC-Input-Octets'])
		if prefix+'CC-Output-Octets' in dctRcvd: units += int(dctRcvd[prefix+'CC-Output-Octets'])
		requestUnits = str(requestUnits)
	else: 
		units = '0'
		serviceType = '0'
		
	return (serviceType, units)

#===============================================================================
def getDiamMsccData(i, dctRcvd):
	# Get MSCC structure index
	msccName = 'Mscc' + str(i)
	
	# If there is no rating group present, then return none
	if msccName+'->Rating-Group' not in dctRcvd: return None
	
	# Get xSU info
	(requestedServiceType, requestedUnits) = getDiamUnitData(dctRcvd, msccName, 'Requested')
	(usedServiceType, usedUnits) = getDiamUnitData(dctRcvd, msccName, 'Used')
	(grantedServiceType, grantedUnits) = getDiamUnitData(dctRcvd, msccName, 'Granted')
	
	# Get other key fields in the MSCC structure
	if msccName+'->Reporting-Reason' in dctRcvd: reportingReason = dctRcvd[msccName+'->Reporting-Reason']
	else: reportingReason = '999'
		
	if msccName+'->Rating-Group' in dctRcvd: ratingGroup = dctRcvd[msccName+'->Rating-Group']
	else: ratingGroup = noRatingGroup
	
	if msccName+'->Result-Code' in dctRcvd: msccResult = dctRcvd[msccName+'->Result-Code']
	else: msccResult = '0'
		
	if msccName+'->Final-Unit-Indication->Final-Unit-Action' in dctRcvd:  fuiFlag = True
	else:									    fuiFlag = False
	
	retData = ((requestedServiceType, requestedUnits, usedServiceType, usedUnits, grantedServiceType, grantedUnits, reportingReason, ratingGroup, msccResult, fuiFlag))
	return retData
	
#===============================================================================
def processCCRandCCA(options, dctRcvd, interface='Gy'):
    global filterFlag
    global ccrStats
    global FileWhereEventCameFrom
    
    reportingReasonMapping = {}
    reportingReasonMapping['0'] = 'threshold'
    reportingReasonMapping['1'] = 'qht'
    reportingReasonMapping['2'] = 'final'
    reportingReasonMapping['3'] = 'quota'
    reportingReasonMapping['4'] = 'time'
    reportingReasonMapping['5'] = 'other'
    reportingReasonMapping['6'] = 'condition'
    reportingReasonMapping['7'] = 'forced'
    reportingReasonMapping['8'] = 'pool'

    # Locals
    deviceId = accessNumbers = None
    deviceIDInput = accessNumbersInput = False
    externalId = subExternalId
    misc = ''
    
    # See if we should skip this message
    if options.skip.upper().count('CCR') or options.skip.upper().count('CCA'): return
    
    # Get key pieces of data
    if 'Session-Id' in dctRcvd: sessionId = dctRcvd['Session-Id']
    else:			sessionId = "None"
    
    # Account for failure tests (not allfields are present)
    if 'CC-Request-Type' in dctRcvd: requestType = dctRcvd['CC-Request-Type']
    else: requestType = '0'
    if 'CC-Request-Number' in dctRcvd: requestNumber = dctRcvd['CC-Request-Number']
    else: requestNumber = '0'
    
    systemTime = dctRcvd['System-Time']
    serviceType = ''
    
    # Do Request-specific work first
    if dctRcvd['CmdReq'] == '1':
	# Debug output
	#print 'Process CCR'
	
    	# Debug output
	#print 'Received Diameter dictionary: '
    	#print str(dctRcvd)
    
	# Get the IMSI and MSISDN.  May have one or two Subscrption structures
	if 'Subscription-Id0->Subscription-Id-Type' in dctRcvd:
		# Type says what kind of item it is
		if dctRcvd['Subscription-Id0->Subscription-Id-Type'] == subIdMSISDNType:
			deviceId = dctRcvd['Subscription-Id0->Subscription-Id-Data']
			deviceIDInput = True
		else:   
			accessNumbers = dctRcvd['Subscription-Id0->Subscription-Id-Data']
			accessNumbersInput = True
		
		#print 'deviceId and aN post Sub0 data: ' + str(deviceId) + ', ' + str(accessNumbers)
	else:
		# Need at least one of these
		print('ERROR: CCR Dictionary does not have any Subscription-Id grouped AVPs')
		pprint.pprint(dctRcvd)
		return
	
	# Second one is optional
	if 'Subscription-Id1->Subscription-Id-Type' in dctRcvd:
		# Type says what kind of item it is
		if dctRcvd['Subscription-Id1->Subscription-Id-Type'] == subIdMSISDNType:
			deviceId = dctRcvd['Subscription-Id1->Subscription-Id-Data']
			deviceIDInput = True
		else:   
			accessNumbers = dctRcvd['Subscription-Id1->Subscription-Id-Data']
			accessNumbersInput = True

	# Debug output
	#print 'deviceId and aN post Sub1 data: ' + str(deviceId) + ', ' + str(accessNumbers)

	# Want to make sure the data is tracked in subscriber/device/accessNumber structures.  Create them if needed (since we may only get debug log files).
	# If only IMSI entered, then need to find device ID
	if accessNumbers and not deviceId:
		# Got IMSI only.  Need to see if we have this.  Work backwards from the IMSI to the device
		if accessNumbers in accessNumberTracking: deviceId = accessNumberTracking[accessNumbers]['deviceId']
			
	# At this point, if no device found yet, then make one up
	if not deviceId: deviceId = subExternalId
	
	# If no device currently stored and filtering, then return
	if deviceId not in deviceTracking and filterFlag: return
	
	# Check if the device has not already been added to the subscriber
	if not subscriberTracking[externalId]['deviceId'].count(deviceId):
                # Add device to subscriber
       	        updateTrackingData('addDeviceToSubscriber', externalId = externalId, deviceId = deviceId, accessNumbers = accessNumbers)
			
	# Get optional pieces of data.  It may be in full format (if present) or partial (if we added it).
	# Try both (one should work...).
	try:
		eventTime = dctRcvd['Event-Timestamp'].split('(')[1].split(')')[0]
	except:
		eventTime = dctRcvd['Event-Timestamp']
	
	# Get per MSCC information (as there could be several per Diameter event)
	msccData = []
	for i in range(10):
		msccSingleData = getDiamMsccData(i, dctRcvd)
		
		# If None returned:
		if not msccSingleData: 
			# Skip if beyond the first entry
			if i > 0: break
			else:
				# Setup defaults, as we want to track the dummy session open
				requestedServiceType = usedServiceType = '0'
				usedUnits = requestedUnits = '0'
				ratingGroup = noRatingGroup
				reportingReason = '999'
		else:
			# Store data into array
			msccData.append(msccSingleData)
	 	
			# Extract returned data
			requestedServiceType = msccSingleData[0]
			requestedUnits = msccSingleData[1]
			usedServiceType = msccSingleData[2]
			usedUnits = msccSingleData[3]
			reportingReason = msccSingleData[6]
			ratingGroup = msccSingleData[7]
		
		# May get multiple CCRs for different rating groups before we get a CCA, so address that
		overallSessionId = sessionId + '_' + ratingGroup + '_' + str(requestNumber)
	
		# Sanity check that we don't have this session already saved...
		if overallSessionId in ccrStats:
			# Check if duplicate set
			if dctRcvd['CmdReXmit'] == '1':
				# Duplicate message received
				print('NOTE: duplicate CCR received for overall session ID: ' + overallSessionId)
			
				# Return here - keep original data
				return
			else:
				# Unexpected message received.  Might be a higher numbered request.
				if int(requestNumber) > int(ccrStats[overallSessionId]['requestNumber']):
					# We got a subsequent higher numbered request...
					print('WARNING: Received a CCR that has a higher numbered request number (' + str(requestNumber) + ') than the previous outstanding CCR (' + str(ccrStats[overallSessionId]['requestNumber']) + ')')
				else:
					# Not sure what's going on here...
					print('ERROR:  CCR received from file ' + str(FileWhereEventCameFrom+1) + '.  ccrStats has an existing key = ' + overallSessionId)
					print(str(ccrStats[overallSessionId]))
					print(str(dctRcvd))
					return
		
		# Set the service type.
		if requestedServiceType != '0': serviceType = requestedServiceType
		else:				serviceType = usedServiceType
		
		# Save this data in the structure for processing when we get the CCA
		ccrStats[overallSessionId] = {}
		ccrStats[overallSessionId]['requestNumber'] = requestNumber
		ccrStats[overallSessionId]['eventTime'] = eventTime
		ccrStats[overallSessionId]['ratingGroup'] = ratingGroup
		ccrStats[overallSessionId]['sessionId'] = sessionId
		ccrStats[overallSessionId]['deviceId'] = deviceId
		ccrStats[overallSessionId]['accessNumbers'] = accessNumbers
		ccrStats[overallSessionId]['externalId'] = externalId
		ccrStats[overallSessionId]['requestUnits'] = requestedUnits
		ccrStats[overallSessionId]['usedUnits'] = usedUnits
		ccrStats[overallSessionId]['Origin-Host'] = dctRcvd['Origin-Host']
		ccrStats[overallSessionId]['Origin-Realm'] = dctRcvd['Origin-Realm']
		ccrStats[overallSessionId]['FileWhereEventCameFrom'] = FileWhereEventCameFrom+1
		ccrStats[overallSessionId]['systemTime'] = systemTime
		ccrStats[overallSessionId]['reportingReason'] = reportingReason
		ccrStats[overallSessionId]['serviceType'] = serviceType
	
		# Request type needs to be stored as string, not a number
		if requestType == '1':   ccrStats[overallSessionId]['requestType'] = 'initial'
		elif requestType == '2': ccrStats[overallSessionId]['requestType'] = 'interim'
		else:   		 ccrStats[overallSessionId]['requestType'] = 'term'
	
		# Debug output
		#print 'Received CCR from blade ' + str(FileWhereEventCameFrom+1) + ' with session ID ' + overallSessionId
	
    else:
	# Debug output
	'''
	print 'Process CCA'
	print 'Received Diameter dictionary: '
    	pprint.pprint(dctRcvd)
	'''
    
	# Get key pieces of data
    	if 'Session-Id' in dctRcvd: sessionId = dctRcvd['Session-Id']
    	else:			sessionId = "None"
	
	# Get specific data
	diamResult = getResultCode('CCA', dctRcvd)
	
	# Get per MSCC information (as there could be several per Diameter event)
	msccData = []
	for i in range(10):
		msccSingleData = getDiamMsccData(i, dctRcvd)
		
		# If None returned:
		if not msccSingleData: 
			# Skip if beyond the first entry
			if i > 0: break
			else:
				# Setup defaults, as we want to track the dummy session open
				grantedServiceType = '0'
				grantedUnits = '0'
				ratingGroup = noRatingGroup
				reportingReason = '999'
				fuiFlag = False
				msccResult = '0'
		else:
			# Store data into array
			msccData.append(msccSingleData)
	 	
			# Extract returned data
			grantedServiceType = msccSingleData[4]
			grantedUnits = msccSingleData[5]
			ratingGroup = msccSingleData[7]
			msccResult = msccSingleData[8]
			fuiFlag = msccSingleData[9]
		
		# May get multiple CCRs for different rating groups before we get a CCA, so address that
		overallSessionId = sessionId + '_' + ratingGroup + '_' + str(requestNumber)
	
		# Make sure the session exists in the stats data
		if overallSessionId not in ccrStats: 
			# If filtering enabled, then this shoudlbe fine
			if filterFlag: return
			else:
				# Hmmmm.....
				print('WARNING:  CCA received with session ' + str(overallSessionId) + ' and but no CCR encountered. Dropping this.')
				return
		
		# Sanity check that the request number received maps to the one stored...
		if int(requestNumber) != int(ccrStats[overallSessionId]['requestNumber']):
			# Not sure what to do here...
			print('WARNING:  received a CCA for session ' + overallSessionId + ' request number ' + requestNumber + ' but the currently stored request number for this session is ' + ccrStats[overallSessionId]['requestNumber'])
		
		# May need to grab what was previous stored in ccrStats for the service type if nothing granted
		if grantedServiceType != '0': serviceType = grantedServiceType
		else:			      serviceType = ccrStats[overallSessionId]['serviceType']
	
		# Need to address sub-sessions that close when a reporting reason comes through...
		reportingReason = ccrStats[overallSessionId]['reportingReason']
	
		misc = 'U/R/G Units(' + serviceType + ') = ' + ccrStats[overallSessionId]['usedUnits'] + '/' + ccrStats[overallSessionId]['requestUnits'] + '/' + grantedUnits
		
		# Output RR name
		if reportingReason != '999': 
			try:
				misc += ', RR = ' + reportingReasonMapping[str(reportingReason)] + '(' + str(reportingReason) + ')'
			except:
				misc += ', RR = unknown value(' + str(reportingReason) + ')'
		
		if fuiFlag: misc += ', FUI returned'
	
		# Set session ID
		if ratingGroup != noRatingGroup: sessionToReport = sessionId + '_' + ratingGroup
		else:				 sessionToReport = sessionId
		
		# Extra work if Gx
		savedI = i
		if interface.lower() == 'gx':
			# Add to session ID
			sessionToReport += '(Gx)'
			
			# Clear misc data
			misc = ''
			
			# Add rule install/remove
			for keyStart in ['Remove', 'Install']:
				rules=''
				for i in range(10):
					# If we run out of items, then break
					key = getPolicyRuleKey(dctRcvd,i, keyStart)
					if not key: break
					
					# Add value to string
					data = dctRcvd[key].split(':')
					if len(data) > 1: data = data[2][:-1]
					
					# Data is encoded.  So an ascii "a" is two characters ('61').
					try:
						data = base64.b16decode(data.upper())
					except:
						kef = 1
									
					# Convert data to printable ascii
					rules += ', ' + str(data)
				
                		# If we added anything, then append to misc (skipping initial "," character)
		                if rules:
        		                misc += ' ' + keyStart + ':' + rules[1:]
		
        		                # Add separator if first pass
                		        if keyStart == 'Remove': misc += ' ;'
			
			# Remove leading space if anything in misc
			if len(misc): misc = misc[1:]
			
		# If not a success, then add error message AVP to misc if present
		if not diamSuccessCheck(diamResult, msccResult) and 'Error-Message' in dctRcvd: misc += 'Error Message: "' + dctRcvd['Error-Message'] + '"' 
		
		i = savedI
		# Output summary
		outputData(options, cmd='CCR/CCA', sessionId=sessionToReport, deviceId=ccrStats[overallSessionId]['deviceId'], \
			accessNumbers=ccrStats[overallSessionId]['accessNumbers'], msccResult=msccResult, \
			time=ccrStats[overallSessionId]['eventTime'], diamResult=diamResult, \
			reqType=ccrStats[overallSessionId]['requestType'], reqNum=ccrStats[overallSessionId]['requestNumber'], \
			misc=misc, index=i)

		# If successful, then update tracking data
		#if int(diamResult) < 4000 and int(msccResult) < 4000:
		if diamSuccessCheck(diamResult, msccResult):
			# Update tracking data
			##if reportingReason == '1' or reportingReason == '2' or reportingReason == '3': requestType = 'term'
			if reportingReason == '2': requestType = 'term'
			else: requestType = ccrStats[overallSessionId]['requestType']
			updateSessionTrackingData(\
				ccrStats[overallSessionId]['deviceId'], ccrStats[overallSessionId]['accessNumbers'], requestType, \
				ccrStats[overallSessionId]['sessionId'], ccrStats[overallSessionId]['ratingGroup'], ccrStats[overallSessionId]['eventTime'], \
				ccrStats[overallSessionId]['requestUnits'], ccrStats[overallSessionId]['usedUnits'], grantedUnits, interface='gy', reportingReason=reportingReason, options=options)
		#else:
		#	print 'NOTE: Not storing session information since there was a failing result code:  Diam/MSCC result codes: ' + str(diamResult) + '/' + str(msccResult)
		# Remove this session from the stats data
		del ccrStats[overallSessionId]
	
#===============================================================================
def diamSuccessCheck(diamResult, msccResult='0'):
	return diamResult != 'None' and int(diamResult) < 4000 and int(msccResult) < 4000
		
#===============================================================================
def getResultCode(message, dctRcvd):
	diamResult = None
	for avp in ['Result-Code', 'Experimental-Result->Experimental-Result-Code']:
	        if avp in dctRcvd:
			diamResult = dctRcvd[avp]
			break
	
	# If still None then we did't get any result
        if diamResult is None:
                print('WARNING: ' + message + ' received without any result code (main or experimental)')
                pprint.pprint(dctRcvd)
                diamResult = 'None'
	
	return diamResult
	
#===============================================================================
def processSLRandSLA(options, dctRcvd):
    global slrStats
    global filterFlag
    
    # Locals
    deviceId = None
    accessNumbers = None
    externalId = subExternalId
    misc = ''
    
    # See if we should skip this message
    if options.skip.upper().count('SLR') or options.skip.upper().count('SLA'): return
    
    # Get common fields
    systemTime = dctRcvd['System-Time']
    
    # Do Request-specific work first
    if dctRcvd['CmdReq'] == '1':
	# Debug output
	#print 'Process SLR'
	
    	# Debug output
	#print 'Received Diameter dictionary: '
    	#print str(dctRcvd)
    
	# Get the IMSI and MSISDN.  May have one or two Subscrption structures
	if 'Subscription-Id0->Subscription-Id-Type' in dctRcvd:
		# Type says what kind of item it is
		if dctRcvd['Subscription-Id0->Subscription-Id-Type'] == subIdMSISDNType:
			deviceId = dctRcvd['Subscription-Id0->Subscription-Id-Data']
		else:   accessNumbers = dctRcvd['Subscription-Id0->Subscription-Id-Data']
		
		#print 'deviceId and aN post Sub0 data: ' + str(deviceId) + ', ' + str(accessNumbers)
	elif 'SL-Request-Type' in dctRcvd and dctRcvd['SL-Request-Type'] != 1:
		# SLR-I may only have the session ID but if not this then an error...
		print('ERROR: SLR init message Dictionary does not have any Subscription-Id grouped AVPs')
		print(str(dctRcvd))
		return
	
	# Second one is optional
	if 'Subscription-Id1->Subscription-Id-Type' in dctRcvd:
		# Type says what kind of item it is
		if dctRcvd['Subscription-Id1->Subscription-Id-Type'] == subIdMSISDNType:
			deviceId = dctRcvd['Subscription-Id1->Subscription-Id-Data']
		else:   accessNumbers = dctRcvd['Subscription-Id1->Subscription-Id-Data']

	#print 'deviceId and aN post Sub1 data: ' + str(deviceId) + ', ' + str(accessNumbers)
	
	# Get key pieces of data
	sessionId = dctRcvd['Session-Id']
	
	# For SLR, the session is not a combination of other data
	overallSessionId = sessionId
	
	# If no device/imsi entered then get from stats
	if 'SL-Request-Type' in dctRcvd and dctRcvd['SL-Request-Type'] == 1 and not deviceId and not accessNumbers:
		# Get data from slr stats
		if overallSessionId in slrStats:
			deviceId = slrStats[overallSessionId]['deviceId']
			accessNumbers = slrStats[overallSessionId]['accessNumbers']
		else:
			print('ERROR: SLR update message Dictionary does not have tracked data and no device/access numbers in the message')
			print(str(dctRcvd))
			return
	
	# Want to make sure the data is tracked in subscriber/device/accessNumber structures.  Create them if needed (since we may only get debug log files).
	# If only IMSI entered, then need to find device ID
	if accessNumbers and not deviceId:
		# Got IMSI only.  Need to see if we have this.  Work backwards from the IMSI to the device
		if accessNumbers in accessNumberTracking: deviceId = accessNumberTracking[accessNumbers]['deviceId']
			
	# At this point, if no device found yet, then make one up
	if not deviceId: deviceId = subExternalId
	
	# If no device currently stored and filtering, then return
	if deviceId not in deviceTracking and filterFlag: return
	
	# Check if the device has not already been added to the subscriber
	if not subscriberTracking[externalId]['deviceId'].count(deviceId):
                # Add device to subscriber
       	        updateTrackingData('addDeviceToSubscriber', externalId = externalId, deviceId = deviceId, accessNumbers = accessNumbers)
			
	# Sanity check that we don't have this session already saved...
	if overallSessionId in slrStats:
		# Check if duplicate set
		if int(dctRcvd['CmdReXmit']) > 0:
			# Duplicate message received
			print('NOTE: duplicate SLR received.  slrStats has an existing key = ' + overallSessionId)
			
			# Return here - keep original data
			return
		else:
			print('ERROR:  SLR received.  slrStats has an existing key = ' + overallSessionId)
			return
	
	# Save this data in the structure for processing when we get the CCA
	slrStats[overallSessionId] = {}
	slrStats[overallSessionId]['Origin-Host'] = dctRcvd['Origin-Host']
	slrStats[overallSessionId]['Origin-Realm'] = dctRcvd['Origin-Realm']
	slrStats[overallSessionId]['deviceId'] = deviceId
	slrStats[overallSessionId]['accessNumbers'] = accessNumbers
	slrStats[overallSessionId]['sessionId'] = sessionId
	if 'SL-Request-Type' in dctRcvd: slrStats[overallSessionId]['SL-Request-Type'] = dctRcvd['SL-Request-Type']
	else: slrStats[overallSessionId]['SL-Request-Type'] = '1'
	
	# Add in all the Policy Counter  entered
	slrStats[overallSessionId]['Pcid'] = []
	idx = 0
	while True:
		# See if the policy value was input
		pcidString = 'Pcid' + str(idx)
		if pcidString in dctRcvd: 
			# Store in the array
			slrStats[overallSessionId]['Pcid'].append(dctRcvd[pcidString])
			idx += 1
		else:
			# No more of these
			break
    else:
	# Debug output
	#print 'Process SLA'
	
    	# Debug output
	#print 'Received Diameter dictionary: '
    	#print str(dctRcvd)
    
	# Get key pieces of data
	sessionId = dctRcvd['Session-Id']
	
        # Get key values.  This message may receive an experimental result code.
	diamResult = getResultCode('SLA', dctRcvd)
	
	# Use same variable name (easy cut/paste)
	overallSessionId = sessionId
	
	# Make sure the session exists in the stats data
	if overallSessionId not in slrStats: 
		# If filtering enabled, then this should be fine
		if filterFlag: return
		else:
			# Hmmmm.....
			print('WARNING:  SLA received with session ' + str(overallSessionId) + ' but no SLR receved.  Dropping message.')
			return
		
	# Grab the policy data from the SLA
	policyData = []
	idx = 0
	while True:
		# See if the policy value was input
		pcidString = 'Pcsr' + str(idx)
		if pcidString + '->Policy-Counter-Status' in dctRcvd: 
			# Store in the array
			policyData.append([dctRcvd[pcidString + '->Policy-Counter-Status'], dctRcvd[pcidString + '->Policy-Counter-Identifier']])
			idx += 1
		else:
			# No more of these
			break
	
	# Convert request type to string
	requestString = 'initial'
	if slrStats[overallSessionId]['SL-Request-Type'] == '1': requestString = 'interim'
	
	# Add policy data to outpu tif defined
	if len(policyData): misc = 'Policy: ' + str(policyData)
	
	# If not a success, then add error message AVP to misc if present
	if not diamSuccessCheck(diamResult) and 'Error-Message' in dctRcvd: misc += ' Error Message: "' + dctRcvd['Error-Message'] + '"' 
		
	# Output summary
	outputData(options, cmd='SLR/SLA', sessionId=overallSessionId, deviceId=slrStats[overallSessionId]['deviceId'], \
		accessNumbers=slrStats[overallSessionId]['accessNumbers'], reqType=requestString, \
		time=systemTime, diamResult=diamResult, misc=misc)

	# Update tracking data.  Send policy data in requested units variable.
	updateSessionTrackingData(\
		slrStats[overallSessionId]['deviceId'], slrStats[overallSessionId]['accessNumbers'], requestString, \
		sessionId, '0', systemTime, \
		policyData, '0', '0', interface='sy', options=options)
		
	# Remove this session from the stats data
	del slrStats[overallSessionId]
	
#===============================================================================
def processSTRandSTA(options, dctRcvd):
    global slrStats
    global filterFlag
    
    misc = ''
    
    # See if we should skip this message
    if options.skip.upper().count('STR') or options.skip.upper().count('STA'): return
    
    # Get key pieces of data
    sessionId = dctRcvd['Session-Id']
    systemTime = dctRcvd['System-Time']

    # For SLR, the session is not a combination of other data
    overallSessionId = sessionId
	
    # If this is not already a session, then no need to do anything here.
    if overallSessionId+'_0' not in sessionTracking: 
	# Debug output
	#print 'Not tracking Sy session, so message ignored'
	
	return
	
    # Do Request-specific work first
    if dctRcvd['CmdReq'] == '1':
	# Debug output
	#print 'Process STR'
	
    	# Debug output
	#print 'Received Diameter dictionary: '
    	#print str(dctRcvd)
    
	# Sanity check that we don't have this session already saved...
	if overallSessionId in slrStats:
		# Check if duplicate set
		if int(dctRcvd['CmdReXmit']) > 0:
			# Duplicate message received
			print('NOTE: duplicate STR received.  slrStats has an existing key = ' + overallSessionId)
			
			# Return here - keep original data
			return
		else:
			print('ERROR:  STR received.  slrStats has an existing key = ' + overallSessionId)
			return
	
	# Save this data in the structure for processing when we get the CCA
	slrStats[overallSessionId] = {}
	slrStats[overallSessionId]['Origin-Host'] = dctRcvd['Origin-Host']
	slrStats[overallSessionId]['Origin-Realm'] = dctRcvd['Origin-Realm']
	slrStats[overallSessionId]['sessionId'] = sessionId
    else:
	# Make sure the session exists in the stats data
	if overallSessionId not in slrStats: 
		# If filtering enabled, then this shoudl be fine
		if filterFlag: return
		else:
			# Hmmmm.....
			print('WARNING:  STA received with session ' + str(overallSessionId) + ' but no STR receved.  Dropping message.')
			return
	
	# Get key values.  This message may receive an experimental result code. 
	diamResult = getResultCode('STA', dctRcvd)
	
	# If not a success, then add error message AVP to misc if present
	if not diamSuccessCheck(diamResult) and 'Error-Message' in dctRcvd: misc += ' Error Message: "' + dctRcvd['Error-Message'] + '"' 
		
	# Output summary
	outputData(options, cmd='STR/STA', sessionId=overallSessionId, reqType='term', \
		time=systemTime, diamResult=diamResult, misc=misc)

	# Update tracking data.  This is a term event.
	updateSessionTrackingData(\
		sessionTracking[overallSessionId+'_0']['deviceId'], '0', 'term', \
		sessionId, '0', systemTime, \
		'0', '0', '0', interface='sy', options=options)
		
	# Remove this session from the stats data
	del slrStats[overallSessionId]
	
#===============================================================================
def getPolicyRuleKey(dctRcvd, i, keyStart):
	# Keys come back as one of two strings
	key = 'Charging-Rule-' + keyStart + str(i) + '->Charging-Rule-Name'
	if key in dctRcvd: return key
	
	# Try second string
	key = 'Charging-Rule-' + keyStart + str(i) + '->Charging-Rule-Base-Name'
	if key in dctRcvd: return key
	else:		   return None

#===============================================================================
def processRARandRAA(options, dctRcvd, interface='Gy'):
    # See if we should skip this message
    if options.skip.upper().count('RAR') or options.skip.upper().count('RAA'): return
    
    '''
    print 'RAR/RAA message: '
    pprint.pprint(dctRcvd)
    '''
	
    # Get key pieces of data
    sessionId = dctRcvd['Session-Id']
    systemTime = dctRcvd['System-Time']

    # Use same variable name (easy cut/paste)
    overallSessionId = sessionId
    
    # Get key items
    if 'Rating-Group' in dctRcvd: ratingGroup = dctRcvd['Rating-Group']
    else:			  ratingGroup = noRatingGroup
    
    # Set session ID
    subSession = sessionId + '_' + ratingGroup
		
    # If no session currently stored and filtering, then return
    if subSession not in sessionTracking:
        # If no checks not in effect, then not so good...
        if not options.noChecks:
                # If filtering enabled, then this is fine
                if filterFlag: return

                # Hmmmm.....
                if dctRcvd['CmdReq'] == '1': msg = 'RAR'
                else:                        msg = 'RAA'
                print('WARNING: ' + msg + ' received with session ' + str(subSession) + ' and it\'s not in the session database')

        # noChecks is true.  Use dummy values
        accessNumber = deviceId = 'Not Tracked'
    else:
        # Get subscriber ID
        # Use IMSI if present, else use MSISDN
        accessNumber = sessionTracking[subSession]['accessNumber']
        deviceId = sessionTracking[subSession]['deviceId']

    # Convert request type to string
    requestString = ''
    
    # Output summary
    if ratingGroup != noRatingGroup:
	misc = 'RG: ' + ratingGroup
    else:
	misc = ''
	subSession = overallSessionId
	
    # If Gx, then add to session ID)
    if interface.lower() == 'gx': subSession += '(Gx)'
	
    # Do Request-specific work first
    if dctRcvd['CmdReq'] == '1':
	# Debug output
	#print 'Process RAR'
	
    	# Debug output
	#print 'Received Diameter dictionary: '
    	#print str(dctRcvd)
	
	# Add rule install/remove
	for keyStart in ['Remove', 'Install']:
		rules=''
		for i in range(10):
			# If we run out of items, then break
			key = getPolicyRuleKey(dctRcvd,i, keyStart)
			if not key: break
	
			# Add value to string
			data = dctRcvd[key].split(':')
			if len(data) > 1: data = data[2][:-1]
			
			# Data is encoded.  So an ascii "a" is two characters ('61').
#			print 'Data: ' + data
			try:
				data = base64.b16decode(data.upper())
			except:
				kef = 1
			
			# Convert data to printable ascii
			rules += ', ' + str(data)
		
                # If we added anything, then append to misc (skipping initial "," character)
                if rules:
                        misc += ' ' + keyStart + ':' + rules[1:]

                        # Add separator if first pass
                        if keyStart == 'Remove': misc += ' ;'
		
	# Output the data
	outputData(options, cmd='RAR', sessionId=subSession, reqType=requestString, time=systemTime, misc=misc.strip(), deviceId=deviceId, accessNumbers=accessNumber)
    else:
	# Debug output
	#print 'Process RAA'
	
    	# Debug output
	#print 'Received Diameter dictionary: '
    	#print str(dctRcvd)
	
	# Get specific data
	diamResult = getResultCode('RAA', dctRcvd)
	
	# If not a success, then add error message AVP to misc if present
	misc = ''
	if not diamSuccessCheck(diamResult) and 'Error-Message' in dctRcvd: misc += ' Error Message: "' + dctRcvd['Error-Message'] + '"' 
		
	# Output summary
	outputData(options, cmd='RAA', sessionId=subSession, reqType=requestString, time=systemTime, diamResult=diamResult, misc=misc, deviceId=deviceId, accessNumbers=accessNumber)

#===============================================================================
def processDWRandDWA(options, dctRcvd):
    # See if we should skip this message
    if options.skip.upper().count('DWR') or options.skip.upper().count('DWA'): return
    
    # Get common fields
    systemTime = dctRcvd['System-Time']
    
    # Get key fields
    originHost = dctRcvd['Origin-Host']
    originRealm = dctRcvd['Origin-Realm']
	
    # Setup Misc data
    misc = 'Origin-Host/Realm = ' + originHost + '/' + originRealm
	
    # Do Request-specific work first
    if dctRcvd['CmdReq'] == '1':
	# Debug output
#	print 'Process DWR'
	
	# Output summary
	outputData(options, cmd='DWR', time=systemTime, misc=misc)

    else:
	# Debug output
#	print 'Process DWA'
	
	# Output summary
	outputData(options, cmd='DWA', time=systemTime, misc=misc)

#===============================================================================
def processSNRandSNA(options, dctRcvd):
    # See if we should skip this message
    if options.skip.upper().count('SNR') or options.skip.upper().count('SNA'): return
    
    # Get key pieces of data
    sessionId = dctRcvd['Session-Id']
    systemTime = dctRcvd['System-Time']

    # Use same variable name (easy cut/paste)
    overallSessionId = sessionId
    
    # Get value that the session tracking uses	
    subSession = overallSessionId+'_0'
    
    # If no session currently stored and filtering, then return
    if subSession not in sessionTracking:
        # If no checks not in effect, then not so good...
        if not options.noChecks:
                # If filtering enabled, then this is fine
                if filterFlag: return
                else:
                        # Hmmmm.....
                        print('WARNING:  SNR received with session ' + str(overallSessionId) + ' and it\'s not in the session database.')

        # noChecks is true.  Use dummy values
        accessNumber = deviceId = 'Not Tracked'
    else:
        # Get subscriber ID
        # Use IMSI if present, else use MSISDN
        accessNumber = sessionTracking[subSession]['accessNumber']
        deviceId = sessionTracking[subSession]['deviceId']
			
    # Do Request-specific work first
    if dctRcvd['CmdReq'] == '1':
	# Debug output
	#print 'Process SNR'
	
    	# Debug output
	#print 'Received Diameter dictionary: '
    	#print str(dctRcvd)
    
	# Grap the policy data
	policyData = []
	idx = 0
	while True:
		# See if the policy value was input
		pcidString = 'Pcsr' + str(idx)
		if pcidString + '->Policy-Counter-Status' in dctRcvd: 
			# Store in the array
			policyData.append([dctRcvd[pcidString + '->Policy-Counter-Status'], dctRcvd[pcidString + '->Policy-Counter-Identifier']])
			idx += 1
		else:
			# No more of these
			break
	
	# Convert request type to string
	requestString = 'interim'
	
	# Output summary
	outputData(options, cmd='SNR', sessionId=overallSessionId, reqType=requestString, time=systemTime, misc='Policy: ' + str(policyData))

	# Update tracking data.  Send policy data in requested units variable.
	if deviceId != 'Not Tracked': updateSessionTrackingData(\
		deviceId, accessNumber, requestString, \
		sessionId, '0', systemTime, \
		policyData, '0', '0', interface='sy', options=options)
		
    else:
	# Debug output
	#print 'Process SNA'
	
    	# Debug output
	#print 'Received Diameter dictionary: '
    	#print str(dctRcvd)
    
	# Get specific data
	diamResult = getResultCode('SNA', dctRcvd)
	
	# If not a success, then add error message AVP to misc if present
	misc = ''
	if not diamSuccessCheck(diamResult) and 'Error-Message' in dctRcvd: misc += ' Error Message: "' + dctRcvd['Error-Message'] + '"' 
		
	# Output summary
	outputData(options, cmd='SNA', sessionId=overallSessionId, reqType='interim', \
		time=systemTime, diamResult=diamResult, misc=misc)

#===============================================================================
def processDPRandDPA(options, dctRcvd):
    # See if we should skip this message
    if options.skip.upper().count('DPR') or options.skip.upper().count('DPA'): return
    
    # Get common fields
    systemTime = dctRcvd['System-Time']
    originHost = dctRcvd['Origin-Host']
    originRealm = dctRcvd['Origin-Realm']
    
    # Setup Misc data
    miscString = 'Origin-Host/Realm = ' + originHost + '/' + originRealm
    
    # Do Request-specific work first
    if dctRcvd['CmdReq'] == '1':
	# Debug output
	#print 'Process DPR'
	
	# Get additional data
	if 'Disconnect-Cause' in dctRcvd: reason = dctRcvd['Disconnect-Cause']
	else: reason = 'None'
	
	# Add to misc string
	misc += ', Disconenct reason = ' + reason
	
	# Output summary
	outputData(options, cmd='DPR', time=systemTime, misc=misc)

    else:
	# Debug output
	#print 'Process DPA'

	# Get specific data
	diamResult = getResultCode('DPA', dctRcvd)
	
	# Output summary
	outputData(options, cmd='DPA', time=systemTime, diamResult=diamResult, misc=misc)

#===============================================================================
def processSock(options, dctRcvd):
    # See if we should skip this message
    if options.skip.upper().count('SOCK'): return
    
    # Get common fields
    systemTime = dctRcvd['System-Time']
    
    # Do Request-specific work first
    if dctRcvd['CmdReq'] == '1':
	# Debug output
	#print 'Process Socket Request'
	
	# Output summary
	outputData(options, cmd='SockR', time=systemTime)

    else:
	# Debug output
	#print 'Process Socket Answer'
	
	# Output summary
	outputData(options, cmd='SockA', time=systemTime)

#===============================================================================
def processCERandCEA(options, dctRcvd):
    global cerStats
    global cerIndex
    
    # See if we should skip this message
    if options.skip.upper().count('CER') or options.skip.upper().count('CEA'): return
    
    # Get common fields
    systemTime = dctRcvd['System-Time']
    
    # Do Request-specific work first
    if dctRcvd['CmdReq'] == '1':
	# Debug output
	#print 'Process CER'
	
    	# Debug output
	#print 'Received Diameter dictionary: '
    	#print str(dctRcvd)
    
	# Setup next CER index
	cerIndex += 1
	cerStats[cerIndex] = {}
	
        # Get key fields
        if 'Origin-Host' in dctRcvd:    cerStats[cerIndex]['Origin-Host'] = dctRcvd['Origin-Host']
        else:                           cerStats[cerIndex]['Origin-Host'] = 'Not Returned'
        if 'Origin-Realm' in dctRcvd:   cerStats[cerIndex]['Origin-Realm'] = dctRcvd['Origin-Realm']
        else:                           cerStats[cerIndex]['Origin-Realm'] = 'Not Returned'
        if 'Origin-State-Id' in dctRcvd:cerStats[cerIndex]['Origin-State-Id'] = dctRcvd['Origin-State-Id']
        else:                           cerStats[cerIndex]['Origin-State-Id'] = 'Not Returned'
	
    else:
	#print 'Process CEA'
	
	# Get specific data
	diamResult = getResultCode('CEA', dctRcvd)
	
	# Output summary
	miscString = 'Origin-Host/Realm = ' + cerStats[cerIndex]['Origin-Host'] + '/' + cerStats[cerIndex]['Origin-Realm']
	outputData(options, cmd='CER/CEA', reqType='exchg', \
		time=systemTime, diamResult=diamResult, misc=miscString)

	# Output summary
#	print 'CER/A exchange: Origin-Host/Realm = ' + cerStats[cerIndex]['Origin-Host'] + '/' + cerStats[cerIndex]['Origin-Realm'] + \
#		' Origin-State-Id = ' + cerStats[cerIndex]['Origin-State-Id'] + ', Result code = ' + diamResult
	
	# Cleanup
	del cerStats[cerIndex]
	cerIndex -= 1
	
#===============================================================================
def getRawDiameterDct(diamObj, groupedAVPs):
    # Init local multiple entry counters
    msccCounter = -1
    pcrsCounter = -1
    pcidCounter = -1
    subIdCounter = -1
    installCounter = -1
    removeCounter = -1
    
    # Local array of group hierarchy
    grouped = []
    
    # Returned structure
    diameterDct = {}
    
    # Separate input string into an array
    diamArr = diamObj.split('\n')

    # Debug output
    #print 'Received diameter array: ' + str(diamArr)

    # Process all array entries
    for line in diamArr:
        # Skip until we get to the header line
        if not re.search(diameterHeader, line): continue

        # Break this line into fields
        hdrLine = line.split(',')

        # Process each field
        for fields in hdrLine:
                # If the field contains the Diameter header, then need to skinny it down
                if re.search(diameterHeader, fields): fields = fields.split(':')[1].strip()

                # Get the command and value (separated by an '=' character)
                command = fields.split('=')[0].strip()
                value = fields.split('=')[1].strip()

                # Add to the dictionary to be returned
                diameterDct[command] = value

        # Done processing the header line
        break

    # Process all array entries
    for line in diamArr:
	# Skip diameter header line
        if re.search(diameterHeader, line): continue  

	# Manipulate the line
        line = line.strip('\n')
        line = line.strip(',')
        line = re.sub('.*AVP: ', '', line)
	
	# Get the fields
        tmp = line.split(',')
	
	# Remove AVP codes from the AVP name
        tmp[0] = re.sub('\(\d+\)','', tmp[0]) 

	# See if this matches the input grouped AVPs
        if tmp[0] in groupedAVPs:
	    #print 'Found group: ' + tmp[0]
		
	    # Three scenarios here: (1) this is the first group,  (2) group is a child of the current group, or (3) it's not a child
	    if not len(grouped):
		# Add to the empty list
		grouped.append(tmp[0])
	    # Check for scenario 2
	    elif groupedAVPs[grouped[-1]]['avps'].count(tmp[0]):
		# Add this group to the local group depth
		grouped.append(tmp[0])
	    else:
		# Scenario 3.  Need to replace the last group hierarchy item with the new group
		grouped[-1] = tmp[0]
	    	
            # Remap and count groups that could be duplicates
            if   tmp[0] == 'Multiple-Services-Credit-Control': 	msccCounter += 1
            elif tmp[0] == 'Policy-Counter-Status-Report': 	pcrsCounter += 1
            elif tmp[0] == 'Policy-Counter-Identifier': 	pcidCounter += 1
            elif tmp[0] == 'Subscription-Id': 			subIdCounter += 1
            elif tmp[0] == 'Charging-Rule-Install': 		installCounter += 1
            elif tmp[0] == 'Charging-Rule-Remove': 		removeCounter += 1
	    
	    # Nothing more to do with this entry
            continue
	
	# OK, not a grouped AVP.  Now see if we're into groups
	while len(grouped):
		# Debug output
		#print 'Checking ' + str(groupedAVPs[grouped[-1]]['avps']) + ' for key ' + tmp[0]
		
		# If this AVP not part of the last group, then remove that group from the hierarchy
		if not groupedAVPs[grouped[-1]]['avps'].count(tmp[0]): 
			# Debug output
			#print 'Did not find ' + tmp[0] + ' in the group ' + grouped[-1]
			
			# Remove from hierarchy
			grouped = grouped[:-1]
		else: 
			# Found it
			
			# Debug output
			#print 'FOUND ' + tmp[0] + ' in the group ' + grouped[-1]
			
			# Stop hierarchy check
			break	

	# This will be the string we add to the dictionary
        avpString = ''
	
	# Build the dictionary name
	for index in range(len(grouped)):
            # Rename groups that could be duplicates
            if   grouped[index] == 'Multiple-Services-Credit-Control': avpString += 'Mscc' + str(msccCounter) 
            elif grouped[index] == 'Policy-Counter-Status-Report':     avpString += 'Pcsr' + str(pcrsCounter) 
            elif grouped[index] == 'Policy-Counter-Identifier':        avpString += 'Pcid' + str(pcidCounter) 
            elif grouped[index] == 'Subscription-Id':                  avpString += 'Subscription-Id' + str(subIdCounter) 
            elif grouped[index] == 'Charging-Rule-Install':            avpString += 'Charging-Rule-Install' + str(installCounter) 
            elif grouped[index] == 'Charging-Rule-Remove':             avpString += 'Charging-Rule-Remove' + str(removeCounter) 
	    else: avpString += grouped[index]
	    
	    # Add group seperator
	    avpString += hierarchyString
		
	# Add the AVP to the string
	avpString += tmp[0]
	
	# Add to the returned dictionary
        diameterDct[avpString] = re.sub('value=', '', tmp[-1].strip())
	
	# Debug output
        #print 'saving dictionary entry ' + avpString + ' = ' + diameterDct[avpString]

    return (diameterDct)

#===============================================================================
def readGroupedAVPs(options):
    groupedAVPs = {}
    diamDict = options.dict
    groupName = ''
    rmvFile = False
    outFile_def = "grouped_avps_def"
    outFile_members = "grouped_avps_members"
    
    # Want to run a command to grab the grouped data.  In 46xx it's in two places now.
    runCmd("awk '/<grouped_avp/,/<\/grouped_avp/' " + diamDict + " | grep [_\<]avp | grep -v TODO > " + outFile_members)
    runCmd('grep \'type_name="Grouped"\' ' + diamDict + " > " + outFile_def)
    
    # ** Process group AVP definition **
    # Open the file
    f = open(outFile_def)
    
    # Go through each line
    for line in f:
	# Remove leading/trailing white space
	line = line.strip()
	
	# If an empty line, skip
	if not line: continue
	
	# Get the fields.  Here's the expected string: <avp name="MtxTxnId" code="2000" type_name="Grouped" vendor_name="MatrixxSoftware">
	# Vendor data is optional.
	groupName   = line.split('=')[1].split('"')[1]
	groupCode   = line.split('=')[2].split('"')[1]
	if re.search(vendorNameString, line): 
	       	groupVendor = line.split('=')[4].split('"')[1]
	else:  	groupVendor = 'None'
	
	# Debug output
	#print 'Found group: ' + groupName
	
	# Create entry for this group
	groupedAVPs[groupName] = {}
	groupedAVPs[groupName]['code'] = groupCode
	groupedAVPs[groupName]['vendor'] = groupVendor
	groupedAVPs[groupName]['avps'] = []
	
    # Close the file
    f.close()
	
    # ** process grouped AVP definition (i.e. the AVPs in the group) **
    # Flag to signal inside a grouped AVP 
    insideGroupedAVPFlag = False
    
    # Open the file
    f = open(outFile_members)
    
    # Go through each line
    for line in f:
	# Remove leading/trailing white space
	line = line.strip()
	
	# If an empty line, skip
	if not line: continue
	
	# Debug output
#        print 'Processing line: ' + line
	
    	# See if this is a start/end flag
	if re.search(groupStartEndString, line):
		# See if this is the start of a group
		if not insideGroupedAVPFlag:
			# Set flag that we're in a grouped AVP
			insideGroupedAVPFlag = True
			
			# Debug output
			#print 'grouped_avp line: ' + line
			
			# Get the group name
			groupName = line.split('=')[1].split('"')[1]
			
			# Sanity check - should have this in the structure
			if groupName not in groupedAVPs:
				print('ERROR:  Encountered grouped_avp name ' + groupName + ' but it\'s not in the defined set of groups: ' + str(groupedAVPs))
				return
		else:
			# This is the end of the group
			insideGroupedAVPFlag = False
		
			# Clear the group name local
			groupName = None
			
		# No more processing for this line
		continue
	
	# Not a grouped item, so a single AVP.  Here's the expected string: <avp name="Outgoing-Trunk-Group-Id"/>
	# Also, file may have a dummy entry (with AVP string), so skip that
	if re.search('AVP', line): continue
	
	# Get AVP name
	avpName = line.split('=')[1].split('"')[1]
	
	# Debug output
	#print 'Group ' + groupName + ', Adding AVP ' + avpName
	
	# Add to the active group
	groupedAVPs[groupName]['avps'].append(avpName)
	
    # Close the file
    f.close()
	
    # Remove temp file
    runCmd('rm -f '+ outFile_def + ' ' + outFile_members)
    
    # Remove dictionary if flag is set
    if rmvFile: runCmd('rm '+ diamDict)
    
    return groupedAVPs
	
#===============================================================================
def processDebugLogFile(inputFile, debugFd=None, warnFd=None):

    # Initialize return structure
    diamMsgs = []

    # Initialize local message holder
    localDiamMsg = ''
    
    # Init message count
    msgCount = 0

    # Define diameter data file
    diamDataFile = '_diamData'
    diamTimeFile = '_diamTime'
    
    # Debug output
    #print 'Pre-processing file: ' + inputFile
	
    # Assume this is the generic debug log file.  Want to grab only the Diameter data.
    runCmd("awk '/Diameter Hdr:/,/}/' " + inputFile + " > " + diamDataFile)

    # Need to grab system time, as not all diameter commands include time.
    runCmd('grep -B1 "Diameter Hdr:" ' + inputFile + ' | grep ^LM_ | cut -f2 -d"|" | cut -f2-3 -d" " | tr " " "T" > ' + diamTimeFile)

    # Open the diameter data and time files
    f = open(diamDataFile)
    g = open(diamTimeFile)

    # Go through each line in the file
    msgStartFlag = False
    for line in f:
	# Remove leading/trailing white space
	line = line.strip()
	
	# If an empty line, skip
	if not line: continue
	
	# Debug output
        #print 'Processing line: ' + line
	
        # Skip until we get to the header line
	if not msgStartFlag:
		# See if at start of new message
	        if re.search(msgStartString, line): 
			# If here, then found the start of the message
			msgStartFlag = True
			
			# Save first line
			localDiamMsg = line + '\n'
		
			# Debug output
		        #print 'Detected start of new message'
	
		# No need to further process this line
		continue
		
	# If here, then past start of the message.  Go until the end of the message is found.
	# Skip the one line that starts with a skip character.
	if line[0] == msgLineSkipChar: continue
	
	# Check if end found.
	# NOTE:	SOCK messages can contain "}" characters, which messes up the awk line...
	#	Protect against this and see if the message start flag is in the line.  Assume end if so.
	if line[0] == msgEndChar or re.search(msgStartString, line): endFlag=True
	else: endFlag = False
	
	# Act if end found
	if endFlag:
		# MINOR HACK:  Want to have a time value in each structure.
		# Read time from time file and create a dummy AVP structure.
		systemMsgTime = g.readline()
		
		# Create a dummy AVP
		lineExtra = 'AVP: System-Time(999), len=27, V=0, M=1, P=0, VendorId=0, value=' + systemMsgTime
		
		# Store as if it was found in the Diameter message
		localDiamMsg += lineExtra + '\n'	
		
		# Save line in return structure
		diamMsgs.append(localDiamMsg)
		
		# Clear start flag
		msgStartFlag = False
		
		# Bump message counter
		msgCount += 1
		
		# Debug output
		#print 'Stored message #' + str(msgCount)
		#print 'Message is:\n' + localDiamMsg
		
		# See if at start of new message (part of SOCK issue highlighted above)
	        if re.search(msgStartString, line): 
			# If here, then found the start of the message
			msgStartFlag = True
			
			# Save first line
			localDiamMsg = line + '\n'
		
			# Debug output
		        #print 'Detected start of new message'
	
		# No more processing of this line needed
		continue
		
	# If here, then it's an AVP line.  Add to local message
	localDiamMsg += line + '\n'

    # Remove temp files
    runCmd('rm ' + diamDataFile + ' ' + diamTimeFile)
    
    return diamMsgs, msgCount
	
#===============================================================================
def showData(externalId = None):
    # Debug output
    print('\nSubscriber/device/session data:\n')
    
    # Sanithy check that an external was added in
    if not externalId:
	# Error
	print('ERROR:  no external passed to showData')
	return
    
    # Show this data
    idList = []
    if type(externalId) is list: idList.extend(externalId)
    else: idList.append(externalId)
	
    # Output data 
    showSubscriberTrackingData(idList, scope = 'full', verbose = 'high')

#===============================================================================
def gatherInputFiles(options):
    fileToProcess = []
    
    # There may be more than one file to process
    if options.inputFile: fileToProcess = options.inputFile.split(',')

    # May want to read files from different servers
    ipAddr = []
    if options.ip:
        # Get all the addresses
        ipAddr = options.ip.split(',')

    	for index in range(len(ipAddr)):
            if ipAddr[index] == 'localhost':  fileToProcess.append('/var/log/mtx/mtx_debug.log')
            else:
                # Want to scp the file here
                runCmd("scp mtx@" + ipAddr[index] + ":/var/log/mtx/mtx_debug.log mtx_debug.log." + ipAddr[index])

                # Add this file to the file to process list
                fileToProcess.append('mtx_debug.log.' + ipAddr[index])

    return fileToProcess
#===============================================================================
def main():
    global options
    global ReprocessFlag
    global outputHeaderFlag
    
    groupedAVPs = []
    fileToProcess = []
    
    # Path is always the current directory
    path = os.getcwd()
    
    ########### Do command line processing ###################
    options = cmdLineInput()
    
    ########### Initialize Tracking Data ###################
    initTrackingData(options)
    
    ########### Read in grouped AVPs ###################
    groupedAVPs = readGroupedAVPs(options)
    
    ########## Gather config files ##################
    options = DEBUG.gatherAllConfigFiles(options)
    
    # Don't want to read debug files the first time through...
    gatherFiles = True
    
    # Set flag to not processed output data
    outputHeaderFlag = False
			
    # Loop while the answer not some form of "no"...
    ans = 'y'
    while not ans.lower().startswith('n') and not ans.lower().startswith('x'):
    	########## Gather all required files ##################
    	if gatherFiles: DEBUG.getDebugLogFiles(options)
	else: gatherFiles = True
    
    	############## Process Input Data #################
    	processInputFiles(options, groupedAVPs)	

    	########### Show subscriber (and device, session) data ###################
#    	showData(externalId = subExternalId)

	# If an IP address was specified, then we may loop to keep processing things
	if ReprocessFlag:
		# If a time specified then sleep for that time
		if options.time:
			time.sleep(options.time)
			ans = 'y'
		else:
			# prompt to continue
			print('Press Enter key to process from last point; enter "n" to terminate: ')
			ans = str(input())
			
			# Set flag to not processed output data
			outputHeaderFlag = False
			
	else: ans = 'n'

if __name__ ==  '__main__':
    main()


#==========================================================

def main():
    x = 1


if __name__ == '__main__':
    main()

#===============================================================================
#
# Copyright 2011,2012, Matrixx Software, Inc. All rights reserved.
#
#===============================================================================

