#!/usr/bin/python

# System imports
from __future__ import print_function
# from builtins import str
import sys, os
from datetime import datetime

# Primtives
from primitives import primGeneric as GENERIC
from primitives import cbRestPrim as CB

# Service specific imports
#from normalizerImportData from rest_tools import *
from normalizerImportData import import_prims as PRIM
from normalizerImportData import normalizer_file_analysis as NORM
from normalizerImportData import rest_get_apis as GET
from normalizerImportData import rest_normalizer_apis as RNORM

#===============================================================================
def sanityCheckInputs(options, lclConfigFile):
    # Date could be input via command line or via the local config file.
    # Command line has priority.
    if not options.date:
	# See if in the config file
	if 'date' in lclConfigFile['Params']: options.date = lclConfigFile['Params']['date']
	else:
    		# No date specified, default to today
	        date = datetime.now()
        	options.date = str(date.year) + '-' + str(date.month).zfill(2) + '-' + str(date.day).zfill(2) + 'T00:00:00'
	        print('No date entered.  Using today\'s date (midnight)')
    print('Revision time will be: ' +  options.date)
    
    # Default parameters
    for pair in [('Action', 'Replace'), ('AllowNewValues', '1'), ('ResultRetainCount', '0'), ('ValueRetainCount', '0'), ('ResultModifyFlag', '0'), ('Header', '0')]:
    	(parameter, defaultValue) = pair
    	if parameter not in lclConfigFile['Params']:
		print('WARNING: no "' + parameter + '" parameter specified.  Defaulting to "' + defaultValue + '"')
		lclConfigFile['Params'][parameter] = defaultValue
    
    # If a delta, then the retain flags should be 0
    action = 'Delta'
    if (lclConfigFile['Params']['Action'] == action):
	for parameter in ['ResultRetainCount', 'ValueRetainCount']:
		if lclConfigFile['Params'][parameter] != '0':
			print('WARNING: "' + parameter + '" is set above 0 and that has no meaning with an action of "' + action + '" as all will be retained.  Ignoring.')
			lclConfigFile['Params'][parameter] = '0'
    
    # If a new, then the allow flag should be 1
    action = 'New'
    if (lclConfigFile['Params']['Action'] == action):
	for parameter in ['AllowNewValues']:
		if lclConfigFile['Params'][parameter] != '1':
			print('WARNING: "' + parameter + '" is not set and that has no meaning with an action of "' + action + '".  Ignoring.')
			lclConfigFile['Params'][parameter] = '1'
    
#===============================================================================
def main():
    global ipToMccValueList
    global ipToMccResultsList
    global mccToCountryCodeValueList
    
    warnCount = None
    
    ########### Command line processing ###################
    options = PRIM.cmdLineInput()
    
    ############## Open warning, debug files #################
    (d, w) = PRIM.openWarningAndDebugFiles(options)
    
    ########### Read primitives config file ####################
    servicesConfig = GENERIC.getConfig(options.configFile)
    
    ########### Read local config file ###################
    lclConfigFile = GENERIC.getConfig(options.lclConfigFile)
    
    # Sanity check the inputs
    sanityCheckInputs(options, lclConfigFile)

    ############## Login to CB #################
    CB.cbLogin(servicesConfig)
    
    ################ Read Normalizers ####################
    normDct = NORM.readNormalizers(options, servicesConfig, lclConfigFile)
#    print 'normDct:'
#    CB.cbPrintNormalizer(normDct['object'])
    
    ################ Process Normalizer file ####################
    # What to do depends on if there's a specific set of data input
    if 'MccToCcNormalizerId' in lclConfigFile['Params']:
    	(warnCount, resultDct) = NORM.processMccMncCcIpInput(options, d, w, lclConfigFile)
	
	# Multiple dictionaries to print
    	print('MccToCcNormalizerId:')
	CB.cbPrintNormalizer(resultDct['object'])
	
    	print('IpToMccNormalizerId:')
	CB.cbPrintNormalizer(NormalizerData['IpToMccNormalizerId']['object'])
	
    else:
	# Process the file
	(normDct, resultDct) = NORM.processGenericInput(options, d, w, lclConfigFile)
#	print 'results: ' + str(resultDct)
    	
	# Create generic normalizer
	payload = RNORM.buildGenericNormalizer(normDct, resultDct, options, lclConfigFile)
	
	# Write it to the CB
#	print 'Normalizer ID ' + lclConfigFile['Params']['NormalizerId'] + ' payload:'
#	print payload
	# What to send depends on new versus updating
	if lclConfigFile['Params']['Action'] != 'New':
		stdOut = CB.runCbRestCmd(servicesConfig, url = 'Normalizer/Ccd/' + lclConfigFile['Params']['NormalizerId'], operation = 'PUT', payload = payload)
	else:	stdOut = CB.runCbRestCmd(servicesConfig, url = 'Normalizer/Ccd', operation = 'POST', payload = payload)
	
#	print 'CB command response: '
#	print str(stdOut)
	
    ############## Logout from CB #################
    CB.cbLogout(servicesConfig)
    
    # Skip the rest of this (old stuff; keeping around just because...)
    sys.exit('Exiting Early')
    
    ##########                                                ########
    ##########    Completed processing the raw data.          ########
    ##########    Start creating new pricing files.           ########
    ##########                                                ########
    
    ############## Build MCC to Zone Normalizer File #################
    if 'MccToZoneNormalizerId' in lclConfigFile['Params']:
	payload = RNORM.buildMccTtoZoneNormalizer(None, NORM.ipToMccValueList, program, options)
	
	# Write it to the CB
	stdOut = CB.runCbRestCmd(servicesConfig, url = 'Normalizer/Ccd/' + lclConfigFile['Params']['NormalizerId'], operation = 'PUT', payload = payload)
	
#	print 'CB command response: '
#	print str(stdOut)
	
    ############## Build MCC to Country Code Normalizer File #################
    if 'MccToCCNormalizerId'   in lclConfigFile['Params']: RNORM.buildMccTtoCcNormalizer(GET.CountryCodeNormalizerList, NORM.mccToCountryCodeValueList, program, options)
    
    ############## Build IP to MCC Normalizer File #################
    if 'IpToMccNormalizerId'   in lclConfigFile['Params']: RNORM.buildIpTtoMccNormalizer(NORM.ipToMccValueList, NORM.ipToMccResultsList, program, options)
    
    # If any warnings, then output to std out that they should look in the warning file
    warnFile = 'warnings'
    if warnCount: print('This run produced warnings.  Please review file "' + warnFile + '" to see what was flagged.')
    else: GENERIC.runCmd('rm -f ' + warnFile)

    ############## Logout from CB #################
    CB.cbLogout(servicesConfig)
    
if __name__ ==  '__main__':
    main()



