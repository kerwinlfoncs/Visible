#!/usr/bin/python
from __future__ import print_function
from __future__ import absolute_import
from future import standard_library
standard_library.install_aliases()
# from builtins import str
# from builtins import range
import sys, os, copy
from subprocess import call
from .rest_tools import *
from . import import_prims as PRIM
try:
    import configparser
except:
    from six.moves import configparser
from . import rest_price_component_apis as PC

global OfferDct
global ApnNormalizerDct
global ZoneNormalizerDct
global CountryCodeNormalizerDct
global CountryCodeNormalizerList
global DataServicesDct

global ApnNormalizerId
global ZoneNormalizerId
global CcNormalizerId
ApnNormalizerId = 0
ZoneNormalizerId = 0
CcNormalizerId = 0

# Initialize global data to be dictionaries
OfferDct = {}
ApnNormalizerDct = {}
ZoneNormalizerDct = {}
CountryCodeNormalizerDct = {}
DataServicesDct = {}

#===============================================================================
# Generic function to check the REST call result for success and exit if failed
def checkForRestCallError(program, dctName):
    # Check result code for failure
    if program.props[dctName+'.Result'] != '0':
        print('ERROR: query command with ID ' + dctName + ' failed.  Result code and result text are: ' + program.props[dctName+'.Result'] + ', "' + program.props[dctName+'.ResultText'] + '"')
        sys.exit("Exit due to error")


#===============================================================================
# This function will login to the CB server
# Old way...
def cbLogin():
    # Get Catalog Builder data needed for web call (environment variables or defaults)
    ipAddress = os.path.expandvars('$CatalogBuilderHost')
    if not ipAddress: ipAddress = 'localhost'

    port = os.path.expandvars('$CatalogBuilderPort')
    if not port: port = '8080'

    userName = os.path.expandvars('$CatalogUserName')
    if not userName: userName = 'guest'

    pswd = os.path.expandvars('$CatalogPassword')
    if not pswd: pswd = 'guest'

    #domain = os.path.expandvars('$pricingdomain')
    #if not domain: domain = 'Functional_Tests'
    # Hard-code to debug domain
    domain = 'swisscom_import_export_testing'

    # Remove old tool files
    PRIM.runCmd('rm cookies* login* body* query* >/dev/null 2>&1')

    # Login (required so we can get the data)
    cmd='curl -c cookies.txt http://' + ipAddress + ':' + port + '/matrixx/data/objects/login?username='+ userName + '\&password=' + pswd+ '\&domain=' + domain
    print('Executing command: ' + cmd)
    PRIM.runCmd(cmd)

#===============================================================================
# A slick way to read a parameter within a section of a config file
def ConfigSectionMap(Config, section):
    dict1 = {}
    options = Config.options(section)
    for option in options:
        try:
            dict1[option] = Config.get(section, option)
            if dict1[option] == -1:
                DebugPrint("skip: %s" % option)
        except:
            print("exception on %s!" % option)
            dict1[option] = None
    #print 'dict1 = ' + str(dict1)
    return dict1

#===============================================================================
# This function sets up parameters such that one can connect to a server using REST calls
def setupHttpConnection(config):
    # Read config file
    Config = configparser.ConfigParser()
    Config.read('/opt/mtx/services/config/config_primitives.ini')
    
    # Get key data from config file
    hostname = config['CB']['hostname']
    hostport = config['CB']['hostport']
    username = config['CB']['username']
    password = config['CB']['password']
    domain   = config['CB']['domain']
    baseString = config['CB']['baseString']
    
    # Build arguments for login call
    #hostArg = "-host:" + os.path.expandvars('$CatalogBuilderHost')
    #portArg = "-port:" + os.path.expandvars('$CatalogBuilderPort')
    hostArg = "-host:" + hostname
    portArg = "-port:" + hostport
    args    = ["-base:"+baseString, hostArg, portArg]

    # Debug output
    print('args = ' + str(args))
    print('CB data: username = "' + username + '", password = ' + password + '", domain = ' + domain + '"')
    
    # Initialize objects and HTTP connection
    program = RestTest()
    program.main(args)
    program.connect()

    # Return key data
    return program

#===============================================================================
# This function logs into the server (pogram input parameter) using the credentials passed in
def cbLogin2(program, username, password, domain):
    # Login
    rsp = program.get("/login?username=" + username + "&password=" + password + "&domain=" + domain)

    # Parse the response into a dictionary
    program.parse(rsp)

    # Check for success/failure
    dctName = 'LoginResponse'
    checkForRestCallError(program, dctName)

    #print "Login command succeeded"
    #print str(rsp.toxml())
    return 

#===============================================================================
# This function will retrieve data services information
def getCurrentDataServicesDct(program, debugFd=None, warnFd=None):
    global DataServicesDct

    # This is the data services ID
    serviceId = '2'

    # Query the normalizer.  Use "default" in the path so we get the descriptions included in the response.  [Using "Ccd" only returns the name...]
    #rsp = program.get("/Normalizer/Zone/" + normalizer)
    program.props = {}
    rsp = program.get("/ServiceType/beats/" + serviceId)
    #print "GET of service ID " + serviceId + " succeeded"

    # Parse the response into a dictionary
    program.parse(rsp)
    print(str(program.props))

    sys.exit()
    
    # Go through the entire list.  Want something that's per APN
    #for i in range(10000):
#===============================================================================
# This function will process the XML file associated with the Zone Normalizer.
def getCurrentZoneNormalizerDct(program, debugFd=None, warnFd=None, id=None):
    # Get normalizer ID
    if id:      normalizer = id
    else:       normalizer = ZoneNormalizerId
    
    # If a supported call, then use name, else use "default"
    normType = 'Zone'
#   normType  'default'
    
    # Query the normalizer
    program.props = {}
    rsp = program.get("/Normalizer/" + normType + "/" + normalizer)
    #print str(rsp.toxml())

    return rsp

#===============================================================================
# This function will process the XML file associated with the Zone Normalizer.
def processCurrentZoneNormalizerDct(program, rsp, warnFd=None):
    global ZoneNormalizerDct

    # Clear global to store data in
    ZoneNormalizerDct = {}
    
    # Parse the response into a dictionary
    program.parse(rsp)
    #print 'Zone Normalizer response: '
    #print str(program.props)
    #sys.exit('Early Exit')

    # Go through the entire list.  Want something that's per APN
    for i in range(10000):
	# If this entry doesn't exist, then we're done
	dctName = 'ZoneNormalizer.ValueList.value[' + str(i) + ']'
# default call: dctName = 'object.normalizer.values.value[' + str(i) + ']'
	if dctName+'.name' not in program.props: 
		print('Queried ' + str(i) + ' Zone normalizer values')
		break

	# Get desired values into local variales (readability)
	name = program.props[dctName+'.name']
	id = program.props[dctName+'.id']
	
    	# Debug output
#     	print 'Processing Entry ' + str(i) + ':' + \
#		'\nName: ' + name + \
#		'\nID:   ' + id

        # At this point we should not have a duplicate key...
        if name in ZoneNormalizerDct:
                # Duplicate country code name found - big problem!!
                msg= 'WARNING:  duplicate Zone ID encountered: ' + name + '.  Please contact MATRIXX as this should not occur.'
		print(msg)
		if warnFd: 
			warnFd.write(msg)
		
		# Skip duplicates
                continue

        # If here, then can add the entry
        ZoneNormalizerDct[name] = id

    # Debug output
    #print str(ZoneNormalizerDct)

    return ZoneNormalizerDct
    
#===============================================================================
# This function will process the XML file associated with the APN Normalizer.
def getCurrentApnNormalizerDct(program, debugFd=None, warnFd=None):
    # This is the normalizer ID
    normalizer = ApnNormalizerId

    # Query the normalizer.  
    program.props = {}
    rsp = program.get("/Normalizer/Apn/" + normalizer)
# default call: rsp = program.get("/Normalizer/default/" + normalizer)
    #print "GET of normalizer " + normalizer + " succeeded"

    return rsp
    
#===============================================================================
# This function will process the XML file associated with the APN Normalizer.
def processCurrentApnNormalizerDct(program, rsp, warnFd=None):
    global ApnNormalizerDct

    # Clear global to store data in
    ApnNormalizerDct = {}

    # Parse the response into a dictionary
    program.parse(rsp)
    #print str(program.props)

    # Get normalizer REST name in response
    normRestName = 'ApnNormalizer'
    
    # Get the normalizer name
    dctName = normRestName + '.name'
    if dctName in program.props:	ApnNormalizerDct['normalizerName'] = program.props[dctName]
    else:			       	ApnNormalizerDct['normalizerName'] = 'None'
    print(normRestName + ' Normalizer name: ' + ApnNormalizerDct['normalizerName'])
    
    # Go through the entire list.  Want something that's per APN
    for i in range(10000):
	# If this entry doesn't exist, then we're done
	dctName = normRestName + '.ValueList.value[' + str(i) + ']'
# default call: 	dctName = 'object.normalizer.values.value[' + str(i) + ']'

	if dctName+'.name' not in program.props: 
		print('Queried ' + str(i) + ' APN normalizer values')
		break

	# Get desired values into local variales (readability)
	name = program.props[dctName+'.name']
	id = program.props[dctName+'.id']
	
    	# Debug output
#     	print 'Processing Entry ' + str(i) + ':' + \
#		'\nName: ' + name + \
#		'\nID:   ' + id

        # At this point we should not have a duplicate key...
        if name in ApnNormalizerDct:
                # Duplicate key name found - big problem!!
                msg= 'WARNING:  duplicate APN name ID encountered: ' + name + '.  Please contact MATRIXX as this should not occur.'
		print(msg)
		if warnFd: 
			warnFd.write(msg)
		
		# Skip duplicates
                continue

        # If here, then can add the entry
        ApnNormalizerDct[name] = id

    # Debug output
    #print str(ApnNormalizerDct)

    return ApnNormalizerDct
    
#===============================================================================
# This function will process the XML file associated with a price component
def processCommercialOfferPriceComponentDct(program, id, date):

    # Query the object
    program.props = {}
    rsp = program.get("/Price/default/" + id)
# default call: rsp = program.get("/Price/default/" + id)
    #print "GET of Price Component " + id + " succeeded"

    # Parse the response into a dictionary
    program.parse(rsp)
    #print str(program.props)

    # Process the rate tables returned here
    matrixxRateTableList = []
 
    for j in range(1000):
	# Get pre-set key name
	dctName = 'object.price.rateTables.rateTable[' + str(j) + ']'
	
	# If the ID key is not present, then we have the full list
	if dctName+'.id' not in program.props: break
	
	# Have another rate table; add to the list
	matrixxRateTableList.append(program.props[dctName+'.id'])
	
    # Debug output
    #print 'Price component ' + id + ' rate table list: ' + str(matrixxRateTableList)
    
    # Setup data for call to price component API
    data = {}
    data['date'] = date
    PC.doPriceComponent(program, data, matrixxRateTableList, id)
    
    #sys.exit('Early Exit')

#===============================================================================
# This function will process the XML file associated with the Country Code Normalizer.
def getCurrentCountryCodeNormalizerDct(program, debugFd=None, warnFd=None, id=None):
    # Get normalizer ID
    if id:	normalizer = id
    else:	normalizer = CcNormalizerId

    # Query the normalizer.  
    program.props = {}
    rsp = program.get("/Normalizer/Ccd/" + normalizer)
# default call: rsp = program.get("/Normalizer/default/" + normalizer)
    print("GET of normalizer " + normalizer + " succeeded")

    return rsp

#===============================================================================
# This function will process the XML file associated with the Country Code Normalizer.
def processCurrentCountryCodeNormalizerDct(program, rsp, warnFd=None):
    global CountryCodeNormalizerDct
    global CountryCodeNormalizerList

    # Clear globals
    CountryCodeNormalizerDct = {}
    CountryCodeNormalizerList = []

    # Parse the response into a dictionary
    program.parse(rsp)
    #print str(program.props)
    
    # Get normalizer REST name in response
    normRestName = 'CcdNormalizer'
    
    # Get key normalizer values
    for parameter in ['name', 'id', 'description', 'algorithm', 'datatype', 'type', 'formatNumber']:
	    dctName = normRestName + '.' + parameter
	    if dctName in program.props:	CountryCodeNormalizerDct[parameter] = program.props[dctName]
	    else:			       	CountryCodeNormalizerDct[parameter] = 'None'
    
    # Go through the entire list.  Want something that's per external ID and per ID for dictionaty entries
    for i in range(10000):
	# If this entry doesn't exist, then we're done
	dctName = normRestName + '.ValueList.value[' + str(i) + ']'
# default call: dctName = 'object.normalizer.values.value[' + str(i) + ']'
	if dctName+'.name' not in program.props: 
		print('Queried ' + str(i) + ' CC normalizer values')
		break

	# Get desired values into local variales (readability)
	name = program.props[dctName+'.name']
	id = program.props[dctName+'.id']
	description = program.props[dctName+'.description']
	
    	# Debug output
#     	print 'Processing Entry ' + str(i) + ':' + \
#		'\nName: ' + name + \
#		'\nID:   ' + id + \
#		'\nDesc: ' + description

        # At this point we should not have a duplicate key...
        if name in CountryCodeNormalizerDct:
                # Duplicate country code name found - big problem!!
                msg= 'WARNING:  duplicate country code ID encountered: ' + name + '.  Please check input data as this can not be supported.\n'
		print(msg)
		if warnFd: 
			warnFd.write(msg)
		
		# Skip duplicates
                continue

        # If here, then can add the entry
        CountryCodeNormalizerDct[name] = ((id, description))
        CountryCodeNormalizerList.append((name, id, description))

    # Debug output
    #print str(CountryCodeNormalizerDct)

    return CountryCodeNormalizerDct
    
#===============================================================================
# This function builds a dictionary of offers, keyed on CB ID and external ID; each stores the others' value
def getCurrentOfferList(program, debugFd=None, warnFd=None):
    program.props = {}
    rsp = program.get("/OfferList/default")
    
    return rsp

#===============================================================================
# This function builds a dictionary of offers, keyed on CB ID and external ID; each stores the others' value
def processCurrentOfferList(program, rsp):
    global OfferDct
    
    # Clear global to store data in
    OfferDct = {}
    
    #print str(rsp.toxml())
    
    # Parse the response into a dictionary
    program.parse(rsp)

    # Clear local revision check
    revisionList = {}
    
    # Go through the entire list.  Want something that's per external ID and per ID for dictionaty entries
    for i in range(10000):
	# If this entry doesn't exist, then we're done
	dctName = 'OfferList.Offer[' + str(i) + ']'
	if dctName+'.ID' not in program.props: 
		print('Queried ' + str(i) + ' offers')
		break

	# Get desired values into local variales (readability)
	cbId = program.props[dctName+'.ID']
	externalId = program.props[dctName+'.EXTERNAL_ID']
	revision = program.props[dctName+'.REVISION']
	
    	# Debug output
#     	 print 'Processing Entry ' + str(i) + ':' + \
#		'\nID:   ' + cbId + \
#		'\nRev:  ' + revision + \
#		'\ExtId: ' + externalId

        # Revisions how up as separate entries.  We only ever want to see the latest revision of an object.
        if cbId in OfferDct:
        	# Duplicate CB ID found - keep latest revision
		if int(revision) > int(revisionList[cbId]):
			# Get rid of older revision data
	                del OfferDct[OfferDct[cbId]]
        	        del OfferDct[cbId]
		else: continue

        # At this point we should not have a duplicate key...
        if externalId in OfferDct:
                # Duplicate external ID found - big problem!!
                print('ERROR:  duplicate external ID encountered: ' + externalId + '.  Please contact MATRIXX as this should not occur.')
                sys.exit('Exiting due to errors')

    	# Add to offer list.  Two entries: both external ID and CB ID as keys
        OfferDct[cbId] = externalId
        OfferDct[externalId] = cbId

	# Store ID + revision 
	revisionList[cbId] = revision
        
    # Debug output
    #print str(OfferDct)

    # Return offer list
    return OfferDct

if __name__ ==  '__main__':
    main()

