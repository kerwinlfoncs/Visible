#!/usr/bin/python
from __future__ import print_function
# from builtins import str
import sys, os
import optparse
from subprocess import call
from datetime import datetime

#import unicodedata

#===============================================================================
# This function open warning and debug files
def openWarningAndDebugFiles(options):
    ############## Open warning file #################
    # Remove old tool files
    fileToOpen = 'warnings'
    try:
        os.remove(fileToOpen)
    except:
        # Do nothing
        i = 1

    # Open desired file
    w = open(fileToOpen, 'w')

    ############## Open debug file if specified #################
    if options.debug:
    	# Remove old tool files
        fileToOpen = options.debug
    	try:
        	os.remove(fileToOpen)
    	except:
        	# Do nothing
        	i = 1
	
    	# Open desired file
        d = open(fileToOpen, 'w')
    else: d = None

    return d, w
    
#===============================================================================
# This function processes command line inputs
def cmdLineInput():
    ########### Do command line processing ###################
    parser = optparse.OptionParser()
    parser.add_option("", "--debug", action='store', type='string', default=None)
    
    # Options for input data
    parser.add_option("-f", "--inputFile", 		action='store', type='string', 	default='inputData', help = 'Input file that contains the normalzier data to process')
    parser.add_option("-d", "--dirName", 		action='store', type='string', 	default='.',	help = 'Directory where the input file resides')
    
    # Options for local config file
    parser.add_option("-c", "--lclConfigFile", 		action='store', type='string', 	default='lclConfig.ini', help = 'Local config file that contains the input data fields we care about')
    
    # Primitives config file
    parser.add_option("", "--configFile", 		action='store', type='string', 	default='/opt/mtx/services/config/config_primitives.ini', help = 'Primitives config file')
    
    # Can pass in a desired date for revisions
    parser.add_option(""  , "--date",			action='store', type='string', 	default=None,	help = 'Date to use for object revisions')
    
    # Process command line params
    (options, args) = parser.parse_args()

    # Sanity checks
    # If no input directory or filename specified, then error
    if not options.dirName and not options.inputFile:
       	sys.exit('ERROR - no input directory or inputfile specified')

    return options

#===============================================================================
# This function is used to run bash scripts.
def runCmd(cmd):
#    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
#    out = p.stdout.read().strip()
#    return out  #This is the stdout from the shell command
    return call(cmd, shell=True)

#===============================================================================
# This function will encode strings for use in XML strings
def encodeNonPrintableChars(input_str):
    # This doesn't work.  I'm being defeated by (en/de)code items between XML, HTTP, and Unicode.
    # Placeholder for now.
    return input_str
    
    try:
    	output_str = input_str.encode("utf8", 'ignore')
    except:
	# For now, set output to input (dumb).
	output_str = input_str
    
    if output_str != input_str: print('Encoded output string: ' + output_str)
    
    return output_str

#===============================================================================
# This function write a buffer via the REST API
def issueRESTCommand(program, object, id, buffer):
    # Define file to use as body in REST call
    fileToOpen='_x'

    # Remove old tool files
    try:
        os.remove(fileToOpen)
    except:
        # Do nothing
        i = 1

    # Open files for writing
    f = open(fileToOpen, 'w')

    # Write data to file
    f.write(buffer)

    # Execute file flush commands (seeing what looks to be a flush issue)
    f.flush()
    os.fsync(f.fileno())
    f.close

    # Normalizer URLs are absolute; BENEs are relative
    if object.count("Normalizer"): url = object
    else: url = "/" + object + "/basic" 
    #else: url = "/" + object + "/" + object
    
    # read and process body
    filedata = program.read(fileToOpen)

    # If an ID passed in, then it's an update (PUT); else it's a create (POST)
    if id:
#	print 'sending to URL ' + url + "/" + str(id)
        rsp = program.put(url + "/" + str(id), filedata)
        dictItem = 'Update'
    else:
#	print 'sending to URL ' + url
        rsp = program.post(url, filedata)
        dictItem = 'Create'

    # Parse the response into a dictionary
    program.parse(rsp)

    # Check for success/failure
    if dictItem+'Response.Result' not in program.props:
       # No result code returned.  Not good...
       print('ERROR: a ' + dictItem + ' operation to url ' + url + ' did not return a result code.  This is considered a failure.')
       print(str(rsp.toxml()))
       sys.exit('Exiting due to failure')
	
    elif program.props[dictItem+'Response.Result'] != '0':
       print('ERROR: ' + dictItem + " failed for price component " + str(id))
       print(str(rsp.toxml()))
       sys.exit('Exiting due to failure')

    print(dictItem + " of " +  object + " with ID " + program.props[dictItem+'Response.ObjectId'] + " to revision " + program.props[dictItem+'Response.Revision'] + " succeeded")
    #print str(rsp.toxml())

    # Remove temp file
    os.remove(fileToOpen)

    # return object ID
    program.command("-Doid=${"+dictItem+"Response.ObjectId}")
    return program.expand("${oid}")

if __name__ ==  '__main__':
    main()

