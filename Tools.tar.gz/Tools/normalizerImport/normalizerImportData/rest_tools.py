#!/usr/bin/python
# pylint: disable=W0622
#=============================================================================
#
# Copyright 2012,2013, MATRIXX Software, Inc. All rights reserved.
#
#-----------------------------------------------------------------------------
#
# @file
# @author     original: Ed Stitt
# @author     last modified by: $Author: ed.stitt $
# @date       $Date: 2013-01-19 23:30:37 -0800 (Sat, 19 Jan 2013) $
#
# $Id: test_v3_rest.py 11910 2013-01-20 07:30:37Z ed.stitt $
#
# @futurize --stage2 --no-diffs -n -w  : Mon 2021-06-07T15:42:59
#
# @futurize --stage1 --no-diffs -n -w  : Mon 2021-06-07T15:42:59
#
#=============================================================================
from __future__ import print_function
from __future__ import division
from future import standard_library
standard_library.install_aliases()
# from builtins import str
from past.utils import old_div
# from builtins import object
import copy
import os
import os.path
import http.client
#pylint: disable=import-error,multiple-imports
import urllib.request, urllib.parse, urllib.error
import xml.dom.minidom
import sys
import time
import traceback
import re
import socket

#
# Socket wrapper to enable socket.TCP_NODELAY
#
realsocket = socket.socket
def socketwrap(family=socket.AF_INET, type=socket.SOCK_STREAM, proto=0):
    sockobj = realsocket(family, type, proto)
    sockobj.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
    return sockobj
# pylint: disable=W0622
socket.socket = socketwrap
# pylint: disable=W0622

def millis():
    return int(round(time.time() * 1000))

#
# This class is used to interact with the RSGATEWAY.  Methods for performing
# the standard get, put, post, and delete operations are supplied.  The response
# XML is parsed via minidom and returned.
#
class RestClient(object):
    #
    # Conststructor
    #
    def __init__(self, peerHost, peerPort, basePath=None):
        # pylint: disable=W0622
        socket.socket = socketwrap
        # pylint: disable=W0622
        self._peerHost = peerHost
        self._peerPort = peerPort
        if basePath == None:
            self._basePath = '/rsgateway/data'
        else:
            self._basePath = basePath
        self.status = 0
        self.cookie = None
        self.reason = ""
        self.connection = http.client.HTTPConnection(self._peerHost, self._peerPort)
        self.elapsed = 0
        if self._basePath == '/rsgateway/data':
            try:
                services = self.get("/v3")
            except:
                traceback.print_exc(file=sys.stdout)
                raise RuntimeError("unable to connect to the rsgateway name=" + peerHost + " port=" + str(peerPort))
            if services == None:
                raise RuntimeError("unable to connect to the rsgateway")
            if self.getStatus() != 200:
                raise RuntimeError("error getting services from the rsgateway " + self.getReason())

    def getElapsed(self):
        return self.elapsed


    #
    # get the http status code
    #
    def getStatus(self):
        return self.status

    #
    # get the http reason string
    #
    def getReason(self):
        return self.reason

    #
    # perform a REST call and return the response
    #
    def _makeRequest(self, method, resource, payload=None):
        start = millis()
        url = self._basePath + resource
        headers = {}
        if self.cookie != None:
            headers["Cookie"] = self.cookie
	print('Request data: url = ' + url + ', payload = ' + str(payload))
        self.connection.request(method, url, payload, headers)
            # parms = {"xmldata": payload}
            # if url.find("?") > 0:
            #     newurl = url + "&" + urllib.urlencode(parms)
            # else:
            #     newurl = url + "?" + urllib.urlencode(parms)
            # # self.connection.request(method, url)
        response = self.connection.getresponse()
        self.status = response.status
        self.reason = response.reason
        msg = response.read()
        self.elapsed = millis() - start
        cookie = response.getheader("set-cookie")
        if cookie != None and cookie != self.cookie:
            self.cookie = cookie
	print('Returned message: ' + str(response.status) + '/' + str(response.reason))
        obj = xml.dom.minidom.parseString(msg)
        return obj

    #
    # get operation
    #
    def get(self, resource):
        return self._makeRequest("GET", resource)

    #
    # put operation
    #
    def put(self, resource, payload):
        return self._makeRequest("PUT", resource, payload)

    #
    # post operation
    #
    def post(self, resource, payload):
        return self._makeRequest("POST", resource, payload)

    #
    # delete operation
    #
    def delete(self, resource):
        return self._makeRequest("DELETE", resource)

    #
    # close the current connection
    #
    def closeClient (self):
        self.connection.close()

def simplifyPropName(nm):
    data = nm
    idx = data.find(".")
    if idx > 0:
        right = data[idx+1:]
        data = right
    return data

#
# function to set a name/value pair into a dictionary
#
def setprop(props,  name,  value):
    if len(value.strip()) > 0:
        props[name] = value

#
# function to build an array of child node names for an
# xml dom node
#
def buildNames(nodes):
    ret = []
    for child in nodes:
        if (child.nodeType == xml.dom.Node.ELEMENT_NODE):
            if len(child.localName) > 0:
                ret.append(child.localName)
    return ret

#
# function to replace all occurences of 'string replacement' macros
# with their equivalent values.  Understands both %{foo} and ${foo}
# as "macros"
#
def replaceProperties(props, strng):
    data = strng
    idx = data.find("%{" )
    while (idx >= 0):
        idx2 = data.find("}", idx + 2)
        if (idx2 >= idx):
            left = data[0:idx]
            mid = data[idx+2:idx2]
            right = data[idx2+1:]
            data = left + str(props[mid]) + right
        else:
            left = data[0:idx]
            right = data[idx+2]
            data = left + right
        idx = data.find("%{" )
    idx = data.find("${" )
    while (idx >= 0):
        idx2 = data.find("}", idx + 2)
        if (idx2 >= idx):
            left = data[0:idx]
            mid = data[idx+2:idx2]
            right = data[idx2+1:]
            if mid in props:
                data = left + str(props[mid]) + right
            else:
                data = left + right
        else:
            left = data[0:idx]
            right = data[idx+2]
            data = left + right
        idx = data.find("${" )

    return data




class RestTest(object):
    def __init__(self):
        self.templates = {}
        self.client = None
        self.response = None
        self.props = {}
        self.logStatus = 0
        self.output = None
        self.echo = False
        self.ignoreList = []
        self.timeStampHead = "2012-06-21T08:"
        self.timeStampTail = ".000000-00:00"
        self.useTimestamp = False
        self.simplify = False
        self.noParse = False

    def printdata(self, msg):
        #print msg
        if self.output != None: self.output = open("_query", "w")
        self.output.write(msg + "\n")

    def log(self, msg):
        if self.logStatus > 0:
            print(msg)

    def sameNodeTypes(self, msg):
        ret = False
        name = ""
        nodes = buildNames(msg.childNodes)
        if len(nodes) > 0:
            name = nodes[0]
            for child in nodes[1:]:
                if child == name:
                    ret = True
        if ret:
            self.log("same node types")
        return ret

    def parseNode(self, props, path, msg, name):
        if len(path) > 0:
            curpath = path + "." + name
        else:
            curpath = name
        if msg.nodeType == xml.dom.Node.ELEMENT_NODE:
            if msg.attributes.length > 0:
                i = 0
                while i < msg.attributes.length:
                    attr = msg.attributes.item(i)
                    nm = curpath + "." + attr.name
                    val = attr.value
                    if self.simplify:
                        nm = simplifyPropName(nm)
                    setprop(props,  nm,  val)
                    i = i + 1
        counter = 0
        if not(self.noParse) or msg.childNodes.length < 20:
            for child in msg.childNodes:
                sameType = self.sameNodeTypes(msg)
                suffix = ""
                if (child.nodeType == xml.dom.Node.ELEMENT_NODE):
                    if sameType:
                        suffix = "[" + str(counter )+ "]"
                        counter = counter + 1
                    self.parseNode(props, curpath, child, child.localName + suffix)
                elif (child.nodeType == xml.dom.Node.TEXT_NODE):
                    data = child.data.strip()
                    if len(data) > 0:
                        nm = curpath
                        if self.simplify:
                            nm = simplifyPropName(nm)
                        setprop(props,  nm,  data)

    def parseResponse(self, props, msg):
        self.response = msg
        document = msg.documentElement
        self.parseNode(props, "", document, document.localName)
        if self.echo:
            xmlString = self.response.toxml()
            xmlString = xmlString.replace("><!--", ">\n<!--")
            xmlString = xmlString.replace("--><", "-->\n<")
            xmlString = xmlString.replace("?><", "?>\n<")
            self.printdata(xmlString)

    def getElapsed(self):
        return self.client.getElapsed()


    def get(self, url):
        self.response = self.client.get(url)
        return self.response

    def delete(self, url):
        self.response = self.client.delete(url)
        return self.response

    def put(self, url, filedata=None):
        self.response = self.client.put(url, filedata)
        return self.response

    def post(self, url, filedata=None):
        self.response = self.client.post(url, filedata)
        return self.response

    def readTemplate(self, props, fileName):
        self.log("readTemplate:" + fileName)
        filedata = None
        ret = None
        if hasattr(self.templates, fileName):
            filedata = self.templates[fileName]
        else:
            if fileName != None:
                if (os.path.isfile(fileName)):
                    postfile = open(fileName)
                    filedata = postfile.read()
                    self.templates[fileName] = filedata
                    postfile.close()
        if (filedata != None):
            data = copy.deepcopy(filedata)
            ret = replaceProperties(props, data)
        return ret

    def readFile(self, fileName):
        self.log("readFile:" + fileName)
        filedata = None
        if hasattr(self.templates, fileName):
            filedata = self.templates[fileName]
        else:
            if fileName != None:
                if (os.path.isfile(fileName)):
                    postfile = open(fileName)
                    filedata = postfile.read()
                    postfile.close()
        return filedata

    def writeFile(self, fileName, filedata):
        self.log("writeFile:" + fileName)
        if fileName != None:
            postfile = open(fileName, "w")
            postfile.write(filedata)
            postfile.close()

    def readResponse(self, msg):
        props = {}
        document = msg.documentElement
        self.simplify = True
        self.parseNode(props, "", document, document.localName)
        return props

    def connect(self):
        if (self.client == None):
            if ("base" not in self.props):
                self.client = RestClient(self.props["host"], self.props["port"])
            else:
                self.client = RestClient(self.props["host"], self.props["port"], self.props["base"])
    def read(self, fileName):
        filedata = self.readTemplate(self.props, fileName)
        return filedata

    def parse(self, xml):
	self.props = {}
        self.parseResponse(self.props, xml)

    def processCommand(self, props, command):
        self.connect()
        idx1 = command.find(":")
        if idx1 >= 0:
            cmd = 1
            if "#" in props:
                cmd = int(props["#"])
            minutes = int(old_div(cmd, 60))
            sec = cmd % 60
            minStr = str(minutes).zfill(2)
            secStr = str(sec).zfill(2)
            tsStr = self.timeStampHead + minStr + ":" + secStr + self.timeStampTail
            props["sys$ts"] = tsStr
            method = command[0:idx1]
            url = command[idx1+1:]
            fileName = None
            idx2 = command.find(":", idx1 + 1)
            filedata = None
            if (idx2 >= 0):
                url = command[idx1+1:idx2]
                fileName = command[idx2+1:]
            if self.useTimestamp:
                if (url.rfind("?") > 0):
                    url = url + "&timestamp=" + tsStr
                else:
                    url = url + "?timestamp=" + tsStr
            xmlString = ""
            outfile = open("output_" + str(cmd) + ".txt", "w")
            try:
                if (method == "get"):
                    self.parseResponse(props, self.get(url))
                    cmd = cmd + 1
                elif (method == "delete"):
                    self.parseResponse(props, self.delete(url))
                    cmd = cmd + 1
                elif (method == "put"):
                    filedata = None
                    if fileName != None:
                        filedata = self.readTemplate(props, fileName)
                    self.parseResponse(props, self.put(url, filedata))
                    cmd = cmd + 1
                elif (method == "post"):
                    filedata = self.readTemplate(props, fileName)
                    self.parseResponse(props, self.post(url, filedata))
                    cmd = cmd + 1
                else:
                    print("Invalid command '" + command + "'")
                    print("Commands are:")
                    print("    get:<url>")
                    print("    delete:<url>")
                    print("    put:<url>[:<filename>]")
                    print("    post:<url>[:<filename>]")
                    print("filename is optional, but ALMOST always required by the REST service being invoked")
                xmlString = self.response.toxml()
                xmlString = xmlString.replace("><!--", ">\n<!--")
                xmlString = xmlString.replace("--><", "-->\n<")
                xmlString = xmlString.replace("?><", "?>\n<")
            except:
                print("Caught exception")
                traceback.print_exc(file=sys.stdout)

            setprop( props, "#", str(cmd))
            outfile.write(xmlString + "\n")
            outfile.close()
        else:
            print ("Error: invalid command '" + command + "'  All commands follow the convention m:u[:d]")
            print ("    where m is a method (get, put, post, delete)")
            print ("    where u is a URL (/v3/subscriberselete)")
            print ("    where d is a file to post")

    def dump(self, props, val=None):
        if val == None:
            self.printdata("    Property Pool\n    ========================================")
        keys = sorted(props.keys())
        for key in keys:
            ignore = False
            for item in self.ignoreList:
                if item.match(key):
                    ignore = True
                    break
            if ignore:
                if val == None:
                    self.printdata("    " + key + " = **skipped**")
                elif key.startswith(val):
                    self.printdata("    " + key + " = **skipped**")
            else:
                if val == None:
                    self.printdata("    " + key + " = " + str(props[key]))
                elif key.startswith(val):
                    self.printdata("    " + key + " = " + str(props[key]))

    def processOption(self, props, arg, val):
        if (arg.startswith("-D")):
            idx = arg.find("=")
            if (idx >= 0):
                setprop(props,  arg[2:idx],  arg[idx+1:])
            else:
                print ("Usage error, -D switch expects -Dparm=value")
        elif (arg == "-dump"):
            self.dump(props, val)
        elif (arg == "-simplify"):
            self.simplify = True
        elif (arg == "-clear"):
            if len(val) == 0:
                self.props = {}
            else:
                search = re.compile(val)
                keys = list(props.keys())
                for key in keys:
                    if key.startswith(val):
                        del props[key]
                    elif search.match(key):
                        del props[key]
        elif (arg == "-ignore"):
            if len(val) > 0:
                search = re.compile(val)
                self.ignoreList.append(search)
        elif (arg == "-host"):
            props["host"] = val
        elif (arg == "-base"):
            props["base"] = val
        elif (arg == "-port"):
            props["port"] = val
        elif (arg == "-echoon"):
            self.echo = True
        elif (arg == "-echooff"):
            self.echo = False
        elif (arg == "-timestamp"):
            if val == "true":
                self.useTimestamp = True
            else:
                self.useTimestamp = False
        elif (arg == "-print"):
            xmlString = self.response.toxml()
            xmlString = xmlString.replace("><!--", ">\n<!--")
            xmlString = xmlString.replace("--><", "-->\n<")
            xmlString = xmlString.replace("?><", "?>\n<")
            self.printdata(xmlString)
        elif (arg == "-format"):
            if (val != None):
                formatFile = open(val, "r")
                formatData = replaceProperties(props, formatFile.read())
                formatFile.close()
                self.printdata(formatData)
        elif (arg == "-log"):
            self.logStatus = 1
        elif (arg == "-noparse"):
            self.noParse = True
        elif (arg == "-output"):
            if self.output != None:
                self.output.close()
            self.output = open(val, "w")
        elif (arg == "-out"):
            xmlString = self.response.toxml()
            xmlString = xmlString.replace("><!--", ">\n<!--")
            xmlString = xmlString.replace("--><", "-->\n<")
            xmlString = xmlString.replace("?><", "?>\n<")
            self.printdata(xmlString)

    def processArg(self, props, arg):
        arg = replaceProperties(props, arg)
        if (arg.startswith("#")):
            self.log(arg)
        elif (arg.startswith("?")):
            self.printdata(arg[1:])
        elif (arg.startswith("'")):
            self.printdata(arg[1:])
        elif (arg.startswith("-")):
            switch = arg
            value = None
            idx = arg.find(":")
            if (idx >= 0):
                switch = arg[0:idx]
                value = arg[idx+1:]
            self.processOption(props, switch, value)
        elif (arg.startswith("@")):
            fileName = arg[1:]
            if (os.path.isfile(fileName)):
                cmdfile = open(fileName)
                line = cmdfile.readline()
                while line != "":
                    line = line.strip()
                    if (len(line) > 0):
                        self.processArg(props, line)
                    line = cmdfile.readline()
            else:
                print("Command file " + arg + " does not exist")
        else:
            self.processCommand(props, arg)

    def expand(self, arg):
        ret = replaceProperties(self.props, arg)
        return ret

    def processArgs(self, props, args):
        for arg in args:
            self.processArg(props, arg)

    def command(self, args):
        self.processArg(self.props, args)

    def main(self, args):
        self.props = {"host":"localhost", "port":8080, "base":"/rsgateway/data"}
        self.processArgs(self.props, args)
        if self.output != None:
            self.output.close()

if __name__ == "__main__":
    arguments = sys.argv[1:]
    program = RestTest()
    program.main(arguments)

