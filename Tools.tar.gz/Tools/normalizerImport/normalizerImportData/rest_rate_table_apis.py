#!/usr/bin/python
from __future__ import print_function
from __future__ import absolute_import
# from builtins import str
# from builtins import range
import sys, os, time
from subprocess import call
from .rest_tools import *
from . import rest_get_apis as GET
from . import import_prims as PRIM

#===============================================================================
# This function manages the creation and writing of a rate table
def doRateTable(program, beneData, rtType = None, zeroCharge=False):
    # First need to check if there's any entries of the desired type
    if not rtType: 
	print('WARNING: must call doRateTable with a type of rate table to processes.')
	return 0
    
    # Assume no breaking out of loop
    breakFlag = False
    for i in range(len(beneData['rows'])):
	# See if we found the type of entry we're looking for
        if rtType in beneData['rows'][str(i)]: 
		# Found it.  Set flag and break out
		breakFlag = True
		print('Customer ' + beneData['custCode'] + ' has data of type ' + rtType)
		break
    
    # If we did not break, then nothing to do
    if not breakFlag: return 0
    
    # **** If here,then we need to create a rate table ****
    # Always create rate tables
    id = 0
    
    # Offers will have all new rate tables
    # Offers will have all new rate tables
    name = rtType + ' matrix'
    if zeroCharge: name += ' Free'
    else:          name += ' Charged'
    body = makeRateTableHeader(name, zeroCharge=zeroCharge)
    print('Will create rate table: ' + name)

    # Add normalizers involved
    body += addNormalizersToRateTable(beneData['rows'], rtType)

    # Add rate table rows
    (foundFlag, line) = addRateTableRows(beneData['rows'], rtType, zeroCharge)

    # If we added any rows to this rate table, then finish the definition and add to the CB
    if foundFlag:
        # Add data to the overall rate table body
        body += line

        # Close up the rate table
        body += makeRateTableFooter()
    
    	# Issue REST command
    	oid = PRIM.issueRESTCommand(program, 'Matrix', id, body)
    else:
        # No rate table to add here
        oid = None
    
    return oid

#===============================================================================
# This function creates a rate table header
def makeRateTableHeader(name, id=0, date=None, zeroCharge=False):

    # Write static start of the object
    line = '''<?xml version="1.0" encoding="UTF-8"?>
<Matrix name="'''
    line += name + '" eventTypeId="2">'

    # Build header information.  Depends on create vs update.
    # Default values don;t matter, other than beat can be overridden (required to be true).
    if not id:
        # What balance to impact depends on the zero charge setting
        if zeroCharge:  line +='''
  <balance id="90259" class="90122" balance_units="bytes"/>'''
        else:           line +='''
  <balance id="90208" class="756" balance_units="none"/>'''

        # Finish common part
        line +='''
  <defaultbeat id="1" override="true"/>
  <formula intercept="1.0000" slope="1.0000" multiple="1.0000" units="kbytes" beat_name="30 kbytes" beatid="3"/>'''
    
    # Return data
    return line
    
#===============================================================================
# This function creates a rate table footer
def makeRateTableFooter():
    # Build end of file information
    line='''
</Matrix>'''

    # Return data
    return line
    
#===============================================================================
# This function adds a rate table row
def addRateTableRows(rowsDct, rtType, zeroCharge):
    # Set flag to nothing found
    foundFlag = False
    
    # Add row list start line
    line='\n  <RowList>\n'

    # See which nornmalizers are needed
    for i in range(len(rowsDct)):
	# Filter out only those that we want to process on this instance
	if rtType not in rowsDct[str(i)]: continue
	
	# Add the row start characters
	line2 = '    <row>\n'
	
	# Process normalizer values
	string = 'ApnNormValue'
	normId = GET.ApnNormalizerId
	if string in rowsDct[str(i)]: 
#		print 'APN Normalizer list:'
#		print str(GET.ApnNormalizerDct)
		# Set locals (much easier to understand)
		value_name = rowsDct[str(i)][string]
		value_index = GET.ApnNormalizerDct[value_name]
		
		# Add normalizer line
		line2 += '      <normalizer_value id="' + normId + '" value_index="' + value_index + '" value_name="'+ value_name + '"/>\n' 
	
	string = 'ZoneNormValue'
	normId = GET.ZoneNormalizerId
	if string in rowsDct[str(i)]: 
#		print 'Zone Normalizer list:'
#		print str(GET.ZoneNormalizerDct)
		# Set locals (much easier to understand)
		value_name = rowsDct[str(i)][string]
		value_index = GET.ZoneNormalizerDct[value_name]
		
		# Add normalizer line
		line2 += '      <normalizer_value id="' + normId + '" value_index="' + value_index + '" value_name="'+ value_name + '"/>\n' 
	
	string = 'CountryNormValue'
	normId = GET.CcNormalizerId
	if string in rowsDct[str(i)]: 
#		print 'CC Normalizer list:'
#		print str(GET.CountryCodeNormalizerDct)
		# Set locals (much easier to understand)
		value_name = rowsDct[str(i)][string]
		value_index = GET.CountryCodeNormalizerDct[value_name][0]
		
		# Add normalizer line
		line2 += '      <normalizer_value id="' + normId + '" value_index="' + value_index + '" value_name="'+ value_name + '"/>\n' 
	
	# Build build the formula row
	beatAmount = rowsDct[str(i)]['beatAmount']
	beatUnit = rowsDct[str(i)]['beatUnit']
	multiple = rowsDct[str(i)]['numberOfUnits']
        slope = rowsDct[str(i)]['costPerUnits']
	beatId = rowsDct[str(i)]['beatId']
	
        # Add the line iff it's correct for the input zero charge setting
        if (zeroCharge and float(slope) == 0) or (not zeroCharge and float(slope) != 0):
                # Add in the full row
                line += line2
                line += '      <formula intercept="0.0000" slope="' + slope + '" multiple="' + multiple + '" units="mbytes" beat="' + beatAmount + ' ' + beatUnit + '" beatid="' + beatId + '"/>\n'

                # Set flag to signal something found
                foundFlag = True

                # Add row termination lines
                line +='    </row>\n'
	
    # 
    #  <normalizer_value id="1090" value_index="0" value_name="Free"/>
    #  <formula intercept="1.0000" slope="1.0000" multiple="1.0000" units="bytes" beat="1 byte"/>
    
    # Add row list termination lines
    line +='  </RowList>'

    # Return data
    return (foundFlag, line)
    
#===============================================================================
# This function determines the number of normalizers required
def addNormalizersToRateTable(rowsDct, rtType):
	# Assume nothing needed
	apnNeeded = False
	zoneNeeded = False
	ccNeeded   = False

	# See which nornmalizers are needed
	for i in range(len(rowsDct)):
		# Filter out only those that we want to process on this instance
		if rtType not in rowsDct[str(i)]: continue
		if 'ApnNormValue' in rowsDct[str(i)]: apnNeeded = True
		if 'ZoneNormValue' in rowsDct[str(i)]: zoneNeeded = True
		if 'CountryNormValue' in rowsDct[str(i)]: ccNeeded = True
	
	# OK, time to add the needed normalizers into the rate table body.
    	line='''
  <NormalizerList>
'''
	if apnNeeded:  line += '     <normalizer id="' + GET.ApnNormalizerId+ '"/>\n'
	if zoneNeeded: line += '     <normalizer id="' + GET.ZoneNormalizerId+ '"/>\n'
	if ccNeeded:   line += '     <normalizer id="' + GET.CcNormalizerId+ '"/>\n'
	
	# Add end of the section
	line += '  </NormalizerList>'

	# Return data
	return line

#===============================================================================
# This function builds a rate table
def buildFreeUsageRateTable(program, id = 0):
    # Write static beginning of the file.
    line = '''<?xml version="1.0" encoding="UTF-8"?>
<Matrix name="free service" eventTypeId="2">'''

    # Build header information
    if not id:
        line +='''
  <balance id="90259" class="90122" balance_units="bytes"/>
  <defaultbeat id="1" override="true"/>
  <formula intercept="1.000" slope="1.0000" multiple="1.0000" units="kbytes" beat_name="30 kbytes" beatid="3"/>'''

    # Build normalizer information
    line +='''
  <NormalizerList>
    <normalizer id="1090"/>
  </NormalizerList>'''

    # Build row information
    line +='''
  <RowList>
    <row>
      <normalizer_value id="1090" value_index="0" value_name="Free"/>
      <formula intercept="0.0000" slope="0.0000" multiple="0.0000" units="kbytes" beat="30 kbytes" beatid="3"/>
    </row>
  </RowList>'''

    # Build end of file information
    line +='''
</Matrix>'''

    # Issue REST command
    oid = PRIM.issueRESTCommand(program, 'Matrix', id, line)

    return oid

if __name__ ==  '__main__':
    main()

