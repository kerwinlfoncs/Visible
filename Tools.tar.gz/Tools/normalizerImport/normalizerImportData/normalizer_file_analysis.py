#!/usr/bin/python
from __future__ import print_function
from __future__ import absolute_import
# from builtins import str
# from builtins import range
import sys, os, copy, pprint
from . import rest_get_apis as GET
from .rest_tools import *
from . import import_prims as PRIM

# Get primitives
from primitives import primGeneric as GENERIC
from primitives import cbRestPrim as CB
from primitives import primHTTP as HTTP
from normalizerImportData import rest_get_apis as RESTGET

global ipToMccValueList
global ipToMccResultsList
global mccToCountryCodeValueList
global NormalizerData

NormalizerData = {}
ipToMccValueList = []
ipToMccResultsList = []
mccToCountryCodeValueList = []

# Define custom country name translation
# Will move to a customer-specific file at some point
customerCountyCodeNameTranslations = {}
customerCountyCodeNameTranslations['Central African Rep.'] = 'Central African Republic'
customerCountyCodeNameTranslations['Congo Democratic Republic'] = 'Democratic Republic Of Congo'
customerCountyCodeNameTranslations['Korea (South)'] = 'South Korea'
customerCountyCodeNameTranslations['Palestinian'] = 'Palestine'
customerCountyCodeNameTranslations['Russian Federation'] = 'Russia'
customerCountyCodeNameTranslations['Saudia Arabia'] = 'Saudi Arabia'
customerCountyCodeNameTranslations['Samoa'] = 'Western Samoa'
customerCountyCodeNameTranslations['Equador'] = 'Ecuador'
customerCountyCodeNameTranslations['Virgin Islands British'] = 'British Virgin Islands'

# Customer word changes (maybe more generic than customer-specific, but keep per-customer for now)
customerWordChanges = {}
customerWordChanges['&'] = 'And'

#===============================================================================
def readNormalizers(options, servicesConfig, lclConfigFile):
    global NormalizerData
    
    name = index = color = id = description = None
    
    # Change ID list to an array
    ids = lclConfigFile['Params']['NormalizerId'].strip().split(',')
    
    # Read normalizer
    for normId in ids:
	# If 0, then we're creating a new normalizer
	if not normId.isdigit(): return None
	
	# Read the normalizer
	NormalizerData[normId] = CB.getNormalizer(servicesConfig, normId)
#	print 'Normalizer ' + str(normId) + ' before processing:'
#    	CB.cbPrintNormalizer(NormalizerData[normId])
    
    	# Create a dictionary of the value names.  These are used a lot, so do that centrally
    	NormalizerData[normId]['valueNames'] = {}
    	for valueItem in NormalizerData[normId]['object']['normalizer']['values']['value']:
		# Each one is a dictionary, with one entry
		valueParamList = valueItem['attrib']
#		print 'Checking valueParamList: ' + str(valueParamList)
		for pair in valueParamList:
			# Separate pair 
			(a,b) = pair
		
			# Set local to this value
			cmd = a + ' = b'
#			print 'cmd: ' + cmd
			exec(cmd)
			
		# Add an entry here
		NormalizerData[normId]['valueNames'][name] = [index, color, id, description]
	
	    	# Print the normalzier
#		print 'Normalizer ' + str(normId) + ' after processing:'
#    	    	CB.cbPrintNormalizer(NormalizerData[normId])
    
    # Return first normalizer data (as usually there's only one)
    return copy.deepcopy(NormalizerData[ids[0]])

#===============================================================================
def addNewValue(normData, value, description, color=None, start=None, end=None):
	# Next index will be the length of the current value list
	index = str(len(normData['object']['normalizer']['values']['value']))
	
	# For now, set the id to the index.  Will address non-sequential items later.
	id = index
	
	# Set color to a fixed value
	if not color: color = '#ffff00'
	
	# Add the value
	normData['valueNames'][value] = [index, color, id, description]
	normData['object']['normalizer']['values']['value'].append({'attrib': [('color', color), ('index', index), ('description', description), ('name', value), ('id', id), ('start', start), ('end', end)]})
	
        # Debug output
        print('NOTE: New value "' + value + '" with description "' + str(description) + '" added at index ' + str(index))

	return normData
#===============================================================================
def translateValue(value):
	# First set to title() behavior
#	value = value.lower().title()
	
	# Translate individual characters/words
	for item in list(customerWordChanges.keys()):
		if value.count(item):
##			print 'Translating item "' + item + '" to" ' + customerWordChanges[item] + '"'
			value = value.replace(item, customerWordChanges[item])
		
	# Replace entire name if it matches
	if value in customerCountyCodeNameTranslations:
#		print 'Translating value "' + value + '" to" ' + customerCountyCodeNameTranslations[value] + '"'
		value = customerCountyCodeNameTranslations[value]
	
	# Return translated value
	return value
	
#===============================================================================
# This function processes generic input data.
# Parameter are expected to be "value" and "data".
def processGenericInput(options, d, w, lclConfigFile):
    global NormalizerData
    
    # Get normalizer ID (for ease of typing)
    id = lclConfigFile['Params']['NormalizerId']
    
    # Debug output
#    pprint.pprint(NormalizerData[id]['object']['normalizer'])
    
    # Default output results
    NormalizerData[id]['results'] = []
    
    # Per-action operations
    parameter = 'ValueRetainCount'
#    print 'In action ' + lclConfigFile['Params']['Action'] + ', checking ' + parameter
    
    # If delta then always retain all of these
    if lclConfigFile['Params']['Action'] in ['Delta']: 
	lclConfigFile['Params'][parameter] = str(len(NormalizerData[id]['object']['normalizer']['values']['value']))
	
    # Want to replace the values as well as the results.
    # No need to keep any values.  Any retained items should not be referenced...
    NormalizerData[id]['valueNames'] = {}
	
    # May want to retain some of the values at the start (e.g. the "unknown" ones)
    retainValue = int(lclConfigFile['Params'][parameter])
    if retainValue > 0:
#	print 'Retaining ' + str(retainValue) + ' results'
		
	# Remove all but the retained items
	NormalizerData[id]['object']['normalizer']['values']['value'] = NormalizerData[id]['object']['normalizer']['values']['value'][0:retainValue]
	
	# Set 'valueNames' dictionary entries for the retained items
	for i,valueItem in enumerate(NormalizerData[id]['object']['normalizer']['values']['value']):
		# Get the attribute list
		valueParamList = valueItem['attrib']
		
		# Look for the name
		for pair in valueParamList:
			(name,value) = pair
			
			# Only want the 'name' parameter
			if name != 'name': continue
			
			# Store name in values name array
			NormalizerData[id]['valueNames'][value] = [str(i), '#ffff00', str(i), 'retained']
			break
	
    else:
	# Wipe clean
	NormalizerData[id]['object']['normalizer']['values']['value'] = []
	
#    print 'Values at end of retain check: ' + str(NormalizerData[id]['object']['normalizer']['values']['value'])
    
    # Look at whether or not to retain results
    parameter = 'ResultRetainCount'
#    print 'In action ' + lclConfigFile['Params']['Action'] + ', checking ' + parameter
    
    # If delta then always retain all of these
    if lclConfigFile['Params']['Action'] in ['Delta']: 
	lclConfigFile['Params'][parameter] = str(len(NormalizerData[id]['object']['normalizer']['results']['result']))
	
    # May want to retain results values
    retainValue = int(lclConfigFile['Params'][parameter])
    if retainValue > 0:
#	print 'Retaining ' + str(retainValue) + ' results'
	
	# Extract the entries
	# KEF: May have a single piece of data, or multiple
	for i in range(retainValue):
		resultItem = NormalizerData[id]['object']['normalizer']['results']['result'][i]
		
		# Set locals as the order returned in the dictionary varies per normalizer type
		exact = index = start = end = value = None
		for j in range(len(resultItem['attrib'])):
			entry = resultItem['attrib'][j][0]
			value = resultItem['attrib'][j][1]
			cmd = entry + ' = "' + value + '"'
#			print 'cmd: ' + cmd
			exec(cmd)
		
		# Rest results to include the count
		NormalizerData[id]['results'].append((index, value, exact, start, end))
	
#    print 'Normalizer value names: '
#    HTTP.printDictionaryLevel(NormalizerData[id]['valueNames'])
    
    # Open input file for reading
    f = open(options.inputFile, 'r')
    
    # Go through each line in the file
    lineCount = 0
    for line in f:
        # Skip lines as configured
        if lineCount < int(lclConfigFile['Params']['Header']):
                lineCount += 1
                continue
	
	# Skip blank lines
	line = line.strip()
	if not line: continue
	
        # We have an item to process.  Separate out key fields in the line.
        lineFields = line.split(lclConfigFile['Params']['delimiter'])
        if options.debug: d.write('Line fields are: ' + str(lineFields) + '\n')
	
	# Read value + result (required) and description (optional)
	for parameter in ['value', 'result', 'description', 'exact', 'start', 'end', 'pattern']:
		if parameter in lclConfigFile['Params']: 
			cmd = parameter + ' = \'' + lineFields[int(lclConfigFile['Params'][parameter])].strip() + '\''
		else:
			cmd = parameter + ' = None'
#		print 'cmd: ' + cmd
		exec(cmd)
	
	# May want to normalize the value name.
	if value: value = translateValue(value)
	if start: start = translateValue(start)
	if end:   end   = translateValue(end)
	
        # If pattern, then address that here
        if pattern:
		# Will end up in result (and code was written for result :-).
		result = pattern
		pattern = None
				
                # Have a range.  Get range start.
                rangePrefix = result.split('-')[0]
		
		# May not have an end range
		if len(result.split('-')) > 1:
	                rangeData = result.split('-')[1]
	
        	        # See if range end is in here
			if len(rangeData.split(' '))> 1:
				# Get range start/end
				rangeEnd = rangeData.split(' ')[-1]
				rangeStart = rangeData.split(' ')[0]
				
				# Pattern components may have different lengths.  Right fill this (since we're looking at numbers)
				if   len(rangeEnd) > len(rangeStart): rangeStart = rangeStart.ljust(len(rangeEnd), '0')
				elif len(rangeEnd) < len(rangeStart): rangeEnd   = rangeEnd.ljust(len(rangeStart), '0')
				
				# Now build the result
				result = rangePrefix + '[' + rangeStart + '-' + rangeEnd + ']*'
			else:	
				result = rangePrefix + rangeData + '*'
		else:
			# Single number. Include all values.
			result += '*'
	
	# See if this is a new "value" entry
	# Use value if defined, else start.
	if value: item = value
	else:     item = start
#	print 'Looking to add item ' + str(item)
	if item not in NormalizerData[id]['valueNames']:
		# There's a config flag to signal whether adds are allowed
		if lclConfigFile['Params']['AllowNewValues'] == '1':
			# Append this value
			NormalizerData[id] = addNewValue(NormalizerData[id], item, description)
		else:
			# Hmmmm.  Didn't find a "value" name in the normalizer data.  This is an error.
			print('ERROR:  Normalizer ' + str(id) + ' didn\'t find a value "name" of "' + item + '" and "AllowNewValues" parameter not set to 1 in the local config file.')
			sys.exit('Exiting due to errors')
			
	# Now store index and result in the results array.
	# Use the "id" field, as that's what the results refer to in their "index" parameter.
	# [Why they don't refer to value's "index" parameter is a curiosity...]
	# NOTE: the data will now always have a value for "value".  When building the normalizer, first see if
	#	start and end are defined.  If so, those take prioity.  They'll be None for normalizers where there is only one value.  
#	print 'Storing result: ' + str(result)
	NormalizerData[id]['results'].append((NormalizerData[id]['valueNames'][item][2], result, exact, start, end))
	
    return NormalizerData[id], copy.deepcopy(NormalizerData[id]['results'])
    
#===============================================================================
# This function processes Mcc Mnc + IP range + country code input data 
def processMccMncCcIpInput(options, d, w, lclConfigFile):
    global ipToMccValueList
    global ipToMccResultsList
    global mccToCountryCodeValueList
    global NormalizerData

    mccMncList = []
    ipRangeProcessedList = []
    warnCount = 0
    newCountry = []
    
    # Get normalizer ID (for ease of typing)
    if 'MccToCcNormalizerId'   in lclConfigFile['Params']:
	MccToCcNormalizerId   = lclConfigFile['Params']['MccToCcNormalizerId']
    	NormalizerData[MccToCcNormalizerId]['results'] = []
    if 'MccToZoneNormalizerId' in lclConfigFile['Params']:
	MccToZoneNormalizerId = lclConfigFile['Params']['MccToZoneNormalizerId']
    	NormalizerData[MccToZoneNormalizerId]['results'] = []
    if 'IpToMccNormalizerId'   in lclConfigFile['Params']:
	IpToMccNormalizerId   = lclConfigFile['Params']['IpToMccNormalizerId']
    	NormalizerData[IpToMccNormalizerId]['results'] = []
    
    # Most calculations use this ID, so put into local for ease of typing
    id = MccToCcNormalizerId
    
    # Create a results entry
    
    # Open input file for reading
    f = open(options.inputFile, 'r')
    
    # Go through each line in the file
    lineCount = 0
    for line in f:
        # Always skip first line (headers)
        if lineCount == 0:
                lineCount += 1
                continue

        # We have an item to process.  Separate out key fields in the line.
        lineFields = line.split(lclConfigFile['Params']['delimiter'])
        if options.debug: d.write('Line fields are: ' + str(lineFields) + '\n')

        # Get key fields.  Remove leading/trailing whitespace for all fields.
	# NOTE: it appears that the library handle encode/decode for us...
        # Encode any HTTP-specific characters for the non-numeric fields.
        # These replacements are:
        # <     ->      &lt;
        # >     ->      &gt;
        # "     ->      &quot;
        # '     ->      &apos;
        # &     ->      &amp;
        # Many more HTTP characters could require conversion (see http://en.wikipedia.org/wiki/List_of_XML_and_HTML_character_entity_references).

        #country     = lineFields[0].strip().replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')
        #countryAbbr = lineFields[1].strip().replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')
        #operator    = lineFields[2].strip().replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')
	for parameter in ['country', 'countryAbbr', 'operator', 'mccField', 'mncField', 'intlDialCode', 'zone', 'ipRange']:
		cmd =  'if parameter in lclConfigFile[\'Params\']: ' + parameter + ' = lineFields[int(lclConfigFile[\'Params\'][parameter])].strip() \n'
		cmd += 'else: ' + parameter + ' = None'
#		print 'processNormalizerFileInput: cmd = ' + cmd
		exec(cmd)
#		cmd = 'print parameter + \' = "\' + str(' + parameter + ') + \'"\''
#		exec(cmd)

	# Sanity check data:  if country is NULL, then exit
	if not country: 
		print('ERROR: no country in line "' + line + '"')
		sys.exit('Exit early')
	
	# If MNC is only one digit, then zero pad it
	if mncField and len(mncField) == 1: mncField = '0' + mncField
	
        # Combine MCC/MNC into one field
	if mccField:	mccMnc = mccField
	else:		mccMnc = ""
	if mncField:	mccMnc += mncField

	# ** Massage country name, as this is the key to everything **
	# Set country to standardized naming convention
        country = lineFields[0].lower().title()
	
	# Want to normalize the country name, as different carriers identify countries differently.
	# First translate individual words, then the entire name
	for item in list(customerWordChanges.keys()):
		if country.count(item): country = country.replace(item, customerWordChanges[item])
		
	# OK, replace entire name if it matches
	if country in customerCountyCodeNameTranslations: country = customerCountyCodeNameTranslations[country]
	
        # Even more fun.  We use the country as a description item.  Some entries have diacritic characters.  Python XML parsing s/w doesn't like these.
        # So change them.  They're only used now for a non-copied description field, so changing them won't cause issues with pricing.
#        oldCountry = country
##        country = PRIM.removeNonPrintableChars(country)

        # Warn if we changed the country
#        if oldCountry != country:
#                w.write('Detected diacritic character in country name "' + oldCountry + '".  Changed to "' + country + '"\n')
#                warnCount += 1

	# Process IP data if range input
	if ipRange:
	        # IP nibbles may have leading zeros.  That's not valid.
        	# Seeing spaces at start/end of entry (not good for us).
	        # Also seeing space in the value (before the mask).
        	# Address each of the above.
		
        	# Start by removing space from the beginning and end, as well as removing any spaces in the middle (spades are bad for IP addresses)
	        ipRange = ipRange.translate(None, ' ')

	        # Get each nibble
        	ipRangeList = ipRange.split('.')
		
	        # Split the last nibble into address and mask
        	ipNibblePlusMask = ipRangeList[3].split('/')
	        ipRangeList[3] = ipNibblePlusMask[0]
        	ipMask = ipNibblePlusMask[1]
		
	        # Unix standard function inet_pton() fails with leading zeros...  Need to remove them from any of the nibbles.
		for i in range(len(ipRangeList)):
	        	if len(ipRangeList[i]) > 1: ipRangeList[i] = ipRangeList[i].lstrip('0')
		
	        # Rebuild the IP range with the modified values
        	ipRange = ipRangeList[0] + '.' + ipRangeList[1] + '.' + ipRangeList[2] + '.' + ipRangeList[3] + '/' + ipMask
		
	        # IP to MCC normalizer: If not already in the list, then add to the list.
        	# Expect a lot of dups here, as there can be multiple IP ranges per MCC/MNC and only want to track one of them here.
	        if not ipToMccValueList.count((operator, mccMnc, countryAbbr, zone)):
        	        # Sanity Check: make sure this is a new MccMnc value.  Otherwise a dup (and we don't support dups of MCC/MNC)
                	if not mccMncList.count(mccMnc): mccMncList.append(mccMnc)
	                else:
        	                # Log to warning file and increment warning counter
                	        w.write('Warning:  enountered duplicate mcc/mnc value ' + str(mccMnc) + '.  Ignore entire entry.\n')
                        	warnCount += 1
	                        # Skip to next entry
        	                continue
			
	                # Debug check
        	        if options.debug: d.write('Appending operator ' + operator + ' with MCC/MNC ' + mccMnc + ' to ipToMccValueList')
			
	                # Store entry
        	        ipToMccValueList.append((operator, mccMnc, countryAbbr, zone))
		
	        # Easy to assume data is presented ordered, but probably not safe.  Go ahead and calculate the index versus assuming it's the current value.
        	# Note that the index needs to be offset by 2 since there are two static entries in this normalizer value list (default, unknown).
	        index = ipToMccValueList.index((operator, mccMnc, countryAbbr, zone)) + 2
		
	        # If this range has already been processed, then don't want to add again.
        	if ipRangeProcessedList.count(ipRange):
                	# Log warning and increment warning count
	                w.write('Warning:  encountered duplicate IP range ' + ipRange + '.  Not adding dup to IP to MCC normalizer\n')
        	        warnCount += 1
		
	        else:
        	        # Add IP range to list
                	ipRangeProcessedList.append(ipRange)
			
	                # Update IP to MCC results item
        	        ipToMccResultsList.append((index, ipRange, operator))
			
			# *** Should be able to get rid of all other data structures besides this one... ***
			# Now store index and result in the results array.
			# The "name" is actually the country code + the operator.  May change that down the road...
			# Use the "id" field, as that's what the results refer to in their "index" parameter.
			name = countryAbbr + '-' + operator
			valueIdx = NormalizerData[IpToMccNormalizerId]['valueNames'][name][2]
			NormalizerData[IpToMccNormalizerId]['results'].append((valueIdx, mccMnc))
	
	                # Debug check
        	        if options.debug: d.write('Added IP range ' + ipRange + ' mapped to MCC/MNC index ' + str(index))
	
	# ** Process country information **
	# First use retrieved data and create a dictionary of the names.
        # If this is a new country, then process it
        if country not in NormalizerData[id]['valueNames']:
                # Append new country only once
		if not newCountry.count((countryAbbr, country, operator, mccMnc, intlDialCode)):
			newCountry.append((countryAbbr, country, operator, mccMnc, intlDialCode))
			print('New Country: ' + str(newCountry[-1]))
		
	else:
		# Processing existing country.
		# Use the "id" field, as that's what the results refer to in their "index" parameter.  [Why they don't refer to value's "index" parameter is a curiosity...]
        	index = NormalizerData[id]['valueNames'][country][2]
		countryDialCode = NormalizerData[id]['valueNames'][country][3]
		
	        # MCC to CC normalizer: If not already in the list, then add to the list
	        if not mccToCountryCodeValueList.count((countryAbbr, mccMnc, operator, index, countryDialCode)):
        	        # Debug check
                	if options.debug: d.write('Appending CC ' + countryAbbr + ' with MCC/MNC ' + mccMnc + ' and operator ' + operator + ' to mccToCountryCodeValueList')

	                # Add to list
        	        mccToCountryCodeValueList.append((countryAbbr, mccMnc, operator, index, countryDialCode))
#			print 'Found country ' + str(country) + ': ' + str(GET.CountryCodeNormalizerDct[country])
			
    # OK, now we have all the data for the various normalizers.
    # Close the file
    f.close()

    # Dump existing and new countries
#    print 'Existing Country data:\n' + str(mccToCountryCodeValueList)
    print('New Country data:\n' + str(newCountry))
    
    # OK, if any new countries found, then need to assign them indices here
    for tuple in newCountry:
	# Get tuple values
	countryAbbr	= tuple[0]
	country		= tuple[1]
	operator	= tuple[2]
	mccMnc		= tuple[3]
	intlDialCode	= tuple[4]
	
	# Only want to add countries once, even though we may add multiple MCC/MNC entries
        if country not in NormalizerData[id]['valueNames']:
		# Index will be the length of the current country list (since that starts at 0 with the undefined entry)
		index = str(len(NormalizerData[id]['valueNames']))
	
		# Track this as a valid country
		NormalizerData[id]['valueNames'][country] = [index, '#ffff00', index, countryAbbr]
		
		NormalizerData[id]['object']['normalizer']['values']['value'].append({'attrib': [('color', '#ffff00'), ('index', index), ('description', countryAbbr), ('name', country), ('id', index)]})
                # Print that we've encountered a new country (FYI)
                print('NOTE: new country found: ' + country + ' with country abbreviation: ' + countryAbbr + ' added at index ' + str(index))

	# MCC to CC normalizer: If not already in the list, then add to the list
	# Get index here, to handle out of order new country values
	index = NormalizerData[id]['valueNames'][country][2]
	if not mccToCountryCodeValueList.count((countryAbbr, mccMnc, operator, index, intlDialCode)):
                # Debug check
               	if options.debug: d.write('Appending CC ' + countryAbbr + ' with MCC/MNC ' + mccMnc + ' and operator ' + operator + ' to mccToCountryCodeValueList')
                print('Appending CC ' + countryAbbr + ' with MCC/MNC ' + mccMnc + ' and operator ' + operator + ' and index ' + index + ' to mccToCountryCodeValueList') 

	        # Add to list
                mccToCountryCodeValueList.append((countryAbbr, mccMnc, operator, index, intlDialCode))
	
    return warnCount, copy.deepcopy(NormalizerData[id])

if __name__ ==  '__main__':
    main()


