#!/usr/bin/python
from __future__ import print_function
from __future__ import absolute_import
# from builtins import str
import sys, os
from . import import_prims as PRIM
from .rest_tools import *
from . import normalizer_file_analysis as NORM
from . import rest_get_apis as GET
from primitives import primHTTP  as HTTP

#===============================================================================
# Build normalizer header
def buildNormHeader(normDct, lclConfig, options):
	defaultValue = None
	
    	# Write static beginning of the file.
	line = '''<?xml version="1.0" encoding="UTF-8"?>
<CcdNormalizer '''
	
	# If we're not creating a new normalizer or it's based on an existing one, then use data that was read.
	if lclConfig['Params']['Action'] != 'New' or ('NormalizerId' in lclConfig['Params'] and lclConfig['Params']['NormalizerId'] != '0'):
		# Add in normalizer definition parameters
		for pair in normDct['object']['normalizer']['attrib']:
			# Separate pair
			(name,value) = pair
			
			# Grab default value, as it's used elsewhere
			# Prioritize 'default' parameter over no_field* parameter
			if name == 'default' or (name == 'no_field_normalization_value' and not defaultValue):
				defaultValue = value
#				continue
			
			# Skip if name not in desired parameter list
			if name not in ['name', 'id', 'description', 'algorithm', 'datatype', 'type', 'formatNumber']: continue
			
			# Only write if not none
			if value.lower() == 'none': continue
			
			# Skip a few parameters
			if name in ['UUID', 'effective_date']: continue
			
			# *** UNTIL I GET THINGS WORKING, only include the name ***
#			if name not in ['name']: continue
			
			# If this is a new normalizer, then use the name value from the config file.
			# NormalizerId should be in the format of base_ID,Name
			if name == 'name' and lclConfig['Params']['Action'] == 'New':
			   try:
				value = lclConfig['Params']['name']
			   except:
				print('ERROR:  Action of "New" requires the normalizer "name" parameter be specified')
				sys.exit('Exiting due to errors')
			
			# Add parameter to the line
			line += name + '="' + encodeForHtml(value) + '" '
	else:
		# New noromalizer, with all new data.
		line += 'correction_number="1" '
		for attrName in ['algorithm', 'datatype', 'formatNumber', 'default', 'type', 'no_field_normalization_value', 'name']:
		    try:
			line += attrName + '="' + encodeForHtml(lclConfig['Params'][attrName]) + '" '
		    except:
			print('ERROR: need to specify all normalizer parameters when creating a new normalizer.  Missing parameter"' + attrName + '"')
			sys.exit('Exiting due to errors')
		
	# Add rest of the static data
    	line += ' > \n'
	
	#print 'buildNormHeader: ' + line[:-1]
	return line, defaultValue
	
#===============================================================================
def buildNormResults(resultDct):
	line = '    <ResultList>\n'
	
	# Process all the results for this normalizer
        for pair in resultDct:
		# Write start of result
		line += '        <result '
		
		# Get the parts
		(index,value,exact, start, end) = pair
		
		# What to add depends on what's defined.
		# Recall that value is always defined.  Need to check that start isn't defined...
		if not start:
			# Add to the line
			line += 'index="' + index + '" value="' + encodeForHtml(value) + '"'
			
			# Add exact value if defined
			if exact: line += ' exact="' + exact + '" '
		else:	line += 'index="' + index + '" start = "' + encodeForHtml(start) + '" end = "' + encodeForHtml(end) + '"'
		
		# Close the value
        	line += '/>\n'
	
    	# End results and normalizer
	line += '    </ResultList>\n'
	
	return line
#===============================================================================
def buildNormValues(normDct, defaultValue):
    	line = "<ValueList default='" + defaultValue + "'> \n"
	
	# Process all existing values
        for valueItem in normDct['object']['normalizer']['values']['value']:
                # Each one is a dictionary, with one entry
                valueParamList = valueItem['attrib']
		
		# Write start of value
		line += '        <value '
		
		# Add the parameters
		for pair in valueParamList:
			# Get data.
			(name,value) = pair
			#print 'buildNormValues: name/value = ' + str(name) + '/' + str(value)
			
			# Parameer may be None (e.g. no description).  Only add if defined.
			if value: line += name + '="' + encodeForHtml(value) + '" '
		
		# Close the value
        	line += '/>\n'

	# End values, start results
	line += '    </ValueList>\n'

	return line
	
#===============================================================================
def encodeForHtml(value):
	# Not sure why I can't simply use the encode() primitive...
	retVal = value.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;').replace('\'', '&apos;')
	retval = PRIM.encodeNonPrintableChars(retVal)
	return retVal
	
#===============================================================================
# This function builds and write a generic normalizer
def buildGenericNormalizer(normDct, resultDct, options, lclConfig):
	# Get the date
	_date = options.date
    	
	# Default the default value
#	defaultValue = '0'
	
	# Build the header
	(line, defaultValue) = buildNormHeader(normDct, lclConfig, options)
	
	# If we're replacing data, then change the default value to 0.
	# Also set to 0 if not defined...
#	if (not defaultValue) or lclConfig['Params']['Action'] == 'Replace: defaultValue = '0'
	if not defaultValue: defaultValue = '0'
	
	# Add misc stuff
    	line += '    	<EffectiveDate>' + _date + '</EffectiveDate> \n'
	
	# Build the values
#	print 'buildGenericNormalizer: Values'
#	HTTP.printDictionaryLevel(normDct)
	line += buildNormValues(normDct, defaultValue)
	
	# Build results
#	print 'buildGenericNormalizer: Results'
#	HTTP.printDictionaryLevel(resultDct)
	line += buildNormResults(resultDct)
	
	# Close things up
	line += '</CcdNormalizer>\n'
	
	print('buildGenericNormalizer:')
	print(line)
    	
	return line
	 
#===============================================================================
# This function builds the MCC to CC Normalizer file
def buildMccTtoCcNormalizer(normDct, resultDct, options):
    	# Get the date
    	_date = options.date
    
    	# This is the normalizer file
    	id = NORM.inputParams['Params']['MccToCcNormalizerId']
	normDct = NormalizerData[id]

	# Default the default value
	defaultValue = '0'
	
	# Build the header
	(line, defaultValue) = buildNormHeader(normDct)
	
	# Add misc stuff
    	line += '    	<EffectiveDate>' + _date + '</EffectiveDate> \n'
	
	# Build the values
	line += buildNormValues(normDct, defaultValue)
	
    	# OK, now build value lines looping through the values data
    	# NOTE: library functiona appears to take care if escaping characters for us :-).
    	# Encode any HTTP-specific characters for the non-numeric fields.
    	# These replacements are:
    	# <     ->      &lt;
    	# >     ->      &gt;
    	# "     ->      &quot;
    	# '     ->      &apos;
    	# &     ->      &amp;
        # Many more HTTP characters could require conversion (see http://en.wikipedia.org/wiki/List_of_XML_and_HTML_character_entity_references).
    	for item in ccList:
        	countryCode = item[0].replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;').replace('\'', '&apos;')
		idx = item[1]
        	country = item[2].replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;').replace('\'', '&apos;')
	
		# Country may have non-ASCII characters.  Need to convert so XML acceptsthem
		country = PRIM.encodeNonPrintableChars(country)
		countryCode = PRIM.encodeNonPrintableChars(countryCode)
	
		# Write the line
	        line += '        <value index="' + str(idx) + '" name="' + str(countryCode) + '" description="' + str(country) + '"/>\n'

    	# OK, now build results lines
    	for item in resultList:
#       	countryCode = item[0].replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')
        	mccMnc      = item[1]
#        	operator    = item[2].replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')
        	index       = item[3]
        	line        += '        <result index="' + str(index) + '" value="' + str(mccMnc) + '" exact="false"/>\n'

		# Convert so XML accepts them
#		operator = PRIM.encodeNonPrintableChars(operator)
#		countryCode = PRIM.encodeNonPrintableChars(countryCode)
		
    	# End results and normalizer
    	line += '    </ResultList>\n</CcdNormalizer>\n'
    
    	print('line:')
    	print(line)
    
    	return line

#===============================================================================
# This function builds the IP to MCC Normalizer file
def buildIpTtoMccNormalizer(valueList, resultList, program, options):
    # Get the date
    _date = options.date
    
    # This is the normalizer file
    normalizer = options.IpToMccNormalizerId

    # Write static beginning of the file.
    line = '''<?xml version="1.0" encoding="UTF-8"?>
<IpMappingNormalizer name="IP to MCC/MNC">
    <EffectiveDate>''' + _date + '''</EffectiveDate>
    <ValueList default='1'>
       <value index="0" name="N/A-Not Present" description="0"/>
       <value index="1" name="N/A-Unknown" description="1"/>
'''

    # OK, now build value lines looping through the values data.
    # Note that for this normalizer, the key item is the description (where the MCC/MNC value is stored).
    # The actual index item won;t ever be used in rating, so go ahead and just make sure it's unique.
    # The Name is just descriptive here (so the reader can better understand what they're looking at).
    idx = 2
    for item in valueList:
        operator = item[0].replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;').replace('\'', '&apos;')
        mccMnc = item[1]
        countryCode = item[2].replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;').replace('\'', '&apos;')
        zone = item[3]
        line += '       <value index="' + str(idx) + '" name="' + str(countryCode) + '-' + str(operator) + '" description="' + str(mccMnc) + '"/>\n'

	# Convert so XML accepts them
        operator = PRIM.encodeNonPrintableChars(operator)
	countryCode = PRIM.encodeNonPrintableChars(countryCode)
	
        # Bump index counter
        idx += 1

    # End values, start results
    # First result is static, so copy here.
    line += '    </ValueList>\n    <ResultList>\n        <result index="0" value="0.0.0.0"/>\n'

    # OK, now build results lines looping through the results data
    for item in resultList:
        index = item[0]
        ipRange = item[1]
        operator = item[2].replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;').replace('\'', '&apos;')

	# Convert so XML accepts them
	operator = PRIM.encodeNonPrintableChars(operator)
	
        line += '        <result index="' + str(index) + '" value="' + str(ipRange) + '"/>\n'

    # End results and normalizer
    line += '    </ResultList>\n</IpMappingNormalizer>\n'
    
    # Debug output
    #print 'IP to MCC body:'
    #print line
    #sys.exit()
    
    # Issue REST command
    oid = PRIM.issueRESTCommand(program, '/Normalizer/IpMapping', normalizer, line)

    return oid

#===============================================================================
# This function builds the MCC to Zone Normalizer file
def buildMccTtoZoneNormalizer(valueList, resultList, program, options):
    # Get the date
    _date = options.date
    
    # This is the normalizer file
    normalizer = options.mccToZoneNormalizerId

    # Write static beginning of the file
    line = '''<?xml version="1.0" ?>
<ZoneNormalizer name="Zone Determination (MCC/MNC)">
    <EffectiveDate>''' + _date + '''</EffectiveDate>
    <ValueList default="0">
        <value index="0" name="Not Present"/>
        <value index="1" name="Zone A"/>
        <value index="2" name="Zone B"/>
        <value index="3" name="Zone C"/>
        <value index="4" name="Zone D"/>
        <value index="5" name="Unknown"/>
        <value index="6" name="Unknown IP Address"/>
        <value index="7" name="Zone B1"/>
        <value index="8" name="Zone B2"/>
    </ValueList>
    <ResultList>
        <result index="0" value="0"/>
        <result index="6" value="1"/>
        <result index="1" value="10"/>
        <result index="7" value="21"/>
        <result index="8" value="22"/>
        <result index="3" value="30"/>
        <result index="4" value="40"/>
'''
    # OK, now build results lines
    for item in resultList:
        operator = item[0].replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;').replace('\'', '&apos;')
        mccMnc = item[1]
        countryCode = item[2].replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;').replace('\'', '&apos;')
        zone = item[3]

	# Convert so XML accepts them
	operator = PRIM.encodeNonPrintableChars(operator)
	countryCode = PRIM.encodeNonPrintableChars(countryCode)
	
        # Index to use is the zone - 'A' + 1
        if zone == 'A':
                index = 1
        elif zone == 'B1':
                index = 7
        elif zone == 'B2':
                index = 8
        elif zone == 'C':
                index = 3
        elif zone == 'D':
                index = 4
        elif zone == '0' or not zone:
                # Dummy entries.  Skip
                continue
        else:
                sys.exit('ERROR:  unknown zone input: ' + zone + '. Exiting.')

        line += '        <result index="' + str(index) + '" value="' + mccMnc + '"/>\n'

    # End results and normalizer
    line += '    </ResultList>\n</ZoneNormalizer>\n'

    # Issue REST command
    oid = PRIM.issueRESTCommand(program, '/Normalizer/Zone', normalizer, line)

    return oid



if __name__ ==  '__main__':
    main()

