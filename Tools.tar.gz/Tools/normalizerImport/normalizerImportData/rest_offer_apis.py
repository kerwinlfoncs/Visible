#!/usr/bin/python
from __future__ import print_function
from __future__ import absolute_import
import sys, os, time
from .rest_tools import *
from . import rest_get_apis as GET
from . import rest_rate_table_apis as RT
from . import rest_price_component_apis as PC
from . import import_prims as PRIM

#=========================== PUT/POST SDK APIs ====================================================
# This function will process an offer request (update or new)
def processOffer(program, beneData):

    # Trace rate table oid values
    rateTableOid = []
    
    # Build free usage rate table (static)
    oid = RT.buildFreeUsageRateTable(program)
    if oid: rateTableOid.append(oid)
    else:
	print('ERROR: Failed in building static rate table.  Something is wrong...')
	sys.exit('Exit due to errors')
    
    # Create and write the country code rate table for this offer (if needed).
    # Separate zero charge from non-zero charge rate tables.
    # [Needed to support setting of "no additional charges" flag and allowing BENE offers to charge $0 for some access.]
    oid = RT.doRateTable(program, beneData, 'CountryNormValue', zeroCharge=True)
    if oid: rateTableOid.append(oid)

    oid = RT.doRateTable(program, beneData, 'CountryNormValue', zeroCharge=False)
    if oid: rateTableOid.append(oid)

    # Create and write the zone/apn rate table for this offer (if needed)
    oid = RT.doRateTable(program, beneData, 'ZoneNormValue', zeroCharge=True)
    if oid: rateTableOid.append(oid)

    oid = RT.doRateTable(program, beneData, 'ZoneNormValue', zeroCharge=False)
    if oid: rateTableOid.append(oid)
    
    # See if we have anything except the free table (in which case we don't do anything)
    if len(rateTableOid) == 1:
	print('No Roaming data entries found for this customer')
	return 0
    
    # Build the one Price component required for this scenario
    priceComponentOid = []
    oid = PC.doPriceComponent(program, beneData, rateTableOid) 
    if not oid:
	print('ERROR: Failed to create a Price Component')
	sys.exit('Exit due to errors')

    # Add to list of OIDs
    priceComponentOid.append(oid)
    
    # Build the offer
    oid = doOffer(program, beneData, priceComponentOid) 
    if not oid:
	print('ERROR: Failed offer REST command')
	sys.exit('Exit due to errors')

    return oid

#=========================================================================
# This function will create/write offer request
def doOffer(program, beneData, priceComponentOid):
    # Priority look-up dictionary
    priority = {2:"200", 3:"210"}
    
    # First see if this is an existing offer
    if beneData['custCode'] in GET.OfferDct:
        id = GET.OfferDct[beneData['custCode']]
        print('Updating offer ID: ' + id)
    else:
        id = 0
        print('Adding a new offer')

    # Offer building is pretty straight-forward, so do inline here
    # Create heading
    name = ' Offer for customer: ' + beneData['custCode']
    line = '<?xml version="1.0" encoding="UTF-8"?>\n<Offer'
    
    # Add details if creating the offer
    if not id:
    	line += ' name="' + name + '"'
    	line += ' external_id="' + beneData['custCode'] + '"'
    	line += ' type="override" priority="' + priority[len(beneData['custCode'].split("."))] + '"'
    
    # Close top line, add deffective date (always)
    line += '>'
    line += '\n<EffectiveDate>' + beneData['date'] + '</EffectiveDate>'
    
    # Add more details if creating the offer
    if not id:
	# Add product info
        line +='''
    <ProductList>
        <Product id="9" />
    </ProductList>'''
    
    	# Add static attribute lista and balance list
    	line += '''
    <AttributeList>
        <attribute code="2" display="2" id="13" lock="false" value="2"/>
    </AttributeList>
    <BalanceImpactList>
    </BalanceImpactList>'''
   
## Removed from above balance impact list
##        <Balance id="90208" class_id="756"/>

    # Add price component header
    line += '\n    <PriceComponentList>\n'
    
    # Loop through input PC list and add each of them
    for oid in priceComponentOid:
        line += '        <PriceComponent id="' + oid + '"/>\n'
    
    # Add price component footer
    line += '    </PriceComponentList>\n'
     
    # Close out the XML body
    line += "</Offer>\n"

    # Debug output
    #print 'Looking to write body: ' + line
    
    # Issue REST command
    oid = PRIM.issueRESTCommand(program, 'Offer', id, line)

    return oid
    

if __name__ ==  '__main__':
    main()

