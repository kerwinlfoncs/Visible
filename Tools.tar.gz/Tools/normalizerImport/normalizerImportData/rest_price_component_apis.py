#!/usr/bin/python
from __future__ import absolute_import
import sys, os
from .rest_tools import *
from . import import_prims as PRIM

#=========================== PUT/POST SDK APIs ====================================================
#===============================================================================
# This function builds a price component
def doPriceComponent(program, beneData, matrixList, id=0):
    # Write static beginning of the file.
    line = '<?xml version="1.0" encoding="UTF-8"?>\n<Price'
    
    # Add name for new object only
    if not id: line += ' name="Charging Price Component"'
    
    # Close top line; add effective date
    line += '>'
    line += '\n<EffectiveDate>' + beneData['date'] + '</EffectiveDate>'

    # Matrix list header
    line +='\n    <MatrixList>\n'
    
    # Add in each rate table in the list
    for mtx in matrixList:
        line += '        <Matrix id="' + mtx +'"/>\n'
    
    # Add closing of matrix list
    line += '    </MatrixList>'

    # Build end of file information
    line +='\n</Price>'

    # Issue REST command
    #print 'PC line: ' + line
    oid = PRIM.issueRESTCommand(program, 'Price', id, line)

    return oid 
    
