#!/usr/bin/python
#===============================================================================
#
# Copyright 2021-2021, MATRIXX Software, Inc. All rights reserved.
#
#-------------------------------------------------------------------------------
#
# @file
# @author     original: Florin-Dan Galan
# @author     last modified by: $Author: mark.germain $
# @author     last modified by:  Patriia Lee
#             fix to skip check of '# $Id' in insertFutureHeader()
# @date       $Date: 2021-06-15 04:06:50 -0400 (Tue, 15 Jun 2021) $
#
# $Id: migrate_python.py 83176 2021-06-15 08:06:50Z mark.germain $
#
# @futurize --stage2 --no-diffs -n -w  : Tue 2021-04-06T16:33:16
#
# @futurizeManager mark.germain : Tue 2021-03-02T12:24:00
# 
#===============================================================================
#
from __future__ import print_function
from builtins import str
import glob
import os
import re
import subprocess
import sys
import time
import fileinput
from argparse import ArgumentParser
import migrate_python_lib as migr_lib

MIGRATE_STAGE_3 = '--stage3'

def checkCommentInFile(fileLines, comment):
    prevLine = ''
    for line in fileLines:
        if comment in unicode(line, 'latin-1'):
            return True
        if '#===============================================================================' in line \
            and '/usr/bin/python' not in prevLine:
            return False
        prevLine = line
    return False

def applyRegularExpression(fileName):
    for _, line in enumerate(fileinput.input(fileName, inplace=1)):
        if '/=' in line:
            tokens = line.split('/=')
            sys.stdout.write(tokens[0].rstrip() + ' = int(old_div(' + tokens[0].strip() + \
                ', ' + tokens[1].strip()  + '))\n')
        elif 'old_div' in line:
            tempLine = ''
            tokens = line.split(',')
            if len(tokens) >= 2:
                for token in tokens:
                    if token == tokens[0]:
                        tempLine += token + ', '
                    elif token == tokens[len(tokens) - 1]:
                        tempLine += token.strip() + '\n'
                    else:
                        tempLine += token.strip() + ', '
                sys.stdout.write(tempLine)
            else:
                sys.stdout.write(line)
        elif 'import urllib.request, urllib.parse, urllib.error' in line:
            sys.stdout.write('#pylint: disable=import-error,multiple-imports\n')
            sys.stdout.write(line)
        else:
            sys.stdout.write(line)

def applyPyLintLineTooLong(fileName):
    for _, line in enumerate(fileinput.input(fileName, inplace=1)):
        if len(line) > 120 and ('#====================' not in line) and \
            ('SPECIAL_CHARS   = COMMA + GREATER_THAN + LEFT_BRACE + LEFT_BRACKET' not in line):
            sys.stdout.write('#pylint: disable=missing-docstring, C0301\n')
            sys.stdout.write(line)
        else:
            sys.stdout.write(line)

def applyOldDivImport(fileName):
    if open(fileName, 'r').read().find('old_div') != -1 and \
        open(fileName, 'r').read().find('from past.utils import old_div') == -1:
        if open(fileName, 'r').read().find('from __future__ import division') != -1:
            for _, line in enumerate(fileinput.input(fileName, inplace=1)):
                if 'from __future__ import division' in line:
                    sys.stdout.write(line)
                    sys.stdout.write('from past.utils import old_div\n')
                else:
                    sys.stdout.write(line)
        elif open(fileName, 'r').read().find('from __future__ import print_function') != -1:
            for _, line in enumerate(fileinput.input(fileName, inplace=1)):
                if 'from __future__ import print_function' in line:
                    sys.stdout.write(line)
                    sys.stdout.write('from past.utils import old_div\n')
                else:
                    sys.stdout.write(line)

def insertFutureHeader(fileName, comment, stage):
    if MIGRATE_STAGE_3 != stage:
        futurize = 'futurize ' + stage
    else:
        futurize = '2to3'
    alreadyHave = False
    fileLines = migr_lib.getFileLines(fileName)
    if checkCommentInFile(fileLines, '@' + futurize) or checkCommentInFile(fileLines, '@fail_' + futurize):
        alreadyHave = True
    for _, line in enumerate(fileinput.input(fileName, inplace=1)):
        if (alreadyHave and (futurize in line)):
            sys.stdout.write('# @' + comment + ' : ' + \
                time.strftime('%a %Y-%m-%dT%H:%M:%S') + '\n')
        elif MIGRATE_STAGE_3 == stage and re.search(r'#!/usr/bin/python', line):
            sys.stdout.write('#!/usr/bin/python3\n')
        elif MIGRATE_STAGE_3 == stage and re.search(r'#!/usr/bin/(env *python)', line):
            sys.stdout.write('#!/usr/bin/env python3\n')
        elif (not alreadyHave) :
            sys.stdout.write(line)
            sys.stdout.write('#\n')
            sys.stdout.write('# @' + comment + ' : ' + \
                time.strftime('%a %Y-%m-%dT%H:%M:%S') + '\n')
            alreadyHave = True
        elif line.startswith('from builtins import '):
            sys.stdout.write('# ' + line)
        else:
            sys.stdout.write(line)

def processFile(baseCmd, fileToProcess, failedToConvertFile=None, stage='--stage3'):
    if not os.path.exists(fileToProcess):
        print('File not found: ' + fileToProcess)
        return
    print('Processing ' + stage + ' : ' + fileToProcess)
    fileLines = migr_lib.getFileLines(fileToProcess)
    if checkCommentInFile(fileLines, '@DoNotMigrate'):
        print('File : ' + fileToProcess + ' has DoNotMigrate tag , ignoring it !!\n')
    elif migr_lib.checkFileInSVN(fileToProcess):
        if (MIGRATE_STAGE_3 == stage and migr_lib.checkStep2Migration(fileLines)) \
            or (MIGRATE_STAGE_3 != stage and not migr_lib.checkStep3Migration(fileLines)):
            futurizeCommand = baseCmd + fileToProcess
            process = subprocess.Popen(futurizeCommand, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            output = process.communicate()[0]
            if 'No files need to be modified' in output:
                output += ' (' + fileToProcess + ')\n'
            # print(output)
            if output.find("error") > 0:
                insertFutureHeader(fileToProcess, 'fail_' + baseCmd, stage)
                if failedToConvertFile:
                    failedToConvertFile.write(fileToProcess + '\n')
            else:
                insertFutureHeader(fileToProcess, baseCmd, stage)
                applyRegularExpression(fileToProcess)
                # applyPyLintLineTooLong(fileToProcess)
                applyOldDivImport(fileToProcess)
        else:
            print('The requested stage : ' + stage + ' migration cannot be applied to: ' + fileToProcess)
            if MIGRATE_STAGE_3 == stage:
                print('    stage3 needs stage2 to have been run first, so requires @futurize --stage2 tag in header')
            else:
                print('    stage1 or stage2 cannot be run after stage3, so rejected if @2to3 tag found in header')
    else:
        print('File : ' + fileToProcess + ' is not in SVN , ignoring it !!')

def processFilesInPath(path, baseCmd, failedToConvertFile, stage):
    for filesInPath in os.walk(path):
        for fileToProcess in glob.glob(os.path.join(filesInPath[0], '*.py')):
            processFile(baseCmd, fileToProcess, failedToConvertFile, stage)

def processFilesInList(baseCmd, filesToConvert, failedToConvertFile, stage):
    if os.path.exists(filesToConvert):
        inFile = open(filesToConvert, 'r')
        for line in inFile:
            fileToProcess = line.rstrip('\n')
            processFile(baseCmd, fileToProcess, failedToConvertFile, stage)
    else:
        print('The path provided for filesToConvert file does not exists')
        sys.exit(1)

def printHelp():
    print('************************************************')
    print('Example : migrate_python.py -path <directory_to_convert>')
    print('Example : migrate_python.py -fromList <file_to_convert>')
    print('file_to_convert contains rows :')
    print('  /location/to/file/<python_file_name_1>')
    print('  /location/to/file/<python_file_name_2>')
    print('More info:')
    print('https://j.m0012242008.com/confluence/display/EN/Python+migration+-+Stage+2')
    print('https://j.m0012242008.com/confluence/display/EN/Troubleshooting+futurize+errors')
    print('************************************************')

def main():
    cmd = 'command -v futurize'
    process = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    output = process.communicate()[0]
    if (len(output) == 0):
        print('************************************************')
        print('ERROR: Please install python3-devel')
        print('sudo yum install python3 python3-devel python2-future python3-future')
        print('************************************************')
        sys.exit(1)
    stage = str('--stage3')
    pathToSearch = str('')

    fileToConvert = str('')
    filesToConvert = str('')
    failedToConvert = str('files_to_convert.failed')
    failedToConvertFile = None

    parser = ArgumentParser(description='Migrate python script to version 3 using futurize.')
    parser.add_argument("-path", "--path", help="migrate_python.py -path <directory_to_convert> \
        The script will execute futurize command for every python \
        file (that has svn attributes) starting from <directory_to_convert> \
        It will also add a comment line in the header of the migrated file")
    parser.add_argument("-fromList", "--fromList", help="migrate_python.py -fromList <files_to_convert> \
        For every python file from the list provided in <files_to_convert>, \
        (formatted as a file per line) \
        This option will also generate a file <files_to_convert>.failed \
        Which will be in the correct format to use as the argument \
        to -fromList so that we can rename and use it again. \
        The script will execute futurize command add an header in \
        the migrated file to record success/failure")
    parser.add_argument("-stage1", "--stage1", action='store_true', help="executes futurize stage1 on \
        the python script")
    parser.add_argument("-stage2", "--stage2", action='store_true', help="executes futurize stage2 on \
        the python script. This is the default stage if not provided")
    parser.add_argument("-stage3", "--stage3", action='store_true', help="executes 2to3 on \
        the python script.")
    parser.add_argument("-file", "--file", help="migrate_python.py -file <file_to_convert> \
        The script will execute futurize/2to3 command for  \
        file (that has svn attributes)")

    try:
        args = parser.parse_args()
    except:
        printHelp()
        sys.exit(0)

    pathToSearch = args.path
    filesToConvert = args.fromList
    fileToConvert = args.file

    # check if user addedstage1 as migration option
    # by default we set stage3 as migration stage if user do not specify it
    # PS: stage3 is 2to3 !!! the final step for migration to python 3
    if args.stage1:
        stage = str('--stage1')
    elif args.stage2:
        stage = str('--stage2')
    elif args.stage3:
        stage = str('--stage3')


    if (not pathToSearch) and (not filesToConvert) and (not fileToConvert):
        print('************************************************')
        print('ERROR: either path , fromList or file parameter must be present.')
        print('Example : migrate_python.py -path <directory_to_convert>')
        print('Example : migrate_python.py -fromList <file_to_convert>')
        print('Example : migrate_python.py -file <python_file.py>')
        print('************************************************')
        sys.exit(1)

    if MIGRATE_STAGE_3 == stage:
        baseCmd = '2to3-3 --no-diffs -x input -w '
    else:
        baseCmd = 'futurize ' + stage + ' --no-diffs -n -w '

    if filesToConvert:
        failedToConvert = filesToConvert + '.failed'
    failedToConvertFile = open(failedToConvert, 'w')

    if pathToSearch:
        processFilesInPath(pathToSearch, baseCmd, failedToConvertFile, stage)
    elif filesToConvert:
        processFilesInList(baseCmd, filesToConvert, failedToConvertFile, stage)
    elif fileToConvert:
        processFile(baseCmd, fileToConvert, failedToConvertFile, stage)

    failedToConvertFile.close()

    sys.exit(0)

#===============================================================================

if __name__ == '__main__':
    main()
