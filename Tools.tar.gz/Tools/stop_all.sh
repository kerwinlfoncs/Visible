stop_engine.py
stop_gateway_proxy.sh
#sudo /usr/sbin/tomcat stop
/opt/Activemq/apache-activemq-5.*.*/bin/activemq stop
stop_notifier.sh
stop_payment_service.sh
stop_rsgateway.sh
#stop_network_protocol_gateway.sh

