#!/bin/bash

# only support rewards, not product catalog meta data

#function
add_refer_mdc_in_yaml_file () {

    referral_conf=("referral_rewards: "\
               "\ \ catalog.id: 2"\
               "\ \ subscriber_extension_mdc.name: Demo2SubscriberObjectExtension"\
               "\ \ purchase_extension_mdc.name: Test_001_OfferExtension")

    echo "" >> /opt/mtx/conf/rsgateway.yaml
    for r_conf in "${referral_conf[@]}"
    do
        crs=`grep -x $r_conf /opt/mtx/conf/rsgateway.yaml | wc -l`
        if [ $crs -eq 0 ]
        then
           sed -i "$ a $r_conf" /opt/mtx/conf/rsgateway.yaml
        fi
    done
    echo "=========================/opt/mtx/conf/rsgateway.yaml========================="
    cat /opt/mtx/conf/rsgateway.yaml

}

add_refer_mdc_in_properties_file () {

    referral_conf=("referral_rewards.catalog.id=2"\
               "referral_rewards.subscriber_extension_mdc.name=Demo2SubscriberObjectExtension"\
               "referral_rewards.purchase_extension_mdc.name=Test_001_OfferExtension")

    for r_conf in "${referral_conf[@]}"
    do
        crs=`grep -x $r_conf /opt/mtx/conf/rsgateway.properties | wc -l`
        if [ $crs -eq 0 ]
        then
           sed -i "$ a $r_conf" /opt/mtx/conf/rsgateway.properties
        fi
    done
    echo "=========================/opt/mtx/conf/rsgateway.properties========================="
    cat /opt/mtx/conf/rsgateway.properties

}


add_mdc_declare_in_file () {
    file=$1
    # Not support from 5200
    #echo "productcatalog-mdc:      /productcatalog-mdc.xml" > $file
    echo "referral-mdc:      /referral-mdc.xml" >> $file
}

#step1: populate rsgateway extension jar
if [ ! -d /opt/mtx/ext ]
then
    echo "Going to create ext directory"
    mkdir /opt/mtx/ext
elif [ ! -d /opt/mtx/ext/rsgateway ]
then
    echo "Going to create ext/rsgateway directory"
    mkdir /opt/mtx/ext/rsgateway
fi

echo "Starting to copy extension jar from /opt/mtx/bin to /opt/mtx/ext/rsgateway"
#cp /opt/mtx/bin/rsgw-productcatalog.jar /opt/mtx/ext/rsgateway
cp /opt/mtx/bin/rsgw-referral-rewards.jar /opt/mtx/ext/rsgateway


#step2: populate extension-containers.properties
echo "Starting to add  mdc definition  in  /opt/mtx/conf/extension-containers.properties"
add_mdc_declare_in_file /opt/mtx/conf/extension-containers.properties
echo "=========================/opt/mtx/conf/extension-containers.properties========================="
cat /opt/mtx/conf/extension-containers.properties


#step3: update rsgateway.properties
#echo "Going to check and add refer mdc in rsgateway.properties"
#add_refer_mdc_in_properties_file

echo "Going to check and add refer mdc in rsgateway.yaml"
add_refer_mdc_in_yaml_file
#step4: restart rsgateway
restart_rsgateway.sh

