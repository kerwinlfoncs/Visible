from threading import Thread
import http.client,json,dateutil.parser,datetime,logging,math,base64,ssl,random,os,binascii,traceback,yaml, inspect
from pytz import timezone
from dotmap import DotMap
from stompest.sync import Stomp
from stompest.config import StompConfig
from .stats import get_stats
from timeit import default_timer as timer
from decimal import Decimal

SUBMANURL='/rsgateway/data/json'
PMURLOBJID='/rsgateway/data/json/subscriber/%s/payment_method?returnDefault=true'
PMURLEXTID='/rsgateway/data/json/subscriber/ExternalId+%s/payment_method?returnDefault=true'
VPASURL='/rsgateway/data/json/visible/1/payment_advice?subscriberExternalId=%s&includeTaxDetails=Y'
VIS_RECH_URL='/rsgateway/data/json/visible/1/visible_recharge'

MTX_API_SUCCESS_CODE = 0

VIS_RECH_CONTAINER = "VisibleRequestRecharge"
PUR_OFFER_CONTAINER = "MtxRequestSubscriberPurchaseOffer"
MOD_OFFER_CONTAINER = "MtxRequestSubscriberModifyOffer"
MOD_SUB_CONTAINER = "MtxRequestSubscriberModify"
SUB_SEARCH_CONTAINER = "MtxSubscriberSearchData"
PO_ATTR_CONTAINER = "VisiblePurchasedOfferExtension"
DEVICE_QUERY_CONTAINER = 'MtxRequestDeviceQuery'
FAIL_NOTIF_CONTAINER = 'MtxPaymentFailureNotification'
SUCCESS_NOTIF_CONTAINER = 'MtxPaymentSuccessNotification'


PARSE_NONE=0
PARSE_JSON=1
PARSE_YAML=2

KEY_OBJID=0
KEY_EXTID=1

class ConnectionError(Exception):
  pass

def isNotBlank(s):
  return bool(s and s.strip())

def fixts(ts):
  s=ts.isoformat()
  if s[19]!='.':
    s=s[:19]+'.000000'+s[19:]
  return s

class Processor(Thread):
  def __init__(self,config,subq,sublogq):
    Thread.__init__(self)
    self.config=config
    self.subq=subq
    self.sublogq=sublogq
    self.advance=datetime.timedelta(hours=int(self.config.delta_hours))
    self.manual_advance=datetime.timedelta(hours=int(self.config.manual_delta_hours))
    self.retry_wait=datetime.timedelta(hours=int(self.config.retry_wait_hours))
    self.not_queue='/queue/%s'%self.config.notification_queue
    self.dryrun=config.dryrun
    self.stats=get_stats()
    self.last_response=None

  def open_connections(self):

    re=random.choice(self.config.rest_endpoints)
    if 'username' in re:
      self.rest_cred=base64.b64encode("%s:%s"%(re.username,re.password))
    else:
      self.rest_cred=None
    if re.use_https:
      self.con=http.client.HTTPSConnection(re.host,re.port,timeout=60,context=ssl._create_unverified_context())
    else:
      self.con=http.client.HTTPConnection(re.host,re.port,timeout=60)

    stomp_config=StompConfig(self.config.stomp)
    self.stomp_client=Stomp(stomp_config)
    self.stomp_client.connect()
    logging.info('Connections opened')

  def get_sub(self,xid):
    key,value=xid
    logging.debug('Querying subscriber %s/%s'%(key,value))
    req=DotMap({"$":"MtxRequestSubscriberQuery"})
    ss=DotMap({"$":SUB_SEARCH_CONTAINER})
    if key==KEY_OBJID:
      ss.ObjectId=value
    elif key==KEY_EXTID:
      ss.ExternalId=value
    req.SubscriberSearchData=ss
    return self.call(self.con,SUBMANURL,req,cred=self.rest_cred,log_request=self.config.log_subscribers,logq=self.sublogq)

  def run(self):
    logging.info('Thread started')
    logging.info(self.sublogq)
    try:
      self.open_connections()
      while True:
        msg=self.subq.get()
        if msg is None:
          return
        else:
          try:
            self.process_one(msg)
          except ConnectionError:
            self.stats.incr('899 -   Skip subscriber due to connection error')
            logging.error('Reopen connections due to connection error and retry')
            self.open_connections()
          except Exception as ex:
            traceback.print_exc()
            logging.error('Exception %s %s'%(type(ex).__name__,ex.args))
            self.stats.incr('898 -   Skip subscriber due to data error')
            if self.last_response is not None:
              logging.error('Last subscriber response was\n'+self.last_response.decode('ascii'))
    except Exception as ex:
      logging.error('Exception %s %s'%(type(ex).__name__,ex.args))
    finally:
      logging.info('Thread exiting')

  def get_devices(self,sub_data):
    sub_data.calc.service_mdn=None
    sub_data.calc.wearable_mdn=None
    try:
      rl=[]
      for did in sub_data.sub['DeviceIdArray']:
        req=DotMap({"$":DEVICE_QUERY_CONTAINER})
        sd=DotMap({"$":"MtxDeviceSearchData"})
        sd.ObjectId=did
        req.DeviceSearchData=sd
        rl.append(req)

      # Parse as YAML because of MTXSALES-2808
      for resp in self.execute_rl(rl,override_dryrun=True,log_request=self.config.log_subscribers,logq=self.sublogq,parse=PARSE_YAML)['ResponseList']:
        try:
          if 'Attr' in resp and 'DeviceType' in resp['Attr']:
            dt=resp['Attr']['DeviceType'].upper()
          else:
            dt='PHONE'
          if dt in ('PHONE'):
            sub_data.calc.service_mdn=str(resp['Attr']['AccessNumberArray'][0])
          elif dt in ('WEARABLE'):
            sub_data.calc.wearable_mdn=str(resp['Attr']['AccessNumberArray'][0])
        except:
          pass
    except:
      pass

  ###########Process Autopay for One Subscriber###########
  def process_one(self,xid):
    self.stats.incr('100 - Subscribers processed')
    sub=self.get_sub(xid)
    oid=sub['ObjectId']
    now=datetime.datetime.now(timezone('UTC'))+datetime.timedelta(hours=int(self.config.test_offset))
    logging.debug('Now is %s'%str(now))

    if 'ExternalId' in sub:
      extid=sub['ExternalId']
    else:
      extid=''

    try:
      paypref=sub['Attr']['PaymentPreference']
    except:
      logging.error('Unable to get payment preference for sub %s'%oid)
      paypref=None

    if paypref.upper()==self.config.manual_payment_method.upper():
      self.stats.incr('269 -   Payment preference ManualPay')
      return

    if paypref.upper()!=self.config.payment_method.upper():
      self.stats.incr('268 -   Payment preference NOT AutoPay')
      return

    self.stats.incr('200 -   Payment preference AutoPay')

    # Build a dotmap with all the data needed for the recharge call
    sub_data=DotMap(sub=sub,oid=oid,extid=extid)

    # Generate a random 16 digit hex string for the orderid
    sub_data.calc=DotMap(orderid=binascii.b2a_hex(os.urandom(8)).decode('ascii'))

    # Figure out if subscriber is due for recharge
    due=self.recharge_due(sub_data,now)
    sub_data.calc.due=due

    if due.pdue:
      self.stats.incr('230 -     Recharge attempted')
      self.get_devices(sub_data)
      error=self.recharge(sub_data)
      if error is not None:
        self.send_notification(sub,now,FAIL_NOTIF_CONTAINER,68,due)
        self.update_paymentretry(oid,now)
      else:
        # Cobble together various request lists (modify offer or purchase offer)
        mr = DotMap({"$": "MtxRequestMulti"})
        rl = due.lifetime + due.credit_transfer_req_list + due.update_offers
        mr.RequestList = rl

        resp = DotMap(self.call(self.con, SUBMANURL, mr, cred=self.rest_cred))

        if self.dryrun or MTX_API_SUCCESS_CODE == resp.Result:
          logging.info('Recharge successful and Subscriber was updated with new taxes and payment date.')
          self.stats.incr('287 -       Subscriber update successful after recharge')
          self.send_notification(sub, now, SUCCESS_NOTIF_CONTAINER, 69, due)
          self.update_paymentdate(sub_data)
          return None
        else:
          self.stats.incr('288 -       Subscriber update error after recharge')
          logging.info('Recharge successful but Subscriber was not updated with ceredits, taxes and payment date.')
          logging.debug('Recharge failed due to %s' % resp.ResultText)
          self.send_notification(sub, now, FAIL_NOTIF_CONTAINER, 68, due)
          self.update_paymentretry(oid, now)
          return resp.ResultText

    else:
      self.stats.incr('270 -     Recharge not due')
      # If the reason for no recharge due was that the subscriber still had sufficient money,
      # then still do the credit transfer and update PaidCycleStartDate
      if due.sufficient:
        logging.debug('Not recharged due to sufficient balance so only purchasing credit transfer offers')
        sub_data.calc.orderid = None
        self.execute_rl(due.credit_transfer_req_list)
        self.update_paymentdate(sub_data)

  ###########Update payment date in beneficiary attributes after recharge###########
  def update_paymentdate(self,sub_data):
    rl=sub_data.calc.due.update_paidcycle
    req=DotMap({"$":MOD_SUB_CONTAINER})
    ss=DotMap({"$":SUB_SEARCH_CONTAINER})
    ss.ObjectId=sub_data.oid
    req.SubscriberSearchData=ss
    se=DotMap({"$":"VisibleSubscriberExtension"})
    se.PaymentDate=fixts(sub_data.calc.due.endtime)
    req.Attr=se
    rl.append(req)

    self.execute_rl(rl)

  ###########Update payment retry in case of failure###########
  def update_paymentretry(self,oid,now):
    req=DotMap({"$":MOD_SUB_CONTAINER})
    ss=DotMap({"$":SUB_SEARCH_CONTAINER})
    ss.ObjectId=oid
    req.SubscriberSearchData=ss
    se=DotMap({"$":"VisibleSubscriberExtension"})
    se.PaymentRetry=fixts(now)
    req.Attr=se
    if self.dryrun:
      logging.info('DRYRUN - would execute\n'+json.dumps(req.toDict()))
    else:
      resp=DotMap(self.call(self.con,SUBMANURL,req,cred=self.rest_cred))
      if resp.ResultText!='OK':
        logging.error('Failed to update PaymentDate for %s, error %s'%(oid,resp.ResultText))

  ###########Update payment method for notification. Not passed to Matrixx. Matrixx gets from Matrixx DB###########
  def get_payment_method_name(self,objid):
    resp=DotMap(self.call(self.con,PMURLOBJID%objid,'',use_get=True,cred=self.rest_cred),_dynamic=False)
    try:
      name=resp.PaymentMethodInfoList[0].Name
      if name is None:
        return ''
      else:
        return name
    except (KeyError,AttributeError):
      return ''

  ###########Update payment method for notification. Not passed to Matrixx. Matrixx gets from Matrixx DB###########
  def get_pmn_by_extid(self,extid):
    resp=DotMap(self.call(self.con,PMURLEXTID%extid,'',use_get=True,cred=self.rest_cred),_dynamic=False)
    try:
      name=resp.PaymentMethodInfoList[0].Name
      if name is None:
        return ''
      else:
        return name
    except (KeyError,AttributeError):
      return ''

  ###########Put notification on queue###########
  def send_notification(self,sub,now,typ,nid,due):
    extid=''
    try:
      extid=sub['ExternalId']
    except:
      pass
    oid=sub['ObjectId']
    logging.info('AUDIT RECORD: Sending notification %s for subscriber %s/%s'%(typ,oid,extid))

    headers={'persistent':'true'}
    msg=DotMap({'$':typ})
    payer=DotMap({'$':'MtxPayerDetails'})
    try:
      msg.ObjectType=1
      msg.ObjectId=oid
      msg.ObjectExternalId=extid
      msg.Amount=str(due.amount)
      msg.Status=2
      msg.NotificationId=sub['ObjectId']+'|'+str(now)
      msg.NotificationType=nid
      msg.PaymentPreference=sub['Attr']['PaymentPreference']
      msg.ContactEmail=sub['ContactEmail']

      if due.endtime is not None:
        d=due.endtime-now
        m=int(d.days*24*60+d.seconds/60)
      else:
        m=0

      msg.BeforeCycleEnd=m
      mdays=int(math.ceil(m/(24.0*60.0)))
      msg.ExpirationNotificationOffset=mdays
      msg.ExpirationNotificationOffsetType='days'

      if due.endtime is not None: msg.ExpirationTime=due.endtime.isoformat()

      msg.OfferArray=due.offer_array

      try:
        msg.CycleLength=sub['Attr']['CycleLength']
      except:
        msg.CycleLength=''

      if isNotBlank(due.payer_external_id):
        pmn = self.get_pmn_by_extid(due.payer_external_id)
        payer.ExternalId=due.payer_external_id
        payer.PaymentMethodName=pmn
        msg.Payer = payer
      else:
        pmn = self.get_payment_method_name(oid)
        msg.PaymentMethodName = pmn

    except:
      pass

    jmsg=json.dumps(msg.toDict()).encode('ascii')

    if self.dryrun:
      logging.debug('DRYRUN - Would send notification\n%s'%jmsg)
    else:
      logging.debug('Sending notification\n%s'%jmsg)
      self.stomp_client.send(self.not_queue,jmsg,headers)

  ###########Call Matrixx multirequest execute###########
  def execute_rl(self,rl,override_dryrun=False,log_request=False,logq=None,parse=PARSE_JSON):
    if len(rl)==0:
      logging.debug('Do not execute an empty request list')
      return None
    mr=DotMap({"$":"MtxRequestMulti"})
    mr.RequestList=rl
    if self.dryrun and not override_dryrun:
      logging.debug('DRYRUN - would execute\n'+json.dumps(mr.toDict()))
      return None
    else:
      resp=DotMap(self.call(self.con,SUBMANURL,mr,cred=self.rest_cred,log_request=log_request,logq=logq,parse=parse))
      return resp


  ########### Call Visible Recharge Api. OOB recharge without Payer. Otherwise does transfer balance to beneficiary###########
  def recharge(self,sd):
    logging.info('AUDIT RECORD: Subscriber %s/%s is due to be auto re-charged now with the amount %s'%(sd.oid,sd.extid,str(sd.calc.due.amount)))
    req=DotMap({"$":VIS_RECH_CONTAINER})
    ss=DotMap({"$":SUB_SEARCH_CONTAINER})
    ss.ObjectId=sd.oid
    req.SubscriberSearchData=ss
    req.Amount=str(sd.calc.due.amount)
    req.PayNow='1'
    req.Reason='purchase_service'
    cma=DotMap({"$":"VisibleBraintreeChargeMethodExtension"})
    cma.TransactionType=self.config.transaction_type
    cma.OrderId=sd.calc.orderid
    cma.VisibleRecurringOverride=self.config.visible_recurring_override
    cmd=DotMap({"$":"MtxChargeMethodData"})
    cmd.ChargeMethodAttr=cma
    req.ChargeMethodData=cmd
    ra=DotMap({'$':'VisibleRechargeExtension'})
    ra.OrderId=sd.calc.orderid

    has_base_device = sd.calc.service_mdn is not None
    has_base_offer = sd.calc.due.base_offer_extid is not None
    is_nonzero_base_recharge = sd.calc.due.base_payable_amount > 0
    is_base_recharge_cycle = has_base_device and has_base_offer and is_nonzero_base_recharge

    if is_base_recharge_cycle:
      ra.RatePlan=sd.calc.due.base_offer_extid
      ra.ServiceMDN = sd.calc.service_mdn
      if sd.calc.due.plan_amount is not None:
        ra.PlanAmount=str(sd.calc.due.plan_amount)

    has_wearable_device = sd.calc.wearable_mdn is not None
    has_wearable_offer = sd.calc.due.wearable_rate_plan is not None
    is_standalone_wearable = has_wearable_device and has_wearable_offer and (sd.calc.due.wearable_payable_amount > 0)
    not_standalone_wearable = has_wearable_device and has_wearable_offer and (sd.calc.due.wearable_payable_amount <= 0)
    is_free_wearable = not_standalone_wearable and is_nonzero_base_recharge

    if is_standalone_wearable or is_free_wearable:
      ra.WearableMDN=sd.calc.wearable_mdn
      ra.WearableRatePlan = sd.calc.due.wearable_rate_plan
      if sd.calc.due.wearable_plan_amount is not None:
        ra.WearablePlanAmount=str(sd.calc.due.wearable_plan_amount)

    if sd.calc.due.purchase_service_type is not None:
      vsd=DotMap({'$':'VisibleServiceDetails'})
      vsd.ChangeServiceReason=sd.calc.due.purchase_service_type
      ra.VisibleServiceInfoArray=[vsd]
    req.RechargeAttr=ra

    if("payer_external_id" in sd.calc.due and sd.calc.due.payer_external_id is not None and isNotBlank(sd.calc.due.payer_external_id)):
      req.PayerExternalId = sd.calc.due.payer_external_id

    if self.dryrun:
      self.stats.incr('234 -       Dryrun')
      logging.debug('DRYRUN - would execute\n'+json.dumps(mr.toDict()))
      return None
    else:
      resp = DotMap(self.call(self.con, VIS_RECH_URL, req, cred=self.rest_cred))

    if self.dryrun or MTX_API_SUCCESS_CODE == resp.Result:
      logging.info('AUDIT RECORD SUCCESS: Subscriber %s/%s was successfully re-charged with the amount of %s'%(sd.oid,sd.extid,str(sd.calc.due.amount)))
      self.stats.incr('232 -       Recharge successful')
      return None
    else:
      self.stats.incr('233 -       Recharge failed')
      logging.info('AUDIT RECORD ERROR: Subscriber %s/%s re-charged with the amount of %s failed due to %s'%(sd.oid,sd.extid,str(sd.calc.due.amount),resp.ResultText))
      logging.debug('Recharge failed due to %s'%resp.ResultText)
      return resp.ResultText

  def paused(self,sub,now):
    if sub['StatusDescription']=='Pause':
      attr=sub['Attr']
      if attr['SubscriberPause']=='Disabled':
        return False
      if len(attr['PauseEndDate'])!=0:
        endtime=dateutil.parser.parse(attr['PauseEndDate'])
      else:
        raise RuntimeError('PauseEndDate has an illegal value')
      if endtime-now>=self.advance:
        return True
    return False

  def has_activation_in_window(self,sub,now,endtime):
    try:
      for po in sub['PurchasedOfferArray']:
        act=dateutil.parser.parse(po['ActivationTime'])
        if endtime-act<self.advance:
          return True
      return False
    except:
      return False

  def recharge_due(self,sub_data,now):
    sub=sub_data.sub
    extid=sub_data.extid
    result=DotMap(pdue=False,sufficient=False)
    try:
      if sub['StatusDescription'] not in ('Active','Pause'):
        self.stats.incr('271 -       Status not Active or Pause')
        return result

      attr=sub['Attr']

      if self.paused(sub,now):
        self.stats.incr('272 -       Paused')
        return result

      result.endtime=None

      for bal in sub['BalanceArray']:
        if bal['Name']==self.config.check_balance:
          result.endtime=dateutil.parser.parse(bal['EndTime'])

        if result.endtime is not None:
          break

      if result.endtime is None:
        logging.debug('EndTime is not set')
        self.stats.incr('280 -       Subscriber data error')
        return result

      if result.endtime-now>=self.advance:
        self.stats.incr('273 -       Recharge not due - window not reached')
        logging.info('AUDIT RECORD: Subscriber %s/%s is not due because %s (next cycle) - %s (now) = %s'%(sub['ObjectId'],extid,fixts(result.endtime),fixts(now),str(result.endtime-now)))
        return result

      if 'TerminateDate' in attr and len(attr['TerminateDate'])!=0:
        termdate=dateutil.parser.parse(attr['TerminateDate'])
        if termdate<=result.endtime:
          self.stats.incr('277 -       Termination date <= next cycle')
          logging.info('AUDIT RECORD: Subscriber %s/%s is due but termination date %s <= next cycle %s'%(sub['ObjectId'],extid,fixts(termdate),fixts(result.endtime)))
          return result

      if 'PaymentDate' in attr and len(attr['PaymentDate'])!=0:
        paymdate=dateutil.parser.parse(attr['PaymentDate'])
        if paymdate==result.endtime:
          if not self.has_activation_in_window(sub,now,result.endtime):
            self.stats.incr('274 -       Recharge not due - already done')
            return result
          else:
            logging.info('AUDIT RECORD: Subscriber %s is not due but ActivationTime within recharge window'%sub['ObjectId'])

      if 'PaymentRetry' in attr and len(attr['PaymentRetry'])!=0:
        retrydate=dateutil.parser.parse(attr['PaymentRetry'])
        if now-retrydate<self.retry_wait:
          self.stats.incr('275 -       Recharge due but in retry period')
          return result

      recharge=self.get_recharge_amount(sub_data,result)
      if recharge is None:
        return result

      if recharge<=Decimal('0'):
        self.stats.incr('276 -       Recharge due but has sufficient balance')
        logging.info('AUDIT RECORD: Subscriber %s/%s is due but has sufficient balance (aoc %s)'%(sub['ObjectId'],extid,str(recharge)))
        result.sufficient=True
        return result
    except Exception as ex:
      self.stats.incr('280 -       Subscriber data error')
      logging.debug('Could not determine recharge_due due to exception %s %s'%(type(ex).__name__,ex.args))
      result=DotMap(pdue=False,sufficient=False)
      return result

    result.pdue=True
    result.amount=recharge
    return result

  def get_rf_requests(self,sub_data,pa,calc):
    logging.debug('Get credit request list')

    sub=sub_data.sub
    rl=[]
    taxdetails=[]

    try:
      if 'Credits' in pa:
        for cr in pa.Credits:
          etc=Decimal(cr.EstimatedTransferableCredits)
          rc=Decimal(cr.RedeemableCredits)
          update=(etc!=Decimal('0'))
          logging.debug('Processing credit %s ETC %s CR %s Update %s'%(cr.PromotionName,str(etc),str(rc),str(update)))
          if update:
            req=DotMap({"$":PUR_OFFER_CONTAINER})
            ss=DotMap({"$":SUB_SEARCH_CONTAINER})
            ss.ObjectId=sub['ObjectId']
            req.SubscriberSearchData=ss
            pod=DotMap({"$":"MtxPurchasedOfferData"})
            pod.ExternalId=cr.CreditRedeemableOfferCI
            poe=DotMap({"$":PO_ATTR_CONTAINER})
            poe.ChargeAmount=str(cr.EstimatedTransferableCredits)
            poe.GoodType=cr.PromotionName
            pod.Attr=poe
            req.OfferRequestArray=[pod]
            rl.append(req)
            taxdetails.append(cr.TaxDetails)
          else:
            pass
            # taxdetails.append('') MTXSALES-1939

      if len(taxdetails)==0:
        taxdetails=['']

      if calc.first_run and calc.base_offer_resid is not None:
        req=DotMap({'$':MOD_OFFER_CONTAINER})
        ss=DotMap({"$":SUB_SEARCH_CONTAINER})
        ss.ObjectId=sub['ObjectId']
        req.SubscriberSearchData=ss
        req.ResourceId=calc.base_offer_resid
        poe=DotMap({"$":PO_ATTR_CONTAINER})
        poe.CreditTaxDetailsArray=taxdetails
        req.Attr=poe
        rl.append(req)

    except Exception as ex:
      logging.error('Could not determine credits request list due to exception %s %s'%(type(ex).__name__,ex.args))
      raise

    try:
      if 'SubscriberGroups' in pa:
        if len(pa.SubscriberGroups)>=1:
          if calc.base_offer_resid is not None:
            req=DotMap({'$':MOD_OFFER_CONTAINER})
            ss=DotMap({"$":SUB_SEARCH_CONTAINER})
            ss.ObjectId=sub['ObjectId']
            req.SubscriberSearchData=ss
            req.ResourceId=calc.base_offer_resid
            poe=DotMap({"$":PO_ATTR_CONTAINER})
            poe.GroupMemberCount=pa.SubscriberGroups[0].SubscriberMemberCount
            req.Attr=poe
            rl.append(req)
    except Exception as ex:
      logging.error('Could not determine subscriber member count due to exception %s %s'%(type(ex).__name__,ex.args))
      raise

    return rl

  def get_recharge_amount(self,sub_data,result):
    sub=sub_data.sub
    oid=sub_data.oid
    extid=sub_data.extid
    try:
      resp=DotMap(self.call(self.con,VPASURL%extid,None,cred=self.rest_cred,use_get=True),_dynamic=False)
    except ConnectionError:
      logging.info('AUDIT RECORD ERROR: Subscriber %s/%s payment advice service connection error'%(oid,extid))
      raise
    if resp.Result != 0:
      self.stats.incr('279 -       Payment Advice Service failed')
      logging.info('AUDIT RECORD ERROR: Subscriber %s/%s payment advice service failed due to %s'%(oid,extid,resp.ResultText))
      logging.debug('Payment Advice Service failed due to %s'%resp.ResultText)
      return None,None,None,None,None,None

    result.update_offers=[]
    result.lifetime=[]
    result.update_paidcycle=[]
    result.offer_array=[]
    result.purchase_service_type = None

    result.plan_amount=None
    result.base_payable_amount = 0
    result.base_offer_resid=None

    result.wearable_plan_amount=None
    result.wearable_payable_amount = 0
    result.wearable_rate_plan=None
    result.payer_external_id=None
    if ("PayerExternalId" in resp and isNotBlank(resp.PayerExternalId)):
      result.payer_external_id=resp.PayerExternalId

    cst_date=dateutil.parser.parse(resp.CycleStartTime).date()

    if 'VisibleOfferDetailsList' in resp:
      for vod in resp.VisibleOfferDetailsList:
        try:
          is_base=False
          if vod.OfferType=='Base':
            is_base=True

            # Get some values
            result.base_offer_resid=vod.ResourceId
            result.base_offer_extid=vod.CatalogItemExternalId
            result.base_payable_amount = vod.PayableAmount

            if 'PurchaseServiceType' in vod:
              result.purchase_service_type=vod.PurchaseServiceType
            else:
              result.purchase_service_type=None

            # Figure out if this is first run or subsequent run
            result.first_run=False
            if "PaidCycleStartDate" not in vod:
              result.first_run=True
            else:
              pcsd=datetime.datetime.strptime(vod.PaidCycleStartDate,'%Y-%m-%d').date()
              if pcsd<cst_date:
                result.first_run=True
              else:
                result.first_run=False

          elif vod.OfferType=='Addon':
            #20241002 : Zero dollar wearables won't have taxes.
            result.wearable_plan_amount=vod.ChargeAmount
            result.wearable_rate_plan=vod.CatalogItemExternalId
            result.wearable_payable_amount = vod.PayableAmount

          # set TaxDetails in poe
          req=DotMap({'$':MOD_OFFER_CONTAINER})
          ss=DotMap({"$":SUB_SEARCH_CONTAINER})
          ss.ObjectId=sub_data.oid
          req.SubscriberSearchData=ss
          req.ResourceId=vod.ResourceId
          poe=DotMap({"$":PO_ATTR_CONTAINER})
          if 'TaxDetails' in vod: poe.TaxDetails=vod.TaxDetails

          if sub_data.calc.orderid is not None:
            poe.OrderId=sub_data.calc.orderid
          #if is_base and (vod.PayableAmount is not None) and (vod.PayableAmount > 0):
          if is_base:
            poe.PurchaseServiceType='Renewal'

          req.Attr=poe
          result.update_offers.append(req)

          # Purchase lifetime tracking offer
          if vod.OfferType=='Base':
            req=DotMap({"$":PUR_OFFER_CONTAINER})
            ss=DotMap({"$":SUB_SEARCH_CONTAINER})
            ss.ObjectId=sub['ObjectId']
            req.SubscriberSearchData=ss
            pod=DotMap({"$":"MtxPurchasedOfferData"})
            pod.ExternalId=self.config.TrackPayment.offer
            poe=DotMap({"$":PO_ATTR_CONTAINER})
            poe.ChargeAmount=str(vod.PayableAmount)
            pod.Attr=poe
            req.OfferRequestArray=[pod]
            result.lifetime.append(req)
            result.plan_amount=vod.ChargeAmount

          # Set PaidCycleStartDate
          # if (vod.PayableAmount is not None) and (vod.PayableAmount > 0):
          req=DotMap({'$':MOD_OFFER_CONTAINER})
          ss=DotMap({"$":SUB_SEARCH_CONTAINER})
          ss.ObjectId=sub_data.oid
          req.SubscriberSearchData=ss
          req.ResourceId=vod.ResourceId
          poe=DotMap({"$":PO_ATTR_CONTAINER})
          poe.PaidCycleStartDate=fixts(result.endtime)
          req.Attr=poe
          result.update_paidcycle.append(req)

          # Add to OfferArray
          if Decimal(vod.PayableAmount)>Decimal('0'):
            result.offer_array.append(vod.CatalogItemExternalId)

        except Exception as e:
          print(e)
          pass

    result.credit_transfer_req_list=self.get_rf_requests(sub_data,resp,result)
    return Decimal(resp.EstimatedPayableAmount)

  def manual_due(self,sub,now):
    try:
      if sub['StatusDescription'] not in ('Active','Pause'):
        return False

      attr=sub['Attr']

      if sub['StatusDescription']=='Pause':
        endtime=dateutil.parser.parse(attr['PauseEndDate'])
        if endtime-now>=self.manual_advance:
          return False

      endtime=None
      for bal in sub['BalanceArray']:
        if bal['Name']==self.config.check_balance:
          endtime=dateutil.parser.parse(bal['EndTime'])
          break
      if endtime is None:
        return False
      if endtime-now>=self.manual_advance:
        return False

    except Exception as ex:
      logging.debug('Could not determine recharge_due manual due to exception %s %s'%(type(ex).__name__,ex.args))
      return False

    return True

  def call(self,con,url,req,parse=PARSE_JSON,use_get=False,cred=None,log_request=True,logq=None):
    if isinstance(req,DotMap):
      req=json.dumps(req.toDict())
    if log_request:
      if logq is None:
        logging.debug('Call %s\n%s'%(url,req))
      else:
        logq.put('Call %s\n%s'%(url,req))
    start=timer()
    if use_get:
      meth='GET'
    else:
      meth='POST'
    headers={"Connection":"keep-alive","Content-Type":"application/json"}
    if cred is not None:
      headers['Authorization']='Basic %s'%cred
    try:
      con.request(meth,url,req,headers=headers)
      response=con.getresponse().read()
    except:
      raise ConnectionError

    self.last_response=response

    elapsed=timer()-start
    if log_request:
      if logq is None:
        logging.debug('Call took %.0f ms'%(elapsed*1000.0))
        logging.debug('Response\n'+str(response))
      else:
        logq.put('Call took %.0f ms'%(elapsed*1000.0))
        logq.put('Response\n'+str(response))
    if parse==PARSE_JSON:
      resp=json.loads(response,parse_float=Decimal)
    elif parse==PARSE_NONE:
      resp=response
    elif parse==PARSE_YAML:
      resp=yaml.safe_load(response)
    return resp

class Processors():
  def __init__(self,config,q,pricing,sublogq):
    self.config=config
    self.subq=q
    self.sublogq=sublogq

  def start(self):
    logging.info('Creating processor threads')
    self.threads=[]
    for i in range(self.config.threads):
      self.threads.append(Processor(self.config,self.subq,self.sublogq))
    logging.info('Threads created')
    for t in self.threads:
      t.start()
  def wait(self):
    logging.info('Waiting for processing threads to complete')
    for t in self.threads:
      self.subq.put(None)
    for t in self.threads:
      t.join()
    logging.info('Processor threads exited')
