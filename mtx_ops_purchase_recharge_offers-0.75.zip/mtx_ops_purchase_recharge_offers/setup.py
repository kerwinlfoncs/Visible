from distutils.core import setup

setup(name='mtx_ops_purchase_recharge_offers',
      version='0.75',
      packages=['mtx_pro'],
      scripts=['mtx_ops_purchase_recharge_offers'],
      data_files=[('etc',['mtx_ops_purchase_recharge_offers.yaml'])]
      )

