import unittest
import yaml, json, datetime
from dotmap import DotMap
from unittest.mock import patch
from stompest.sync import Stomp
from stompest.config import StompConfig
from mtx_pro.processor import Processor


class TestProcessorNotifications(unittest.TestCase):

    @patch('mtx_pro.processor.get_stats')
    @patch('mtx_pro.processor.Stomp.send')
    @patch.object(Processor, 'get_payment_method_name', return_value="MockCreditCard")
    def test_When_NoPayerExists_Then_NotificationHasNoPayer(self, mock_pmn, mock_stomp, mock_get_stats):
        now = datetime.datetime.now()

        with open('resources/due.json', 'r') as file:
            duedata = json.load(file)
        due = DotMap(duedata)
        due.endtime = now
        due.payer_external_id = ""

        with open('resources/subscriber.json', 'r') as file:
            subdata = json.load(file)
        subscriber = DotMap(subdata)

        with open('../mtx_ops_purchase_recharge_offers.yaml', 'r') as stream:
            config = DotMap(yaml.safe_load(stream), _dynamic=False)
        config.dryrun = False

        stomp_config = StompConfig(config.stomp)

        processor = Processor(config, None, None)
        processor.stomp_client = Stomp(stomp_config)

        # Act
        processor.send_notification(subscriber, now, 'MtxPaymentSuccessNotification', 69, due)

        # Assert
        mock_stomp.assert_called_once()

        args, kwargs = mock_stomp.call_args
        captured_bytes = args[1]
        captured_dict = json.loads(captured_bytes.decode('ascii'))
        print(captured_dict)

        assert None == captured_dict.get('Payer')

    @patch('mtx_pro.processor.get_stats')
    @patch('mtx_pro.processor.Stomp.send')
    @patch.object(Processor, 'get_payment_method_name', return_value="MockCreditCard")
    def test_When_NoPayerExists_Then_GetPaymentMethodByObjectId(self, mock_pmn, mock_stomp, mock_get_stats):
        now = datetime.datetime.now()

        with open('resources/due.json', 'r') as file:
            duedata = json.load(file)
        due = DotMap(duedata)
        due.endtime = now
        due.payer_external_id = ""

        with open('resources/subscriber.json', 'r') as file:
            subdata = json.load(file)
        subscriber = DotMap(subdata)

        with open('../mtx_ops_purchase_recharge_offers.yaml', 'r') as stream:
            config = DotMap(yaml.safe_load(stream), _dynamic=False)
        config.dryrun = False

        stomp_config = StompConfig(config.stomp)

        processor = Processor(config, None, None)
        processor.stomp_client = Stomp(stomp_config)

        # Act
        processor.send_notification(subscriber, now, 'MtxPaymentSuccessNotification', 69, due)

        # Assert
        mock_pmn.assert_called_once()

    @patch('mtx_pro.processor.get_stats')
    @patch('mtx_pro.processor.Stomp.send')
    @patch.object(Processor, 'get_pmn_by_extid', return_value="MockCreditCard")
    def test_When_PayerExists_Then_NotificationHasPayer(self, mock_pmn, mock_stomp, mock_get_stats):
        now = datetime.datetime.now()

        with open('resources/due.json', 'r') as file:
            duedata = json.load(file)
        due = DotMap(duedata)
        due.endtime = now

        with open('resources/subscriber.json', 'r') as file:
            subdata = json.load(file)
        subscriber = DotMap(subdata)

        with open('../mtx_ops_purchase_recharge_offers.yaml', 'r') as stream:
            config = DotMap(yaml.safe_load(stream), _dynamic=False)
        config.dryrun = False

        stomp_config = StompConfig(config.stomp)

        processor = Processor(config, None, None)
        processor.stomp_client = Stomp(stomp_config)

        # Act
        processor.send_notification(subscriber, now, 'MtxPaymentSuccessNotification', 69, due)

        # Assert
        mock_stomp.assert_called_once()

        args, kwargs = mock_stomp.call_args
        captured_bytes = args[1]
        captured_dict = json.loads(captured_bytes.decode('ascii'))
        print(captured_dict.get('Payer'))

        assert 'MtxPayerDetails' == captured_dict.get('Payer').get('$')
        assert due.payer_external_id == captured_dict.get('Payer').get('ExternalId')
        assert mock_pmn.return_value == captured_dict.get('Payer').get('PaymentMethodName')

    @patch('mtx_pro.processor.get_stats')
    @patch('mtx_pro.processor.Stomp.send')
    @patch.object(Processor, 'get_pmn_by_extid', return_value="MockCreditCard")
    def test_When_PayerExists_Then_GetPaymentMethodByExternalId(self, mock_pmn, mock_stomp, mock_get_stats):
        now = datetime.datetime.now()

        with open('resources/due.json', 'r') as file:
            duedata = json.load(file)
        due = DotMap(duedata)
        due.endtime = now

        with open('resources/subscriber.json', 'r') as file:
            subdata = json.load(file)
        subscriber = DotMap(subdata)

        with open('../mtx_ops_purchase_recharge_offers.yaml', 'r') as stream:
            config = DotMap(yaml.safe_load(stream), _dynamic=False)
        config.dryrun = False

        stomp_config = StompConfig(config.stomp)

        processor = Processor(config, None, None)
        processor.stomp_client = Stomp(stomp_config)

        # Act
        processor.send_notification(subscriber, now, 'MtxPaymentSuccessNotification', 69, due)

        # Assert
        mock_pmn.assert_called_once()


if __name__ == '__main__':
    unittest.main()
