import unittest
import yaml, json, datetime
from dotmap import DotMap
from unittest.mock import patch
from mtx_pro.processor import Processor
from collections import defaultdict

class TestProcessorRecharge(unittest.TestCase):

    @patch('mtx_pro.processor.get_stats')
    @patch.object(Processor, 'call', return_value=defaultdict)
    def test_When_Recharge_Then_Call_VisibleRecharge(self, mock_call, mock_get_stats):
        with open('resources/subscriber.json', 'r') as file:
            subdata = json.load(file)
        subscriber = DotMap(subdata)
        oid = "0-1-2-3"
        extid = "1234567890"
        sub_data = DotMap(sub=subscriber, oid=oid, extid=extid)

        with open('../mtx_ops_purchase_recharge_offers.yaml', 'r') as stream:
            config = DotMap(yaml.safe_load(stream), _dynamic=False)
        config.dryrun = False

        now = datetime.datetime.now()

        with open('resources/due.json', 'r') as file:
            duedata = json.load(file)
        due = DotMap(duedata)
        due.endtime = now
        due.payer_external_id = ""

        sub_data.calc = DotMap(orderid="O-1234")
        sub_data.calc.due = due

        processorObj = Processor(config, None, None)
        processorObj.con = None
        processorObj.rest_cred = None
        processorObj.recharge(sub_data)

        mock_call.assert_called_once()
        args, kwargs = mock_call.call_args

        rechargeRequest = args[2]
        rechargeUrl = args[1]
        print(rechargeRequest)

        from mtx_pro import processor
        assert processor.VIS_RECH_CONTAINER == rechargeRequest.get("$")
        assert processor.VIS_RECH_URL == rechargeUrl

    @patch('mtx_pro.processor.get_stats')
    @patch.object(Processor, 'call', return_value=defaultdict)
    def test_When_PayerExternalId_Then_CallHasPayerExternalId(self, mock_call, mock_get_stats):
        with open('resources/subscriber.json', 'r') as file:
            subdata = json.load(file)
        subscriber = DotMap(subdata)
        oid = "0-1-2-3"
        extid = "1234567890"
        sub_data = DotMap(sub=subscriber, oid=oid, extid=extid)

        with open('../mtx_ops_purchase_recharge_offers.yaml', 'r') as stream:
            config = DotMap(yaml.safe_load(stream), _dynamic=False)
        config.dryrun = False

        now = datetime.datetime.now()

        with open('resources/due.json', 'r') as file:
            duedata = json.load(file)
        due = DotMap(duedata)
        due.endtime = now
        due.payer_external_id = "9876543210"

        sub_data.calc = DotMap(orderid="O-1234")
        sub_data.calc.due = due

        processorObj = Processor(config, None, None)
        processorObj.con = None
        processorObj.rest_cred = None
        processorObj.recharge(sub_data)

        mock_call.assert_called_once()
        args, kwargs = mock_call.call_args

        rechargeRequest = args[2]
        print(rechargeRequest)

        assert due.payer_external_id == rechargeRequest.PayerExternalId

if __name__ == '__main__':
    unittest.main()
