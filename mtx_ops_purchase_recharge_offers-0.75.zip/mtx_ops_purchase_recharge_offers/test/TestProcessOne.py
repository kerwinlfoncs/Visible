import unittest
import yaml, json, datetime
from dotmap import DotMap
from unittest.mock import patch, MagicMock

import mtx_pro.processor
from mtx_pro.processor import Processor

class TestProcessOne(unittest.TestCase):

    @patch('mtx_pro.processor.get_stats')
    def test_ProcessOne_When_Success_Then_OrderOfRequests(self,  mock_get_stats):
        with open('../mtx_ops_purchase_recharge_offers.yaml', 'r') as stream:
            config = DotMap(yaml.safe_load(stream), _dynamic=False)
        config.dryrun = False
        now = datetime.datetime.now()

        with open('resources/subscriber.json', 'r') as file:
            subdata = json.load(file)
        subscriber = DotMap(subdata)
        mock_get_sub = MagicMock(return_value=subscriber)

        with open('resources/due.json', 'r') as file:
            duedata = json.load(file)
        due = DotMap(duedata)
        due.endtime = now
        due.payer_external_id = "5678912340"
        mock_recharge_due = MagicMock(return_value=due)

        mock_send_notification = MagicMock(return_value=None)
        mock_recharge = MagicMock(return_value=None)

        call_success = {"Result":0, "ResultText":"OK"}
        mock_subman_call = MagicMock(side_effect=[call_success,call_success,call_success])

        processorObj = Processor(config, None, None)
        processorObj.con = None
        processorObj.rest_cred = None
        processorObj.get_sub = mock_get_sub
        processorObj.recharge_due = mock_recharge_due
        processorObj.send_notification = mock_send_notification
        processorObj.recharge = mock_recharge
        processorObj.call = mock_subman_call
        processorObj.process_one("1234567890")

        calls = mock_subman_call.call_args_list
        #1st index = position in call list, 2ndIndex = parameters in a call 3rd index Multirequest input
        # 1st call - query device details
        assert mtx_pro.processor.DEVICE_QUERY_CONTAINER == calls[0][0][2].get("RequestList")[0].get("$")
        # 2nd call - Update offer and subscriber after recharge
        # purchase 'Visible_Update_Service_Payments'
        assert mtx_pro.processor.PUR_OFFER_CONTAINER == calls[1][0][2].get("RequestList")[0].get("$")
        # purchase credit redeem offer
        assert mtx_pro.processor.PUR_OFFER_CONTAINER == calls[1][0][2].get("RequestList")[1].get("$")
        # modify offer to add credit taxes
        assert mtx_pro.processor.MOD_OFFER_CONTAINER == calls[1][0][2].get("RequestList")[2].get("$")
        # modify offer to add member count
        assert mtx_pro.processor.MOD_OFFER_CONTAINER == calls[1][0][2].get("RequestList")[3].get("$")
        # modify offer to add orderid, purchase_service_type, taxes
        assert mtx_pro.processor.MOD_OFFER_CONTAINER == calls[1][0][2].get("RequestList")[4].get("$")

        # 3rd call - Update paymentdate and paidcyclestartdate
        # update paidcyclestartdate
        assert mtx_pro.processor.MOD_OFFER_CONTAINER == calls[2][0][2].get("RequestList")[0].get("$")
        # update paymentdate
        assert mtx_pro.processor.MOD_SUB_CONTAINER == calls[2][0][2].get("RequestList")[1].get("$")

    @patch('mtx_pro.processor.get_stats')
    def test_ProcessOne_When_UpdateMultiRequestFails_Then_OrderOfRequests(self,  mock_get_stats):
        with open('../mtx_ops_purchase_recharge_offers.yaml', 'r') as stream:
            config = DotMap(yaml.safe_load(stream), _dynamic=False)
        config.dryrun = False
        now = datetime.datetime.now()

        with open('resources/subscriber.json', 'r') as file:
            subdata = json.load(file)
        subscriber = DotMap(subdata)
        mock_get_sub = MagicMock(return_value=subscriber)

        with open('resources/due.json', 'r') as file:
            duedata = json.load(file)
        due = DotMap(duedata)
        due.endtime = now
        due.payer_external_id = "5678912340"
        mock_recharge_due = MagicMock(return_value=due)

        mock_send_notification = MagicMock(return_value=None)
        mock_recharge = MagicMock(return_value=None)

        call_success = {"Result":0, "ResultText":"OK"}
        call_fail = {"Result": -1, "ResultText": "OK"}
        mock_subman_call = MagicMock(side_effect=[call_success,call_fail,call_success])

        processorObj = Processor(config, None, None)
        processorObj.con = None
        processorObj.rest_cred = None
        processorObj.get_sub = mock_get_sub
        processorObj.recharge_due = mock_recharge_due
        processorObj.send_notification = mock_send_notification
        processorObj.recharge = mock_recharge
        processorObj.call = mock_subman_call
        processorObj.process_one("1234567890")

        calls = mock_subman_call.call_args_list
        #1st index = position in call list, 2ndIndex = parameters in a call 3rd index Multirequest input
        # 1st call - query device details
        assert mtx_pro.processor.DEVICE_QUERY_CONTAINER == calls[0][0][2].get("RequestList")[0].get("$")
        # 2nd call - Update offer and subscriber after recharge
        # purchase 'Visible_Update_Service_Payments'
        assert mtx_pro.processor.PUR_OFFER_CONTAINER == calls[1][0][2].get("RequestList")[0].get("$")
        # purchase credit redeem offer
        assert mtx_pro.processor.PUR_OFFER_CONTAINER == calls[1][0][2].get("RequestList")[1].get("$")
        # modify offer to add credit taxes
        assert mtx_pro.processor.MOD_OFFER_CONTAINER == calls[1][0][2].get("RequestList")[2].get("$")
        # modify offer to add member count
        assert mtx_pro.processor.MOD_OFFER_CONTAINER == calls[1][0][2].get("RequestList")[3].get("$")
        # modify offer to add orderid, purchase_service_type, taxes
        assert mtx_pro.processor.MOD_OFFER_CONTAINER == calls[1][0][2].get("RequestList")[4].get("$")
        # 3rd call - Update payment retry
        assert mtx_pro.processor.MOD_SUB_CONTAINER == calls[2][0][2].get("$")

    @patch('mtx_pro.processor.get_stats')
    def test_ProcessOne_When_RechargeFails_Then_OrderOfRequests(self,  mock_get_stats):
        with open('../mtx_ops_purchase_recharge_offers.yaml', 'r') as stream:
            config = DotMap(yaml.safe_load(stream), _dynamic=False)
        config.dryrun = False
        now = datetime.datetime.now()

        with open('resources/subscriber.json', 'r') as file:
            subdata = json.load(file)
        subscriber = DotMap(subdata)
        mock_get_sub = MagicMock(return_value=subscriber)

        with open('resources/due.json', 'r') as file:
            duedata = json.load(file)
        due = DotMap(duedata)
        due.endtime = now
        due.payer_external_id = "5678912340"
        mock_recharge_due = MagicMock(return_value=due)

        mock_send_notification = MagicMock(return_value=None)
        mock_recharge = MagicMock(return_value="Error Error Error")

        call_success = {"Result":0, "ResultText":"OK"}
        mock_subman_call = MagicMock(side_effect=[call_success,call_success])

        processorObj = Processor(config, None, None)
        processorObj.con = None
        processorObj.rest_cred = None
        processorObj.get_sub = mock_get_sub
        processorObj.recharge_due = mock_recharge_due
        processorObj.send_notification = mock_send_notification
        processorObj.recharge = mock_recharge
        processorObj.call = mock_subman_call
        processorObj.process_one("1234567890")

        calls = mock_subman_call.call_args_list
        #1st index = position in call list, 2ndIndex = parameters in a call 3rd index Multirequest input
        # 1st call - query device details
        assert mtx_pro.processor.DEVICE_QUERY_CONTAINER == calls[0][0][2].get("RequestList")[0].get("$")
        # 2nd call -  update payment retry
        assert mtx_pro.processor.MOD_SUB_CONTAINER == calls[1][0][2].get("$")

    @patch('mtx_pro.processor.get_stats')
    def test_ProcessOne_When_Success_Then_SuccessNotification(self,  mock_get_stats):
        with open('../mtx_ops_purchase_recharge_offers.yaml', 'r') as stream:
            config = DotMap(yaml.safe_load(stream), _dynamic=False)
        config.dryrun = False
        now = datetime.datetime.now()

        with open('resources/subscriber.json', 'r') as file:
            subdata = json.load(file)
        subscriber = DotMap(subdata)
        mock_get_sub = MagicMock(return_value=subscriber)

        with open('resources/due.json', 'r') as file:
            duedata = json.load(file)
        due = DotMap(duedata)
        due.endtime = now
        due.payer_external_id = "5678912340"
        mock_recharge_due = MagicMock(return_value=due)

        mock_send_notification = MagicMock(return_value=None)
        mock_recharge = MagicMock(return_value=None)

        call_success = {"Result":0, "ResultText":"OK"}
        mock_subman_call = MagicMock(side_effect=[call_success,call_success,call_success])

        processorObj = Processor(config, None, None)
        processorObj.con = None
        processorObj.rest_cred = None
        processorObj.get_sub = mock_get_sub
        processorObj.recharge_due = mock_recharge_due
        processorObj.send_notification = mock_send_notification
        processorObj.recharge = mock_recharge
        processorObj.call = mock_subman_call
        processorObj.process_one("1234567890")

        calls = mock_send_notification.call_args_list
        assert mtx_pro.processor.SUCCESS_NOTIF_CONTAINER == calls[0][0][2]

    @patch('mtx_pro.processor.get_stats')
    def test_ProcessOne_When_UpdateMultiRequestFails_Then_FailNotification(self,  mock_get_stats):
        with open('../mtx_ops_purchase_recharge_offers.yaml', 'r') as stream:
            config = DotMap(yaml.safe_load(stream), _dynamic=False)
        config.dryrun = False
        now = datetime.datetime.now()

        with open('resources/subscriber.json', 'r') as file:
            subdata = json.load(file)
        subscriber = DotMap(subdata)
        mock_get_sub = MagicMock(return_value=subscriber)

        with open('resources/due.json', 'r') as file:
            duedata = json.load(file)
        due = DotMap(duedata)
        due.endtime = now
        due.payer_external_id = "5678912340"
        mock_recharge_due = MagicMock(return_value=due)

        mock_send_notification = MagicMock(return_value=None)
        mock_recharge = MagicMock(return_value=None)

        call_success = {"Result":0, "ResultText":"OK"}
        call_fail = {"Result": -1, "ResultText": "OK"}
        mock_subman_call = MagicMock(side_effect=[call_success,call_fail,call_success])

        processorObj = Processor(config, None, None)
        processorObj.con = None
        processorObj.rest_cred = None
        processorObj.get_sub = mock_get_sub
        processorObj.recharge_due = mock_recharge_due
        processorObj.send_notification = mock_send_notification
        processorObj.recharge = mock_recharge
        processorObj.call = mock_subman_call
        processorObj.process_one("1234567890")

        calls = mock_send_notification.call_args_list
        assert mtx_pro.processor.FAIL_NOTIF_CONTAINER == calls[0][0][2]

    @patch('mtx_pro.processor.get_stats')
    def test_ProcessOne_When_RechargeFails_Then_FailNotification(self,  mock_get_stats):
        with open('../mtx_ops_purchase_recharge_offers.yaml', 'r') as stream:
            config = DotMap(yaml.safe_load(stream), _dynamic=False)
        config.dryrun = False
        now = datetime.datetime.now()

        with open('resources/subscriber.json', 'r') as file:
            subdata = json.load(file)
        subscriber = DotMap(subdata)
        mock_get_sub = MagicMock(return_value=subscriber)

        with open('resources/due.json', 'r') as file:
            duedata = json.load(file)
        due = DotMap(duedata)
        due.endtime = now
        due.payer_external_id = "5678912340"
        mock_recharge_due = MagicMock(return_value=due)

        mock_send_notification = MagicMock(return_value=None)
        mock_recharge = MagicMock(return_value="Error Error Error")

        call_success = {"Result":0, "ResultText":"OK"}
        mock_subman_call = MagicMock(side_effect=[call_success,call_success])

        processorObj = Processor(config, None, None)
        processorObj.con = None
        processorObj.rest_cred = None
        processorObj.get_sub = mock_get_sub
        processorObj.recharge_due = mock_recharge_due
        processorObj.send_notification = mock_send_notification
        processorObj.recharge = mock_recharge
        processorObj.call = mock_subman_call
        processorObj.process_one("1234567890")

        calls = mock_send_notification.call_args_list
        assert mtx_pro.processor.FAIL_NOTIF_CONTAINER == calls[0][0][2]

if __name__ == '__main__':
    unittest.main()
