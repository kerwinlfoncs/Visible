from timeit import default_timer as timer
import logging,json,base64,ssl,http.client
from dotmap import DotMap

SUBMANURL='/rsgateway/data/json'
PARSE_NONE=0
PARSE_JSON=1

class Pricing():
  def __init__(self,config):
    self.config=config

  def load_offers(self,olist):
    
    re=self.config.rest_endpoint
    if 'username' in re:
      self.cred=base64.b64encode("%s:%s"%(re.username,re.password))
    else:
      self.cred=None
    if re.use_https:
      self.con=http.client.HTTPSConnection(re.host,re.port,timeout=20,context=ssl._create_unverified_context())
    else:
      self.con=http.client.HTTPConnection(re.host,re.port,timeout=20)

    multi=DotMap({"$":"MtxRequestMulti"})
    rl=[]
    for offer in olist:
      req=DotMap({"$":"MtxRequestPricingQueryOffer"})
      ss=DotMap({"$":"MtxPricingOfferSearchData"})
      ss.ExternalId=offer
      req.OfferSearchData=ss
      rl.append(req)
    multi.RequestList=rl
    resp=self.call(self.con,self.cred,SUBMANURL,multi)
    self.offers={}
    for r in resp['ResponseList']:
      o=DotMap(r['OfferInfo'])
      self.offers[o.ExternalId]=o
    return self.offers

  def call(self,con,cred,url,req,parse=PARSE_JSON):
    if isinstance(req,DotMap):
      req=json.dumps(req.toDict())
    logging.debug('Call\n'+req)
    headers={"Connection":"keep-alive","Content-Type":"application/json"}
    if self.cred is not None:
      headers['Authorization']='Basic %s'%self.cred
    start=timer()
    con.request("POST",url,req,headers=headers)
    response=con.getresponse().read()
    elapsed=timer()-start
    logging.debug('Call took %.0f ms'%(elapsed*1000.0))
    logging.debug('Response\n'+response)
    if parse==PARSE_JSON:
      resp=json.loads(response)
    elif parse==PARSE_NONE:
      resp=response      
    return resp

