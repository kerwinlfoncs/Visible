from threading import Thread
import subscriber_mgmt_v3 as subman
import data_container as MDC
# Check if the data_container_defs.py needs to be re-created
# MDC.createDefsFileIfNeeded()
import data_container_defs as MDCDEFS
import logging
from .stats import get_stats

KEY_OBJID=0
KEY_EXTID=1

class Scanner(Thread):
  def __init__(self,config,subq):
    Thread.__init__(self)
    self.config=config
    self.subq=subq
    self.stats=get_stats()
    self.client=None
    self.con_idx=0
  def openconnection(self):
    host,port=self.config.mdc_endpoints[self.con_idx].split(':')
    port=int(port)
    self.client=subman.SubscriberManagementV3Client(hostName=host,hostPort=port)
    self.client.openConnection()
    logging.info('SubMan connection opened to %s %d'%(host,port))
  def run(self):
    logging.info('Thread started')
    try:
      self.scan()
    except Exception as ex:
      logging.error('Exception %s %s'%(type(ex).__name__,ex.args))
    finally:
      logging.info('Thread exiting')

  def scan(self):
    cursor=None
    moreObjects=True
    count=0
    retry=0
    while moreObjects:
      while True:
        try:
          if self.client is None:
            self.openconnection()
          resp=self.client.executeMulti(databaseId=1,containerKey=MDCDEFS.kMtxSubscriberObjectMdcDesc.containerKey,queryCursor=cursor)
          retry=0
          break
        except:
          retry+=1
          if retry==self.config.connection_max_retry:
            logging.error('Maximum connection retry reached. Exiting.')
            raise
          logging.error('Connection problem, moving to next connection')
          self.client=None
          self.con_idx=(self.con_idx+1)%len(self.config.mdc_endpoints) 
      if not subman.checkResultSuccess(resp):
        raise RuntimeError('ExecMulti failed')
      results=resp.getUsingKey(MDCDEFS.kMtxResponseExecuteMultiExecuteRequestResultListFldKey)
      if results:
        logging.debug('Batch retrieved length %d'%len(results))
        for result in results:
          self.subq.put((KEY_OBJID,result.getUsingKey(MDCDEFS.kMtxExecuteRequestResultObjectIdFldKey)))
          self.stats.incr('050 - Subscribers scanned',log=False)

      cursor=resp.getUsingKey(MDCDEFS.kMtxResponseExecuteMultiQueryCursorFldKey)
      if cursor is None:
        moreObjects=False


